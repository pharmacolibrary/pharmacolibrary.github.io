model Dextromoramide_Lanon1989_reference
  parameter Real Cl_ref = 2.3333333333333336e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.0406 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.39254300000000003,
    adminMass = 2e-05
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About dextromoramide</h4><p>Dextromoramide is a narcotic opioid analgesic, classified among diphenylpropylamine derivatives, that has been used as a painkiller. It is not an approved medicine today; databases list it as experimental and illicit, so it appears to have no current authorised medical use.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q408446\">Wikidata Q408446</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>dextromoramide</td></tr><tr><td>population:</td><td>surgical patients</td></tr><tr><td>source_paper:</td><td>Lançon_1989</td></tr><tr><td>measured_compound:</td><td>dextromoramide</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>dextromoramide 392.543 g/mol (drugbank)</td></tr></table><h4>Interpretation flags</h4><ul><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=dextromoramide</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Dextromoramide_Lanon1989_reference;
