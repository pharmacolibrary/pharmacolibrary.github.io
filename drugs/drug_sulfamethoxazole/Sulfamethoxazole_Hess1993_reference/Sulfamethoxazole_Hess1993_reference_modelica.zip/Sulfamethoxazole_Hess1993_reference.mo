model Sulfamethoxazole_Hess1993_reference
  parameter Real Cl_ref = 3.0333333333333337e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.14700000000000002 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.253278,
    adminMass = 1e-05
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About sulfamethoxazole</h4><p>Sulfamethoxazole is a sulfonamide antibiotic used to treat bacterial infections such as urinary tract infections, otitis media, acute bronchitis, toxoplasmosis, nocardiosis, and gram-negative infections. It remains in use, often combined with trimethoprim, and is also included in combination regimens for tuberculosis treatment.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q415843\">Wikidata Q415843</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>sulfamethoxazole</td></tr><tr><td>population:</td><td>adult trauma patients</td></tr><tr><td>source_paper:</td><td>Hess_1993</td></tr><tr><td>measured_compound:</td><td>sulfamethoxazole</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>sulfamethoxazole 253.278 g/mol (drugbank)</td></tr></table><h4>Interpretation flags</h4><ul><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=sulfamethoxazole</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 259200, Tolerance = 1e-9, Interval = 1));
end Sulfamethoxazole_Hess1993_reference;
