model Mezlocillin_Jungbluth1989_reference
  parameter Real Cl_ref = 9.15e-08 "Cl [m3/s]";
  parameter Real Vd_ref = 0.0287 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.539582,
    adminMass = 0.0014
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About mezlocillin</h4><p>Mezlocillin is an extended-spectrum penicillin antibiotic used to treat bacterial infections such as sepsis, urinary tract, skin, and respiratory infections, including Pseudomonas and other gram-negative infections. It is an approved antibacterial, though it is not authorised in the European Union and is now used only in a limited number of countries.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q3307752\">Wikidata Q3307752</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>mezlocillin</td></tr><tr><td>population:</td><td>male Sprague-Dawley rats</td></tr><tr><td>source_paper:</td><td>Jungbluth_1989</td></tr><tr><td>measured_compound:</td><td>mezlocillin</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>tab_1</td></tr><tr><td>input:</td><td>PK_1C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>mezlocillin 539.582 g/mol (drugbank)</td></tr></table><h4>Interpretation flags</h4><ul><li>dropped unlinked row (NIL): 'C3.ax, pg/ml (simulated)' — extend the ontology if this is a real PK parameter (source ['tab_1:row7:col1', 'tab_1:row7:col2'])</li><li>salvaged Q22 (&quot;CL'&quot;=5.49) from results prose — parameter table was unreadable</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=mezlocillin</li><li>held at status:extracted — NIL link or unit issue (mismatch/unknown/normalisation-failed) present</li><li>structure disagreement: deterministic 1C vs LLM 2C — review compartment count</li><li>status held at route_to_review — not promoted</li><li>gap-filled Q61 (V) from Pacifici_2010's review values (primary lacked it)</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 1123200, Tolerance = 1e-9, Interval = 1));
end Mezlocillin_Jungbluth1989_reference;
