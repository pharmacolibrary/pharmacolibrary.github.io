model Mezlocillin_FrimodtMller1980_reference
  parameter Real Cl_ref = 1.6666666666666667e-05 "Cl [m3/s]";
  parameter Real Vd_ref = 0.022400000000000003 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.539582,
    adminMass = 0.006
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About mezlocillin</h4><p>Mezlocillin is an extended-spectrum penicillin antibiotic used to treat bacterial infections such as sepsis, urinary tract, skin, and respiratory infections, including Pseudomonas and other gram-negative infections. It is an approved antibacterial, though it is not authorised in the European Union and is now used only in a limited number of countries.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q3307752\">Wikidata Q3307752</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>mezlocillin</td></tr><tr><td>population:</td><td>patients with varying degrees of renal function</td></tr><tr><td>source_paper:</td><td>Frimodt-Möller_1980</td></tr><tr><td>measured_compound:</td><td>mezlocillin</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>mezlocillin 539.582 g/mol (drugbank)</td></tr></table><h4>Interpretation flags</h4><ul><li>unit_dimension_unknown: 'ml min(-1) 1.73 m(-2)' (CLu)</li><li>dropped duplicate Q57 ('mean serum half-life', value 1.5) — already have one for this compound</li><li>implicit units: 'creatinine clearances' → L/h (from the popPK convention: 'Creatinine clearance (CLcr) is a standard surrogate marker for glomerular filtration rate used as a covariate in populat')</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=mezlocillin</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Mezlocillin_FrimodtMller1980_reference;
