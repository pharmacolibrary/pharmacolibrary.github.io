model Fenofibrate_Zhang2024_reference
  parameter Real Cl_ref = 8.972222222222223e-07 "Cl [m3/s]";
  parameter Real Vd_ref = 0.157 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.360831,
    adminMass = 0.0002,
    ka = 0.00029444444444444445,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About fenofibrate</h4><p>Fenofibrate is a fibrate-class lipid-lowering drug used to reduce cholesterol and treat dyslipidemias such as hypertriglyceridemia and familial hyperlipidemia. It is an approved medicine, widely used, and also available in combination products with other lipid-modifying agents.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q419724\">Wikidata Q419724</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>fenofibrate</td></tr><tr><td>population:</td><td>review reference</td></tr><tr><td>source_paper:</td><td>Zhang_2024</td></tr><tr><td>measured_compound:</td><td>fenofibrate</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>fenofibrate 360.831 g/mol (drugbank)</td></tr></table><p><b>Defaulted (base-class default used):</b> Tlag.</p><h4>Interpretation flags</h4><ul><li>built from REVIEW reference values (Zhang_2024) — secondary source</li><li>volume reported by review</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 691200, Tolerance = 1e-9, Interval = 1));
end Fenofibrate_Zhang2024_reference;
