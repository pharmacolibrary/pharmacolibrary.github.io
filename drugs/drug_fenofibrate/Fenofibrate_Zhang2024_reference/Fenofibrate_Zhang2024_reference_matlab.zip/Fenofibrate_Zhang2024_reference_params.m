function p = Fenofibrate_Zhang2024_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: fenofibrate   source: Zhang_2024 / reference   route: oral
  p.name  = 'Fenofibrate_Zhang2024_reference_params';
  p.drug  = 'fenofibrate';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 157.0;                % central volume [L]
  p.CL = 3.23;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 1.06;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 200.0;             % dose [mg]
end
