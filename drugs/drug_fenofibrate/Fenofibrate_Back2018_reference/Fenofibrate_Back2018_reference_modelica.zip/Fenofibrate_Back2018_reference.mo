model Fenofibrate_Back2018_reference
  parameter Real Cl_ref = 9.263333333333334e-07 "Cl [m3/s]";
  parameter Real Vd_ref = 0.01191 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.318753,
    adminMass = 0.00025,
    ka = 1.1666666666666668e-05,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About fenofibrate</h4><p>Fenofibrate is a fibrate-class lipid-lowering drug used to reduce cholesterol and treat dyslipidemias such as hypertriglyceridemia and familial hyperlipidemia. It is an approved medicine, widely used, and also available in combination products with other lipid-modifying agents.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q419724\">Wikidata Q419724</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>fenofibrate</td></tr><tr><td>population:</td><td>healthy adults</td></tr><tr><td>source_paper:</td><td>Back_2018</td></tr><tr><td>measured_compound:</td><td>fenofibric acid</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>Tab3</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>fenofibrate 360.831 g/mol (drugbank); fenofibric acid 318.753 g/mol (pubchem)</td></tr></table><p><b>Defaulted (base-class default used):</b> Tlag.</p><h4>Interpretation flags</h4><ul><li>table section residual_error: 'Proportional error (% RSE)' routed out of structural estimates ('Residual variability')</li><li>dropped unlinked row (NIL): 'Vstomach (L)' — extend the ontology if this is a real PK parameter (source ['Tab3:row5:col1', 'Tab3:row5:col4'])</li><li>dropped duplicate Q47 ('kg’ (hr−1)', value '0.011') — already have one for this compound</li><li>dropped PD-category row 'kout (hr−1)' → Q328 (kout, category G11) — pharmacodynamic parameters belong to scholarpd, not the PK model (source ['Tab3:row8:col4'])</li><li>dropped unlinked row (NIL): 'E bile' — extend the ontology if this is a real PK parameter (source ['Tab3:row9:col4'])</li><li>dropped unlinked row (NIL): 'MTIME2 (hr)' — extend the ontology if this is a real PK parameter (source ['Tab3:row11:col4'])</li><li>dropped unlinked row (NIL): 'E food' — extend the ontology if this is a real PK parameter (source ['Tab3:row12:col4'])</li><li>apparent-ness (ontology-grounded): parameterization=apparent, measured_compound=fenofibric acid</li><li>template fit: none — only the metabolite is modelled — no parent compartment</li><li>1C volume normalization: Q290→Q76 (single-compartment model has no central/peripheral split; 'Vc/F (L)' is the general volume)</li><li>row roles (LLM): model_class=compartmental; 11/11 row label(s) assigned, 4 linked by role; re-tagged fenofibric acid→parent ×2</li><li>review gap-fill skipped: this record measures 'fenofibric acid', not fenofibrate — the review values are the parent's</li><li>derived CL/F=3.3348 L/h from Ke × V/F = CL/F (Q47 × Q76); not separately reported</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Fenofibrate_Back2018_reference;
