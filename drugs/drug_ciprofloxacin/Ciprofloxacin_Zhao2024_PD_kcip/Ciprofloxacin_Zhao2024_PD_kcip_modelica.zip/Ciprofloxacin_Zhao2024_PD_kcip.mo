model Ciprofloxacin_Zhao2024_PD_kcip
  "sigmoid_emax exposure-response sweep — Zhao_2024 :: kCIP (Bacterial killing rate constant)"
  extends Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep(
    E0 = 0,      // [1]
    Emax = -0.001875,  // [1/s; /h × 0.000277778]
    EC50 = 0.00153,  // [kg/m3; mg/L × 0.001]
    gamma = 1.6,
    exposure_per_s = 0.001);   // 1 mg/L per second
  // imax_as_negative_emax: Imax (Q323) enters SigmoidEmaxSweep as −Emax
  // defaulted: E0
  annotation(experiment(StartTime = 0, StopTime = 16, Interval = 0.032),
    Documentation(info = "<html><body><!-- drug-about --><h4>About ciprofloxacin</h4><p>Ciprofloxacin is a fluoroquinolone antibiotic used to treat many bacterial infections, including urinary tract infections, pneumonia, typhoid fever, gonorrhea, and bone and joint infections. It is widely used worldwide and appears on the WHO list of essential medicines, available as tablets and also as eye and ear preparations.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q256602\">Wikidata Q256602</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h4>Ciprofloxacin_Zhao2024_PD_kcip</h4><p>The steady-state exposure-response curve of Zhao C et al., <i>Scientific reports 14(1):11706</i> 2024 (<a href=\"https://doi.org/10.1038/s41598-024-61518-0\">doi:10.1038/s41598-024-61518-0</a>) — Bacterial killing rate constant [/h] against ciprofloxacin mg/L — obtained by sweeping the driver instead of simulating a dose. Model family: sigmoid_emax.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = (library default) drug-free response (baseline)
  Emax  =       6.75 /h       maximal effect term (EmaxCIP, Q323)
  EC50  =       1.53 mg/L     exposure at half of the maximal effect term (EC50CIP,3,4, Q321)
  gamma =        1.6          Hill coefficient (γCIP, Q325)</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep\">SigmoidEmaxSweep</a>; this model only supplies the numbers. The x axis is one mg/L of ciprofloxacin per second of simulated time (exposure is in kg/m3): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0   (drug-free)
  exposure = EC50 (1.53 mg/L)  response -0.0009375
  exposure -> infinity  response -0.001875</pre></body></html>"));
end Ciprofloxacin_Zhao2024_PD_kcip;
