function p = Ciprofloxacin_Campion2005_PD_r_mrsa_8043_params()
% Ciprofloxacin_Campion2005_PD_r_mrsa_8043_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% ciprofloxacin Campion_2005::R_MRSA_8043: emax exposure-response sweep (response = E0 + Emax*frac). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one g/ml per second, in SI inside (kg/m3, s). Response R (MRSA 8043) in CFU/ml. Driver: ciprofloxacin (cited_pk).
p.E0 = 1.06;
p.Emax = -0.000325;
p.EC50 = 5190.0;
p.gamma = 1.0;
p.slope = 0.0;
p.exposure_per_s = 1000.0;
p.stop_time = 52.0;
p.form = 'E0 + Emax*frac';
end
