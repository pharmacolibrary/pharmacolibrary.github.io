model Ciprofloxacin_Zhao2024_PD_ksnc
  "sigmoid_emax exposure-response sweep — Zhao_2024 :: kSNc (Transfer of bacteria from susceptible (S) state to transiently non-colony forming (Nc) state under ciprofloxacin exposure)"
  extends Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep(
    E0 = 0,      // [1]
    Emax = 0.00130277777778,  // [1/s; /h × 0.000277778]
    EC50 = 0.000183,  // [kg/m3; mg/L × 0.001]
    gamma = 20,
    exposure_per_s = 0.001);   // 1 mg/L per second
  // defaulted: E0
  annotation(experiment(StartTime = 0, StopTime = 1.9, Interval = 0.0038),
    Documentation(info = "<html><body><h4>Ciprofloxacin_Zhao2024_PD_ksnc</h4><p>The steady-state exposure-response curve of Zhao C et al., <i>Scientific reports 14(1):11706</i> 2024 (<a href=\"https://doi.org/10.1038/s41598-024-61518-0\">doi:10.1038/s41598-024-61518-0</a>) — Transfer of bacteria from susceptible (S) state to transiently non-colony forming (Nc) state under ciprofloxacin exposure against ciprofloxacin mg/L — obtained by sweeping the driver instead of simulating a dose. Model family: sigmoid_emax.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = (library default) drug-free response (baseline)
  Emax  =       4.69 /h       maximal effect term (kSNc,max, Q320)
  EC50  =      0.183 mg/L     exposure at half of the maximal effect term (tr50, Q321)
  gamma =         20          Hill coefficient (γSNc, Q325)</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep\">SigmoidEmaxSweep</a>; this model only supplies the numbers. The x axis is one mg/L of ciprofloxacin per second of simulated time (exposure is in kg/m3): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0   (drug-free)
  exposure = EC50 (0.183 mg/L)  response 0.0006514
  exposure -> infinity  response 0.001303</pre></body></html>"));
end Ciprofloxacin_Zhao2024_PD_ksnc;
