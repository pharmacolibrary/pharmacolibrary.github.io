function p = Ciprofloxacin_Zhao2024_PD_ksnc_params()
% Ciprofloxacin_Zhao2024_PD_ksnc_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% ciprofloxacin Zhao_2024::kSNc: sigmoid_emax exposure-response sweep (response = E0 + Emax*frac). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one mg/L per second, in SI inside (kg/m3, s). Response kSNc in its own unit. Driver: ciprofloxacin (cited_pk).
p.E0 = 0.0;
p.Emax = 0.001302777777777778;
p.EC50 = 0.00018299999999999995;
p.gamma = 20.0;
p.slope = 0.0;
p.exposure_per_s = 0.001;
p.stop_time = 1.9;
p.form = 'E0 + Emax*frac';
end
