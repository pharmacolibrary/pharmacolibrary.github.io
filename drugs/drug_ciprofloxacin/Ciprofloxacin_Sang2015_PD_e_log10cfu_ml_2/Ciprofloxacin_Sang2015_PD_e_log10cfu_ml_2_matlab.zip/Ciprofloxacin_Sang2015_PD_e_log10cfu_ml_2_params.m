function p = Ciprofloxacin_Sang2015_PD_e_log10cfu_ml_2_params()
% Ciprofloxacin_Sang2015_PD_e_log10cfu_ml_2_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% ciprofloxacin Sang_2015::E_log10CFU_mL::2: sigmoid_emax exposure-response sweep (response = E0 + Emax*frac). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one h per second, in SI inside (kg/m3, s). Response E (log10CFU/mL) in Log10CFU/mL. Driver: enrofloxacin + ciprofloxacin (sum of concentrations) (conc_no_pk).
p.E0 = -5.69;
p.Emax = -2.91;
p.EC50 = 2888136.0;
p.gamma = 2.72;
p.slope = 0.0;
p.exposure_per_s = 3600.0;
p.stop_time = 8100.0;
p.form = 'E0 + Emax*frac';
end
