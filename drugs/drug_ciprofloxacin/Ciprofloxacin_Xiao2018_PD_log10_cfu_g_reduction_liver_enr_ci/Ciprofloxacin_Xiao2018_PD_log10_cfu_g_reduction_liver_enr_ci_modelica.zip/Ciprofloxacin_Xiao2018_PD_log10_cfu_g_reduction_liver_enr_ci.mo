model Ciprofloxacin_Xiao2018_PD_log10_cfu_g_reduction_liver_enr_ci
  "sigmoid_emax exposure-response sweep — Xiao_2018 :: log10 cfu/g reduction (liver, ENR+CIP) (Bacterial loading reduction in liver (E. coli O78), combined enrofloxacin + ciprofloxacin exposure)"
  extends Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep(
    E0 = 1.68,      // [Log 10 cfu/mL]
    Emax = -4.7,  // [Log 10 cfu/mL]
    EC50 = 17.66,  // [h (AUC0–24/MIC ratio)]
    gamma = 2.67,
    exposure_per_s = 1);   // 1 h (AUC0–24/MIC ratio) per second
  // exposure_unit_unresolved: 'h (AUC0–24/MIC ratio)' — the x axis is in the paper's unit, not SI
  annotation(experiment(StartTime = 0, StopTime = 180, Interval = 0.36),
    Documentation(info = "<html><body><h4>Ciprofloxacin_Xiao2018_PD_log10_cfu_g_reduction_liver_enr_ci</h4><p>The steady-state exposure-response curve of Xiao X et al., <i>BMC veterinary research 14(1):374</i> 2018 (<a href=\"https://doi.org/10.1186/s12917-018-1698-3\">doi:10.1186/s12917-018-1698-3</a>) — Bacterial loading reduction in liver (E. coli O78), combined enrofloxacin + ciprofloxacin exposure [Log10 cfu/g] against enrofloxacin + ciprofloxacin (combined AUC0–24/MIC) h (AUC0–24/MIC ratio) — obtained by sweeping the driver instead of simulating a dose. Model family: sigmoid_emax.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    =       1.68 Log 10 cfu/mL drug-free response (baseline) (E0, Q324)
  Emax  =       -4.7 Log 10 cfu/mL maximal effect term (Emax, Q320)
  EC50  =      17.66 h (AUC0–24/MIC ratio) exposure at half of the maximal effect term (EC50, Q321)
  gamma =       2.67          Hill coefficient (Slope (N), Q325)</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep\">SigmoidEmaxSweep</a>; this model only supplies the numbers. The x axis is one h (AUC0–24/MIC ratio) of enrofloxacin + ciprofloxacin (combined AUC0–24/MIC) per second of simulated time: there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 1.68   (drug-free)
  exposure = EC50 (17.66 h (AUC0–24/MIC ratio))  response -0.67
  exposure -> infinity  response -3.02</pre></body></html>"));
end Ciprofloxacin_Xiao2018_PD_log10_cfu_g_reduction_liver_enr_ci;
