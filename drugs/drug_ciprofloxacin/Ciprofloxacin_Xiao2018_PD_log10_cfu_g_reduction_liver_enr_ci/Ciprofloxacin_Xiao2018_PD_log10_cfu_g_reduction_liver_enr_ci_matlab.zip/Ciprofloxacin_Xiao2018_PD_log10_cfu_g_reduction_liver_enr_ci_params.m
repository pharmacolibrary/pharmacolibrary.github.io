function p = Ciprofloxacin_Xiao2018_PD_log10_cfu_g_reduction_liver_enr_ci_params()
% Ciprofloxacin_Xiao2018_PD_log10_cfu_g_reduction_liver_enr_ci_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% ciprofloxacin Xiao_2018::log10_cfu_g_reduction_liver_ENR_CIP: sigmoid_emax exposure-response sweep (response = E0 + Emax*frac). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one h (AUC0–24/MIC ratio) per second, in SI inside (kg/m3, s). Response log10 cfu/g reduction (liver, ENR+CIP) in Log10 cfu/g. Driver: enrofloxacin + ciprofloxacin (combined AUC0–24/MIC) (not_resolved).
p.E0 = 1.68;
p.Emax = -4.7;
p.EC50 = 17.66;
p.gamma = 2.67;
p.slope = 0.0;
p.exposure_per_s = 1.0;
p.stop_time = 180.0;
p.form = 'E0 + Emax*frac';
end
