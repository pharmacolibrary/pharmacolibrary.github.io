model Ciprofloxacin_Garg2024_reference
  parameter Real Cl_ref = 5.188888888888888e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.011130000000000001 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 0.9,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.3313415,
    adminMass = 0.001,
    ka = 0.0005277777777777777,
    Tlag = 2844.0
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About ciprofloxacin</h4><p>Ciprofloxacin is a fluoroquinolone antibiotic used to treat many bacterial infections, including urinary tract infections, pneumonia, typhoid fever, gonorrhea, and bone and joint infections. It is widely used worldwide and appears on the WHO list of essential medicines, available as tablets and also as eye and ear preparations.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q256602\">Wikidata Q256602</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>ciprofloxacin</td></tr><tr><td>population:</td><td>neonates with early onset sepsis</td></tr><tr><td>source_paper:</td><td>Garg_2024</td></tr><tr><td>measured_compound:</td><td>ciprofloxacin</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>tab_2</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>ciprofloxacin 331.341 g/mol (drugbank)</td></tr></table><p><b>Defaulted (base-class default used):</b> F.</p><h4>Interpretation flags</h4><ul><li>dropped unlinked row (NIL): 'Inter-individual' — extend the ontology if this is a real PK parameter (source ['tab_2:row6:col1', 'tab_2:row6:col2', 'tab_2:row6:col3', 'tab_2:row8:col1', 'tab_2:row8:col2', 'tab_2:row8:col3'])</li><li>implicit units: 'Vc = tvvc*' → L (from the popPK convention: 'Volume of distribution is conventionally expressed in liters (L) for population PK, and the magnitude (11.13) is consist')</li><li>implicit units: 'CL = tvcl' → L/h (from the popPK convention: 'Clearance is conventionally expressed in liters per hour (L/h) for population PK, and the magnitude (18.68) is consisten')</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=ciprofloxacin</li><li>bound model equation to Q63 (V1): Vc = tvvc*(wt/1.96)^1.135</li><li>Q63 (V1) is equation-defined: value moved to equation-variable 'Vc'; equation kept verbatim</li><li>1C volume Q63 kept: Q61 already present — review duplicate volume</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li><li>gap-filled Q49 (kabs) from Cattrall_2019's review values (primary lacked it)</li><li>gap-filled Q83 (tlag) from Gasser_1987's review values (primary lacked it)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Ciprofloxacin_Garg2024_reference;
