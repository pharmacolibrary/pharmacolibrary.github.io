function p = Ciprofloxacin_Sang2015_PD_bacterial_count_params()
% Ciprofloxacin_Sang2015_PD_bacterial_count_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% ciprofloxacin Sang_2015::bacterial_count: sigmoid_emax exposure-response sweep (response = E0 + Emax*frac). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one μg/mL per second, in SI inside (kg/m3, s). Response bacterial count in log10CFU/mL. Driver: enrofloxacin and ciprofloxacin (conc_no_pk).
p.E0 = -5.62;
p.Emax = -2.35;
p.EC50 = 0.34850999999999993;
p.gamma = 1.0;
p.slope = 0.0;
p.exposure_per_s = 0.0009999999999999998;
p.stop_time = 3485.1;
p.form = 'E0 + Emax*frac';
end
