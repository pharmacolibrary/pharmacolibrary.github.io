function p = Ciprofloxacin_Zhu2026_PD_bis_params()
% Ciprofloxacin_Zhu2026_PD_bis_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% ciprofloxacin Zhu_2026::BIS: sigmoid_emax exposure-response sweep (response = E0 + Emax*frac). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one ng·ml-1 per second, in SI inside (kg/m3, s). Response BIS in its own unit. Driver: ciprofol (not_resolved).
p.E0 = 93.4;
p.Emax = -45.77;
p.EC50 = 0.00023391;
p.gamma = 3.0;
p.slope = 0.0;
p.exposure_per_s = 1e-06;
p.stop_time = 2400.0;
p.form = 'E0 + Emax*frac';
end
