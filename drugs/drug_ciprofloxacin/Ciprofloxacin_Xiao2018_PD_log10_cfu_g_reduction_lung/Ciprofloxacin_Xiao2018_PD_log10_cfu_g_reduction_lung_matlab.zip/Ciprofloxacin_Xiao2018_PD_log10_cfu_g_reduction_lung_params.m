function p = Ciprofloxacin_Xiao2018_PD_log10_cfu_g_reduction_lung_params()
% Ciprofloxacin_Xiao2018_PD_log10_cfu_g_reduction_lung_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% ciprofloxacin Xiao_2018::log10_cfu_g_reduction_lung: sigmoid_emax exposure-response sweep (response = E0 + Emax*frac). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one h (AUC0–24/MIC ratio) per second, in SI inside (kg/m3, s). Response log10 cfu/g reduction (lung) in Log10 cfu/g. Driver: enrofloxacin (not_resolved).
p.E0 = 2.29;
p.Emax = -4.4;
p.EC50 = 10.33;
p.gamma = 3.01;
p.slope = 0.0;
p.exposure_per_s = 1.0;
p.stop_time = 110.0;
p.form = 'E0 + Emax*frac';
end
