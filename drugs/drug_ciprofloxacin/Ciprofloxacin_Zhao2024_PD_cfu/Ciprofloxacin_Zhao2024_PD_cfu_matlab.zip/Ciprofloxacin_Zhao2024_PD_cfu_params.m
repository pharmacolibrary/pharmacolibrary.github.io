function p = Ciprofloxacin_Zhao2024_PD_cfu_params()
% Ciprofloxacin_Zhao2024_PD_cfu_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% ciprofloxacin Zhao_2024::CFU: sigmoid_emax exposure-response sweep (response = E0 + Emax*frac). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one mg/L per second, in SI inside (kg/m3, s). Response CFU in log10 CFU/mL. Driver: ciprofloxacin (cited_pk).
p.E0 = 0.0;
p.Emax = 0.001875;
p.EC50 = 0.0015299999999999997;
p.gamma = 1.6;
p.slope = 0.0;
p.exposure_per_s = 0.001;
p.stop_time = 16.0;
p.form = 'E0 + Emax*frac';
end
