% run_Ciprofloxacin_Xiao2018_PD_log10_cfu_ml_reduction_blood  Evaluate the exposure-response curve and plot response against exposure.
% A sweep is a static map: no ODE solver is needed. exposure runs 0..stop_time*exposure_per_s.
p = Ciprofloxacin_Xiao2018_PD_log10_cfu_ml_reduction_blood_params();
exposure = linspace(0, p.stop_time * p.exposure_per_s, 501);
frac = exposure.^p.gamma ./ (p.EC50^p.gamma + exposure.^p.gamma);
E0 = p.E0; Emax = p.Emax; slope = p.slope;
response = E0 + Emax.*frac;
figure; plot(exposure, response, 'LineWidth', 1.5); grid on;
xlabel('exposure [h (AUC0–24/MIC ratio)]'); ylabel('response [Log10 cfu/mL]'); title('Ciprofloxacin_Xiao2018_PD_log10_cfu_ml_reduction_blood', 'Interpreter', 'none');
writematrix([exposure(:) response(:)], 'Ciprofloxacin_Xiao2018_PD_log10_cfu_ml_reduction_blood.csv');
