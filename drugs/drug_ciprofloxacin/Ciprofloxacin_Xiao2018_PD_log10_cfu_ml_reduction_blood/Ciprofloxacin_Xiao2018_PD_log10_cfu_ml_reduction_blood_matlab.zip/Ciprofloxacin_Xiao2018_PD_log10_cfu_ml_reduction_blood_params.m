function p = Ciprofloxacin_Xiao2018_PD_log10_cfu_ml_reduction_blood_params()
% Ciprofloxacin_Xiao2018_PD_log10_cfu_ml_reduction_blood_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% ciprofloxacin Xiao_2018::log10_cfu_mL_reduction_blood: sigmoid_emax exposure-response sweep (response = E0 + Emax*frac). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one h (AUC0–24/MIC ratio) per second, in SI inside (kg/m3, s). Response log10 cfu/mL reduction (blood) in Log10 cfu/mL. Driver: enrofloxacin (not_resolved).
p.E0 = 1.78;
p.Emax = -5.8;
p.EC50 = 16.61;
p.gamma = 2.58;
p.slope = 0.0;
p.exposure_per_s = 1.0;
p.stop_time = 170.0;
p.form = 'E0 + Emax*frac';
end
