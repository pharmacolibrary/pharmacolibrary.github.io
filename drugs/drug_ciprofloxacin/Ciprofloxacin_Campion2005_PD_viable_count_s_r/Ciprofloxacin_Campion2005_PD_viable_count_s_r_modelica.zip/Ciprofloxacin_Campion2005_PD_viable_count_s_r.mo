model Ciprofloxacin_Campion2005_PD_viable_count_s_r
  "emax exposure-response sweep — Campion_2005 :: viable count (S, R) (viable count of ciprofloxacin-susceptible (S) and -resistant (R) subpopulations)"
  extends Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep(
    E0 = 1.06,      // [CFU/ml]
    Emax = -0.000433333333333,  // [1/s; h−1 × 0.000277778]
    EC50 = 0.00021,  // [kg/m3; µg/ml × 0.001]
    gamma = 1,
    exposure_per_s = 0.001);   // 1 µg/ml per second
  // inhibition_sign: effect_direction=inhibition with a positive Emax (Q320) — sign flipped
  // defaulted: gamma
  annotation(experiment(StartTime = 0, StopTime = 2.1, Interval = 0.0042),
    Documentation(info = "<html><body><h4>Ciprofloxacin_Campion2005_PD_viable_count_s_r</h4><p>The steady-state exposure-response curve of Campion JJ et al., <i>Antimicrobial agents and chemotherapy 49(1):209–219</i> 2005 (<a href=\"https://doi.org/10.1128/AAC.49.1.209-219.2005\">doi:10.1128/AAC.49.1.209-219.2005</a>) — viable count of ciprofloxacin-susceptible (S) and -resistant (R) subpopulations [CFU/ml] against ciprofloxacin µg/ml — obtained by sweeping the driver instead of simulating a dose. Model family: emax.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    =       1.06 CFU/ml   drug-free response (baseline) (size of resistant subpopulation at time zero, Q336)
  Emax  =       1.56 h−1      maximal effect term (maximal killing rate constant susceptible subpopulation, Q320)
  EC50  =       0.21 µg/ml    exposure at half of the maximal effect term (ciprofloxacin concentration at which 50% of maximal killing occurs, susceptible subpopulation, Q321)
  gamma = (library default) Hill coefficient</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep\">SigmoidEmaxSweep</a>; this model only supplies the numbers. The x axis is one µg/ml of ciprofloxacin per second of simulated time (exposure is in kg/m3): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 1.06   (drug-free)
  exposure = EC50 (0.21 µg/ml)  response 1.06
  exposure -> infinity  response 1.06</pre></body></html>"));
end Ciprofloxacin_Campion2005_PD_viable_count_s_r;
