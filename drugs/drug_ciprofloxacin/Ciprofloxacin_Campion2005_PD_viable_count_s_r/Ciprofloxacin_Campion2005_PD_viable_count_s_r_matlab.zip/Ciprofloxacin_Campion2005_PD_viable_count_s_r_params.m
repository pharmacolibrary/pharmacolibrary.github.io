function p = Ciprofloxacin_Campion2005_PD_viable_count_s_r_params()
% Ciprofloxacin_Campion2005_PD_viable_count_s_r_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% ciprofloxacin Campion_2005::viable_count_S_R: emax exposure-response sweep (response = E0 + Emax*frac). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one µg/ml per second, in SI inside (kg/m3, s). Response viable count (S, R) in CFU/ml. Driver: ciprofloxacin (cited_pk).
p.E0 = 1.06;
p.Emax = -0.00043333333333333337;
p.EC50 = 0.00020999999999999995;
p.gamma = 1.0;
p.slope = 0.0;
p.exposure_per_s = 0.001;
p.stop_time = 2.1;
p.form = 'E0 + Emax*frac';
end
