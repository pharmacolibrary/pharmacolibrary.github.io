model Ciprofloxacin_Campion2005_PD_s_mrsa_8043
  "emax exposure-response sweep — Campion_2005 :: S (MRSA 8043) (viable count of MRSA 8043 susceptible subpopulation)"
  extends Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep(
    E0 = 0,      // [1]
    Emax = -0.000433333333333,  // [1/s; h^-1 × 0.000277778]
    EC50 = 210,  // [kg/m3; g/ml × 1000]
    gamma = 1,
    exposure_per_s = 1000);   // 1 g/ml per second
  // imax_as_negative_emax: Imax (Q323) enters SigmoidEmaxSweep as −Emax
  // defaulted: E0
  // defaulted: gamma
  annotation(experiment(StartTime = 0, StopTime = 2.1, Interval = 0.0042),
    Documentation(info = "<html><body><!-- drug-about --><h4>About ciprofloxacin</h4><p>Ciprofloxacin is a fluoroquinolone antibiotic used to treat many bacterial infections, including urinary tract infections, pneumonia, typhoid fever, gonorrhea, and bone and joint infections. It is widely used worldwide and appears on the WHO list of essential medicines, available as tablets and also as eye and ear preparations.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q256602\">Wikidata Q256602</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h4>Ciprofloxacin_Campion2005_PD_s_mrsa_8043</h4><p>The steady-state exposure-response curve of Campion JJ et al., <i>Antimicrobial agents and chemotherapy 49(1):209–219</i> 2005 (<a href=\"https://doi.org/10.1128/AAC.49.1.209-219.2005\">doi:10.1128/AAC.49.1.209-219.2005</a>) — viable count of MRSA 8043 susceptible subpopulation [CFU/ml] against ciprofloxacin g/ml — obtained by sweeping the driver instead of simulating a dose. Model family: emax.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = (library default) drug-free response (baseline)
  Emax  =       1.56 h^-1     maximal effect term (k S, Q323)
  EC50  =       0.21 g/ml     exposure at half of the maximal effect term (EC 50S, Q321)
  gamma = (library default) Hill coefficient</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep\">SigmoidEmaxSweep</a>; this model only supplies the numbers. The x axis is one g/ml of ciprofloxacin per second of simulated time (exposure is in kg/m3): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0   (drug-free)
  exposure = EC50 (0.21 g/ml)  response -0.0002167
  exposure -> infinity  response -0.0004333</pre></body></html>"));
end Ciprofloxacin_Campion2005_PD_s_mrsa_8043;
