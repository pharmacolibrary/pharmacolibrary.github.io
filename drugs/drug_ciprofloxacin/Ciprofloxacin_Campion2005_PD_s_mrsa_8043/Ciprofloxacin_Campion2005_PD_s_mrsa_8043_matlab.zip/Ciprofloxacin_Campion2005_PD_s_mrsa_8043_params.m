function p = Ciprofloxacin_Campion2005_PD_s_mrsa_8043_params()
% Ciprofloxacin_Campion2005_PD_s_mrsa_8043_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% ciprofloxacin Campion_2005::S_MRSA_8043: emax exposure-response sweep (response = E0 + Emax*frac). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one g/ml per second, in SI inside (kg/m3, s). Response S (MRSA 8043) in CFU/ml. Driver: ciprofloxacin (cited_pk).
p.E0 = 0.0;
p.Emax = -0.00043333333333333337;
p.EC50 = 209.99999999999997;
p.gamma = 1.0;
p.slope = 0.0;
p.exposure_per_s = 1000.0;
p.stop_time = 2.1;
p.form = 'E0 + Emax*frac';
end
