model Ciprofloxacin_Haefliger2025_reference
  parameter Real Cl_ref = 3.833333333333334e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.0217 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.3313415,
    adminMass = 0.0008
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About ciprofloxacin</h4><p>Ciprofloxacin is a fluoroquinolone antibiotic used to treat many bacterial infections, including urinary tract infections, pneumonia, typhoid fever, gonorrhea, and bone and joint infections. It is widely used worldwide and appears on the WHO list of essential medicines, available as tablets and also as eye and ear preparations.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q256602\">Wikidata Q256602</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>ciprofloxacin</td></tr><tr><td>population:</td><td>review reference</td></tr><tr><td>source_paper:</td><td>Haefliger_2025</td></tr><tr><td>measured_compound:</td><td>ciprofloxacin</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>ciprofloxacin 331.341 g/mol (drugbank)</td></tr></table><h4>Interpretation flags</h4><ul><li>built from REVIEW reference values (Haefliger_2025) — secondary source</li><li>volume reported by review</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Ciprofloxacin_Haefliger2025_reference;
