model Ciprofloxacin_Sang2015_PD_e_log10cfu_ml
  "sigmoid_emax exposure-response sweep — Sang_2015 :: E (log10CFU/mL) (Change in bacterial count of E. coli Anhui112 after 24 h ex vivo incubation in intestinal contents (healthy broilers))"
  extends Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep(
    E0 = -5.62,      // [Log10CFU/mL]
    Emax = -2.35,  // [Log10CFU/mL]
    EC50 = 1254636,  // [s; h × 3600]
    gamma = 2.85,
    exposure_per_s = 3600);   // 1 h per second
  // inhibition_sign: effect_direction=inhibition with a positive Emax (Q320) — sign flipped
  annotation(experiment(StartTime = 0, StopTime = 3500, Interval = 7),
    Documentation(info = "<html><body><h4>Ciprofloxacin_Sang2015_PD_e_log10cfu_ml</h4><p>The steady-state exposure-response curve of Sang K et al., <i>Frontiers in veterinary science 2:80</i> 2015 (<a href=\"https://doi.org/10.3389/fvets.2015.00080\">doi:10.3389/fvets.2015.00080</a>) — Change in bacterial count of E. coli Anhui112 after 24 h ex vivo incubation in intestinal contents (healthy broilers) [Log10CFU/mL] against enrofloxacin + ciprofloxacin (sum of concentrations) h — obtained by sweeping the driver instead of simulating a dose. Model family: sigmoid_emax.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    =      -5.62 Log10CFU/mL drug-free response (baseline) (E0, Q324)
  Emax  =       2.35 Log10CFU/mL maximal effect term (Emax, Q320)
  EC50  =     348.51 h        exposure at half of the maximal effect term (EC50, Q321)
  gamma =       2.85          Hill coefficient (Slope (N), Q325)</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep\">SigmoidEmaxSweep</a>; this model only supplies the numbers. The x axis is one h of enrofloxacin + ciprofloxacin (sum of concentrations) per second of simulated time (exposure is in s): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response -5.62   (drug-free)
  exposure = EC50 (348.51 h)  response -6.795
  exposure -> infinity  response -7.97</pre></body></html>"));
end Ciprofloxacin_Sang2015_PD_e_log10cfu_ml;
