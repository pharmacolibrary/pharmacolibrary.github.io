model Dolutegravir_Zhang2015_reference
  parameter Real Cl_ref = 5.861111111111111e-07 "Cl [m3/s]";
  parameter Real Vd_ref = 0.0024900000000000005 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.4193788,
    adminMass = 1e-05,
    ka = 0.004277777777777778,
    Tlag = 117720.00000000001
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About dolutegravir</h4><p>Dolutegravir is an integrase inhibitor used to treat HIV infection. It is an approved medicine, authorised in the European Union for HIV infections, and is included on the WHO list of essential medicines, so it is widely used.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q937224\">Wikidata Q937224</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>dolutegravir</td></tr><tr><td>population:</td><td>HIV-infected treatment-naive adults</td></tr><tr><td>source_paper:</td><td>Zhang_2015</td></tr><tr><td>measured_compound:</td><td>dolutegravir</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>tbl3</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>dolutegravir 419.379 g/mol (drugbank)</td></tr></table><h4>Interpretation flags</h4><ul><li>table section iiv: 'ω2CL' routed out of structural estimates ('Inter-individual or inter-occasion variability')</li><li>table section iiv: 'ω2CL' routed out of structural estimates ('Inter-individual or inter-occasion variability')</li><li>table section iiv: 'ω2CL' routed out of structural estimates ('Inter-individual or inter-occasion variability')</li><li>table section iiv: 'ω2CL' routed out of structural estimates ('Inter-individual or inter-occasion variability')</li><li>table section iiv: 'ω2V' routed out of structural estimates ('Inter-individual or inter-occasion variability')</li><li>table section iiv: 'ω2V' routed out of structural estimates ('Inter-individual or inter-occasion variability')</li><li>table section iiv: 'ω2V' routed out of structural estimates ('Inter-individual or inter-occasion variability')</li><li>table section iiv: 'ω2V' routed out of structural estimates ('Inter-individual or inter-occasion variability')</li><li>table section iiv: 'ω2ka' routed out of structural estimates ('Inter-individual or inter-occasion variability')</li><li>table section iiv: 'ω2ka' routed out of structural estimates ('Inter-individual or inter-occasion variability')</li><li>table section iiv: 'ω2ka' routed out of structural estimates ('Inter-individual or inter-occasion variability')</li><li>table section iiv: 'ω2ka' routed out of structural estimates ('Inter-individual or inter-occasion variability')</li><li>table section iiv: 'ω2IOV-CL' routed out of structural estimates ('Inter-individual or inter-occasion variability')</li><li>table section iiv: 'ω2IOV-CL' routed out of structural estimates ('Inter-individual or inter-occasion variability')</li><li>table section iiv: 'ω2IOV-CL' routed out of structural estimates ('Inter-individual or inter-occasion variability')</li><li>table section iiv: 'ω2IOV-CL' routed out of structural estimates ('Inter-individual or inter-occasion variability')</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Dolutegravir_Zhang2015_reference;
