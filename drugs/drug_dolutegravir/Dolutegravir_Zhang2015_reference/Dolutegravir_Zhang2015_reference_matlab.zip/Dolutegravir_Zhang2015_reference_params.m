function p = Dolutegravir_Zhang2015_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: dolutegravir   source: Zhang_2015 / reference   route: oral
  p.name  = 'Dolutegravir_Zhang2015_reference_params';
  p.drug  = 'dolutegravir';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 2.49;                % central volume [L]
  p.CL = 2.11;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 15.4;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 32.7;             % absorption lag [h]
  p.dose = 10.0;             % dose [mg]
end
