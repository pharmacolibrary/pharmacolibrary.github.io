function p = Daptomycin_Lou2021_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: daptomycin   source: Lou_2021 / reference   route: iv_bolus
  % estimated (absent from source): F
  p.name  = 'Daptomycin_Lou2021_reference_params';
  p.drug  = 'daptomycin';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'iv_bolus';        % 'oral' | 'iv_bolus'
  p.depot = false;             % oral -> first-order absorption depot
  p.Vc = 6.04;                % central volume [L]
  p.CL = 0.316;                % clearance [L/h]
  p.Vp = [2.46];             % peripheral volumes [L]
  p.Q  = [2.31];             % inter-compartmental clearances [L/h]
  p.ka = 0.0;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 280.0;             % dose [mg]
end
