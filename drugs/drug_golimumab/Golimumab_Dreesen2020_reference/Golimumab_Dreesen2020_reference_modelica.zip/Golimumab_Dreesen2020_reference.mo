model Golimumab_Dreesen2020_reference
  parameter Real Cl_ref = 5.115740740740741e-09 "Cl [m3/s]";
  parameter Real Vd_ref = 0.00864 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    adminMass = 5e-05,
    ka = 5.474537037037037e-06,
    Tlag = 0.0,
    k12 = 5.760245198902606e-07,
    k21 = 1.1109044312169312e-06
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About golimumab</h4><p>Golimumab is a monoclonal antibody that blocks tumour necrosis factor alpha and is used to treat inflammatory conditions such as rheumatoid and psoriatic arthritis, ankylosing spondylitis, and ulcerative colitis. It is an approved medicine, authorised in the European Union, and is widely used for these immune-mediated diseases.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q413879\">Wikidata Q413879</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>golimumab</td></tr><tr><td>population:</td><td>adults with ulcerative colitis</td></tr><tr><td>source_paper:</td><td>Dreesen_2020</td></tr><tr><td>measured_compound:</td><td>golimumab</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>tab_1</td></tr><tr><td>input:</td><td>PK_2C_enteral: absorption rate constant reported</td></tr></table><p><b>Defaulted (base-class default used):</b> Tlag.</p><h4>Interpretation flags</h4><ul><li>table section iiv: 'CL, %' routed out of structural estimates ('Interindividual variability')</li><li>table section iiv: 'V c /F, %' routed out of structural estimates ('Interindividual variability')</li><li>table section iiv: 'V p /F, %' routed out of structural estimates ('Interindividual variability')</li><li>table section iiv: 'Corr(CL/F-V c /F), %' routed out of structural estimates ('Interindividual variability')</li><li>table section iiv: 'Corr(CL/F-V c /F), %' routed out of structural estimates ('Interindividual variability')</li><li>table section iiv: 'Corr(CL/F-V c /F), %' routed out of structural estimates ('Interindividual variability')</li><li>table section iiv: 'Corr(CL/F-V p /F), %' routed out of structural estimates ('Interindividual variability')</li><li>table section iiv: 'Corr(CL/F-V p /F), %' routed out of structural estimates ('Interindividual variability')</li><li>table section iiv: 'Corr(CL/F-V p /F), %' routed out of structural estimates ('Interindividual variability')</li><li>table section iiv: 'Corr(V c /F-V p /F), %' routed out of structural estimates ('Interindividual variability')</li><li>table section iiv: 'Corr(V c /F-V p /F), %' routed out of structural estimates ('Interindividual variability')</li><li>table section iiv: 'Corr(V c /F-V p /F), %' routed out of structural estimates ('Interindividual variability')</li><li>dropped unlinked row (NIL): 'When no ATG' — extend the ontology if this is a real PK parameter (source ['tab_1:row8:col2', 'tab_1:row8:col4'])</li><li>dropped unlinked row (NIL): 'When ATG' — extend the ontology if this is a real PK parameter (source ['tab_1:row9:col2', 'tab_1:row9:col4'])</li><li>dropped unlinked row (NIL): 'When PREV' — extend the ontology if this is a real PK parameter (source ['tab_1:row14:col2', 'tab_1:row14:col4'])</li><li>dropped unlinked row (NIL): 'Dried blood spot-to-' — extend the ontology if this is a real PK parameter (source ['tab_1:row15:col1', 'tab_1:row15:col2', 'tab_1:row15:col4'])</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 6652800, Tolerance = 1e-9, Interval = 1));
end Golimumab_Dreesen2020_reference;
