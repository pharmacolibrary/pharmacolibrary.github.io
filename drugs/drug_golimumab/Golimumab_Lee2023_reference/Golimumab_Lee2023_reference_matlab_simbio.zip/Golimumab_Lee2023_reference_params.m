function p = Golimumab_Lee2023_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: golimumab   source: Lee_2023 / reference   route: oral
  % estimated (absent from source): dose
  p.name  = 'Golimumab_Lee2023_reference_params';
  p.drug  = 'golimumab';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 16.0;                % central volume [L]
  p.CL = 0.035417;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.042083;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 100.0;             % dose [mg]
end
