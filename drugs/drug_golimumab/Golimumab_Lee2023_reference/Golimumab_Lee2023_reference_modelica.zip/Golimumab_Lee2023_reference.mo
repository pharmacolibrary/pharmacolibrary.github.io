model Golimumab_Lee2023_reference
  parameter Real Cl_ref = 9.837962962962963e-09 "Cl [m3/s]";
  parameter Real Vd_ref = 0.016 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    adminMass = 0.0001,
    ka = 1.1689814814814814e-05,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About golimumab</h4><p>Golimumab is a monoclonal antibody that blocks tumour necrosis factor alpha and is used to treat inflammatory conditions such as rheumatoid and psoriatic arthritis, ankylosing spondylitis, and ulcerative colitis. It is an approved medicine, authorised in the European Union, and is widely used for these immune-mediated diseases.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q413879\">Wikidata Q413879</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>golimumab</td></tr><tr><td>population:</td><td>children and young adults with type 1 diabetes</td></tr><tr><td>source_paper:</td><td>Lee_2023</td></tr><tr><td>measured_compound:</td><td>golimumab</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr></table><p><b>Defaulted (base-class default used):</b> Tlag.</p><h4>Interpretation flags</h4><ul><li>apparent-ness (ontology-grounded): parameterization=apparent, measured_compound=golimumab</li><li>molar mass: none found for 'golimumab' — its concentrations stay mass-only</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of TLAG: primary's parameterization (rate-constant / ka-only) does not use it</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 6048000, Tolerance = 1e-9, Interval = 1));
end Golimumab_Lee2023_reference;
