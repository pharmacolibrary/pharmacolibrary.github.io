model Crizotinib_Gibson2021_reference
  parameter Real Cl_ref = 1.852777777777778e-05 "Cl [m3/s]";
  parameter Real Vd_ref = 0.0733 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.450337,
    adminMass = 0.0005,
    ka = 0.0001866666666666667,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About crizotinib</h4><p>Crizotinib is an ALK inhibitor anticancer drug used to treat non-small-cell lung carcinoma and other tumours such as inflammatory myofibroblastic tumour. It is authorised in the European Union and is an approved medicine, used mainly in oncology care.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q5186964\">Wikidata Q5186964</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>crizotinib</td></tr><tr><td>population:</td><td>children with progressive or recurrent high-grade and diffuse intrinsic pontine gliomas</td></tr><tr><td>source_paper:</td><td>Gibson_2021</td></tr><tr><td>measured_compound:</td><td>crizotinib</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>crizotinib 450.337 g/mol (drugbank)</td></tr></table><p><b>Defaulted (base-class default used):</b> Tlag.</p><h4>Interpretation flags</h4><ul><li>unit_dimension_unknown: 'L/h/m2' (CL/F)</li><li>unit_dimension_unknown: 'L/m2' (V1/F)</li><li>implicit units: 'CL/F' → L/h (from the popPK convention: 'Apparent oral clearance is commonly reported in L/h; 66.7 is consistent with that scale.')</li><li>implicit units: 'V1/F' → L (from the popPK convention: 'Apparent central-compartment volume is commonly reported in L; 73.3 is consistent with that scale.')</li><li>apparent-ness (ontology-grounded): parameterization=apparent, measured_compound=crizotinib</li><li>1C volume normalization: Q290→Q76 (single-compartment model has no central/peripheral split; 'V1/F' is the general volume)</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li><li>gap-filled Q49 (kabs) from Wanika_2024's review values (primary lacked it)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Crizotinib_Gibson2021_reference;
