model Crizotinib_Gupta2021_reference
  parameter Real Cl_ref = 2.9444444444444445e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.20700000000000002 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.450337,
    adminMass = 0.0005,
    ka = 0.0001388888888888889,
    Tlag = 0.0,
    k12 = 1.6908212560386472e-05,
    k21 = 3.0701754385964913e-05
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About crizotinib</h4><p>Crizotinib is an ALK inhibitor anticancer drug used to treat non-small-cell lung carcinoma and other tumours such as inflammatory myofibroblastic tumour. It is authorised in the European Union and is an approved medicine, used mainly in oncology care.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q5186964\">Wikidata Q5186964</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>crizotinib</td></tr><tr><td>population:</td><td>review reference</td></tr><tr><td>source_paper:</td><td>Gupta_2021</td></tr><tr><td>measured_compound:</td><td>crizotinib</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_2C_enteral: apparent (/F) parameterization ⇒ extravascular dosing</td></tr><tr><td>molar_masses:</td><td>crizotinib 450.337 g/mol (drugbank)</td></tr></table><p><b>Defaulted (base-class default used):</b> ka, Tlag.</p><h4>Interpretation flags</h4><ul><li>built from REVIEW reference values (Gupta_2021) — secondary source</li><li>volume reported by review</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 259200, Tolerance = 1e-9, Interval = 1));
end Crizotinib_Gupta2021_reference;
