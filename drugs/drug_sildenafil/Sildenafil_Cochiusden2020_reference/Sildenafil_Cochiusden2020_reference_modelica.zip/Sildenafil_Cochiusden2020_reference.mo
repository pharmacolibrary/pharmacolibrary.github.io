model Sildenafil_Cochiusden2020_reference
  parameter Real Cl_ref = 1.8611111111111113e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.0751 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.474576,
    adminMass = 1e-05,
    k12 = 0.00016385559994081965,
    k21 = 0.0012305555555555555
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About sildenafil</h4><p>Sildenafil is a medication used to treat erectile dysfunction and pulmonary arterial hypertension. It is widely used and authorised in the European Union, available in products for both erectile dysfunction and pulmonary hypertension.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q191521\">Wikidata Q191521</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>sildenafil</td></tr><tr><td>population:</td><td>review reference</td></tr><tr><td>source_paper:</td><td>Cochius-den_2020</td></tr><tr><td>measured_compound:</td><td>sildenafil</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_2C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>sildenafil 474.576 g/mol (drugbank)</td></tr></table><h4>Interpretation flags</h4><ul><li>built from REVIEW reference values (Cochius-den_2020) — secondary source</li><li>volume reported by review</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 140400, Tolerance = 1e-9, Interval = 1));
end Sildenafil_Cochiusden2020_reference;
