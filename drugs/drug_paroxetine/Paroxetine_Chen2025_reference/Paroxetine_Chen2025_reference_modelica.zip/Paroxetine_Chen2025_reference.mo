model Paroxetine_Chen2025_reference
  parameter Real Cl_ref = 3.916666666666667e-05 "Cl [m3/s]";
  parameter Real Vd_ref = 1.46 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.32936540000000003,
    adminMass = 2e-05,
    ka = 0.00040555555555555554,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About paroxetine</h4><p>Paroxetine is a selective serotonin reuptake inhibitor antidepressant used for conditions such as depression, anxiety disorders, panic disorder, obsessive-compulsive disorder, and post-traumatic stress disorder. It is an approved medicine in widespread clinical use, though it carries a boxed warning.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q408471\">Wikidata Q408471</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>paroxetine</td></tr><tr><td>population:</td><td>review reference</td></tr><tr><td>source_paper:</td><td>Chen_2025</td></tr><tr><td>measured_compound:</td><td>paroxetine</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>paroxetine 329.365 g/mol (drugbank)</td></tr></table><p><b>Defaulted (base-class default used):</b> Tlag.</p><h4>Interpretation flags</h4><ul><li>built from REVIEW reference values (Chen_2025) — secondary source</li><li>volume reported by review</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 136800, Tolerance = 1e-9, Interval = 1));
end Paroxetine_Chen2025_reference;
