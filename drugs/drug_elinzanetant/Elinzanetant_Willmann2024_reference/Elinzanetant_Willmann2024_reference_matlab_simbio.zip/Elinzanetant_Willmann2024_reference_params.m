function p = Elinzanetant_Willmann2024_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: elinzanetant   source: Willmann_2024 / reference   route: oral
  % estimated (absent from source): F
  p.name  = 'Elinzanetant_Willmann2024_reference_params';
  p.drug  = 'elinzanetant';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 23.7;                % central volume [L]
  p.CL = 7.26;                % clearance [L/h]
  p.Vp = [168.0];             % peripheral volumes [L]
  p.Q  = [6.57];             % inter-compartmental clearances [L/h]
  p.ka = 2.37;                % absorption rate [1/h]
  p.F  = 0.9;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 40.0;             % dose [mg]
end
