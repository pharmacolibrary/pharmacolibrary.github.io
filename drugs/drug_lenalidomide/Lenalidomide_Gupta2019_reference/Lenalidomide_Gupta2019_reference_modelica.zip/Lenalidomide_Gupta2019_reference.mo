model Lenalidomide_Gupta2019_reference
  parameter Real Cl_ref = 5.277777777777777e-07 "Cl [m3/s]";
  parameter Real Vd_ref = 0.624975491713099 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.2592606,
    adminMass = 1e-05
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About lenalidomide</h4><p>Lenalidomide is an immunomodulating and anti-angiogenic drug used to treat blood cancers and related disorders, including multiple myeloma, myelodysplastic syndromes, and several types of lymphoma and leukemia. It is approved and widely used, with several authorised products in the European Union, though it carries a boxed warning.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q425681\">Wikidata Q425681</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>lenalidomide</td></tr><tr><td>population:</td><td>review reference</td></tr><tr><td>source_paper:</td><td>Gupta_2019</td></tr><tr><td>measured_compound:</td><td>lenalidomide</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>lenalidomide 259.261 g/mol (drugbank)</td></tr></table><h4>Interpretation flags</h4><ul><li>built from REVIEW reference values (Gupta_2019) — secondary source</li><li>central volume derived from CL·t½/ln2</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 4233600, Tolerance = 1e-9, Interval = 1));
end Lenalidomide_Gupta2019_reference;
