model Lenalidomide_Hughes2019_reference
  parameter Real Cl_ref = 3.3333333333333333e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.0688 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.2592606,
    adminMass = 1e-05,
    ka = 0.00375,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About lenalidomide</h4><p>Lenalidomide is an immunomodulating and anti-angiogenic drug used to treat blood cancers and related disorders, including multiple myeloma, myelodysplastic syndromes, and several types of lymphoma and leukemia. It is approved and widely used, with several authorised products in the European Union, though it carries a boxed warning.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q425681\">Wikidata Q425681</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>lenalidomide</td></tr><tr><td>population:</td><td>adults with B-cell malignancies (multiple myeloma, CLL, AML, ALL)</td></tr><tr><td>source_paper:</td><td>Hughes_2019</td></tr><tr><td>measured_compound:</td><td>lenalidomide</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C_enteral: transit-compartment absorption reported; transit absorption (ktr=0.00375/s, n=0) folded to first-order ka = ktr/(n+1) = 0.00375/s — same mean absorption time, no delay phase</td></tr><tr><td>molar_masses:</td><td>lenalidomide 259.261 g/mol (drugbank)</td></tr></table><p><b>Defaulted (base-class default used):</b> Tlag.</p><h4>Interpretation flags</h4><ul><li>unit_dimension_mismatch: 'lenalidomide clearance' → Q22 (unit 'dimensionless' vs ontology '[length] ** 3 / [time]') — route to review</li><li>dropped duplicate Q22 ('lenalidomide clearance', value 22) — already have one for this compound</li><li>apparent-ness (ontology-grounded): parameterization=apparent, measured_compound=lenalidomide</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Lenalidomide_Hughes2019_reference;
