function p = Zopiclone_Luurila1996_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: zopiclone   source: Luurila_1996 / reference   route: oral
  % estimated (absent from source): F
  p.name  = 'Zopiclone_Luurila1996_reference_params';
  p.drug  = 'zopiclone';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 132.0;                % central volume [L]
  p.CL = 21.0;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 1.3;                % absorption rate [1/h]
  p.F  = 0.9;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 7.5;             % dose [mg]
end
