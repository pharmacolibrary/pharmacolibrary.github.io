model Zopiclone_Lloyd1990_PD_35s_tbps_binding
  "emax exposure-response sweep — Lloyd_1990 :: 35S-TBPS binding (35S-TBPS binding to rat cerebral cortex membranes)"
  extends Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep(
    E0 = 0,      // [1]
    Emax = 0.51,  // [1; % × 0.01]
    EC50 = 171,  // [nM]
    gamma = 1,
    exposure_per_s = 1);   // 1 nM per second
  // exposure_unit_unresolved: 'nM' — the x axis is in the paper's unit, not SI
  // defaulted: E0
  // defaulted: gamma
  annotation(experiment(StartTime = 0, StopTime = 1800, Interval = 3.6),
    Documentation(info = "<html><body><!-- drug-about --><h4>About zopiclone</h4><p>Zopiclone is a hypnotic and sedative medicine used to treat sleep disorders such as insomnia. It is an approved drug, widely used as a short-term sleeping aid in many countries.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q220426\">Wikidata Q220426</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h4>Zopiclone_Lloyd1990_PD_35s_tbps_binding</h4><p>The steady-state exposure-response curve of Lloyd GK et al., <i>The Journal of pharmacology and experimental therapeutics 255(2):690–696</i> 1990 — 35S-TBPS binding to rat cerebral cortex membranes against zopiclone nM — obtained by sweeping the driver instead of simulating a dose. Model family: emax.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = (library default) drug-free response (baseline)
  Emax  =         51 %        maximal effect term (maximal enhancement, Q320)
  EC50  =        171 nM       exposure at half of the maximal effect term (EC50, Q321)
  gamma = (library default) Hill coefficient</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep\">SigmoidEmaxSweep</a>; this model only supplies the numbers. The x axis is one nM of zopiclone per second of simulated time: there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0   (drug-free)
  exposure = EC50 (171 nM)  response 0.255
  exposure -> infinity  response 0.51</pre></body></html>"));
end Zopiclone_Lloyd1990_PD_35s_tbps_binding;
