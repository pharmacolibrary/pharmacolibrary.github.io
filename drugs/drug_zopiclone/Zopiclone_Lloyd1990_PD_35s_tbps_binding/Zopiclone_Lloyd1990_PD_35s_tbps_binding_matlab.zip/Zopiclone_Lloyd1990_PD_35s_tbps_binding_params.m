function p = Zopiclone_Lloyd1990_PD_35s_tbps_binding_params()
% Zopiclone_Lloyd1990_PD_35s_tbps_binding_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% zopiclone Lloyd_1990::35S_TBPS_binding: emax exposure-response sweep (response = E0 + Emax*frac). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one nM per second, in SI inside (kg/m3, s). Response 35S-TBPS binding in its own unit. Driver: zopiclone (cited_pk).
p.E0 = 0.0;
p.Emax = 0.51;
p.EC50 = 171.0;
p.gamma = 1.0;
p.slope = 0.0;
p.exposure_per_s = 1.0;
p.stop_time = 1800.0;
p.form = 'E0 + Emax*frac';
end
