model Sirukumab_Zhuang2013_reference
  parameter Real Cl_ref = 6.25e-09 "Cl [m3/s]";
  parameter Real Vd_ref = 0.012199999999999999 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    adminMass = 0.0001,
    ka = 8.912037037037037e-06,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About sirukumab</h4><p>Sirukumab, a monoclonal antibody interleukin inhibitor, was investigated for treating rheumatoid arthritis. It was never approved; its marketing application in the European Union was withdrawn, so it remains investigational.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q7530673\">Wikidata Q7530673</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>sirukumab</td></tr><tr><td>population:</td><td>healthy Japanese and Caucasian adults</td></tr><tr><td>source_paper:</td><td>Zhuang_2013</td></tr><tr><td>measured_compound:</td><td>sirukumab</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr></table><p><b>Defaulted (base-class default used):</b> Tlag.</p><h4>Interpretation flags</h4><ul><li>apparent-ness (ontology-grounded): parameterization=apparent, measured_compound=sirukumab</li><li>molar mass: none found for 'sirukumab' — its concentrations stay mass-only</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of TLAG: primary's parameterization (rate-constant / ka-only) does not use it</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 7257600, Tolerance = 1e-9, Interval = 1));
end Sirukumab_Zhuang2013_reference;
