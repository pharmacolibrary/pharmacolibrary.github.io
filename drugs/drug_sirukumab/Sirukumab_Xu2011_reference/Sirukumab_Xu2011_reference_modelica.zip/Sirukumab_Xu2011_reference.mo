model Sirukumab_Xu2011_reference
  parameter Real Cl_ref = 4.212962962962963e-09 "Cl [m3/s]";
  parameter Real Vd_ref = 0.00328 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    adminMass = 2.1e-05,
    k12 = 2.0748644986449864e-06,
    k21 = 1.3693270735524258e-06
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About sirukumab</h4><p>Sirukumab, a monoclonal antibody interleukin inhibitor, was investigated for treating rheumatoid arthritis. It was never approved; its marketing application in the European Union was withdrawn, so it remains investigational.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q7530673\">Wikidata Q7530673</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>sirukumab</td></tr><tr><td>population:</td><td>healthy adults</td></tr><tr><td>source_paper:</td><td>Xu_2011</td></tr><tr><td>measured_compound:</td><td>sirukumab</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>tab_2</td></tr><tr><td>input:</td><td>PK_2C: IV (no input phase)</td></tr></table><h4>Interpretation flags</h4><ul><li>table section iiv: 'IIV (%) on CL' routed out of structural estimates ('Inter-individual variability (IIV)')</li><li>table section iiv: 'IIV (%) on CL' routed out of structural estimates ('Inter-individual variability (IIV)')</li><li>table section iiv: 'IIV (%) on CL' routed out of structural estimates ('Inter-individual variability (IIV)')</li><li>table section iiv: 'IIV (%) on CL' routed out of structural estimates ('Inter-individual variability (IIV)')</li><li>table section iiv: 'IIV (%) on V1' routed out of structural estimates ('Inter-individual variability (IIV)')</li><li>table section iiv: 'IIV (%) on V1' routed out of structural estimates ('Inter-individual variability (IIV)')</li><li>table section iiv: 'IIV (%) on V1' routed out of structural estimates ('Inter-individual variability (IIV)')</li><li>table section iiv: 'IIV (%) on V1' routed out of structural estimates ('Inter-individual variability (IIV)')</li><li>table section iiv: 'IIV (%) on Q' routed out of structural estimates ('Inter-individual variability (IIV)')</li><li>table section iiv: 'IIV (%) on Q' routed out of structural estimates ('Inter-individual variability (IIV)')</li><li>table section iiv: 'IIV (%) on Q' routed out of structural estimates ('Inter-individual variability (IIV)')</li><li>table section iiv: 'IIV (%) on Q' routed out of structural estimates ('Inter-individual variability (IIV)')</li><li>table section iiv: 'IIV (%) on V2' routed out of structural estimates ('Inter-individual variability (IIV)')</li><li>table section iiv: 'IIV (%) on V2' routed out of structural estimates ('Inter-individual variability (IIV)')</li><li>table section iiv: 'IIV (%) on V2' routed out of structural estimates ('Inter-individual variability (IIV)')</li><li>table section iiv: 'IIV (%) on V2' routed out of structural estimates ('Inter-individual variability (IIV)')</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 3024000, Tolerance = 1e-9, Interval = 1));
end Sirukumab_Xu2011_reference;
