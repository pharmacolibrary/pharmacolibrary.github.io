function p = Sirukumab_Xu2011_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: sirukumab   source: Xu_2011 / reference   route: iv_bolus
  % estimated (absent from source): F
  p.name  = 'Sirukumab_Xu2011_reference_params';
  p.drug  = 'sirukumab';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'iv_bolus';        % 'oral' | 'iv_bolus'
  p.depot = false;             % oral -> first-order absorption depot
  p.Vc = 3.28;                % central volume [L]
  p.CL = 0.015167;                % clearance [L/h]
  p.Vp = [4.97];             % peripheral volumes [L]
  p.Q  = [0.0245];             % inter-compartmental clearances [L/h]
  p.ka = 0.0;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 21.0;             % dose [mg]
end
