model Ethionamide_Zhu2002_reference
  parameter Real Cl_ref = 3.655555555555556e-05 "Cl [m3/s]";
  parameter Real Vd_ref = 0.22540000000000002 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 0.9,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.166243,
    adminMass = 0.00075,
    ka = 0.00028333333333333335,
    Tlag = 1548.0
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About ethionamide</h4><p>Ethionamide is an antituberculous drug used to treat tuberculosis. It is a WHO essential medicine and remains in use as part of tuberculosis treatment, though it is not authorised in the European Union.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q414767\">Wikidata Q414767</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>ethionamide</td></tr><tr><td>population:</td><td>patients with tuberculosis</td></tr><tr><td>source_paper:</td><td>Zhu_2002</td></tr><tr><td>measured_compound:</td><td>ethionamide</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>ethionamide 166.243 g/mol (drugbank)</td></tr></table><p><b>Defaulted (base-class default used):</b> F.</p><h4>Interpretation flags</h4><ul><li>dropped value-less row: 'ETA areas under the concentration-versus-time curve (AUCs)' (captured trailing unit 'AUCs' for child rows)</li><li>dropped value-less row: 'ETA PK parameter estimates'</li><li>dropped unlinked row (NIL): 'delayed absorption' — extend the ontology if this is a real PK parameter (source ['Zhu_2002:abstract'])</li><li>unit_dimension_unknown: 'mcg h/ml' (AUC)</li><li>implicit units: 'AUC values' → mg*h/L (from the popPK convention: 'The parameter is AUC (Area Under the Curve). Without paper-specific information, the standard unit for AUC in pharmacoki')</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=ethionamide</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li><li>gap-filled Q49 (kabs) from Al-Shaer_2020's review values (primary lacked it)</li><li>gap-filled Q83 (tlag) from Al-Shaer_2020's review values (primary lacked it)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Ethionamide_Zhu2002_reference;
