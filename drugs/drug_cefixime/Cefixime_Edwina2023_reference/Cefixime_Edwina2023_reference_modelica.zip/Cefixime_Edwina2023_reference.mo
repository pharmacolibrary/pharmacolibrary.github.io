model Cefixime_Edwina2023_reference
  parameter Real Cl_ref = 1.7611111111111112e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.010199999999999999 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.45344999999999996,
    adminMass = 1e-05,
    k12 = 0.0003213507625272332,
    k21 = 0.0003365274925849875
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About cefixime</h4><p>Cefixime is a third-generation cephalosporin antibiotic used to treat bacterial infections such as gonorrhea, urinary tract infections, bronchitis, otitis media, and strep throat. It is an approved medicine and appears on the WHO list of essential medicines, so it remains in widespread use.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q163901\">Wikidata Q163901</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>cefixime</td></tr><tr><td>population:</td><td>review reference</td></tr><tr><td>source_paper:</td><td>Edwina_2023</td></tr><tr><td>measured_compound:</td><td>cefixime</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_2C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>cefixime 453.45 g/mol (drugbank)</td></tr></table><h4>Interpretation flags</h4><ul><li>built from REVIEW reference values (Edwina_2023) — secondary source</li><li>volume reported by review</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Cefixime_Edwina2023_reference;
