model Voclosporin_AbdelKahaar2023_reference
  parameter Real Cl_ref = 1.6666666666666667e-05 "Cl [m3/s]";
  parameter Real Vd_ref = 2.154 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 1.214646,
    adminMass = 4.74e-05,
    ka = 0.0001388888888888889,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About voclosporin</h4><p>Voclosporin is an immunosuppressive calcineurin inhibitor used to treat lupus nephritis and has also been studied for uveitis. It is approved and authorised in the European Union for lupus nephritis, though it remains investigational for some other uses and carries a boxed warning.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q7939256\">Wikidata Q7939256</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>voclosporin</td></tr><tr><td>population:</td><td>review reference</td></tr><tr><td>source_paper:</td><td>Abdel-Kahaar_2023</td></tr><tr><td>measured_compound:</td><td>voclosporin</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C_enteral: apparent (/F) parameterization ⇒ extravascular dosing</td></tr><tr><td>molar_masses:</td><td>voclosporin 1214.65 g/mol (drugbank)</td></tr></table><p><b>Defaulted (base-class default used):</b> ka, Tlag.</p><h4>Interpretation flags</h4><ul><li>built from REVIEW reference values (Abdel-Kahaar_2023) — secondary source</li><li>volume reported by review</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 518400, Tolerance = 1e-9, Interval = 1));
end Voclosporin_AbdelKahaar2023_reference;
