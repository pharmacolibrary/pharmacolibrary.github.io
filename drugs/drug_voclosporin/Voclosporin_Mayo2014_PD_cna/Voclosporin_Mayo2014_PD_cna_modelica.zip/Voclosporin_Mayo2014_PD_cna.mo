model Voclosporin_Mayo2014_PD_cna
  "sigmoid_emax exposure-response sweep — Mayo_2014 :: CNa (calcineurin activity)"
  extends Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep(
    E0 = 1.15,      // [pmol/min/mg]
    Emax = -0.87,  // [pmol/min/mg]
    EC50 = 0.000123,  // [kg/m3; ng/mL × 1e-06]
    gamma = 1,
    exposure_per_s = 1e-06);   // 1 ng/mL per second
  // imax_as_negative_emax: Imax (Q323) enters SigmoidEmaxSweep as −Emax
  // defaulted: gamma
  annotation(experiment(StartTime = 0, StopTime = 1300, Interval = 2.6),
    Documentation(info = "<html><body><!-- drug-about --><h4>About voclosporin</h4><p>Voclosporin is an immunosuppressive calcineurin inhibitor used to treat lupus nephritis and has also been studied for uveitis. It is approved and authorised in the European Union for lupus nephritis, though it remains investigational for some other uses and carries a boxed warning.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q7939256\">Wikidata Q7939256</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h4>Voclosporin_Mayo2014_PD_cna</h4><p>The steady-state exposure-response curve of Mayo PR et al., <i>Journal of clinical pharmacology 54(5):537–545</i> 2014 (<a href=\"https://doi.org/10.1002/jcph.237\">doi:10.1002/jcph.237</a>) — calcineurin activity [pmol/min/mg] against voclosporin ng/mL — obtained by sweeping the driver instead of simulating a dose. Model family: sigmoid_emax.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    =       1.15 pmol/min/mg drug-free response (baseline) (baseline immunosuppression, Q324)
  Emax  =       0.87 pmol/min/mg maximal effect term (Maximum CNa Inhibition, Q323)
  EC50  =        123 ng/mL    exposure at half of the maximal effect term (effective concentration, Q321)
  gamma = (library default) Hill coefficient</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep\">SigmoidEmaxSweep</a>; this model only supplies the numbers. The x axis is one ng/mL of voclosporin per second of simulated time (exposure is in kg/m3): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 1.15   (drug-free)
  exposure = EC50 (123 ng/mL)  response 0.715
  exposure -> infinity  response 0.28</pre></body></html>"));
end Voclosporin_Mayo2014_PD_cna;
