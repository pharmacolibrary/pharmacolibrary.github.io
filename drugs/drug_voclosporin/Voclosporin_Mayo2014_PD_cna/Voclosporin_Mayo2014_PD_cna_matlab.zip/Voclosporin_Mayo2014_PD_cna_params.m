function p = Voclosporin_Mayo2014_PD_cna_params()
% Voclosporin_Mayo2014_PD_cna_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% voclosporin Mayo_2014::CNa: sigmoid_emax exposure-response sweep (response = E0 + Emax*frac). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one ng/mL per second, in SI inside (kg/m3, s). Response CNa in pmol/min/mg. Driver: voclosporin (pk_record).
p.E0 = 1.15;
p.Emax = -0.87;
p.EC50 = 0.00012299999999999998;
p.gamma = 1.0;
p.slope = 0.0;
p.exposure_per_s = 1e-06;
p.stop_time = 1300.0;
p.form = 'E0 + Emax*frac';
end
