model Fentanyl_Koehntop1986_reference
  parameter Real Cl_ref = 4.983333333333334e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.10149999999999999 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.3364705,
    adminMass = 1e-05
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About fentanyl</h4><p>Fentanyl is a synthetic opioid analgesic used to treat pain, including cancer-related and postoperative pain, and as an anesthetic adjuvant. It is widely used and authorised in the European Union, though it is a controlled substance carrying a boxed warning.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q407541\">Wikidata Q407541</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>fentanyl</td></tr><tr><td>population:</td><td>neonates</td></tr><tr><td>source_paper:</td><td>Koehntop_1986</td></tr><tr><td>measured_compound:</td><td>fentanyl</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>fentanyl 336.471 g/mol (drugbank)</td></tr></table><h4>Interpretation flags</h4><ul><li>unit_dimension_unknown: 'ml X kg-1 X min-1' (CL)</li><li>dropped duplicate Q60 ('t 1/2 beta', value None) — already have one for this compound</li><li>implicit units: 'clearance' → L/h (from the popPK convention: 'The paper provides no text or table notes to specify the unit. In population PK, total clearance is conventionally repor')</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=fentanyl</li><li>structure disagreement: deterministic 1C vs LLM 2C — review compartment count</li><li>1C volume normalization: Q63→Q61 (single-compartment model has no central/peripheral split; 'volume of the central compartment' is the general volume)</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li><li>gap-filled Q83 (tlag) from Andersen_1986's review values (primary lacked it)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 97200, Tolerance = 1e-9, Interval = 1));
end Fentanyl_Koehntop1986_reference;
