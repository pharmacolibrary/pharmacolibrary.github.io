model Fentanyl_Tulbah2026_reference
  parameter Real Cl_ref = 3.7500000000000003e-05 "Cl [m3/s]";
  parameter Real Vd_ref = 0.00447 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.3364705,
    adminMass = 1e-05,
    k12 = 0.011931394481730051,
    k21 = 0.0020050125313283208
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>fentanyl</td></tr><tr><td>population:</td><td>review reference</td></tr><tr><td>source_paper:</td><td>Tulbah_2026</td></tr><tr><td>measured_compound:</td><td>fentanyl</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_2C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>fentanyl 336.471 g/mol (drugbank)</td></tr></table><h4>Interpretation flags</h4><ul><li>built from REVIEW reference values (Tulbah_2026) — secondary source</li><li>volume reported by review</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Fentanyl_Tulbah2026_reference;
