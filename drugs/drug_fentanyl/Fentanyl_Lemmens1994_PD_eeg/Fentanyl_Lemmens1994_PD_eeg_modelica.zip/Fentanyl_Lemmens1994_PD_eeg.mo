model Fentanyl_Lemmens1994_PD_eeg
  "sigmoid_emax exposure-response sweep — Lemmens_1994 :: EEG (spectral edge)"
  extends Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep(
    E0 = 19,      // [Hz]
    Emax = -12,  // [Hz]
    EC50 = 9.8e-06,  // [kg/m3; ng/ml × 1e-06]
    gamma = 4,
    exposure_per_s = 1e-06);   // 1 ng/ml per second
  // imax_as_negative_emax: Imax (Q323) enters SigmoidEmaxSweep as −Emax
  annotation(experiment(StartTime = 0, StopTime = 98, Interval = 0.196),
    Documentation(info = "<html><body><h4>Fentanyl_Lemmens1994_PD_eeg</h4><p>The steady-state exposure-response curve of Lemmens HJ et al., <i>Clinical pharmacology and therapeutics 56(3):261–271</i> 1994 (<a href=\"https://doi.org/10.1038/clpt.1994.136\">doi:10.1038/clpt.1994.136</a>) — spectral edge [Hz] against fentanyl ng/ml — obtained by sweeping the driver instead of simulating a dose. Model family: sigmoid_emax.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    =         19 Hz       drug-free response (baseline) (E0, Q324)
  Emax  =         12 Hz       maximal effect term (Emax, Q323)
  EC50  =        9.8 ng/ml    exposure at half of the maximal effect term (EC50, Q321)
  gamma =          4          Hill coefficient (gamma, Q325)</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep\">SigmoidEmaxSweep</a>; this model only supplies the numbers. The x axis is one ng/ml of fentanyl per second of simulated time (exposure is in kg/m3): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 19   (drug-free)
  exposure = EC50 (9.8 ng/ml)  response 13
  exposure -> infinity  response 7</pre></body></html>"));
end Fentanyl_Lemmens1994_PD_eeg;
