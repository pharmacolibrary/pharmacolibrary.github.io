function p = Fentanyl_Lemmens1994_PD_eeg_params()
% Fentanyl_Lemmens1994_PD_eeg_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% fentanyl Lemmens_1994::EEG: sigmoid_emax exposure-response sweep (response = E0 + Emax*frac). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one ng/ml per second, in SI inside (kg/m3, s). Response EEG in Hz. Driver: fentanyl (cited_pk).
p.E0 = 19.0;
p.Emax = -12.0;
p.EC50 = 9.800000000000001e-06;
p.gamma = 4.0;
p.slope = 0.0;
p.exposure_per_s = 1e-06;
p.stop_time = 98.0;
p.form = 'E0 + Emax*frac';
end
