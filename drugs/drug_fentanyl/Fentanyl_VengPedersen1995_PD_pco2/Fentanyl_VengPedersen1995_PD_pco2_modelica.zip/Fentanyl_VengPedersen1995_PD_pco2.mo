model Fentanyl_VengPedersen1995_PD_pco2
  "emax exposure-response sweep — Veng-Pedersen_1995 :: pCO2 (transcutaneous pCO2)"
  extends Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep(
    E0 = 39.6,      // [1]
    Emax = 31.5,  // [1]
    EC50 = 0.473,  // [1]
    gamma = 1.33,
    exposure_per_s = 1);   // 1 unit per second
  // exposure_unit_unresolved: '' — the x axis is in the paper's unit, not SI
  annotation(experiment(StartTime = 0, StopTime = 4.8, Interval = 0.0096),
    Documentation(info = "<html><body><h4>Fentanyl_VengPedersen1995_PD_pco2</h4><p>The steady-state exposure-response curve of Veng-Pedersen P et al., <i>Journal of pharmaceutical sciences 84(9):1101–1106</i> 1995 (<a href=\"https://doi.org/10.1002/jps.2600840913\">doi:10.1002/jps.2600840913</a>) — transcutaneous pCO2 against fentanyl — obtained by sweeping the driver instead of simulating a dose. Model family: emax.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    =       39.6          drug-free response (baseline) (Eo, Q324)
  Emax  =       31.5          maximal effect term (EMAX, Q320)
  EC50  =      0.473          exposure at half of the maximal effect term (EC50a, Q321)
  gamma =       1.33          Hill coefficient (N, Q325)</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep\">SigmoidEmaxSweep</a>; this model only supplies the numbers. The x axis is one  of fentanyl per second of simulated time: there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 39.6   (drug-free)
  exposure = EC50 (0.473 )  response 55.35
  exposure -> infinity  response 71.1</pre></body></html>"));
end Fentanyl_VengPedersen1995_PD_pco2;
