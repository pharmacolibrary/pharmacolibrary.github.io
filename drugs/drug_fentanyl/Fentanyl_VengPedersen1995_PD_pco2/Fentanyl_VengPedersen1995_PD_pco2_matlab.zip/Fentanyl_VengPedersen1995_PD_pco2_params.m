function p = Fentanyl_VengPedersen1995_PD_pco2_params()
% Fentanyl_VengPedersen1995_PD_pco2_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% fentanyl Veng-Pedersen_1995::pCO2: emax exposure-response sweep (response = E0 + Emax*frac). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one SI per second, in SI inside (kg/m3, s). Response pCO2 in its own unit. Driver: fentanyl (cited_pk).
p.E0 = 39.6;
p.Emax = 31.5;
p.EC50 = 0.473;
p.gamma = 1.33;
p.slope = 0.0;
p.exposure_per_s = 1.0;
p.stop_time = 4.8;
p.form = 'E0 + Emax*frac';
end
