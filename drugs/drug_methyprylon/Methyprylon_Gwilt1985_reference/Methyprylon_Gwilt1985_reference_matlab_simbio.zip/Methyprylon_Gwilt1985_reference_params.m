function p = Methyprylon_Gwilt1985_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: methyprylon   source: Gwilt_1985 / reference   route: oral
  % estimated (absent from source): ka
  % Vc is the record's Vss — no central volume was reported; 1-compartment reading
  p.name  = 'Methyprylon_Gwilt1985_reference_params';
  p.drug  = 'methyprylon';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 67.9;                % central volume [L]
  p.CL = 0.8337;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.5;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 200.0;             % dose [mg]
end
