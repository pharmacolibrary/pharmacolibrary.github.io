model Temocillin_Muller2023_reference
  parameter Real Cl_ref = 2.002777777777778e-05 "Cl [m3/s]";
  parameter Real Vd_ref = 0.031990000000000005 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.41445,
    adminMass = 0.004
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About temocillin</h4><p>Temocillin is an antibiotic of the penicillin group with an extended spectrum, used to treat bacterial infections. It is not authorised across the whole European Union but is used in a limited number of European countries, mainly for serious infections caused by resistant gram-negative bacteria.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q3983108\">Wikidata Q3983108</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>temocillin</td></tr><tr><td>population:</td><td>neutropenic mice</td></tr><tr><td>source_paper:</td><td>Muller_2023</td></tr><tr><td>measured_compound:</td><td>temocillin</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>temocillin 414.45 g/mol (drugbank)</td></tr></table><h4>Interpretation flags</h4><ul><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=temocillin</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Temocillin_Muller2023_reference;
