model Temocillin_van2024_PD_cfu_ml
  "sigmoid_emax exposure-response sweep — van_2024 :: cfu/mL (total bacterial population)"
  extends Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep(
    E0 = 0,      // [1]
    Emax = -0.000572222222222,  // [1/s; h−1 × 0.000277778]
    EC50 = 0.00356,  // [kg/m3; mg/L × 0.001]
    gamma = 10,
    exposure_per_s = 0.001);   // 1 mg/L per second
  // imax_as_negative_emax: Imax (Q323) enters SigmoidEmaxSweep as −Emax
  // defaulted: E0
  annotation(experiment(StartTime = 0, StopTime = 36, Interval = 0.072),
    Documentation(info = "<html><body><!-- drug-about --><h4>About temocillin</h4><p>Temocillin is an antibiotic of the penicillin group with an extended spectrum, used to treat bacterial infections. It is not authorised across the whole European Union but is used in a limited number of European countries, mainly for serious infections caused by resistant gram-negative bacteria.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q3983108\">Wikidata Q3983108</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h4>Temocillin_van2024_PD_cfu_ml</h4><p>The steady-state exposure-response curve of van Os W et al., <i>The Journal of antimicrobial chemotherapy 79(10):2484–2492</i> 2024 (<a href=\"https://doi.org/10.1093/jac/dkae243\">doi:10.1093/jac/dkae243</a>) — total bacterial population [log10 cfu/mL] against temocillin mg/L — obtained by sweeping the driver instead of simulating a dose. Model family: sigmoid_emax.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = (library default) drug-free response (baseline)
  Emax  =       2.06 h−1      maximal effect term (Maximum drug effect rate constant (S), Q323)
  EC50  =       3.56 mg/L     exposure at half of the maximal effect term (Drug concentration at which effect is half-maximal (S), Q321)
  gamma =         10          Hill coefficient (Hill coefficient (S), Q325)</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep\">SigmoidEmaxSweep</a>; this model only supplies the numbers. The x axis is one mg/L of temocillin per second of simulated time (exposure is in kg/m3): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0   (drug-free)
  exposure = EC50 (3.56 mg/L)  response -0.0002861
  exposure -> infinity  response -0.0005722</pre></body></html>"));
end Temocillin_van2024_PD_cfu_ml;
