function p = Temocillin_van2024_PD_cfu_ml_params()
% Temocillin_van2024_PD_cfu_ml_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% temocillin van_2024::cfu_mL: sigmoid_emax exposure-response sweep (response = E0 + Emax*frac). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one mg/L per second, in SI inside (kg/m3, s). Response cfu/mL in log10 cfu/mL. Driver: temocillin (pk_record).
p.E0 = 0.0;
p.Emax = -0.0005722222222222222;
p.EC50 = 0.0035599999999999994;
p.gamma = 10.0;
p.slope = 0.0;
p.exposure_per_s = 0.001;
p.stop_time = 36.0;
p.form = 'E0 + Emax*frac';
end
