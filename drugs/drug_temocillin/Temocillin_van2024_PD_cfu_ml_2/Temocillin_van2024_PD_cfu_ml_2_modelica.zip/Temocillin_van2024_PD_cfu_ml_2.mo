model Temocillin_van2024_PD_cfu_ml_2
  "linear exposure-response sweep — van_2024 :: cfu/mL (resistant bacterial population)"
  extends Pharmacolibrary.Interfaces.PartialExposureResponseSweep(
    E0 = 0,      // [1]
    Emax = 0, EC50 = 1,      // unused by a line
    exposure_per_s = 0.001);
  parameter Real slope = 31212   "[meter ** 3 * second / kilogram; L/mg·h−1 × 3.6e+06]";
equation
  response = E0 + slope*exposure;
  // defaulted: E0
  annotation(experiment(StartTime = 0, StopTime = 1000, Interval = 2),
    Documentation(info = "<html><body><!-- drug-about --><h4>About temocillin</h4><p>Temocillin is an antibiotic of the penicillin group with an extended spectrum, used to treat bacterial infections. It is not authorised across the whole European Union but is used in a limited number of European countries, mainly for serious infections caused by resistant gram-negative bacteria.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q3983108\">Wikidata Q3983108</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h4>Temocillin_van2024_PD_cfu_ml_2</h4><p>The steady-state exposure-response curve of van Os W et al., <i>The Journal of antimicrobial chemotherapy 79(10):2484–2492</i> 2024 (<a href=\"https://doi.org/10.1093/jac/dkae243\">doi:10.1093/jac/dkae243</a>) — resistant bacterial population [log10 cfu/mL] against temocillin mg/L — obtained by sweeping the driver instead of simulating a dose. Model family: linear.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = (library default) drug-free response (baseline)
  slope =    0.00867 L/mg·h−1 change in response per unit of exposure (Linear drug effect rate constant (RES), Q335)</pre><p>The algebra is <code>response = E0 + slope*exposure</code>; this model only supplies the numbers. The x axis is one mg/L of temocillin per second of simulated time (exposure is in kg/m3): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0   (drug-free)</pre></body></html>"));
end Temocillin_van2024_PD_cfu_ml_2;
