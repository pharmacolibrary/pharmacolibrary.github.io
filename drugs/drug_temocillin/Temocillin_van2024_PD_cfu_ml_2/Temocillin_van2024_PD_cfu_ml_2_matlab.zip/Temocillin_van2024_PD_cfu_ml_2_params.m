function p = Temocillin_van2024_PD_cfu_ml_2_params()
% Temocillin_van2024_PD_cfu_ml_2_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% temocillin van_2024::cfu_mL::2: linear exposure-response sweep (response = E0 + slope*exposure). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one mg/L per second, in SI inside (kg/m3, s). Response cfu/mL in log10 cfu/mL. Driver: temocillin (pk_record).
p.E0 = 0.0;
p.Emax = 0.0;
p.EC50 = 1.0;
p.gamma = 1.0;
p.slope = 31212.00000000001;
p.exposure_per_s = 0.001;
p.stop_time = 1000.0;
p.form = 'E0 + slope*exposure';
end
