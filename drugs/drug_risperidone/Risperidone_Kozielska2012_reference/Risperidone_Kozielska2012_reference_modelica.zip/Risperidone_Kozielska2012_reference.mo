// parent + metabolites (paliperidone): PK_3M_3C — first-pass formation; parent 2 + hepatic, metabolites [2]
model Risperidone_Kozielska2012_reference
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_3M_3C(
    Vd1 = 0.08960000000000001,
    Vd2 = 0.08960000000000001,
    Vd3 = 0.011760000000000001,
    q12 = 2.4999999999999998e-05,
    q21 = 2.4999999999999998e-05,
    q23 = 1.7325e-06,
    q32 = 1.7325e-06,
    q1_m11 = 1.4719444444444444e-05,
    CL1 = 0.0,
    Vd1m1 = 0.0847,
    CLm1 = 2.0222222222222222e-05,
    Vd2m1 = 0.019670000000000003,
    qm11_m12 = 4.763888888888889e-06,
    qm12_m11 = 4.763888888888889e-06,
    MW = 0.41048450000000003,
    MW_m1 = 0.42649200000000004,
    F = 1.0,
    ka = 0.0008055555555555556,
    Tlag = 612.0,
    adminDuration = 600,
    adminCount = 1,
    adminMass = 7e-07
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About risperidone</h4><p>Risperidone is an atypical antipsychotic used for schizophrenia and a range of other mental disorders such as bipolar disorder, autism-related irritability, and Tourette syndrome. It is widely used worldwide, is included on the WHO list of essential medicines, and is authorised in the European Union for schizophrenia.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q412443\">Wikidata Q412443</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>risperidone</td></tr><tr><td>population:</td><td>rats</td></tr><tr><td>source_paper:</td><td>Kozielska_2012</td></tr><tr><td>measured_compound:</td><td>risperidone</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>parent_metabolite</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>Tab2</td></tr><tr><td>input:</td><td>PK_3M_3C: absorption rate constant reported; parent clearance = Σ formation clearances (no other elimination route); hepatic volume not reported separately — set equal to the central volume (as Jung_2024 fixes Vc = VH); formation of paliperidone: CLfm; F = 1: first pass is the hepatic compartment (absorption complete, no bioavailability reported); dose 0.7 mg (paper)</td></tr><tr><td>molar_masses:</td><td>paliperidone 426.492 g/mol (pubchem); risperidone 410.485 g/mol (drugbank)</td></tr></table><p><b>Defaulted (base-class default used):</b> q12/q21 (hepatic flow, 90 L/h).</p><h4>Interpretation flags</h4><ul><li>table section iiv: 'IIV-FIP (%CV)' routed out of structural estimates ('Inter-individual variability')</li><li>table section iiv: 'IIV-FIP (%CV)' routed out of structural estimates ('Inter-individual variability')</li><li>table section iiv: 'IIV-FIP (%CV)' routed out of structural estimates ('Inter-individual variability')</li><li>table section iiv: 'IIV-FIP (%CV)' routed out of structural estimates ('Inter-individual variability')</li><li>table section iiv: 'IIV-KaSC-RIS (%CV)' routed out of structural estimates ('Inter-individual variability')</li><li>table section iiv: 'IIV-KaSC-RIS (%CV)' routed out of structural estimates ('Inter-individual variability')</li><li>table section iiv: 'IIV-KaSC-RIS (%CV)' routed out of structural estimates ('Inter-individual variability')</li><li>table section iiv: 'IIV-KaSC-RIS (%CV)' routed out of structural estimates ('Inter-individual variability')</li><li>table section iiv: 'IIV-KaSC-PALI (%CV)' routed out of structural estimates ('Inter-individual variability')</li><li>table section iiv: 'IIV-KaSC-PALI (%CV)' routed out of structural estimates ('Inter-individual variability')</li><li>table section iiv: 'IIV-KaSC-PALI (%CV)' routed out of structural estimates ('Inter-individual variability')</li><li>table section iiv: 'IIV-KaSC-PALI (%CV)' routed out of structural estimates ('Inter-individual variability')</li><li>table section iiv: 'IIV-DRSC-RIS (%CV)' routed out of structural estimates ('Inter-individual variability')</li><li>table section iiv: 'IIV-DRSC-RIS (%CV)' routed out of structural estimates ('Inter-individual variability')</li><li>table section iiv: 'IIV-DRSC-RIS (%CV)' routed out of structural estimates ('Inter-individual variability')</li><li>table section iiv: 'IIV-DRSC-RIS (%CV)' routed out of structural estimates ('Inter-individual variability')</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Risperidone_Kozielska2012_reference;
