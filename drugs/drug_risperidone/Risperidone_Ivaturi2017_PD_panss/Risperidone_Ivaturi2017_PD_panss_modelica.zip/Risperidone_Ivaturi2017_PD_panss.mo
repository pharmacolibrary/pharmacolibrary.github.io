model Risperidone_Ivaturi2017_PD_panss
  "emax exposure-response sweep — Ivaturi_2017 :: PANSS (PANSS total score)"
  extends Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep(
    E0 = 94.9,      // [1]
    Emax = -0.054,  // [1]
    EC50 = 4.6e-06,  // [kg/m3; ng ml À1 × 1e-06]
    gamma = 1,
    exposure_per_s = 1e-06);   // 1 ng ml À1 per second
  // imax_as_negative_emax: Imax (Q323) enters SigmoidEmaxSweep as −Emax
  // defaulted: gamma
  annotation(experiment(StartTime = 0, StopTime = 46, Interval = 0.092),
    Documentation(info = "<html><body><!-- drug-about --><h4>About risperidone</h4><p>Risperidone is an atypical antipsychotic used for schizophrenia and a range of other mental disorders such as bipolar disorder, autism-related irritability, and Tourette syndrome. It is widely used worldwide, is included on the WHO list of essential medicines, and is authorised in the European Union for schizophrenia.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q412443\">Wikidata Q412443</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h4>Risperidone_Ivaturi2017_PD_panss</h4><p>The steady-state exposure-response curve of Ivaturi V et al., <i>British journal of clinical pharmacology 83(7):1476–1498</i> 2017 (<a href=\"https://doi.org/10.1111/bcp.13246\">doi:10.1111/bcp.13246</a>) — PANSS total score against total active moiety (risperidone + 9-OH-risperidone) ng ml À1 — obtained by sweeping the driver instead of simulating a dose. Model family: emax.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    =       94.9          drug-free response (baseline) (BSL - Baseline PANSS, Q324)
  Emax  =      0.054          maximal effect term (Emax - Maximum drug effect, Q323)
  EC50  =        4.6 ng ml À1 exposure at half of the maximal effect term (EC50 - Concentration to 50% of Emax, Q321)
  gamma = (library default) Hill coefficient</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep\">SigmoidEmaxSweep</a>; this model only supplies the numbers. The x axis is one ng ml À1 of total active moiety (risperidone + 9-OH-risperidone) per second of simulated time (exposure is in kg/m3): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 94.9   (drug-free)
  exposure = EC50 (4.6 ng ml À1)  response 94.87
  exposure -> infinity  response 94.85</pre></body></html>"));
end Risperidone_Ivaturi2017_PD_panss;
