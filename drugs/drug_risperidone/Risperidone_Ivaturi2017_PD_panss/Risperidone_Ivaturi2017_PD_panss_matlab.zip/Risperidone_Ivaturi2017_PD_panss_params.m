function p = Risperidone_Ivaturi2017_PD_panss_params()
% Risperidone_Ivaturi2017_PD_panss_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% risperidone Ivaturi_2017::PANSS: emax exposure-response sweep (response = E0 + Emax*frac). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one ng ml À1 per second, in SI inside (kg/m3, s). Response PANSS in its own unit. Driver: total active moiety (risperidone + 9-OH-risperidone) (not_resolved).
p.E0 = 94.9;
p.Emax = -0.054;
p.EC50 = 4.599999999999999e-06;
p.gamma = 1.0;
p.slope = 0.0;
p.exposure_per_s = 1e-06;
p.stop_time = 46.0;
p.form = 'E0 + Emax*frac';
end
