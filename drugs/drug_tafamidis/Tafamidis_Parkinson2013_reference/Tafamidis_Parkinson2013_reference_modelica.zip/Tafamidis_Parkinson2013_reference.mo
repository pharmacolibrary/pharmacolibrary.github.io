model Tafamidis_Parkinson2013_reference
  parameter Real Cl_ref = 2.3333333333333336e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.007675137617529287 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C_enteral(
    weight = 70.0,
    F = 0.9,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.308116,
    adminMass = 2e-05,
    ka = 0.00011388888888888888,
    Tlag = 0.0,
    k12 = 0.019254088348887366,
    k21 = 0.007539682539682538
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About tafamidis</h4><p>Tafamidis is a nervous system drug used to treat amyloidosis. It is authorised in the European Union and is also being investigated for other uses.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q519447\">Wikidata Q519447</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>tafamidis</td></tr><tr><td>population:</td><td>review reference</td></tr><tr><td>source_paper:</td><td>Parkinson_2013</td></tr><tr><td>measured_compound:</td><td>tafamidis</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_2C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>tafamidis 308.116 g/mol (drugbank)</td></tr></table><p><b>Defaulted (base-class default used):</b> F, Tlag.</p><h4>Interpretation flags</h4><ul><li>built from REVIEW reference values (Parkinson_2013) — secondary source</li><li>central volume derived from CL·t½/ln2</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Tafamidis_Parkinson2013_reference;
