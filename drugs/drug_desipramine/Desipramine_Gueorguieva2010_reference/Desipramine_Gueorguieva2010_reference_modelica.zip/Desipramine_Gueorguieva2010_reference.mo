model Desipramine_Gueorguieva2010_reference
  parameter Real Cl_ref = 4.444444444444444e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.022 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.26638069999999997,
    adminMass = 5e-05,
    k12 = 0.00016414141414141417,
    k21 = 0.0002777777777777778
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>desipramine</td></tr><tr><td>population:</td><td>healthy subjects</td></tr><tr><td>source_paper:</td><td>Gueorguieva_2010</td></tr><tr><td>measured_compound:</td><td>desipramine</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>tab_0</td></tr><tr><td>input:</td><td>PK_2C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>desipramine 266.381 g/mol (drugbank)</td></tr></table><h4>Interpretation flags</h4><ul><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=desipramine</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Desipramine_Gueorguieva2010_reference;
