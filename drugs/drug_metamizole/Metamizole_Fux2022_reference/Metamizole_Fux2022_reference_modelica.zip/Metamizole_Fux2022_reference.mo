model Metamizole_Fux2022_reference
  parameter Real Cl_ref = 1.1666666666666665e-07 "Cl [m3/s]";
  parameter Real Vd_ref = 0.005374616105327743 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.311356,
    adminMass = 1e-05
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About metamizole</h4><p>Metamizole (dipyrone) is a pyrazolone painkiller and fever reducer used to treat pain and fever. It has been withdrawn in some countries over safety concerns, but remains in use in others.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q422761\">Wikidata Q422761</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>metamizole</td></tr><tr><td>population:</td><td>review reference</td></tr><tr><td>source_paper:</td><td>Fux_2022</td></tr><tr><td>measured_compound:</td><td>metamizole</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>metamizole 311.356 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>built from REVIEW reference values (Fux_2022) — secondary source</li><li>central volume derived from CL·t½/ln2</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 162000, Tolerance = 1e-9, Interval = 1));
end Metamizole_Fux2022_reference;
