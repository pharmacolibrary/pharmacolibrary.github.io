function p = Nalbuphine_Nie2023_estimates_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: nalbuphine   source: Nie_2023 / estimates   route: oral
  % estimated (absent from source): F
  p.name  = 'Nalbuphine_Nie2023_estimates_params';
  p.drug  = 'nalbuphine';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 31.0;                % central volume [L]
  p.CL = 32.9;                % clearance [L/h]
  p.Vp = [85.9];             % peripheral volumes [L]
  p.Q  = [261.0];             % inter-compartmental clearances [L/h]
  p.ka = 0.826;                % absorption rate [1/h]
  p.F  = 0.9;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 15.0;             % dose [mg]
end
