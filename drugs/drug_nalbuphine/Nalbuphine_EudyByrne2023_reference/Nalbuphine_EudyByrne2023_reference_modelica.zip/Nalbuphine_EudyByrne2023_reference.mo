model Nalbuphine_EudyByrne2023_reference
  parameter Real Cl_ref = 0.0001591666666666667 "Cl [m3/s]";
  parameter Real Vd_ref = 2.57 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.3574434,
    adminMass = 2.7e-05,
    ka = 0.00022944444444444444,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About nalbuphine</h4><p>Nalbuphine is an opioid medication used to treat pain. It is an approved analgesic, though it is not authorised in the European Union.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q277979\">Wikidata Q277979</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>nalbuphine</td></tr><tr><td>population:</td><td>patients with prurigo nodularis</td></tr><tr><td>source_paper:</td><td>Eudy-Byrne_2023</td></tr><tr><td>measured_compound:</td><td>nalbuphine</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>Table 1</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>nalbuphine 357.443 g/mol (drugbank)</td></tr></table><p><b>Defaulted (base-class default used):</b> Tlag.</p><h4>Interpretation flags</h4><ul><li>table section iiv: 'IIV-CL/F' routed out of structural estimates ('Interindividual variance parameters')</li><li>table section iiv: 'IIV-CL/F' routed out of structural estimates ('Interindividual variance parameters')</li><li>table section iiv: 'IIV-CL/F' routed out of structural estimates ('Interindividual variance parameters')</li><li>table section iiv: 'IIV-scale' routed out of structural estimates ('Interindividual variance parameters')</li><li>table section iiv: 'IIV-scale' routed out of structural estimates ('Interindividual variance parameters')</li><li>column 'description' classified 'other' by the LLM but kept: the deterministic diagnostic-column test disagrees (a stratum column is a value column, not a statistic)</li><li>column 'description' classified 'other' by the LLM but kept: the deterministic diagnostic-column test disagrees (a stratum column is a value column, not a statistic)</li><li>routed 'Proportional' → Q316 (prop_error) to residual_error — variability estimate, not a structural parameter</li><li>routed 'Additive' → Q317 (add_error) to residual_error — variability estimate, not a structural parameter</li><li>covariate effect for Q314 has no base parameter row (kept as unattached equation-variable)</li><li>implicit units: 'KA (1/h)' → 1/h (from the paper text: &quot;Table 1 explicitly lists the unit for KA as '(1/h)' next to the parameter name: 'KA (1/h) θ 5 First order absorption rat&quot;)</li><li>apparent-ness (ontology-grounded): parameterization=apparent, measured_compound=nalbuphine</li><li>structure disagreement: deterministic 1C vs LLM 3C — review compartment count</li><li>gap-filled Q76 (V/F) from Zhu_2024's review values (primary lacked it)</li><li>skipped review gap-fill of TLAG: primary's parameterization (rate-constant / ka-only) does not use it</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Nalbuphine_EudyByrne2023_reference;
