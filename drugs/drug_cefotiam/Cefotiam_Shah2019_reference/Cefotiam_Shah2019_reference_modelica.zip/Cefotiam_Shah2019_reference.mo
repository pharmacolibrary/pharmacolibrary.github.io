model Cefotiam_Shah2019_reference
  parameter Real Cl_ref = 9.666666666666667e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.027100000000000003 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.5256280000000001,
    adminMass = 0.0010275
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About cefotiam</h4><p>Cefotiam is a second-generation cephalosporin antibiotic used to treat bacterial infections. It is an approved antibacterial for systemic use, given by injection, mainly in hospital settings.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q3009984\">Wikidata Q3009984</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>cefotiam</td></tr><tr><td>population:</td><td>patients with cystic fibrosis and healthy volunteers</td></tr><tr><td>source_paper:</td><td>Shah_2019</td></tr><tr><td>measured_compound:</td><td>cefotiam</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>pharmaceutics-11-00286-t004</td></tr><tr><td>input:</td><td>PK_1C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>cefotiam 525.628 g/mol (drugbank)</td></tr></table><h4>Interpretation flags</h4><ul><li>covariate effect for Q46 has no base parameter row (kept as unattached equation-variable)</li><li>implicit units: 'Unbound total clearance' → L/h (from the popPK convention: 'The paper discusses unscaled clearance and volume of distribution. In population PK, clearance is standardly expressed i')</li><li>implicit units: 'Unbound volume of distribution at steady-state' → L (from the popPK convention: 'Volume of distribution is standardly expressed in liters (L). The value 27.1 is consistent with a volume of distribution')</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=cefotiam</li><li>structure disagreement: deterministic 1C vs LLM 2C — review compartment count</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Cefotiam_Shah2019_reference;
