model Paracetamol_Langeskov2022_reference
  parameter Real Cl_ref = 7.194444444444444e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.0485 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.151165,
    adminMass = 0.0015,
    ka = 0.0026111111111111114,
    Tlag = 576.0,
    k12 = 0.0011397479954180986,
    k21 = 0.00099779382270357
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About paracetamol</h4><p>Paracetamol is a pain-relieving and fever-lowering medicine used to treat pain, fever, and related conditions such as colds and flu. It is very widely used worldwide, appears on the WHO essential medicines list, and is available over the counter in the UK and approved by the FDA.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q57055\">Wikidata Q57055</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>paracetamol</td></tr><tr><td>population:</td><td>healthy obese adults</td></tr><tr><td>source_paper:</td><td>Langeskov_2022</td></tr><tr><td>measured_compound:</td><td>paracetamol</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>prp2962-tbl-0002</td></tr><tr><td>input:</td><td>PK_2C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>paracetamol 151.165 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>table section iiv: 'ω2 Ka' routed out of structural estimates ('Between subject variablity (ω2)')</li><li>table section iiv: 'ω2 V1/F' routed out of structural estimates ('Between subject variablity (ω2)')</li><li>table section iiv: 'ω2 Cl/f' routed out of structural estimates ('Between subject variablity (ω2)')</li><li>table section iiv: 'ω2 V2/F' routed out of structural estimates ('Between subject variablity (ω2)')</li><li>table section iiv: 'ω2 Tlag' routed out of structural estimates ('Between subject variablity (ω2)')</li><li>table section iiv: 'Residual unexplained variability (Ceps)' routed out of structural estimates ('Between subject variablity (ω2)')</li><li>unit_dimension_unknown: 'Placebo' (kabs)</li><li>routed 'Θkacovariate' → Q314 (omega_cov) to covariance — variability estimate, not a structural parameter</li><li>unit_dimension_mismatch: 'ΘV1/Fcovariate' → Q290 (unit '[luminosity] / [length] ** 2' vs ontology '[length] ** 3') — route to review</li><li>dropped duplicate Q290 ('ΘV1/Fcovariate', value '0.0312') — already have one for this compound</li><li>implicit units: 'ka (h−1) (Placebo)' → 1/h (from the paper text: &quot;The paper text explicitly states the unit for the absorption rate constant in the discussion of previous findings: 'The &quot;)</li><li>apparent-ness (ontology-grounded): parameterization=apparent, measured_compound=paracetamol</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Paracetamol_Langeskov2022_reference;
