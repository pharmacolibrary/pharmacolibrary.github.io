function p = Paracetamol_Anderson2015_PD_vas_params()
% Paracetamol_Anderson2015_PD_vas_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% paracetamol Anderson_2015::VAS: sigmoid_emax exposure-response sweep (response = E0 + Emax*frac). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one mg/l per second, in SI inside (kg/m3, s). Response VAS in 0-10. Driver: paracetamol (pk_record).
p.E0 = 0.0;
p.Emax = -5.2;
p.EC50 = 0.009799999999999998;
p.gamma = 1.0;
p.slope = 0.0;
p.exposure_per_s = 0.001;
p.stop_time = 98.0;
p.form = 'E0 + Emax*frac';
end
