model Paracetamol_Gibb2008_PD_vas
  "sigmoid_emax exposure-response sweep — Gibb_2008 :: VAS (Pain score reduction)"
  extends Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep(
    E0 = 0,      // [1]
    Emax = -5.17,  // [pain units]
    EC50 = 0.00998,  // [kg/m3; mg/l × 0.001]
    gamma = 1,
    exposure_per_s = 0.001);   // 1 mg/l per second
  // family_inferred: the record's model family is effect_compartment; read from the parameters: Emax/Imax, EC50/IC50 and a Hill coefficient — sigmoid Emax
  // imax_as_negative_emax: Imax (Q323) enters SigmoidEmaxSweep as −Emax
  // defaulted: E0
  annotation(experiment(StartTime = 0, StopTime = 100, Interval = 0.2),
    Documentation(info = "<html><body><!-- drug-about --><h4>About paracetamol</h4><p>Paracetamol is a pain-relieving and fever-lowering medicine used to treat pain, fever, and related conditions such as colds and flu. It is very widely used worldwide, appears on the WHO essential medicines list, and is available over the counter in the UK and approved by the FDA.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q57055\">Wikidata Q57055</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h4>Paracetamol_Gibb2008_PD_vas</h4><p>The steady-state exposure-response curve of Gibb IA et al., <i>Archives of disease in childhood 93(3):241–247</i> 2008 (<a href=\"https://doi.org/10.1136/adc.2007.126896\">doi:10.1136/adc.2007.126896</a>) — Pain score reduction [pain units] against paracetamol mg/l — obtained by sweeping the driver instead of simulating a dose. Model family: sigmoid_emax.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = (library default) drug-free response (baseline)
  Emax  =       5.17 pain units maximal effect term (Emax, Q323)
  EC50  =       9.98 mg/l     exposure at half of the maximal effect term (EC 50, Q321)
  gamma =          1          Hill coefficient (Hill coefficient, Q325)</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep\">SigmoidEmaxSweep</a>; this model only supplies the numbers. The x axis is one mg/l of paracetamol per second of simulated time (exposure is in kg/m3): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0   (drug-free)
  exposure = EC50 (9.98 mg/l)  response -2.585
  exposure -> infinity  response -5.17</pre></body></html>"));
end Paracetamol_Gibb2008_PD_vas;
