function p = Paracetamol_Gibb2008_PD_vas_params()
% Paracetamol_Gibb2008_PD_vas_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% paracetamol Gibb_2008::VAS: sigmoid_emax exposure-response sweep (response = E0 + Emax*frac). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one mg/l per second, in SI inside (kg/m3, s). Response VAS in pain units. Driver: paracetamol (cited_pk).
p.E0 = 0.0;
p.Emax = -5.17;
p.EC50 = 0.00998;
p.gamma = 1.0;
p.slope = 0.0;
p.exposure_per_s = 0.001;
p.stop_time = 100.0;
p.form = 'E0 + Emax*frac';
end
