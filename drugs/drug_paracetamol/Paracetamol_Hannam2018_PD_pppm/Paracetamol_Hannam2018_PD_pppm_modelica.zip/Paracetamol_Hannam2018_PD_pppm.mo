model Paracetamol_Hannam2018_PD_pppm
  "sigmoid_emax exposure-response sweep — Hannam_2018 :: PPPM (Pain Score)"
  extends Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep(
    E0 = 15,      // [pain units]
    Emax = -0.648,  // [pain units]
    EC50 = 0.00706,  // [kg/m3; mg/L × 0.001]
    gamma = 1.48,
    exposure_per_s = 0.001);   // 1 mg/L per second
  // imax_as_negative_emax: Imax (Q323) enters SigmoidEmaxSweep as −Emax
  annotation(experiment(StartTime = 0, StopTime = 71, Interval = 0.142),
    Documentation(info = "<html><body><!-- drug-about --><h4>About paracetamol</h4><p>Paracetamol is a pain-relieving and fever-lowering medicine used to treat pain, fever, and related conditions such as colds and flu. It is very widely used worldwide, appears on the WHO essential medicines list, and is available over the counter in the UK and approved by the FDA.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q57055\">Wikidata Q57055</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h4>Paracetamol_Hannam2018_PD_pppm</h4><p>The steady-state exposure-response curve of Hannam JA et al., <i>Paediatric anaesthesia 28(10):841–851</i> 2018 (<a href=\"https://doi.org/10.1111/pan.13464\">doi:10.1111/pan.13464</a>) — Pain Score [pain units] against paracetamol, ibuprofen, tramadol mg/L — obtained by sweeping the driver instead of simulating a dose. Model family: sigmoid_emax.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    =         15 pain units drug-free response (baseline) (E 0, Q324)
  Emax  =      0.648 pain units maximal effect term (E MAX, Q323)
  EC50  =       7.06 mg/L     exposure at half of the maximal effect term (C 50,ACET, Q321)
  gamma =       1.48          Hill coefficient (HILL EFFECT, Q325)</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep\">SigmoidEmaxSweep</a>; this model only supplies the numbers. The x axis is one mg/L of paracetamol, ibuprofen, tramadol per second of simulated time (exposure is in kg/m3): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 15   (drug-free)
  exposure = EC50 (7.06 mg/L)  response 14.68
  exposure -> infinity  response 14.35</pre></body></html>"));
end Paracetamol_Hannam2018_PD_pppm;
