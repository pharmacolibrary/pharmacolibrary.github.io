function p = RopeginterferonAlfa2b_Qin2025_PD_plt_params()
% RopeginterferonAlfa2b_Qin2025_PD_plt_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% ropeginterferon_alfa_2b Qin_2025::PLT: indirect_response_i exposure-response sweep (response = E0*(1 - Emax*frac)). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one ng mL−1 per second, in SI inside (kg/m3, s). Response PLT in 109 L−1. Driver: ropeg (not_resolved).
p.E0 = 332.0;
p.Emax = 1.0;
p.EC50 = 7.24e-05;
p.gamma = 1.0;
p.slope = 0.0;
p.exposure_per_s = 1e-06;
p.stop_time = 730.0;
p.form = 'E0*(1 - Emax*frac)';
end
