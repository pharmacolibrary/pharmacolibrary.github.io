function p = RopeginterferonAlfa2b_Qin2025_PD_jak2v617f_allele_burden_red_params()
% RopeginterferonAlfa2b_Qin2025_PD_jak2v617f_allele_burden_red_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% ropeginterferon_alfa_2b Qin_2025::JAK2V617F_allele_burden_reduction: linear exposure-response sweep (response = E0 + slope*exposure). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one ng mL−1 per second, in SI inside (kg/m3, s). Response JAK2V617F allele burden reduction in its own unit. Driver: ropeg (not_resolved).
p.E0 = 0.0;
p.Emax = 0.0;
p.EC50 = 1.0;
p.gamma = 1.0;
p.slope = -0.51;
p.exposure_per_s = 1e-06;
p.stop_time = 1000.0;
p.form = 'E0 + slope*exposure';
end
