model RopeginterferonAlfa2b_Qin2025_PD_jak2v617f_allele_burden_red
  "linear exposure-response sweep — Qin_2025 :: JAK2V617F allele burden reduction (JAK2V617F allele burden reduction)"
  extends Pharmacolibrary.Interfaces.PartialExposureResponseSweep(
    E0 = 0,      // [1]
    Emax = 0, EC50 = 1,      // unused by a line
    exposure_per_s = 1e-06);
  parameter Real slope = -0.51   "[1]";
equation
  response = E0 + slope*exposure;
  // defaulted: E0
  annotation(experiment(StartTime = 0, StopTime = 1000, Interval = 2),
    Documentation(info = "<html><body><!-- drug-about --><h4>About ropeginterferon_alfa_2b</h4><p>Ropeginterferon alfa-2b is a long-acting pegylated interferon used to treat polycythemia vera. It is authorised in the European Union and remains investigational for other uses.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q99754007\">Wikidata Q99754007</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h4>RopeginterferonAlfa2b_Qin2025_PD_jak2v617f_allele_burden_red</h4><p>The steady-state exposure-response curve of Qin A et al., <i>Pharmacology research &amp; perspectives 13(3):e70109</i> 2025 (<a href=\"https://doi.org/10.1002/prp2.70109\">doi:10.1002/prp2.70109</a>) — JAK2V617F allele burden reduction against ropeg ng mL−1 — obtained by sweeping the driver instead of simulating a dose. Model family: linear.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = (library default) drug-free response (baseline)
  slope =      -0.51          change in response per unit of exposure (Exposure effect, Q335)</pre><p>The algebra is <code>response = E0 + slope*exposure</code>; this model only supplies the numbers. The x axis is one ng mL−1 of ropeg per second of simulated time (exposure is in kg/m3): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0   (drug-free)</pre></body></html>"));
end RopeginterferonAlfa2b_Qin2025_PD_jak2v617f_allele_burden_red;
