model RopeginterferonAlfa2b_Qin2025_PD_chr
  "emax exposure-response sweep — Qin_2025 :: CHR (complete hematologic response)"
  extends Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep(
    E0 = 0,      // [1]
    Emax = 8.397,  // [1]
    EC50 = 1.98e-06,  // [kg/m3; ng mL−1 × 1e-06]
    gamma = 1,
    exposure_per_s = 1e-06);   // 1 ng mL−1 per second
  // defaulted: E0
  // defaulted: gamma
  annotation(experiment(StartTime = 0, StopTime = 20, Interval = 0.04),
    Documentation(info = "<html><body><!-- drug-about --><h4>About ropeginterferon_alfa_2b</h4><p>Ropeginterferon alfa-2b is a long-acting pegylated interferon used to treat polycythemia vera. It is authorised in the European Union and remains investigational for other uses.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q99754007\">Wikidata Q99754007</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h4>RopeginterferonAlfa2b_Qin2025_PD_chr</h4><p>The steady-state exposure-response curve of Qin A et al., <i>Pharmacology research &amp; perspectives 13(3):e70109</i> 2025 (<a href=\"https://doi.org/10.1002/prp2.70109\">doi:10.1002/prp2.70109</a>) — complete hematologic response against ropeg ng mL−1 — obtained by sweeping the driver instead of simulating a dose. Model family: emax.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = (library default) drug-free response (baseline)
  Emax  =      8.397          maximal effect term (Maximum effect, Q320)
  EC50  =       1.98 ng mL−1  exposure at half of the maximal effect term (Exposure resulting in 50% of maximum effect, Q321)
  gamma = (library default) Hill coefficient</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep\">SigmoidEmaxSweep</a>; this model only supplies the numbers. The x axis is one ng mL−1 of ropeg per second of simulated time (exposure is in kg/m3): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0   (drug-free)
  exposure = EC50 (1.98 ng mL−1)  response 4.199
  exposure -> infinity  response 8.397</pre></body></html>"));
end RopeginterferonAlfa2b_Qin2025_PD_chr;
