function p = RopeginterferonAlfa2b_Qin2025_PD_chr_params()
% RopeginterferonAlfa2b_Qin2025_PD_chr_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% ropeginterferon_alfa_2b Qin_2025::CHR: emax exposure-response sweep (response = E0 + Emax*frac). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one ng mL−1 per second, in SI inside (kg/m3, s). Response CHR in its own unit. Driver: ropeg (not_resolved).
p.E0 = 0.0;
p.Emax = 8.397;
p.EC50 = 1.98e-06;
p.gamma = 1.0;
p.slope = 0.0;
p.exposure_per_s = 1e-06;
p.stop_time = 20.0;
p.form = 'E0 + Emax*frac';
end
