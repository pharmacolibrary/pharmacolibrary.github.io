model RopeginterferonAlfa2b_Qin2025_PD_wbc
  "indirect_response_i exposure-response sweep — Qin_2025 :: WBC (white blood cell)"
  extends Pharmacolibrary.Interfaces.PartialExposureResponseSweep(
    E0 = 6.72,      // [109 L−1 day−1]
    Emax = 1,  // type I effect term
    EC50 = 0.000152,  // [kg/m3; ng mL−1 × 1e-06]
    gamma = 1,
    exposure_per_s = 1e-06);   // 1 ng mL−1 per second
equation
  response = E0*(1 - Emax*frac);   // steady state, indirect response type I
  // defaulted: gamma
  annotation(experiment(StartTime = 0, StopTime = 1600, Interval = 3.2),
    Documentation(info = "<html><body><!-- drug-about --><h4>About ropeginterferon_alfa_2b</h4><p>Ropeginterferon alfa-2b is a long-acting pegylated interferon used to treat polycythemia vera. It is authorised in the European Union and remains investigational for other uses.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q99754007\">Wikidata Q99754007</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h4>RopeginterferonAlfa2b_Qin2025_PD_wbc</h4><p>The steady-state exposure-response curve of Qin A et al., <i>Pharmacology research &amp; perspectives 13(3):e70109</i> 2025 (<a href=\"https://doi.org/10.1002/prp2.70109\">doi:10.1002/prp2.70109</a>) — white blood cell [109 L−1] against ropeg ng mL−1 — obtained by sweeping the driver instead of simulating a dose. Model family: indirect_response_i.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    =       6.72 109 L−1 day−1 drug-free response (baseline) (WBCss, Q324)
  Emax  =          1          maximal effect term (I max,W, Q323)
  EC50  =        152 ng mL−1  exposure at half of the maximal effect term (IC 50,W, Q322)
  gamma = (library default) Hill coefficient</pre><p>The algebra is <code>response = E0*(1 - Emax*frac)</code>; this model only supplies the numbers. The x axis is one ng mL−1 of ropeg per second of simulated time (exposure is in kg/m3): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 6.72   (drug-free)
  exposure = EC50 (152 ng mL−1)  response 3.36
  exposure -> infinity  response 0</pre></body></html>"));
end RopeginterferonAlfa2b_Qin2025_PD_wbc;
