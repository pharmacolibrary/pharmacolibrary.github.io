function p = RopeginterferonAlfa2b_Qin2025_PD_wbc_params()
% RopeginterferonAlfa2b_Qin2025_PD_wbc_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% ropeginterferon_alfa_2b Qin_2025::WBC: indirect_response_i exposure-response sweep (response = E0*(1 - Emax*frac)). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one ng mL−1 per second, in SI inside (kg/m3, s). Response WBC in 109 L−1. Driver: ropeg (not_resolved).
p.E0 = 6.72;
p.Emax = 1.0;
p.EC50 = 0.00015199999999999998;
p.gamma = 1.0;
p.slope = 0.0;
p.exposure_per_s = 1e-06;
p.stop_time = 1600.0;
p.form = 'E0*(1 - Emax*frac)';
end
