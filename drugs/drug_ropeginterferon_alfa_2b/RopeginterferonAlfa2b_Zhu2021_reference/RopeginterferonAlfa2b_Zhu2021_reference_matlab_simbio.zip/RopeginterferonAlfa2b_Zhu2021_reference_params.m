function p = RopeginterferonAlfa2b_Zhu2021_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: ropeginterferon_alfa_2b   source: Zhu_2021 / reference   route: oral
  p.name  = 'RopeginterferonAlfa2b_Zhu2021_reference_params';
  p.drug  = 'ropeginterferon_alfa_2b';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 2.32;                % central volume [L]
  p.CL = 0.032417;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.005833;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.426;             % absorption lag [h]
  p.dose = 0.024;             % dose [mg]
end
