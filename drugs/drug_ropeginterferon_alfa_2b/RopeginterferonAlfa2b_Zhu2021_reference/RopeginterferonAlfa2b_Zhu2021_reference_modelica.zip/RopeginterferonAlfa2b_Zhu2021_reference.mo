model RopeginterferonAlfa2b_Zhu2021_reference
  parameter Real Cl_ref = 9.00462962962963e-09 "Cl [m3/s]";
  parameter Real cov_body_weight = 1.0 "body weight covariate (reference 1.0)";
  parameter Real Vd_ref = 0.00232 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref*(cov_body_weight/1.0)^(0.927),
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.447529,
    adminMass = 2.4e-08,
    ka = 1.6203703703703705e-06,
    Tlag = 1533.6
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About ropeginterferon_alfa_2b</h4><p>Ropeginterferon alfa-2b is a long-acting pegylated interferon used to treat polycythemia vera. It is authorised in the European Union and remains investigational for other uses.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q99754007\">Wikidata Q99754007</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>ropeginterferon_alfa_2b</td></tr><tr><td>population:</td><td>healthy Caucasian and Chinese adults</td></tr><tr><td>source_paper:</td><td>Zhu_2021</td></tr><tr><td>measured_compound:</td><td>ropeginterferon_alfa_2b</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>T2</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>ropeginterferon_alfa_2b 447.529 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>table section iiv: 'CL/F' routed out of structural estimates ('Between subject variability (CV%)')</li><li>table section iiv: 'CL/F' routed out of structural estimates ('Between subject variability (CV%)')</li><li>table section iiv: 'V/F' routed out of structural estimates ('Between subject variability (CV%)')</li><li>table section iiv: 'V/F' routed out of structural estimates ('Between subject variability (CV%)')</li><li>table section iiv: 'ka' routed out of structural estimates ('Between subject variability (CV%)')</li><li>table section iiv: 'ka' routed out of structural estimates ('Between subject variability (CV%)')</li><li>covariate level 'Impact of body weight' → Q900:impact_of_body_weight = 0.927 (power on Q27)</li><li>dropped PD-category row 'R0 (ng/ml)' → Q336 (R0, category G13) — pharmacodynamic parameters belong to scholarpd, not the PK model (source ['T2:row7:col1'])</li><li>dropped PD-category row 'kdeg (h−1)' → Q328 (kout, category G11) — pharmacodynamic parameters belong to scholarpd, not the PK model (source ['T2:row9:col1'])</li><li>routed 'Proptional (%)' → Q316 (prop_error) to residual_error — variability estimate, not a structural parameter</li><li>routed 'Additive (ng/ml)' → Q317 (add_error) to residual_error — variability estimate, not a structural parameter</li><li>implicit units: 'ka (1/day)' → 1/day (from the paper text: &quot;The paper states in the Results section: 'The typical value ... of apparent clearance (CL/F) ... were 0.778 ... L/day'. &quot;)</li><li>apparent-ness (ontology-grounded): parameterization=apparent, measured_compound=ropeginterferon_alfa_2b</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 3024000, Tolerance = 1e-9, Interval = 1));
end RopeginterferonAlfa2b_Zhu2021_reference;
