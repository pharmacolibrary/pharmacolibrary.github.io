model Ephedrine_Tran2020_reference
  parameter Real Cl_ref = 6.2499999999999995e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.016300000000000002 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.1652322,
    adminMass = 5e-05,
    ka = 0.0001388888888888889,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About ephedrine</h4><p>Ephedrine is a sympathomimetic used for conditions such as asthma, rhinitis, and orthostatic hypotension, and as a nasal decongestant, cardiac stimulant, and pupil-dilating agent. It remains an approved medicine and is included on the WHO list of essential medicines, so it is still in use worldwide.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q219626\">Wikidata Q219626</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>ephedrine</td></tr><tr><td>population:</td><td>review reference</td></tr><tr><td>source_paper:</td><td>Tran_2020</td></tr><tr><td>measured_compound:</td><td>ephedrine</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C_enteral: apparent (/F) parameterization ⇒ extravascular dosing</td></tr><tr><td>molar_masses:</td><td>ephedrine 165.232 g/mol (drugbank)</td></tr></table><p><b>Defaulted (base-class default used):</b> ka, Tlag.</p><h4>Interpretation flags</h4><ul><li>built from REVIEW reference values (Tran_2020) — secondary source</li><li>volume reported by review</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Ephedrine_Tran2020_reference;
