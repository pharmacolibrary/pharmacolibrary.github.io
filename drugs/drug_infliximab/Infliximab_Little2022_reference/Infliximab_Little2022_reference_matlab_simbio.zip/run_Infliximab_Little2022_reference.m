% Run (SimBiology): build model + dose, simulate 0..1344.0 h, plot.
p = Infliximab_Little2022_reference_params();
[model, dose, variant] = build_sb_pk(p);
sd = simulate_sb(model, variant, dose, 1344.0);
