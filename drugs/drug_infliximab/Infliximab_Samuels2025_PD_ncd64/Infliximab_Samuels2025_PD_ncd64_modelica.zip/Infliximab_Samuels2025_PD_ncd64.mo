model Infliximab_Samuels2025_PD_ncd64
  "emax exposure-response sweep — Samuels_2025 :: nCD64 (neutrophil CD64)"
  extends Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep(
    E0 = 0,      // [1]
    Emax = -0.362,  // [ratio]
    EC50 = 1.1,  // [1]
    gamma = 1,
    exposure_per_s = 1);   // 1 unit per second
  // imax_as_negative_emax: Imax (Q323) enters SigmoidEmaxSweep as −Emax
  // exposure_unit_unresolved: '' — the x axis is in the paper's unit, not SI
  // defaulted: E0
  // defaulted: gamma
  annotation(experiment(StartTime = 0, StopTime = 11, Interval = 0.022),
    Documentation(info = "<html><body><!-- drug-about --><h4>About infliximab</h4><p>Infliximab is a monoclonal antibody that blocks tumour necrosis factor alpha and is used to treat inflammatory conditions such as rheumatoid and psoriatic arthritis, Crohn's disease, ulcerative colitis, psoriasis, and ankylosing spondylitis. It is approved and widely used, with several products authorised in the European Union, and is also being studied for other uses.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q415264\">Wikidata Q415264</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h4>Infliximab_Samuels2025_PD_ncd64</h4><p>The steady-state exposure-response curve of Samuels A et al., <i>Clinical and translational science 18(2):e70086</i> 2025 (<a href=\"https://doi.org/10.1111/cts.70086\">doi:10.1111/cts.70086</a>) — neutrophil CD64 [ratio] against infliximab dose number — obtained by sweeping the driver instead of simulating a dose. Model family: emax.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = (library default) drug-free response (baseline)
  Emax  =     -0.362 ratio    maximal effect term (Emax, Q323)
  EC50  =        1.1          exposure at half of the maximal effect term (D50, Q321)
  gamma = (library default) Hill coefficient</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep\">SigmoidEmaxSweep</a>; this model only supplies the numbers. The x axis is one  of infliximab dose number per second of simulated time: there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0   (drug-free)
  exposure = EC50 (1.1 )  response -0.181
  exposure -> infinity  response -0.362</pre></body></html>"));
end Infliximab_Samuels2025_PD_ncd64;
