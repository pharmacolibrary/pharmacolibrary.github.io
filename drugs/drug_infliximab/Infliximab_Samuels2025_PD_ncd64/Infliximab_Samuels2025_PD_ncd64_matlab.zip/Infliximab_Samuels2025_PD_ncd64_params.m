function p = Infliximab_Samuels2025_PD_ncd64_params()
% Infliximab_Samuels2025_PD_ncd64_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% infliximab Samuels_2025::nCD64: emax exposure-response sweep (response = E0 + Emax*frac). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one SI per second, in SI inside (kg/m3, s). Response nCD64 in ratio. Driver: infliximab dose number (dose_only).
p.E0 = 0.0;
p.Emax = -0.362;
p.EC50 = 1.1;
p.gamma = 1.0;
p.slope = 0.0;
p.exposure_per_s = 1.0;
p.stop_time = 11.0;
p.form = 'E0 + Emax*frac';
end
