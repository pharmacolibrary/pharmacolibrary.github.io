function p = Infliximab_Eser2021_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: infliximab   source: Eser_2021 / reference   route: iv_bolus
  % estimated (absent from source): F
  p.name  = 'Infliximab_Eser2021_reference_params';
  p.drug  = 'infliximab';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'iv_bolus';        % 'oral' | 'iv_bolus'
  p.depot = false;             % oral -> first-order absorption depot
  p.Vc = 2.79;                % central volume [L]
  p.CL = 0.011083;                % clearance [L/h]
  p.Vp = [0.898];             % peripheral volumes [L]
  p.Q  = [0.002321];             % inter-compartmental clearances [L/h]
  p.ka = 0.0;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 210.0;             % dose [mg]
end
