model Infliximab_Eser2021_reference
  parameter Real Cl_ref = 3.0787037037037037e-09 "Cl [m3/s]";
  parameter Real cov_weight_0 = 0 "weight covariate";
  parameter Real cov_albumin_1 = 0 "albumin covariate";
  parameter Real cov_sex_2 = 0 "sex covariate";
  parameter Real cov_ada_3 = 0 "ada covariate";
  parameter Real Vd_ref = 0.00279 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref*(1 + (0.729)*cov_weight_0)*(1 + (-0.32)*cov_albumin_1)*(1 + (-0.0728)*cov_sex_2)*(1 + (0.307)*cov_ada_3),
    Vd = Vd_ref*(1 + (1.0)*cov_weight_0),
    adminDuration = 600,
    adminCount = 1,
    adminMass = 0.00021,
    k12 = 2.3106664011681935e-07,
    k21 = 7.179019219665099e-07
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About infliximab</h4><p>Infliximab is a monoclonal antibody that blocks tumour necrosis factor alpha and is used to treat inflammatory conditions such as rheumatoid and psoriatic arthritis, Crohn's disease, ulcerative colitis, psoriasis, and ankylosing spondylitis. It is approved and widely used, with several products authorised in the European Union, and is also being studied for other uses.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q415264\">Wikidata Q415264</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>infliximab</td></tr><tr><td>population:</td><td>adults with rheumatoid arthritis and ankylosing spondylitis</td></tr><tr><td>source_paper:</td><td>Eser_2021</td></tr><tr><td>measured_compound:</td><td>infliximab</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>jcph1732-tbl-0003</td></tr><tr><td>input:</td><td>PK_2C: IV (no input phase)</td></tr></table><h4>Interpretation flags</h4><ul><li>covariate level 'Effect of weight on baseline CL' → Q900:effect_of_weight_on_baseline_cl = 0.729 (linear_fractional on Q22)</li><li>covariate level 'Effect of albumin on baseline CL' → Q900:effect_of_albumin_on_baseline_cl = -0.32 (linear_fractional on Q22)</li><li>dropped duplicate Q22 ('Effect of glucose on baseline CL', value '0.0725') — already have one for this compound</li><li>covariate level 'Effect of patient sex on baseline CL' → Q900:effect_of_patient_sex_on_baseline_cl = -0.0728 (linear_fractional on Q22)</li><li>dropped unlinked row (NIL): 'Effect of CRP on baseline CL' — extend the ontology if this is a real PK parameter (source ['jcph1732-tbl-0003:row13:col1', 'jcph1732-tbl-0003:row13:col2', 'jcph1732-tbl-0003:row13:col3', 'jcph1732-tbl-0003:row13:col4', 'jcph1732-tbl-0003:row13:col5'])</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=infliximab</li><li>molar mass: none found for 'infliximab' — its concentrations stay mass-only</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 3628800, Tolerance = 1e-9, Interval = 1));
end Infliximab_Eser2021_reference;
