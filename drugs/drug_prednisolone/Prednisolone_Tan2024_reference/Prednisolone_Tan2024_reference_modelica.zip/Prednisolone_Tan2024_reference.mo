model Prednisolone_Tan2024_reference
  parameter Real Cl_ref = 2.15e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.0096 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.36044400000000004,
    adminMass = 1e-05
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About prednisolone</h4><p>Prednisolone is a glucocorticoid steroid used to treat inflammatory and autoimmune conditions such as ulcerative colitis, myasthenia gravis, nephrotic syndrome, and various eye, skin, and blood disorders. It is widely used in human medicine, appears on the WHO essential medicines list, and is also approved for veterinary use.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q11426176\">Wikidata Q11426176</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>prednisolone</td></tr><tr><td>population:</td><td>review reference</td></tr><tr><td>source_paper:</td><td>Tan_2024</td></tr><tr><td>measured_compound:</td><td>prednisolone</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>prednisolone 360.444 g/mol (drugbank)</td></tr></table><h4>Interpretation flags</h4><ul><li>built from REVIEW reference values (Tan_2024) — secondary source</li><li>volume reported by review</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Prednisolone_Tan2024_reference;
