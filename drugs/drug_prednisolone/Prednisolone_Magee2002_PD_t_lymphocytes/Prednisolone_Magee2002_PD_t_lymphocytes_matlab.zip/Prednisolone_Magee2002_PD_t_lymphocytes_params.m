function p = Prednisolone_Magee2002_PD_t_lymphocytes_params()
% Prednisolone_Magee2002_PD_t_lymphocytes_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% prednisolone Magee_2002::T_lymphocytes: indirect_response_i exposure-response sweep (response = E0*(1 - Emax*frac)). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one ng ml x1 per second, in SI inside (kg/m3, s). Response T-lymphocytes in cells ml -1. Driver: prednisolone (pk_record).
p.E0 = 2.026578073089701;
p.Emax = 1.0;
p.EC50 = 9.15;
p.gamma = 1.0;
p.slope = 0.0;
p.exposure_per_s = 1.0;
p.stop_time = 92.0;
p.form = 'E0*(1 - Emax*frac)';
end
