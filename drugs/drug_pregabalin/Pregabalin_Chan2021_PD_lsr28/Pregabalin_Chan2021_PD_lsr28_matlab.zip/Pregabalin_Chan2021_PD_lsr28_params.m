function p = Pregabalin_Chan2021_PD_lsr28_params()
% Pregabalin_Chan2021_PD_lsr28_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% pregabalin Chan_2021::LSR28: emax exposure-response sweep (response = E0 + Emax*frac). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one μg/mL per second, in SI inside (kg/m3, s). Response LSR28 in its own unit. Driver: pregabalin (pk_record).
p.E0 = 0.0;
p.Emax = -0.924;
p.EC50 = 0.00469;
p.gamma = 1.0;
p.slope = 0.0;
p.exposure_per_s = 0.001;
p.stop_time = 47.0;
p.form = 'E0 + Emax*frac';
end
