model Pregabalin_Chan2021_PD_lsr28
  "emax exposure-response sweep — Chan_2021 :: LSR28 (natural log‐transformed 28‐day seizure rate)"
  extends Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep(
    E0 = 0,      // [1]
    Emax = -0.924,  // [1]
    EC50 = 0.00469,  // [kg/m3; μg/mL × 0.001]
    gamma = 1,
    exposure_per_s = 0.001);   // 1 μg/mL per second
  // imax_as_negative_emax: Imax (Q323) enters SigmoidEmaxSweep as −Emax
  // defaulted: E0
  // defaulted: gamma
  annotation(experiment(StartTime = 0, StopTime = 47, Interval = 0.094),
    Documentation(info = "<html><body><!-- drug-about --><h4>About pregabalin</h4><p>Pregabalin is used for epilepsy, anxiety disorders, and various types of neuropathic pain such as neuralgia. It is widely used and authorised in the European Union, where several products remain on the market.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q412174\">Wikidata Q412174</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h4>Pregabalin_Chan2021_PD_lsr28</h4><p>The steady-state exposure-response curve of Chan PLS et al., <i>Clinical pharmacology and therapeutics 110(1):132–140</i> 2021 (<a href=\"https://doi.org/10.1002/cpt.2132\">doi:10.1002/cpt.2132</a>) — natural log‐transformed 28‐day seizure rate against pregabalin μg/mL — obtained by sweeping the driver instead of simulating a dose. Model family: emax.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = (library default) drug-free response (baseline)
  Emax  =     -0.924          maximal effect term (Emax, Q323)
  EC50  =       4.69 μg/mL    exposure at half of the maximal effect term (EC50, Q321)
  gamma = (library default) Hill coefficient</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep\">SigmoidEmaxSweep</a>; this model only supplies the numbers. The x axis is one μg/mL of pregabalin per second of simulated time (exposure is in kg/m3): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0   (drug-free)
  exposure = EC50 (4.69 μg/mL)  response -0.462
  exposure -> infinity  response -0.924</pre></body></html>"));
end Pregabalin_Chan2021_PD_lsr28;
