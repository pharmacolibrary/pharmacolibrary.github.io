model Pregabalin_Miller2003_PD_monthly_seizure_frequency
  "emax exposure-response sweep — Miller_2003 :: monthly seizure frequency (monthly seizure frequency)"
  extends Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep(
    E0 = 0,      // [1]
    Emax = -0.8,  // [1; % × 0.01]
    EC50 = 0.000186,  // [kg; mg × 1e-06]
    gamma = 1,
    exposure_per_s = 1e-06);   // 1 mg per second
  // imax_as_negative_emax: Imax (Q323) enters SigmoidEmaxSweep as −Emax
  // defaulted: E0
  // defaulted: gamma
  annotation(experiment(StartTime = 0, StopTime = 1900, Interval = 3.8),
    Documentation(info = "<html><body><!-- drug-about --><h4>About pregabalin</h4><p>Pregabalin is used for epilepsy, anxiety disorders, and various types of neuropathic pain such as neuralgia. It is widely used and authorised in the European Union, where several products remain on the market.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q412174\">Wikidata Q412174</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h4>Pregabalin_Miller2003_PD_monthly_seizure_frequency</h4><p>The steady-state exposure-response curve of Miller R et al., <i>Clinical pharmacology and therapeutics 73(6):491–505</i> 2003 (<a href=\"https://doi.org/10.1016/S0009-9236(03)00049-3\">doi:10.1016/S0009-9236(03)00049-3</a>) — monthly seizure frequency against pregabalin mg — obtained by sweeping the driver instead of simulating a dose. Model family: emax.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = (library default) drug-free response (baseline)
  Emax  =         80 %        maximal effect term (maximal percentage of seizure reduction from baseline, Q323)
  EC50  =        186 mg       exposure at half of the maximal effect term (daily dose decreasing seizures on average to 50% of maximum, Q321)
  gamma = (library default) Hill coefficient</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep\">SigmoidEmaxSweep</a>; this model only supplies the numbers. The x axis is one mg of pregabalin per second of simulated time (exposure is in kg): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0   (drug-free)
  exposure = EC50 (186 mg)  response -0.4
  exposure -> infinity  response -0.8</pre></body></html>"));
end Pregabalin_Miller2003_PD_monthly_seizure_frequency;
