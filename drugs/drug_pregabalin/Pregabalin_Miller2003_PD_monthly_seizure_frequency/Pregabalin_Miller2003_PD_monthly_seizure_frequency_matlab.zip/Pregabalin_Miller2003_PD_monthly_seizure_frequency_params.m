function p = Pregabalin_Miller2003_PD_monthly_seizure_frequency_params()
% Pregabalin_Miller2003_PD_monthly_seizure_frequency_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% pregabalin Miller_2003::monthly_seizure_frequency: emax exposure-response sweep (response = E0 + Emax*frac). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one mg per second, in SI inside (kg/m3, s). Response monthly seizure frequency in its own unit. Driver: pregabalin (dose_only).
p.E0 = 0.0;
p.Emax = -0.8;
p.EC50 = 0.000186;
p.gamma = 1.0;
p.slope = 0.0;
p.exposure_per_s = 1e-06;
p.stop_time = 1900.0;
p.form = 'E0 + Emax*frac';
end
