model TranexamicAcid_Gilliot2022_original_dataset
  parameter Real Cl_ref = 1.2833333333333333e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.00925 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.1572102,
    adminMass = 0.0005,
    k12 = 0.0005765765765765766,
    k21 = 0.0005619950825430278
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>tranexamic_acid</td></tr><tr><td>population:</td><td>parturients undergoing hemorrhagic cesarean delivery</td></tr><tr><td>source_paper:</td><td>Gilliot_2022</td></tr><tr><td>measured_compound:</td><td>tranexamic acid</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>pharmaceutics-14-00578-t004</td></tr><tr><td>input:</td><td>PK_2C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>tranexamic_acid 157.21 g/mol (drugbank)</td></tr></table><h4>Interpretation flags</h4><ul><li>dropped duplicate Q22 ('βCL', value '0.0039') — already have one for this compound</li><li>dropped duplicate Q63 ('βV1', value '1.41') — already have one for this compound</li><li>kept covariate coefficient θpurine=0.54 (covariate purine) — not an ontology parameter</li><li>dropped duplicate Q22 ('ωCL (%)', value '20') — already have one for this compound</li><li>dropped duplicate Q63 ('ωV1 (%)', value '59') — already have one for this compound</li><li>dropped unlinked row (NIL): 'ωQ (%)' — extend the ontology if this is a real PK parameter (source ['pharmaceutics-14-00578-t004:row11:col2'])</li><li>dropped duplicate Q64 ('ωV2 (%)', value '13') — already have one for this compound</li><li>dropped unlinked row (NIL): 'ωpurine (%)' — extend the ontology if this is a real PK parameter (source ['pharmaceutics-14-00578-t004:row13:col2'])</li><li>dropped unlinked row (NIL): 'a1' — extend the ontology if this is a real PK parameter (source ['pharmaceutics-14-00578-t004:row14:col2'])</li><li>dropped unlinked row (NIL): 'b1' — extend the ontology if this is a real PK parameter (source ['pharmaceutics-14-00578-t004:row15:col2'])</li><li>dropped unlinked row (NIL): 'b2' — extend the ontology if this is a real PK parameter (source ['pharmaceutics-14-00578-t004:row16:col2'])</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=tranexamic acid</li><li>population split: 'original dataset' subgroup of Gilliot_2022 (paper reports 9 populations: 01-1-049, 01-1-065, 01-1-070, 01-1-099, 01-1-108, 01-1-119, 01-1-134, 01-1-151, original dataset)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end TranexamicAcid_Gilliot2022_original_dataset;
