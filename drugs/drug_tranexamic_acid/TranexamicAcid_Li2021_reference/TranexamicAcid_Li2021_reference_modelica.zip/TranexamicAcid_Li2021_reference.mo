model TranexamicAcid_Li2021_reference
  parameter Real Cl_ref = 2.6111111111111113e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.0101 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.1572102,
    adminMass = 0.002,
    k12 = 0.0006160616061606161,
    k21 = 0.00044444444444444447
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About tranexamic_acid</h4><p>Tranexamic acid is an antifibrinolytic medicine used to treat or prevent bleeding, including conditions such as subarachnoid hemorrhage and blood coagulation disorders. It is widely used and is included on the WHO list of essential medicines, and it is also being investigated for additional uses.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q418666\">Wikidata Q418666</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>tranexamic_acid</td></tr><tr><td>population:</td><td>pregnant women undergoing caesarean delivery</td></tr><tr><td>source_paper:</td><td>Li_2021</td></tr><tr><td>measured_compound:</td><td>tranexamic acid</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_2C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>tranexamic acid 157.21 g/mol (drugbank); tranexamic_acid 157.21 g/mol (drugbank)</td></tr></table><h4>Interpretation flags</h4><ul><li>dropped PD-category row 'baseline lysis' → Q324 (E0, category G11) — pharmacodynamic parameters belong to scholarpd, not the PK model (source ['Li_2021:abstract'])</li><li>dropped PD-category row 'maximum inhibition' → Q323 (Imax, category G11) — pharmacodynamic parameters belong to scholarpd, not the PK model (source ['Li_2021:abstract'])</li><li>dropped PD-category row 'IC50' → Q322 (IC50, category G11) — pharmacodynamic parameters belong to scholarpd, not the PK model (source ['Li_2021:abstract'])</li><li>dropped PD-category row 'hill factor' → Q325 (Hill, category G11) — pharmacodynamic parameters belong to scholarpd, not the PK model (source ['Li_2021:abstract'])</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=tranexamic acid</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end TranexamicAcid_Li2021_reference;
