model TranexamicAcid_ShakurStill2023_PD_d_dimer
  "indirect_response_i exposure-response sweep — Shakur-Still_2023 :: D-dimer (D-dimer)"
  extends Pharmacolibrary.Interfaces.PartialExposureResponseSweep(
    E0 = 0,      // [1]
    Emax = 1,  // type I effect term
    EC50 = 0.0075,  // [kg/m3; mg/L × 0.001]
    gamma = 1,
    exposure_per_s = 0.001);   // 1 mg/L per second
equation
  response = E0*(1 - Emax*frac);   // steady state, indirect response type I
  // defaulted: E0
  annotation(experiment(StartTime = 0, StopTime = 75, Interval = 0.15),
    Documentation(info = "<html><body><!-- drug-about --><h4>About tranexamic_acid</h4><p>Tranexamic acid is an antifibrinolytic medicine used to treat or prevent bleeding, including conditions such as subarachnoid hemorrhage and blood coagulation disorders. It is widely used and is included on the WHO list of essential medicines, and it is also being investigated for additional uses.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q418666\">Wikidata Q418666</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h4>TranexamicAcid_ShakurStill2023_PD_d_dimer</h4><p>The steady-state exposure-response curve of Shakur-Still H et al., <i>BJOG : an international journal of obstetrics and gynaecology 130(10):1177–1186</i> 2023 (<a href=\"https://doi.org/10.1111/1471-0528.17455\">doi:10.1111/1471-0528.17455</a>) — D-dimer against tranexamic acid mg/L — obtained by sweeping the driver instead of simulating a dose. Model family: indirect_response_i.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = (library default) drug-free response (baseline)
  Emax  =          1          maximal effect term (I max, Q323)
  EC50  =        7.5 mg/L     exposure at half of the maximal effect term (IC 50, Q322)
  gamma =          1          Hill coefficient (γ, Q325)</pre><p>The algebra is <code>response = E0*(1 - Emax*frac)</code>; this model only supplies the numbers. The x axis is one mg/L of tranexamic acid per second of simulated time (exposure is in kg/m3): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0   (drug-free)
  exposure = EC50 (7.5 mg/L)  response 0
  exposure -> infinity  response 0</pre></body></html>"));
end TranexamicAcid_ShakurStill2023_PD_d_dimer;
