function p = TranexamicAcid_ShakurStill2023_PD_d_dimer_params()
% TranexamicAcid_ShakurStill2023_PD_d_dimer_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% tranexamic_acid Shakur-Still_2023::D_dimer: indirect_response_i exposure-response sweep (response = E0*(1 - Emax*frac)). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one mg/L per second, in SI inside (kg/m3, s). Response D-dimer in its own unit. Driver: tranexamic acid (cited_pk).
p.E0 = 0.0;
p.Emax = 1.0;
p.EC50 = 0.007499999999999999;
p.gamma = 1.0;
p.slope = 0.0;
p.exposure_per_s = 0.001;
p.stop_time = 75.0;
p.form = 'E0*(1 - Emax*frac)';
end
