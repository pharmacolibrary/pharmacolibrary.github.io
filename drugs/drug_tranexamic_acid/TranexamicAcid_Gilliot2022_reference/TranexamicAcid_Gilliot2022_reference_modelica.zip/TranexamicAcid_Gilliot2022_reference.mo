model TranexamicAcid_Gilliot2022_reference
  parameter Real Cl_ref = 1.2833333333333333e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.00925 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.1572102,
    adminMass = 0.0005,
    k12 = 0.0005765765765765766,
    k21 = 0.0005619950825430278
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About tranexamic_acid</h4><p>Tranexamic acid is an antifibrinolytic medicine used to treat or prevent bleeding, including conditions such as subarachnoid hemorrhage and blood coagulation disorders. It is widely used and is included on the WHO list of essential medicines, and it is also being investigated for additional uses.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q418666\">Wikidata Q418666</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>tranexamic_acid</td></tr><tr><td>population:</td><td>parturients undergoing hemorrhagic cesarean delivery</td></tr><tr><td>source_paper:</td><td>Gilliot_2022</td></tr><tr><td>measured_compound:</td><td>tranexamic acid</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>pharmaceutics-14-00578-t004</td></tr><tr><td>input:</td><td>PK_2C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>tranexamic acid 157.21 g/mol (drugbank); tranexamic_acid 157.21 g/mol (drugbank)</td></tr></table><h4>Interpretation flags</h4><ul><li>dropped duplicate Q22 ('βCL', value '0.0039') — already have one for this compound</li><li>dropped duplicate Q63 ('βV1', value '1.41') — already have one for this compound</li><li>kept covariate coefficient θpurine=0.54 (covariate purine) — not an ontology parameter</li><li>dropped unlinked row (NIL): 'a1' — extend the ontology if this is a real PK parameter (source ['pharmaceutics-14-00578-t004:row14:col2', 'pharmaceutics-14-00578-t004:row14:col4'])</li><li>dropped unlinked row (NIL): 'b1' — extend the ontology if this is a real PK parameter (source ['pharmaceutics-14-00578-t004:row15:col2', 'pharmaceutics-14-00578-t004:row15:col4'])</li><li>dropped unlinked row (NIL): 'b2' — extend the ontology if this is a real PK parameter (source ['pharmaceutics-14-00578-t004:row16:col2', 'pharmaceutics-14-00578-t004:row16:col4'])</li><li>dropped duplicate Q22 ('CL', value '0.19') — already have one for this compound</li><li>dropped duplicate Q63 ('V1', value '25.34') — already have one for this compound</li><li>dropped duplicate Q64 ('V2', value '0.31') — already have one for this compound</li><li>dropped duplicate Q30 ('Q', value '9.61') — already have one for this compound</li><li>dropped unlinked row (NIL): 'Purine' — extend the ontology if this is a real PK parameter (source ['Gilliot_2022_table_8:row4:col2', 'Gilliot_2022_table_8:row4:col3', 'Gilliot_2022_table_8:row4:col4', 'Gilliot_2022_table_8:row4:col5', 'Gilliot_2022_table_8:row4:col6', 'Gilliot_2022_table_8:row4:col7', 'Gilliot_2022_table_8:row4:col8', 'Gilliot_2022_table_8:row4:col9'])</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=tranexamic acid</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end TranexamicAcid_Gilliot2022_reference;
