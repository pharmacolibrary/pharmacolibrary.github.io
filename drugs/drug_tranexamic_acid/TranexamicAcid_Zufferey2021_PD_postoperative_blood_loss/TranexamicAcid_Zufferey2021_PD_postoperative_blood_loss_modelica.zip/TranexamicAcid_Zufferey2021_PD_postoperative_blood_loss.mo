model TranexamicAcid_Zufferey2021_PD_postoperative_blood_loss
  "emax exposure-response sweep — Zufferey_2021 :: postoperative blood loss (postoperative blood loss)"
  extends Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep(
    E0 = 0,      // [1]
    Emax = -0.4,  // [1; % × 0.01]
    EC50 = 0.0056,  // [kg/m3; mg/l × 0.001]
    gamma = 1,
    exposure_per_s = 0.001);   // 1 mg/l per second
  // imax_as_negative_emax: Imax (Q323) enters SigmoidEmaxSweep as −Emax
  // defaulted: E0
  // defaulted: gamma
  annotation(experiment(StartTime = 0, StopTime = 56, Interval = 0.112),
    Documentation(info = "<html><body><!-- drug-about --><h4>About tranexamic_acid</h4><p>Tranexamic acid is an antifibrinolytic medicine used to treat or prevent bleeding, including conditions such as subarachnoid hemorrhage and blood coagulation disorders. It is widely used and is included on the WHO list of essential medicines, and it is also being investigated for additional uses.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q418666\">Wikidata Q418666</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h4>TranexamicAcid_Zufferey2021_PD_postoperative_blood_loss</h4><p>The steady-state exposure-response curve of Zufferey PJ et al., <i>Anesthesiology 134(2):165–178</i> 2021 (<a href=\"https://doi.org/10.1097/ALN.0000000000003633\">doi:10.1097/ALN.0000000000003633</a>) — postoperative blood loss against tranexamic acid mg/l — obtained by sweeping the driver instead of simulating a dose. Model family: emax.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = (library default) drug-free response (baseline)
  Emax  =         40 %        maximal effect term (maximum effect, Q323)
  EC50  =        5.6 mg/l     exposure at half of the maximal effect term (EC50, Q321)
  gamma = (library default) Hill coefficient</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep\">SigmoidEmaxSweep</a>; this model only supplies the numbers. The x axis is one mg/l of tranexamic acid per second of simulated time (exposure is in kg/m3): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0   (drug-free)
  exposure = EC50 (5.6 mg/l)  response -0.2
  exposure -> infinity  response -0.4</pre></body></html>"));
end TranexamicAcid_Zufferey2021_PD_postoperative_blood_loss;
