% run_TranexamicAcid_Zufferey2021_PD_postoperative_blood_loss  Evaluate the exposure-response curve and plot response against exposure.
% A sweep is a static map: no ODE solver is needed. exposure runs 0..stop_time*exposure_per_s.
p = TranexamicAcid_Zufferey2021_PD_postoperative_blood_loss_params();
exposure = linspace(0, p.stop_time * p.exposure_per_s, 501);
frac = exposure.^p.gamma ./ (p.EC50^p.gamma + exposure.^p.gamma);
E0 = p.E0; Emax = p.Emax; slope = p.slope;
response = E0 + Emax.*frac;
figure; plot(exposure, response, 'LineWidth', 1.5); grid on;
xlabel('exposure [mg/l]'); ylabel('response []'); title('TranexamicAcid_Zufferey2021_PD_postoperative_blood_loss', 'Interpreter', 'none');
writematrix([exposure(:) response(:)], 'TranexamicAcid_Zufferey2021_PD_postoperative_blood_loss.csv');
