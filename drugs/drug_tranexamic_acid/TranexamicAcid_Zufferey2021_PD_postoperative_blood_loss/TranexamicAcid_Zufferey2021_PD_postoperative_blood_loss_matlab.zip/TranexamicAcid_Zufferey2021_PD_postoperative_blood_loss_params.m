function p = TranexamicAcid_Zufferey2021_PD_postoperative_blood_loss_params()
% TranexamicAcid_Zufferey2021_PD_postoperative_blood_loss_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% tranexamic_acid Zufferey_2021::postoperative_blood_loss: emax exposure-response sweep (response = E0 + Emax*frac). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one mg/l per second, in SI inside (kg/m3, s). Response postoperative blood loss in its own unit. Driver: tranexamic acid (cited_pk).
p.E0 = 0.0;
p.Emax = -0.4;
p.EC50 = 0.005599999999999998;
p.gamma = 1.0;
p.slope = 0.0;
p.exposure_per_s = 0.001;
p.stop_time = 56.0;
p.form = 'E0 + Emax*frac';
end
