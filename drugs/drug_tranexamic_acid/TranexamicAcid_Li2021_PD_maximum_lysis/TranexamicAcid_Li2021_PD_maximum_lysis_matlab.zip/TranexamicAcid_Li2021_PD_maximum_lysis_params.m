function p = TranexamicAcid_Li2021_PD_maximum_lysis_params()
% TranexamicAcid_Li2021_PD_maximum_lysis_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% tranexamic_acid Li_2021::maximum_lysis: sigmoid_emax exposure-response sweep (response = E0 + Emax*frac). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one mg/L per second, in SI inside (kg/m3, s). Response maximum lysis in %. Driver: tranexamic acid (pk_record).
p.E0 = 0.97;
p.Emax = -0.89;
p.EC50 = 0.005999999999999998;
p.gamma = 8.5;
p.slope = 0.0;
p.exposure_per_s = 0.001;
p.stop_time = 60.0;
p.form = 'E0 + Emax*frac';
end
