model TranexamicAcid_Li2021_PD_maximum_lysis
  "sigmoid_emax exposure-response sweep — Li_2021 :: maximum lysis (maximum lysis)"
  extends Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep(
    E0 = 0.97,      // [1; % × 0.01]
    Emax = -0.89,  // [1; % × 0.01]
    EC50 = 0.006,  // [kg/m3; mg/L × 0.001]
    gamma = 8.5,
    exposure_per_s = 0.001);   // 1 mg/L per second
  // imax_as_negative_emax: Imax (Q323) enters SigmoidEmaxSweep as −Emax
  annotation(experiment(StartTime = 0, StopTime = 60, Interval = 0.12),
    Documentation(info = "<html><body><!-- drug-about --><h4>About tranexamic_acid</h4><p>Tranexamic acid is an antifibrinolytic medicine used to treat or prevent bleeding, including conditions such as subarachnoid hemorrhage and blood coagulation disorders. It is widely used and is included on the WHO list of essential medicines, and it is also being investigated for additional uses.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q418666\">Wikidata Q418666</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h4>TranexamicAcid_Li2021_PD_maximum_lysis</h4><p>The steady-state exposure-response curve of Li S et al., <i>British journal of clinical pharmacology 87(9):3531–3541</i> 2021 (<a href=\"https://doi.org/10.1111/bcp.14767\">doi:10.1111/bcp.14767</a>) — maximum lysis [%] against tranexamic acid mg/L — obtained by sweeping the driver instead of simulating a dose. Model family: sigmoid_emax.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    =         97 %        drug-free response (baseline) (baseline lysis, Q324)
  Emax  =         89 %        maximal effect term (maximum inhibition, Q323)
  EC50  =          6 mg/L     exposure at half of the maximal effect term (IC50, Q322)
  gamma =        8.5          Hill coefficient (hill factor, Q325)</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep\">SigmoidEmaxSweep</a>; this model only supplies the numbers. The x axis is one mg/L of tranexamic acid per second of simulated time (exposure is in kg/m3): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0.97   (drug-free)
  exposure = EC50 (6 mg/L)  response 0.525
  exposure -> infinity  response 0.08</pre></body></html>"));
end TranexamicAcid_Li2021_PD_maximum_lysis;
