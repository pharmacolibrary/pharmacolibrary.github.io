model Famotidine_Ikawa2007_PD_dph
  "sigmoid_emax exposure-response sweep — Ikawa_2007 :: DpH (DpH)"
  extends Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep(
    E0 = 0,      // [1]
    Emax = 2.493,  // [1]
    EC50 = 4.638e-05,  // [kg/m3; ng/ml × 1e-06]
    gamma = 3.182,
    exposure_per_s = 1e-06);   // 1 ng/ml per second
  // defaulted: E0
  annotation(experiment(StartTime = 0, StopTime = 470, Interval = 0.94),
    Documentation(info = "<html><body><h4>Famotidine_Ikawa2007_PD_dph</h4><p>The steady-state exposure-response curve of Ikawa K et al., <i>Biological &amp; pharmaceutical bulletin 30(5):1003–1006</i> 2007 (<a href=\"https://doi.org/10.1248/bpb.30.1003\">doi:10.1248/bpb.30.1003</a>) — DpH against famotidine ng/ml — obtained by sweeping the driver instead of simulating a dose. Model family: sigmoid_emax.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = (library default) drug-free response (baseline)
  Emax  =      2.493          maximal effect term (E max, Q320)
  EC50  =      46.38 ng/ml    exposure at half of the maximal effect term (EC 50, Q321)
  gamma =      3.182          Hill coefficient (g, Q325)</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep\">SigmoidEmaxSweep</a>; this model only supplies the numbers. The x axis is one ng/ml of famotidine per second of simulated time (exposure is in kg/m3): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0   (drug-free)
  exposure = EC50 (46.38 ng/ml)  response 1.246
  exposure -> infinity  response 2.493</pre></body></html>"));
end Famotidine_Ikawa2007_PD_dph;
