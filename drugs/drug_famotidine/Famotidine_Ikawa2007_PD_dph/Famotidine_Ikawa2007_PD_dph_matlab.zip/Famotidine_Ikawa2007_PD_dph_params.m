function p = Famotidine_Ikawa2007_PD_dph_params()
% Famotidine_Ikawa2007_PD_dph_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% famotidine Ikawa_2007::DpH: sigmoid_emax exposure-response sweep (response = E0 + Emax*frac). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one ng/ml per second, in SI inside (kg/m3, s). Response DpH in its own unit. Driver: famotidine (pk_record).
p.E0 = 0.0;
p.Emax = 2.493;
p.EC50 = 4.638e-05;
p.gamma = 3.182;
p.slope = 0.0;
p.exposure_per_s = 1e-06;
p.stop_time = 470.0;
p.form = 'E0 + Emax*frac';
end
