function p = MagnesiumDifferentSaltsInCombination_Deng2024_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: magnesium_different_salts_in_combination   source: Deng_2024 / reference   route: iv_bolus
  % estimated (absent from source): F, dose
  p.name  = 'MagnesiumDifferentSaltsInCombination_Deng2024_reference_params';
  p.drug  = 'magnesium_different_salts_in_combination';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'iv_bolus';        % 'oral' | 'iv_bolus'
  p.depot = false;             % oral -> first-order absorption depot
  p.Vc = 25.07;                % central volume [L]
  p.CL = 2.98;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.0;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 10.0;             % dose [mg]
end
