model MagnesiumDifferentSaltsInCombination_da2020_reference
  parameter Real Cl_ref = 3.833333333333333e-07 "Cl [m3/s]";
  parameter Real Vd_ref = 0.013300000000000001 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    adminMass = 0.001
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>magnesium_different_salts_in_combination</td></tr><tr><td>population:</td><td>review reference</td></tr><tr><td>source_paper:</td><td>da_2020</td></tr><tr><td>measured_compound:</td><td>magnesium_different_salts_in_combination</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C: IV (no input phase)</td></tr></table><h4>Interpretation flags</h4><ul><li>built from REVIEW reference values (da_2020) — secondary source</li><li>volume reported by review</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 122400, Tolerance = 1e-9, Interval = 1));
end MagnesiumDifferentSaltsInCombination_da2020_reference;
