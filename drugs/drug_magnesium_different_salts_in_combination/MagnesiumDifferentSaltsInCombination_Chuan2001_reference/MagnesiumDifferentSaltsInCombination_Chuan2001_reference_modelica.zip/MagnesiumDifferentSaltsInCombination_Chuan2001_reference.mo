model MagnesiumDifferentSaltsInCombination_Chuan2001_reference
  parameter Real Cl_ref = 1.188888888888889e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.032299999999999995 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    adminMass = 1e-05
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>magnesium_different_salts_in_combination</td></tr><tr><td>population:</td><td>patients with preeclampsia</td></tr><tr><td>source_paper:</td><td>Chuan_2001</td></tr><tr><td>measured_compound:</td><td>magnesium</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C: IV (no input phase)</td></tr></table><h4>Interpretation flags</h4><ul><li>dropped PD-category row 'baseline concentration' → Q324 (E0, category G11) — pharmacodynamic parameters belong to scholarpd, not the PK model (source ['Chuan_2001:abstract'])</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=magnesium</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li><li>review gap-fill skipped: this record measures 'magnesium', not magnesium_different_salts_in_combination — the review values are the parent's</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 93600, Tolerance = 1e-9, Interval = 1));
end MagnesiumDifferentSaltsInCombination_Chuan2001_reference;
