function p = Rivaroxaban_Esmaeili2022_PD_anti_fxa_params()
% Rivaroxaban_Esmaeili2022_PD_anti_fxa_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% rivaroxaban Esmaeili_2022::anti_FXa: sigmoid_emax exposure-response sweep (response = E0 + Emax*frac). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one ng·ml-1 per second, in SI inside (kg/m3, s). Response anti-FXa in IU·ml-1. Driver: rivaroxaban (pk_record).
p.E0 = 0.0;
p.Emax = -4.0;
p.EC50 = 0.00017999999999999998;
p.gamma = 1.44;
p.slope = 0.0;
p.exposure_per_s = 1e-06;
p.stop_time = 1800.0;
p.form = 'E0 + Emax*frac';
end
