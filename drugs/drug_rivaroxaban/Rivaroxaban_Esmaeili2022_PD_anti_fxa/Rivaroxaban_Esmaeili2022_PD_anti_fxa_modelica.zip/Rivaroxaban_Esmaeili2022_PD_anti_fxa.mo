model Rivaroxaban_Esmaeili2022_PD_anti_fxa
  "sigmoid_emax exposure-response sweep — Esmaeili_2022 :: anti-FXa (anti-factor Xa activity)"
  extends Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep(
    E0 = 0,      // [1]
    Emax = -4,  // [IU·ml-1]
    EC50 = 0.00018,  // [kg/m3; ng·ml-1 × 1e-06]
    gamma = 1.44,
    exposure_per_s = 1e-06);   // 1 ng·ml-1 per second
  // imax_as_negative_emax: Imax (Q323) enters SigmoidEmaxSweep as −Emax
  // defaulted: E0
  annotation(experiment(StartTime = 0, StopTime = 1800, Interval = 3.6),
    Documentation(info = "<html><body><!-- drug-about --><h4>About rivaroxaban</h4><p>Rivaroxaban is an anticoagulant that directly inhibits factor Xa and is used to prevent and treat blood clots, including venous thromboembolism, pulmonary embolism, and stroke prevention in atrial fibrillation. It is widely used and authorised in the European Union, with several approved products on the market.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q420262\">Wikidata Q420262</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h4>Rivaroxaban_Esmaeili2022_PD_anti_fxa</h4><p>The steady-state exposure-response curve of Esmaeili T et al., <i>Journal of clinical pharmacy and therapeutics 47(8):1284–1292</i> 2022 (<a href=\"https://doi.org/10.1111/jcpt.13673\">doi:10.1111/jcpt.13673</a>) — anti-factor Xa activity [IU·ml-1] against rivaroxaban ng·ml-1 — obtained by sweeping the driver instead of simulating a dose. Model family: sigmoid_emax.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = (library default) drug-free response (baseline)
  Emax  =          4 IU·ml-1  maximal effect term (Emax, Q323)
  EC50  =        180 ng·ml-1  exposure at half of the maximal effect term (EC50, Q322)
  gamma =       1.44          Hill coefficient (Hill coefficient, Q325)</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep\">SigmoidEmaxSweep</a>; this model only supplies the numbers. The x axis is one ng·ml-1 of rivaroxaban per second of simulated time (exposure is in kg/m3): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0   (drug-free)
  exposure = EC50 (180 ng·ml-1)  response -2
  exposure -> infinity  response -4</pre></body></html>"));
end Rivaroxaban_Esmaeili2022_PD_anti_fxa;
