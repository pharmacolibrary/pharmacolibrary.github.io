function p = Rivaroxaban_Esmaeili2022_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: rivaroxaban   source: Esmaeili_2022 / reference   route: oral
  % estimated (absent from source): F
  p.name  = 'Rivaroxaban_Esmaeili2022_reference_params';
  p.drug  = 'rivaroxaban';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 61.2;                % central volume [L]
  p.CL = 3.68;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.821;                % absorption rate [1/h]
  p.F  = 0.9;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 20.0;             % dose [mg]
end
