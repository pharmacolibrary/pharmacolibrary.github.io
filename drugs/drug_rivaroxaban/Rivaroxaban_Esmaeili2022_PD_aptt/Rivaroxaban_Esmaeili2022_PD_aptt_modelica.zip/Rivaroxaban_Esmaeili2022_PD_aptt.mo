model Rivaroxaban_Esmaeili2022_PD_aptt
  "linear exposure-response sweep — Esmaeili_2022 :: aPTT (activated partial thromboplastin time)"
  extends Pharmacolibrary.Interfaces.PartialExposureResponseSweep(
    E0 = 35,      // [s; seconds × 1]
    Emax = 0, EC50 = 1,      // unused by a line
    exposure_per_s = 1e-06);
  parameter Real slope = 33000   "[meter ** 3 * second / kilogram; s·ml·ng-1 × 1e+06]";
equation
  response = E0 + slope*exposure;
  annotation(experiment(StartTime = 0, StopTime = 1000, Interval = 2),
    Documentation(info = "<html><body><!-- drug-about --><h4>About rivaroxaban</h4><p>Rivaroxaban is an anticoagulant that directly inhibits factor Xa and is used to prevent and treat blood clots, including venous thromboembolism, pulmonary embolism, and stroke prevention in atrial fibrillation. It is widely used and authorised in the European Union, with several approved products on the market.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q420262\">Wikidata Q420262</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h4>Rivaroxaban_Esmaeili2022_PD_aptt</h4><p>The steady-state exposure-response curve of Esmaeili T et al., <i>Journal of clinical pharmacy and therapeutics 47(8):1284–1292</i> 2022 (<a href=\"https://doi.org/10.1111/jcpt.13673\">doi:10.1111/jcpt.13673</a>) — activated partial thromboplastin time [seconds] against rivaroxaban ng·ml-1 — obtained by sweeping the driver instead of simulating a dose. Model family: linear.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    =         35 seconds  drug-free response (baseline) (baseline, Q324)
  slope =      0.033 s·ml·ng-1 change in response per unit of exposure (slope, Q335)</pre><p>The algebra is <code>response = E0 + slope*exposure</code>; this model only supplies the numbers. The x axis is one ng·ml-1 of rivaroxaban per second of simulated time (exposure is in kg/m3): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 35   (drug-free)</pre></body></html>"));
end Rivaroxaban_Esmaeili2022_PD_aptt;
