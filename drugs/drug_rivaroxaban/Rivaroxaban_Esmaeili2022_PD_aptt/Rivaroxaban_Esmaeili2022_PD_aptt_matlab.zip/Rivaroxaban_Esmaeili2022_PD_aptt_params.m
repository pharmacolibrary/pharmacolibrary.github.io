function p = Rivaroxaban_Esmaeili2022_PD_aptt_params()
% Rivaroxaban_Esmaeili2022_PD_aptt_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% rivaroxaban Esmaeili_2022::aPTT: linear exposure-response sweep (response = E0 + slope*exposure). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one ng·ml-1 per second, in SI inside (kg/m3, s). Response aPTT in seconds. Driver: rivaroxaban (pk_record).
p.E0 = 35.0;
p.Emax = 0.0;
p.EC50 = 1.0;
p.gamma = 1.0;
p.slope = 33000.00000000001;
p.exposure_per_s = 1e-06;
p.stop_time = 1000.0;
p.form = 'E0 + slope*exposure';
end
