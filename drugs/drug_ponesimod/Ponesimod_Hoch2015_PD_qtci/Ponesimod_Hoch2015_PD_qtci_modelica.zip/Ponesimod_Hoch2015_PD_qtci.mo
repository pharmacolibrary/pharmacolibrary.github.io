model Ponesimod_Hoch2015_PD_qtci
  "linear exposure-response sweep — Hoch_2015 :: QTcI (QTcI)"
  extends Pharmacolibrary.Interfaces.PartialExposureResponseSweep(
    E0 = 0,      // [1]
    Emax = 0, EC50 = 1,      // unused by a line
    exposure_per_s = 1e-06);
  parameter Real slope = 0.0053   "[ms per ng/mL]";
equation
  response = E0 + slope*exposure;
  // defaulted: E0
  annotation(experiment(StartTime = 0, StopTime = 1000, Interval = 2),
    Documentation(info = "<html><body><!-- drug-about --><h4>About ponesimod</h4><p>Ponesimod is an immunosuppressant used to treat relapsing-remitting multiple sclerosis. It is authorised in the European Union.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q18604129\">Wikidata Q18604129</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h4>Ponesimod_Hoch2015_PD_qtci</h4><p>The steady-state exposure-response curve of Hoch M et al., <i>Basic &amp; clinical pharmacology &amp; toxicology 116(5):429–437</i> 2015 (<a href=\"https://doi.org/10.1111/bcpt.12336\">doi:10.1111/bcpt.12336</a>) — QTcI [ms] against ponesimod ng/mL — obtained by sweeping the driver instead of simulating a dose. Model family: linear.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = (library default) drug-free response (baseline)
  slope =     0.0053 ms per ng/mL change in response per unit of exposure (slope, Q335)</pre><p>The algebra is <code>response = E0 + slope*exposure</code>; this model only supplies the numbers. The x axis is one ng/mL of ponesimod per second of simulated time (exposure is in kg/m3): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0   (drug-free)</pre></body></html>"));
end Ponesimod_Hoch2015_PD_qtci;
