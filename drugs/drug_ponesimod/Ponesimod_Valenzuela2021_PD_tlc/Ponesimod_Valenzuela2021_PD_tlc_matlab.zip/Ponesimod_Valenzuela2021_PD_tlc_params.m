function p = Ponesimod_Valenzuela2021_PD_tlc_params()
% Ponesimod_Valenzuela2021_PD_tlc_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% ponesimod Valenzuela_2021::TLC: indirect_response_i exposure-response sweep (response = E0/(1 + Emax*frac)). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one ng/mL per second, in SI inside (kg/m3, s). Response TLC in its own unit. Driver: ponesimod (pk_record).
p.E0 = 0.0;
p.Emax = 88.0;
p.EC50 = 5.489999999999999e-05;
p.gamma = 1.0;
p.slope = 0.0;
p.exposure_per_s = 1e-06;
p.stop_time = 550.0;
p.form = 'E0/(1 + Emax*frac)';
end
