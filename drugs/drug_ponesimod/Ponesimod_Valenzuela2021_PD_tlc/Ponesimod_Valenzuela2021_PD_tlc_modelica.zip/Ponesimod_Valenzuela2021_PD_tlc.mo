model Ponesimod_Valenzuela2021_PD_tlc
  "indirect_response_i exposure-response sweep — Valenzuela_2021 :: TLC (total lymphocyte counts)"
  extends Pharmacolibrary.Pharmacodynamic.IndirectTurnoverSweep(
    E0 = 0,      // [1]
    Emax = 88,  // type IV effect term
    EC50 = 5.49e-05,  // [kg/m3; ng/mL × 1e-06]
    gamma = 1,
    exposure_per_s = 1e-06);   // 1 ng/mL per second
  // emax_not_a_fraction: type I needs Imax ≤ 1 but the record has 88; bound as the reciprocal stimulation form (IV) the paper fitted
  // defaulted: E0
  // defaulted: gamma
  annotation(experiment(StartTime = 0, StopTime = 550, Interval = 1.1),
    Documentation(info = "<html><body><!-- drug-about --><h4>About ponesimod</h4><p>Ponesimod is an immunosuppressant used to treat relapsing-remitting multiple sclerosis. It is authorised in the European Union.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q18604129\">Wikidata Q18604129</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h4>Ponesimod_Valenzuela2021_PD_tlc</h4><p>The steady-state exposure-response curve of Valenzuela B et al., <i>Clinical pharmacokinetics 60(9):1239–1250</i> 2021 (<a href=\"https://doi.org/10.1007/s40262-021-01019-9\">doi:10.1007/s40262-021-01019-9</a>) — total lymphocyte counts against ponesimod ng/mL — obtained by sweeping the driver instead of simulating a dose. Model family: indirect_response_i.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = (library default) drug-free response (baseline)
  Emax  =         88          maximal effect term (maximum reduction, Q323)
  EC50  =       54.9 ng/mL    exposure at half of the maximal effect term (half maximal inhibitory concentration, Q322)
  gamma = (library default) Hill coefficient</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.IndirectTurnoverSweep\">IndirectTurnoverSweep</a>; this model only supplies the numbers. The x axis is one ng/mL of ponesimod per second of simulated time (exposure is in kg/m3): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><p>The effect term enters as a reciprocal (steady state of <code>der(R) = Kin - Kout*(1 + Emax*frac)*R</code>), so EC50 is the exposure at half the maximal STIMULATION of turnover, not at half the response.</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0   (drug-free)
  exposure = EC50 (54.9 ng/mL)  response 0
  exposure -> infinity  response 0</pre></body></html>"));
end Ponesimod_Valenzuela2021_PD_tlc;
