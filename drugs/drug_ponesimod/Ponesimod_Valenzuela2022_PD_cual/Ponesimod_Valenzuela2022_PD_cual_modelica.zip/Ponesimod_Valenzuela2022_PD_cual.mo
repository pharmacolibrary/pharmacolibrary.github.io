model Ponesimod_Valenzuela2022_PD_cual
  "log_linear exposure-response sweep — Valenzuela_2022 :: CUAL (Combined unique active lesions)"
  extends Pharmacolibrary.Interfaces.PartialExposureResponseSweep(
    E0 = 0,      // [1]
    Emax = 0, EC50 = 1,      // unused by a line
    exposure_per_s = 1);
  parameter Real slope = -0.7   "[1]";
equation
  response = E0 + slope*log(exposure);
  // defaulted: E0
  annotation(experiment(StartTime = 0, StopTime = 1000, Interval = 2),
    Documentation(info = "<html><body><!-- drug-about --><h4>About ponesimod</h4><p>Ponesimod is an immunosuppressant used to treat relapsing-remitting multiple sclerosis. It is authorised in the European Union.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q18604129\">Wikidata Q18604129</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h4>Ponesimod_Valenzuela2022_PD_cual</h4><p>The steady-state exposure-response curve of Valenzuela B et al., <i>CPT: pharmacometrics &amp; systems pharmacology 11(10):1294–1304</i> 2022 (<a href=\"https://doi.org/10.1002/psp4.12778\">doi:10.1002/psp4.12778</a>) — Combined unique active lesions [lesions/year] against Ponesimod ng·h/ml — obtained by sweeping the driver instead of simulating a dose. Model family: log_linear.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = (library default) drug-free response (baseline)
  slope =       -0.7          change in response per unit of exposure (Log AUCSS slope, Q335)</pre><p>The algebra is <code>response = E0 + slope*log(exposure)</code>; this model only supplies the numbers. The x axis is one ng·h/ml of Ponesimod per second of simulated time: there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p></body></html>"));
end Ponesimod_Valenzuela2022_PD_cual;
