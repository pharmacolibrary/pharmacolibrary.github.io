% run_Ponesimod_Valenzuela2022_PD_cual  Evaluate the exposure-response curve and plot response against exposure.
% A sweep is a static map: no ODE solver is needed. exposure runs 0..stop_time*exposure_per_s.
p = Ponesimod_Valenzuela2022_PD_cual_params();
exposure = linspace(0, p.stop_time * p.exposure_per_s, 501);
frac = exposure.^p.gamma ./ (p.EC50^p.gamma + exposure.^p.gamma);
E0 = p.E0; Emax = p.Emax; slope = p.slope;
response = E0 + slope.*log(exposure);
figure; plot(exposure, response, 'LineWidth', 1.5); grid on;
xlabel('exposure [ng·h/ml]'); ylabel('response [lesions/year]'); title('Ponesimod_Valenzuela2022_PD_cual', 'Interpreter', 'none');
writematrix([exposure(:) response(:)], 'Ponesimod_Valenzuela2022_PD_cual.csv');
