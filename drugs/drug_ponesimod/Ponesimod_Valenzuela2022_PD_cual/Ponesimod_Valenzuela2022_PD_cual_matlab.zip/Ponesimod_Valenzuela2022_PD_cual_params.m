function p = Ponesimod_Valenzuela2022_PD_cual_params()
% Ponesimod_Valenzuela2022_PD_cual_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% ponesimod Valenzuela_2022::CUAL: log_linear exposure-response sweep (response = E0 + slope*log(exposure)). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one ng·h/ml per second, in SI inside (kg/m3, s). Response CUAL in lesions/year. Driver: Ponesimod (cited_pk).
p.E0 = 0.0;
p.Emax = 0.0;
p.EC50 = 1.0;
p.gamma = 1.0;
p.slope = -0.7;
p.exposure_per_s = 1.0;
p.stop_time = 1000.0;
p.form = 'E0 + slope*log(exposure)';
end
