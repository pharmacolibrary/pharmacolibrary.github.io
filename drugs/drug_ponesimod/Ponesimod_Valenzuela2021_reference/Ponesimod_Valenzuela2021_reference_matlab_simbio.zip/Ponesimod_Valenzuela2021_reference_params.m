function p = Ponesimod_Valenzuela2021_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: ponesimod   source: Valenzuela_2021 / reference   route: oral
  % estimated (absent from source): ka
  % Vc is the record's Vss — no central volume was reported; 1-compartment reading
  p.name  = 'Ponesimod_Valenzuela2021_reference_params';
  p.drug  = 'ponesimod';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 239.0;                % central volume [L]
  p.CL = 5.52;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.5;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 20.0;             % dose [mg]
end
