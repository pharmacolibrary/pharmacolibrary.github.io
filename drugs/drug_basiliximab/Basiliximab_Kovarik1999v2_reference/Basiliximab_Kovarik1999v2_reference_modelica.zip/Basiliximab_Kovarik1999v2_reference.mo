model Basiliximab_Kovarik1999v2_reference
  parameter Real Cl_ref = 9.166666666666666e-09 "Cl [m3/s]";
  parameter Real Vd_ref = 0.0075 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    adminMass = 4e-05
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About basiliximab</h4><p>Basiliximab is an immunosuppressive monoclonal antibody used to prevent graft rejection in kidney transplantation. It is authorised in the European Union and used in transplant medicine, though it carries a boxed warning.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q418702\">Wikidata Q418702</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>basiliximab</td></tr><tr><td>population:</td><td>renal transplant patients</td></tr><tr><td>source_paper:</td><td>Kovarik_1999_2</td></tr><tr><td>measured_compound:</td><td>basiliximab</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C: IV (no input phase)</td></tr></table><h4>Interpretation flags</h4><ul><li>dropped unlinked row (NIL): '32 +/- 11 versus 45 +/- 26 d, respectively' — extend the ontology if this is a real PK parameter (source ['Kovarik_1999_2:abstract'])</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=basiliximab</li><li>molar mass: none found for 'basiliximab' — its concentrations stay mass-only</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 3628800, Tolerance = 1e-9, Interval = 1));
end Basiliximab_Kovarik1999v2_reference;
