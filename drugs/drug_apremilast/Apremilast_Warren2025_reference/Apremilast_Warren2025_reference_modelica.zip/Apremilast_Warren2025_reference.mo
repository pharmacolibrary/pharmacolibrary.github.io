model Apremilast_Warren2025_reference
  parameter Real Cl_ref = 2.572222222222222e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.11800000000000001 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.4605,
    adminMass = 2e-05,
    ka = 0.0005111111111111112,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About apremilast</h4><p>Apremilast is an immunosuppressant used to treat inflammatory conditions such as psoriasis, psoriatic arthritis, and Behçet's disease. It is an approved medicine, authorised in the European Union, and is also being investigated for other uses.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q2858961\">Wikidata Q2858961</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>apremilast</td></tr><tr><td>population:</td><td>atopic dermatitis patients</td></tr><tr><td>source_paper:</td><td>Warren_2025</td></tr><tr><td>measured_compound:</td><td>apremilast</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>Tab1</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>apremilast 460.5 g/mol (drugbank)</td></tr></table><p><b>Defaulted (base-class default used):</b> Tlag.</p><h4>Interpretation flags</h4><ul><li>implicit units: 'Ka (1/h)' → 1/h (from the paper text: &quot;Table 1 lists the parameter as 'Ka (1/h)' with a value of 1.84, and the table footnote explicitly defines 'Ka = absorpti&quot;)</li><li>apparent-ness (ontology-grounded): parameterization=apparent, measured_compound=apremilast</li><li>1C volume normalization: Q290→Q76 (single-compartment model has no central/peripheral split; 'Vc/F (l)' is the general volume)</li><li>gap-filled Q27 (CL/F) from Warren_2025's review values (primary lacked it)</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of TLAG: primary's parameterization (rate-constant / ka-only) does not use it</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 165600, Tolerance = 1e-9, Interval = 1));
end Apremilast_Warren2025_reference;
