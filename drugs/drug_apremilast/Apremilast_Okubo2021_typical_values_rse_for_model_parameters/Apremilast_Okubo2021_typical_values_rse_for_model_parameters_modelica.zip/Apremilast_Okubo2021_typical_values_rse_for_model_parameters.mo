model Apremilast_Okubo2021_typical_values_rse_for_model_parameters
  parameter Real Cl_ref = 2.5694444444444443e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.115 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.4605,
    adminMass = 1e-05,
    ka = 0.0005083333333333334,
    Tlag = 1044.0
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About apremilast</h4><p>Apremilast is an immunosuppressant used to treat inflammatory conditions such as psoriasis, psoriatic arthritis, and Behçet's disease. It is an approved medicine, authorised in the European Union, and is also being investigated for other uses.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q2858961\">Wikidata Q2858961</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>apremilast</td></tr><tr><td>population:</td><td>subjects with moderate to severe psoriasis</td></tr><tr><td>source_paper:</td><td>Okubo_2021</td></tr><tr><td>measured_compound:</td><td>apremilast</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>jde16068-tbl-0004</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>apremilast 460.5 g/mol (drugbank)</td></tr></table><h4>Interpretation flags</h4><ul><li>dropped unlinked row (NIL): 'Disease status: psoriasis a' — extend the ontology if this is a real PK parameter (source ['jde16068-tbl-0004:row2:col1'])</li><li>dropped unlinked row (NIL): 'Sex: male b' — extend the ontology if this is a real PK parameter (source ['jde16068-tbl-0004:row3:col1'])</li><li>dropped unlinked row (NIL): 'Race: Japanese c' — extend the ontology if this is a real PK parameter (source ['jde16068-tbl-0004:row4:col1'])</li><li>dropped unlinked row (NIL): 'Age d' — extend the ontology if this is a real PK parameter (source ['jde16068-tbl-0004:row5:col1'])</li><li>dropped unlinked row (NIL): 'Bodyweight, kg e' — extend the ontology if this is a real PK parameter (source ['jde16068-tbl-0004:row7:col1'])</li><li>NIL: refused to back-fill base 'CL/F' from footnote/prose loose number 0.834 (source ['jde16068-tbl-0004:footnote', 'jde16068-tbl-0004:footnote', 'jde16068-tbl-0004:footnote', 'jde16068-tbl-0004:footnote']); the table cell was unparseable — needs review</li><li>NIL: refused to back-fill base 'V1/F' from footnote/prose loose number None (source ['jde16068-tbl-0004:footnote']); the table cell was unparseable — needs review</li><li>apparent-ness (ontology-grounded): parameterization=apparent, measured_compound=apremilast</li><li>1C volume normalization: Q290→Q76 (single-compartment model has no central/peripheral split; 'Vc/F, L' is the general volume)</li><li>population split: 'typical values (rse %) for model parameters and covariate effects' subgroup of Okubo_2021 (paper reports 3 populations: geometric mean (cv% geometric mean), geometric mean (geometric cv%), typical values (rse %) for model parameters and covariate effects)</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 162000, Tolerance = 1e-9, Interval = 1));
end Apremilast_Okubo2021_typical_values_rse_for_model_parameters;
