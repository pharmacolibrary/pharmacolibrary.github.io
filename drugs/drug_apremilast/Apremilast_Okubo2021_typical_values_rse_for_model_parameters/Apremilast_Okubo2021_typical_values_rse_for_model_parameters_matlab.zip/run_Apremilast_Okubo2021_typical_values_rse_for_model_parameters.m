% Run: build params, simulate 0..45.0 h, plot + save Apremilast_Okubo2021_typical_values_rse_for_model_parameters.png/.csv/.json.
% Interactive display (keep the window open):  octave --persist run_Apremilast_Okubo2021_typical_values_rse_for_model_parameters.m
here = fileparts(mfilename('fullpath'));
p = Apremilast_Okubo2021_typical_values_rse_for_model_parameters_params();
out = simulate_pk(p, 0:0.05:45.0);

% figure (shown on screen if interactive) and PNG (works in MATLAB and Octave)
fig = figure; plot(out.t, out.C, 'LineWidth', 1.5); grid on;
xlabel('time [h]'); ylabel('central concentration [mg/L]');
title('apremilast — Okubo_2021 (oral)');
print(fig, fullfile(here, 'Apremilast_Okubo2021_typical_values_rse_for_model_parameters.png'), '-dpng', '-r150');

% CSV (time_h, Cc_mg_per_L)
fid = fopen(fullfile(here, 'Apremilast_Okubo2021_typical_values_rse_for_model_parameters.csv'), 'w');
fprintf(fid, 'time_h,Cc_mg_per_L\n');
fprintf(fid, '%.10g,%.10g\n', [out.t(:), out.C(:)].');
fclose(fid);

% JSON (summary + arrays; jsonencode with a manual fallback for older versions)
fid = fopen(fullfile(here, 'Apremilast_Okubo2021_typical_values_rse_for_model_parameters.json'), 'w');
try
  s.model = 'Apremilast_Okubo2021_typical_values_rse_for_model_parameters'; s.Cmax = out.Cmax; s.Tmax = out.Tmax; s.AUC = out.AUC;
  s.time_h = out.t(:).'; s.Cc_mg_per_L = out.C(:).';
  fprintf(fid, '%s', jsonencode(s));
catch
  fprintf(fid, '{"model":"Apremilast_Okubo2021_typical_values_rse_for_model_parameters","Cmax":%g,"Tmax":%g,"AUC":%g}', out.Cmax, out.Tmax, out.AUC);
end
fclose(fid);

fprintf('Cmax=%.3g mg/L  Tmax=%.3g h  AUC=%.3g mg*h/L\n', out.Cmax, out.Tmax, out.AUC);
fprintf('wrote Apremilast_Okubo2021_typical_values_rse_for_model_parameters.png, Apremilast_Okubo2021_typical_values_rse_for_model_parameters.csv, Apremilast_Okubo2021_typical_values_rse_for_model_parameters.json\n');
