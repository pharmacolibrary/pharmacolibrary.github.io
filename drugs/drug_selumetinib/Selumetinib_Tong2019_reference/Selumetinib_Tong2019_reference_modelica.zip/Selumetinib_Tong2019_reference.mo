model Selumetinib_Tong2019_reference
  parameter Real Cl_ref = 3.3055555555555558e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.032100000000000004 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.45768000000000003,
    adminMass = 0.0001,
    ka = 0.0001388888888888889,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About selumetinib</h4><p>Selumetinib is a MEK inhibitor anticancer drug used to treat neurofibromatosis 1 and has been studied for low-grade serous carcinoma. It is authorised in the European Union for neurofibromatosis 1 and is also under investigation for other uses.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q7448840\">Wikidata Q7448840</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>selumetinib</td></tr><tr><td>population:</td><td>patients with non-small cell lung cancer</td></tr><tr><td>source_paper:</td><td>Tong_2019</td></tr><tr><td>measured_compound:</td><td>selumetinib</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C_enteral: apparent (/F) parameterization ⇒ extravascular dosing</td></tr><tr><td>molar_masses:</td><td>N-desmethyl selumetinib 443.657 g/mol (pubchem); selumetinib 457.68 g/mol (drugbank)</td></tr></table><p><b>Defaulted (base-class default used):</b> ka, Tlag.</p><h4>Interpretation flags</h4><ul><li>apparent-ness (ontology-grounded): parameterization=apparent, measured_compound=selumetinib</li><li>topology: transfer parameter unlinked (Q100) — add Kfm/formation-rate/rate-constant to the ontology; routing to review</li><li>template fit: PK_3M_9C — formed from central; parent 1, metabolites [0]</li><li>status held at route_to_review — not promoted</li><li>row roles (LLM): model_class=compartmental; 2/2 row label(s) assigned, 2 linked by role; re-tagged selumetinib→parent ×2</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li><li>skipped review gap-fill of V2: primary is PARENT_METABOLITE (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is PARENT_METABOLITE (peripheral family needs ≥2C)</li><li>engineer: parent → metabolite not buildable on PK_3M_9C (None) — the measured compound's 1-compartment model instead</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Selumetinib_Tong2019_reference;
