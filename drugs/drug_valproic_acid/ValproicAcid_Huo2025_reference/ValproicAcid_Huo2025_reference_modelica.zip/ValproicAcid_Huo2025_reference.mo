model ValproicAcid_Huo2025_reference
  parameter Real Cl_ref = 6.722222222222222e-07 "Cl [m3/s]";
  parameter Real Vd_ref = 0.0688 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.1442114,
    adminMass = 0.0015,
    ka = 0.0005361111111111111,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About valproic_acid</h4><p>Valproic acid is an antiepileptic drug used to treat epilepsy, including childhood absence epilepsy and complex partial seizures, and also bipolar disorder. It is widely used and appears on the WHO essential medicines list, though it carries a boxed warning as a developmental toxicant.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q240642\">Wikidata Q240642</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>valproic_acid</td></tr><tr><td>population:</td><td>review reference</td></tr><tr><td>source_paper:</td><td>Huo_2025</td></tr><tr><td>measured_compound:</td><td>valproic_acid</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>valproic_acid 144.211 g/mol (drugbank)</td></tr></table><p><b>Defaulted (base-class default used):</b> Tlag.</p><h4>Interpretation flags</h4><ul><li>built from REVIEW reference values (Huo_2025) — secondary source</li><li>volume reported by review</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 432000, Tolerance = 1e-9, Interval = 1));
end ValproicAcid_Huo2025_reference;
