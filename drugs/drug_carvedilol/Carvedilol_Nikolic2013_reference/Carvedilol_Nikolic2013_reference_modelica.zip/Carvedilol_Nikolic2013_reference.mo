model Carvedilol_Nikolic2013_reference
  parameter Real Cl_ref = 2.777777777777778e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.8320000000000001 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.4064742,
    adminMass = 6.25e-06
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About carvedilol</h4><p>Carvedilol is a beta blocker with additional alpha-blocking activity used to treat high blood pressure, angina, heart failure, and other heart conditions such as after a myocardial infarction. It is an approved medicine and is widely used in cardiovascular care.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q412534\">Wikidata Q412534</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>carvedilol</td></tr><tr><td>population:</td><td>adult patients with chronic heart failure</td></tr><tr><td>source_paper:</td><td>Nikolic_2013</td></tr><tr><td>measured_compound:</td><td>carvedilol</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>tab_2</td></tr><tr><td>input:</td><td>PK_1C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>carvedilol 406.474 g/mol (drugbank)</td></tr></table><h4>Interpretation flags</h4><ul><li>dropped unlinked row (NIL): 'Effect of TBW-θ 3' — extend the ontology if this is a real PK parameter (source ['tab_2:row7:col1', 'tab_2:row7:col2'])</li><li>dropped unlinked row (NIL): 'Effect of TOB-θ 4' — extend the ontology if this is a real PK parameter (source ['tab_2:row9:col1', 'tab_2:row9:col2'])</li><li>dropped unlinked row (NIL): 'Effect of DIG-θ 5' — extend the ontology if this is a real PK parameter (source ['tab_2:row11:col1', 'tab_2:row11:col2'])</li><li>routed 'Interindividual variance' → Q312 (IIV) to iiv — variability estimate, not a structural parameter</li><li>implicit units: 'Clearance (L/h)-θ 1' → L/h (from the paper text: &quot;The text explicitly states the unit for clearance in the abstract: 'The typical mean value for carvedilol CL... was 43.8&quot;)</li><li>implicit units: 'Volume of distribution' → L (from the popPK convention: 'The paper does not explicitly state the unit for the volume of distribution in the provided excerpts. However, in popula')</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=carvedilol</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 1123200, Tolerance = 1e-9, Interval = 1));
end Carvedilol_Nikolic2013_reference;
