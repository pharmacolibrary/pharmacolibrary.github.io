model Carvedilol_Liu2009_PD_map
  "indirect_response_i exposure-response sweep — Liu_2009 :: MAP (mean arterial blood pressure)"
  extends Pharmacolibrary.Interfaces.PartialExposureResponseSweep(
    E0 = 1.025,      // [%]
    Emax = 1,  // type I effect term
    EC50 = 24.4,  // [ng x mL(-1)]
    gamma = 1,
    exposure_per_s = 1);   // 1 ng x mL(-1) per second
equation
  response = E0*(1 - Emax*frac);   // steady state, indirect response type I
  // e0_from_kin_kout: no baseline row; E0 = kin/kout (0.41/0.4 = 1.025) — the paper's stated baseline may differ
  // exposure_unit_unresolved: 'ng x mL(-1)' — the x axis is in the paper's unit, not SI
  // defaulted: Emax
  // defaulted: gamma
  annotation(experiment(StartTime = 0, StopTime = 250, Interval = 0.5),
    Documentation(info = "<html><body><!-- drug-about --><h4>About carvedilol</h4><p>Carvedilol is a beta blocker with additional alpha-blocking activity used to treat high blood pressure, angina, heart failure, and other heart conditions such as after a myocardial infarction. It is an approved medicine and is widely used in cardiovascular care.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q412534\">Wikidata Q412534</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h4>Carvedilol_Liu2009_PD_map</h4><p>The steady-state exposure-response curve of Liu XY et al., <i>Yao xue xue bao = Acta pharmaceutica Sinica 44(4):406–411</i> 2009 — mean arterial blood pressure [%] against carvedilol ng x mL(-1) — obtained by sweeping the driver instead of simulating a dose. Model family: indirect_response_i.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    =      1.025 %        drug-free response (baseline) (kin/kout, Q327/Q328)
  Emax  = (library default) maximal effect term
  EC50  =       24.4 ng x mL(-1) exposure at half of the maximal effect term (IC50, Q322)
  gamma = (library default) Hill coefficient</pre><p>The algebra is <code>response = E0*(1 - Emax*frac)</code>; this model only supplies the numbers. The x axis is one ng x mL(-1) of carvedilol per second of simulated time: there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 1.025   (drug-free)
  exposure = EC50 (24.4 ng x mL(-1))  response 0.5125
  exposure -> infinity  response 0</pre></body></html>"));
end Carvedilol_Liu2009_PD_map;
