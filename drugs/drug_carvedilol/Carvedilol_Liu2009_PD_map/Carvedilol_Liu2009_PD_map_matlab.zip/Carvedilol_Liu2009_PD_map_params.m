function p = Carvedilol_Liu2009_PD_map_params()
% Carvedilol_Liu2009_PD_map_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% carvedilol Liu_2009::MAP: indirect_response_i exposure-response sweep (response = E0*(1 - Emax*frac)). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one ng x mL(-1) per second, in SI inside (kg/m3, s). Response MAP in %. Driver: carvedilol (cited_pk).
p.E0 = 1.025;
p.Emax = 1.0;
p.EC50 = 24.4;
p.gamma = 1.0;
p.slope = 0.0;
p.exposure_per_s = 1.0;
p.stop_time = 250.0;
p.form = 'E0*(1 - Emax*frac)';
end
