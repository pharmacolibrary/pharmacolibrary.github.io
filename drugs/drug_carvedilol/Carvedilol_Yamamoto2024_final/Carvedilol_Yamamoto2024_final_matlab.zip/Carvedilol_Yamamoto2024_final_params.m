function p = Carvedilol_Yamamoto2024_final_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: carvedilol   source: Yamamoto_2024 / final   route: oral
  p.name  = 'Carvedilol_Yamamoto2024_final_params';
  p.drug  = 'carvedilol';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 5.81;                % central volume [L]
  p.CL = 18.21;                % clearance [L/h]
  p.Vp = [23.21];             % peripheral volumes [L]
  p.Q  = [1.54];             % inter-compartmental clearances [L/h]
  p.ka = 0.095;                % absorption rate [1/h]
  p.F  = 0.3;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 25.0;             % dose [mg]
end
