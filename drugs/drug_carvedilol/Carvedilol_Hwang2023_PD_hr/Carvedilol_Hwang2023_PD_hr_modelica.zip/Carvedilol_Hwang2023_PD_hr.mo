model Carvedilol_Hwang2023_PD_hr
  "emax exposure-response sweep — Hwang_2023 :: HR (heart rate)"
  extends Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep(
    E0 = 60.4,      // [bpm]
    Emax = -30.7,  // [bpm]
    EC50 = 6.85e-10,  // [kg; μg × 1e-09]
    gamma = 1,
    exposure_per_s = 1e-09);   // 1 μg per second
  // imax_as_negative_emax: Imax (Q323) enters SigmoidEmaxSweep as −Emax
  // defaulted: gamma
  annotation(experiment(StartTime = 0, StopTime = 6.9, Interval = 0.0138),
    Documentation(info = "<html><body><!-- drug-about --><h4>About carvedilol</h4><p>Carvedilol is a beta blocker with additional alpha-blocking activity used to treat high blood pressure, angina, heart failure, and other heart conditions such as after a myocardial infarction. It is an approved medicine and is widely used in cardiovascular care.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q412534\">Wikidata Q412534</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h4>Carvedilol_Hwang2023_PD_hr</h4><p>The steady-state exposure-response curve of Hwang S et al., <i>Journal of Korean medical science 38(22):e173</i> 2023 (<a href=\"https://doi.org/10.3346/jkms.2023.38.e173\">doi:10.3346/jkms.2023.38.e173</a>) — heart rate [bpm] against carvedilol μg — obtained by sweeping the driver instead of simulating a dose. Model family: emax.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    =       60.4 bpm      drug-free response (baseline) (E0, Q324)
  Emax  =       30.7 bpm      maximal effect term (Emax, Q323)
  EC50  =      0.685 μg       exposure at half of the maximal effect term (ED50, Q321)
  gamma = (library default) Hill coefficient</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep\">SigmoidEmaxSweep</a>; this model only supplies the numbers. The x axis is one μg of carvedilol per second of simulated time (exposure is in kg): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 60.4   (drug-free)
  exposure = EC50 (0.685 μg)  response 45.05
  exposure -> infinity  response 29.7</pre></body></html>"));
end Carvedilol_Hwang2023_PD_hr;
