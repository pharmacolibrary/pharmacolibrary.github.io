model Carvedilol_Hwang2023_PD_hr
  "emax exposure-response sweep — Hwang_2023 :: HR (heart rate)"
  extends Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep(
    E0 = 60.4,      // [bpm]
    Emax = -30.7,  // [bpm]
    EC50 = 6.850000000000001e-10,  // [kg; μg × 1e-09]
    gamma = 1.0,
    exposure_per_s = 1e-09);   // 1 μg per second
  // inhibition_sign: effect_direction=inhibition with a positive Emax (Q320) — sign flipped
  // defaulted: gamma
  annotation(experiment(StartTime = 0, StopTime = 6.85, Interval = 0.0137));
end Carvedilol_Hwang2023_PD_hr;
