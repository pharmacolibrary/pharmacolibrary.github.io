function p = Carvedilol_Yamamoto2024_final_s_carvedilol_final_model_estim_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: carvedilol   source: Yamamoto_2024 / final_s_carvedilol_final_model_estimate_rse   route: oral
  p.name  = 'Carvedilol_Yamamoto2024_final_s_carvedilol_final_model_estim_params';
  p.drug  = 'carvedilol';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 4.96;                % central volume [L]
  p.CL = 17.29;                % clearance [L/h]
  p.Vp = [140.65];             % peripheral volumes [L]
  p.Q  = [12.54];             % inter-compartmental clearances [L/h]
  p.ka = 0.15;                % absorption rate [1/h]
  p.F  = 0.15;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 25.0;             % dose [mg]
end
