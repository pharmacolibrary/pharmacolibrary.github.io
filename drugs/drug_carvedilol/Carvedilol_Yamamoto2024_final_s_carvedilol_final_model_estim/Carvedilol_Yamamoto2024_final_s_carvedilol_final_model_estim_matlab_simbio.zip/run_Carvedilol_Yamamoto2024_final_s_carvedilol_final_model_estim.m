% Run (SimBiology): build model + dose, simulate 0..24.0 h, plot.
p = Carvedilol_Yamamoto2024_final_s_carvedilol_final_model_estim_params();
[model, dose, variant] = build_sb_pk(p);
sd = simulate_sb(model, variant, dose, 24.0);
