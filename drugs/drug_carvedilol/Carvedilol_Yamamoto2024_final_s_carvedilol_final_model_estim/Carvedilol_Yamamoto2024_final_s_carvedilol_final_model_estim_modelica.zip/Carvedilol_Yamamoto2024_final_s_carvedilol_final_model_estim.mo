model Carvedilol_Yamamoto2024_final_s_carvedilol_final_model_estim
  parameter Real Cl_ref = 4.802777777777778e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.00496 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C_enteral(
    weight = 70.0,
    F = 0.15,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    adminMass = 2.5e-05,
    ka = 4.1666666666666665e-05,
    Tlag = 0.0,
    k12 = 0.0007022849462365591,
    k21 = 2.4765967531698068e-05
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About carvedilol</h4><p>Carvedilol is a beta blocker with additional alpha-blocking activity used to treat high blood pressure, angina, heart failure, and other heart conditions such as after a myocardial infarction. It is an approved medicine and is widely used in cardiovascular care.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q412534\">Wikidata Q412534</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>carvedilol</td></tr><tr><td>population:</td><td>nonobese, obese, and post-RYGB patients</td></tr><tr><td>source_paper:</td><td>Yamamoto_2024</td></tr><tr><td>measured_compound:</td><td>(S)-carvedilol</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>table 1</td></tr><tr><td>input:</td><td>PK_2C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>carvedilol 406.474 g/mol (drugbank)</td></tr></table><p><b>Defaulted (base-class default used):</b> Tlag.</p><h4>Interpretation flags</h4><ul><li>dropped duplicate Q49 ('ka2pop', value '0.57') — already have one for this compound</li><li>dropped unlinked row (NIL): 'RVGB on F1' — extend the ontology if this is a real PK parameter (source ['Yamamoto_2024_table_1:row3:col4'])</li><li>dropped unlinked row (NIL): 'TIag2pop' — extend the ontology if this is a real PK parameter (source ['Yamamoto_2024_table_1:row4:col4'])</li><li>dropped duplicate Q87 ('BIO2', value '0.13') — already have one for this compound</li><li>implicit units: 'ka1pop' → 1/h (from the popPK convention: 'ka is an absorption rate constant; the standard unit in population PK is 1/h, consistent with the value 0.15.')</li><li>implicit units: 'Clpop' → L/h (from the popPK convention: 'Cl is total clearance; the standard unit in population PK is L/h, consistent with the value 17.29.')</li><li>implicit units: 'V1pop' → L (from the popPK convention: 'V1 is the volume of distribution of the central compartment; the standard unit in population PK is L, consistent with th')</li><li>implicit units: 'Qpop' → L/h (from the popPK convention: 'Q is intercompartmental clearance; the standard unit in population PK is L/h, consistent with the value 12.54.')</li><li>implicit units: 'V2pop' → L (from the popPK convention: 'V2 is the volume of distribution of the peripheral compartment; the standard unit in population PK is L, consistent with')</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=(S)-carvedilol</li><li>model-stage split: '(s)-carvedilol: final model estimate (rse %)' is the final model of Yamamoto_2024 (paper reports 2 stages: (r)-carvedilol: final model estimate (rse %), (s)-carvedilol: final model estimate (rse %)); same population, different model-building step</li><li>molar mass: none of 1 PubChem candidate(s) is '(S)-carvedilol' (LLM) — left in mass units</li><li>molar mass: none found for '(S)-carvedilol' — its concentrations stay mass-only</li><li>skipped review gap-fill of TLAG: primary's parameterization (rate-constant / ka-only) does not use it</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Carvedilol_Yamamoto2024_final_s_carvedilol_final_model_estim;
