function p = Carvedilol_Yamamoto2024_PD_e_params()
% Carvedilol_Yamamoto2024_PD_e_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% carvedilol Yamamoto_2024::E: emax exposure-response sweep (response = E0 + Emax*frac). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one ng mL-1 per second, in SI inside (kg/m3, s). Response E in beats/min. Driver: (S)-carvedilol (pk_record).
p.E0 = 146.0;
p.Emax = -19.2;
p.EC50 = 7.699999999999999e-06;
p.gamma = 1.0;
p.slope = 0.0;
p.exposure_per_s = 1e-06;
p.stop_time = 77.0;
p.form = 'E0 + Emax*frac';
end
