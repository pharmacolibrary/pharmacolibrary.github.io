model Carvedilol_Yamamoto2024_PD_e
  "emax exposure-response sweep — Yamamoto_2024 :: E (exercise-induced heart rate)"
  extends Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep(
    E0 = 146,      // [beats/min]
    Emax = -19.2,  // [beats/min]
    EC50 = 7.7e-06,  // [kg/m3; ng mL-1 × 1e-06]
    gamma = 1,
    exposure_per_s = 1e-06);   // 1 ng mL-1 per second
  // imax_as_negative_emax: Imax (Q323) enters SigmoidEmaxSweep as −Emax
  // defaulted: gamma
  annotation(experiment(StartTime = 0, StopTime = 77, Interval = 0.154),
    Documentation(info = "<html><body><!-- drug-about --><h4>About carvedilol</h4><p>Carvedilol is a beta blocker with additional alpha-blocking activity used to treat high blood pressure, angina, heart failure, and other heart conditions such as after a myocardial infarction. It is an approved medicine and is widely used in cardiovascular care.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q412534\">Wikidata Q412534</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h4>Carvedilol_Yamamoto2024_PD_e</h4><p>The steady-state exposure-response curve of Yamamoto PA et al., <i>British journal of clinical pharmacology 90(9):2223–2235</i> 2024 (<a href=\"https://doi.org/10.1111/bcp.16129\">doi:10.1111/bcp.16129</a>) — exercise-induced heart rate [beats/min] against (S)-carvedilol ng mL-1 — obtained by sweeping the driver instead of simulating a dose. Model family: emax.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    =        146 beats/min drug-free response (baseline) (E0, Q324)
  Emax  =       19.2 beats/min maximal effect term (Emax, Q323)
  EC50  =        7.7 ng mL-1  exposure at half of the maximal effect term (EC50, Q321)
  gamma = (library default) Hill coefficient</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep\">SigmoidEmaxSweep</a>; this model only supplies the numbers. The x axis is one ng mL-1 of (S)-carvedilol per second of simulated time (exposure is in kg/m3): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 146   (drug-free)
  exposure = EC50 (7.7 ng mL-1)  response 136.4
  exposure -> infinity  response 126.8</pre></body></html>"));
end Carvedilol_Yamamoto2024_PD_e;
