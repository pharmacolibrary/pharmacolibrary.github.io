model Carvedilol_McTavish1993_reference
  parameter Real Cl_ref = 1.0138888888888888e-05 "Cl [m3/s]";
  parameter Real Vd_ref = 0.7635463503904839 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.4064742,
    adminMass = 1e-05
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About carvedilol</h4><p>Carvedilol is a beta blocker with additional alpha-blocking activity used to treat high blood pressure, angina, heart failure, and other heart conditions such as after a myocardial infarction. It is an approved medicine and is widely used in cardiovascular care.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q412534\">Wikidata Q412534</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>carvedilol</td></tr><tr><td>population:</td><td>review reference</td></tr><tr><td>source_paper:</td><td>McTavish_1993</td></tr><tr><td>measured_compound:</td><td>carvedilol</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>carvedilol 406.474 g/mol (drugbank)</td></tr></table><h4>Interpretation flags</h4><ul><li>built from REVIEW reference values (McTavish_1993) — secondary source</li><li>central volume derived from CL·t½/ln2</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 345600, Tolerance = 1e-9, Interval = 1));
end Carvedilol_McTavish1993_reference;
