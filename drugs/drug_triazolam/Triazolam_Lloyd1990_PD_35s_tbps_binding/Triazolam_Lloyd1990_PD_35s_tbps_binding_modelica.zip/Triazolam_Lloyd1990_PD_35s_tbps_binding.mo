model Triazolam_Lloyd1990_PD_35s_tbps_binding
  "emax exposure-response sweep — Lloyd_1990 :: 35S-TBPS binding (35S-TBPS binding to rat cerebral cortex membranes)"
  extends Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep(
    E0 = 0,      // [1]
    Emax = 0.42,  // [1; % × 0.01]
    EC50 = 2,  // [nM]
    gamma = 1,
    exposure_per_s = 1);   // 1 nM per second
  // exposure_unit_unresolved: 'nM' — the x axis is in the paper's unit, not SI
  // defaulted: E0
  // defaulted: gamma
  annotation(experiment(StartTime = 0, StopTime = 20, Interval = 0.04),
    Documentation(info = "<html><body><!-- drug-about --><h4>About triazolam</h4><p>Triazolam is a benzodiazepine sedative used to treat insomnia and other sleep-wake disorders. It remains an approved medicine, though it carries a boxed warning, indicating its use is approached with caution.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q412143\">Wikidata Q412143</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h4>Triazolam_Lloyd1990_PD_35s_tbps_binding</h4><p>The steady-state exposure-response curve of Lloyd GK et al., <i>The Journal of pharmacology and experimental therapeutics 255(2):690–696</i> 1990 — 35S-TBPS binding to rat cerebral cortex membranes [%] against triazolam nM — obtained by sweeping the driver instead of simulating a dose. Model family: emax.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = (library default) drug-free response (baseline)
  Emax  =         42 %        maximal effect term (Emax, Q320)
  EC50  =          2 nM       exposure at half of the maximal effect term (EC50, Q321)
  gamma = (library default) Hill coefficient</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep\">SigmoidEmaxSweep</a>; this model only supplies the numbers. The x axis is one nM of triazolam per second of simulated time: there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0   (drug-free)
  exposure = EC50 (2 nM)  response 0.21
  exposure -> infinity  response 0.42</pre></body></html>"));
end Triazolam_Lloyd1990_PD_35s_tbps_binding;
