function p = Triazolam_Lloyd1990_PD_35s_tbps_binding_params()
% Triazolam_Lloyd1990_PD_35s_tbps_binding_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% triazolam Lloyd_1990::35S_TBPS_binding: emax exposure-response sweep (response = E0 + Emax*frac). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one nM per second, in SI inside (kg/m3, s). Response 35S-TBPS binding in %. Driver: triazolam (cited_pk).
p.E0 = 0.0;
p.Emax = 0.42;
p.EC50 = 2.0;
p.gamma = 1.0;
p.slope = 0.0;
p.exposure_per_s = 1.0;
p.stop_time = 20.0;
p.form = 'E0 + Emax*frac';
end
