% run_Triazolam_Lloyd1990_PD_35s_tbps_binding  Evaluate the exposure-response curve and plot response against exposure.
% A sweep is a static map: no ODE solver is needed. exposure runs 0..stop_time*exposure_per_s.
p = Triazolam_Lloyd1990_PD_35s_tbps_binding_params();
exposure = linspace(0, p.stop_time * p.exposure_per_s, 501);
frac = exposure.^p.gamma ./ (p.EC50^p.gamma + exposure.^p.gamma);
E0 = p.E0; Emax = p.Emax; slope = p.slope;
response = E0 + Emax.*frac;
figure; plot(exposure, response, 'LineWidth', 1.5); grid on;
xlabel('exposure [nM]'); ylabel('response [%]'); title('Triazolam_Lloyd1990_PD_35s_tbps_binding', 'Interpreter', 'none');
writematrix([exposure(:) response(:)], 'Triazolam_Lloyd1990_PD_35s_tbps_binding.csv');
