function p = Triazolam_Okada2024_PD_cognitive_function_params()
% Triazolam_Okada2024_PD_cognitive_function_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% triazolam Okada_2024::Cognitive_function: linear exposure-response sweep (response = E0 + slope*exposure). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one ng/mL per second, in SI inside (kg/m3, s). Response Cognitive function in %. Driver: triazolam (pk_record).
p.E0 = 0.0;
p.Emax = 0.0;
p.EC50 = 1.0;
p.gamma = 1.0;
p.slope = -11.0;
p.exposure_per_s = 1e-06;
p.stop_time = 1000.0;
p.form = 'E0 + slope*exposure';
end
