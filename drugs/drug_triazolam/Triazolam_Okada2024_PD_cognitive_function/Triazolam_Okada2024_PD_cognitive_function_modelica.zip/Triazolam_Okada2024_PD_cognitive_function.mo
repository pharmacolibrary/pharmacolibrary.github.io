model Triazolam_Okada2024_PD_cognitive_function
  "linear exposure-response sweep — Okada_2024 :: Cognitive function (Cognitive function)"
  extends Pharmacolibrary.Interfaces.PartialExposureResponseSweep(
    E0 = 0,      // [1]
    Emax = 0, EC50 = 1,      // unused by a line
    exposure_per_s = 1e-06);
  parameter Real slope = -11   "[1]";
equation
  response = E0 + slope*exposure;
  // family_inferred: the record's model family is effect_compartment; read from the parameters: a slope and no Emax — linear
  // defaulted: E0
  annotation(experiment(StartTime = 0, StopTime = 1000, Interval = 2),
    Documentation(info = "<html><body><!-- drug-about --><h4>About triazolam</h4><p>Triazolam is a benzodiazepine sedative used to treat insomnia and other sleep-wake disorders. It remains an approved medicine, though it carries a boxed warning, indicating its use is approached with caution.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q412143\">Wikidata Q412143</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h4>Triazolam_Okada2024_PD_cognitive_function</h4><p>The steady-state exposure-response curve of Okada A et al., <i>BMC pharmacology &amp; toxicology 25(1):60</i> 2024 (<a href=\"https://doi.org/10.1186/s40360-024-00777-z\">doi:10.1186/s40360-024-00777-z</a>) — Cognitive function [%] against triazolam ng/mL — obtained by sweeping the driver instead of simulating a dose. Model family: linear.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = (library default) drug-free response (baseline)
  slope =        -11          change in response per unit of exposure (Cognitive function constant, Q335)</pre><p>The algebra is <code>response = E0 + slope*exposure</code>; this model only supplies the numbers. The x axis is one ng/mL of triazolam per second of simulated time (exposure is in kg/m3): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0   (drug-free)</pre></body></html>"));
end Triazolam_Okada2024_PD_cognitive_function;
