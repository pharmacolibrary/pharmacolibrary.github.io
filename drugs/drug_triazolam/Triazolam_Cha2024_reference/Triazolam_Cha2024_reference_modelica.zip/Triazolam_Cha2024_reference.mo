model Triazolam_Cha2024_reference
  parameter Real Cl_ref = 5.4888888888888895e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.0748 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.34320999999999996,
    adminMass = 2.5e-07,
    ka = 0.0015027777777777778,
    Tlag = 1418.4
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About triazolam</h4><p>Triazolam is a benzodiazepine sedative used to treat insomnia and other sleep-wake disorders. It remains an approved medicine, though it carries a boxed warning, indicating its use is approached with caution.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q412143\">Wikidata Q412143</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>triazolam</td></tr><tr><td>population:</td><td>review reference</td></tr><tr><td>source_paper:</td><td>Cha_2024</td></tr><tr><td>measured_compound:</td><td>triazolam</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>triazolam 343.21 g/mol (drugbank)</td></tr></table><h4>Interpretation flags</h4><ul><li>built from REVIEW reference values (Cha_2024) — secondary source</li><li>volume reported by review</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Triazolam_Cha2024_reference;
