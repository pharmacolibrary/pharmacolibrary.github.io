function p = Macrogol_Sharda2021_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: macrogol   source: Sharda_2021 / reference   route: iv_bolus
  % estimated (absent from source): dose
  % Vc is the record's Vss — no central volume was reported; 1-compartment reading
  p.name  = 'Macrogol_Sharda2021_reference_params';
  p.drug  = 'macrogol';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'iv_bolus';        % 'oral' | 'iv_bolus'
  p.depot = false;             % oral -> first-order absorption depot
  p.Vc = 13.3;                % central volume [L]
  p.CL = 0.3318;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.0;                % absorption rate [1/h]
  p.F  = 0.68;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 10.0;             % dose [mg]
end
