function p = Fluvoxamine_Geldof2008_PD_sert_occupancy_params()
% Fluvoxamine_Geldof2008_PD_sert_occupancy_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% fluvoxamine Geldof_2008::SERT_occupancy: emax exposure-response sweep (response = E0 + Emax*frac). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one ng mL À1 per second, in SI inside (kg/m3, s). Response SERT occupancy in %. Driver: fluvoxamine (cited_pk).
p.E0 = 0.0;
p.Emax = -0.9450000000000001;
p.EC50 = 4.8e-07;
p.gamma = 1.0;
p.slope = 0.0;
p.exposure_per_s = 1e-06;
p.stop_time = 4.8;
p.form = 'E0 + Emax*frac';
end
