model Fluvoxamine_Geldof2008_PD_sert_occupancy
  "emax exposure-response sweep — Geldof_2008 :: SERT occupancy (fluvoxamine SERT occupancy (ex vivo, rat frontal cortex))"
  extends Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep(
    E0 = 0,      // [1]
    Emax = -0.945,  // [1; % × 0.01]
    EC50 = 4.8e-07,  // [kg/m3; ng mL À1 × 1e-06]
    gamma = 1,
    exposure_per_s = 1e-06);   // 1 ng mL À1 per second
  // imax_as_negative_emax: Imax (Q323) enters SigmoidEmaxSweep as −Emax
  // defaulted: E0
  // defaulted: gamma
  annotation(experiment(StartTime = 0, StopTime = 4.8, Interval = 0.0096),
    Documentation(info = "<html><body><!-- drug-about --><h4>About fluvoxamine</h4><p>Fluvoxamine is a selective serotonin reuptake inhibitor antidepressant used for depression, obsessive-compulsive disorder, anxiety disorders and panic disorder. It is an approved medicine used worldwide in everyday clinical practice, mainly for obsessive-compulsive disorder and depression.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q409236\">Wikidata Q409236</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h4>Fluvoxamine_Geldof2008_PD_sert_occupancy</h4><p>The steady-state exposure-response curve of Geldof M et al., <i>British journal of pharmacology 154(6):1369–1378</i> 2008 (<a href=\"https://doi.org/10.1038/bjp.2008.179\">doi:10.1038/bjp.2008.179</a>) — fluvoxamine SERT occupancy (ex vivo, rat frontal cortex) [%] against fluvoxamine ng mL À1 — obtained by sweeping the driver instead of simulating a dose. Model family: emax.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = (library default) drug-free response (baseline)
  Emax  =       94.5 %        maximal effect term (B max, Q323)
  EC50  =       0.48 ng mL À1 exposure at half of the maximal effect term (EC 50, Q321)
  gamma = (library default) Hill coefficient</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep\">SigmoidEmaxSweep</a>; this model only supplies the numbers. The x axis is one ng mL À1 of fluvoxamine per second of simulated time (exposure is in kg/m3): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0   (drug-free)
  exposure = EC50 (0.48 ng mL À1)  response -0.4725
  exposure -> infinity  response -0.945</pre></body></html>"));
end Fluvoxamine_Geldof2008_PD_sert_occupancy;
