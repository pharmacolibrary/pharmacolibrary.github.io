model Fluvoxamine_Strauss1999_reference
  parameter Real Cl_ref = 2.8055555555555556e-07 "Cl [m3/s]";
  parameter Real Vd_ref = 0.07840000000000001 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 1.85,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.31833999999999996,
    adminMass = 0.0001,
    ka = 0.00040555555555555554,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About fluvoxamine</h4><p>Fluvoxamine is a selective serotonin reuptake inhibitor antidepressant used for depression, obsessive-compulsive disorder, anxiety disorders and panic disorder. It is an approved medicine used worldwide in everyday clinical practice, mainly for obsessive-compulsive disorder and depression.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q409236\">Wikidata Q409236</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>fluvoxamine</td></tr><tr><td>population:</td><td>adults (fluvoxamine-treated, 19F MRS brain PK)</td></tr><tr><td>source_paper:</td><td>Strauss_1999</td></tr><tr><td>measured_compound:</td><td>fluvoxamine</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>fluvoxamine 318.34 g/mol (drugbank)</td></tr></table><p><b>Defaulted (base-class default used):</b> Tlag.</p><h4>Interpretation flags</h4><ul><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=fluvoxamine</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li><li>gap-filled Q49 (kabs) from Chen_2024's review values (primary lacked it)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 1036800, Tolerance = 1e-9, Interval = 1));
end Fluvoxamine_Strauss1999_reference;
