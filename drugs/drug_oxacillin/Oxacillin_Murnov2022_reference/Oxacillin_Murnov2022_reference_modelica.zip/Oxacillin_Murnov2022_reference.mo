model Oxacillin_Murnov2022_reference
  parameter Real Cl_ref = 2.271111111111111e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.0112 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.40143599999999996,
    adminMass = 0.002
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About oxacillin</h4><p>Oxacillin is a penicillin antibiotic used to treat staphylococcal infections, including sepsis, urinary tract infections, cellulitis, osteomyelitis, infective endocarditis, and bacterial meningitis. It is an approved beta-lactamase–resistant penicillin, though it is not authorised in the European Union.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q418725\">Wikidata Q418725</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>oxacillin</td></tr><tr><td>population:</td><td>patients with staphylococcal infections</td></tr><tr><td>source_paper:</td><td>Murínová_2022</td></tr><tr><td>measured_compound:</td><td>oxacillin</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>antibiotics-11-01736-t002</td></tr><tr><td>input:</td><td>PK_1C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>oxacillin 401.436 g/mol (drugbank)</td></tr></table><h4>Interpretation flags</h4><ul><li>unit_dimension_unknown: 'h−1 per each 1 mL/s/1.73 m2 of eGFR' (kel)</li><li>dropped duplicate Q47 ('β_Ke_eGFR (h−1 per each 1 mL/s/1.73 m2 of eGFR)', value '0.3') — already have one for this compound</li><li>dropped unlinked row (NIL): 'Ω_Vd' — extend the ontology if this is a real PK parameter (source ['antibiotics-11-01736-t002:row6:col1', 'antibiotics-11-01736-t002:row6:col2'])</li><li>routed 'Ω_Ke' → Q312 (IIV) to iiv — variability estimate, not a structural parameter</li><li>dropped unlinked row (NIL): 'b' — extend the ontology if this is a real PK parameter (source ['antibiotics-11-01736-t002:row9:col1', 'antibiotics-11-01736-t002:row9:col2'])</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=oxacillin</li><li>skipped review gap-fill of CL: primary's parameterization (rate-constant / ka-only) does not use it</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary's parameterization (rate-constant / ka-only) does not use it</li><li>derived CL=8.176 L/h from Ke × V = CL (Q47 × Q61); not separately reported</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Oxacillin_Murnov2022_reference;
