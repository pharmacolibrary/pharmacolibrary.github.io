function p = Oxacillin_Rodriguez2010_PD_e_params()
% Oxacillin_Rodriguez2010_PD_e_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% oxacillin Rodriguez_2010::E: sigmoid_emax exposure-response sweep (response = E0 + Emax*frac). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one mg/kg per second, in SI inside (kg/m3, s). Response E in log10 CFU/g. Driver: oxacillin (dose_only).
p.E0 = 0.0;
p.Emax = -5.42;
p.EC50 = 4.518999999999999e-05;
p.gamma = 1.73;
p.slope = 0.0;
p.exposure_per_s = 1e-06;
p.stop_time = 460.0;
p.form = 'E0 + Emax*frac';
end
