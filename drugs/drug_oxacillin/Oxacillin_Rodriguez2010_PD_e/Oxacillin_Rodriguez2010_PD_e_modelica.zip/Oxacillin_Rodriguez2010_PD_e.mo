model Oxacillin_Rodriguez2010_PD_e
  "sigmoid_emax exposure-response sweep — Rodriguez_2010 :: E (net antibacterial effect (log10 CFU/g) after 24 h of treatment)"
  extends Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep(
    E0 = 0,      // [1]
    Emax = -5.42,  // [log10 CFU/g]
    EC50 = 4.519e-05,  // [1; mg/kg × 1e-06]
    gamma = 1.73,
    exposure_per_s = 1e-06);   // 1 mg/kg per second
  // imax_as_negative_emax: Imax (Q323) enters SigmoidEmaxSweep as −Emax
  // defaulted: E0
  annotation(experiment(StartTime = 0, StopTime = 460, Interval = 0.92),
    Documentation(info = "<html><body><!-- drug-about --><h4>About oxacillin</h4><p>Oxacillin is a penicillin antibiotic used to treat staphylococcal infections, including sepsis, urinary tract infections, cellulitis, osteomyelitis, infective endocarditis, and bacterial meningitis. It is an approved beta-lactamase–resistant penicillin, though it is not authorised in the European Union.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q418725\">Wikidata Q418725</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h4>Oxacillin_Rodriguez2010_PD_e</h4><p>The steady-state exposure-response curve of Rodriguez CA et al., <i>BMC infectious diseases 10:153</i> 2010 (<a href=\"https://doi.org/10.1186/1471-2334-10-153\">doi:10.1186/1471-2334-10-153</a>) — net antibacterial effect (log10 CFU/g) after 24 h of treatment [log10 CFU/g] against oxacillin mg/kg — obtained by sweeping the driver instead of simulating a dose. Model family: sigmoid_emax.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = (library default) drug-free response (baseline)
  Emax  =       5.42 log10 CFU/g maximal effect term (Emax, Q323)
  EC50  =      45.19 mg/kg    exposure at half of the maximal effect term (ED50, Q321)
  gamma =       1.73          Hill coefficient (N, Q325)</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep\">SigmoidEmaxSweep</a>; this model only supplies the numbers. The x axis is one mg/kg of oxacillin per second of simulated time: there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0   (drug-free)
  exposure = EC50 (45.19 mg/kg)  response -2.71
  exposure -> infinity  response -5.42</pre></body></html>"));
end Oxacillin_Rodriguez2010_PD_e;
