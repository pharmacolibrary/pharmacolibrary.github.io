model Oxacillin_Lee2026_reference
  parameter Real Cl_ref = 2.8055555555555556e-07 "Cl [m3/s]";
  parameter Real Vd_ref = 0.0018700000000000001 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.40143599999999996,
    adminMass = 0.00175
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About oxacillin</h4><p>Oxacillin is a penicillin antibiotic used to treat staphylococcal infections, including sepsis, urinary tract infections, cellulitis, osteomyelitis, infective endocarditis, and bacterial meningitis. It is an approved beta-lactamase–resistant penicillin, though it is not authorised in the European Union.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q418725\">Wikidata Q418725</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>oxacillin</td></tr><tr><td>population:</td><td>preterm and term neonates and infants</td></tr><tr><td>source_paper:</td><td>Lee_2026</td></tr><tr><td>measured_compound:</td><td>oxacillin</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>T2</td></tr><tr><td>input:</td><td>PK_1C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>oxacillin 401.436 g/mol (drugbank)</td></tr></table><h4>Interpretation flags</h4><ul><li>dropped duplicate Q22 ('Effect of PNA on CL (Θ3)', value '0.433') — already have one for this compound</li><li>implicit units: 'CL (Θ1)' → L/h (from the paper text: &quot;TABLE 2 caption states: 'Final Model: CL (L/h) = 1.01 * (WTKg/3.4) 0.75 * (PNAdays/36) 0.433'&quot;)</li><li>implicit units: 'V (Θ2)' → L (from the paper text: &quot;TABLE 2 caption states: 'Vd (L) = 1.87 * WTKg/3.4'&quot;)</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=oxacillin</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Oxacillin_Lee2026_reference;
