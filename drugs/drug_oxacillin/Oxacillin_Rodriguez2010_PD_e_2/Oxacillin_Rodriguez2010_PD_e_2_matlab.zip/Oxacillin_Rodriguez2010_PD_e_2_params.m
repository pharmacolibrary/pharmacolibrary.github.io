function p = Oxacillin_Rodriguez2010_PD_e_2_params()
% Oxacillin_Rodriguez2010_PD_e_2_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% oxacillin Rodriguez_2010::E::2: emax exposure-response sweep (response = E0 + Emax*frac). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one mg/kg per day per second, in SI inside (kg/m3, s). Response E in log10 CFU/g. Driver: oxacillin (dose_only).
p.E0 = 0.0;
p.Emax = -5.1;
p.EC50 = 1.78;
p.gamma = 1.0;
p.slope = 0.0;
p.exposure_per_s = 1.0;
p.stop_time = 18.0;
p.form = 'E0 + Emax*frac';
end
