model Melarsoprol_Burri1994_reference
  parameter Real Cl_ref = 4.083333333333333e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.252 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.39832999999999996,
    adminMass = 6e-05
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About melarsoprol</h4><p>Melarsoprol is an arsenic-based antiparasitic drug used to treat sleeping sickness (African trypanosomiasis). It has been listed among WHO essential medicines as a trypanocidal agent, but DrugBank currently classifies it as investigational, so its availability today appears limited.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q419753\">Wikidata Q419753</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>melarsoprol</td></tr><tr><td>population:</td><td>healthy vervet monkeys</td></tr><tr><td>source_paper:</td><td>Burri_1994</td></tr><tr><td>measured_compound:</td><td>melarsoprol</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>melarsoprol 398.33 g/mol (drugbank)</td></tr></table><h4>Interpretation flags</h4><ul><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=melarsoprol</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 259200, Tolerance = 1e-9, Interval = 1));
end Melarsoprol_Burri1994_reference;
