model Terazosin_Campanero2008_PD_dbp
  "emax exposure-response sweep — Campanero_2008 :: DBP (diastolic blood pressure)"
  extends Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep(
    E0 = 0,      // [1]
    Emax = -39.7,  // [mmHg]
    EC50 = 2.87e-05,  // [kg/m3; microg/L × 1e-06]
    gamma = 1,
    exposure_per_s = 1e-06);   // 1 microg/L per second
  // family_inferred: the record's model family is effect_compartment; read from the parameters: Emax/Imax and EC50/IC50 without a Hill coefficient — Emax
  // imax_as_negative_emax: Imax (Q323) enters SigmoidEmaxSweep as −Emax
  // defaulted: E0
  // defaulted: gamma
  annotation(experiment(StartTime = 0, StopTime = 290, Interval = 0.58),
    Documentation(info = "<html><body><!-- drug-about --><h4>About terazosin</h4><p>Terazosin is an alpha-blocker used to treat high blood pressure and urinary problems caused by an enlarged prostate, such as difficulty passing urine. It is an approved medicine and is used fairly widely, mainly for benign prostatic enlargement.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q280786\">Wikidata Q280786</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h4>Terazosin_Campanero2008_PD_dbp</h4><p>The steady-state exposure-response curve of Campanero MA et al., <i>Clinical drug investigation 28(3):139–147</i> 2008 (<a href=\"https://doi.org/10.2165/00044011-200828030-00001\">doi:10.2165/00044011-200828030-00001</a>) — diastolic blood pressure [mmHg] against terazosin microg/L — obtained by sweeping the driver instead of simulating a dose. Model family: emax.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = (library default) drug-free response (baseline)
  Emax  =       39.7 mmHg     maximal effect term (E(max), Q323)
  EC50  =       28.7 microg/L exposure at half of the maximal effect term (EC(50), Q322)
  gamma = (library default) Hill coefficient</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep\">SigmoidEmaxSweep</a>; this model only supplies the numbers. The x axis is one microg/L of terazosin per second of simulated time (exposure is in kg/m3): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0   (drug-free)
  exposure = EC50 (28.7 microg/L)  response -19.85
  exposure -> infinity  response -39.7</pre></body></html>"));
end Terazosin_Campanero2008_PD_dbp;
