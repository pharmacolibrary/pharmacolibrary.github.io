function p = Terazosin_Campanero2008_PD_dbp_params()
% Terazosin_Campanero2008_PD_dbp_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% terazosin Campanero_2008::DBP: emax exposure-response sweep (response = E0 + Emax*frac). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one microg/L per second, in SI inside (kg/m3, s). Response DBP in mmHg. Driver: terazosin (cited_pk).
p.E0 = 0.0;
p.Emax = -39.7;
p.EC50 = 2.8699999999999993e-05;
p.gamma = 1.0;
p.slope = 0.0;
p.exposure_per_s = 1e-06;
p.stop_time = 290.0;
p.form = 'E0 + Emax*frac';
end
