function p = Terazosin_Campanero2008_PD_sbp_params()
% Terazosin_Campanero2008_PD_sbp_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% terazosin Campanero_2008::SBP: emax exposure-response sweep (response = E0 + Emax*frac). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one microg/L per second, in SI inside (kg/m3, s). Response SBP in mmHg. Driver: terazosin (cited_pk).
p.E0 = 0.0;
p.Emax = -29.9;
p.EC50 = 2.989999999999999e-05;
p.gamma = 1.0;
p.slope = 0.0;
p.exposure_per_s = 1e-06;
p.stop_time = 300.0;
p.form = 'E0 + Emax*frac';
end
