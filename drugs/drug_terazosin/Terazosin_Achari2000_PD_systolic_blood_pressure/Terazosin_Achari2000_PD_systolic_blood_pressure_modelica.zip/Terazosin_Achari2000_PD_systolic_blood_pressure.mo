model Terazosin_Achari2000_PD_systolic_blood_pressure
  "emax exposure-response sweep — Achari_2000 :: systolic blood pressure (systolic blood pressure)"
  extends Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep(
    E0 = 0,      // [1]
    Emax = -10.7,  // [mmHg]
    EC50 = 3e-06,  // [kg; mg × 1e-06]
    gamma = 1,
    exposure_per_s = 1e-06);   // 1 mg per second
  // imax_as_negative_emax: Imax (Q323) enters SigmoidEmaxSweep as −Emax
  // defaulted: E0
  // defaulted: gamma
  annotation(experiment(StartTime = 0, StopTime = 30, Interval = 0.06),
    Documentation(info = "<html><body><!-- drug-about --><h4>About terazosin</h4><p>Terazosin is an alpha-blocker used to treat high blood pressure and urinary problems caused by an enlarged prostate, such as difficulty passing urine. It is an approved medicine and is used fairly widely, mainly for benign prostatic enlargement.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q280786\">Wikidata Q280786</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h4>Terazosin_Achari2000_PD_systolic_blood_pressure</h4><p>The steady-state exposure-response curve of Achari R et al., <i>Journal of clinical pharmacology 40(10):1166–1172</i> 2000 — systolic blood pressure [mmHg] against terazosin mg — obtained by sweeping the driver instead of simulating a dose. Model family: emax.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = (library default) drug-free response (baseline)
  Emax  =       10.7 mmHg     maximal effect term (Emax, Q323)
  EC50  =          3 mg       exposure at half of the maximal effect term (ED50, Q321)
  gamma = (library default) Hill coefficient</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep\">SigmoidEmaxSweep</a>; this model only supplies the numbers. The x axis is one mg of terazosin per second of simulated time (exposure is in kg): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0   (drug-free)
  exposure = EC50 (3 mg)  response -5.35
  exposure -> infinity  response -10.7</pre></body></html>"));
end Terazosin_Achari2000_PD_systolic_blood_pressure;
