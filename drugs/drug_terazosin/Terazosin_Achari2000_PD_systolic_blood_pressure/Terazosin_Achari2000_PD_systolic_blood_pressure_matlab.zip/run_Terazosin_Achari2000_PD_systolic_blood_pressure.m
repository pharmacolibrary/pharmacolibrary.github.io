% run_Terazosin_Achari2000_PD_systolic_blood_pressure  Evaluate the exposure-response curve and plot response against exposure.
% A sweep is a static map: no ODE solver is needed. exposure runs 0..stop_time*exposure_per_s.
p = Terazosin_Achari2000_PD_systolic_blood_pressure_params();
exposure = linspace(0, p.stop_time * p.exposure_per_s, 501);
frac = exposure.^p.gamma ./ (p.EC50^p.gamma + exposure.^p.gamma);
E0 = p.E0; Emax = p.Emax; slope = p.slope;
response = E0 + Emax.*frac;
figure; plot(exposure, response, 'LineWidth', 1.5); grid on;
xlabel('exposure [mg]'); ylabel('response [mmHg]'); title('Terazosin_Achari2000_PD_systolic_blood_pressure', 'Interpreter', 'none');
writematrix([exposure(:) response(:)], 'Terazosin_Achari2000_PD_systolic_blood_pressure.csv');
