function p = Terazosin_Achari2000_PD_systolic_blood_pressure_params()
% Terazosin_Achari2000_PD_systolic_blood_pressure_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% terazosin Achari_2000::systolic_blood_pressure: emax exposure-response sweep (response = E0 + Emax*frac). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one mg per second, in SI inside (kg/m3, s). Response systolic blood pressure in mmHg. Driver: terazosin (dose_only).
p.E0 = 0.0;
p.Emax = -10.7;
p.EC50 = 3e-06;
p.gamma = 1.0;
p.slope = 0.0;
p.exposure_per_s = 1e-06;
p.stop_time = 30.0;
p.form = 'E0 + Emax*frac';
end
