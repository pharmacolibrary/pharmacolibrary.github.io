model Terazosin_Sonders1986_reference
  parameter Real Cl_ref = 2.2222222222222223e-05 "Cl [m3/s]";
  parameter Real Vd_ref = 0.025 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.3874329,
    adminMass = 5e-06,
    ka = 0.0001388888888888889,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About terazosin</h4><p>Terazosin is an alpha-blocker used to treat high blood pressure and urinary problems caused by an enlarged prostate, such as difficulty passing urine. It is an approved medicine and is used fairly widely, mainly for benign prostatic enlargement.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q280786\">Wikidata Q280786</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>terazosin</td></tr><tr><td>population:</td><td>human volunteers, hypertensive patients, elderly volunteers, patients with congestive heart failure</td></tr><tr><td>source_paper:</td><td>Sonders_1986</td></tr><tr><td>measured_compound:</td><td>terazosin</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C_enteral: apparent (/F) parameterization ⇒ extravascular dosing</td></tr><tr><td>molar_masses:</td><td>terazosin 387.433 g/mol (drugbank)</td></tr></table><p><b>Defaulted (base-class default used):</b> ka, Tlag.</p><h4>Interpretation flags</h4><ul><li>unit_dimension_unknown: 'ml per minute' (CL/F)</li><li>unit_dimension_unknown: 'ml per minute' (CLR)</li><li>implicit units: 'Plasma clearances' → L/h (from the popPK convention: 'Total clearance (CL/F) in population PK for systemic exposure (AUC) is conventionally expressed in L/h. The value 80 is ')</li><li>implicit units: 'renal clearances' → L/h (from the popPK convention: 'Renal clearance (CLR) is a component of total clearance and shares the same units. The value 10 is consistent with renal')</li><li>apparent-ness (ontology-grounded): parameterization=apparent, measured_compound=terazosin</li><li>structure disagreement: deterministic 1C vs LLM 2C — review compartment count</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 259200, Tolerance = 1e-9, Interval = 1));
end Terazosin_Sonders1986_reference;
