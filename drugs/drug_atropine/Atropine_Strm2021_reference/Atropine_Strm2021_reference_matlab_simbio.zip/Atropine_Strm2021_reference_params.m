function p = Atropine_Strm2021_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: atropine   source: Ström_2021 / reference   route: oral
  p.name  = 'Atropine_Strm2021_reference_params';
  p.drug  = 'atropine';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 45.22;                % central volume [L]
  p.CL = 1.905;                % clearance [L/h]
  p.Vp = [80.36];             % peripheral volumes [L]
  p.Q  = [2.477];             % inter-compartmental clearances [L/h]
  p.ka = 5.948;                % absorption rate [1/h]
  p.F  = 0.685;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 0.14;             % dose [mg]
end
