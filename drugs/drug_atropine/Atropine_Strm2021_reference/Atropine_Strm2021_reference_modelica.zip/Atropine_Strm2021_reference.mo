model Atropine_Strm2021_reference
  parameter Real Cl_ref = 5.291666666666666e-07 "Cl [m3/s]";
  parameter Real Vd_ref = 0.045219999999999996 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C_enteral(
    weight = 70.0,
    F = 0.685,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.2893694,
    adminMass = 1.4e-07,
    ka = 0.0016522222222222222,
    Tlag = 0.0,
    k12 = 1.5215735416973808e-05,
    k21 = 8.562164703279685e-06
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>atropine</td></tr><tr><td>population:</td><td>horses</td></tr><tr><td>source_paper:</td><td>Ström_2021</td></tr><tr><td>measured_compound:</td><td>atropine</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>Tab1</td></tr><tr><td>input:</td><td>PK_2C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>atropine 289.369 g/mol (drugbank)</td></tr></table><p><b>Defaulted (base-class default used):</b> Tlag.</p><h4>Interpretation flags</h4><ul><li>column 'units' classified 'other' by the LLM but kept: the deterministic diagnostic-column test disagrees (a stratum column is a value column, not a statistic)</li><li>unit_dimension_unknown: 'ilogit, eye drop' (Fab)</li><li>unit_dimension_unknown: 'ilogit, infusion' (Fab)</li><li>dropped duplicate Q40 ('tvfINF (ilogit, infusion)', value '0.738') — already have one for this compound</li><li>unit_dimension_unknown: 'terminal phase' (t1/2β)</li><li>unit_dimension_unknown: 'initial phase' (t1/2α)</li><li>unit_dimension_unknown: 'steady-state volume of distribution' (Vss)</li><li>unit_dimension_unknown: 'Mean residence time (IV' (MRT)</li><li>implicit units: 'tvVc' → L/kg (from the paper text: &quot;The abstract states: 'The typical value was 1.7 L/kg for the steady-state volume of distribution.' Since Vss is derived &quot;)</li><li>implicit units: 'tvVt' → L/kg (from the paper text: &quot;The abstract states: 'The typical value was 1.7 L/kg for the steady-state volume of distribution.' Since Vss is derived &quot;)</li><li>implicit units: 'tvCl' → L/h (from the paper text: &quot;The abstract states: 'Total plasma clearance was 1.9 L/h'. The parameter tvCl corresponds to Total clearance (CL).&quot;)</li><li>implicit units: 'tvCld' → L/h (from the popPK convention: 'Intercompartmental clearance (Cld or Q) is a clearance parameter. In population PK, clearances are typically reported in')</li><li>implicit units: 'tvKa' → 1/h (from the popPK convention: 'Absorption rate constant (ka) is a first-order rate constant. The standard unit is 1/h (or h^-1). The magnitude (5.948) ')</li><li>implicit units: 'Half-life_absorption' → h (from the popPK convention: 'Half-life is a time parameter. The standard unit is hours (h). The value 0.117 h is consistent with the absorption half-')</li><li>implicit units: 'Half-life_Beta (terminal phase)' → h (from the popPK convention: 'Terminal half-life is a time parameter. The standard unit is hours (h).')</li><li>implicit units: 'Half-life_alpha (initial phase)' → h (from the popPK convention: 'Initial phase half-life is a time parameter. The standard unit is hours (h).')</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Atropine_Strm2021_reference;
