model Allopurinol_Wen2023_PD_su
  "sigmoid_emax exposure-response sweep — Wen_2023 :: SU (serum urate)"
  extends Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep(
    E0 = 0.09,      // [kg/m3; mg/dL × 0.01]
    Emax = -0.076,  // [kg/m3; mg/dL × 0.01]
    EC50 = 0.0176,  // [kg/m3; mg/L × 0.001]
    gamma = 1,
    exposure_per_s = 0.001);   // 1 mg/L per second
  // imax_as_negative_emax: Imax (Q323) enters SigmoidEmaxSweep as −Emax
  annotation(experiment(StartTime = 0, StopTime = 180, Interval = 0.36),
    Documentation(info = "<html><body><!-- drug-about --><h4>About allopurinol</h4><p>Allopurinol is a medicine used to lower high uric acid levels in the blood, mainly to treat gout and hyperuricemia. It is widely used and appears on the WHO list of essential medicines.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q412486\">Wikidata Q412486</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h4>Allopurinol_Wen2023_PD_su</h4><p>The steady-state exposure-response curve of Wen YF et al., <i>British journal of clinical pharmacology 89(10):2964–2976</i> 2023 (<a href=\"https://doi.org/10.1111/bcp.15792\">doi:10.1111/bcp.15792</a>) — serum urate [mg/dL] against oxypurinol mg/L — obtained by sweeping the driver instead of simulating a dose. Model family: sigmoid_emax.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    =          9 mg/dL    drug-free response (baseline) (BLurate, Q324)
  Emax  =        7.6 mg/dL    maximal effect term (Imax, Q323)
  EC50  =       17.6 mg/L     exposure at half of the maximal effect term (IC50, Q322)
  gamma =          1          Hill coefficient (gamma, Q325)</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep\">SigmoidEmaxSweep</a>; this model only supplies the numbers. The x axis is one mg/L of oxypurinol per second of simulated time (exposure is in kg/m3): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0.09   (drug-free)
  exposure = EC50 (17.6 mg/L)  response 0.052
  exposure -> infinity  response 0.014</pre></body></html>"));
end Allopurinol_Wen2023_PD_su;
