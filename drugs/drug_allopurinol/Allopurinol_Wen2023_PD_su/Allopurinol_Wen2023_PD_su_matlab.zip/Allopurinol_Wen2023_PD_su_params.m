function p = Allopurinol_Wen2023_PD_su_params()
% Allopurinol_Wen2023_PD_su_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% allopurinol Wen_2023::SU: sigmoid_emax exposure-response sweep (response = E0 + Emax*frac). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one mg/L per second, in SI inside (kg/m3, s). Response SU in mg/dL. Driver: oxypurinol (cited_pk).
p.E0 = 0.08999999999999998;
p.Emax = -0.07599999999999998;
p.EC50 = 0.017599999999999998;
p.gamma = 1.0;
p.slope = 0.0;
p.exposure_per_s = 0.001;
p.stop_time = 180.0;
p.form = 'E0 + Emax*frac';
end
