function p = Allopurinol_Chu2022_PD_xanthine_params()
% Allopurinol_Chu2022_PD_xanthine_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% allopurinol Chu_2022::Xanthine: indirect_response_i exposure-response sweep (response = E0*(1 - Emax*frac)). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one mg/L per second, in SI inside (kg/m3, s). Response Xanthine in mg/L. Driver: allopurinol and oxypurinol (conc_no_pk).
p.E0 = 9.999999999999999e-05;
p.Emax = 1.0;
p.EC50 = 0.0003599999999999999;
p.gamma = 1.0;
p.slope = 0.0;
p.exposure_per_s = 0.001;
p.stop_time = 3.6;
p.form = 'E0*(1 - Emax*frac)';
end
