function p = Allopurinol_Graham1996_PD_1mu_1mx_params()
% Allopurinol_Graham1996_PD_1mu_1mx_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% allopurinol Graham_1996::1MU_1MX: sigmoid_emax exposure-response sweep (response = E0 + Emax*frac). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one mg l-1 per second, in SI inside (kg/m3, s). Response 1MU/1MX in its own unit. Driver: oxypurinol (cited_pk).
p.E0 = 2.63;
p.Emax = -2.27;
p.EC50 = 0.004009999999999999;
p.gamma = 8.92;
p.slope = 0.0;
p.exposure_per_s = 0.001;
p.stop_time = 41.0;
p.form = 'E0 + Emax*frac';
end
