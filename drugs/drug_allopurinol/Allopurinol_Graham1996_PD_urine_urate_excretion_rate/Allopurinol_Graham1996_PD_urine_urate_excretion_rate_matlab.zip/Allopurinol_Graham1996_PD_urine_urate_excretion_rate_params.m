function p = Allopurinol_Graham1996_PD_urine_urate_excretion_rate_params()
% Allopurinol_Graham1996_PD_urine_urate_excretion_rate_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% allopurinol Graham_1996::urine_urate_excretion_rate: sigmoid_emax exposure-response sweep (response = E0 + Emax*frac). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one mg l-1 per second, in SI inside (kg/m3, s). Response urine urate excretion rate in mol min-1. Driver: oxypurinol (cited_pk).
p.E0 = 3.53;
p.Emax = -3.26;
p.EC50 = 0.0037399999999999994;
p.gamma = 1.08;
p.slope = 0.0;
p.exposure_per_s = 0.001;
p.stop_time = 38.0;
p.form = 'E0 + Emax*frac';
end
