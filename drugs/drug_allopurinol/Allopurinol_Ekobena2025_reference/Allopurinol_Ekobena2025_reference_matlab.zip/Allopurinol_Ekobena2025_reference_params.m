function p = Allopurinol_Ekobena2025_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: allopurinol   source: Ekobena_2025 / reference   route: oral
  % estimated (absent from source): F
  p.name  = 'Allopurinol_Ekobena2025_reference_params';
  p.drug  = 'allopurinol';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 10.9;                % central volume [L]
  p.CL = 0.46;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.64;                % absorption rate [1/h]
  p.F  = 0.9;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 400.0;             % dose [mg]
end
