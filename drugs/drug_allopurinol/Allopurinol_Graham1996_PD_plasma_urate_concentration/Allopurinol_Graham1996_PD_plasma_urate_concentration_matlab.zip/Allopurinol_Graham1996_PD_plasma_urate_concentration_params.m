function p = Allopurinol_Graham1996_PD_plasma_urate_concentration_params()
% Allopurinol_Graham1996_PD_plasma_urate_concentration_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% allopurinol Graham_1996::plasma_urate_concentration: sigmoid_emax exposure-response sweep (response = E0 + Emax*frac). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one mg l-1 per second, in SI inside (kg/m3, s). Response plasma urate concentration in m. Driver: oxypurinol (cited_pk).
p.E0 = 0.35;
p.Emax = -0.29;
p.EC50 = 0.005559999999999998;
p.gamma = 1.22;
p.slope = 0.0;
p.exposure_per_s = 0.001;
p.stop_time = 56.0;
p.form = 'E0 + Emax*frac';
end
