% run_Allopurinol_Day2007_PD_1_mu_1_mx_5  Evaluate the exposure-response curve and plot response against exposure.
% A sweep is a static map: no ODE solver is needed. exposure runs 0..stop_time*exposure_per_s.
p = Allopurinol_Day2007_PD_1_mu_1_mx_5_params();
exposure = linspace(0, p.stop_time * p.exposure_per_s, 501);
frac = exposure.^p.gamma ./ (p.EC50^p.gamma + exposure.^p.gamma);
E0 = p.E0; Emax = p.Emax; slope = p.slope;
response = E0 + Emax.*frac;
figure; plot(exposure, response, 'LineWidth', 1.5); grid on;
xlabel('exposure [mg/L]'); ylabel('response []'); title('Allopurinol_Day2007_PD_1_mu_1_mx_5', 'Interpreter', 'none');
writematrix([exposure(:) response(:)], 'Allopurinol_Day2007_PD_1_mu_1_mx_5.csv');
