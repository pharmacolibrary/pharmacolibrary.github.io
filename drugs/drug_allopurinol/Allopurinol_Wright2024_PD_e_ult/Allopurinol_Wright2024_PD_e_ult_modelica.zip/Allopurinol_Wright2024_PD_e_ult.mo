model Allopurinol_Wright2024_PD_e_ult
  "sigmoid_emax exposure-response sweep — Wright_2024 :: E ULT (serum urate)"
  extends Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep(
    E0 = 0.55,      // [mol/m3; mmol L À1 × 1]
    Emax = -1,  // [mol/m3; mmol L À1 × 1]
    EC50 = 0.1394,  // [mol/m3; μmol L À1 × 0.001]
    gamma = 1.06,
    exposure_per_s = 0.001);   // 1 μmol L À1 per second
  // imax_as_negative_emax: Imax (Q323) enters SigmoidEmaxSweep as −Emax
  annotation(experiment(StartTime = 0, StopTime = 1400, Interval = 2.8),
    Documentation(info = "<html><body><!-- drug-about --><h4>About allopurinol</h4><p>Allopurinol is a medicine used to lower high uric acid levels in the blood, mainly to treat gout and hyperuricemia. It is widely used and appears on the WHO list of essential medicines.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q412486\">Wikidata Q412486</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h4>Allopurinol_Wright2024_PD_e_ult</h4><p>The steady-state exposure-response curve of Wright DFB et al., <i>British journal of clinical pharmacology 90(5):1268–1279</i> 2024 (<a href=\"https://doi.org/10.1111/bcp.16005\">doi:10.1111/bcp.16005</a>) — serum urate [mmol L À1] against oxypurinol μmol L À1 — obtained by sweeping the driver instead of simulating a dose. Model family: sigmoid_emax.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    =       0.55 mmol L À1 drug-free response (baseline) (E 0 (baseline urate), Q324)
  Emax  =          1 mmol L À1 maximal effect term (I max, Q323)
  EC50  =      139.4 μmol L À1 exposure at half of the maximal effect term (C 50, Q322)
  gamma =       1.06          Hill coefficient (GAM (Hill coefficient), Q325)</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep\">SigmoidEmaxSweep</a>; this model only supplies the numbers. The x axis is one μmol L À1 of oxypurinol per second of simulated time (exposure is in mol/m3): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0.55   (drug-free)
  exposure = EC50 (139.4 μmol L À1)  response 0.05
  exposure -> infinity  response -0.45</pre></body></html>"));
end Allopurinol_Wright2024_PD_e_ult;
