function p = Allopurinol_Wright2024_PD_e_ult_params()
% Allopurinol_Wright2024_PD_e_ult_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% allopurinol Wright_2024::E_ULT: sigmoid_emax exposure-response sweep (response = E0 + Emax*frac). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one μmol L À1 per second, in SI inside (kg/m3, s). Response E ULT in mmol L À1. Driver: oxypurinol (cited_pk).
p.E0 = 0.5499999999999999;
p.Emax = -0.9999999999999999;
p.EC50 = 0.13939999999999997;
p.gamma = 1.06;
p.slope = 0.0;
p.exposure_per_s = 0.001;
p.stop_time = 1400.0;
p.form = 'E0 + Emax*frac';
end
