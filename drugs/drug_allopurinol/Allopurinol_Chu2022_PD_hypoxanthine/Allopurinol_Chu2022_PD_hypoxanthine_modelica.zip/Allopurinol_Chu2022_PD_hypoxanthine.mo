model Allopurinol_Chu2022_PD_hypoxanthine
  "indirect_response_i exposure-response sweep — Chu_2022 :: Hypoxanthine (Hypoxanthine)"
  extends Pharmacolibrary.Interfaces.PartialExposureResponseSweep(
    E0 = 3.6e-05,      // [kg/m3; mg/L × 0.001]
    Emax = 1,  // type I effect term
    EC50 = 0.00036,  // [kg/m3; mg/L × 0.001]
    gamma = 1,
    exposure_per_s = 0.001);   // 1 mg/L per second
equation
  response = E0*(1 - Emax*frac);   // steady state, indirect response type I
  // defaulted: gamma
  annotation(experiment(StartTime = 0, StopTime = 3.6, Interval = 0.0072),
    Documentation(info = "<html><body><!-- drug-about --><h4>About allopurinol</h4><p>Allopurinol is a medicine used to lower high uric acid levels in the blood, mainly to treat gout and hyperuricemia. It is widely used and appears on the WHO list of essential medicines.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q412486\">Wikidata Q412486</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h4>Allopurinol_Chu2022_PD_hypoxanthine</h4><p>The steady-state exposure-response curve of Chu WY et al., <i>Clinical pharmacokinetics 61(2):321–333</i> 2022 (<a href=\"https://doi.org/10.1007/s40262-021-01068-0\">doi:10.1007/s40262-021-01068-0</a>) — Hypoxanthine [mg/L] against allopurinol and oxypurinol mg/L — obtained by sweeping the driver instead of simulating a dose. Model family: indirect_response_i.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    =      0.036 mg/L     drug-free response (baseline) (Hypoxanthine baseline value (EBASE3), Q324)
  Emax  =          1          maximal effect term (Maximum achievable XO inhibition effect (Emax), Q323)
  EC50  =       0.36 mg/L     exposure at half of the maximal effect term (Allopurinol and oxypurinol concentration with 50% of maximum effect on inhibition XO (IC50), Q322)
  gamma = (library default) Hill coefficient</pre><p>The algebra is <code>response = E0*(1 - Emax*frac)</code>; this model only supplies the numbers. The x axis is one mg/L of allopurinol and oxypurinol per second of simulated time (exposure is in kg/m3): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 3.6e-05   (drug-free)
  exposure = EC50 (0.36 mg/L)  response 1.8e-05
  exposure -> infinity  response 0</pre></body></html>"));
end Allopurinol_Chu2022_PD_hypoxanthine;
