model Allopurinol_Liu2026_reference
  parameter Real Cl_ref = 2.0361111111111113e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.181 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.1361115,
    adminMass = 0.0004,
    ka = 4.4444444444444447e-05,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About allopurinol</h4><p>Allopurinol is a medicine used to lower high uric acid levels in the blood, mainly to treat gout and hyperuricemia. It is widely used and appears on the WHO list of essential medicines.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q412486\">Wikidata Q412486</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>allopurinol</td></tr><tr><td>population:</td><td>review reference</td></tr><tr><td>source_paper:</td><td>Liu_2026</td></tr><tr><td>measured_compound:</td><td>allopurinol</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>allopurinol 136.112 g/mol (drugbank)</td></tr></table><p><b>Defaulted (base-class default used):</b> Tlag.</p><h4>Interpretation flags</h4><ul><li>built from REVIEW reference values (Liu_2026) — secondary source</li><li>volume reported by review</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 432000, Tolerance = 1e-9, Interval = 1));
end Allopurinol_Liu2026_reference;
