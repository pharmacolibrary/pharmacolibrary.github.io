model Rifabutin_Chang2023v2_PD_cfu_lung
  "linear exposure-response sweep — Chang_2023_2 :: CFU/lung (M. tuberculosis lung burden)"
  extends Pharmacolibrary.Interfaces.PartialExposureResponseSweep(
    E0 = 4.46,      // [log10 CFU/lung]
    Emax = 0, EC50 = 1,      // unused by a line
    exposure_per_s = 0.001);
  parameter Real slope = -0.09   "[wk−1]";
equation
  response = E0 + slope*exposure;
  annotation(experiment(StartTime = 0, StopTime = 1000, Interval = 2),
    Documentation(info = "<html><body><!-- drug-about --><h4>About rifabutin</h4><p>Rifabutin is an antibiotic used to treat tuberculosis and infections caused by Mycobacterium avium-intracellulare. It is an approved medicine and is included on the WHO list of essential medicines, and is also used in combination therapy for eradicating Helicobacter pylori.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q1135705\">Wikidata Q1135705</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h4>Rifabutin_Chang2023v2_PD_cfu_lung</h4><p>The steady-state exposure-response curve of Chang YS et al., <i>Antimicrobial agents and chemotherapy 67(7):e0048123</i> 2023 (<a href=\"https://doi.org/10.1128/aac.00481-23\">doi:10.1128/aac.00481-23</a>) — M. tuberculosis lung burden [log10 CFU/lung] against rifabutin μg/mL — obtained by sweeping the driver instead of simulating a dose. Model family: linear.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    =       4.46 log10 CFU/lung drug-free response (baseline) (Initial log10 CFU/lung, Q324)
  slope =      -0.09 wk−1     change in response per unit of exposure (knet, Q335)</pre><p>The algebra is <code>response = E0 + slope*exposure</code>; this model only supplies the numbers. The x axis is one μg/mL of rifabutin per second of simulated time (exposure is in kg/m3): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 4.46   (drug-free)</pre></body></html>"));
end Rifabutin_Chang2023v2_PD_cfu_lung;
