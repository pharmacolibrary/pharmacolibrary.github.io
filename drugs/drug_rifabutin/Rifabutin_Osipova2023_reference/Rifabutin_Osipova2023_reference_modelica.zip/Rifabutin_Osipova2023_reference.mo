model Rifabutin_Osipova2023_reference
  parameter Real Cl_ref = 1.5258333333333333e-08 "Cl [m3/s]";
  parameter Real Vd_ref = 0.00069684 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.8470046999999999,
    adminMass = 0.0004375
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>rifabutin</td></tr><tr><td>population:</td><td>review reference</td></tr><tr><td>source_paper:</td><td>Osipova_2023</td></tr><tr><td>measured_compound:</td><td>rifabutin</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>rifabutin 847.005 g/mol (drugbank)</td></tr></table><h4>Interpretation flags</h4><ul><li>built from REVIEW reference values (Osipova_2023) — secondary source</li><li>volume reported by review</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 158400, Tolerance = 1e-9, Interval = 1));
end Rifabutin_Osipova2023_reference;
