model Rifabutin_Bentley2021_reference
  parameter Real Cl_ref = 2.3416666666666666e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.186 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.8470046999999999,
    adminMass = 0.00015,
    ka = 4.4444444444444447e-05,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About rifabutin</h4><p>Rifabutin is an antibiotic used to treat tuberculosis and infections caused by Mycobacterium avium-intracellulare. It is an approved medicine and is included on the WHO list of essential medicines, and is also used in combination therapy for eradicating Helicobacter pylori.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q1135705\">Wikidata Q1135705</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>rifabutin</td></tr><tr><td>population:</td><td>review reference</td></tr><tr><td>source_paper:</td><td>Bentley_2021</td></tr><tr><td>measured_compound:</td><td>rifabutin</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>rifabutin 847.005 g/mol (drugbank)</td></tr></table><p><b>Defaulted (base-class default used):</b> Tlag.</p><h4>Interpretation flags</h4><ul><li>built from REVIEW reference values (Bentley_2021) — secondary source</li><li>volume reported by review</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 345600, Tolerance = 1e-9, Interval = 1));
end Rifabutin_Bentley2021_reference;
