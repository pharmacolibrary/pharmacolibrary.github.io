model Tramadol_Pypendop2008_reference
  parameter Real Cl_ref = 2.426666666666667e-05 "Cl [m3/s]";
  parameter Real Vd_ref = 0.10870999999999999 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.263381,
    adminMass = 0.0003,
    ka = 0.00018055555555555557,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About tramadol</h4><p>Tramadol is an opioid painkiller used to treat pain. It is an approved medicine and is widely used, available both alone and in combination with non-opioid analgesics.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q407592\">Wikidata Q407592</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>tramadol</td></tr><tr><td>population:</td><td>cats</td></tr><tr><td>source_paper:</td><td>Pypendop_2008</td></tr><tr><td>measured_compound:</td><td>tramadol</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>tramadol 263.381 g/mol (drugbank)</td></tr></table><p><b>Defaulted (base-class default used):</b> Tlag.</p><h4>Interpretation flags</h4><ul><li>dropped duplicate Q57 ('terminal half-life after oral administration', value 204) — already have one for this compound</li><li>dropped duplicate Q57 ('terminal half-lives of O-desmethyl-tramadol after i.v.', value 261) — already have one for this compound</li><li>dropped unlinked row (NIL): 'rate of formation of O-desmethyl-tramadol estimated from a model including both tramadol and O-desmethyl-tramadol after i.v.' — extend the ontology if this is a real PK parameter (source ['Pypendop_2008:abstract', 'Pypendop_2008:abstract'])</li><li>apparent-ness (ontology-grounded): parameterization=apparent, measured_compound=tramadol</li><li>held at status:extracted — NIL link or unit issue (mismatch/unknown/normalisation-failed) present</li><li>status held at route_to_review — not promoted</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li><li>skipped review gap-fill of V2: primary is PARENT_METABOLITE (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is PARENT_METABOLITE (peripheral family needs ≥2C)</li><li>gap-filled Q49 (kabs) from Ekstrand_2026's review values (primary lacked it)</li><li>engineer: parent → metabolite not buildable on PK_3M_9C (None) — the measured compound's 1-compartment model instead</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Tramadol_Pypendop2008_reference;
