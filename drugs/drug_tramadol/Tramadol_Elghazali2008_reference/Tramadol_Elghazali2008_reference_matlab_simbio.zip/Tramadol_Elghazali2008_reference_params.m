function p = Tramadol_Elghazali2008_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: tramadol   source: Elghazali_2008 / reference   route: oral
  % estimated (absent from source): F
  p.name  = 'Tramadol_Elghazali2008_reference_params';
  p.drug  = 'tramadol';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 625.8;                % central volume [L]
  p.CL = 1.94;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.65;                % absorption rate [1/h]
  p.F  = 0.9;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 300.0;             % dose [mg]
end
