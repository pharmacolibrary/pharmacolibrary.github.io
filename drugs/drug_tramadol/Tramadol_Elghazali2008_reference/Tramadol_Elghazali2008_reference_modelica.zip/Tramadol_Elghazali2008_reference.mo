model Tramadol_Elghazali2008_reference
  parameter Real Cl_ref = 5.388888888888888e-07 "Cl [m3/s]";
  parameter Real Vd_ref = 0.6258 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 101.62,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.263381,
    adminMass = 0.0003,
    ka = 0.00018055555555555557,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About tramadol</h4><p>Tramadol is an opioid painkiller used to treat pain. It is an approved medicine and is widely used, available both alone and in combination with non-opioid analgesics.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q407592\">Wikidata Q407592</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>tramadol</td></tr><tr><td>population:</td><td>camels</td></tr><tr><td>source_paper:</td><td>Elghazali_2008</td></tr><tr><td>measured_compound:</td><td>tramadol</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>tramadol 263.381 g/mol (drugbank)</td></tr></table><p><b>Defaulted (base-class default used):</b> Tlag.</p><h4>Interpretation flags</h4><ul><li>unit_dimension_unknown: 'L h kg(-1)' (CL)</li><li>unit_dimension_unknown: 'mg h L(-1)' (AUC∞)</li><li>dropped duplicate Q60 ('(t(1/2)(beta))', value 3.24) — already have one for this compound</li><li>unit_dimension_unknown: 'mg h L(-1)' (AUC∞)</li><li>dropped duplicate Q17 ('(AUC(0-infinity))', value 1.27) — already have one for this compound</li><li>dropped unlinked row (NIL): 'urinary detection times for tramadol' — extend the ontology if this is a real PK parameter (source ['Elghazali_2008:abstract'])</li><li>dropped unlinked row (NIL): 'urinary detection times for O-desmethyltramadol' — extend the ontology if this is a real PK parameter (source ['Elghazali_2008:abstract'])</li><li>implicit units: 'total body clearance (Cl(T))' → L/h (from the popPK convention: 'Total body clearance is conventionally expressed in L/h in population PK studies, and the value 1.94 is consistent with ')</li><li>implicit units: 'area under the concentration vs. time curve (AUC(0-infinity))' → mg*h/L (from the popPK convention: 'AUC is conventionally expressed as concentration multiplied by time (e.g., mg*h/L). The value 1.25 is consistent with th')</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=tramadol</li><li>held at status:extracted — NIL link or unit issue (mismatch/unknown/normalisation-failed) present</li><li>structure disagreement: deterministic 1C vs LLM 2C — review compartment count</li><li>status held at route_to_review — not promoted</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Tramadol_Elghazali2008_reference;
