function p = Tramadol_Hannam2018_PD_parent_s_postoperative_pain_measureme_params()
% Tramadol_Hannam2018_PD_parent_s_postoperative_pain_measureme_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% tramadol Hannam_2018::Parent_s_Postoperative_Pain_Measurement: sigmoid_emax exposure-response sweep (response = E0 + Emax*frac). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one mg/L per second, in SI inside (kg/m3, s). Response Parent's Postoperative Pain Measurement in pain units. Driver: acetaminophen, ibuprofen, tramadol (pk_record).
p.E0 = 0.0;
p.Emax = -0.648;
p.EC50 = 0.007059999999999999;
p.gamma = 1.48;
p.slope = 0.0;
p.exposure_per_s = 0.001;
p.stop_time = 71.0;
p.form = 'E0 + Emax*frac';
end
