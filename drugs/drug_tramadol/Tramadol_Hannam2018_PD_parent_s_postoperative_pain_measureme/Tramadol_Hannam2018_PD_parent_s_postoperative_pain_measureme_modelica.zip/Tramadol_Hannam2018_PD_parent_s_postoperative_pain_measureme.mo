model Tramadol_Hannam2018_PD_parent_s_postoperative_pain_measureme
  "sigmoid_emax exposure-response sweep — Hannam_2018 :: Parent's Postoperative Pain Measurement (name)"
  extends Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep(
    E0 = 0.0,      // [1]
    Emax = -0.648,  // [pain units]
    EC50 = 0.007059999999999999,  // [kg/m3; mg/L × 0.001]
    gamma = 1.48,
    exposure_per_s = 0.0009999999999999998);   // 1 mg/L per second
  // inhibition_sign: effect_direction=inhibition with a positive Emax (Q320) — sign flipped
  // defaulted: E0
  annotation(experiment(StartTime = 0, StopTime = 70.6, Interval = 0.1412));
end Tramadol_Hannam2018_PD_parent_s_postoperative_pain_measureme;
