model Canakinumab_Krause2014_PD_pflare
  "sigmoid_emax exposure-response sweep — Krause_2014 :: Pflare (probability of a flare in inflammatory symptoms)"
  extends Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep(
    E0 = 25,      // [Base effect]
    Emax = -50,  // [Maximum effect]
    EC50 = 0.00113,  // [kg/m3; µg/mL × 0.001]
    gamma = 4.22,
    exposure_per_s = 0.001);   // 1 µg/mL per second
  // inhibition_sign: effect_direction=inhibition with a positive Emax (Q320) — sign flipped
  annotation(experiment(StartTime = 0, StopTime = 12, Interval = 0.024),
    Documentation(info = "<html><body><!-- drug-about --><h4>About canakinumab</h4><p>Canakinumab is a monoclonal antibody that blocks interleukin signalling and is used to treat Cryopyrin-Associated Periodic Syndromes and juvenile idiopathic arthritis, with investigational use in gouty arthritis and cardiovascular conditions such as acute coronary syndrome. It is authorised in the European Union.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q3655009\">Wikidata Q3655009</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h4>Canakinumab_Krause2014_PD_pflare</h4><p>The steady-state exposure-response curve of Krause A et al., <i>CPT: pharmacometrics &amp; systems pharmacology 3:e116</i> 2014 (<a href=\"https://doi.org/10.1038/psp.2014.13\">doi:10.1038/psp.2014.13</a>) — probability of a flare in inflammatory symptoms against canakinumab µg/mL — obtained by sweeping the driver instead of simulating a dose. Model family: sigmoid_emax.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    =         25 Base effect drug-free response (baseline) (E0, Q324)
  Emax  =         50 Maximum effect maximal effect term (Emax, Q320)
  EC50  =       1.13 µg/mL    exposure at half of the maximal effect term (KIEFmean, Q322)
  gamma =       4.22          Hill coefficient (HILL, Q325)</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep\">SigmoidEmaxSweep</a>; this model only supplies the numbers. The x axis is one µg/mL of canakinumab per second of simulated time (exposure is in kg/m3): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 25   (drug-free)
  exposure = EC50 (1.13 µg/mL)  response 0
  exposure -> infinity  response -25</pre></body></html>"));
end Canakinumab_Krause2014_PD_pflare;
