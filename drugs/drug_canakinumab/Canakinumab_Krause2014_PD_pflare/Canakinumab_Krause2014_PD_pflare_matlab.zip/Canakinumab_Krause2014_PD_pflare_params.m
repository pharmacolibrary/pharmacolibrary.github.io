function p = Canakinumab_Krause2014_PD_pflare_params()
% Canakinumab_Krause2014_PD_pflare_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% canakinumab Krause_2014::Pflare: sigmoid_emax exposure-response sweep (response = E0 + Emax*frac). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one µg/mL per second, in SI inside (kg/m3, s). Response Pflare in its own unit. Driver: canakinumab (cited_pk).
p.E0 = 25.0;
p.Emax = -50.0;
p.EC50 = 0.0011299999999999997;
p.gamma = 4.22;
p.slope = 0.0;
p.exposure_per_s = 0.001;
p.stop_time = 12.0;
p.form = 'E0 + Emax*frac';
end
