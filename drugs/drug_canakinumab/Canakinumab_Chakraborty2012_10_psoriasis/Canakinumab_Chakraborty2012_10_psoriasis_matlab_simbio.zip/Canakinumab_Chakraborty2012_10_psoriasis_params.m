function p = Canakinumab_Chakraborty2012_10_psoriasis_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: canakinumab   source: Chakraborty_2012 / 10_psoriasis   route: oral
  p.name  = 'Canakinumab_Chakraborty2012_10_psoriasis_params';
  p.drug  = 'canakinumab';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 15.0;                % central volume [L]
  p.CL = 0.017917;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.38;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 140.0;             % dose [mg]
end
