model Canakinumab_Chakraborty2012_2_paediatric_caps
  parameter Real Cl_ref = 2.6851851851851853e-09 "Cl [m3/s]";
  parameter Real Vd_ref = 0.00767 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    adminMass = 0.00014,
    ka = 0.00010555555555555555,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About canakinumab</h4><p>Canakinumab is a monoclonal antibody that blocks interleukin signalling and is used to treat Cryopyrin-Associated Periodic Syndromes and juvenile idiopathic arthritis, with investigational use in gouty arthritis and cardiovascular conditions such as acute coronary syndrome. It is authorised in the European Union.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q3655009\">Wikidata Q3655009</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>canakinumab</td></tr><tr><td>population:</td><td>CAPS patients</td></tr><tr><td>source_paper:</td><td>Chakraborty_2012</td></tr><tr><td>measured_compound:</td><td>canakinumab</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>Table IV Population pharmacokinetic-binding model estimated parameters</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr></table><p><b>Defaulted (base-class default used):</b> Tlag.</p><h4>Interpretation flags</h4><ul><li>column '2 (paediatric caps)' classified 'other' by the LLM but kept: the deterministic diagnostic-column test disagrees (a stratum column is a value column, not a statistic)</li><li>column '2 (paediatric caps)' classified 'other' by the LLM but kept: the deterministic diagnostic-column test disagrees (a stratum column is a value column, not a statistic)</li><li>column '2 (paediatric caps)' classified 'other' by the LLM but kept: the deterministic diagnostic-column test disagrees (a stratum column is a value column, not a statistic)</li><li>column '2 (paediatric caps)' classified 'other' by the LLM but kept: the deterministic diagnostic-column test disagrees (a stratum column is a value column, not a statistic)</li><li>apparent-ness (ontology-grounded): parameterization=apparent, measured_compound=canakinumab</li><li>population split: '2 (paediatric caps)' subgroup of Chakraborty_2012 (paper reports 17 populations: 10 (psoriasis), 2 (paediatric caps), 20 (asthmatic), 20 (ra), 25 (adult caps), 3 (paediatric caps), 4 (adult caps), 5 (healthy), 5 (ra), 6 (healthy), 6 (ra), human, marmoset monkey, mouse, population mean [θ ± se of θ], population mean [θ±se of θ], rhesus monkey)</li><li>molar mass: none found for 'canakinumab' — its concentrations stay mass-only</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li><li>gap-filled Q49 (kabs) from Urien_2013's review values (primary lacked it)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 10281600, Tolerance = 1e-9, Interval = 1));
end Canakinumab_Chakraborty2012_2_paediatric_caps;
