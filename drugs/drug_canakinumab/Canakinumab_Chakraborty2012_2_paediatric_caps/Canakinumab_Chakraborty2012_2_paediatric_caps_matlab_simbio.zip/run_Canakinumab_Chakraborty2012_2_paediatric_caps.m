% Run (SimBiology): build model + dose, simulate 0..2856.0 h, plot.
p = Canakinumab_Chakraborty2012_2_paediatric_caps_params();
[model, dose, variant] = build_sb_pk(p);
sd = simulate_sb(model, variant, dose, 2856.0);
