function p = Canakinumab_Chakraborty2012_20_asthmatic_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: canakinumab   source: Chakraborty_2012 / 20_asthmatic   route: oral
  p.name  = 'Canakinumab_Chakraborty2012_20_asthmatic_params';
  p.drug  = 'canakinumab';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 5.64;                % central volume [L]
  p.CL = 0.0065;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.38;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 140.0;             % dose [mg]
end
