function p = Canakinumab_Chakraborty2012_5_ra_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: canakinumab   source: Chakraborty_2012 / 5_ra   route: oral
  p.name  = 'Canakinumab_Chakraborty2012_5_ra_params';
  p.drug  = 'canakinumab';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 7.89;                % central volume [L]
  p.CL = 0.011792;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.38;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 140.0;             % dose [mg]
end
