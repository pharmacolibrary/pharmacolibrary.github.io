function p = Canakinumab_Chakraborty2012_population_mean_se_of_2_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: canakinumab   source: Chakraborty_2012 / population_mean_se_of_2   route: oral
  % estimated (absent from source): F
  p.name  = 'Canakinumab_Chakraborty2012_population_mean_se_of_2_params';
  p.drug  = 'canakinumab';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 3.3;                % central volume [L]
  p.CL = 0.005708;                % clearance [L/h]
  p.Vp = [2.71];             % peripheral volumes [L]
  p.Q  = [0.00725];             % inter-compartmental clearances [L/h]
  p.ka = 0.38;                % absorption rate [1/h]
  p.F  = 0.9;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 140.0;             % dose [mg]
end
