model Idarubicin_Tamura1996_reference
  parameter Real Cl_ref = 2.286111111111111e-05 "Cl [m3/s]";
  parameter Real Vd_ref = 0.9349 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.4974939,
    adminMass = 1e-05
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About idarubicin</h4><p>Idarubicin is an anthracycline antibiotic used to treat cancers, mainly acute myeloid leukemia and other leukemias, as well as breast cancer. It is an approved anticancer medicine, used mainly in hospital settings for leukemia treatment.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q1063862\">Wikidata Q1063862</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>idarubicin</td></tr><tr><td>population:</td><td>patients with acute leukemia or chronic myelogenous leukemia in blastic crisis</td></tr><tr><td>source_paper:</td><td>Tamura_1996</td></tr><tr><td>measured_compound:</td><td>idarubicin</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>idarubicin 497.494 g/mol (drugbank)</td></tr></table><h4>Interpretation flags</h4><ul><li>dropped value-less row: 'terminal half-life (t1/2) values for IDA in plasma'</li><li>dropped value-less row: 't1/2 values for IDA in blood cells'</li><li>dropped value-less row: 't1/2 values for idarubicinol in plasma'</li><li>dropped value-less row: 't1/2 values for idarubicinol in blood cells'</li><li>dropped value-less row: 'AUC of idarubicinol in plasma'</li><li>dropped value-less row: 'AUC of idarubicinol in blood cells'</li><li>dropped value-less row: 'dosage range'</li><li>unit_dimension_unknown: 'L/m2' (Vss)</li><li>unit_dimension_unknown: 'L/h/m2' (CL)</li><li>implicit units: 'steady-state volume of distribution (Vdss)' → L (from the popPK convention: 'Steady-state volume of distribution is conventionally reported in L; 934.9 is consistent with a volume in L.')</li><li>implicit units: 'plasma clearance' → L/h (from the popPK convention: 'Plasma clearance is conventionally reported in L/h; 82.3 is consistent with clearance in L/h.')</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=idarubicin</li><li>structure disagreement: deterministic 1C vs LLM 2C — review compartment count</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 169200, Tolerance = 1e-9, Interval = 1));
end Idarubicin_Tamura1996_reference;
