function p = Idarubicin_Tamura1996_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: idarubicin   source: Tamura_1996 / reference   route: iv_bolus
  % estimated (absent from source): F, dose
  % Vc is the record's Vss — no central volume was reported; 1-compartment reading
  p.name  = 'Idarubicin_Tamura1996_reference_params';
  p.drug  = 'idarubicin';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'iv_bolus';        % 'oral' | 'iv_bolus'
  p.depot = false;             % oral -> first-order absorption depot
  p.Vc = 934.9;                % central volume [L]
  p.CL = 82.3;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.0;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 10.0;             % dose [mg]
end
