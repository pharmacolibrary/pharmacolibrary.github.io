model Idarubicin_Kuhlmann2001_reference
  parameter Real Cl_ref = 4.5e-07 "Cl [m3/s]";
  parameter Real Vd_ref = 0.01251 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.4974939,
    adminMass = 1e-05
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About idarubicin</h4><p>Idarubicin is an anthracycline antibiotic used to treat cancers, mainly acute myeloid leukemia and other leukemias, as well as breast cancer. It is an approved anticancer medicine, used mainly in hospital settings for leukemia treatment.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q1063862\">Wikidata Q1063862</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>idarubicin</td></tr><tr><td>population:</td><td>rats</td></tr><tr><td>source_paper:</td><td>Kuhlmann_2001</td></tr><tr><td>measured_compound:</td><td>idarubicin</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>idarubicin 497.494 g/mol (drugbank)</td></tr></table><h4>Interpretation flags</h4><ul><li>implicit units: 'Vss' → L (from the popPK convention: 'Vss is a volume of distribution; population PK volumes are commonly reported in L, and 12.51 is consistent with that uni')</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=idarubicin</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 97200, Tolerance = 1e-9, Interval = 1));
end Idarubicin_Kuhlmann2001_reference;
