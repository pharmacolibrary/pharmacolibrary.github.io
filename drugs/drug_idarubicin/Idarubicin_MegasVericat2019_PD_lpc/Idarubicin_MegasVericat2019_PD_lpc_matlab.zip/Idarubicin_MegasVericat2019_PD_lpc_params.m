function p = Idarubicin_MegasVericat2019_PD_lpc_params()
% Idarubicin_MegasVericat2019_PD_lpc_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% idarubicin Megías-Vericat_2019::LPC: sigmoid_emax exposure-response sweep (response = E0 + Emax*frac). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one μM per second, in SI inside (kg/m3, s). Response LPC in cells. Driver: idarubicin (cited_pk).
p.E0 = 8384.0;
p.Emax = -1.0;
p.EC50 = 0.07;
p.gamma = 1.04;
p.slope = 0.0;
p.exposure_per_s = 1.0;
p.stop_time = 0.7;
p.form = 'E0 + Emax*frac';
end
