model Cefoxitin_Chabert2022_reference
  parameter Real Cl_ref = 6.61111111111111e-07 "Cl [m3/s]";
  parameter Real Vd_ref = 0.0195 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.427452,
    adminMass = 0.006
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About cefoxitin</h4><p>Cefoxitin is a second-generation cephalosporin antibiotic used to treat bacterial infections such as staphylococcal infections, abscesses, sepsis, urinary tract infections, and peritonitis. It is an approved antibiotic used for systemic treatment of bacterial infections, though it carries a boxed warning.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q2353907\">Wikidata Q2353907</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>cefoxitin</td></tr><tr><td>population:</td><td>review reference</td></tr><tr><td>source_paper:</td><td>Chabert_2022</td></tr><tr><td>measured_compound:</td><td>cefoxitin</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>cefoxitin 427.452 g/mol (drugbank)</td></tr></table><h4>Interpretation flags</h4><ul><li>built from REVIEW reference values (Chabert_2022) — secondary source</li><li>volume reported by review</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 104400, Tolerance = 1e-9, Interval = 1));
end Cefoxitin_Chabert2022_reference;
