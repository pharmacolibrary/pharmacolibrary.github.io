function p = Cefoxitin_Ferro2015_PD_m_fortuitum_kill_rate_params()
% Cefoxitin_Ferro2015_PD_m_fortuitum_kill_rate_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% cefoxitin Ferro_2015::M_fortuitum_kill_rate: sigmoid_emax exposure-response sweep (response = E0 + Emax*frac). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one mg/L per second, in SI inside (kg/m3, s). Response M. fortuitum kill rate in h-1. Driver: cefoxitin (cited_pk).
p.E0 = 0.0;
p.Emax = -3.463888888888889e-05;
p.EC50 = 0.018239999999999996;
p.gamma = 1.416;
p.slope = 0.0;
p.exposure_per_s = 0.001;
p.stop_time = 190.0;
p.form = 'E0 + Emax*frac';
end
