% run_Cefoxitin_Ferro2015_PD_m_fortuitum_kill_rate  Evaluate the exposure-response curve and plot response against exposure.
% A sweep is a static map: no ODE solver is needed. exposure runs 0..stop_time*exposure_per_s.
p = Cefoxitin_Ferro2015_PD_m_fortuitum_kill_rate_params();
exposure = linspace(0, p.stop_time * p.exposure_per_s, 501);
frac = exposure.^p.gamma ./ (p.EC50^p.gamma + exposure.^p.gamma);
E0 = p.E0; Emax = p.Emax; slope = p.slope;
response = E0 + Emax.*frac;
figure; plot(exposure, response, 'LineWidth', 1.5); grid on;
xlabel('exposure [mg/L]'); ylabel('response [h-1]'); title('Cefoxitin_Ferro2015_PD_m_fortuitum_kill_rate', 'Interpreter', 'none');
writematrix([exposure(:) response(:)], 'Cefoxitin_Ferro2015_PD_m_fortuitum_kill_rate.csv');
