model Cefoxitin_Ferro2015_PD_m_fortuitum_kill_rate
  "sigmoid_emax exposure-response sweep — Ferro_2015 :: M. fortuitum kill rate (M. fortuitum kill rate)"
  extends Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep(
    E0 = 0,      // [1]
    Emax = -3.46388888889e-05,  // [1/s; h-1 × 0.000277778]
    EC50 = 0.01824,  // [kg/m3; mg/L × 0.001]
    gamma = 1.416,
    exposure_per_s = 0.001);   // 1 mg/L per second
  // imax_as_negative_emax: Imax (Q323) enters SigmoidEmaxSweep as −Emax
  // defaulted: E0
  annotation(experiment(StartTime = 0, StopTime = 190, Interval = 0.38),
    Documentation(info = "<html><body><!-- drug-about --><h4>About cefoxitin</h4><p>Cefoxitin is a second-generation cephalosporin antibiotic used to treat bacterial infections such as staphylococcal infections, abscesses, sepsis, urinary tract infections, and peritonitis. It is an approved antibiotic used for systemic treatment of bacterial infections, though it carries a boxed warning.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q2353907\">Wikidata Q2353907</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h4>Cefoxitin_Ferro2015_PD_m_fortuitum_kill_rate</h4><p>The steady-state exposure-response curve of Ferro BE et al., <i>The Journal of antimicrobial chemotherapy 70(3):811–817</i> 2015 (<a href=\"https://doi.org/10.1093/jac/dku431\">doi:10.1093/jac/dku431</a>) — M. fortuitum kill rate [h-1] against cefoxitin mg/L — obtained by sweeping the driver instead of simulating a dose. Model family: sigmoid_emax.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = (library default) drug-free response (baseline)
  Emax  =     0.1247 h-1      maximal effect term (Emax, Q323)
  EC50  =      18.24 mg/L     exposure at half of the maximal effect term (EC50, Q321)
  gamma =      1.416          Hill coefficient (Hill's slope, Q325)</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep\">SigmoidEmaxSweep</a>; this model only supplies the numbers. The x axis is one mg/L of cefoxitin per second of simulated time (exposure is in kg/m3): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0   (drug-free)
  exposure = EC50 (18.24 mg/L)  response -1.732e-05
  exposure -> infinity  response -3.464e-05</pre></body></html>"));
end Cefoxitin_Ferro2015_PD_m_fortuitum_kill_rate;
