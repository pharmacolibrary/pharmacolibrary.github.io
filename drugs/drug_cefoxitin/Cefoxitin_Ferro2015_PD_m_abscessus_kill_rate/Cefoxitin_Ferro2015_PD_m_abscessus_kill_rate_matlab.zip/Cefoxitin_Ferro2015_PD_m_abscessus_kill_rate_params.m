function p = Cefoxitin_Ferro2015_PD_m_abscessus_kill_rate_params()
% Cefoxitin_Ferro2015_PD_m_abscessus_kill_rate_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% cefoxitin Ferro_2015::M_abscessus_kill_rate: sigmoid_emax exposure-response sweep (response = E0 + Emax*frac). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one mg/L per second, in SI inside (kg/m3, s). Response M. abscessus kill rate in h-1. Driver: cefoxitin (cited_pk).
p.E0 = 0.0;
p.Emax = -3.944444444444445e-06;
p.EC50 = 0.006239999999999999;
p.gamma = 3.534;
p.slope = 0.0;
p.exposure_per_s = 0.001;
p.stop_time = 63.0;
p.form = 'E0 + Emax*frac';
end
