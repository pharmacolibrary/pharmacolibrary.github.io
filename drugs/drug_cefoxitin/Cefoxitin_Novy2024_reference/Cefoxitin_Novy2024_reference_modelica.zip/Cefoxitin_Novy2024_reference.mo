model Cefoxitin_Novy2024_reference
  parameter Real Cl_ref = 3.0277777777777776e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.0234 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 0.9,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.427452,
    adminMass = 0.0001,
    ka = 0.0027166666666666663,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About cefoxitin</h4><p>Cefoxitin is a second-generation cephalosporin antibiotic used to treat bacterial infections such as staphylococcal infections, abscesses, sepsis, urinary tract infections, and peritonitis. It is an approved antibiotic used for systemic treatment of bacterial infections, though it carries a boxed warning.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q2353907\">Wikidata Q2353907</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>cefoxitin</td></tr><tr><td>population:</td><td>obese patients undergoing elective bariatric surgery</td></tr><tr><td>source_paper:</td><td>Novy_2024</td></tr><tr><td>measured_compound:</td><td>cefoxitin</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>cefoxitin 427.452 g/mol (drugbank)</td></tr></table><p><b>Defaulted (base-class default used):</b> F, Tlag.</p><h4>Interpretation flags</h4><ul><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=cefoxitin</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li><li>gap-filled Q49 (kabs) from Roelofsen_2022's review values (primary lacked it)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Cefoxitin_Novy2024_reference;
