model Sotatercept_AitOudhia2025_PD_pvr
  "linear exposure-response sweep — Ait-Oudhia_2025 :: PVR (pulmonary vascular resistance)"
  extends Pharmacolibrary.Interfaces.PartialExposureResponseSweep(
    E0 = 719.9,      // [dynes.s/cm5]
    Emax = 0, EC50 = 1,      // unused by a line
    exposure_per_s = 1e-06);
  parameter Real slope = -0.05164   "[1]";
equation
  response = E0 + slope*exposure;
  annotation(experiment(StartTime = 0, StopTime = 1000, Interval = 2),
    Documentation(info = "<html><body><!-- drug-about --><h4>About sotatercept</h4><p>Sotatercept is a fusion-protein medication used to treat pulmonary arterial hypertension. It is an approved drug and is used for pulmonary hypertension, classified among antihypertensives for pulmonary arterial hypertension.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q103815273\">Wikidata Q103815273</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h4>Sotatercept_AitOudhia2025_PD_pvr</h4><p>The steady-state exposure-response curve of Ait-Oudhia S et al., <i>Clinical pharmacology and therapeutics 117(3):798–807</i> 2025 (<a href=\"https://doi.org/10.1002/cpt.3524\">doi:10.1002/cpt.3524</a>) — pulmonary vascular resistance [dynes.s/cm5] against sotatercept ng/mL — obtained by sweeping the driver instead of simulating a dose. Model family: linear.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    =      719.9 dynes.s/cm5 drug-free response (baseline) (Baseline PVR, Q324)
  slope =   -0.05164          change in response per unit of exposure (Power for average sotatercept concentration, Q335)</pre><p>The algebra is <code>response = E0 + slope*exposure</code>; this model only supplies the numbers. The x axis is one ng/mL of sotatercept per second of simulated time (exposure is in kg/m3): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 719.9   (drug-free)</pre></body></html>"));
end Sotatercept_AitOudhia2025_PD_pvr;
