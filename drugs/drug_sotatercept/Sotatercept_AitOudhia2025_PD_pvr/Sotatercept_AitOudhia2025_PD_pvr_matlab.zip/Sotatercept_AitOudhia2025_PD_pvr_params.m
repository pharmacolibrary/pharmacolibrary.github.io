function p = Sotatercept_AitOudhia2025_PD_pvr_params()
% Sotatercept_AitOudhia2025_PD_pvr_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% sotatercept Ait-Oudhia_2025::PVR: linear exposure-response sweep (response = E0 + slope*exposure). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one ng/mL per second, in SI inside (kg/m3, s). Response PVR in dynes.s/cm5. Driver: sotatercept (cited_pk).
p.E0 = 719.9;
p.Emax = 0.0;
p.EC50 = 1.0;
p.gamma = 1.0;
p.slope = -0.05164;
p.exposure_per_s = 1e-06;
p.stop_time = 1000.0;
p.form = 'E0 + slope*exposure';
end
