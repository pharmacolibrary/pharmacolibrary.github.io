function p = Sotatercept_AitOudhia2025_PD_hgb_params()
% Sotatercept_AitOudhia2025_PD_hgb_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% sotatercept Ait-Oudhia_2025::Hgb: sigmoid_emax exposure-response sweep (response = E0 + Emax*frac). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one ng/mL per second, in SI inside (kg/m3, s). Response Hgb in g/dL. Driver: sotatercept (cited_pk).
p.E0 = 0.0;
p.Emax = 1.8599999999999997;
p.EC50 = 0.0027099999999999997;
p.gamma = 1.0;
p.slope = 0.0;
p.exposure_per_s = 1e-06;
p.stop_time = 28000.0;
p.form = 'E0 + Emax*frac';
end
