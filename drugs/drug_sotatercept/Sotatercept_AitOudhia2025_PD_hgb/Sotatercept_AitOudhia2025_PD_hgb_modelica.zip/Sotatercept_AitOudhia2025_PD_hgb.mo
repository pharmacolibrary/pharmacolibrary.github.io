model Sotatercept_AitOudhia2025_PD_hgb
  "sigmoid_emax exposure-response sweep — Ait-Oudhia_2025 :: Hgb (hemoglobin)"
  extends Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep(
    E0 = 0,      // [1]
    Emax = 1.86,  // [kg/m3; g/dL × 10]
    EC50 = 0.00271,  // [kg/m3; ng/mL × 1e-06]
    gamma = 1,
    exposure_per_s = 1e-06);   // 1 ng/mL per second
  // defaulted: E0
  annotation(experiment(StartTime = 0, StopTime = 28000, Interval = 56),
    Documentation(info = "<html><body><!-- drug-about --><h4>About sotatercept</h4><p>Sotatercept is a fusion-protein medication used to treat pulmonary arterial hypertension. It is an approved drug and is used for pulmonary hypertension, classified among antihypertensives for pulmonary arterial hypertension.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q103815273\">Wikidata Q103815273</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h4>Sotatercept_AitOudhia2025_PD_hgb</h4><p>The steady-state exposure-response curve of Ait-Oudhia S et al., <i>Clinical pharmacology and therapeutics 117(3):798–807</i> 2025 (<a href=\"https://doi.org/10.1002/cpt.3524\">doi:10.1002/cpt.3524</a>) — hemoglobin [g/dL] against sotatercept ng/mL — obtained by sweeping the driver instead of simulating a dose. Model family: sigmoid_emax.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = (library default) drug-free response (baseline)
  Emax  =      0.186 g/dL     maximal effect term (Maximum stimulation, Q320)
  EC50  =       2710 ng/mL    exposure at half of the maximal effect term (Half‐stimulatory sotatercept concentration, Q321)
  gamma =          1          Hill coefficient (Hill coefficient for sotatercept stimulation function, Q325)</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep\">SigmoidEmaxSweep</a>; this model only supplies the numbers. The x axis is one ng/mL of sotatercept per second of simulated time (exposure is in kg/m3): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0   (drug-free)
  exposure = EC50 (2710 ng/mL)  response 0.93
  exposure -> infinity  response 1.86</pre></body></html>"));
end Sotatercept_AitOudhia2025_PD_hgb;
