model Cisapride_Preechagoon1999_reference
  parameter Real Cl_ref = 1.4944444444444445e-07 "Cl [m3/s]";
  parameter Real Vd_ref = 0.0219 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.465945,
    adminMass = 3e-05,
    ka = 0.0007166666666666667,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>cisapride</td></tr><tr><td>population:</td><td>young infants with gastro-oesophageal reflux disease</td></tr><tr><td>source_paper:</td><td>Preechagoon_1999</td></tr><tr><td>measured_compound:</td><td>cisapride</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>cisapride 465.945 g/mol (drugbank)</td></tr></table><p><b>Defaulted (base-class default used):</b> Tlag.</p><h4>Interpretation flags</h4><ul><li>dropped PD-category row 'slope' → Q335 (slope, category G13) — pharmacodynamic parameters belong to scholarpd, not the PK model (source ['Preechagoon_1999:abstract'])</li><li>unit_dimension_unknown: 'l h-1 kg-1' (CL/F)</li><li>dropped unlinked row (NIL): 'CV%' — extend the ontology if this is a real PK parameter (source ['Preechagoon_1999:abstract', 'Preechagoon_1999:abstract'])</li><li>covariate category for omega_cov from footnote/prose kept as documentation only (['Preechagoon_1999:abstract'])</li><li>routed 'intrapatient variance' → Q313 (IOV) to iov — variability estimate, not a structural parameter</li><li>implicit units: 'CL/F' → L/h (from the popPK convention: 'No unit is stated in the provided text or table captions. CL/F represents apparent total clearance. In population pharma')</li><li>apparent-ness (ontology-grounded): parameterization=apparent, measured_compound=cisapride</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of TLAG: primary's parameterization (rate-constant / ka-only) does not use it</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 518400, Tolerance = 1e-9, Interval = 1));
end Cisapride_Preechagoon1999_reference;
