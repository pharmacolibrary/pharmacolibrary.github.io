model Pirarubicin_Robert1988_reference
  parameter Real Cl_ref = 2.4999999999999998e-05 "Cl [m3/s]";
  parameter Real Vd_ref = 1.3800000000000001 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.6276430000000001,
    adminMass = 1e-05
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About pirarubicin</h4><p>Pirarubicin is an anthracycline cytotoxic antibiotic investigated as an anticancer drug. It is not an approved medicine and remains investigational, with no authorisation in the European Union.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q76416926\">Wikidata Q76416926</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>pirarubicin</td></tr><tr><td>population:</td><td>patients with advanced cancer</td></tr><tr><td>source_paper:</td><td>Robert_1988</td></tr><tr><td>measured_compound:</td><td>pirarubicin</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>pirarubicin 627.643 g/mol (drugbank)</td></tr></table><h4>Interpretation flags</h4><ul><li>unit_dimension_unknown: 'l/h/m2' (CL)</li><li>unit_dimension_unknown: 'l/m2' (V)</li><li>implicit units: 'Total plasma clearance of the drug' → L/h (from the popPK convention: 'The paper provides no unit. Clearance is conventionally reported in L/h; 90 is plausible in that unit.')</li><li>implicit units: 'total volume of distribution' → L (from the popPK convention: 'The paper provides no unit. Volume of distribution is conventionally reported in L; 1380 L is plausible for a drug with ')</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=pirarubicin</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 259200, Tolerance = 1e-9, Interval = 1));
end Pirarubicin_Robert1988_reference;
