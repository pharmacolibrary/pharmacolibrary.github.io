% run_Pirarubicin_Leca1998_PD_wbcnadir  Evaluate the exposure-response curve and plot response against exposure.
% A sweep is a static map: no ODE solver is needed. exposure runs 0..stop_time*exposure_per_s.
p = Pirarubicin_Leca1998_PD_wbcnadir_params();
exposure = linspace(0, p.stop_time * p.exposure_per_s, 501);
frac = exposure.^p.gamma ./ (p.EC50^p.gamma + exposure.^p.gamma);
E0 = p.E0; Emax = p.Emax; slope = p.slope;
response = E0 + slope.*log(exposure);
figure; plot(exposure, response, 'LineWidth', 1.5); grid on;
xlabel('exposure [ng/ml x h]'); ylabel('response [x 10(3) cells/microl]'); title('Pirarubicin_Leca1998_PD_wbcnadir', 'Interpreter', 'none');
writematrix([exposure(:) response(:)], 'Pirarubicin_Leca1998_PD_wbcnadir.csv');
