function p = Pirarubicin_Leca1998_PD_wbcnadir_params()
% Pirarubicin_Leca1998_PD_wbcnadir_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% pirarubicin Leca_1998::WBCnadir: log_linear exposure-response sweep (response = E0 + slope*log(exposure)). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one ng/ml x h per second, in SI inside (kg/m3, s). Response WBCnadir in x 10(3) cells/microl. Driver: pirarubicin (cited_pk).
p.E0 = 0.0;
p.Emax = 0.0;
p.EC50 = 1.0;
p.gamma = 1.0;
p.slope = -0.009316;
p.exposure_per_s = 1.0;
p.stop_time = 1000.0;
p.form = 'E0 + slope*log(exposure)';
end
