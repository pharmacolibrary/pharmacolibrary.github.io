model Pirarubicin_Leca1998_PD_wbcnadir
  "log_linear exposure-response sweep — Leca_1998 :: WBCnadir (white blood cell nadir count)"
  extends Pharmacolibrary.Interfaces.PartialExposureResponseSweep(
    E0 = 0,      // [1]
    Emax = 0, EC50 = 1,      // unused by a line
    exposure_per_s = 1);
  parameter Real slope = -0.009316   "[1]";
equation
  response = E0 + slope*log(exposure);
  // defaulted: E0
  annotation(experiment(StartTime = 0, StopTime = 1000, Interval = 2),
    Documentation(info = "<html><body><!-- drug-about --><h4>About pirarubicin</h4><p>Pirarubicin is an anthracycline cytotoxic antibiotic investigated as an anticancer drug. It is not an approved medicine and remains investigational, with no authorisation in the European Union.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q76416926\">Wikidata Q76416926</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h4>Pirarubicin_Leca1998_PD_wbcnadir</h4><p>The steady-state exposure-response curve of Leca FR et al., <i>Anti-cancer drugs 9(6):503–509</i> 1998 — white blood cell nadir count [x 10(3) cells/microl] against pirarubicin ng/ml x h — obtained by sweeping the driver instead of simulating a dose. Model family: log_linear.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = (library default) drug-free response (baseline)
  slope =  -0.009316          change in response per unit of exposure (Exposure slope, Q335)</pre><p>The algebra is <code>response = E0 + slope*log(exposure)</code>; this model only supplies the numbers. The x axis is one ng/ml x h of pirarubicin per second of simulated time: there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p></body></html>"));
end Pirarubicin_Leca1998_PD_wbcnadir;
