% Run (SimBiology): build model + dose, simulate 0..2856.0 h, plot.
p = Carbamazepine_Milovanovic2016_reference_params();
[model, dose, variant] = build_sb_pk(p);
sd = simulate_sb(model, variant, dose, 2856.0);
