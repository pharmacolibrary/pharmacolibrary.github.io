% Run: build params, simulate 0..2856.0 h, plot + save Carbamazepine_Milovanovic2016_reference.png/.csv/.json.
% Interactive display (keep the window open):  octave --persist run_Carbamazepine_Milovanovic2016_reference.m
here = fileparts(mfilename('fullpath'));
p = Carbamazepine_Milovanovic2016_reference_params();
out = simulate_pk(p, 0:0.05:2856.0);

% figure (shown on screen if interactive) and PNG (works in MATLAB and Octave)
fig = figure; plot(out.t, out.C, 'LineWidth', 1.5); grid on;
xlabel('time [h]'); ylabel('central concentration [mg/L]');
title('carbamazepine — Milovanovic_2016 (oral)');
print(fig, fullfile(here, 'Carbamazepine_Milovanovic2016_reference.png'), '-dpng', '-r150');

% CSV (time_h, Cc_mg_per_L)
fid = fopen(fullfile(here, 'Carbamazepine_Milovanovic2016_reference.csv'), 'w');
fprintf(fid, 'time_h,Cc_mg_per_L\n');
fprintf(fid, '%.10g,%.10g\n', [out.t(:), out.C(:)].');
fclose(fid);

% JSON (summary + arrays; jsonencode with a manual fallback for older versions)
fid = fopen(fullfile(here, 'Carbamazepine_Milovanovic2016_reference.json'), 'w');
try
  s.model = 'Carbamazepine_Milovanovic2016_reference'; s.Cmax = out.Cmax; s.Tmax = out.Tmax; s.AUC = out.AUC;
  s.time_h = out.t(:).'; s.Cc_mg_per_L = out.C(:).';
  fprintf(fid, '%s', jsonencode(s));
catch
  fprintf(fid, '{"model":"Carbamazepine_Milovanovic2016_reference","Cmax":%g,"Tmax":%g,"AUC":%g}', out.Cmax, out.Tmax, out.AUC);
end
fclose(fid);

fprintf('Cmax=%.3g mg/L  Tmax=%.3g h  AUC=%.3g mg*h/L\n', out.Cmax, out.Tmax, out.AUC);
fprintf('wrote Carbamazepine_Milovanovic2016_reference.png, Carbamazepine_Milovanovic2016_reference.csv, Carbamazepine_Milovanovic2016_reference.json\n');
