model Brodalumab_RodrguezFernndez2022_reference
  parameter Real Cl_ref = 1.597222222222222e-08 "Cl [m3/s]";
  parameter Real Vd_ref = 0.0249 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    adminMass = 0.0001,
    ka = 1.0509259259259259e-05,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About brodalumab</h4><p>Brodalumab is a monoclonal antibody used to treat psoriasis. It is authorised in the European Union for psoriasis and is also under investigation for other uses.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q4972934\">Wikidata Q4972934</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>brodalumab</td></tr><tr><td>population:</td><td>review reference</td></tr><tr><td>source_paper:</td><td>Rodríguez-Fernández_2022</td></tr><tr><td>measured_compound:</td><td>brodalumab</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr></table><p><b>Defaulted (base-class default used):</b> Tlag.</p><h4>Interpretation flags</h4><ul><li>built from REVIEW reference values (Rodríguez-Fernández_2022) — secondary source</li><li>volume reported by review</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 6048000, Tolerance = 1e-9, Interval = 1));
end Brodalumab_RodrguezFernndez2022_reference;
