function p = Brodalumab_Salinger2014_PD_pasi_params()
% Brodalumab_Salinger2014_PD_pasi_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% brodalumab Salinger_2014::PASI: indirect_response_i exposure-response sweep (response = E0*(1 - Emax*frac)). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one µg/mL per second, in SI inside (kg/m3, s). Response PASI in PASI units. Driver: brodalumab (cited_pk).
p.E0 = 0.0;
p.Emax = 1.0;
p.EC50 = 0.0028599999999999993;
p.gamma = 1.0;
p.slope = 0.0;
p.exposure_per_s = 0.001;
p.stop_time = 29.0;
p.form = 'E0*(1 - Emax*frac)';
end
