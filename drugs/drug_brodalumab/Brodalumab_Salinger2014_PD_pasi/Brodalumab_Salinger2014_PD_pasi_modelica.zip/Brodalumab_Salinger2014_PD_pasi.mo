model Brodalumab_Salinger2014_PD_pasi
  "indirect_response_i exposure-response sweep — Salinger_2014 :: PASI (Psoriasis Area and Severity Index)"
  extends Pharmacolibrary.Interfaces.PartialExposureResponseSweep(
    E0 = 0,      // [1]
    Emax = 1,  // type I effect term
    EC50 = 0.00286,  // [kg/m3; µg/mL × 0.001]
    gamma = 1,
    exposure_per_s = 0.001);   // 1 µg/mL per second
equation
  response = E0*(1 - Emax*frac);   // steady state, indirect response type I
  // defaulted: E0
  // defaulted: Emax
  // defaulted: gamma
  annotation(experiment(StartTime = 0, StopTime = 29, Interval = 0.058),
    Documentation(info = "<html><body><!-- drug-about --><h4>About brodalumab</h4><p>Brodalumab is a monoclonal antibody used to treat psoriasis. It is authorised in the European Union for psoriasis and is also under investigation for other uses.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q4972934\">Wikidata Q4972934</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h4>Brodalumab_Salinger2014_PD_pasi</h4><p>The steady-state exposure-response curve of Salinger DH et al., <i>Clinical pharmacology in drug development 3(4):276–283</i> 2014 (<a href=\"https://doi.org/10.1002/cpdd.103\">doi:10.1002/cpdd.103</a>) — Psoriasis Area and Severity Index [PASI units] against brodalumab µg/mL — obtained by sweeping the driver instead of simulating a dose. Model family: indirect_response_i.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = (library default) drug-free response (baseline)
  Emax  = (library default) maximal effect term
  EC50  =       2.86 µg/mL    exposure at half of the maximal effect term (IC50, Q322)
  gamma = (library default) Hill coefficient</pre><p>The algebra is <code>response = E0*(1 - Emax*frac)</code>; this model only supplies the numbers. The x axis is one µg/mL of brodalumab per second of simulated time (exposure is in kg/m3): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0   (drug-free)
  exposure = EC50 (2.86 µg/mL)  response 0
  exposure -> infinity  response 0</pre></body></html>"));
end Brodalumab_Salinger2014_PD_pasi;
