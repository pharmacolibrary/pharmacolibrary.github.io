model Pantoprazole_Pettersen2009_reference
  parameter Real Cl_ref = 1.4111111111111111e-06 "Cl [m3/s]";
  parameter Real cov_age_0 = 0 "age covariate";
  parameter Real cov_cyp2c19_1 = 0 "cyp2c19 covariate";
  parameter Real cov_hepatic_2 = 0 "hepatic covariate";
  parameter Real Vd_ref = 0.0022 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C_enteral(
    weight = 70.0,
    F = 0.9,
    Cl = Cl_ref*(1 + (0.32)*cov_age_0)*(1 + (0.342)*cov_cyp2c19_1)*(1 + (0.501)*cov_hepatic_2),
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.38337,
    adminMass = 4e-05,
    ka = 9.027777777777779e-05,
    Tlag = 9000.0,
    k12 = 0.0001388888888888889,
    k21 = 0.00011358942585708385
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About pantoprazole</h4><p>Pantoprazole is a proton-pump inhibitor used to treat acid-related stomach problems such as peptic ulcers, gastritis, gastroesophageal reflux disease, and Zollinger–Ellison syndrome. It is approved and widely used, with authorised products in the European Union mainly for reflux conditions.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q286846\">Wikidata Q286846</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>pantoprazole</td></tr><tr><td>population:</td><td>paediatric intensive care patients</td></tr><tr><td>source_paper:</td><td>Pettersen_2009</td></tr><tr><td>measured_compound:</td><td>pantoprazole</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>tab_1</td></tr><tr><td>input:</td><td>PK_2C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>pantoprazole 383.37 g/mol (drugbank)</td></tr></table><p><b>Defaulted (base-class default used):</b> F.</p><h4>Interpretation flags</h4><ul><li>table section iiv: 'IIV CL (%)' routed out of structural estimates ('Interindividual variability (IIV) §')</li><li>table section iiv: 'IIV CL (%)' routed out of structural estimates ('Interindividual variability (IIV) §')</li><li>table section iiv: 'IIV Vc (%)' routed out of structural estimates ('Interindividual variability (IIV) §')</li><li>table section iiv: 'IIV Vc (%)' routed out of structural estimates ('Interindividual variability (IIV) §')</li><li>table section iiv: 'IIV Q (%)' routed out of structural estimates ('Interindividual variability (IIV) §')</li><li>table section iiv: 'IIV Q (%)' routed out of structural estimates ('Interindividual variability (IIV) §')</li><li>table section iiv: 'IIV V2 (%)' routed out of structural estimates ('Interindividual variability (IIV) §')</li><li>table section iiv: 'IIV V2 (%)' routed out of structural estimates ('Interindividual variability (IIV) §')</li><li>table section residual_error: 'Residual additive error (SD in mg l -1 ) ¶' routed out of structural estimates ('Residual variability')</li><li>table section residual_error: 'Residual proportional error (%) §' routed out of structural estimates ('Residual variability')</li><li>table section residual_error: 'Residual proportional error (%) §' routed out of structural estimates ('Residual variability')</li><li>column 'parameter' classified 'other' by the LLM but kept: the deterministic diagnostic-column test disagrees (a stratum column is a value column, not a statistic)</li><li>column 'parameter' classified 'other' by the LLM but kept: the deterministic diagnostic-column test disagrees (a stratum column is a value column, not a statistic)</li><li>column 'parameter' classified 'other' by the LLM but kept: the deterministic diagnostic-column test disagrees (a stratum column is a value column, not a statistic)</li><li>column 'parameter' classified 'other' by the LLM but kept: the deterministic diagnostic-column test disagrees (a stratum column is a value column, not a statistic)</li><li>column 'parameter' classified 'other' by the LLM but kept: the deterministic diagnostic-column test disagrees (a stratum column is a value column, not a statistic)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Pantoprazole_Pettersen2009_reference;
