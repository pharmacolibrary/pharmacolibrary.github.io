model Pantoprazole_Olivarez2020_reference
  parameter Real Cl_ref = 5.203333333333332e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.02107 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.38337,
    adminMass = 4e-05
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About pantoprazole</h4><p>Pantoprazole is a proton-pump inhibitor used to treat acid-related stomach problems such as peptic ulcers, gastritis, gastroesophageal reflux disease, and Zollinger–Ellison syndrome. It is approved and widely used, with authorised products in the European Union mainly for reflux conditions.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q286846\">Wikidata Q286846</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>pantoprazole</td></tr><tr><td>population:</td><td>review reference</td></tr><tr><td>source_paper:</td><td>Olivarez_2020</td></tr><tr><td>measured_compound:</td><td>pantoprazole</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>pantoprazole 383.37 g/mol (drugbank)</td></tr></table><h4>Interpretation flags</h4><ul><li>built from REVIEW reference values (Olivarez_2020) — secondary source</li><li>volume reported by review</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Pantoprazole_Olivarez2020_reference;
