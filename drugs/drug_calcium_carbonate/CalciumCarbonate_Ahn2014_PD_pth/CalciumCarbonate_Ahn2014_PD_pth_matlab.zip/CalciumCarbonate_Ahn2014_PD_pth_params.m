function p = CalciumCarbonate_Ahn2014_PD_pth_params()
% CalciumCarbonate_Ahn2014_PD_pth_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% calcium_carbonate Ahn_2014::PTH: indirect_response_i exposure-response sweep (response = E0*(1 - Emax*frac)). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one mmol/L per second, in SI inside (kg/m3, s). Response PTH in its own unit. Driver: calcium_carbonate (cited_pk).
p.E0 = 25.441696113074208;
p.Emax = 1.0;
p.EC50 = 0.15799999999999997;
p.gamma = 1.0;
p.slope = 0.0;
p.exposure_per_s = 1.0;
p.stop_time = 1.6;
p.form = 'E0*(1 - Emax*frac)';
end
