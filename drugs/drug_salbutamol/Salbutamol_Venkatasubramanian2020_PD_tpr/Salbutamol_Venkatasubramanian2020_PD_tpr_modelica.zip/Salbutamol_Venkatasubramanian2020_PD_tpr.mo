model Salbutamol_Venkatasubramanian2020_PD_tpr
  "indirect_response_i exposure-response sweep — Venkatasubramanian_2020 :: TPR (total peripheral resistance)"
  extends Pharmacolibrary.Interfaces.PartialExposureResponseSweep(
    E0 = 0.49,      // [1]
    Emax = 0.99,  // type I effect term
    EC50 = 131,  // [1]
    gamma = 1,
    exposure_per_s = 1);   // 1 unit per second
equation
  response = E0*(1 - Emax*frac);   // steady state, indirect response type I
  // exposure_unit_unresolved: '' — the x axis is in the paper's unit, not SI
  // defaulted: gamma
  annotation(experiment(StartTime = 0, StopTime = 1400, Interval = 2.8),
    Documentation(info = "<html><body><!-- drug-about --><h4>About salbutamol</h4><p>Salbutamol is a bronchodilator used to treat asthma, bronchospasm and other obstructive lung diseases. It is widely used worldwide, appears on the WHO list of essential medicines, and is available on prescription.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q410358\">Wikidata Q410358</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h4>Salbutamol_Venkatasubramanian2020_PD_tpr</h4><p>The steady-state exposure-response curve of Venkatasubramanian R et al., <i>British journal of pharmacology 177(15):3568-3590</i> 2020 (<a href=\"https://doi.org/10.1111/bph.15079\">doi:10.1111/bph.15079</a>) — total peripheral resistance against salbutamol — obtained by sweeping the driver instead of simulating a dose. Model family: indirect_response_i.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    =       0.49          drug-free response (baseline) (Base TPR, Q324)
  Emax  =       0.99          maximal effect term (Emax,TPR, Q323)
  EC50  =        131          exposure at half of the maximal effect term (EC50,TPR, Q321)
  gamma = (library default) Hill coefficient</pre><p>The algebra is <code>response = E0*(1 - Emax*frac)</code>; this model only supplies the numbers. The x axis is one  of salbutamol per second of simulated time: there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0.49   (drug-free)
  exposure = EC50 (131 )  response 0.2475
  exposure -> infinity  response 0.0049</pre></body></html>"));
end Salbutamol_Venkatasubramanian2020_PD_tpr;
