model Salbutamol_Walsh2023_PD_hr_z_score
  "sigmoid_emax exposure-response sweep — Walsh_2023 :: HR Z-score (Heart rate (age-standardised Z-score))"
  extends Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep(
    E0 = 3.08,      // [z-score]
    Emax = 4.16,  // [z-score]
    EC50 = 0.000385,  // [kg/m3; ng/ml × 1e-06]
    gamma = 1,
    exposure_per_s = 1e-06);   // 1 ng/ml per second
  // defaulted: gamma
  annotation(experiment(StartTime = 0, StopTime = 3900, Interval = 7.8),
    Documentation(info = "<html><body><h4>Salbutamol_Walsh2023_PD_hr_z_score</h4><p>The steady-state exposure-response curve of Walsh S et al., <i>Archives of disease in childhood 108(4):316–322</i> 2023 (<a href=\"https://doi.org/10.1136/archdischild-2022-324008\">doi:10.1136/archdischild-2022-324008</a>) — Heart rate (age-standardised Z-score) [z-score] against salbutamol ng/ml — obtained by sweeping the driver instead of simulating a dose. Model family: sigmoid_emax.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    =       3.08 z-score  drug-free response (baseline) (E0, Q324)
  Emax  =       4.16 z-score  maximal effect term (EMAX, Q320)
  EC50  =        385 ng/ml    exposure at half of the maximal effect term (EC50, Q321)
  gamma = (library default) Hill coefficient</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep\">SigmoidEmaxSweep</a>; this model only supplies the numbers. The x axis is one ng/ml of salbutamol per second of simulated time (exposure is in kg/m3): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 3.08   (drug-free)
  exposure = EC50 (385 ng/ml)  response 5.16
  exposure -> infinity  response 7.24</pre></body></html>"));
end Salbutamol_Walsh2023_PD_hr_z_score;
