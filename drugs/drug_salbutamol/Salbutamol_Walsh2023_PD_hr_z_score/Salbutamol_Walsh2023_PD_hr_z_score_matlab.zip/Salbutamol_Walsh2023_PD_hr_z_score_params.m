function p = Salbutamol_Walsh2023_PD_hr_z_score_params()
% Salbutamol_Walsh2023_PD_hr_z_score_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% salbutamol Walsh_2023::HR_Z_score: sigmoid_emax exposure-response sweep (response = E0 + Emax*frac). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one ng/ml per second, in SI inside (kg/m3, s). Response HR Z-score in z-score. Driver: salbutamol (pk_record).
p.E0 = 3.08;
p.Emax = 4.16;
p.EC50 = 0.000385;
p.gamma = 1.0;
p.slope = 0.0;
p.exposure_per_s = 1e-06;
p.stop_time = 3900.0;
p.form = 'E0 + Emax*frac';
end
