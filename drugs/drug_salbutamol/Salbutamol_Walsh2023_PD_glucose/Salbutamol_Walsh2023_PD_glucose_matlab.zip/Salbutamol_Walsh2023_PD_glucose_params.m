function p = Salbutamol_Walsh2023_PD_glucose_params()
% Salbutamol_Walsh2023_PD_glucose_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% salbutamol Walsh_2023::glucose: sigmoid_emax exposure-response sweep (response = E0 + Emax*frac). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one ng/ml per second, in SI inside (kg/m3, s). Response glucose in mmol/l. Driver: salbutamol (pk_record).
p.E0 = 5.029999999999999;
p.Emax = 3.8599999999999994;
p.EC50 = 1.08e-06;
p.gamma = 1.0;
p.slope = 0.0;
p.exposure_per_s = 1e-06;
p.stop_time = 11.0;
p.form = 'E0 + Emax*frac';
end
