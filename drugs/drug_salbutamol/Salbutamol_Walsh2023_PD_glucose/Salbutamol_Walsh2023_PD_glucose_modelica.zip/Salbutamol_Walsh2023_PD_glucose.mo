model Salbutamol_Walsh2023_PD_glucose
  "sigmoid_emax exposure-response sweep — Walsh_2023 :: Glucose (Blood glucose)"
  extends Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep(
    E0 = 5.03,      // [mol/m3; mmol/l × 1]
    Emax = 3.86,  // [mol/m3; mmol/l × 1]
    EC50 = 1.08e-06,  // [kg/m3; ng/ml × 1e-06]
    gamma = 1,
    exposure_per_s = 1e-06);   // 1 ng/ml per second
  // defaulted: gamma
  annotation(experiment(StartTime = 0, StopTime = 11, Interval = 0.022),
    Documentation(info = "<html><body><!-- drug-about --><h4>About salbutamol</h4><p>Salbutamol is a bronchodilator used to treat asthma, bronchospasm and other obstructive lung diseases. It is widely used worldwide, appears on the WHO list of essential medicines, and is available on prescription.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q410358\">Wikidata Q410358</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h4>Salbutamol_Walsh2023_PD_glucose</h4><p>The steady-state exposure-response curve of Walsh S et al., <i>Archives of disease in childhood 108(4):316–322</i> 2023 (<a href=\"https://doi.org/10.1136/archdischild-2022-324008\">doi:10.1136/archdischild-2022-324008</a>) — Blood glucose [mmol/l] against salbutamol ng/ml — obtained by sweeping the driver instead of simulating a dose. Model family: sigmoid_emax.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    =       5.03 mmol/l   drug-free response (baseline) (E0, Q324)
  Emax  =       3.86 mmol/l   maximal effect term (EMAX, Q320)
  EC50  =       1.08 ng/ml    exposure at half of the maximal effect term (EC50, Q321)
  gamma = (library default) Hill coefficient</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep\">SigmoidEmaxSweep</a>; this model only supplies the numbers. The x axis is one ng/ml of salbutamol per second of simulated time (exposure is in kg/m3): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 5.03   (drug-free)
  exposure = EC50 (1.08 ng/ml)  response 6.96
  exposure -> infinity  response 8.89</pre></body></html>"));
end Salbutamol_Walsh2023_PD_glucose;
