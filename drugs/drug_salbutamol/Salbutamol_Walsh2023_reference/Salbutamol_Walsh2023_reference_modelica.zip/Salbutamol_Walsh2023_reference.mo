model Salbutamol_Walsh2023_reference
  parameter Real Cl_ref = 1.45e-07 "Cl [m3/s]";
  parameter Real Vd_ref = 0.0017900000000000001 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C_enteral(
    weight = 70.0,
    F = 0.0925,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.2393107,
    adminMass = 7e-08,
    ka = 0.004638888888888889,
    Tlag = 0.0,
    k12 = 0.0013314711359404096,
    k21 = 0.0003695090439276486
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>salbutamol</td></tr><tr><td>population:</td><td>children with acute asthma</td></tr><tr><td>source_paper:</td><td>Walsh_2023</td></tr><tr><td>measured_compound:</td><td>salbutamol</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>Table 3</td></tr><tr><td>input:</td><td>PK_2C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>salbutamol 239.311 g/mol (drugbank)</td></tr></table><p><b>Defaulted (base-class default used):</b> Tlag.</p><h4>Interpretation flags</h4><ul><li>dropped unlinked row (NIL): 'BASE (ng/ml)' — extend the ontology if this is a real PK parameter (source ['Walsh_2023_table_p23_1:row7:col1'])</li><li>dropped PD-category row 'E0 (fraction of PASS-score [0-9])' → Q324 (E0, category G11) — pharmacodynamic parameters belong to scholarpd, not the PK model (source ['Walsh_2023_table_p23_1:row11:col1', 'Walsh_2023_table_p23_1:row11:col2'])</li><li>dropped PD-category row 'EMAX (fraction of PASS-score [0-9])' → Q320 (Emax, category G11) — pharmacodynamic parameters belong to scholarpd, not the PK model (source ['Walsh_2023_table_p23_1:row12:col1'])</li><li>dropped PD-category row 'EC50 (ng/ml)' → Q321 (EC50, category G11) — pharmacodynamic parameters belong to scholarpd, not the PK model (source ['Walsh_2023_table_p23_1:row13:col1', 'Walsh_2023_table_p23_1:row19:col1', 'Walsh_2023_table_p23_1:row19:col2', 'Walsh_2023_table_p23_1:row24:col1', 'Walsh_2023_table_p23_1:row24:col2'])</li><li>dropped PD-category row 'HILL' → Q325 (Hill, category G11) — pharmacodynamic parameters belong to scholarpd, not the PK model (source ['Walsh_2023_table_p23_1:row14:col1'])</li><li>dropped unlinked row (NIL): 'Additive on logit-scale' — extend the ontology if this is a real PK parameter (source ['Walsh_2023_table_p23_1:row15:col3'])</li><li>dropped PD-category row 'E0 (mmol/l)' → Q324 (E0, category G11) — pharmacodynamic parameters belong to scholarpd, not the PK model (source ['Walsh_2023_table_p23_1:row17:col1'])</li><li>dropped PD-category row 'EMAX' → Q320 (Emax, category G11) — pharmacodynamic parameters belong to scholarpd, not the PK model (source ['Walsh_2023_table_p23_1:row18:col1', 'Walsh_2023_table_p23_1:row18:col2', 'Walsh_2023_table_p23_1:row23:col1'])</li><li>dropped PD-category row 'E0 (z-score)' → Q324 (E0, category G11) — pharmacodynamic parameters belong to scholarpd, not the PK model (source ['Walsh_2023_table_p23_1:row22:col1', 'Walsh_2023_table_p23_1:row22:col2'])</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=salbutamol</li><li>skipped review gap-fill of TLAG: primary's parameterization (rate-constant / ka-only) does not use it</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Salbutamol_Walsh2023_reference;
