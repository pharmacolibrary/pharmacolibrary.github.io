function p = Salbutamol_Kume2018_PD_unknown_params()
% Salbutamol_Kume2018_PD_unknown_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% salbutamol Kume_2018::resp: sigmoid_emax exposure-response sweep (response = E0 + Emax*frac). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one nM per second, in SI inside (kg/m3, s). Response % in continuous. Driver: procaterol (conc_no_pk).
p.E0 = 0.0;
p.Emax = -100.0;
p.EC50 = 3.3;
p.gamma = 1.0;
p.slope = 0.0;
p.exposure_per_s = 1.0;
p.stop_time = 33.0;
p.form = 'E0 + Emax*frac';
end
