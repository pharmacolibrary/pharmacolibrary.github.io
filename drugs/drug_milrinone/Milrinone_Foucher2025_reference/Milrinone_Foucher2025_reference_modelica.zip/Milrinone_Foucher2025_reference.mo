model Milrinone_Foucher2025_reference
  parameter Real Cl_ref = 1.5222222222222223e-05 "Cl [m3/s]";
  parameter Real Vd_ref = 0.314 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.2112194,
    adminMass = 5e-05
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About milrinone</h4><p>Milrinone is a phosphodiesterase inhibitor used as a cardiotonic and vasodilator for congestive heart failure. It is an approved drug, used mainly in hospital settings for acute cardiac support.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q847399\">Wikidata Q847399</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>milrinone</td></tr><tr><td>population:</td><td>review reference</td></tr><tr><td>source_paper:</td><td>Foucher_2025</td></tr><tr><td>measured_compound:</td><td>milrinone</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>milrinone 211.219 g/mol (drugbank)</td></tr></table><h4>Interpretation flags</h4><ul><li>built from REVIEW reference values (Foucher_2025) — secondary source</li><li>volume reported by review</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Milrinone_Foucher2025_reference;
