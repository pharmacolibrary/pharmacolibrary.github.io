model Milrinone_OHanlon2024_reference
  parameter Real Cl_ref = 4.9444444444444444e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.020399999999999998 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.2112194,
    adminMass = 5e-05
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About milrinone</h4><p>Milrinone is a phosphodiesterase inhibitor used as a cardiotonic and vasodilator for congestive heart failure. It is an approved drug, used mainly in hospital settings for acute cardiac support.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q847399\">Wikidata Q847399</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>milrinone</td></tr><tr><td>population:</td><td>paediatric patients (premature neonates to adolescents) after cardiac surgery</td></tr><tr><td>source_paper:</td><td>OHanlon_2024</td></tr><tr><td>measured_compound:</td><td>milrinone</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>Tab2</td></tr><tr><td>input:</td><td>PK_1C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>milrinone 211.219 g/mol (drugbank)</td></tr></table><h4>Interpretation flags</h4><ul><li>table section residual_error: 'CV batch 1' routed out of structural estimates ('Residual error')</li><li>table section residual_error: 'CV batch 1' routed out of structural estimates ('Residual error')</li><li>table section residual_error: 'CV batch 1' routed out of structural estimates ('Residual error')</li><li>table section residual_error: 'CV batch 1' routed out of structural estimates ('Residual error')</li><li>table section residual_error: 'CV batch 1' routed out of structural estimates ('Residual error')</li><li>table section residual_error: 'SD batch 1' routed out of structural estimates ('Residual error')</li><li>table section residual_error: 'SD batch 1' routed out of structural estimates ('Residual error')</li><li>table section residual_error: 'SD batch 1' routed out of structural estimates ('Residual error')</li><li>table section residual_error: 'SD batch 1' routed out of structural estimates ('Residual error')</li><li>table section residual_error: 'SD batch 1' routed out of structural estimates ('Residual error')</li><li>table section residual_error: 'CV batch 2' routed out of structural estimates ('Residual error')</li><li>table section residual_error: 'SD batch 2' routed out of structural estimates ('Residual error')</li><li>table section residual_error: 'SD batch 2' routed out of structural estimates ('Residual error')</li><li>table section residual_error: 'SD batch 2' routed out of structural estimates ('Residual error')</li><li>table section residual_error: 'SD batch 2' routed out of structural estimates ('Residual error')</li><li>table section residual_error: 'SD batch 2' routed out of structural estimates ('Residual error')</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Milrinone_OHanlon2024_reference;
