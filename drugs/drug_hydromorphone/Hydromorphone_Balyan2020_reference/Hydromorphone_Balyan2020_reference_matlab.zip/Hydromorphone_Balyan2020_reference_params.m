function p = Hydromorphone_Balyan2020_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: hydromorphone   source: Balyan_2020 / reference   route: iv_bolus
  % estimated (absent from source): F
  p.name  = 'Hydromorphone_Balyan2020_reference_params';
  p.drug  = 'hydromorphone';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'iv_bolus';        % 'oral' | 'iv_bolus'
  p.depot = false;             % oral -> first-order absorption depot
  p.Vc = 33.0;                % central volume [L]
  p.CL = 44.88;                % clearance [L/h]
  p.Vp = [146.0];             % peripheral volumes [L]
  p.Q  = [11.34];             % inter-compartmental clearances [L/h]
  p.ka = 0.0;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 4.0;             % dose [mg]
end
