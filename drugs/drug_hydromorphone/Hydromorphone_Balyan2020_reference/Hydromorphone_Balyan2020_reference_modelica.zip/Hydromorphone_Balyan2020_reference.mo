model Hydromorphone_Balyan2020_reference
  parameter Real Cl_ref = 1.2466666666666665e-05 "Cl [m3/s]";
  parameter Real Vd_ref = 0.033 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.28533769999999997,
    adminMass = 4e-06,
    k12 = 9.545454545454545e-05,
    k21 = 2.1575342465753424e-05
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About hydromorphone</h4><p>Hydromorphone is an opioid painkiller used to relieve pain, and has also been used for cough. It is an approved medicine used widely for pain relief, though as a controlled opioid its availability is restricted.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q303646\">Wikidata Q303646</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>hydromorphone</td></tr><tr><td>population:</td><td>pediatric surgical patients</td></tr><tr><td>source_paper:</td><td>Balyan_2020</td></tr><tr><td>measured_compound:</td><td>hydromorphone</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_2C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>hydromorphone 285.338 g/mol (drugbank)</td></tr></table><h4>Interpretation flags</h4><ul><li>dropped unlinked row (NIL): 'peripheral clearance' — extend the ontology if this is a real PK parameter (source ['Balyan_2020:abstract', 'Balyan_2020:abstract'])</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=hydromorphone</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li><li>gap-filled Q30 (Q) from Wimbish_2024's review values (primary lacked it)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Hydromorphone_Balyan2020_reference;
