model Hydromorphone_Wimbish2024_reference
  parameter Real Cl_ref = 3.5466666666666664e-05 "Cl [m3/s]";
  parameter Real Vd_ref = 0.14 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.28533769999999997,
    adminMass = 4e-06,
    k12 = 2.2499999999999998e-05
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About hydromorphone</h4><p>Hydromorphone is an opioid painkiller used to relieve pain, and has also been used for cough. It is an approved medicine used widely for pain relief, though as a controlled opioid its availability is restricted.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q303646\">Wikidata Q303646</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>hydromorphone</td></tr><tr><td>population:</td><td>review reference</td></tr><tr><td>source_paper:</td><td>Wimbish_2024</td></tr><tr><td>measured_compound:</td><td>hydromorphone</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_2C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>hydromorphone 285.338 g/mol (drugbank)</td></tr></table><p><b>Defaulted (base-class default used):</b> k21.</p><h4>Interpretation flags</h4><ul><li>built from REVIEW reference values (Wimbish_2024) — secondary source</li><li>volume reported by review</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Hydromorphone_Wimbish2024_reference;
