model Hydromorphone_Meissner2025_reference
  parameter Real Cl_ref = 2.3277777777777778e-05 "Cl [m3/s]";
  parameter Real Vd_ref = 0.0136 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.28533769999999997,
    adminMass = 3.5e-06
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About hydromorphone</h4><p>Hydromorphone is an opioid painkiller used to relieve pain, and has also been used for cough. It is an approved medicine used widely for pain relief, though as a controlled opioid its availability is restricted.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q303646\">Wikidata Q303646</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>hydromorphone</td></tr><tr><td>population:</td><td>healthy adults</td></tr><tr><td>source_paper:</td><td>Meissner_2025</td></tr><tr><td>measured_compound:</td><td>hydromorphone</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>tab_0</td></tr><tr><td>input:</td><td>PK_1C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>hydromorphone 285.338 g/mol (drugbank); morphine 285.343 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>dropped unlinked row (NIL): 's A' — extend the ontology if this is a real PK parameter (source ['tab_0:row6:col2', 'tab_0:row6:col3', 'tab_0:row10:col2', 'tab_0:row10:col3'])</li><li>dropped value-less row: 's R,MOR'</li><li>dropped value-less row: 's A,MOR'</li><li>dropped value-less row: 's R,HMO'</li><li>dropped value-less row: 's A,HMO'</li><li>salvaged Q63 ('V 1 (L)'=13.6) from results prose — parameter table was unreadable</li><li>salvaged Q22 ('CL 1 (L h À1 )*'=83.8) from results prose — parameter table was unreadable</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=hydromorphone</li><li>held at status:extracted — NIL link or unit issue (mismatch/unknown/normalisation-failed) present</li><li>template fit: PK_3M_9C — formed from central; parent 1, metabolites [0]</li><li>status held at route_to_review — not promoted</li><li>row roles (LLM): model_class=compartmental; 7/7 row label(s) assigned, 0 linked by role; re-tagged morphine-glucuronides→morphine ×4, morphine-glucuronides→parent ×4</li><li>molar mass: no plausible PubChem entry for 'morphine-glucuronides' ('no full name in the paper') — left in mass units</li><li>molar mass: none found for 'morphine-glucuronides' — its concentrations stay mass-only</li><li>skipped review gap-fill of V2: primary is PARENT_METABOLITE (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is PARENT_METABOLITE (peripheral family needs ≥2C)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Hydromorphone_Meissner2025_reference;
