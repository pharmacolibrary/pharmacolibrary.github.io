model Bretylium_Kamath1981_reference
  parameter Real Cl_ref = 3.752777777777778e-05 "Cl [m3/s]";
  parameter Real Vd_ref = 1.05 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.243168,
    adminMass = 0.0001,
    ka = 0.0001388888888888889,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About bretylium</h4><p>Bretylium is a class III antiarrhythmic agent used to treat ventricular fibrillation and heart conduction disease. It is an approved drug, though it is not authorised in the European Union.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q420026\">Wikidata Q420026</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>bretylium</td></tr><tr><td>population:</td><td>male Charles River rats</td></tr><tr><td>source_paper:</td><td>Kamath_1981</td></tr><tr><td>measured_compound:</td><td>bretylium</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_2C_enteral: apparent (/F) parameterization ⇒ extravascular dosing</td></tr><tr><td>molar_masses:</td><td>bretylium 243.168 g/mol (pubchem)</td></tr></table><p><b>Defaulted (base-class default used):</b> ka, Tlag, k12, k21.</p><h4>Interpretation flags</h4><ul><li>apparent-ness (ontology-grounded): parameterization=apparent, measured_compound=bretylium</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 100800, Tolerance = 1e-9, Interval = 1));
end Bretylium_Kamath1981_reference;
