model Amisulpride_Yan2024_final
  parameter Real Cl_ref = 1.2527777777777778e-05 "Cl [m3/s]";
  parameter Real Vd_ref = 0.466 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.369479,
    adminMass = 0.0004,
    ka = 4.9999999999999996e-05,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About amisulpride</h4><p>Amisulpride is an antipsychotic medicine used to treat schizophrenia. It is an approved drug and remains in clinical use, mainly in Europe.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q418785\">Wikidata Q418785</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>amisulpride</td></tr><tr><td>population:</td><td>Chinese adult inpatients with schizophrenia</td></tr><tr><td>source_paper:</td><td>Yan_2024</td></tr><tr><td>measured_compound:</td><td>amisulpride</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>t0005</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>amisulpride 369.479 g/mol (drugbank)</td></tr></table><p><b>Defaulted (base-class default used):</b> Tlag.</p><h4>Interpretation flags</h4><ul><li>table section iiv: 'CL/F' routed out of structural estimates ('Interindividual variability')</li><li>table section iiv: 'CL/F' routed out of structural estimates ('Interindividual variability')</li><li>dropped unlinked row (NIL): '(n=1000 samples)' — extend the ontology if this is a real PK parameter (source ['t0005:row1:col1'])</li><li>dropped duplicate Q27 ('eCLcr on CL/F', value '0.364') — already have one for this compound</li><li>dropped value-less row: 'eCLcr'</li><li>dropped value-less row: 'CL/F'</li><li>dropped value-less row: 'Ka'</li><li>dropped value-less row: 'V/F'</li><li>implicit units: 'ka (1/h)' → 1/h (from the paper text: 'Text states the absorption rate constant (Ka) is fixed at 0.18; first-order rate constants are conventionally in 1/h, an')</li><li>implicit units: 'CL/F (1/h)' → L/h (from the paper text: &quot;Text states 'the typical clearance rate of amisulpride is 45.1 L/h' and 'Typical estimates for amisulpride clearance in &quot;)</li><li>apparent-ness (ontology-grounded): parameterization=apparent, measured_compound=amisulpride</li><li>model-stage split: 'final population parameters' is the final model of Yan_2024 (paper reports 3 stages: final population parameters, software/algorithm, structural model); same population, different model-building step</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of TLAG: primary's parameterization (rate-constant / ka-only) does not use it</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 259200, Tolerance = 1e-9, Interval = 1));
end Amisulpride_Yan2024_final;
