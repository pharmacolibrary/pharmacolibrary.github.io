function p = Amisulpride_Yan2024_final_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: amisulpride   source: Yan_2024 / final   route: oral
  p.name  = 'Amisulpride_Yan2024_final_params';
  p.drug  = 'amisulpride';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 466.0;                % central volume [L]
  p.CL = 45.1;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.18;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 400.0;             % dose [mg]
end
