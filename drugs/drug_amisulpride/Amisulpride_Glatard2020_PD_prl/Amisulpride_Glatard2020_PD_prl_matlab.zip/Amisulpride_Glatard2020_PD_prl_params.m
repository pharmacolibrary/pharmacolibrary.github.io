function p = Amisulpride_Glatard2020_PD_prl_params()
% Amisulpride_Glatard2020_PD_prl_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% amisulpride Glatard_2020::PRL: emax exposure-response sweep (response = E0 + Emax*frac). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one ng/mL per second, in SI inside (kg/m3, s). Response PRL in ng/mL. Driver: amisulpride (pk_record).
p.E0 = 1.6e-05;
p.Emax = 0.00014099999999999998;
p.EC50 = 4.2e-05;
p.gamma = 1.0;
p.slope = 0.0;
p.exposure_per_s = 1e-06;
p.stop_time = 420.0;
p.form = 'E0 + Emax*frac';
end
