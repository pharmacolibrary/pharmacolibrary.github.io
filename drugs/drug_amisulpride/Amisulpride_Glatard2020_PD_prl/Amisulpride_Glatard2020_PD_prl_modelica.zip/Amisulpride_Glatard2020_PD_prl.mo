model Amisulpride_Glatard2020_PD_prl
  "emax exposure-response sweep — Glatard_2020 :: PRL (Prolactin)"
  extends Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep(
    E0 = 1.6e-05,      // [kg/m3; ng/mL × 1e-06]
    Emax = 0.000141,  // [kg/m3; ng/mL × 1e-06]
    EC50 = 4.2e-05,  // [kg/m3; ng/mL × 1e-06]
    gamma = 1,
    exposure_per_s = 1e-06);   // 1 ng/mL per second
  // defaulted: gamma
  annotation(experiment(StartTime = 0, StopTime = 420, Interval = 0.84),
    Documentation(info = "<html><body><!-- drug-about --><h4>About amisulpride</h4><p>Amisulpride is an antipsychotic medicine used to treat schizophrenia. It is an approved drug and remains in clinical use, mainly in Europe.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q418785\">Wikidata Q418785</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h4>Amisulpride_Glatard2020_PD_prl</h4><p>The steady-state exposure-response curve of Glatard A et al., <i>Clinical pharmacokinetics 59(3):371–382</i> 2020 (<a href=\"https://doi.org/10.1007/s40262-019-00821-w\">doi:10.1007/s40262-019-00821-w</a>) — Prolactin [ng/mL] against amisulpride ng/mL — obtained by sweeping the driver instead of simulating a dose. Model family: emax.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    =         16 ng/mL    drug-free response (baseline) (PRLbase, Q324)
  Emax  =        141 ng/mL    maximal effect term (Emax, Q320)
  EC50  =         42 ng/mL    exposure at half of the maximal effect term (EC50, Q321)
  gamma = (library default) Hill coefficient</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep\">SigmoidEmaxSweep</a>; this model only supplies the numbers. The x axis is one ng/mL of amisulpride per second of simulated time (exposure is in kg/m3): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 1.6e-05   (drug-free)
  exposure = EC50 (42 ng/mL)  response 8.65e-05
  exposure -> infinity  response 0.000157</pre></body></html>"));
end Amisulpride_Glatard2020_PD_prl;
