function p = Amisulpride_Glatard2020_PD_bw_params()
% Amisulpride_Glatard2020_PD_bw_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% amisulpride Glatard_2020::BW: linear exposure-response sweep (response = E0 + slope*exposure). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one ng/mL per second, in SI inside (kg/m3, s). Response BW in kg. Driver: amisulpride (pk_record).
p.E0 = 0.0;
p.Emax = 0.0;
p.EC50 = 1.0;
p.gamma = 1.0;
p.slope = 0.001;
p.exposure_per_s = 1e-06;
p.stop_time = 1000.0;
p.form = 'E0 + slope*exposure';
end
