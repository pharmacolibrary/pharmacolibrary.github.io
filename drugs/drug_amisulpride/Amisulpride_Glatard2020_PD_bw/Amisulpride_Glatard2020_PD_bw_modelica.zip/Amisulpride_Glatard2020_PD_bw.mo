model Amisulpride_Glatard2020_PD_bw
  "linear exposure-response sweep — Glatard_2020 :: BW (Body weight)"
  extends Pharmacolibrary.Interfaces.PartialExposureResponseSweep(
    E0 = 0,      // [1]
    Emax = 0, EC50 = 1,      // unused by a line
    exposure_per_s = 1e-06);
  parameter Real slope = 0.001   "[kg per ng/mL]";
equation
  response = E0 + slope*exposure;
  // defaulted: E0
  annotation(experiment(StartTime = 0, StopTime = 1000, Interval = 2),
    Documentation(info = "<html><body><!-- drug-about --><h4>About amisulpride</h4><p>Amisulpride is an antipsychotic medicine used to treat schizophrenia. It is an approved drug and remains in clinical use, mainly in Europe.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q418785\">Wikidata Q418785</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h4>Amisulpride_Glatard2020_PD_bw</h4><p>The steady-state exposure-response curve of Glatard A et al., <i>Clinical pharmacokinetics 59(3):371–382</i> 2020 (<a href=\"https://doi.org/10.1007/s40262-019-00821-w\">doi:10.1007/s40262-019-00821-w</a>) — Body weight [kg] against amisulpride ng/mL — obtained by sweeping the driver instead of simulating a dose. Model family: linear.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = (library default) drug-free response (baseline)
  slope =      0.001 kg per ng/mL change in response per unit of exposure (Cav slope (multivariate), Q335)</pre><p>The algebra is <code>response = E0 + slope*exposure</code>; this model only supplies the numbers. The x axis is one ng/mL of amisulpride per second of simulated time (exposure is in kg/m3): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0   (drug-free)</pre></body></html>"));
end Amisulpride_Glatard2020_PD_bw;
