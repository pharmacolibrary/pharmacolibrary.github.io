function p = Amisulpride_Liu2023_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: amisulpride   source: Liu_2023 / reference   route: oral
  p.name  = 'Amisulpride_Liu2023_reference_params';
  p.drug  = 'amisulpride';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 391.0;                % central volume [L]
  p.CL = 32.6;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.9;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 400.0;             % dose [mg]
end
