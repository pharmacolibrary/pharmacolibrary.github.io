model Amisulpride_Liu2023_reference
  parameter Real Cl_ref = 9.055555555555556e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.391 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.369479,
    adminMass = 0.0004,
    ka = 0.00025,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About amisulpride</h4><p>Amisulpride is an antipsychotic medicine used to treat schizophrenia. It is an approved drug and remains in clinical use, mainly in Europe.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q418785\">Wikidata Q418785</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>amisulpride</td></tr><tr><td>population:</td><td>adult Chinese patients with schizophrenia</td></tr><tr><td>source_paper:</td><td>Liu_2023</td></tr><tr><td>measured_compound:</td><td>amisulpride</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>amisulpride 369.479 g/mol (drugbank)</td></tr></table><p><b>Defaulted (base-class default used):</b> Tlag.</p><h4>Interpretation flags</h4><ul><li>dropped duplicate Q27 ('CL/F = 32.6 × (eCLcr/114.3)0.485', value None) — already have one for this compound</li><li>apparent-ness (ontology-grounded): parameterization=apparent, measured_compound=amisulpride</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li><li>gap-filled Q49 (kabs) from Glatard_2020's review values (primary lacked it)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 162000, Tolerance = 1e-9, Interval = 1));
end Amisulpride_Liu2023_reference;
