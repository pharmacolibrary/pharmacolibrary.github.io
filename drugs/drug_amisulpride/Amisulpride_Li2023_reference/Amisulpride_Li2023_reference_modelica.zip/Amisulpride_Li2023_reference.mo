model Amisulpride_Li2023_reference
  parameter Real Cl_ref = 1.6805555555555555e-05 "Cl [m3/s]";
  parameter Real Vd_ref = 0.645 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.369479,
    adminMass = 5e-05,
    ka = 2.9444444444444445e-05,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About amisulpride</h4><p>Amisulpride is an antipsychotic medicine used to treat schizophrenia. It is an approved drug and remains in clinical use, mainly in Europe.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q418785\">Wikidata Q418785</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>amisulpride</td></tr><tr><td>population:</td><td>Chinese patients with schizophrenia</td></tr><tr><td>source_paper:</td><td>Li_2023</td></tr><tr><td>measured_compound:</td><td>amisulpride</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>T2</td></tr><tr><td>input:</td><td>PK_2C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>amisulpride 369.479 g/mol (drugbank)</td></tr></table><p><b>Defaulted (base-class default used):</b> Tlag, k12, k21.</p><h4>Interpretation flags</h4><ul><li>NIL: refused to back-fill base 'CL/F' from footnote/prose loose number None (source ['T2:footnote']); the table cell was unparseable — needs review</li><li>NIL: refused to back-fill base 'V/F' from footnote/prose loose number 645 (source ['T2:footnote']); the table cell was unparseable — needs review</li><li>NIL: refused to back-fill base 'kabs' from footnote/prose loose number 0.106 (source ['T2:footnote']); the table cell was unparseable — needs review</li><li>salvaged Q27 ('CL/F'=60.5) from results prose — parameter table was unreadable</li><li>salvaged Q76 ('V/F'=645) from results prose — parameter table was unreadable</li><li>salvaged Q49 ('k a'=0.106) from results prose — parameter table was unreadable</li><li>salvaged Q22 ('clearance'=61.1) from results prose — parameter table was unreadable</li><li>salvaged Q61 ('volume of distribution'=1720) from results prose — parameter table was unreadable</li><li>apparent-ness (ontology-grounded): parameterization=apparent, measured_compound=amisulpride</li><li>held at status:extracted — NIL link or unit issue (mismatch/unknown/normalisation-failed) present</li><li>structure disagreement: deterministic 2C vs LLM 1C — review compartment count</li><li>status held at route_to_review — not promoted</li><li>skipped review gap-fill of TLAG: primary's parameterization (rate-constant / ka-only) does not use it</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 259200, Tolerance = 1e-9, Interval = 1));
end Amisulpride_Li2023_reference;
