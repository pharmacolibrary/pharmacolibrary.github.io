model Amisulpride_Reeves2016_combined
  parameter Real Cl_ref = 1.5083333333333333e-05 "Cl [m3/s]";
  parameter Real Vd_ref = 0.455 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C_enteral(
    weight = 70.0,
    F = 0.9,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.369479,
    adminMass = 2.5e-05,
    ka = 0.0002361111111111111,
    Tlag = 0.0,
    k12 = 6.776556776556777e-05,
    k21 = 4.189311594202899e-05
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About amisulpride</h4><p>Amisulpride is an antipsychotic medicine used to treat schizophrenia. It is an approved drug and remains in clinical use, mainly in Europe.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q418785\">Wikidata Q418785</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>amisulpride</td></tr><tr><td>population:</td><td>older people (healthy elderly and Alzheimer's disease patients)</td></tr><tr><td>source_paper:</td><td>Reeves_2016</td></tr><tr><td>measured_compound:</td><td>amisulpride</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>Tab3</td></tr><tr><td>input:</td><td>PK_2C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>amisulpride 369.479 g/mol (drugbank)</td></tr></table><p><b>Defaulted (base-class default used):</b> F, Tlag.</p><h4>Interpretation flags</h4><ul><li>table section residual_error: 'σ (group 1)%' routed out of structural estimates ('Residual error')</li><li>table section residual_error: 'σ (group 1)%' routed out of structural estimates ('Residual error')</li><li>table section residual_error: 'σ (group 2)%' routed out of structural estimates ('Residual error')</li><li>table section residual_error: 'σ (group 2)%' routed out of structural estimates ('Residual error')</li><li>dropped unlinked row (NIL): 'Parameter (units)' — extend the ontology if this is a real PK parameter (source ['Tab3:row0:col3', 'Tab3:row0:col4'])</li><li>unit_dimension_unknown: 'n = 45' (kabs)</li><li>unit_dimension_unknown: 'n = 45' (CL)</li><li>unit_dimension_unknown: 'n = 45' (CL)</li><li>dropped duplicate Q22 ('β-Cl,weight', value '0.75') — already have one for this compound</li><li>unit_dimension_unknown: 'n = 45' (CL)</li><li>dropped duplicate Q22 ('β-Cl,Age', value None) — already have one for this compound</li><li>unit_dimension_unknown: 'n = 45' (V1)</li><li>unit_dimension_unknown: 'n = 45' (Q)</li><li>unit_dimension_unknown: 'n = 45' (V2)</li><li>routed 'ω_ka%' → Q312 (IIV) to iiv — variability estimate, not a structural parameter</li><li>routed 'ω_Cl%' → Q314 (omega_cov) to covariance — variability estimate, not a structural parameter</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 118800, Tolerance = 1e-9, Interval = 1));
end Amisulpride_Reeves2016_combined;
