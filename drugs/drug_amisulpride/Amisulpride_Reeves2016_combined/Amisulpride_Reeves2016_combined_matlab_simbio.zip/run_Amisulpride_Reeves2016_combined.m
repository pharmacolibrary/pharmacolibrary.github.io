% Run (SimBiology): build model + dose, simulate 0..33.0 h, plot.
p = Amisulpride_Reeves2016_combined_params();
[model, dose, variant] = build_sb_pk(p);
sd = simulate_sb(model, variant, dose, 33.0);
