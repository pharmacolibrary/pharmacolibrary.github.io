function p = Alfaxalone_Goodchild2020_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: alfaxalone   source: Goodchild_2020 / reference   route: iv_bolus
  % estimated (absent from source): F, dose
  p.name  = 'Alfaxalone_Goodchild2020_reference_params';
  p.drug  = 'alfaxalone';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'iv_bolus';        % 'oral' | 'iv_bolus'
  p.depot = false;             % oral -> first-order absorption depot
  p.Vc = 0.99;                % central volume [L]
  p.CL = 64.8;                % clearance [L/h]
  p.Vp = [6.36];             % peripheral volumes [L]
  p.Q  = [52.2];             % inter-compartmental clearances [L/h]
  p.ka = 0.0;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 10.0;             % dose [mg]
end
