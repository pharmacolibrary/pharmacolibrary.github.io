model Alfaxalone_Goodchild2020_reference
  parameter Real Cl_ref = 1.8e-05 "Cl [m3/s]";
  parameter Real Vd_ref = 0.00099 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.332484,
    adminMass = 1e-05,
    k12 = 0.014646464646464647,
    k21 = 0.002279874213836478
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About alfaxalone</h4><p>Alfaxalone is a steroid-based general anesthetic used to induce and maintain anesthesia. It is approved for veterinary use, where it is widely used as an anesthetic in animals, while in humans it is considered experimental.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q3611058\">Wikidata Q3611058</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>alfaxalone</td></tr><tr><td>population:</td><td>healthy male volunteers</td></tr><tr><td>source_paper:</td><td>Goodchild_2020</td></tr><tr><td>measured_compound:</td><td>alfaxalone</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_2C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>alfaxalone 332.484 g/mol (drugbank)</td></tr></table><h4>Interpretation flags</h4><ul><li>dropped unlinked row (NIL): 'baseline BIS' — extend the ontology if this is a real PK parameter (source ['Goodchild_2020:abstract'])</li><li>dropped PD-category row 'EMAX' → Q320 (Emax, category G11) — pharmacodynamic parameters belong to scholarpd, not the PK model (source ['Goodchild_2020:abstract'])</li><li>covariate category for EC50 from footnote/prose kept as documentation only (['Goodchild_2020:abstract'])</li><li>dropped PD-category row 'Hill coefficient (γ)' → Q325 (Hill, category G11) — pharmacodynamic parameters belong to scholarpd, not the PK model (source ['Goodchild_2020:abstract'])</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=alfaxalone</li><li>structure disagreement: deterministic 2C vs LLM 3C — review compartment count</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Alfaxalone_Goodchild2020_reference;
