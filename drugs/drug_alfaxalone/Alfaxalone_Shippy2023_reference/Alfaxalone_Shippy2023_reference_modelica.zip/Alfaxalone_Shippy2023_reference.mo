model Alfaxalone_Shippy2023_reference
  parameter Real Cl_ref = 2.6666666666666664e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.07 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.332484,
    adminMass = 0.0001,
    ka = 0.03833333333333333,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About alfaxalone</h4><p>Alfaxalone is a steroid-based general anesthetic used to induce and maintain anesthesia. It is approved for veterinary use, where it is widely used as an anesthetic in animals, while in humans it is considered experimental.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q3611058\">Wikidata Q3611058</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>alfaxalone</td></tr><tr><td>population:</td><td>healthy bearded dragons</td></tr><tr><td>source_paper:</td><td>Shippy_2023</td></tr><tr><td>measured_compound:</td><td>alfaxalone</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>alfaxalone 332.484 g/mol (drugbank)</td></tr></table><p><b>Defaulted (base-class default used):</b> Tlag.</p><h4>Interpretation flags</h4><ul><li>unit_dimension_unknown: 'mL minute-1 kg-1' (CL/F)</li><li>implicit units: 'clearance per fraction absorbed' → L/h (from the popPK convention: 'Clearance parameters in population pharmacokinetics are conventionally expressed in volume per time (e.g., L/h). The val')</li><li>apparent-ness (ontology-grounded): parameterization=apparent, measured_compound=alfaxalone</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Alfaxalone_Shippy2023_reference;
