function p = Alfaxalone_White2022_female_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: alfaxalone   source: White_2022 / female   route: iv_bolus
  % estimated (absent from source): F
  % Vc is the record's Vss — no central volume was reported; 1-compartment reading
  p.name  = 'Alfaxalone_White2022_female_params';
  p.drug  = 'alfaxalone';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'iv_bolus';        % 'oral' | 'iv_bolus'
  p.depot = false;             % oral -> first-order absorption depot
  p.Vc = 210.0;                % central volume [L]
  p.CL = 154.56;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.0;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 36.4;             % dose [mg]
end
