model Alfaxalone_White2022_female
  parameter Real Cl_ref = 4.2933333333333324e-05 "Cl [m3/s]";
  parameter Real Vd_ref = 0.21 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.332484,
    adminMass = 3.64e-05
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About alfaxalone</h4><p>Alfaxalone is a steroid-based general anesthetic used to induce and maintain anesthesia. It is approved for veterinary use, where it is widely used as an anesthetic in animals, while in humans it is considered experimental.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q3611058\">Wikidata Q3611058</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>alfaxalone</td></tr><tr><td>population:</td><td>inbred and outbred rat strains</td></tr><tr><td>source_paper:</td><td>White_2022</td></tr><tr><td>measured_compound:</td><td>alfaxalone</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>prp21031-tbl-0004</td></tr><tr><td>input:</td><td>PK_1C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>alfaxalone 332.484 g/mol (drugbank)</td></tr></table><h4>Interpretation flags</h4><ul><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=alfaxalone</li><li>population split: 'female' subgroup of White_2022 (paper reports 5 populations: adjusted typical values, adjusted typical values a, female, male, p‐value)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Alfaxalone_White2022_female;
