function p = Alfaxalone_White2022_adjusted_typical_values_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: alfaxalone   source: White_2022 / adjusted_typical_values   route: iv_bolus
  % estimated (absent from source): F
  p.name  = 'Alfaxalone_White2022_adjusted_typical_values_params';
  p.drug  = 'alfaxalone';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'iv_bolus';        % 'oral' | 'iv_bolus'
  p.depot = false;             % oral -> first-order absorption depot
  p.Vc = 0.57;                % central volume [L]
  p.CL = 1.512;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.0;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 36.4;             % dose [mg]
end
