function p = Alectinib_Mohmaed2026_fed_geometric_mean_cv_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: alectinib   source: Mohmaed_2026 / fed_geometric_mean_cv   route: oral
  % estimated (absent from source): ka
  p.name  = 'Alectinib_Mohmaed2026_fed_geometric_mean_cv_params';
  p.drug  = 'alectinib';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 776.0;                % central volume [L]
  p.CL = 84.2;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.5;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 0.1;             % dose [mg]
end
