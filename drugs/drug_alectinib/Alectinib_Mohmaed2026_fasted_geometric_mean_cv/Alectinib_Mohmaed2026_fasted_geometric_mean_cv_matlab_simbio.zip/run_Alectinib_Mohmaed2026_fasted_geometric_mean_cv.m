% Run (SimBiology): build model + dose, simulate 0..32.0 h, plot.
p = Alectinib_Mohmaed2026_fasted_geometric_mean_cv_params();
[model, dose, variant] = build_sb_pk(p);
sd = simulate_sb(model, variant, dose, 32.0);
