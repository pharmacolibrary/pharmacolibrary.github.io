model Febuxostat_Leander2021_PD_sua
  "indirect_response_i exposure-response sweep — Leander_2021 :: sUA (serum uric acid)"
  extends Pharmacolibrary.Interfaces.PartialExposureResponseSweep(
    E0 = 0,      // [1]
    Emax = 1,  // type I effect term
    EC50 = 0.000128,  // [kg/m3; ng/mL × 1e-06]
    gamma = 1,
    exposure_per_s = 1e-06);   // 1 ng/mL per second
equation
  response = E0*(1 - Emax*frac);   // steady state, indirect response type I
  // defaulted: E0
  // defaulted: Emax
  // defaulted: gamma
  annotation(experiment(StartTime = 0, StopTime = 1300, Interval = 2.6),
    Documentation(info = "<html><body><!-- drug-about --><h4>About febuxostat</h4><p>Febuxostat is a xanthine oxidase inhibitor used to treat hyperuricemia and gout. It is authorised in the European Union and widely used as an antigout medicine, though it carries a boxed warning.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q417296\">Wikidata Q417296</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h4>Febuxostat_Leander2021_PD_sua</h4><p>The steady-state exposure-response curve of Leander J et al., <i>Journal of pharmacokinetics and pharmacodynamics 48(4):525–541</i> 2021 (<a href=\"https://doi.org/10.1007/s10928-021-09747-y\">doi:10.1007/s10928-021-09747-y</a>) — serum uric acid [mg/dL] against febuxostat ng/mL — obtained by sweeping the driver instead of simulating a dose. Model family: indirect_response_i.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = (library default) drug-free response (baseline)
  Emax  = (library default) maximal effect term
  EC50  =        128 ng/mL    exposure at half of the maximal effect term (Febuxostat EC50, Q322)
  gamma = (library default) Hill coefficient</pre><p>The algebra is <code>response = E0*(1 - Emax*frac)</code>; this model only supplies the numbers. The x axis is one ng/mL of febuxostat per second of simulated time (exposure is in kg/m3): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0   (drug-free)
  exposure = EC50 (128 ng/mL)  response 0
  exposure -> infinity  response 0</pre></body></html>"));
end Febuxostat_Leander2021_PD_sua;
