function p = Febuxostat_Leander2021_PD_sua_params()
% Febuxostat_Leander2021_PD_sua_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% febuxostat Leander_2021::sUA: indirect_response_i exposure-response sweep (response = E0*(1 - Emax*frac)). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one ng/mL per second, in SI inside (kg/m3, s). Response sUA in mg/dL. Driver: febuxostat (cited_pk).
p.E0 = 0.0;
p.Emax = 1.0;
p.EC50 = 0.000128;
p.gamma = 1.0;
p.slope = 0.0;
p.exposure_per_s = 1e-06;
p.stop_time = 1300.0;
p.form = 'E0*(1 - Emax*frac)';
end
