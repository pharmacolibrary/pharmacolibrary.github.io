function p = Febuxostat_Aksenov2018_PD_k_p_params()
% Febuxostat_Aksenov2018_PD_k_p_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% febuxostat Aksenov_2018::k_P: indirect_response_i exposure-response sweep (response = E0*(1 - Emax*frac)). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one ng/mL per second, in SI inside (kg/m3, s). Response k P in mg/h. Driver: febuxostat (cited_pk).
p.E0 = 0.0;
p.Emax = 1.0;
p.EC50 = 8.7e-05;
p.gamma = 1.0;
p.slope = 0.0;
p.exposure_per_s = 1e-06;
p.stop_time = 870.0;
p.form = 'E0*(1 - Emax*frac)';
end
