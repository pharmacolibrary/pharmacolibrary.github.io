model Febuxostat_Aksenov2018_PD_k_p
  "indirect_response_i exposure-response sweep — Aksenov_2018 :: k P (production rate of uric acid)"
  extends Pharmacolibrary.Interfaces.PartialExposureResponseSweep(
    E0 = 0,      // [1]
    Emax = 1,  // type I effect term
    EC50 = 8.7e-05,  // [kg/m3; ng/mL × 1e-06]
    gamma = 1,
    exposure_per_s = 1e-06);   // 1 ng/mL per second
equation
  response = E0*(1 - Emax*frac);   // steady state, indirect response type I
  // defaulted: E0
  // defaulted: gamma
  annotation(experiment(StartTime = 0, StopTime = 870, Interval = 1.74),
    Documentation(info = "<html><body><!-- drug-about --><h4>About febuxostat</h4><p>Febuxostat is a xanthine oxidase inhibitor used to treat hyperuricemia and gout. It is authorised in the European Union and widely used as an antigout medicine, though it carries a boxed warning.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q417296\">Wikidata Q417296</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h4>Febuxostat_Aksenov2018_PD_k_p</h4><p>The steady-state exposure-response curve of Aksenov S et al., <i>Physiological reports 6(5)</i> 2018 (<a href=\"https://doi.org/10.14814/phy2.13614\">doi:10.14814/phy2.13614</a>) — production rate of uric acid [mg/h] against febuxostat ng/mL — obtained by sweeping the driver instead of simulating a dose. Model family: indirect_response_i.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = (library default) drug-free response (baseline)
  Emax  =          1          maximal effect term (R max (febuxostat), Q323)
  EC50  =         87 ng/mL    exposure at half of the maximal effect term ([P]50,PIN (febuxostat, not hyperuricemia, ng/mL), Q322)
  gamma = (library default) Hill coefficient</pre><p>The algebra is <code>response = E0*(1 - Emax*frac)</code>; this model only supplies the numbers. The x axis is one ng/mL of febuxostat per second of simulated time (exposure is in kg/m3): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0   (drug-free)
  exposure = EC50 (87 ng/mL)  response 0
  exposure -> infinity  response 0</pre></body></html>"));
end Febuxostat_Aksenov2018_PD_k_p;
