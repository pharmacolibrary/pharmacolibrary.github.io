function p = Febuxostat_Kamel2022_estimate_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: febuxostat   source: Kamel_2022 / estimate   route: oral
  p.name  = 'Febuxostat_Kamel2022_estimate_params';
  p.drug  = 'febuxostat';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 32.8;                % central volume [L]
  p.CL = 6.91;                % clearance [L/h]
  p.Vp = [19.4];             % peripheral volumes [L]
  p.Q  = [1.25];             % inter-compartmental clearances [L/h]
  p.ka = 3.62;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 40.0;             % dose [mg]
end
