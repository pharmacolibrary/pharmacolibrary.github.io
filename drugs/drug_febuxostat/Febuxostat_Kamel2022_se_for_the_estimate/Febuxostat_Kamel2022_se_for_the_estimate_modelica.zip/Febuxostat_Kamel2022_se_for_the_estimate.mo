model Febuxostat_Kamel2022_se_for_the_estimate
  parameter Real Cl_ref = 1.6666666666666667e-06 "Cl [m3/s]";
  parameter Real cov_food_0 = 0 "food covariate";
  parameter Real Vd_ref = 0.01 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref*(1 + (7.5)*cov_food_0),
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.316375,
    adminMass = 4e-05,
    ka = 0.008138888888888888,
    Tlag = 0.0,
    k12 = 0.00038611111111111116,
    k21 = 0.00032446311858076564
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About febuxostat</h4><p>Febuxostat is a xanthine oxidase inhibitor used to treat hyperuricemia and gout. It is authorised in the European Union and widely used as an antigout medicine, though it carries a boxed warning.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q417296\">Wikidata Q417296</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>febuxostat</td></tr><tr><td>population:</td><td>healthy subjects and people with gout</td></tr><tr><td>source_paper:</td><td>Kamel_2022</td></tr><tr><td>measured_compound:</td><td>febuxostat</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>bcp15462-tbl-0002</td></tr><tr><td>input:</td><td>PK_2C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>febuxostat 316.375 g/mol (drugbank)</td></tr></table><p><b>Defaulted (base-class default used):</b> Tlag.</p><h4>Interpretation flags</h4><ul><li>table section iiv: 'BSV‐CL/F (ϴ 1)' routed out of structural estimates ('BSV (shrinkage %)')</li><li>table section iiv: 'BSV‐Vc/F (ϴ 2)' routed out of structural estimates ('BSV (shrinkage %)')</li><li>table section iiv: 'BSV‐Vp/F (ϴ 4)' routed out of structural estimates ('BSV‐Q (ϴ 3)')</li><li>table section iiv: 'BSV‐FVAR' routed out of structural estimates ('BSV‐ka (ϴ 5)')</li><li>table section iiv: 'RUV‐CV% (shrinkage %)' routed out of structural estimates ('BSV‐ka (ϴ 5)')</li><li>column 'se% for the estimate' classified 'rse' by the LLM but kept as the estimate: the header names the point value</li><li>column 'se% for the estimate' classified 'rse' by the LLM but kept as the estimate: the header names the point value</li><li>column 'se% for the estimate' classified 'rse' by the LLM but kept as the estimate: the header names the point value</li><li>column 'se% for the estimate' classified 'rse' by the LLM but kept as the estimate: the header names the point value</li><li>column 'se% for the estimate' classified 'rse' by the LLM but kept as the estimate: the header names the point value</li><li>column 'se% for the estimate' classified 'rse' by the LLM but kept as the estimate: the header names the point value</li><li>column 'se% for the estimate' classified 'rse' by the LLM but kept as the estimate: the header names the point value</li><li>column 'se% for the estimate' classified 'rse' by the LLM but kept as the estimate: the header names the point value</li><li>column 'se% for the estimate' classified 'rse' by the LLM but kept as the estimate: the header names the point value</li><li>routed 'Covariate TCrCL (ϴ 6)' → Q314 (omega_cov) to covariance — variability estimate, not a structural parameter</li><li>dropped unlinked row (NIL): 'Covariate BMI (ϴ 7)' — extend the ontology if this is a real PK parameter (source ['bcp15462-tbl-0002:row4:col2'])</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Febuxostat_Kamel2022_se_for_the_estimate;
