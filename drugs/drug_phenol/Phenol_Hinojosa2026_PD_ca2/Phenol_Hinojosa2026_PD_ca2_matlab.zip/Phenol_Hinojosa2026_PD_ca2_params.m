function p = Phenol_Hinojosa2026_PD_ca2_params()
% Phenol_Hinojosa2026_PD_ca2_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% phenol Hinojosa_2026::Ca2: sigmoid_emax exposure-response sweep (response = E0 + Emax*frac). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one M per second, in SI inside (kg/m3, s). Response Ca2+ in its own unit. Driver: phenol (cited_pk).
p.E0 = 0.0;
p.Emax = 114.0;
p.EC50 = 2.7e-05;
p.gamma = 1.0;
p.slope = 0.0;
p.exposure_per_s = 1.0;
p.stop_time = 0.00027;
p.form = 'E0 + Emax*frac';
end
