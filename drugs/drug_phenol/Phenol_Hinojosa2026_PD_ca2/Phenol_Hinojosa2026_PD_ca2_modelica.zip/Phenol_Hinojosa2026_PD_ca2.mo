model Phenol_Hinojosa2026_PD_ca2
  "sigmoid_emax exposure-response sweep — Hinojosa_2026 :: Ca2+ (Intracellular Ca2+ concentration)"
  extends Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep(
    E0 = 0,      // [1]
    Emax = 114,  // [% of Capsaicin]
    EC50 = 2.7e-05,  // [M]
    gamma = 1,
    exposure_per_s = 1);   // 1 M per second
  // exposure_unit_unresolved: 'M' — the x axis is in the paper's unit, not SI
  // defaulted: E0
  // defaulted: gamma
  annotation(experiment(StartTime = 0, StopTime = 0.00027, Interval = 5.4e-07),
    Documentation(info = "<html><body><!-- drug-about --><h4>About phenol</h4><p>Phenol is used as an antiseptic and disinfectant, as a sclerosing agent, and as a local anesthetic for pain relief. It remains an approved medicine used in topical antiseptic and throat preparations, with some investigational uses.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q130336\">Wikidata Q130336</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h4>Phenol_Hinojosa2026_PD_ca2</h4><p>The steady-state exposure-response curve of Hinojosa M et al., <i>Archives of toxicology 100(4):1301–1320</i> 2026 (<a href=\"https://doi.org/10.1007/s00204-025-04288-6\">doi:10.1007/s00204-025-04288-6</a>) — Intracellular Ca2+ concentration against phenol M — obtained by sweeping the driver instead of simulating a dose. Model family: sigmoid_emax.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = (library default) drug-free response (baseline)
  Emax  =        114 % of Capsaicin maximal effect term (Emax, Q320)
  EC50  =    2.7e-05 M        exposure at half of the maximal effect term (EC20, Q321)
  gamma = (library default) Hill coefficient</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep\">SigmoidEmaxSweep</a>; this model only supplies the numbers. The x axis is one M of phenol per second of simulated time: there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0   (drug-free)
  exposure = EC50 (2.7e-05 M)  response 57
  exposure -> infinity  response 114</pre></body></html>"));
end Phenol_Hinojosa2026_PD_ca2;
