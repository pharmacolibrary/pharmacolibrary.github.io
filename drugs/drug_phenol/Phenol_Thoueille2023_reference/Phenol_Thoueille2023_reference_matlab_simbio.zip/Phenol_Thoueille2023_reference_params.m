function p = Phenol_Thoueille2023_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: phenol   source: Thoueille_2023 / reference   route: oral
  % estimated (absent from source): dose
  p.name  = 'Phenol_Thoueille2023_reference_params';
  p.drug  = 'phenol';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 2660.0;                % central volume [L]
  p.CL = 39.9;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 2.0;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 100.0;             % dose [mg]
end
