% Run (SimBiology): build model + dose, simulate 0..3528.0 h, plot.
p = Lebrikizumab_Zhu2017_reference_params();
[model, dose, variant] = build_sb_pk(p);
sd = simulate_sb(model, variant, dose, 3528.0);
