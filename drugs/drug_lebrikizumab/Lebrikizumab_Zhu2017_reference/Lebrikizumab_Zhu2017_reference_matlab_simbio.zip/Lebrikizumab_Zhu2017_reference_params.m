function p = Lebrikizumab_Zhu2017_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: lebrikizumab   source: Zhu_2017 / reference   route: oral
  % estimated (absent from source): dose
  p.name  = 'Lebrikizumab_Zhu2017_reference_params';
  p.drug  = 'lebrikizumab';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 4.1;                % central volume [L]
  p.CL = 0.0065;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.009958;                % absorption rate [1/h]
  p.F  = 0.856;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 100.0;             % dose [mg]
end
