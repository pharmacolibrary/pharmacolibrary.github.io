function p = Amprenavir_Okusanya2007_median_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: amprenavir   source: Okusanya_2007 / median   route: oral
  p.name  = 'Amprenavir_Okusanya2007_median_params';
  p.drug  = 'amprenavir';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 69.09;                % central volume [L]
  p.CL = 64.19;                % clearance [L/h]
  p.Vp = [392.7];             % peripheral volumes [L]
  p.Q  = [22.4];             % inter-compartmental clearances [L/h]
  p.ka = 0.995;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.013;             % absorption lag [h]
  p.dose = 600.0;             % dose [mg]
end
