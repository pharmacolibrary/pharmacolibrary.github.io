model Amprenavir_Okusanya2007_mean
  parameter Real Cl_ref = 2.061111111111111e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.0749 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.505627,
    adminMass = 0.0006,
    ka = 0.0002738888888888889,
    Tlag = 1274.3999999999999,
    k12 = 0.0001105919003115265,
    k21 = 1.5468409586056645e-05
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About amprenavir</h4><p>Amprenavir is a protease inhibitor that was used to treat HIV infection. It has been withdrawn, including from the European Union, and is no longer available.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q422198\">Wikidata Q422198</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>amprenavir</td></tr><tr><td>population:</td><td>HIV-seronegative healthy adults</td></tr><tr><td>source_paper:</td><td>Okusanya_2007</td></tr><tr><td>measured_compound:</td><td>amprenavir</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>tab_1</td></tr><tr><td>input:</td><td>PK_2C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>amprenavir 505.627 g/mol (drugbank)</td></tr></table><h4>Interpretation flags</h4><ul><li>dropped unlinked row (NIL): 'Recycling time (h)' — extend the ontology if this is a real PK parameter (source ['tab_1:row7:col1'])</li><li>apparent-ness (ontology-grounded): parameterization=apparent, measured_compound=amprenavir</li><li>population split: 'mean' subgroup of Okusanya_2007 (paper reports 2 populations: mean, median)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Amprenavir_Okusanya2007_mean;
