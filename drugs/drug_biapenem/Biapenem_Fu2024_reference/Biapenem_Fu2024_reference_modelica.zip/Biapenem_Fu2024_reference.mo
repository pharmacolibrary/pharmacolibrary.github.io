model Biapenem_Fu2024_reference
  parameter Real Cl_ref = 1.4666666666666667e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.01089292463672803 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.35039,
    adminMass = 0.0012
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About biapenem</h4><p>Biapenem is a carbapenem antibiotic (a beta-lactam antibacterial) with bactericidal, anti-infective activity, investigated for treating bacterial infections. It is considered investigational and is not authorised in the European Union.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q4902548\">Wikidata Q4902548</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>biapenem</td></tr><tr><td>population:</td><td>review reference</td></tr><tr><td>source_paper:</td><td>Fu_2024</td></tr><tr><td>measured_compound:</td><td>biapenem</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>biapenem 350.39 g/mol (drugbank)</td></tr></table><h4>Interpretation flags</h4><ul><li>built from REVIEW reference values (Fu_2024) — secondary source</li><li>central volume derived from CL·t½/ln2</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Biapenem_Fu2024_reference;
