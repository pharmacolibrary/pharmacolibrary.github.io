// parent + metabolites (carboxyprimaquine): PK_3M_3C — first-pass formation; parent 2 + hepatic, metabolites [1]
model Primaquine_Chairat2018_reference
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_3M_3C(
    Vd1 = 0.0223,
    Vd2 = 0.0223,
    q12 = 2.4999999999999998e-05,
    q21 = 2.4999999999999998e-05,
    q1_m11 = 2.951666666666667e-06,
    CL1 = 3.4650000000000003e-06,
    Vd1m1 = 0.0105,
    CLm1 = 1.0472222222222222e-07,
    MW = 0.2593467,
    MW_m1 = 0.27432,
    F = 1,
    ka = 0.0001388888888888889,
    Tlag = 0.0,
    adminDuration = 600,
    adminCount = 1,
    adminMass = 3e-05
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About primaquine</h4><p>Primaquine is an antimalarial drug used to treat malaria, including Plasmodium vivax and Plasmodium falciparum infections, and for malaria prophylaxis. It is an approved medicine and appears on the WHO list of essential medicines, so it remains in use worldwide.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q419834\">Wikidata Q419834</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>primaquine</td></tr><tr><td>population:</td><td>healthy adult volunteers</td></tr><tr><td>source_paper:</td><td>Chairat_2018</td></tr><tr><td>measured_compound:</td><td>primaquine</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>parent_metabolite</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>dky297-T1</td></tr><tr><td>input:</td><td>PK_3M_3C: apparent (/F) parameterization ⇒ extravascular dosing; hepatic volume not reported separately — set equal to the central volume (as Jung_2024 fixes Vc = VH); formation of carboxyprimaquine: fm=0.46 × CL; dose 30 mg (paper)</td></tr><tr><td>molar_masses:</td><td>carboxyprimaquine 274.32 g/mol (pubchem); primaquine 259.347 g/mol (drugbank)</td></tr></table><p><b>Defaulted (base-class default used):</b> q12/q21 (hepatic flow, 90 L/h), ka.</p><h4>Interpretation flags</h4><ul><li>dropped value-less row: 'NA'</li><li>NIL: refused to back-fill base 'NIL' from footnote/prose loose number 1000 (source ['dky297-T1:footnote']); the table cell was unparseable — needs review</li><li>implicit units: 'V/FPRQ' → L (from the paper text: &quot;Table 1 lists the parameter as 'V/FPRQ (L)', i.e. volume of distribution adjusted for bioavailability in litres (text: '&quot;)</li><li>metabolite volume: 'V/FCPRQ (L)' Q63→Q61 for carboxyprimaquine — it is 1-compartment, so its central volume is its only volume</li><li>apparent-ness (ontology-grounded): parameterization=apparent, measured_compound=primaquine</li><li>template fit: PK_3M_3C — first-pass formation; parent 2 + hepatic, metabolites [1] (site presystemic: 'Incorporation of hepatic first-pass metabolism showed a significant improvement (P < 0.05) in model fit (ΔOFV of −260, −')</li><li>row roles (LLM): model_class=compartmental; 22/22 row label(s) assigned, 39 linked by role; re-tagged primaquine→parent ×68, primaquine→carboxyprimaquine ×36</li><li>skipped review gap-fill of V2: primary is PARENT_METABOLITE (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is PARENT_METABOLITE (peripheral family needs ≥2C)</li><li>gap-filled Q83 (tlag) from Fasinu_2022_2's review values (primary lacked it)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Primaquine_Chairat2018_reference;
