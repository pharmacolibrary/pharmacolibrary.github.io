model Primaquine_Sridharan2019_reference
  parameter Real Cl_ref = 2.872222222222222e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.0119 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 0.9,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.2593467,
    adminMass = 1.5e-05,
    ka = 0.005022222222222221,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About primaquine</h4><p>Primaquine is an antimalarial drug used to treat malaria, including Plasmodium vivax and Plasmodium falciparum infections, and for malaria prophylaxis. It is an approved medicine and appears on the WHO list of essential medicines, so it remains in use worldwide.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q419834\">Wikidata Q419834</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>primaquine</td></tr><tr><td>population:</td><td>healthy volunteers and patients with hepatic or renal dysfunction</td></tr><tr><td>source_paper:</td><td>Sridharan_2019</td></tr><tr><td>measured_compound:</td><td>primaquine</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>T2</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>primaquine 259.347 g/mol (drugbank)</td></tr></table><p><b>Defaulted (base-class default used):</b> F, Tlag.</p><h4>Interpretation flags</h4><ul><li>table section iiv: 'BSV on CL (% CV)' routed out of structural estimates ('Between subject variability')</li><li>table section iiv: 'BSV on CL (% CV)' routed out of structural estimates ('Between subject variability')</li><li>table section iiv: 'BSV on CL (% CV)' routed out of structural estimates ('Between subject variability')</li><li>table section iiv: 'BSV on CL (% CV)' routed out of structural estimates ('Between subject variability')</li><li>table section iiv: 'BSV on V (% CV)' routed out of structural estimates ('Between subject variability')</li><li>table section iiv: 'BSV on V (% CV)' routed out of structural estimates ('Between subject variability')</li><li>table section iiv: 'BSV on V (% CV)' routed out of structural estimates ('Between subject variability')</li><li>table section iiv: 'BSV on V (% CV)' routed out of structural estimates ('Between subject variability')</li><li>table section iiv: 'BSV on Ka (% CV)' routed out of structural estimates ('Between subject variability')</li><li>table section iiv: 'BSV on Ka (% CV)' routed out of structural estimates ('Between subject variability')</li><li>table section iiv: 'BSV on Ka (% CV)' routed out of structural estimates ('Between subject variability')</li><li>table section iiv: 'BSV on Ka (% CV)' routed out of structural estimates ('Between subject variability')</li><li>table section residual_error: 'Proportional (% CV)' routed out of structural estimates ('Residual variability')</li><li>table section residual_error: 'Proportional (% CV)' routed out of structural estimates ('Residual variability')</li><li>table section residual_error: 'Proportional (% CV)' routed out of structural estimates ('Residual variability')</li><li>table section residual_error: 'Proportional (% CV)' routed out of structural estimates ('Residual variability')</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Primaquine_Sridharan2019_reference;
