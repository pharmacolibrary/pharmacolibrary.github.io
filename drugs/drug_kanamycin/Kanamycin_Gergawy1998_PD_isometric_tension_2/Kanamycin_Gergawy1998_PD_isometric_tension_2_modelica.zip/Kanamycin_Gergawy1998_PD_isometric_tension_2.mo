model Kanamycin_Gergawy1998_PD_isometric_tension_2
  "sigmoid_emax exposure-response sweep — Gergawy_1998 :: isometric tension (isometric tension)"
  extends Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep(
    E0 = 0,      // [1]
    Emax = -0.594,  // [1; % × 0.01]
    EC50 = 3.72,  // [mM]
    gamma = 1,
    exposure_per_s = 1);   // 1 mM per second
  // imax_as_negative_emax: Imax (Q323) enters SigmoidEmaxSweep as −Emax
  // exposure_unit_unresolved: 'mM' — the x axis is in the paper's unit, not SI
  // defaulted: E0
  // defaulted: gamma
  annotation(experiment(StartTime = 0, StopTime = 38, Interval = 0.076),
    Documentation(info = "<html><body><h4>Kanamycin_Gergawy1998_PD_isometric_tension_2</h4><p>The steady-state exposure-response curve of Gergawy M et al., <i>British journal of pharmacology 125(6):1150–1157</i> 1998 (<a href=\"https://doi.org/10.1038/sj.bjp.0702180\">doi:10.1038/sj.bjp.0702180</a>) — isometric tension [%] against kanamycin mM — obtained by sweeping the driver instead of simulating a dose. Model family: sigmoid_emax.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = (library default) drug-free response (baseline)
  Emax  =       59.4 %        maximal effect term (maximal relaxant eect, Q323)
  EC50  =       3.72 mM       exposure at half of the maximal effect term (EC 50, Q321)
  gamma = (library default) Hill coefficient</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep\">SigmoidEmaxSweep</a>; this model only supplies the numbers. The x axis is one mM of kanamycin per second of simulated time: there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0   (drug-free)
  exposure = EC50 (3.72 mM)  response -0.297
  exposure -> infinity  response -0.594</pre></body></html>"));
end Kanamycin_Gergawy1998_PD_isometric_tension_2;
