function p = Kanamycin_Gergawy1998_PD_isometric_tension_3_params()
% Kanamycin_Gergawy1998_PD_isometric_tension_3_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% kanamycin Gergawy_1998::isometric_tension::3: sigmoid_emax exposure-response sweep (response = E0 + Emax*frac). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one mM per second, in SI inside (kg/m3, s). Response isometric tension in %. Driver: kanamycin (cited_pk).
p.E0 = 0.0;
p.Emax = -0.528;
p.EC50 = 4.51;
p.gamma = 1.0;
p.slope = 0.0;
p.exposure_per_s = 1.0;
p.stop_time = 46.0;
p.form = 'E0 + Emax*frac';
end
