function p = Mirogabalin_Li2023_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: mirogabalin   source: Li_2023 / reference   route: oral
  % estimated (absent from source): ka
  p.name  = 'Mirogabalin_Li2023_reference_params';
  p.drug  = 'mirogabalin';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 73.4;                % central volume [L]
  p.CL = 17.6;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.5;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 25.0;             % dose [mg]
end
