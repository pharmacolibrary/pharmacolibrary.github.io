model Lamivudine_Chandasana2024v2_reference
  parameter Real Cl_ref = 2.3833333333333334e-07 "Cl [m3/s]";
  parameter Real cov_wt = 79.0 "wt covariate (reference 79.0)";
  parameter Real cov_bilirubin = 79.0 "bilirubin covariate (reference 79.0)";
  parameter Real cov_ethnicity = 79.0 "ethnicity covariate (reference 79.0)";
  parameter Real cov_egfr = 79.0 "egfr covariate (reference 79.0)";
  parameter Real cov_race = 79.0 "race covariate (reference 79.0)";
  parameter Real Vd_ref = 0.0167 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref*(cov_wt/79.0)^(0.427)*(cov_bilirubin/79.0)^(-0.153)*(cov_ethnicity/79.0)^(0.844)*(cov_egfr/79.0)^(0.533)*(cov_race/79.0)^(0.789),
    Vd = Vd_ref*(cov_wt/79.0)^(0.917),
    adminDuration = 600,
    adminCount = 1,
    MM = 0.229256,
    adminMass = 5e-05,
    ka = 0.0005972222222222222,
    Tlag = 0.0,
    k21 = 7.85714285714286e-06
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About lamivudine</h4><p>Lamivudine is an antiviral nucleoside analogue used to treat HIV infection and chronic hepatitis B. It is widely used, appears on the WHO essential medicines list, and is authorised in the European Union for HIV and hepatitis B, often in combination products.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q422631\">Wikidata Q422631</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>lamivudine</td></tr><tr><td>population:</td><td>virologically suppressed adults living with HIV-1</td></tr><tr><td>source_paper:</td><td>Chandasana_2024_2</td></tr><tr><td>measured_compound:</td><td>lamivudine</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>T2</td></tr><tr><td>input:</td><td>PK_2C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>lamivudine 229.256 g/mol (drugbank)</td></tr></table><p><b>Defaulted (base-class default used):</b> Tlag, k12.</p><h4>Interpretation flags</h4><ul><li>table section iiv: 'ω2CL/F' routed out of structural estimates ('Inter-individual variability')</li><li>table section iiv: 'ω2CL/F' routed out of structural estimates ('Inter-individual variability')</li><li>table section iiv: 'ω2CL/F' routed out of structural estimates ('Inter-individual variability')</li><li>table section iiv: 'ω2CL/F' routed out of structural estimates ('Inter-individual variability')</li><li>table section iiv: 'ω2proportional error' routed out of structural estimates ('Inter-individual variability')</li><li>table section iiv: 'ω2proportional error' routed out of structural estimates ('Inter-individual variability')</li><li>table section iiv: 'ω2proportional error' routed out of structural estimates ('Inter-individual variability')</li><li>table section iiv: 'ω2proportional error' routed out of structural estimates ('Inter-individual variability')</li><li>table section residual_error: 'σ2prop' routed out of structural estimates ('Residual variability')</li><li>table section residual_error: 'σ2prop' routed out of structural estimates ('Residual variability')</li><li>table section residual_error: 'σ2prop' routed out of structural estimates ('Residual variability')</li><li>table section iiv: 'ω2CL/F' routed out of structural estimates ('Inter-individual variability')</li><li>table section iiv: 'ω2CL/F' routed out of structural estimates ('Inter-individual variability')</li><li>table section iiv: 'ω2CL/F' routed out of structural estimates ('Inter-individual variability')</li><li>table section iiv: 'ω2CL/F' routed out of structural estimates ('Inter-individual variability')</li><li>table section iiv: 'BSCCL/F~V2/F' routed out of structural estimates ('Inter-individual variability')</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 259200, Tolerance = 1e-9, Interval = 1));
end Lamivudine_Chandasana2024v2_reference;
