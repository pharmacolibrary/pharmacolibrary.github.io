% Run (SimBiology): build model + dose, simulate 0..72.0 h, plot.
p = Lamivudine_Chandasana2024v2_reference_params();
[model, dose, variant] = build_sb_pk(p);
sd = simulate_sb(model, variant, dose, 72.0);
