model AngiotensinIi_Steichert2025_reference
  parameter Real Cl_ref = 1.0108333333333333e-05 "Cl [m3/s]";
  parameter Real Vd_ref = 0.22371000000000002 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 1.0461969999999998,
    adminMass = 1.89e-05,
    ka = 0.00033055555555555556,
    Tlag = 0.0,
    k12 = 7.921962461321452e-06,
    k21 = 1.637005562739906e-05
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>angiotensin_ii</td></tr><tr><td>population:</td><td>review reference</td></tr><tr><td>source_paper:</td><td>Steichert_2025</td></tr><tr><td>measured_compound:</td><td>angiotensin_ii</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_2C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>angiotensin_ii 1046.2 g/mol (pubchem)</td></tr></table><p><b>Defaulted (base-class default used):</b> Tlag.</p><h4>Interpretation flags</h4><ul><li>built from REVIEW reference values (Steichert_2025) — secondary source</li><li>volume reported by review</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end AngiotensinIi_Steichert2025_reference;
