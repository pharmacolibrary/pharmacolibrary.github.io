% Run (SimBiology): build model + dose, simulate 0..36.0 h, plot.
p = AngiotensinIi_Athanassa2025_reference_params();
[model, dose, variant] = build_sb_pk(p);
sd = simulate_sb(model, variant, dose, 36.0);
