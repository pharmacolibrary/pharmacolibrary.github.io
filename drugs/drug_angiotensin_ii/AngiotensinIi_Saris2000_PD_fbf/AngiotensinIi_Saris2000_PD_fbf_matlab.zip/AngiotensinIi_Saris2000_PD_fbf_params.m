function p = AngiotensinIi_Saris2000_PD_fbf_params()
% AngiotensinIi_Saris2000_PD_fbf_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% angiotensin_ii Saris_2000::FBF: sigmoid_emax exposure-response sweep (response = E0 + Emax*frac). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one nmol/L per second, in SI inside (kg/m3, s). Response FBF in %. Driver: angiotensin_ii (cited_pk).
p.E0 = 0.0;
p.Emax = -0.75;
p.EC50 = 3.6e-06;
p.gamma = 1.0;
p.slope = 0.0;
p.exposure_per_s = 1e-06;
p.stop_time = 36.0;
p.form = 'E0 + Emax*frac';
end
