model AngiotensinIi_Saris2000_PD_fbf
  "sigmoid_emax exposure-response sweep — Saris_2000 :: FBF (forearm blood flow)"
  extends Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep(
    E0 = 0,      // [1]
    Emax = -0.75,  // [1; % × 0.01]
    EC50 = 3.6e-06,  // [mol/m3; nmol/L × 1e-06]
    gamma = 1,
    exposure_per_s = 1e-06);   // 1 nmol/L per second
  // imax_as_negative_emax: Imax (Q323) enters SigmoidEmaxSweep as −Emax
  // defaulted: E0
  // defaulted: gamma
  annotation(experiment(StartTime = 0, StopTime = 36, Interval = 0.072),
    Documentation(info = "<html><body><!-- drug-about --><h4>About angiotensin_ii</h4><p>Angiotensin II, a peptide hormone, is used as a cardiac stimulant to raise blood pressure in hypotension and shock. It is authorised in the European Union, but its use is limited to a single approved product, mainly in hospital settings for severe low blood pressure.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q412999\">Wikidata Q412999</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h4>AngiotensinIi_Saris2000_PD_fbf</h4><p>The steady-state exposure-response curve of Saris JJ et al., <i>Hypertension (Dallas, Tex. : 1979) 35(3):764–768</i> 2000 (<a href=\"https://doi.org/10.1161/01.hyp.35.3.764\">doi:10.1161/01.hyp.35.3.764</a>) — forearm blood flow [%] against angiotensin_ii nmol/L — obtained by sweeping the driver instead of simulating a dose. Model family: sigmoid_emax.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = (library default) drug-free response (baseline)
  Emax  =         75 %        maximal effect term (maximal effect, Q323)
  EC50  =        3.6 nmol/L   exposure at half of the maximal effect term (EC 50, Q321)
  gamma = (library default) Hill coefficient</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep\">SigmoidEmaxSweep</a>; this model only supplies the numbers. The x axis is one nmol/L of angiotensin_ii per second of simulated time (exposure is in mol/m3): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0   (drug-free)
  exposure = EC50 (3.6 nmol/L)  response -0.375
  exposure -> infinity  response -0.75</pre></body></html>"));
end AngiotensinIi_Saris2000_PD_fbf;
