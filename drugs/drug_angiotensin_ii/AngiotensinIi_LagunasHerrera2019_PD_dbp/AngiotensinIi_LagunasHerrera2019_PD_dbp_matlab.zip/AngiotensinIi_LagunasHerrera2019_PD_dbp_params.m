function p = AngiotensinIi_LagunasHerrera2019_PD_dbp_params()
% AngiotensinIi_LagunasHerrera2019_PD_dbp_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% angiotensin_ii Lagunas-Herrera_2019::DBP: emax exposure-response sweep (response = E0 + Emax*frac). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one µg/kg per second, in SI inside (kg/m3, s). Response DBP in mmHg. Driver: angiotensin II (dose_only).
p.E0 = 0.0;
p.Emax = 98.0;
p.EC50 = 4.6e-11;
p.gamma = 1.0;
p.slope = 0.0;
p.exposure_per_s = 1e-09;
p.stop_time = 0.46;
p.form = 'E0 + Emax*frac';
end
