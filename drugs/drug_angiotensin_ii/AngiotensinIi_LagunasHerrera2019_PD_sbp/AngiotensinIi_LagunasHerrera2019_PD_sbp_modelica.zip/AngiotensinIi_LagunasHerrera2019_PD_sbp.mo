model AngiotensinIi_LagunasHerrera2019_PD_sbp
  "emax exposure-response sweep — Lagunas-Herrera_2019 :: SBP (systolic blood pressure)"
  extends Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep(
    E0 = 0,      // [1]
    Emax = 135,  // [mmHg]
    EC50 = 3.8e-11,  // [1; µg/kg × 1e-09]
    gamma = 1,
    exposure_per_s = 1e-09);   // 1 µg/kg per second
  // defaulted: E0
  // defaulted: gamma
  annotation(experiment(StartTime = 0, StopTime = 0.38, Interval = 0.00076),
    Documentation(info = "<html><body><!-- drug-about --><h4>About angiotensin_ii</h4><p>Angiotensin II, a peptide hormone, is used as a cardiac stimulant to raise blood pressure in hypotension and shock. It is authorised in the European Union, but its use is limited to a single approved product, mainly in hospital settings for severe low blood pressure.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q412999\">Wikidata Q412999</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h4>AngiotensinIi_LagunasHerrera2019_PD_sbp</h4><p>The steady-state exposure-response curve of Lagunas-Herrera H et al., <i>Biological &amp; pharmaceutical bulletin 42(1):18–25</i> 2019 (<a href=\"https://doi.org/10.1248/bpb.b18-00355\">doi:10.1248/bpb.b18-00355</a>) — systolic blood pressure [mmHg] against angiotensin II µg/kg — obtained by sweeping the driver instead of simulating a dose. Model family: emax.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = (library default) drug-free response (baseline)
  Emax  =        135 mmHg     maximal effect term (E max, Q320)
  EC50  =      0.038 µg/kg    exposure at half of the maximal effect term (ED 50, Q321)
  gamma = (library default) Hill coefficient</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep\">SigmoidEmaxSweep</a>; this model only supplies the numbers. The x axis is one µg/kg of angiotensin II per second of simulated time: there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0   (drug-free)
  exposure = EC50 (0.038 µg/kg)  response 67.5
  exposure -> infinity  response 135</pre></body></html>"));
end AngiotensinIi_LagunasHerrera2019_PD_sbp;
