model AngiotensinIi_Ghatta2004_PD_ang_ii
  "emax exposure-response sweep — Ghatta_2004 :: Ang II (contractile responses)"
  extends Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep(
    E0 = 0,      // [1]
    Emax = 0.34,  // [1; % × 0.01]
    EC50 = 7.31,  // [nM]
    gamma = 1,
    exposure_per_s = 1);   // 1 nM per second
  // exposure_unit_unresolved: 'nM' — the x axis is in the paper's unit, not SI
  // defaulted: E0
  // defaulted: gamma
  annotation(experiment(StartTime = 0, StopTime = 74, Interval = 0.148),
    Documentation(info = "<html><body><!-- drug-about --><h4>About angiotensin_ii</h4><p>Angiotensin II, a peptide hormone, is used as a cardiac stimulant to raise blood pressure in hypotension and shock. It is authorised in the European Union, but its use is limited to a single approved product, mainly in hospital settings for severe low blood pressure.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q412999\">Wikidata Q412999</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h4>AngiotensinIi_Ghatta2004_PD_ang_ii</h4><p>The steady-state exposure-response curve of Ghatta S et al., <i>Lipids in health and disease 3:19</i> 2004 (<a href=\"https://doi.org/10.1186/1476-511X-3-19\">doi:10.1186/1476-511X-3-19</a>) — contractile responses [%] against Angiotensin II nM — obtained by sweeping the driver instead of simulating a dose. Model family: emax.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = (library default) drug-free response (baseline)
  Emax  =         34 %        maximal effect term (Emax of Ang II, Q320)
  EC50  =       7.31 nM       exposure at half of the maximal effect term (pD2 of Ang II, Q321)
  gamma = (library default) Hill coefficient</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep\">SigmoidEmaxSweep</a>; this model only supplies the numbers. The x axis is one nM of Angiotensin II per second of simulated time: there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0   (drug-free)
  exposure = EC50 (7.31 nM)  response 0.17
  exposure -> infinity  response 0.34</pre></body></html>"));
end AngiotensinIi_Ghatta2004_PD_ang_ii;
