function p = AngiotensinIi_Ghatta2004_PD_ang_ii_params()
% AngiotensinIi_Ghatta2004_PD_ang_ii_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% angiotensin_ii Ghatta_2004::Ang_II: emax exposure-response sweep (response = E0 + Emax*frac). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one nM per second, in SI inside (kg/m3, s). Response Ang II in %. Driver: Angiotensin II (conc_no_pk).
p.E0 = 0.0;
p.Emax = 0.34;
p.EC50 = 7.31;
p.gamma = 1.0;
p.slope = 0.0;
p.exposure_per_s = 1.0;
p.stop_time = 74.0;
p.form = 'E0 + Emax*frac';
end
