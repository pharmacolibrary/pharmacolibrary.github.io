model AngiotensinIi_Xu2014_PD_aldo
  "emax exposure-response sweep — Xu_2014 :: Aldo (aldosterone)"
  extends Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep(
    E0 = 0,      // [1]
    Emax = 9.263e-07,  // [kg/m3; ng/dl × 1e-08]
    EC50 = 9.4129e-08,  // [kg/m3; pg/ml × 1e-09]
    gamma = 9.97,
    exposure_per_s = 1e-09);   // 1 pg/ml per second
  // defaulted: E0
  annotation(experiment(StartTime = 0, StopTime = 950, Interval = 1.9),
    Documentation(info = "<html><body><!-- drug-about --><h4>About angiotensin_ii</h4><p>Angiotensin II, a peptide hormone, is used as a cardiac stimulant to raise blood pressure in hypotension and shock. It is authorised in the European Union, but its use is limited to a single approved product, mainly in hospital settings for severe low blood pressure.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q412999\">Wikidata Q412999</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h4>AngiotensinIi_Xu2014_PD_aldo</h4><p>The steady-state exposure-response curve of Xu R et al., <i>PloS one 9(12):e114049</i> 2014 (<a href=\"https://doi.org/10.1371/journal.pone.0114049\">doi:10.1371/journal.pone.0114049</a>) — aldosterone [ng/dl] against angiotensin_ii pg/ml — obtained by sweeping the driver instead of simulating a dose. Model family: emax.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = (library default) drug-free response (baseline)
  Emax  =      92.63 ng/dl    maximal effect term (Smax, Q320)
  EC50  =     94.129 pg/ml    exposure at half of the maximal effect term (SC50AngII, Q321)
  gamma =       9.97          Hill coefficient (Γ, Q325)</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep\">SigmoidEmaxSweep</a>; this model only supplies the numbers. The x axis is one pg/ml of angiotensin_ii per second of simulated time (exposure is in kg/m3): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0   (drug-free)
  exposure = EC50 (94.129 pg/ml)  response 4.631e-07
  exposure -> infinity  response 9.263e-07</pre></body></html>"));
end AngiotensinIi_Xu2014_PD_aldo;
