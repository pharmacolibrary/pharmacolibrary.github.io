function p = AngiotensinIi_Xu2014_PD_aldo_params()
% AngiotensinIi_Xu2014_PD_aldo_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% angiotensin_ii Xu_2014::Aldo: emax exposure-response sweep (response = E0 + Emax*frac). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one pg/ml per second, in SI inside (kg/m3, s). Response Aldo in ng/dl. Driver: angiotensin_ii (cited_pk).
p.E0 = 0.0;
p.Emax = 9.262999999999998e-07;
p.EC50 = 9.412900000000001e-08;
p.gamma = 9.97;
p.slope = 0.0;
p.exposure_per_s = 1e-09;
p.stop_time = 950.0;
p.form = 'E0 + Emax*frac';
end
