model Voriconazole_Wang2024_reference
  parameter Real Cl_ref = 8.944444444444445e-07 "Cl [m3/s]";
  parameter Real Vd_ref = 0.194 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.34931049999999997,
    adminMass = 0.0004
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About voriconazole</h4><p>Voriconazole is an antifungal medicine used to treat serious fungal infections such as aspergillosis, candidiasis, and other systemic mycoses. It is authorised in the European Union and is included on the WHO list of essential medicines, so it is widely used for systemic fungal infections.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q412236\">Wikidata Q412236</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>voriconazole</td></tr><tr><td>population:</td><td>elderly Chinese patients with invasive aspergillosis</td></tr><tr><td>source_paper:</td><td>Wang_2024</td></tr><tr><td>measured_compound:</td><td>voriconazole</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>voriconazole 349.31 g/mol (drugbank)</td></tr></table><h4>Interpretation flags</h4><ul><li>dropped value-less row: 'albumin (ALB)' (captured trailing unit 'ALB' for child rows)</li><li>dropped value-less row: 'gamma-glutamyl transpeptidase'</li><li>dropped value-less row: 'direct bilirubin'</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=voriconazole</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 777600, Tolerance = 1e-9, Interval = 1));
end Voriconazole_Wang2024_reference;
