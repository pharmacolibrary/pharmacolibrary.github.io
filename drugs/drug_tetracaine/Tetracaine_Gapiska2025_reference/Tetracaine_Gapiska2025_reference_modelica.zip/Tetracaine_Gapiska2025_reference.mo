model Tetracaine_Gapiska2025_reference
  parameter Real Cl_ref = 9.076666666666666e-05 "Cl [m3/s]";
  parameter Real Vd_ref = 0.7791000000000001 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.264369,
    adminMass = 0.0001,
    ka = 0.0001388888888888889,
    Tlag = 0.0,
    k12 = 1.0696102340307191e-08
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About tetracaine</h4><p>Tetracaine is a local anesthetic used to prevent or relieve pain, including topical use on skin, eye, and hemorrhoids or anal fissures. It is widely used and appears on the WHO list of essential medicines, and is also approved for veterinary use.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q419608\">Wikidata Q419608</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>tetracaine</td></tr><tr><td>population:</td><td>review reference</td></tr><tr><td>source_paper:</td><td>Gapińska_2025</td></tr><tr><td>measured_compound:</td><td>tetracaine</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_2C_enteral: apparent (/F) parameterization ⇒ extravascular dosing</td></tr><tr><td>molar_masses:</td><td>tetracaine 264.369 g/mol (drugbank)</td></tr></table><p><b>Defaulted (base-class default used):</b> ka, Tlag, k21.</p><h4>Interpretation flags</h4><ul><li>built from REVIEW reference values (Gapińska_2025) — secondary source</li><li>volume reported by review</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Tetracaine_Gapiska2025_reference;
