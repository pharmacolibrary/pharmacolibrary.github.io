function p = Amantadine_Jaber2021_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: amantadine   source: Jaber_2021 / reference   route: oral
  % estimated (absent from source): F
  p.name  = 'Amantadine_Jaber2021_reference_params';
  p.drug  = 'amantadine';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 38.9;                % central volume [L]
  p.CL = 22.6;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 3.3;                % absorption rate [1/h]
  p.F  = 0.9;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 200.0;             % dose [mg]
end
