model Amantadine_Riley2026_reference
  parameter Real Cl_ref = 2.6133333333333333e-05 "Cl [m3/s]";
  parameter Real Vd_ref = 0.2233 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C_enteral(
    weight = 70.0,
    F = 0.9,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.1512487,
    adminMass = 0.00021,
    ka = 0.0008777777777777778,
    Tlag = 0.0,
    k12 = 3.5423197492163014e-05,
    k21 = 5.207373271889401e-05
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About amantadine</h4><p>Amantadine is a medication used to treat Parkinson's disease and the dyskinesia associated with parkinsonism, and it has also been used against influenza. It is an approved drug, classified as an antiparkinson dopaminergic agent, and is used in human medicine.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q409761\">Wikidata Q409761</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>amantadine</td></tr><tr><td>population:</td><td>healthy adult horses</td></tr><tr><td>source_paper:</td><td>Riley_2026</td></tr><tr><td>measured_compound:</td><td>amantadine</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>Tab2</td></tr><tr><td>input:</td><td>PK_2C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>amantadine 151.249 g/mol (drugbank)</td></tr></table><p><b>Defaulted (base-class default used):</b> F, Tlag.</p><h4>Interpretation flags</h4><ul><li>table section iiv: 'V' routed out of structural estimates ('Between subject variability (%CV)')</li><li>table section iiv: 'V' routed out of structural estimates ('Between subject variability (%CV)')</li><li>table section iiv: 'V2' routed out of structural estimates ('Between subject variability (%CV)')</li><li>table section iiv: 'V2' routed out of structural estimates ('Between subject variability (%CV)')</li><li>table section iiv: 'Cl' routed out of structural estimates ('Between subject variability (%CV)')</li><li>table section iiv: 'Cl' routed out of structural estimates ('Between subject variability (%CV)')</li><li>table section iiv: 'Cl2' routed out of structural estimates ('Between subject variability (%CV)')</li><li>table section iiv: 'Cl2' routed out of structural estimates ('Between subject variability (%CV)')</li><li>table section iiv: 'Fbio' routed out of structural estimates ('Between subject variability (%CV)')</li><li>table section iiv: 'Fbio' routed out of structural estimates ('Between subject variability (%CV)')</li><li>dropped duplicate Q57 ('Effective HL (h)', value '2.76') — already have one for this compound</li><li>routed 'stdev0' → Q315 (sigma) to residual_error — variability estimate, not a structural parameter</li><li>dropped value-less row: 'tvKa, rate of absorption'</li><li>dropped value-less row: 'tvV, the value of the central compartment'</li><li>dropped value-less row: 'tvV2, denotes the value of the peripheral compartment'</li><li>dropped value-less row: 'tvCl, the clearance of drug from plasma'</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Amantadine_Riley2026_reference;
