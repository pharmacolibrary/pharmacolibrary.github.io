model Levosimendan_Bertin2025_reference
  parameter Real Cl_ref = 6.988333333333333e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.1036 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.2802847,
    adminMass = 1.1e-05
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About levosimendan</h4><p>Levosimendan is a calcium sensitiser used to treat acutely decompensated congestive heart failure. It is an approved cardiac stimulant, though its use appears limited and it has also been investigated and withdrawn in some settings.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q162541\">Wikidata Q162541</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>levosimendan</td></tr><tr><td>population:</td><td>review reference</td></tr><tr><td>source_paper:</td><td>Bertin_2025</td></tr><tr><td>measured_compound:</td><td>levosimendan</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>levosimendan 280.285 g/mol (drugbank)</td></tr></table><h4>Interpretation flags</h4><ul><li>built from REVIEW reference values (Bertin_2025) — secondary source</li><li>volume reported by review</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Levosimendan_Bertin2025_reference;
