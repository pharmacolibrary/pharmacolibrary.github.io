model Levosimendan_Wanderer2022_PD_unknown
  "emax exposure-response sweep — Wanderer_2022 :: unknown (vasorelaxation)"
  extends Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep(
    E0 = 0.0,      // [1]
    Emax = 1.03,  // [1; % × 0.01]
    EC50 = 5.38,  // [-log10EC50]
    gamma = 1.0,
    exposure_per_s = 1.0);   // 1 -log10EC50 per second
  // exposure_unit_unresolved: '-log10EC50' — the x axis is in the paper's unit, not SI
  // defaulted: E0
  // defaulted: gamma
  annotation(experiment(StartTime = 0, StopTime = 53.8, Interval = 0.1076));
end Levosimendan_Wanderer2022_PD_unknown;
