model Levosimendan_Wanderer2022_PD_unknown
  "emax exposure-response sweep — Wanderer_2022 :: unknown (vasorelaxation)"
  extends Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep(
    E0 = 0,      // [1]
    Emax = 1.03,  // [1; % × 0.01]
    EC50 = 5.38,  // [-log10EC50]
    gamma = 1,
    exposure_per_s = 1);   // 1 -log10EC50 per second
  // exposure_unit_unresolved: '-log10EC50' — the x axis is in the paper's unit, not SI
  // defaulted: E0
  // defaulted: gamma
  annotation(experiment(StartTime = 0, StopTime = 54, Interval = 0.108),
    Documentation(info = "<html><body><h4>Levosimendan_Wanderer2022_PD_unknown</h4><p>The steady-state exposure-response curve of Wanderer S et al., <i>Journal of neurointerventional surgery 14(4):408–412</i> 2022 (<a href=\"https://doi.org/10.1136/neurintsurg-2021-017504\">doi:10.1136/neurintsurg-2021-017504</a>) — vasorelaxation [%] against levosimendan -log10EC50 — obtained by sweeping the driver instead of simulating a dose. Model family: emax.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = (library default) drug-free response (baseline)
  Emax  =        103 %        maximal effect term (Emax, Q320)
  EC50  =       5.38 -log10EC50 exposure at half of the maximal effect term (pD2 (-log10EC50), Q321)
  gamma = (library default) Hill coefficient</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep\">SigmoidEmaxSweep</a>; this model only supplies the numbers. The x axis is one -log10EC50 of levosimendan per second of simulated time: there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0   (drug-free)
  exposure = EC50 (5.38 -log10EC50)  response 0.515
  exposure -> infinity  response 1.03</pre></body></html>"));
end Levosimendan_Wanderer2022_PD_unknown;
