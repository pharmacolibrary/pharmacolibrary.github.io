function p = Levosimendan_Wanderer2022_PD_unknown_params()
% Levosimendan_Wanderer2022_PD_unknown_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% levosimendan Wanderer_2022::unknown: emax exposure-response sweep (response = E0 + Emax*frac). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one -log10EC50 per second, in SI inside (kg/m3, s). Response unknown in %. Driver: levosimendan (cited_pk).
p.E0 = 0.0;
p.Emax = 1.03;
p.EC50 = 5.38;
p.gamma = 1.0;
p.slope = 0.0;
p.exposure_per_s = 1.0;
p.stop_time = 54.0;
p.form = 'E0 + Emax*frac';
end
