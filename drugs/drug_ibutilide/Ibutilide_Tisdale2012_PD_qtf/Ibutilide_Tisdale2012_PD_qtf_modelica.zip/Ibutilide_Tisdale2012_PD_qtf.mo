model Ibutilide_Tisdale2012_PD_qtf
  "sigmoid_emax exposure-response sweep — Tisdale_2012 :: QTF (QTF interval)"
  extends Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep(
    E0 = 0,      // [1]
    Emax = 0.07,  // [s; s × 1]
    EC50 = 8e-09,  // [kg/m3; μg/L × 1e-06]
    gamma = 1,
    exposure_per_s = 1e-06);   // 1 μg/L per second
  // defaulted: E0
  // defaulted: gamma
  annotation(experiment(StartTime = 0, StopTime = 0.08, Interval = 0.00016),
    Documentation(info = "<html><body><h4>Ibutilide_Tisdale2012_PD_qtf</h4><p>The steady-state exposure-response curve of Tisdale JE et al., <i>Journal of clinical pharmacology 52(9):1296–1305</i> 2012 (<a href=\"https://doi.org/10.1177/0091270011416939\">doi:10.1177/0091270011416939</a>) — QTF interval [s] against ibutilide μg/L — obtained by sweeping the driver instead of simulating a dose. Model family: sigmoid_emax.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = (library default) drug-free response (baseline)
  Emax  =       0.07 s        maximal effect term (Emax, s — P, Q320)
  EC50  =      0.008 μg/L     exposure at half of the maximal effect term (EC50, μg/L — P, Q321)
  gamma = (library default) Hill coefficient</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep\">SigmoidEmaxSweep</a>; this model only supplies the numbers. The x axis is one μg/L of ibutilide per second of simulated time (exposure is in kg/m3): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0   (drug-free)
  exposure = EC50 (0.008 μg/L)  response 0.035
  exposure -> infinity  response 0.07</pre></body></html>"));
end Ibutilide_Tisdale2012_PD_qtf;
