function p = Terizidone_Mulubwa2019_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: terizidone   source: Mulubwa_2019 / reference   route: oral
  % estimated (absent from source): dose
  p.name  = 'Terizidone_Mulubwa2019_reference_params';
  p.drug  = 'terizidone';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 13.4;                % central volume [L]
  p.CL = 0.51;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 2.97;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 100.0;             % dose [mg]
end
