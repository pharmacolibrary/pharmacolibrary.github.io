model Terizidone_Mulubwa2019_reference
  parameter Real Cl_ref = 1.4166666666666668e-07 "Cl [m3/s]";
  parameter Real Vd_ref = 0.0134 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.30229,
    adminMass = 0.0001,
    ka = 0.0008250000000000001,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About terizidone</h4><p>Terizidone is an antimycobacterial medicine classified for the treatment of tuberculosis. It is not authorised in the European Union, and its current availability is unclear, with sources describing it variously as approved, investigational, or withdrawn.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q1318344\">Wikidata Q1318344</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>terizidone</td></tr><tr><td>population:</td><td>adult DR-TB patients</td></tr><tr><td>source_paper:</td><td>Mulubwa_2019</td></tr><tr><td>measured_compound:</td><td>terizidone</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>terizidone 302.29 g/mol (drugbank)</td></tr></table><p><b>Defaulted (base-class default used):</b> Tlag.</p><h4>Interpretation flags</h4><ul><li>dropped unlinked row (NIL): 'apparent fraction of terizidone converted to cycloserine' — extend the ontology if this is a real PK parameter (source ['Mulubwa_2019:abstract'])</li><li>dropped duplicate Q27 ('apparent clearance of terizidone via other routes', value 0.1) — already have one for this compound</li><li>apparent-ness (ontology-grounded): parameterization=apparent, measured_compound=terizidone</li><li>template fit: none — noncompartmental model — not a compartmental parent–metabolite model</li><li>row roles (LLM): model_class=noncompartmental; 7/7 row label(s) assigned, 6 linked by role; re-tagged terizidone→parent ×5, terizidone→cycloserine ×2</li><li>molar mass: PubChem entry choice failed (RateLimitError)</li><li>molar mass: none of 2 PubChem candidate(s) is 'cycloserine' (LLM) — left in mass units</li><li>molar mass: none found for 'cycloserine' — its concentrations stay mass-only</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li><li>skipped review gap-fill of V2: primary is PARENT_METABOLITE (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is PARENT_METABOLITE (peripheral family needs ≥2C)</li><li>skipped review gap-fill of TLAG: primary's parameterization (rate-constant / ka-only) does not use it</li><li>engineer: parent → metabolite not buildable on PK_3M_9C (None) — the measured compound's 1-compartment model instead</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 345600, Tolerance = 1e-9, Interval = 1));
end Terizidone_Mulubwa2019_reference;
