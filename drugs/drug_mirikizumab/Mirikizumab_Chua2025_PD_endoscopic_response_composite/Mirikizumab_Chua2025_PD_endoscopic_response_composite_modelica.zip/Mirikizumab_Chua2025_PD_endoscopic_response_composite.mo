model Mirikizumab_Chua2025_PD_endoscopic_response_composite
  "linear exposure-response sweep — Chua_2025 :: endoscopic response-composite (endoscopic response)"
  extends Pharmacolibrary.Interfaces.PartialExposureResponseSweep(
    E0 = 0,      // [1]
    Emax = 0, EC50 = 1,      // unused by a line
    exposure_per_s = 0.001);
  parameter Real slope = 0.127   "[1]";
equation
  response = E0 + slope*exposure;
  // defaulted: E0
  annotation(experiment(StartTime = 0, StopTime = 1000, Interval = 2),
    Documentation(info = "<html><body><!-- drug-about --><h4>About mirikizumab</h4><p>Mirikizumab, a monoclonal antibody that blocks interleukin signalling, is used to treat ulcerative colitis. It is approved and authorised in the European Union, and remains under investigation for other uses.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q55641096\">Wikidata Q55641096</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h4>Mirikizumab_Chua2025_PD_endoscopic_response_composite</h4><p>The steady-state exposure-response curve of Chua L et al., <i>Clinical and translational science 18(8):e70320</i> 2025 (<a href=\"https://doi.org/10.1111/cts.70320\">doi:10.1111/cts.70320</a>) — endoscopic response against mirikizumab µg/mL — obtained by sweeping the driver instead of simulating a dose. Model family: linear.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = (library default) drug-free response (baseline)
  slope =      0.127          change in response per unit of exposure (Slope, Q335)</pre><p>The algebra is <code>response = E0 + slope*exposure</code>; this model only supplies the numbers. The x axis is one µg/mL of mirikizumab per second of simulated time (exposure is in kg/m3): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0   (drug-free)</pre></body></html>"));
end Mirikizumab_Chua2025_PD_endoscopic_response_composite;
