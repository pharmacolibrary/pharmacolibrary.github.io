function p = Mirikizumab_Chua2025_PD_endoscopic_response_composite_params()
% Mirikizumab_Chua2025_PD_endoscopic_response_composite_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% mirikizumab Chua_2025::endoscopic_response_composite: linear exposure-response sweep (response = E0 + slope*exposure). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one µg/mL per second, in SI inside (kg/m3, s). Response endoscopic response-composite in its own unit. Driver: mirikizumab (pk_record).
p.E0 = 0.0;
p.Emax = 0.0;
p.EC50 = 1.0;
p.gamma = 1.0;
p.slope = 0.127;
p.exposure_per_s = 0.001;
p.stop_time = 1000.0;
p.form = 'E0 + slope*exposure';
end
