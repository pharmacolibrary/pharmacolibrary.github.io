function p = Tigecycline_Song2024_non_crrt_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: tigecycline   source: Song_2024 / non_crrt   route: iv_bolus
  % estimated (absent from source): F
  p.name  = 'Tigecycline_Song2024_non_crrt_params';
  p.drug  = 'tigecycline';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'iv_bolus';        % 'oral' | 'iv_bolus'
  p.depot = false;             % oral -> first-order absorption depot
  p.Vc = 32.1;                % central volume [L]
  p.CL = 3.09;                % clearance [L/h]
  p.Vp = [113.0];             % peripheral volumes [L]
  p.Q  = [39.7];             % inter-compartmental clearances [L/h]
  p.ka = 0.0;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 100.0;             % dose [mg]
end
