model Tigecycline_Song2024_non_crrt
  parameter Real Cl_ref = 8.583333333333333e-07 "Cl [m3/s]";
  parameter Real Vd_ref = 0.032100000000000004 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.5856486999999999,
    adminMass = 0.0001,
    k12 = 0.0003435444790584978,
    k21 = 9.759095378564407e-05
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About tigecycline</h4><p>Tigecycline is a tetracycline antibiotic used to treat bacterial infections, including pneumonia and complicated skin, soft tissue, and intra-abdominal infections. It is authorised in the European Union and used mainly in hospital settings for serious bacterial infections.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q420595\">Wikidata Q420595</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>tigecycline</td></tr><tr><td>population:</td><td>critically ill patients</td></tr><tr><td>source_paper:</td><td>Song_2024</td></tr><tr><td>measured_compound:</td><td>tigecycline</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>t0002</td></tr><tr><td>input:</td><td>PK_2C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>tigecycline 585.649 g/mol (drugbank)</td></tr></table><h4>Interpretation flags</h4><ul><li>table section iiv: 'ωCL (%)' routed out of structural estimates ('Inter-individual variability')</li><li>table section iiv: 'ωV1 (%)' routed out of structural estimates ('Inter-individual variability')</li><li>table section residual_error: 'σ (%)' routed out of structural estimates ('Residual variability')</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=tigecycline</li><li>population split: 'non-crrt*' subgroup of Song_2024 (paper reports 2 populations: crrt, non-crrt*)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 133200, Tolerance = 1e-9, Interval = 1));
end Tigecycline_Song2024_non_crrt;
