model Tigecycline_Deshpande2025_PD_bacterial_burden_2
  "sigmoid_emax exposure-response sweep — Deshpande_2025 :: bacterial burden (bacterial burden)"
  extends Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep(
    E0 = 7.19,      // [log10 CFU/mL]
    Emax = -4.33,  // [log10 CFU/mL]
    EC50 = 1e-05,  // [kg/m3; mg/L × 0.001]
    gamma = 0.38,
    exposure_per_s = 0.001);   // 1 mg/L per second
  // imax_as_negative_emax: Imax (Q323) enters SigmoidEmaxSweep as −Emax
  annotation(experiment(StartTime = 0, StopTime = 0.1, Interval = 0.0002),
    Documentation(info = "<html><body><!-- drug-about --><h4>About tigecycline</h4><p>Tigecycline is a tetracycline antibiotic used to treat bacterial infections, including pneumonia and complicated skin, soft tissue, and intra-abdominal infections. It is authorised in the European Union and used mainly in hospital settings for serious bacterial infections.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q420595\">Wikidata Q420595</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h4>Tigecycline_Deshpande2025_PD_bacterial_burden_2</h4><p>The steady-state exposure-response curve of Deshpande D et al., <i>bioRxiv : the preprint server for biology</i> 2025 (<a href=\"https://doi.org/10.1101/2025.07.29.667481\">doi:10.1101/2025.07.29.667481</a>) — bacterial burden against tigecycline mg/L — obtained by sweeping the driver instead of simulating a dose. Model family: sigmoid_emax.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    =       7.19 log10 CFU/mL drug-free response (baseline) (Econ, Q324)
  Emax  =       4.33 log10 CFU/mL maximal effect term (Emax, Q323)
  EC50  =       0.01 mg/L     exposure at half of the maximal effect term (EC50, Q321)
  gamma =       0.38          Hill coefficient (H, Q325)</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep\">SigmoidEmaxSweep</a>; this model only supplies the numbers. The x axis is one mg/L of tigecycline per second of simulated time (exposure is in kg/m3): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 7.19   (drug-free)
  exposure = EC50 (0.01 mg/L)  response 5.025
  exposure -> infinity  response 2.86</pre></body></html>"));
end Tigecycline_Deshpande2025_PD_bacterial_burden_2;
