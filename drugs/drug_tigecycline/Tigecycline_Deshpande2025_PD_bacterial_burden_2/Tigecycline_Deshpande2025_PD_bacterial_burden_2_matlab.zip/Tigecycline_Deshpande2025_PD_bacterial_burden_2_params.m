function p = Tigecycline_Deshpande2025_PD_bacterial_burden_2_params()
% Tigecycline_Deshpande2025_PD_bacterial_burden_2_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% tigecycline Deshpande_2025::bacterial_burden::2: sigmoid_emax exposure-response sweep (response = E0 + Emax*frac). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one mg/L per second, in SI inside (kg/m3, s). Response bacterial burden in its own unit. Driver: tigecycline (cited_pk).
p.E0 = 7.19;
p.Emax = -4.33;
p.EC50 = 9.999999999999997e-06;
p.gamma = 0.38;
p.slope = 0.0;
p.exposure_per_s = 0.001;
p.stop_time = 0.1;
p.form = 'E0 + Emax*frac';
end
