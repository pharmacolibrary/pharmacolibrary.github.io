model Tigecycline_Bastida2022_reference
  parameter Real Cl_ref = 4.111111111111111e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.0637 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.5856486999999999,
    adminMass = 0.0001
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About tigecycline</h4><p>Tigecycline is a tetracycline antibiotic used to treat bacterial infections, including pneumonia and complicated skin, soft tissue, and intra-abdominal infections. It is authorised in the European Union and used mainly in hospital settings for serious bacterial infections.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q420595\">Wikidata Q420595</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>tigecycline</td></tr><tr><td>population:</td><td>critically ill patients with decompensated cirrhosis and severe infections</td></tr><tr><td>source_paper:</td><td>Bastida_2022</td></tr><tr><td>measured_compound:</td><td>tigecycline</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>tigecycline 585.649 g/mol (drugbank)</td></tr></table><h4>Interpretation flags</h4><ul><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=tigecycline</li><li>structure disagreement: deterministic 1C vs LLM 2C — review compartment count</li><li>1C volume normalization: Q63→Q61 (single-compartment model has no central/peripheral split; 'central and peripheral volumes of distribution (V1 and V2)' is the general volume)</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Tigecycline_Bastida2022_reference;
