model Disopyramide_Bryson1978_reference
  parameter Real Cl_ref = 1.0261666666666666e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.031977624120312055 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.33947449999999996,
    adminMass = 0.0004
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>disopyramide</td></tr><tr><td>population:</td><td>review reference</td></tr><tr><td>source_paper:</td><td>Bryson_1978</td></tr><tr><td>measured_compound:</td><td>disopyramide</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>disopyramide 339.474 g/mol (drugbank)</td></tr></table><h4>Interpretation flags</h4><ul><li>built from REVIEW reference values (Bryson_1978) — secondary source</li><li>central volume derived from CL·t½/ln2</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 111600, Tolerance = 1e-9, Interval = 1));
end Disopyramide_Bryson1978_reference;
