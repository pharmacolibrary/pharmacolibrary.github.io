model Disopyramide_Whiting1980_PD_qt
  "linear exposure-response sweep — Whiting_1980 :: ΔQT (QT prolongation)"
  extends Pharmacolibrary.Interfaces.PartialExposureResponseSweep(
    E0 = 0,      // [1]
    Emax = 0, EC50 = 1,      // unused by a line
    exposure_per_s = 0.001);
  parameter Real slope = 14.52   "[ms/jg ml-1]";
equation
  response = E0 + slope*exposure;
  // family_inferred: the record's model family is effect_compartment; read from the parameters: a slope and no Emax — linear
  // defaulted: E0
  annotation(experiment(StartTime = 0, StopTime = 1000, Interval = 2),
    Documentation(info = "<html><body><!-- drug-about --><h4>About disopyramide</h4><p>Disopyramide is a class Ia antiarrhythmic used to treat heart rhythm problems such as atrial fibrillation. It is an approved medicine, though not authorised in the European Union, and is used relatively little today.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q425120\">Wikidata Q425120</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h4>Disopyramide_Whiting1980_PD_qt</h4><p>The steady-state exposure-response curve of Whiting B et al., <i>British journal of clinical pharmacology 9(1):67–75</i> 1980 (<a href=\"https://doi.org/10.1111/j.1365-2125.1980.tb04799.x\">doi:10.1111/j.1365-2125.1980.tb04799.x</a>) — QT prolongation [ms] against disopyramide μg ml-1 — obtained by sweeping the driver instead of simulating a dose. Model family: linear.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = (library default) drug-free response (baseline)
  slope =      14.52 ms/jg ml-1 change in response per unit of exposure (Slopes, Q335)</pre><p>The algebra is <code>response = E0 + slope*exposure</code>; this model only supplies the numbers. The x axis is one μg ml-1 of disopyramide per second of simulated time (exposure is in kg/m3): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0   (drug-free)</pre></body></html>"));
end Disopyramide_Whiting1980_PD_qt;
