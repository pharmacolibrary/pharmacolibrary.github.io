model Disopyramide_Aso2001_s_udp
  parameter Real Cl_ref = 5.951111111111111e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.20600000000000002 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.33947449999999996,
    adminMass = 0.0004,
    ka = 0.0001388888888888889,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About disopyramide</h4><p>Disopyramide is a class Ia antiarrhythmic used to treat heart rhythm problems such as atrial fibrillation. It is an approved medicine, though not authorised in the European Union, and is used relatively little today.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q425120\">Wikidata Q425120</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>disopyramide</td></tr><tr><td>population:</td><td>adults with arrhythmia</td></tr><tr><td>source_paper:</td><td>Aso_2001</td></tr><tr><td>measured_compound:</td><td>disopyramide</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C_enteral: apparent (/F) parameterization ⇒ extravascular dosing</td></tr><tr><td>molar_masses:</td><td>disopyramide 339.474 g/mol (drugbank)</td></tr></table><p><b>Defaulted (base-class default used):</b> ka, Tlag.</p><h4>Interpretation flags</h4><ul><li>dropped unlinked row (NIL): 'Obj*²' — extend the ontology if this is a real PK parameter (source ['Aso_2001_table_4:row5:col5'])</li><li>apparent-ness (ontology-grounded): parameterization=apparent, measured_compound=disopyramide</li><li>population split: 's(+)–udp' subgroup of Aso_2001 (paper reports 6 populations: dp, r(−)–dp, r(−)–udp, s(+)–dp, s(+)–udp, udp)</li><li>skipped review gap-fill of CL: primary's parameterization (rate-constant / ka-only) does not use it</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary's parameterization (rate-constant / ka-only) does not use it</li><li>derived CL/F=21.424 L/h from Ke × V/F = CL/F (Q47 × Q76); not separately reported</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 122400, Tolerance = 1e-9, Interval = 1));
end Disopyramide_Aso2001_s_udp;
