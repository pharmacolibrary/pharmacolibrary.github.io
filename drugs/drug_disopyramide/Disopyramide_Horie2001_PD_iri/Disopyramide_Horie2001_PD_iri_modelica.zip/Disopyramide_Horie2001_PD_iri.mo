model Disopyramide_Horie2001_PD_iri
  "emax exposure-response sweep — Horie_2001 :: IRI (insulin release)"
  extends Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep(
    E0 = 0,      // [1]
    Emax = 2.657,  // [1; % × 0.01]
    EC50 = 30.9,  // [microM]
    gamma = 1,
    exposure_per_s = 1);   // 1 microM per second
  // exposure_unit_unresolved: 'microM' — the x axis is in the paper's unit, not SI
  // defaulted: E0
  // defaulted: gamma
  annotation(experiment(StartTime = 0, StopTime = 310, Interval = 0.62),
    Documentation(info = "<html><body><!-- drug-about --><h4>About disopyramide</h4><p>Disopyramide is a class Ia antiarrhythmic used to treat heart rhythm problems such as atrial fibrillation. It is an approved medicine, though not authorised in the European Union, and is used relatively little today.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q425120\">Wikidata Q425120</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h4>Disopyramide_Horie2001_PD_iri</h4><p>The steady-state exposure-response curve of Horie M et al., <i>Cardiovascular drugs and therapy 15(1):31–39</i> 2001 (<a href=\"https://doi.org/10.1023/a:1011106701063\">doi:10.1023/a:1011106701063</a>) — insulin release [%] against disopyramide microM — obtained by sweeping the driver instead of simulating a dose. Model family: emax.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = (library default) drug-free response (baseline)
  Emax  =      265.7 %        maximal effect term (Emax, Q320)
  EC50  =       30.9 microM   exposure at half of the maximal effect term (EC50, Q321)
  gamma = (library default) Hill coefficient</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep\">SigmoidEmaxSweep</a>; this model only supplies the numbers. The x axis is one microM of disopyramide per second of simulated time: there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0   (drug-free)
  exposure = EC50 (30.9 microM)  response 1.329
  exposure -> infinity  response 2.657</pre></body></html>"));
end Disopyramide_Horie2001_PD_iri;
