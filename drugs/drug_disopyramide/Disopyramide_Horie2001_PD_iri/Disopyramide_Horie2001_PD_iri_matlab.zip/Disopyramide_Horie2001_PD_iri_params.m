function p = Disopyramide_Horie2001_PD_iri_params()
% Disopyramide_Horie2001_PD_iri_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% disopyramide Horie_2001::IRI: emax exposure-response sweep (response = E0 + Emax*frac). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one microM per second, in SI inside (kg/m3, s). Response IRI in %. Driver: disopyramide (cited_pk).
p.E0 = 0.0;
p.Emax = 2.657;
p.EC50 = 30.9;
p.gamma = 1.0;
p.slope = 0.0;
p.exposure_per_s = 1.0;
p.stop_time = 310.0;
p.form = 'E0 + Emax*frac';
end
