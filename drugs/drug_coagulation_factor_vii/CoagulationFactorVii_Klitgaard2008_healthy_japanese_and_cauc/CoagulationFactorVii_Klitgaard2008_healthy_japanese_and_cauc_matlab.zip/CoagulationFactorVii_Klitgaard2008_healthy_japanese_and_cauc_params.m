function p = CoagulationFactorVii_Klitgaard2008_healthy_japanese_and_cauc_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: coagulation_factor_vii   source: Klitgaard_2008 / healthy_japanese_and_caucasian_volunteers_16   route: iv_bolus
  % estimated (absent from source): F, dose
  % Vc is the record's Vss — no central volume was reported; 1-compartment reading
  p.name  = 'CoagulationFactorVii_Klitgaard2008_healthy_japanese_and_cauc_params';
  p.drug  = 'coagulation_factor_vii';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'iv_bolus';        % 'oral' | 'iv_bolus'
  p.depot = false;             % oral -> first-order absorption depot
  p.Vc = 9.1;                % central volume [L]
  p.CL = 2.38;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.0;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 10.0;             % dose [mg]
end
