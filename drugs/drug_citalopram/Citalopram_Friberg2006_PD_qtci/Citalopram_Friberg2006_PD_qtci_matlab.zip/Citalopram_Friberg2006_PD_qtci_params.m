function p = Citalopram_Friberg2006_PD_qtci_params()
% Citalopram_Friberg2006_PD_qtci_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% citalopram Friberg_2006::QTci: linear exposure-response sweep (response = E0 + slope*exposure). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one mg l-1 per second, in SI inside (kg/m3, s). Response QTci in ms. Driver: citalopram (pk_record).
p.E0 = 0.429;
p.Emax = 0.02;
p.EC50 = 1.0;
p.gamma = 1.0;
p.slope = 40.0;
p.exposure_per_s = 0.001;
p.stop_time = 1000.0;
p.form = 'E0 + slope*exposure';
end
