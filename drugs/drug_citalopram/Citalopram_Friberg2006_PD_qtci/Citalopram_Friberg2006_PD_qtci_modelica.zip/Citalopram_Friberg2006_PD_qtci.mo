model Citalopram_Friberg2006_PD_qtci
  "linear exposure-response sweep — Friberg_2006 :: QTci (Heart-rate corrected QT interval)"
  extends Pharmacolibrary.Interfaces.PartialExposureResponseSweep(
    E0 = 0.429,      // [s; ms × 0.001]
    Emax = 0, EC50 = 1,      // unused by a line
    exposure_per_s = 0.001);
  parameter Real slope = 40   "[ms l mg-1]";
equation
  response = E0 + slope*exposure;
  annotation(experiment(StartTime = 0, StopTime = 1000, Interval = 2),
    Documentation(info = "<html><body><!-- drug-about --><h4>About citalopram</h4><p>Citalopram is an antidepressant of the selective serotonin reuptake inhibitor class used to treat depression and related mental and mood disorders, as well as anxiety conditions such as generalized anxiety disorder and obsessive-compulsive disorder. It is an approved medicine in widespread clinical use, though it carries a boxed warning.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q409672\">Wikidata Q409672</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h4>Citalopram_Friberg2006_PD_qtci</h4><p>The steady-state exposure-response curve of Friberg LE et al., <i>British journal of clinical pharmacology 61(2):177–190</i> 2006 (<a href=\"https://doi.org/10.1111/j.1365-2125.2005.02546.x\">doi:10.1111/j.1365-2125.2005.02546.x</a>) — Heart-rate corrected QT interval [ms] against citalopram mg l-1 — obtained by sweeping the driver instead of simulating a dose. Model family: linear.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    =        429 ms       drug-free response (baseline) (QTci0, women, Q324)
  Emax  =         20 ms       maximal effect term (E max (ms), Q320)
  slope =         40 ms l mg-1 change in response per unit of exposure (Slope, Q335)</pre><p>The algebra is <code>response = E0 + slope*exposure</code>; this model only supplies the numbers. The x axis is one mg l-1 of citalopram per second of simulated time (exposure is in kg/m3): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0.429   (drug-free)</pre></body></html>"));
end Citalopram_Friberg2006_PD_qtci;
