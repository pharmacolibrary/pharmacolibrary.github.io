function p = Topiramate_Ahmed2015_PD_cowa_params()
% Topiramate_Ahmed2015_PD_cowa_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% topiramate Ahmed_2015::COWA: linear exposure-response sweep (response = E0 + slope*exposure). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one mg l(-1) per second, in SI inside (kg/m3, s). Response COWA in its own unit. Driver: topiramate (cited_pk).
p.E0 = 0.0;
p.Emax = 0.0;
p.EC50 = 1.0;
p.gamma = 1.0;
p.slope = 14.5;
p.exposure_per_s = 0.001;
p.stop_time = 1000.0;
p.form = 'E0 + slope*exposure';
end
