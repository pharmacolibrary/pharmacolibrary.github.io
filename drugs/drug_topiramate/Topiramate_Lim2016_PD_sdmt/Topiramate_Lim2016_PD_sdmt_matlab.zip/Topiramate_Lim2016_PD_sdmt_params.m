function p = Topiramate_Lim2016_PD_sdmt_params()
% Topiramate_Lim2016_PD_sdmt_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% topiramate Lim_2016::SDMT: emax exposure-response sweep (response = E0 + Emax*frac). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one μg/mL per second, in SI inside (kg/m3, s). Response SDMT in its own unit. Driver: topiramate (cited_pk).
p.E0 = 0.0;
p.Emax = -0.255;
p.EC50 = 0.0028499999999999997;
p.gamma = 1.0;
p.slope = 0.0;
p.exposure_per_s = 0.001;
p.stop_time = 29.0;
p.form = 'E0 + Emax*frac';
end
