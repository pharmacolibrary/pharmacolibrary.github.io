model Zidovudine_Fauchet2013_reference
  parameter Real Cl_ref = 2.4916666666666668e-05 "Cl [m3/s]";
  parameter Real Vd_ref = 0.229 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.2672413,
    adminMass = 0.0006,
    ka = 0.0007944444444444444,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About zidovudine</h4><p>Zidovudine (AZT) is an antiviral nucleoside analogue used to treat HIV infection and AIDS. It remains an approved medicine, is included on the WHO essential medicines list, and is used worldwide, often in combination with other HIV drugs.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q198504\">Wikidata Q198504</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>zidovudine</td></tr><tr><td>population:</td><td>HIV-1-infected children</td></tr><tr><td>source_paper:</td><td>Fauchet_2013</td></tr><tr><td>measured_compound:</td><td>zidovudine</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>zidovudine 267.241 g/mol (drugbank)</td></tr></table><p><b>Defaulted (base-class default used):</b> Tlag.</p><h4>Interpretation flags</h4><ul><li>apparent-ness (ontology-grounded): parameterization=apparent, measured_compound=zidovudine</li><li>template fit: PK_3M_9C — formed from central; parent 1, metabolites [0]</li><li>row roles (LLM): model_class=compartmental; 5/5 row label(s) assigned, 5 linked by role; re-tagged zidovudine→parent ×3, zidovudine→G-ZDV (3′-azido-3′-deoxy-5′-glucuronylthymidine) ×2</li><li>molar mass: no plausible PubChem entry for 'G-ZDV (3′-azido-3′-deoxy-5′-glucuronylthymidine)' ('3′-azido-3′-deoxy-5′-glucuronylthymidine') — left in mass units</li><li>molar mass: none found for 'G-ZDV (3′-azido-3′-deoxy-5′-glucuronylthymidine)' — its concentrations stay mass-only</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li><li>skipped review gap-fill of V2: primary is PARENT_METABOLITE (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary's parameterization (rate-constant / ka-only) does not use it</li><li>skipped review gap-fill of TLAG: primary's parameterization (rate-constant / ka-only) does not use it</li><li>engineer: parent → metabolite not buildable on PK_3M_9C (None) — the measured compound's 1-compartment model instead</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Zidovudine_Fauchet2013_reference;
