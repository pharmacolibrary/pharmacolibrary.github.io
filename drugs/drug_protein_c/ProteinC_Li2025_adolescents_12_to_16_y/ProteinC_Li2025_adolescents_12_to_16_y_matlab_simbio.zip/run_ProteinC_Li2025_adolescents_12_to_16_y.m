% Run (SimBiology): build model + dose, simulate 0..72.0 h, plot.
p = ProteinC_Li2025_adolescents_12_to_16_y_params();
[model, dose, variant] = build_sb_pk(p);
sd = simulate_sb(model, variant, dose, 72.0);
