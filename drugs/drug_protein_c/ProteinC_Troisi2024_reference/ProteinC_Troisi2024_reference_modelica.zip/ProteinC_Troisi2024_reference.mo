model ProteinC_Troisi2024_reference
  parameter Real Cl_ref = 1.638888888888889e-07 "Cl [m3/s]";
  parameter Real Vd_ref = 0.02 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    adminMass = 1e-05
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About protein_c</h4><p>Protein C concentrate is used to treat purpura fulminans and protein C deficiency, acting as an antithrombotic agent. It is authorised in the European Union but appears to be a niche product, used only in these rare conditions.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q28852357\">Wikidata Q28852357</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>protein_c</td></tr><tr><td>population:</td><td>review reference</td></tr><tr><td>source_paper:</td><td>Troisi_2024</td></tr><tr><td>measured_compound:</td><td>protein_c</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C: IV (no input phase)</td></tr></table><h4>Interpretation flags</h4><ul><li>built from REVIEW reference values (Troisi_2024) — secondary source</li><li>volume reported by review</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 432000, Tolerance = 1e-9, Interval = 1));
end ProteinC_Troisi2024_reference;
