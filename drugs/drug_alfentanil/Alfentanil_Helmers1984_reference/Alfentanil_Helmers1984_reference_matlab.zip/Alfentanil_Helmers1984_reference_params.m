function p = Alfentanil_Helmers1984_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: alfentanil   source: Helmers_1984 / reference   route: iv_bolus
  % estimated (absent from source): F, dose
  p.name  = 'Alfentanil_Helmers1984_reference_params';
  p.drug  = 'alfentanil';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'iv_bolus';        % 'oral' | 'iv_bolus'
  p.depot = false;             % oral -> first-order absorption depot
  p.Vc = 14.07;                % central volume [L]
  p.CL = 18.48;                % clearance [L/h]
  p.Vp = [275.7];             % peripheral volumes [L]
  p.Q  = [173.04];             % inter-compartmental clearances [L/h]
  p.ka = 0.0;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.016;             % absorption lag [h]
  p.dose = 10.0;             % dose [mg]
end
