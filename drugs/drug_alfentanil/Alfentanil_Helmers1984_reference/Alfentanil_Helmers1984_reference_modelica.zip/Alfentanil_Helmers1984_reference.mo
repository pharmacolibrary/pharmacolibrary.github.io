model Alfentanil_Helmers1984_reference
  parameter Real Cl_ref = 5.133333333333334e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.01407 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.4165172,
    adminMass = 1e-05,
    k12 = 0.003416252072968491,
    k21 = 0.00017434409382178695
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About alfentanil</h4><p>Alfentanil is an opioid used as an intravenous anesthetic for general anesthesia and pain control. It is an approved medicine used mainly in hospital settings for anesthesia, though it is also a controlled drug with illicit misuse potential.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q176533\">Wikidata Q176533</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>alfentanil</td></tr><tr><td>population:</td><td>elderly surgical patients</td></tr><tr><td>source_paper:</td><td>Helmers_1984</td></tr><tr><td>measured_compound:</td><td>alfentanil</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_2C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>alfentanil 416.517 g/mol (drugbank)</td></tr></table><h4>Interpretation flags</h4><ul><li>dropped duplicate Q22 ('Plasma clearance ... in young adults', value 6.5) — already have one for this compound</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=alfentanil</li><li>structure disagreement: deterministic 2C vs LLM 1C — review compartment count</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li><li>gap-filled Q64 (V2) from Bower_1982's review values (primary lacked it)</li><li>gap-filled Q30 (Q) from Egan_1995's review values (primary lacked it)</li><li>gap-filled Q83 (tlag) from Mertens_2004's review values (primary lacked it)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Alfentanil_Helmers1984_reference;
