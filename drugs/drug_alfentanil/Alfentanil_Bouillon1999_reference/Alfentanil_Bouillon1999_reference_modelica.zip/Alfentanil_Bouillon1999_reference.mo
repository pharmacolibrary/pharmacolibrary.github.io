model Alfentanil_Bouillon1999_reference
  parameter Real Cl_ref = 5.833333333333333e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.00535 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.4165172,
    adminMass = 1e-05
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About alfentanil</h4><p>Alfentanil is an opioid used as an intravenous anesthetic for general anesthesia and pain control. It is an approved medicine used mainly in hospital settings for anesthesia, though it is also a controlled drug with illicit misuse potential.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q176533\">Wikidata Q176533</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>alfentanil</td></tr><tr><td>population:</td><td>adult men undergoing urologic surgery</td></tr><tr><td>source_paper:</td><td>Bouillon_1999</td></tr><tr><td>measured_compound:</td><td>alfentanil</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>table 1</td></tr><tr><td>input:</td><td>PK_1C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>alfentanil 416.517 g/mol (drugbank)</td></tr></table><h4>Interpretation flags</h4><ul><li>unit_dimension_unknown: 'V₁' (V1)</li><li>unit_dimension_unknown: 'Cl₁' (CL)</li><li>unit_dimension_unknown: 'Cl₂' (Q2)</li><li>implicit units: 'Central (V₁)' → L (from the paper text: &quot;Table 1 header explicitly states 'Volumes [l]' (interpreted as Liters).&quot;)</li><li>implicit units: 'Central (Cl₁)' → L/min (from the paper text: &quot;Table 1 header explicitly states 'Clearances [Vmin]' which is a typo/OCR error for 'L/min' (liters per minute), consiste&quot;)</li><li>implicit units: 'Peripheral (Cl₂)' → L/min (from the paper text: &quot;Table 1 header explicitly states 'Clearances [Vmin]' which applies to the clearance section containing Cl1 and Cl2.&quot;)</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=alfentanil</li><li>structure disagreement: deterministic 1C vs LLM 2C — review compartment count</li><li>1C volume normalization: Q63→Q61 (single-compartment model has no central/peripheral split; 'Central (V₁)' is the general volume)</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li><li>gap-filled Q83 (tlag) from Mertens_2004's review values (primary lacked it)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Alfentanil_Bouillon1999_reference;
