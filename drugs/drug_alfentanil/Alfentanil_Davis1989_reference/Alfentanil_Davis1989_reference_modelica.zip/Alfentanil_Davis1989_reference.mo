model Alfentanil_Davis1989_reference
  parameter Real Cl_ref = 2.566666666666667e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.07 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.4165172,
    adminMass = 0.0001,
    ka = 0.0001388888888888889,
    Tlag = 57.599999999999994
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About alfentanil</h4><p>Alfentanil is an opioid used as an intravenous anesthetic for general anesthesia and pain control. It is an approved medicine used mainly in hospital settings for anesthesia, though it is also a controlled drug with illicit misuse potential.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q176533\">Wikidata Q176533</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>alfentanil</td></tr><tr><td>population:</td><td>premature infants and older children</td></tr><tr><td>source_paper:</td><td>Davis_1989</td></tr><tr><td>measured_compound:</td><td>alfentanil</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C_enteral: apparent (/F) parameterization ⇒ extravascular dosing</td></tr><tr><td>molar_masses:</td><td>alfentanil 416.517 g/mol (drugbank)</td></tr></table><p><b>Defaulted (base-class default used):</b> ka.</p><h4>Interpretation flags</h4><ul><li>apparent-ness (ontology-grounded): parameterization=apparent, measured_compound=alfentanil</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li><li>gap-filled Q83 (tlag) from Mertens_2004's review values (primary lacked it)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 158400, Tolerance = 1e-9, Interval = 1));
end Alfentanil_Davis1989_reference;
