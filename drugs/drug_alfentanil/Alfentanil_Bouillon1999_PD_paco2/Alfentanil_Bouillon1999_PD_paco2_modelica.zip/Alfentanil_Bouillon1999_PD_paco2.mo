model Alfentanil_Bouillon1999_PD_paco2
  "indirect_response_ii exposure-response sweep — Bouillon_1999 :: PaCO2 (PaCO2)"
  extends Pharmacolibrary.Interfaces.PartialExposureResponseSweep(
    E0 = 0,      // [1]
    Emax = 1,  // type II effect term
    EC50 = 6.03e-11,  // [kg/m3; pg/l × 1e-12]
    gamma = 1,
    exposure_per_s = 1e-12);   // 1 pg/l per second
equation
  response = E0/(1 - Emax*frac);   // steady state, indirect response type II
  // defaulted: E0
  // defaulted: Emax
  // defaulted: gamma
  annotation(experiment(StartTime = 0, StopTime = 610, Interval = 1.22),
    Documentation(info = "<html><body><!-- drug-about --><h4>About alfentanil</h4><p>Alfentanil is an opioid used as an intravenous anesthetic for general anesthesia and pain control. It is an approved medicine used mainly in hospital settings for anesthesia, though it is also a controlled drug with illicit misuse potential.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q176533\">Wikidata Q176533</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h4>Alfentanil_Bouillon1999_PD_paco2</h4><p>The steady-state exposure-response curve of Bouillon T et al., <i>Anesthesiology 91(1):144–155</i> 1999 (<a href=\"https://doi.org/10.1097/00000542-199907000-00023\">doi:10.1097/00000542-199907000-00023</a>) — PaCO2 [mmHg] against alfentanil pg/l — obtained by sweeping the driver instead of simulating a dose. Model family: indirect_response_ii.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = (library default) drug-free response (baseline)
  Emax  = (library default) maximal effect term
  EC50  =       60.3 pg/l     exposure at half of the maximal effect term (EC50, Q322)
  gamma = (library default) Hill coefficient</pre><p>The algebra is <code>response = E0/(1 - Emax*frac)</code>; this model only supplies the numbers. The x axis is one pg/l of alfentanil per second of simulated time (exposure is in kg/m3): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0   (drug-free)
  exposure = EC50 (60.3 pg/l)  response 0
  exposure -> infinity  response inf</pre></body></html>"));
end Alfentanil_Bouillon1999_PD_paco2;
