function p = Alfentanil_Bouillon1999_PD_paco2_params()
% Alfentanil_Bouillon1999_PD_paco2_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% alfentanil Bouillon_1999::PaCO2: indirect_response_ii exposure-response sweep (response = E0/(1 - Emax*frac)). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one pg/l per second, in SI inside (kg/m3, s). Response PaCO2 in mmHg. Driver: alfentanil (pk_record).
p.E0 = 0.0;
p.Emax = 1.0;
p.EC50 = 6.029999999999999e-11;
p.gamma = 1.0;
p.slope = 0.0;
p.exposure_per_s = 1e-12;
p.stop_time = 610.0;
p.form = 'E0/(1 - Emax*frac)';
end
