model MycophenolicAcid_Wei2022_reference
  parameter Real Cl_ref = 4.111111111111111e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.006 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.32033710000000004,
    adminMass = 0.0007,
    ka = 0.0005555555555555556,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About mycophenolic_acid</h4><p>Mycophenolic acid is an immunosuppressant used to prevent organ transplant rejection and, according to Wikidata, also to treat lupus nephritis. It is an approved medicine, widely used in transplant medicine, and has also been studied for other investigational uses.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q420553\">Wikidata Q420553</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>mycophenolic_acid</td></tr><tr><td>population:</td><td>pediatric patients after liver transplantation</td></tr><tr><td>source_paper:</td><td>Wei_2022</td></tr><tr><td>measured_compound:</td><td>mycophenolic acid</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>T3</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>mycophenolate mofetil 433.501 g/mol (pubchem); mycophenolic acid 320.337 g/mol (drugbank)</td></tr></table><p><b>Defaulted (base-class default used):</b> Tlag.</p><h4>Interpretation flags</h4><ul><li>the dosed compound is mycophenolic_acid; the compartment is mycophenolic acid. Input enters at the reported formation rate, so formation is already accounted for in the input step and the simulated concentration is mycophenolic acid, not mycophenolic_acid</li><li>apparent parameters (CLm/F, Vm/F) already contain F and the metabolised fraction, so F=1 and no molar correction is applied — adding either would double-count it</li><li>mycophenolic_acid's own concentration-time course is not produced by this model</li><li>dropped unlinked row (NIL): 'OFV' — extend the ontology if this is a real PK parameter (source ['T3:row2:col1', 'T3:row2:col4'])</li><li>kept covariate coefficient θDOSE=0.452 (covariate DOSE) — not an ontology parameter</li><li>dropped unlinked row (NIL): 'RV (%)' — extend the ontology if this is a real PK parameter (source ['T3:row11:col1', 'T3:row11:col2', 'T3:row11:col3', 'T3:row11:col4', 'T3:row11:col6'])</li><li>metabolite mycophenolic acid: Q27→Q351 — only the metabolite is measured and fm is not identifiable, so its CL/V are apparent (fm-divided)</li><li>apparent-ness (ontology-grounded): parameterization=apparent, measured_compound=mycophenolic acid</li><li>template fit: none — only the metabolite is modelled — no parent compartment</li><li>structure disagreement: deterministic 1C vs LLM 2C — review compartment count</li><li>row roles (LLM): model_class=compartmental; 10/10 row label(s) assigned, 14 linked by role</li><li>skipped review gap-fill of TLAG: primary's parameterization (rate-constant / ka-only) does not use it</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end MycophenolicAcid_Wei2022_reference;
