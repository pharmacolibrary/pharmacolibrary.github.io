model Procainamide_Liu1991_PD_qtc
  "sigmoid_emax exposure-response sweep — Liu_1991 :: QTc (QTc prolongation)"
  extends Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep(
    E0 = 0,      // [1]
    Emax = 0.037,  // [s; ms × 0.001]
    EC50 = 0.0036,  // [kg/m3; micrograms.ml-1 × 0.001]
    gamma = 3.9,
    exposure_per_s = 0.001);   // 1 micrograms.ml-1 per second
  // defaulted: E0
  annotation(experiment(StartTime = 0, StopTime = 36, Interval = 0.072),
    Documentation(info = "<html><body><!-- drug-about --><h4>About procainamide</h4><p>Procainamide is a class Ia antiarrhythmic used to treat heart rhythm problems such as atrial fibrillation and supraventricular tachycardia. It is an approved medicine, though it is not authorised in the European Union and is used mainly in other regions.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q417597\">Wikidata Q417597</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h4>Procainamide_Liu1991_PD_qtc</h4><p>The steady-state exposure-response curve of Liu XQ et al., <i>Zhongguo yao li xue bao = Acta pharmacologica Sinica 12(1):7–11</i> 1991 — QTc prolongation [ms] against procainamide micrograms.ml-1 — obtained by sweeping the driver instead of simulating a dose. Model family: sigmoid_emax.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = (library default) drug-free response (baseline)
  Emax  =         37 ms       maximal effect term (Emax, Q320)
  EC50  =        3.6 micrograms.ml-1 exposure at half of the maximal effect term (Ce(50), Q321)
  gamma =        3.9          Hill coefficient (S, Q325)</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep\">SigmoidEmaxSweep</a>; this model only supplies the numbers. The x axis is one micrograms.ml-1 of procainamide per second of simulated time (exposure is in kg/m3): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0   (drug-free)
  exposure = EC50 (3.6 micrograms.ml-1)  response 0.0185
  exposure -> infinity  response 0.037</pre></body></html>"));
end Procainamide_Liu1991_PD_qtc;
