function p = Procainamide_Liu1991_PD_qtc_params()
% Procainamide_Liu1991_PD_qtc_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% procainamide Liu_1991::QTc: sigmoid_emax exposure-response sweep (response = E0 + Emax*frac). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one micrograms.ml-1 per second, in SI inside (kg/m3, s). Response QTc in ms. Driver: procainamide (cited_pk).
p.E0 = 0.0;
p.Emax = 0.037;
p.EC50 = 0.0035999999999999995;
p.gamma = 3.9;
p.slope = 0.0;
p.exposure_per_s = 0.001;
p.stop_time = 36.0;
p.form = 'E0 + Emax*frac';
end
