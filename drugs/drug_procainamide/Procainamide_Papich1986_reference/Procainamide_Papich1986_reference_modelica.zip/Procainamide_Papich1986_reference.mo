model Procainamide_Papich1986_reference
  parameter Real Cl_ref = 8.01111111111111e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.10079999999999999 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.2353253,
    adminMass = 0.003,
    ka = 0.0001388888888888889,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About procainamide</h4><p>Procainamide is a class Ia antiarrhythmic used to treat heart rhythm problems such as atrial fibrillation and supraventricular tachycardia. It is an approved medicine, though it is not authorised in the European Union and is used mainly in other regions.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q417597\">Wikidata Q417597</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>procainamide</td></tr><tr><td>population:</td><td>dogs</td></tr><tr><td>source_paper:</td><td>Papich_1986</td></tr><tr><td>measured_compound:</td><td>procainamide</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C_enteral: apparent (/F) parameterization ⇒ extravascular dosing</td></tr><tr><td>molar_masses:</td><td>procainamide 235.325 g/mol (drugbank)</td></tr></table><p><b>Defaulted (base-class default used):</b> ka, Tlag.</p><h4>Interpretation flags</h4><ul><li>covariate category for t1/2z from footnote/prose kept as documentation only (['Papich_1986:abstract'])</li><li>dropped duplicate Q57 ('estimated elimination half-life of NAPA', value 4.7) — already have one for this compound</li><li>apparent-ness (ontology-grounded): parameterization=apparent, measured_compound=procainamide</li><li>held at status:extracted — NIL link or unit issue (mismatch/unknown/normalisation-failed) present</li><li>topology: transfer parameter unlinked (Q100) — add Kfm/formation-rate/rate-constant to the ontology; routing to review</li><li>status held at route_to_review — not promoted</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li><li>skipped review gap-fill of V2: primary is PARENT_METABOLITE (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is PARENT_METABOLITE (peripheral family needs ≥2C)</li><li>engineer: parent → metabolite not buildable on PK_3M_9C (None) — the measured compound's 1-compartment model instead</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Procainamide_Papich1986_reference;
