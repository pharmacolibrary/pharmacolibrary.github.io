function p = Procainamide_Kharidia1996_PD_qt_params()
% Procainamide_Kharidia1996_PD_qt_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% procainamide Kharidia_1996::QT: emax exposure-response sweep (response = E0 + Emax*frac). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one ng/mL per second, in SI inside (kg/m3, s). Response QT in %. Driver: procainamide (pk_record).
p.E0 = 0.0;
p.Emax = 0.3009;
p.EC50 = 0.000445;
p.gamma = 1.0;
p.slope = 0.0;
p.exposure_per_s = 1e-06;
p.stop_time = 4500.0;
p.form = 'E0 + Emax*frac';
end
