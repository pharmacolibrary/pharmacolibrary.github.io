model Procainamide_Kharidia1996_PD_qt
  "emax exposure-response sweep — Kharidia_1996 :: QT (percent change QT interval)"
  extends Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep(
    E0 = 0,      // [1]
    Emax = 0.3009,  // [1; % × 0.01]
    EC50 = 0.000445,  // [kg/m3; ng/mL × 1e-06]
    gamma = 1,
    exposure_per_s = 1e-06);   // 1 ng/mL per second
  // defaulted: E0
  // defaulted: gamma
  annotation(experiment(StartTime = 0, StopTime = 4500, Interval = 9),
    Documentation(info = "<html><body><!-- drug-about --><h4>About procainamide</h4><p>Procainamide is a class Ia antiarrhythmic used to treat heart rhythm problems such as atrial fibrillation and supraventricular tachycardia. It is an approved medicine, though it is not authorised in the European Union and is used mainly in other regions.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q417597\">Wikidata Q417597</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h4>Procainamide_Kharidia1996_PD_qt</h4><p>The steady-state exposure-response curve of Kharidia J et al., <i>Journal of pharmaceutical sciences 85(6):595–599</i> 1996 (<a href=\"https://doi.org/10.1021/js950473h\">doi:10.1021/js950473h</a>) — percent change QT interval [%] against procainamide ng/mL — obtained by sweeping the driver instead of simulating a dose. Model family: emax.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = (library default) drug-free response (baseline)
  Emax  =      30.09 %        maximal effect term (Emax, Q320)
  EC50  =        445 ng/mL    exposure at half of the maximal effect term (EC50, Q321)
  gamma = (library default) Hill coefficient</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep\">SigmoidEmaxSweep</a>; this model only supplies the numbers. The x axis is one ng/mL of procainamide per second of simulated time (exposure is in kg/m3): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0   (drug-free)
  exposure = EC50 (445 ng/mL)  response 0.1505
  exposure -> infinity  response 0.3009</pre></body></html>"));
end Procainamide_Kharidia1996_PD_qt;
