function p = Procainamide_Liu1991_PD_qtc_2_params()
% Procainamide_Liu1991_PD_qtc_2_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% procainamide Liu_1991::QTc::2: sigmoid_emax exposure-response sweep (response = E0 + Emax*frac). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one micrograms.ml-1 per second, in SI inside (kg/m3, s). Response QTc in ms. Driver: acetylprocainamide (not_resolved).
p.E0 = 0.0;
p.Emax = 0.0536;
p.EC50 = 0.006199999999999999;
p.gamma = 2.2;
p.slope = 0.0;
p.exposure_per_s = 0.001;
p.stop_time = 62.0;
p.form = 'E0 + Emax*frac';
end
