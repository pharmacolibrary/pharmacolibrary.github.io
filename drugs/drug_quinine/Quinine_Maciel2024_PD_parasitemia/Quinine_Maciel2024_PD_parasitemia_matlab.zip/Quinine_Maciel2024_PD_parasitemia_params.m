function p = Quinine_Maciel2024_PD_parasitemia_params()
% Quinine_Maciel2024_PD_parasitemia_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% quinine Maciel_2024::parasitemia: emax exposure-response sweep (response = E0 + Emax*frac). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one mg/L per second, in SI inside (kg/m3, s). Response parasitemia in %. Driver: quinine (pk_record).
p.E0 = 0.0;
p.Emax = -0.00055;
p.EC50 = 0.003589999999999999;
p.gamma = 1.0;
p.slope = 0.0;
p.exposure_per_s = 0.001;
p.stop_time = 36.0;
p.form = 'E0 + Emax*frac';
end
