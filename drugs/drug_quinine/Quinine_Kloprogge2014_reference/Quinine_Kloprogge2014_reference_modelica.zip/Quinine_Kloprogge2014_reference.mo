model Quinine_Kloprogge2014_reference
  parameter Real Cl_ref = 2.8888888888888894e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.17400000000000002 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.3244168,
    adminMass = 0.0007,
    ka = 0.00022694444444444444,
    Tlag = 0.0,
    k12 = 1.7081736909323115e-05,
    k21 = 5.4737057499488435e-05
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About quinine</h4><p>Quinine is an antimalarial drug used to treat malaria, including falciparum malaria, and has also been used for babesiosis and muscle cramps. It remains an approved medicine, is listed among WHO essential medicines, and is used worldwide mainly for malaria, though it carries a boxed warning.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q189522\">Wikidata Q189522</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>quinine</td></tr><tr><td>population:</td><td>pregnant women with uncomplicated falciparum malaria</td></tr><tr><td>source_paper:</td><td>Kloprogge_2014</td></tr><tr><td>measured_compound:</td><td>quinine</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>DKU228TB2</td></tr><tr><td>input:</td><td>PK_2C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>quinine 324.417 g/mol (drugbank)</td></tr></table><p><b>Defaulted (base-class default used):</b> Tlag.</p><h4>Interpretation flags</h4><ul><li>table section iiv: 'ka (1/h)' routed out of structural estimates ('IIV/IOV (% CV)a (% RSE)b')</li><li>table section iiv: 'CL/F (L/h)' routed out of structural estimates ('IIV/IOV (% CV)a (% RSE)b')</li><li>table section iiv: 'Vp/F (L)' routed out of structural estimates ('IIV/IOV (% CV)a (% RSE)b')</li><li>dropped value-less row: 'ka (1/h)' (captured trailing unit '1/h' for child rows)</li><li>dropped value-less row: 'CL/F (L/h)' (captured trailing unit 'L/h' for child rows)</li><li>dropped value-less row: 'Vc/F (L)' (captured trailing unit 'L' for child rows)</li><li>dropped value-less row: 'Q/F (L/h)' (captured trailing unit 'L/h' for child rows)</li><li>dropped value-less row: 'Vp/F (L)' (captured trailing unit 'L' for child rows)</li><li>dropped value-less row: 'Parasitaemia (log10) on F (%)' (captured trailing unit '%' for child rows)</li><li>dropped value-less row: 'Temperature on CL/F'</li><li>dropped value-less row: 'The additive error (σ) variance will essentially be exponential on normal scale data.'</li><li>dropped value-less row: 'bThe relative standard error (RSE) is calculated as 100 × (standard deviation/mean value) from 1000 runs of a non-parametric bootstrap. The 95% CI is displayed as the 2.5th to 97.5th percentiles of the bootstrap estimates.'</li><li>dropped value-less row: 'cPost hoc estimates were calculated as the medians and ranges of the empirical Bayes estimates.'</li><li>salvaged Q49 ('ka'=0.817) from results prose — parameter table was unreadable</li><li>salvaged Q27 ('CL/F'=10.4) from results prose — parameter table was unreadable</li><li>salvaged Q290 ('Vc/F'=174) from results prose — parameter table was unreadable</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 259200, Tolerance = 1e-9, Interval = 1));
end Quinine_Kloprogge2014_reference;
