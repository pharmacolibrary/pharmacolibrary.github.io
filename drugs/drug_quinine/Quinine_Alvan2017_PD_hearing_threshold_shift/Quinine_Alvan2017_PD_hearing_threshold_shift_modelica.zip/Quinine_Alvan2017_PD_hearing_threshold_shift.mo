model Quinine_Alvan2017_PD_hearing_threshold_shift
  "log_linear exposure-response sweep — Alvan_2017 :: hearing threshold shift (Hearing threshold shift (cochlear neural activity, 8 kHz tone burst))"
  extends Pharmacolibrary.Interfaces.PartialExposureResponseSweep(
    E0 = 0,      // [1]
    Emax = 0, EC50 = 1,      // unused by a line
    exposure_per_s = 1);
  parameter Real slope = 5.3   "[1]";
equation
  response = E0 + slope*log(exposure);
  // defaulted: E0
  annotation(experiment(StartTime = 0, StopTime = 1000, Interval = 2),
    Documentation(info = "<html><body><!-- drug-about --><h4>About quinine</h4><p>Quinine is an antimalarial drug used to treat malaria, including falciparum malaria, and has also been used for babesiosis and muscle cramps. It remains an approved medicine, is listed among WHO essential medicines, and is used worldwide mainly for malaria, though it carries a boxed warning.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q189522\">Wikidata Q189522</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h4>Quinine_Alvan2017_PD_hearing_threshold_shift</h4><p>The steady-state exposure-response curve of Alvan G et al., <i>Basic &amp; clinical pharmacology &amp; toxicology 120(1):5–13</i> 2017 (<a href=\"https://doi.org/10.1111/bcpt.12640\">doi:10.1111/bcpt.12640</a>) — Hearing threshold shift (cochlear neural activity, 8 kHz tone burst) [dB] against quinine µM — obtained by sweeping the driver instead of simulating a dose. Model family: log_linear.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = (library default) drug-free response (baseline)
  slope =        5.3          change in response per unit of exposure (proportionality constant c, Q335)</pre><p>The algebra is <code>response = E0 + slope*log(exposure)</code>; this model only supplies the numbers. The x axis is one µM of quinine per second of simulated time: there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p></body></html>"));
end Quinine_Alvan2017_PD_hearing_threshold_shift;
