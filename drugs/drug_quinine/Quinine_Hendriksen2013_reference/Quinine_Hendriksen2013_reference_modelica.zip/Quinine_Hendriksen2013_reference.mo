model Quinine_Hendriksen2013_reference
  parameter Real Cl_ref = 2.713888888888889e-07 "Cl [m3/s]";
  parameter Real Vd_ref = 0.0167 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.3244168,
    adminMass = 0.0015
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About quinine</h4><p>Quinine is an antimalarial drug used to treat malaria, including falciparum malaria, and has also been used for babesiosis and muscle cramps. It remains an approved medicine, is listed among WHO essential medicines, and is used worldwide mainly for malaria, though it carries a boxed warning.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q189522\">Wikidata Q189522</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>quinine</td></tr><tr><td>population:</td><td>Tanzanian children with severe falciparum malaria</td></tr><tr><td>source_paper:</td><td>Hendriksen_2013</td></tr><tr><td>measured_compound:</td><td>quinine</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>quinine 324.417 g/mol (drugbank)</td></tr></table><h4>Interpretation flags</h4><ul><li>dropped unlinked row (NIL): 'typical patient weighing' — extend the ontology if this is a real PK parameter (source ['Hendriksen_2013:abstract'])</li><li>dropped unlinked row (NIL): 'patients weighing' — extend the ontology if this is a real PK parameter (source ['Hendriksen_2013:abstract'])</li><li>dropped unlinked row (NIL): 'those weighing' — extend the ontology if this is a real PK parameter (source ['Hendriksen_2013:abstract'])</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=quinine</li><li>1C volume normalization: Q63→Q61 (single-compartment model has no central/peripheral split; 'central volume of distribution' is the general volume)</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 259200, Tolerance = 1e-9, Interval = 1));
end Quinine_Hendriksen2013_reference;
