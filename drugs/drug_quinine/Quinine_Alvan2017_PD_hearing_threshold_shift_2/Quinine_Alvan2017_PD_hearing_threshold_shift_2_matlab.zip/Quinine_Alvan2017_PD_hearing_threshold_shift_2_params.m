function p = Quinine_Alvan2017_PD_hearing_threshold_shift_2_params()
% Quinine_Alvan2017_PD_hearing_threshold_shift_2_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% quinine Alvan_2017::hearing_threshold_shift::2: linear exposure-response sweep (response = E0 + slope*exposure). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one µM per second, in SI inside (kg/m3, s). Response hearing threshold shift in dB. Driver: quinine (cited_pk).
p.E0 = 0.0;
p.Emax = 0.0;
p.EC50 = 1.0;
p.gamma = 1.0;
p.slope = 0.15;
p.exposure_per_s = 1.0;
p.stop_time = 1000.0;
p.form = 'E0 + slope*exposure';
end
