model Quinine_Pukrittayakamee2003_PD_e
  "sigmoid_emax exposure-response sweep — Pukrittayakamee_2003 :: E (effect of treatment on the parasite multiplication rate (PMR))"
  extends Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep(
    E0 = 0,      // [1]
    Emax = -0.9999,  // [1]
    EC50 = 0.00068,  // [kg/m3; µg/ml × 0.001]
    gamma = 3,
    exposure_per_s = 0.001);   // 1 µg/ml per second
  // imax_as_negative_emax: Imax (Q323) enters SigmoidEmaxSweep as −Emax
  // defaulted: E0
  annotation(experiment(StartTime = 0, StopTime = 6.8, Interval = 0.0136),
    Documentation(info = "<html><body><!-- drug-about --><h4>About quinine</h4><p>Quinine is an antimalarial drug used to treat malaria, including falciparum malaria, and has also been used for babesiosis and muscle cramps. It remains an approved medicine, is listed among WHO essential medicines, and is used worldwide mainly for malaria, though it carries a boxed warning.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q189522\">Wikidata Q189522</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h4>Quinine_Pukrittayakamee2003_PD_e</h4><p>The steady-state exposure-response curve of Pukrittayakamee S et al., <i>Antimicrobial agents and chemotherapy 47(11):3458–3463</i> 2003 (<a href=\"https://doi.org/10.1128/AAC.47.11.3458-3463.2003\">doi:10.1128/AAC.47.11.3458-3463.2003</a>) — effect of treatment on the parasite multiplication rate (PMR) against quinine µg/ml — obtained by sweeping the driver instead of simulating a dose. Model family: sigmoid_emax.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = (library default) drug-free response (baseline)
  Emax  =     0.9999          maximal effect term (Emax, Q323)
  EC50  =       0.68 µg/ml    exposure at half of the maximal effect term (MIC, Q322)
  gamma =          3          Hill coefficient (slope (gamma), Q325)</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep\">SigmoidEmaxSweep</a>; this model only supplies the numbers. The x axis is one µg/ml of quinine per second of simulated time (exposure is in kg/m3): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0   (drug-free)
  exposure = EC50 (0.68 µg/ml)  response -0.5
  exposure -> infinity  response -0.9999</pre></body></html>"));
end Quinine_Pukrittayakamee2003_PD_e;
