function p = Quinine_Pukrittayakamee2003_PD_e_params()
% Quinine_Pukrittayakamee2003_PD_e_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% quinine Pukrittayakamee_2003::E: sigmoid_emax exposure-response sweep (response = E0 + Emax*frac). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one µg/ml per second, in SI inside (kg/m3, s). Response E in its own unit. Driver: quinine (cited_pk).
p.E0 = 0.0;
p.Emax = -0.9999;
p.EC50 = 0.0006799999999999999;
p.gamma = 3.0;
p.slope = 0.0;
p.exposure_per_s = 0.001;
p.stop_time = 6.8;
p.form = 'E0 + Emax*frac';
end
