function p = Quinine_Garrido2003_PD_cl_m10_params()
% Quinine_Garrido2003_PD_cl_m10_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% quinine Garrido_2003::CL_M10: emax exposure-response sweep (response = E0 + Emax*frac). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one ng/ml per second, in SI inside (kg/m3, s). Response CL(M10) in its own unit. Driver: quinine (cited_pk).
p.E0 = 0.0;
p.Emax = -0.94;
p.EC50 = 9.7e-05;
p.gamma = 1.0;
p.slope = 0.0;
p.exposure_per_s = 1e-06;
p.stop_time = 970.0;
p.form = 'E0 + Emax*frac';
end
