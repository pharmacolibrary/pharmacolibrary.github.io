model Quinine_Phillips1986_reference
  parameter Real Cl_ref = 9.333333333333332e-07 "Cl [m3/s]";
  parameter Real Vd_ref = 0.707 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.3244168,
    adminMass = 0.00035
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About quinine</h4><p>Quinine is an antimalarial drug used to treat malaria, including falciparum malaria, and has also been used for babesiosis and muscle cramps. It remains an approved medicine, is listed among WHO essential medicines, and is used worldwide mainly for malaria, though it carries a boxed warning.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q189522\">Wikidata Q189522</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>quinine</td></tr><tr><td>population:</td><td>pregnant and lactating women with falciparum malaria</td></tr><tr><td>source_paper:</td><td>Phillips_1986</td></tr><tr><td>measured_compound:</td><td>quinine</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>tab_0</td></tr><tr><td>input:</td><td>PK_1C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>quinine 324.417 g/mol (drugbank)</td></tr></table><h4>Interpretation flags</h4><ul><li>unit_dimension_unknown: 'l kg' (V)</li><li>unit_dimension_unknown: &quot;ml min-' kg-'&quot; (CL)</li><li>dropped value-less row: 't,lz = plasma half-time'</li><li>dropped value-less row: 'V = total apparent volume of distribution'</li><li>dropped value-less row: 'CL = total clearance'</li><li>implicit units: 't,2,z' → h (from the paper text: &quot;Abstract: 'elimination half-time (t112,z), 11.3 ± 4.3 h'&quot;)</li><li>implicit units: 'V (l kg)' → L/kg (from the paper text: &quot;Abstract: 'total apparent volume of distribution, V, 0.96 ± 0.27 l kg-' (i.e. L/kg)'&quot;)</li><li>implicit units: &quot;CL (ml min-' kg-')&quot; → mL/min/kg (from the paper text: &quot;Abstract: 'total clearance, 1.22 ± 0.77 ml min-1 kg-'; table column header also 'CL (ml min-1 kg-1)'&quot;)</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=quinine</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 259200, Tolerance = 1e-9, Interval = 1));
end Quinine_Phillips1986_reference;
