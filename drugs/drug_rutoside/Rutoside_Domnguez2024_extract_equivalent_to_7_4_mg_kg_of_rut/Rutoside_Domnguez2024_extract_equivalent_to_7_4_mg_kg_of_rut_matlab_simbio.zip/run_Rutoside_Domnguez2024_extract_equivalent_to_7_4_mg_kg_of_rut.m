% Run (SimBiology): build model + dose, simulate 0..24.0 h, plot.
p = Rutoside_Domnguez2024_extract_equivalent_to_7_4_mg_kg_of_rut_params();
[model, dose, variant] = build_sb_pk(p);
sd = simulate_sb(model, variant, dose, 24.0);
