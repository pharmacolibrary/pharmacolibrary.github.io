% Run (SimBiology): build model + dose, simulate 0..432.0 h, plot.
p = VonWillebrandFactor_Zhu2020_reference_params();
[model, dose, variant] = build_sb_pk(p);
sd = simulate_sb(model, variant, dose, 432.0);
