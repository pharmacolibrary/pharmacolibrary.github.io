model VonWillebrandFactor_Al2025_final
  parameter Real Cl_ref = 2.1333333333333332e-08 "Cl [m3/s]";
  parameter Real Vd_ref = 0.00358 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 0.9,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    adminMass = 0.0001,
    ka = 0.0001388888888888889,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About von_willebrand_factor</h4><p>Von Willebrand factor is a blood protein used as a medicine to treat bleeding problems, particularly von Willebrand disease. It is an approved treatment, given as a blood coagulation factor product, though its use remains limited to specialised care.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q412310\">Wikidata Q412310</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>von_willebrand_factor</td></tr><tr><td>population:</td><td>pregnant women with von Willebrand disease</td></tr><tr><td>source_paper:</td><td>Al_2025</td></tr><tr><td>measured_compound:</td><td>von Willebrand factor</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>hem370061-tbl-0003</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr></table><p><b>Defaulted (base-class default used):</b> F, Tlag.</p><h4>Interpretation flags</h4><ul><li>table section residual_error: 'Proportional error (%)' routed out of structural estimates ('Residual variability')</li><li>table section residual_error: 'Additional error (IU/mL)' routed out of structural estimates ('Residual variability')</li><li>dropped PD-category row 'Baseline (IU/mL)' → Q324 (E0, category G11) — pharmacodynamic parameters belong to scholarpd, not the PK model (source ['hem370061-tbl-0003:row1:col3'])</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=von Willebrand factor</li><li>model-stage split: 'fviii final model values (rse%) [shrinkage %]' is the final model of Al_2025 (paper reports 2 stages: fviii final model values (rse%) [shrinkage %], vwf final model values (rse%) [shrinkage %]); same population, different model-building step</li><li>molar mass: none found for 'von_willebrand_factor' — its concentrations stay mass-only</li><li>molar mass: none found for 'von Willebrand factor' — its concentrations stay mass-only</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li><li>gap-filled Q49 (kabs) from Schöning_2026's review values (primary lacked it)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 604800, Tolerance = 1e-9, Interval = 1));
end VonWillebrandFactor_Al2025_final;
