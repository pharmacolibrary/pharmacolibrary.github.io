model VonWillebrandFactor_Valke2024_reference
  parameter Real Cl_ref = 8.527777777777778e-08 "Cl [m3/s]";
  parameter Real Vd_ref = 0.00391 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    adminMass = 1e-05,
    k12 = 7.743677181017335e-06,
    k21 = 3.305434255215915e-05
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About von_willebrand_factor</h4><p>Von Willebrand factor is a blood protein used as a medicine to treat bleeding problems, particularly von Willebrand disease. It is an approved treatment, given as a blood coagulation factor product, though its use remains limited to specialised care.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q412310\">Wikidata Q412310</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>von_willebrand_factor</td></tr><tr><td>population:</td><td>review reference</td></tr><tr><td>source_paper:</td><td>Valke_2024</td></tr><tr><td>measured_compound:</td><td>von_willebrand_factor</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_2C: IV (no input phase)</td></tr></table><h4>Interpretation flags</h4><ul><li>built from REVIEW reference values (Valke_2024) — secondary source</li><li>volume reported by review</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 162000, Tolerance = 1e-9, Interval = 1));
end VonWillebrandFactor_Valke2024_reference;
