model VonWillebrandFactor_Valke2024_PD_ntp
  "sigmoid_emax exposure-response sweep — Valke_2024 :: NTP (Normalized thrombin potential)"
  extends Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep(
    E0 = 21.9,      // [% of NPP]
    Emax = 65.3,  // [% of NPP]
    EC50 = 1.93,  // [IU/dl]
    gamma = 1,
    exposure_per_s = 1);   // 1 IU/dl per second
  // exposure_unit_unresolved: 'IU/dl' — the x axis is in the paper's unit, not SI
  annotation(experiment(StartTime = 0, StopTime = 20, Interval = 0.04),
    Documentation(info = "<html><body><!-- drug-about --><h4>About von_willebrand_factor</h4><p>Von Willebrand factor is a blood protein used as a medicine to treat bleeding problems, particularly von Willebrand disease. It is an approved treatment, given as a blood coagulation factor product, though its use remains limited to specialised care.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q412310\">Wikidata Q412310</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h4>VonWillebrandFactor_Valke2024_PD_ntp</h4><p>The steady-state exposure-response curve of Valke LLFG et al., <i>European journal of drug metabolism and pharmacokinetics 49(2):191-205</i> 2024 (<a href=\"https://doi.org/10.1007/s13318-024-00876-6\">doi:10.1007/s13318-024-00876-6</a>) — Normalized thrombin potential [% of NPP] against Factor VIII IU/dl — obtained by sweeping the driver instead of simulating a dose. Model family: sigmoid_emax.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    =       21.9 % of NPP drug-free response (baseline) (Baseline effect (% of NPP), Q324)
  Emax  =       65.3 % of NPP maximal effect term (Maximal effect (Emax) (% of NPP), Q320)
  EC50  =       1.93 IU/dl    exposure at half of the maximal effect term (EC50 (IU/dl), Q321)
  gamma =          1          Hill coefficient (Hill coefficient, Q325)</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep\">SigmoidEmaxSweep</a>; this model only supplies the numbers. The x axis is one IU/dl of Factor VIII per second of simulated time: there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 21.9   (drug-free)
  exposure = EC50 (1.93 IU/dl)  response 54.55
  exposure -> infinity  response 87.2</pre></body></html>"));
end VonWillebrandFactor_Valke2024_PD_ntp;
