function p = VonWillebrandFactor_Valke2024_PD_ntp_params()
% VonWillebrandFactor_Valke2024_PD_ntp_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% von_willebrand_factor Valke_2024::NTP: sigmoid_emax exposure-response sweep (response = E0 + Emax*frac). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one IU/dl per second, in SI inside (kg/m3, s). Response NTP in % of NPP. Driver: Factor VIII (cited_pk).
p.E0 = 21.9;
p.Emax = 65.3;
p.EC50 = 1.93;
p.gamma = 1.0;
p.slope = 0.0;
p.exposure_per_s = 1.0;
p.stop_time = 20.0;
p.form = 'E0 + Emax*frac';
end
