function p = VonWillebrandFactor_Valke2024_PD_npph_params()
% VonWillebrandFactor_Valke2024_PD_npph_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% von_willebrand_factor Valke_2024::NPPH: sigmoid_emax exposure-response sweep (response = E0 + Emax*frac). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one IU/dl per second, in SI inside (kg/m3, s). Response NPPH in % of NPP. Driver: Factor VIII (cited_pk).
p.E0 = 81.2;
p.Emax = -1.0;
p.EC50 = 256.0;
p.gamma = 1.0;
p.slope = 0.0;
p.exposure_per_s = 1.0;
p.stop_time = 2600.0;
p.form = 'E0 + Emax*frac';
end
