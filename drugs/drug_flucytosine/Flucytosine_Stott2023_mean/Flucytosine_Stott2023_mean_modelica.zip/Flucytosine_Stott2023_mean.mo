model Flucytosine_Stott2023_mean
  parameter Real Cl_ref = 1.6333333333333333e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.0175 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.1290925,
    adminMass = 0.00175,
    ka = 0.0004916666666666666,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About flucytosine</h4><p>Flucytosine is an antifungal used to treat serious fungal infections such as candidiasis, cryptococcosis including cryptococcal meningitis, aspergillosis, and chromoblastomycosis. It remains in clinical use, is listed among WHO essential medicines, and is available as a systemic and topical antifungal, though it carries a boxed warning.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q238490\">Wikidata Q238490</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>flucytosine</td></tr><tr><td>population:</td><td>adults with HIV-associated cryptococcal meningoencephalitis</td></tr><tr><td>source_paper:</td><td>Stott_2023</td></tr><tr><td>measured_compound:</td><td>flucytosine</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>dkad038-T1</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>flucytosine 129.093 g/mol (drugbank)</td></tr></table><p><b>Defaulted (base-class default used):</b> Tlag.</p><h4>Interpretation flags</h4><ul><li>dropped duplicate Q48 ('K32 (h−1)', value '9.02') — already have one for this compound</li><li>dropped duplicate Q48 ('K24 (h−1)', value '5.68') — already have one for this compound</li><li>dropped duplicate Q48 ('K42 (h−1)', value '1.38') — already have one for this compound</li><li>dropped unlinked row (NIL): 'Vcns/F (L)' — extend the ontology if this is a real PK parameter (source ['dkad038-T1:row8:col1'])</li><li>apparent-ness (ontology-grounded): parameterization=apparent, measured_compound=flucytosine</li><li>structure disagreement: deterministic 1C vs LLM 3C — review compartment count</li><li>population split: 'mean' subgroup of Stott_2023 (paper reports 2 populations: mean, median)</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of TLAG: primary's parameterization (rate-constant / ka-only) does not use it</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Flucytosine_Stott2023_mean;
