model Flucytosine_Kim2020_reference
  parameter Real Cl_ref = 1.2666666666666667e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.060700000000000004 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.1290925,
    adminMass = 0.01
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About flucytosine</h4><p>Flucytosine is an antifungal used to treat serious fungal infections such as candidiasis, cryptococcosis including cryptococcal meningitis, aspergillosis, and chromoblastomycosis. It remains in clinical use, is listed among WHO essential medicines, and is available as a systemic and topical antifungal, though it carries a boxed warning.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q238490\">Wikidata Q238490</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>flucytosine</td></tr><tr><td>population:</td><td>review reference</td></tr><tr><td>source_paper:</td><td>Kim_2020</td></tr><tr><td>measured_compound:</td><td>flucytosine</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>flucytosine 129.093 g/mol (drugbank)</td></tr></table><h4>Interpretation flags</h4><ul><li>built from REVIEW reference values (Kim_2020) — secondary source</li><li>volume reported by review</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 169200, Tolerance = 1e-9, Interval = 1));
end Flucytosine_Kim2020_reference;
