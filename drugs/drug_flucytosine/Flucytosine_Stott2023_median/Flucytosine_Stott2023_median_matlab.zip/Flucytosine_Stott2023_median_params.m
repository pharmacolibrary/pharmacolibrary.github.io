function p = Flucytosine_Stott2023_median_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: flucytosine   source: Stott_2023 / median   route: oral
  p.name  = 'Flucytosine_Stott2023_median_params';
  p.drug  = 'flucytosine';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 14.76;                % central volume [L]
  p.CL = 5.31;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 1.01;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 1750.0;             % dose [mg]
end
