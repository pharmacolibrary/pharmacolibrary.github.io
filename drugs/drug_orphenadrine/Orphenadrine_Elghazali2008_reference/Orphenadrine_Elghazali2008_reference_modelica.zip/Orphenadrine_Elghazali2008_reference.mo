model Orphenadrine_Elghazali2008_reference
  parameter Real Cl_ref = 1.1666666666666666e-05 "Cl [m3/s]";
  parameter Real Vd_ref = 0.0609 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.26938799999999996,
    adminMass = 1e-05
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About orphenadrine</h4><p>Orphenadrine is a centrally acting muscle relaxant and anticholinergic drug used for painful muscle spasms, cramps, and spastic conditions, and also as an antiparkinson agent. It remains an approved medicine, used mainly for musculoskeletal and neurological indications, though not authorised centrally in the European Union.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q3292273\">Wikidata Q3292273</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>orphenadrine</td></tr><tr><td>population:</td><td>camels</td></tr><tr><td>source_paper:</td><td>Elghazali_2008</td></tr><tr><td>measured_compound:</td><td>orphenadrine</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>orphenadrine 269.388 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>unit_dimension_unknown: 'g/hl(-1)' (AUC)</li><li>dropped unlinked row (NIL): 'single dose of orphenadrine aspartate' — extend the ontology if this is a real PK parameter (source ['Elghazali_2008:abstract'])</li><li>implicit units: 'area under the time concentration curve (AUC)' → mg*h/L (from the popPK convention: 'The paper provides no explicit unit in the text or table caption. The parameter is AUC (Area Under the Curve) with a val')</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=orphenadrine</li><li>structure disagreement: deterministic 1C vs LLM 2C — review compartment count</li><li>1C volume normalization: Q63→Q61 (single-compartment model has no central/peripheral split; 'volume of the central compartment of the two compartment pharmacokinetic model (V(c))' is the general volume)</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Orphenadrine_Elghazali2008_reference;
