% Run (SimBiology): build model + dose, simulate 0..96.0 h, plot.
p = Roxadustat_Czock2022_healthy_params();
[model, dose, variant] = build_sb_pk(p);
sd = simulate_sb(model, variant, dose, 96.0);
