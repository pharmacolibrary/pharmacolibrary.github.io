function p = Roxadustat_Takada2022_PD_ldl_c_params()
% Roxadustat_Takada2022_PD_ldl_c_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% roxadustat Takada_2022::LDL_C: indirect_response_i exposure-response sweep (response = E0*(1 - Emax*frac)). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one mg/h per second, in SI inside (kg/m3, s). Response LDL-C in its own unit. Driver: roxadustat (cited_pk).
p.E0 = 0.0;
p.Emax = 0.661;
p.EC50 = 4.194444444444444e-10;
p.gamma = 1.0;
p.slope = 0.0;
p.exposure_per_s = 2.77777777778e-10;
p.stop_time = 16.0;
p.form = 'E0*(1 - Emax*frac)';
end
