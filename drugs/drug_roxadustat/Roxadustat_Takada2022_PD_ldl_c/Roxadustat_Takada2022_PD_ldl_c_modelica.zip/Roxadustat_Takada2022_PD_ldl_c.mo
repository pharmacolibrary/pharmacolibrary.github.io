model Roxadustat_Takada2022_PD_ldl_c
  "indirect_response_i exposure-response sweep — Takada_2022 :: LDL-C (low-density lipoprotein cholesterol)"
  extends Pharmacolibrary.Interfaces.PartialExposureResponseSweep(
    E0 = 0,      // [1]
    Emax = 0.661,  // type I effect term
    EC50 = 4.19444444444e-10,  // [kg/s; mg/h × 2.77778e-10]
    gamma = 1,
    exposure_per_s = 2.77777777778e-10);   // 1 mg/h per second
equation
  response = E0*(1 - Emax*frac);   // steady state, indirect response type I
  // defaulted: E0
  // defaulted: gamma
  annotation(experiment(StartTime = 0, StopTime = 16, Interval = 0.032),
    Documentation(info = "<html><body><!-- drug-about --><h4>About roxadustat</h4><p>Roxadustat is an antianemic medicine used to treat anemia in people with chronic kidney disease. It is authorised in the European Union.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q27088611\">Wikidata Q27088611</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h4>Roxadustat_Takada2022_PD_ldl_c</h4><p>The steady-state exposure-response curve of Takada A et al., <i>Drug metabolism and pharmacokinetics 46:100461</i> 2022 (<a href=\"https://doi.org/10.1016/j.dmpk.2022.100461\">doi:10.1016/j.dmpk.2022.100461</a>) — low-density lipoprotein cholesterol against roxadustat mg/h — obtained by sweeping the driver instead of simulating a dose. Model family: indirect_response_i.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = (library default) drug-free response (baseline)
  Emax  =      0.661          maximal effect term (Imax, Q323)
  EC50  =       1.51 mg/h     exposure at half of the maximal effect term (ID50, Q322)
  gamma = (library default) Hill coefficient</pre><p>The algebra is <code>response = E0*(1 - Emax*frac)</code>; this model only supplies the numbers. The x axis is one mg/h of roxadustat per second of simulated time (exposure is in kg/s): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0   (drug-free)
  exposure = EC50 (1.51 mg/h)  response 0
  exposure -> infinity  response 0</pre></body></html>"));
end Roxadustat_Takada2022_PD_ldl_c;
