function p = Fexuprazan_Kim2022_PD_ph_3_params()
% Fexuprazan_Kim2022_PD_ph_3_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% fexuprazan Kim_2022::pH::3: indirect_response_i exposure-response sweep (response = E0*(1 - Emax*frac)). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one ng/g tissue per second, in SI inside (kg/m3, s). Response pH in its own unit. Driver: fexuprazan (pk_record).
p.E0 = 1.29;
p.Emax = 0.378;
p.EC50 = 0.919;
p.gamma = 2.16;
p.slope = 0.0;
p.exposure_per_s = 1.0;
p.stop_time = 9.2;
p.form = 'E0*(1 - Emax*frac)';
end
