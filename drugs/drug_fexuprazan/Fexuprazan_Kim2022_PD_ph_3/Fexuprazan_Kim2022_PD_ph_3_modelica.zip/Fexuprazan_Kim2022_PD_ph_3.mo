model Fexuprazan_Kim2022_PD_ph_3
  "indirect_response_i exposure-response sweep — Kim_2022 :: pH (gastric pH)"
  extends Pharmacolibrary.Interfaces.PartialExposureResponseSweep(
    E0 = 1.29,      // [1]
    Emax = 0.378,  // type I effect term
    EC50 = 0.919,  // [ng/g tissue]
    gamma = 2.16,
    exposure_per_s = 1);   // 1 ng/g tissue per second
equation
  response = E0*(1 - Emax*frac);   // steady state, indirect response type I
  // exposure_unit_unresolved: 'ng/g tissue' — the x axis is in the paper's unit, not SI
  annotation(experiment(StartTime = 0, StopTime = 9.2, Interval = 0.0184),
    Documentation(info = "<html><body><h4>Fexuprazan_Kim2022_PD_ph_3</h4><p>The steady-state exposure-response curve of Kim MS et al., <i>Pharmaceuticals (Basel, Switzerland) 15(6)</i> 2022 (<a href=\"https://doi.org/10.3390/ph15060709\">doi:10.3390/ph15060709</a>) — gastric pH against fexuprazan ng/g tissue — obtained by sweeping the driver instead of simulating a dose. Model family: indirect_response_i.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    =       1.29          drug-free response (baseline) (pHbaseline, Q324)
  Emax  =      0.378          maximal effect term (Imax, Q323)
  EC50  =      0.919 ng/g tissue exposure at half of the maximal effect term (IC50, Q322)
  gamma =       2.16          Hill coefficient (γ, Q325)</pre><p>The algebra is <code>response = E0*(1 - Emax*frac)</code>; this model only supplies the numbers. The x axis is one ng/g tissue of fexuprazan per second of simulated time: there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 1.29   (drug-free)
  exposure = EC50 (0.919 ng/g tissue)  response 1.046
  exposure -> infinity  response 0.8024</pre></body></html>"));
end Fexuprazan_Kim2022_PD_ph_3;
