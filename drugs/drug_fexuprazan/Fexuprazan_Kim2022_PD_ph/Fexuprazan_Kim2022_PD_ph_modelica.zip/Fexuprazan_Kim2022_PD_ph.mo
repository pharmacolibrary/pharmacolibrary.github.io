model Fexuprazan_Kim2022_PD_ph
  "indirect_response_i exposure-response sweep — Kim_2022 :: pH (gastric pH)"
  extends Pharmacolibrary.Interfaces.PartialExposureResponseSweep(
    E0 = 1.3,      // [1]
    Emax = 0.386,  // type I effect term
    EC50 = 1.06e-06,  // [kg/m3; ng/mL × 1e-06]
    gamma = 2.51,
    exposure_per_s = 1e-06);   // 1 ng/mL per second
equation
  response = E0*(1 - Emax*frac);   // steady state, indirect response type I
  annotation(experiment(StartTime = 0, StopTime = 11, Interval = 0.022),
    Documentation(info = "<html><body><h4>Fexuprazan_Kim2022_PD_ph</h4><p>The steady-state exposure-response curve of Kim MS et al., <i>Pharmaceuticals (Basel, Switzerland) 15(6)</i> 2022 (<a href=\"https://doi.org/10.3390/ph15060709\">doi:10.3390/ph15060709</a>) — gastric pH against fexuprazan ng/mL — obtained by sweeping the driver instead of simulating a dose. Model family: indirect_response_i.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    =        1.3          drug-free response (baseline) (pHbaseline, Q324)
  Emax  =      0.386          maximal effect term (Imax, Q323)
  EC50  =       1.06 ng/mL    exposure at half of the maximal effect term (IC50, Q322)
  gamma =       2.51          Hill coefficient (γ, Q325)</pre><p>The algebra is <code>response = E0*(1 - Emax*frac)</code>; this model only supplies the numbers. The x axis is one ng/mL of fexuprazan per second of simulated time (exposure is in kg/m3): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 1.3   (drug-free)
  exposure = EC50 (1.06 ng/mL)  response 1.049
  exposure -> infinity  response 0.7982</pre></body></html>"));
end Fexuprazan_Kim2022_PD_ph;
