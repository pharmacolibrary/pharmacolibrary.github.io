function p = Fexuprazan_Kim2022_PD_ph_params()
% Fexuprazan_Kim2022_PD_ph_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% fexuprazan Kim_2022::pH: indirect_response_i exposure-response sweep (response = E0*(1 - Emax*frac)). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one ng/mL per second, in SI inside (kg/m3, s). Response pH in its own unit. Driver: fexuprazan (pk_record).
p.E0 = 1.3;
p.Emax = 0.386;
p.EC50 = 1.06e-06;
p.gamma = 2.51;
p.slope = 0.0;
p.exposure_per_s = 1e-06;
p.stop_time = 11.0;
p.form = 'E0*(1 - Emax*frac)';
end
