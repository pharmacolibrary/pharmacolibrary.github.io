model Fexuprazan_Kim2022_PD_ph_4
  "sigmoid_emax exposure-response sweep — Kim_2022 :: pH (gastric pH)"
  extends Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep(
    E0 = 1.04,      // [1]
    Emax = 1.98e-08,  // [s; pH × 3.6e-09]
    EC50 = 0.992,  // [ng/g tissue]
    gamma = 1.58,
    exposure_per_s = 1);   // 1 ng/g tissue per second
  // exposure_unit_unresolved: 'ng/g tissue' — the x axis is in the paper's unit, not SI
  annotation(experiment(StartTime = 0, StopTime = 10, Interval = 0.02),
    Documentation(info = "<html><body><h4>Fexuprazan_Kim2022_PD_ph_4</h4><p>The steady-state exposure-response curve of Kim MS et al., <i>Pharmaceuticals (Basel, Switzerland) 15(6)</i> 2022 (<a href=\"https://doi.org/10.3390/ph15060709\">doi:10.3390/ph15060709</a>) — gastric pH against fexuprazan ng/g tissue — obtained by sweeping the driver instead of simulating a dose. Model family: sigmoid_emax.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    =       1.04          drug-free response (baseline) (pHbaseline, Q324)
  Emax  =        5.5 pH       maximal effect term (Emax, Q320)
  EC50  =      0.992 ng/g tissue exposure at half of the maximal effect term (EC50, Q321)
  gamma =       1.58          Hill coefficient (γ, Q325)</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep\">SigmoidEmaxSweep</a>; this model only supplies the numbers. The x axis is one ng/g tissue of fexuprazan per second of simulated time: there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 1.04   (drug-free)
  exposure = EC50 (0.992 ng/g tissue)  response 1.04
  exposure -> infinity  response 1.04</pre></body></html>"));
end Fexuprazan_Kim2022_PD_ph_4;
