function p = Fexuprazan_Kim2022_PD_ph_4_params()
% Fexuprazan_Kim2022_PD_ph_4_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% fexuprazan Kim_2022::pH::4: sigmoid_emax exposure-response sweep (response = E0 + Emax*frac). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one ng/g tissue per second, in SI inside (kg/m3, s). Response pH in its own unit. Driver: fexuprazan (pk_record).
p.E0 = 1.04;
p.Emax = 1.98e-08;
p.EC50 = 0.992;
p.gamma = 1.58;
p.slope = 0.0;
p.exposure_per_s = 1.0;
p.stop_time = 10.0;
p.form = 'E0 + Emax*frac';
end
