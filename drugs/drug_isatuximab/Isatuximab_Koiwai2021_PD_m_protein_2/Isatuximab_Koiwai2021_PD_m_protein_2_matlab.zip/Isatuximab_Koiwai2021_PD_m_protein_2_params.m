function p = Isatuximab_Koiwai2021_PD_m_protein_2_params()
% Isatuximab_Koiwai2021_PD_m_protein_2_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% isatuximab Koiwai_2021::M_protein::2: linear exposure-response sweep (response = E0 + slope*exposure). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one molar units per second, in SI inside (kg/m3, s). Response M-protein in g/L. Driver: isatuximab and lenalidomide (not_resolved).
p.E0 = 23.799999999999997;
p.Emax = 0.0;
p.EC50 = 1.0;
p.gamma = 1.0;
p.slope = 0.0193;
p.exposure_per_s = 1.0;
p.stop_time = 1000.0;
p.form = 'E0 + slope*exposure';
end
