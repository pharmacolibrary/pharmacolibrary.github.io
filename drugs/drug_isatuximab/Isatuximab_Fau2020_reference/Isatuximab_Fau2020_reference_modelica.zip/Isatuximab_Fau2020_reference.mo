model Isatuximab_Fau2020_reference
  parameter Real Cl_ref = 2.6527777777777777e-09 "Cl [m3/s]";
  parameter Real Vd_ref = 0.00513 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    adminMass = 7e-05
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About isatuximab</h4><p>Isatuximab is a monoclonal antibody that inhibits CD38 and is used to treat multiple myeloma. It is authorised in the European Union and is used in cancer treatment.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q20707906\">Wikidata Q20707906</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>isatuximab</td></tr><tr><td>population:</td><td>patients with relapsed/refractory multiple myeloma</td></tr><tr><td>source_paper:</td><td>Fau_2020</td></tr><tr><td>measured_compound:</td><td>isatuximab</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>Table S3</td></tr><tr><td>input:</td><td>PK_1C: IV (no input phase)</td></tr></table><h4>Interpretation flags</h4><ul><li>salvaged Q22 ('typical linear CL at steady-state'=0.00955) from results prose — parameter table was unreadable</li><li>salvaged Q63 ('typical volume of distribution of the central compartment'=5.13) from results prose — parameter table was unreadable</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=isatuximab</li><li>held at status:extracted — NIL link or unit issue (mismatch/unknown/normalisation-failed) present</li><li>1C volume normalization: Q63→Q61 (single-compartment model has no central/peripheral split; 'typical volume of distribution of the central compartment' is the general volume)</li><li>status held at route_to_review — not promoted</li><li>molar mass: none found for 'isatuximab' — its concentrations stay mass-only</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 7257600, Tolerance = 1e-9, Interval = 1));
end Isatuximab_Fau2020_reference;
