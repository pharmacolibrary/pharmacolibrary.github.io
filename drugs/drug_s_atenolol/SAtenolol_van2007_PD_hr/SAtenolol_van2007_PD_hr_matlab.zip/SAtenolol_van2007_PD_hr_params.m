function p = SAtenolol_van2007_PD_hr_params()
% SAtenolol_van2007_PD_hr_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% s_atenolol van_2007::HR: sigmoid_emax exposure-response sweep (response = E0 + Emax*frac). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one ng ml(-1) per second, in SI inside (kg/m3, s). Response HR in b.p.m.. Driver: S(-)-atenolol (not_resolved).
p.E0 = 517.0;
p.Emax = -168.0;
p.EC50 = 4.9e-05;
p.gamma = 0.95;
p.slope = 0.0;
p.exposure_per_s = 1e-06;
p.stop_time = 490.0;
p.form = 'E0 + Emax*frac';
end
