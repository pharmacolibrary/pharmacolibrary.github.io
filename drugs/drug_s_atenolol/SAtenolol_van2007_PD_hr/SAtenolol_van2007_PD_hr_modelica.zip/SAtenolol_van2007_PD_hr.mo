model SAtenolol_van2007_PD_hr
  "sigmoid_emax exposure-response sweep — van_2007 :: HR (heart rate)"
  extends Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep(
    E0 = 517,      // [b.p.m.]
    Emax = -168,  // [b.p.m.]
    EC50 = 4.9e-05,  // [kg/m3; ng ml(-1) × 1e-06]
    gamma = 0.95,
    exposure_per_s = 1e-06);   // 1 ng ml(-1) per second
  // imax_as_negative_emax: Imax (Q323) enters SigmoidEmaxSweep as −Emax
  annotation(experiment(StartTime = 0, StopTime = 490, Interval = 0.98),
    Documentation(info = "<html><body><!-- drug-about --><h4>About s_atenolol</h4><p>Esatenolol, the S-enantiomer of atenolol, is a selective beta blocker studied for treating myocardial infarction and arterial hypertension. It remains an experimental compound and is not an established marketed medicine.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q24255323\">Wikidata Q24255323</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h4>SAtenolol_van2007_PD_hr</h4><p>The steady-state exposure-response curve of van Steeg TJ et al., <i>British journal of pharmacology 151(3):356–366</i> 2007 (<a href=\"https://doi.org/10.1038/sj.bjp.0707234\">doi:10.1038/sj.bjp.0707234</a>) — heart rate [b.p.m.] against S(-)-atenolol ng ml(-1) — obtained by sweeping the driver instead of simulating a dose. Model family: sigmoid_emax.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    =        517 b.p.m.   drug-free response (baseline) (E0, Q324)
  Emax  =        168 b.p.m.   maximal effect term (Emax, Q323)
  EC50  =         49 ng ml(-1) exposure at half of the maximal effect term (EC50, Q321)
  gamma =       0.95          Hill coefficient (n, Q325)</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep\">SigmoidEmaxSweep</a>; this model only supplies the numbers. The x axis is one ng ml(-1) of S(-)-atenolol per second of simulated time (exposure is in kg/m3): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 517   (drug-free)
  exposure = EC50 (49 ng ml(-1))  response 433
  exposure -> infinity  response 349</pre></body></html>"));
end SAtenolol_van2007_PD_hr;
