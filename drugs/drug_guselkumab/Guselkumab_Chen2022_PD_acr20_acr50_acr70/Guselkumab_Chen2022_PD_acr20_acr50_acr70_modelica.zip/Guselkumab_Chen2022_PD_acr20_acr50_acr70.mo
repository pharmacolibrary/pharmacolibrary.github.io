model Guselkumab_Chen2022_PD_acr20_acr50_acr70
  "emax exposure-response sweep — Chen_2022 :: ACR20/ACR50/ACR70 (American College of Rheumatology [ACR] 20%, 50%, and 70% improvement criteria)"
  extends Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep(
    E0 = 0,      // [1]
    Emax = 1.44,  // [1]
    EC50 = 134,  // [day*µg/ml]
    gamma = 1,
    exposure_per_s = 1);   // 1 day*µg/ml per second
  // exposure_unit_unresolved: 'day*µg/ml' — the x axis is in the paper's unit, not SI
  // defaulted: E0
  // defaulted: gamma
  annotation(experiment(StartTime = 0, StopTime = 1400, Interval = 2.8),
    Documentation(info = "<html><body><!-- drug-about --><h4>About guselkumab</h4><p>Guselkumab is a monoclonal antibody that acts as an interleukin inhibitor, belonging to the immunosuppressant class of medicines. It is an approved medicine and has also been investigated for further uses.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q15708315\">Wikidata Q15708315</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h4>Guselkumab_Chen2022_PD_acr20_acr50_acr70</h4><p>The steady-state exposure-response curve of Chen Y et al., <i>Clinical and translational science 15(3):749–760</i> 2022 (<a href=\"https://doi.org/10.1111/cts.13197\">doi:10.1111/cts.13197</a>) — American College of Rheumatology [ACR] 20%, 50%, and 70% improvement criteria against guselkumab day*µg/ml — obtained by sweeping the driver instead of simulating a dose. Model family: emax.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = (library default) drug-free response (baseline)
  Emax  =       1.44          maximal effect term (Emax, Q320)
  EC50  =        134 day*µg/ml exposure at half of the maximal effect term (EC50, Q321)
  gamma = (library default) Hill coefficient</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep\">SigmoidEmaxSweep</a>; this model only supplies the numbers. The x axis is one day*µg/ml of guselkumab per second of simulated time: there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0   (drug-free)
  exposure = EC50 (134 day*µg/ml)  response 0.72
  exposure -> infinity  response 1.44</pre></body></html>"));
end Guselkumab_Chen2022_PD_acr20_acr50_acr70;
