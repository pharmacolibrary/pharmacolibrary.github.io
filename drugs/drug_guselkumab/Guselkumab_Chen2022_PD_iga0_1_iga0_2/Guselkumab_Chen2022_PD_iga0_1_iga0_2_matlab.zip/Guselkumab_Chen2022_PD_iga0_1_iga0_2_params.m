function p = Guselkumab_Chen2022_PD_iga0_1_iga0_2_params()
% Guselkumab_Chen2022_PD_iga0_1_iga0_2_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% guselkumab Chen_2022::IGA0_1_IGA0::2: emax exposure-response sweep (response = E0 + Emax*frac). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one µg/ml per second, in SI inside (kg/m3, s). Response IGA0/1/IGA0 in its own unit. Driver: guselkumab (pk_record).
p.E0 = 0.0;
p.Emax = 3.09;
p.EC50 = 0.0009219999999999999;
p.gamma = 1.0;
p.slope = 0.0;
p.exposure_per_s = 0.001;
p.stop_time = 9.3;
p.form = 'E0 + Emax*frac';
end
