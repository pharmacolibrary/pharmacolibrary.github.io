function p = Guselkumab_Chen2022_PD_acr20_acr50_acr70_2_params()
% Guselkumab_Chen2022_PD_acr20_acr50_acr70_2_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% guselkumab Chen_2022::ACR20_ACR50_ACR70::2: emax exposure-response sweep (response = E0 + Emax*frac). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one µg/ml per second, in SI inside (kg/m3, s). Response ACR20/ACR50/ACR70 in its own unit. Driver: guselkumab (pk_record).
p.E0 = 0.0;
p.Emax = 1.53;
p.EC50 = 0.0010599999999999997;
p.gamma = 1.0;
p.slope = 0.0;
p.exposure_per_s = 0.001;
p.stop_time = 11.0;
p.form = 'E0 + Emax*frac';
end
