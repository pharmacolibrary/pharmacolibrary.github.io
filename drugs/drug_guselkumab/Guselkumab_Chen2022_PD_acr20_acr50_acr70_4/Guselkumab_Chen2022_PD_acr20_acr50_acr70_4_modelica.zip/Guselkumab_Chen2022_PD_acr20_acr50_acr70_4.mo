model Guselkumab_Chen2022_PD_acr20_acr50_acr70_4
  "indirect_response_i exposure-response sweep — Chen_2022 :: ACR20/ACR50/ACR70 (American College of Rheumatology [ACR] 20%, 50%, and 70% improvement criteria)"
  extends Pharmacolibrary.Pharmacodynamic.IndirectTurnoverSweep(
    E0 = 0,      // [1]
    Emax = 2.75,  // type IV effect term
    EC50 = 0.000173,  // [kg/m3; µg/ml × 0.001]
    gamma = 1,
    exposure_per_s = 0.001);   // 1 µg/ml per second
  // emax_not_a_fraction: type I needs Imax ≤ 1 but the record has 2.75; bound as the reciprocal stimulation form (IV) the paper fitted
  // defaulted: E0
  // defaulted: gamma
  annotation(experiment(StartTime = 0, StopTime = 1.8, Interval = 0.0036),
    Documentation(info = "<html><body><!-- drug-about --><h4>About guselkumab</h4><p>Guselkumab is a monoclonal antibody that acts as an interleukin inhibitor, belonging to the immunosuppressant class of medicines. It is an approved medicine and has also been investigated for further uses.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q15708315\">Wikidata Q15708315</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h4>Guselkumab_Chen2022_PD_acr20_acr50_acr70_4</h4><p>The steady-state exposure-response curve of Chen Y et al., <i>Clinical and translational science 15(3):749–760</i> 2022 (<a href=\"https://doi.org/10.1111/cts.13197\">doi:10.1111/cts.13197</a>) — American College of Rheumatology [ACR] 20%, 50%, and 70% improvement criteria against guselkumab µg/ml — obtained by sweeping the driver instead of simulating a dose. Model family: indirect_response_i.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = (library default) drug-free response (baseline)
  Emax  =       2.75          maximal effect term (DEMX, Q323)
  EC50  =      0.173 µg/ml    exposure at half of the maximal effect term (EC50, Q321)
  gamma = (library default) Hill coefficient</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.IndirectTurnoverSweep\">IndirectTurnoverSweep</a>; this model only supplies the numbers. The x axis is one µg/ml of guselkumab per second of simulated time (exposure is in kg/m3): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><p>The effect term enters as a reciprocal (steady state of <code>der(R) = Kin - Kout*(1 + Emax*frac)*R</code>), so EC50 is the exposure at half the maximal STIMULATION of turnover, not at half the response.</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0   (drug-free)
  exposure = EC50 (0.173 µg/ml)  response 0
  exposure -> infinity  response 0</pre></body></html>"));
end Guselkumab_Chen2022_PD_acr20_acr50_acr70_4;
