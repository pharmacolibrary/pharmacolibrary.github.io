model Guselkumab_Vaskeikina2026_PD_mrss
  "emax exposure-response sweep — Vaskeikina_2026 :: mRSS (modified Rodnan skin score)"
  extends Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep(
    E0 = 0,      // [1]
    Emax = -23.55,  // [1]
    EC50 = 16625952,  // [s; weeks × 604800]
    gamma = 1,
    exposure_per_s = 604800);   // 1 weeks per second
  // imax_as_negative_emax: Imax (Q323) enters SigmoidEmaxSweep as −Emax
  // defaulted: E0
  // defaulted: gamma
  annotation(experiment(StartTime = 0, StopTime = 280, Interval = 0.56),
    Documentation(info = "<html><body><!-- drug-about --><h4>About guselkumab</h4><p>Guselkumab is a monoclonal antibody that acts as an interleukin inhibitor, belonging to the immunosuppressant class of medicines. It is an approved medicine and has also been investigated for further uses.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q15708315\">Wikidata Q15708315</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h4>Guselkumab_Vaskeikina2026_PD_mrss</h4><p>The steady-state exposure-response curve of Vaskeikina M et al., <i>Pharmaceutics 18(2)</i> 2026 (<a href=\"https://doi.org/10.3390/pharmaceutics18020250\">doi:10.3390/pharmaceutics18020250</a>) — modified Rodnan skin score against Guselkumab weeks — obtained by sweeping the driver instead of simulating a dose. Model family: emax.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = (library default) drug-free response (baseline)
  Emax  =     -23.55          maximal effect term (Effect of guselkumab on mRSS reduction (βGuselkumabmRSS), Q323)
  EC50  =      27.49 weeks    exposure at half of the maximal effect term (Time to 50% maximum change in mRSS and FVC in weeks (ET50), Q321)
  gamma = (library default) Hill coefficient</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep\">SigmoidEmaxSweep</a>; this model only supplies the numbers. The x axis is one weeks of Guselkumab per second of simulated time (exposure is in s): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0   (drug-free)
  exposure = EC50 (27.49 weeks)  response -11.78
  exposure -> infinity  response -23.55</pre></body></html>"));
end Guselkumab_Vaskeikina2026_PD_mrss;
