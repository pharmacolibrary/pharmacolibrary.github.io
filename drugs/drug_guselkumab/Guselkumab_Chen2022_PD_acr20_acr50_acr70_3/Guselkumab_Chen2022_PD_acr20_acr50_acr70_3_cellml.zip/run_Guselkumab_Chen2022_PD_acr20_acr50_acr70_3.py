#!/usr/bin/env python3
"""Sweep Guselkumab_Chen2022_PD_acr20_acr50_acr70_3.cellml — the curve is evaluated directly (one ODE for the swept exposure and
one algebraic response), so no CellML tooling is needed; OpenCOR opens the file as-is.
Writes Guselkumab_Chen2022_PD_acr20_acr50_acr70_3.csv/.json/.png next to this script."""
import json, os, math
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

BASE = os.path.join(os.path.dirname(os.path.abspath(__file__)), "Guselkumab_Chen2022_PD_acr20_acr50_acr70_3")
E0, Emax, EC50, gamma, slope, exposure_per_s = 0.0, 1.26, 0.00014999999999999996, 1.0, 0.0, 0.001
def response(exposure):
    frac = exposure**gamma / (EC50**gamma + exposure**gamma) if exposure > 0 else 0.0
    log = math.log
    return E0 + Emax*(exposure**gamma / (EC50**gamma + exposure**gamma))
x = [exposure_per_s * 1.5 * i / 500 for i in range(501)]
y = [response(v) for v in x]
with open(BASE + ".csv", "w") as f:
    f.write("exposure_si,response\n")
    for xi, yi in zip(x, y):
        f.write("%r,%r\n" % (xi, yi))
with open(BASE + ".json", "w") as f:
    json.dump({"model": "Guselkumab_Chen2022_PD_acr20_acr50_acr70_3", "exposure_si": x, "response": y}, f, indent=2)
plt.figure(); plt.plot(x, y, linewidth=1.5)
plt.xlabel("exposure [µg/ml]"); plt.ylabel("response []")
plt.title("Guselkumab_Chen2022_PD_acr20_acr50_acr70_3"); plt.grid(True, alpha=0.3); plt.tight_layout(); plt.savefig(BASE + ".png", dpi=150)
print("wrote %s.csv, %s.json, %s.png" % (BASE, BASE, BASE))
