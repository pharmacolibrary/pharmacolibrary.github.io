model Ertapenem_Wittau2017_reference
  parameter Real Cl_ref = 3.416666666666667e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.0143 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.47551499999999997,
    adminMass = 0.001
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About ertapenem</h4><p>Ertapenem is a carbapenem antibiotic used to treat bacterial infections such as sepsis, urinary tract infections, pyelonephritis, and skin infections. It is an approved antibiotic, authorised in the European Union, and used for a range of community-acquired bacterial infections.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q553220\">Wikidata Q553220</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>ertapenem</td></tr><tr><td>population:</td><td>morbidly obese patients after laparoscopic visceral surgery</td></tr><tr><td>source_paper:</td><td>Wittau_2017</td></tr><tr><td>measured_compound:</td><td>ertapenem</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>ertapenem 475.515 g/mol (drugbank)</td></tr></table><h4>Interpretation flags</h4><ul><li>dropped unlinked row (NIL): 'fat-free mass' — extend the ontology if this is a real PK parameter (source ['Wittau_2017:abstract'])</li><li>dropped value-less row: 'The area under the concentration-time curve (AUC) for ertapenem was 49% lower in subcutaneous tissue and 25% lower in peritoneal fluid than the unbound AUC in plasma.'</li><li>dropped value-less row: 'equilibration half-life'</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=ertapenem</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li><li>gap-filled Q61 (V) from Chen_2024's review values (primary lacked it)</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Ertapenem_Wittau2017_reference;
