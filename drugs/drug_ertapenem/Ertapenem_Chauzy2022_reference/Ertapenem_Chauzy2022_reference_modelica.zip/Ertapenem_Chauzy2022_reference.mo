model Ertapenem_Chauzy2022_reference
  parameter Real Cl_ref = 8.497222222222222e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.0518 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.47551499999999997,
    adminMass = 0.001,
    k12 = 0.00011824324324324326,
    k21 = 0.00011776581426648721
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About ertapenem</h4><p>Ertapenem is a carbapenem antibiotic used to treat bacterial infections such as sepsis, urinary tract infections, pyelonephritis, and skin infections. It is an approved antibiotic, authorised in the European Union, and used for a range of community-acquired bacterial infections.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q553220\">Wikidata Q553220</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>ertapenem</td></tr><tr><td>population:</td><td>review reference</td></tr><tr><td>source_paper:</td><td>Chauzy_2022</td></tr><tr><td>measured_compound:</td><td>ertapenem</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_2C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>ertapenem 475.515 g/mol (drugbank)</td></tr></table><h4>Interpretation flags</h4><ul><li>built from REVIEW reference values (Chauzy_2022) — secondary source</li><li>volume reported by review</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Ertapenem_Chauzy2022_reference;
