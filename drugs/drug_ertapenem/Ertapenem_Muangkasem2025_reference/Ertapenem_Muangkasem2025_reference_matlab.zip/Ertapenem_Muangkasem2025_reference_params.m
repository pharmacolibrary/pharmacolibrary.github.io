function p = Ertapenem_Muangkasem2025_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: ertapenem   source: Muangkasem_2025 / reference   route: iv_bolus
  % estimated (absent from source): F
  p.name  = 'Ertapenem_Muangkasem2025_reference_params';
  p.drug  = 'ertapenem';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'iv_bolus';        % 'oral' | 'iv_bolus'
  p.depot = false;             % oral -> first-order absorption depot
  p.Vc = 10.6;                % central volume [L]
  p.CL = 2.63;                % clearance [L/h]
  p.Vp = [4.24];             % peripheral volumes [L]
  p.Q  = [22.05];             % inter-compartmental clearances [L/h]
  p.ka = 0.0;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 1000.0;             % dose [mg]
end
