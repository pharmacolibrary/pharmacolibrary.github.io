model Ertapenem_Cardone2012_reference
  parameter Real Cl_ref = 6.666666666666667e-08 "Cl [m3/s]";
  parameter Real Vd_ref = 0.00278 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.47551499999999997,
    adminMass = 0.0001,
    ka = 0.0001388888888888889,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About ertapenem</h4><p>Ertapenem is a carbapenem antibiotic used to treat bacterial infections such as sepsis, urinary tract infections, pyelonephritis, and skin infections. It is an approved antibiotic, authorised in the European Union, and used for a range of community-acquired bacterial infections.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q553220\">Wikidata Q553220</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>ertapenem</td></tr><tr><td>population:</td><td>patients on continuous ambulatory peritoneal dialysis</td></tr><tr><td>source_paper:</td><td>Cardone_2012</td></tr><tr><td>measured_compound:</td><td>ertapenem</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_2C_enteral: apparent (/F) parameterization ⇒ extravascular dosing</td></tr><tr><td>molar_masses:</td><td>ertapenem 475.515 g/mol (drugbank)</td></tr></table><p><b>Defaulted (base-class default used):</b> ka, Tlag, k12, k21.</p><h4>Interpretation flags</h4><ul><li>dropped duplicate Q21 ('median penetration ratio', value 0.801) — already have one for this compound</li><li>apparent-ness (ontology-grounded): parameterization=apparent, measured_compound=ertapenem</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 147600, Tolerance = 1e-9, Interval = 1));
end Ertapenem_Cardone2012_reference;
