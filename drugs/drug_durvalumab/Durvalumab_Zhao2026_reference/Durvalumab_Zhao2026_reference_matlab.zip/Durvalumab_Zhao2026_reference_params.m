function p = Durvalumab_Zhao2026_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: durvalumab   source: Zhao_2026 / reference   route: iv_bolus
  % estimated (absent from source): F
  p.name  = 'Durvalumab_Zhao2026_reference_params';
  p.drug  = 'durvalumab';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'iv_bolus';        % 'oral' | 'iv_bolus'
  p.depot = false;             % oral -> first-order absorption depot
  p.Vc = 3.42;                % central volume [L]
  p.CL = 0.011875;                % clearance [L/h]
  p.Vp = [2.3];             % peripheral volumes [L]
  p.Q  = [0.381];             % inter-compartmental clearances [L/h]
  p.ka = 0.0;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 1500.0;             % dose [mg]
end
