model Durvalumab_Zhao2026_reference
  parameter Real Cl_ref = 3.298611111111111e-09 "Cl [m3/s]";
  parameter Real cov_albumin_0 = 0 "albumin covariate";
  parameter Real cov_sex_1 = 0 "sex covariate";
  parameter Real cov_creatinine_2 = 0 "creatinine covariate";
  parameter Real cov_sex_3 = 0 "sex covariate";
  parameter Real Vd_ref = 0.00342 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref*(1 + (-0.537)*cov_albumin_0)*(1 + (-0.143)*cov_sex_1)*(1 + (0.111)*cov_creatinine_2)*(1 + (-0.165)*cov_sex_3),
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    adminMass = 0.0015,
    k12 = 3.0945419103313844e-05,
    k21 = 4.601449275362319e-05
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About durvalumab</h4><p>Durvalumab is a monoclonal antibody that blocks the PD-L1 protein and is used to treat non-small-cell lung cancer. It is approved and authorised in the European Union, and is also being studied for other uses.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q19904005\">Wikidata Q19904005</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>durvalumab</td></tr><tr><td>population:</td><td>Patients with urothelial carcinoma, NSCLC, SCLC and other solid tumours in the pooled PopPK dataset, including patients with resectable NSCLC</td></tr><tr><td>source_paper:</td><td>Zhao_2026</td></tr><tr><td>measured_compound:</td><td>durvalumab</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>bcp70287-tbl-0003</td></tr><tr><td>input:</td><td>PK_2C: IV (no input phase)</td></tr></table><h4>Interpretation flags</h4><ul><li>table section iiv: 'ETA CL' routed out of structural estimates ('Interindividual variability')</li><li>table section iiv: 'ETA CL' routed out of structural estimates ('Interindividual variability')</li><li>table section iiv: 'ETA CL' routed out of structural estimates ('Interindividual variability')</li><li>table section iiv: 'ETA CL' routed out of structural estimates ('Interindividual variability')</li><li>table section iiv: 'Cov CL‐V1' routed out of structural estimates ('Interindividual variability')</li><li>table section iiv: 'Cov CL‐V1' routed out of structural estimates ('Interindividual variability')</li><li>table section iiv: 'Cov CL‐V1' routed out of structural estimates ('Interindividual variability')</li><li>table section iiv: 'ETA V1' routed out of structural estimates ('Interindividual variability')</li><li>table section iiv: 'ETA V1' routed out of structural estimates ('Interindividual variability')</li><li>table section iiv: 'ETA V1' routed out of structural estimates ('Interindividual variability')</li><li>table section iiv: 'ETA V1' routed out of structural estimates ('Interindividual variability')</li><li>table section iiv: 'ETA T max' routed out of structural estimates ('Interindividual variability')</li><li>table section iiv: 'ETA T max' routed out of structural estimates ('Interindividual variability')</li><li>table section iiv: 'ETA T max' routed out of structural estimates ('Interindividual variability')</li><li>table section iiv: 'ETA T max' routed out of structural estimates ('Interindividual variability')</li><li>table section residual_error: 'Proportional component' routed out of structural estimates ('Residual variability')</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 3628800, Tolerance = 1e-9, Interval = 1));
end Durvalumab_Zhao2026_reference;
