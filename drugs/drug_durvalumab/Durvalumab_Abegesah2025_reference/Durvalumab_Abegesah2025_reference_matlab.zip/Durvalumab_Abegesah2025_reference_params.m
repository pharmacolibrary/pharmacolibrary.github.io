function p = Durvalumab_Abegesah2025_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: durvalumab   source: Abegesah_2025 / reference   route: iv_bolus
  % estimated (absent from source): F
  p.name  = 'Durvalumab_Abegesah2025_reference_params';
  p.drug  = 'durvalumab';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'iv_bolus';        % 'oral' | 'iv_bolus'
  p.depot = false;             % oral -> first-order absorption depot
  p.Vc = 3.42;                % central volume [L]
  p.CL = 0.012417;                % clearance [L/h]
  p.Vp = [1.99];             % peripheral volumes [L]
  p.Q  = [0.018875];             % inter-compartmental clearances [L/h]
  p.ka = 0.0;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 7.0;             % dose [mg]
end
