function p = Irbesartan_Huang2006_PD_sbp_params()
% Irbesartan_Huang2006_PD_sbp_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% irbesartan Huang_2006::SBP: sigmoid_emax exposure-response sweep (response = E0 + Emax*frac). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one microg x ml(-1) per second, in SI inside (kg/m3, s). Response SBP in mmHg. Driver: irbesartan (cited_pk).
p.E0 = 0.0;
p.Emax = -14.8;
p.EC50 = 0.29;
p.gamma = 1.0;
p.slope = 0.0;
p.exposure_per_s = 1.0;
p.stop_time = 2.9;
p.form = 'E0 + Emax*frac';
end
