model Irbesartan_Huang2006_PD_sbp
  "sigmoid_emax exposure-response sweep — Huang_2006 :: SBP (systolic blood pressure)"
  extends Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep(
    E0 = 0,      // [1]
    Emax = -14.8,  // [mmHg]
    EC50 = 0.29,  // [microg x ml(-1)]
    gamma = 1,
    exposure_per_s = 1);   // 1 microg x ml(-1) per second
  // imax_as_negative_emax: Imax (Q323) enters SigmoidEmaxSweep as −Emax
  // exposure_unit_unresolved: 'microg x ml(-1)' — the x axis is in the paper's unit, not SI
  // defaulted: E0
  // defaulted: gamma
  annotation(experiment(StartTime = 0, StopTime = 2.9, Interval = 0.0058),
    Documentation(info = "<html><body><!-- drug-about --><h4>About irbesartan</h4><p>Irbesartan is an angiotensin II receptor blocker used to treat high blood pressure (arterial hypertension). It is an approved medicine, authorised in the European Union, and is available both alone and in combination products with diuretics or calcium channel blockers.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q947266\">Wikidata Q947266</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h4>Irbesartan_Huang2006_PD_sbp</h4><p>The steady-state exposure-response curve of Huang XH et al., <i>European journal of drug metabolism and pharmacokinetics 31(4):259–264</i> 2006 (<a href=\"https://doi.org/10.1007/BF03190465\">doi:10.1007/BF03190465</a>) — systolic blood pressure [mmHg] against irbesartan microg x ml(-1) — obtained by sweeping the driver instead of simulating a dose. Model family: sigmoid_emax.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = (library default) drug-free response (baseline)
  Emax  =       14.8 mmHg     maximal effect term (Emax, Q323)
  EC50  =       0.29 microg x ml(-1) exposure at half of the maximal effect term (EC50, Q322)
  gamma = (library default) Hill coefficient</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep\">SigmoidEmaxSweep</a>; this model only supplies the numbers. The x axis is one microg x ml(-1) of irbesartan per second of simulated time: there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0   (drug-free)
  exposure = EC50 (0.29 microg x ml(-1))  response -7.4
  exposure -> infinity  response -14.8</pre></body></html>"));
end Irbesartan_Huang2006_PD_sbp;
