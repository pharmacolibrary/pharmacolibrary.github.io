model Irbesartan_Carlucci2013_reference
  parameter Real Cl_ref = 6.805555555555556e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.1778 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.4285294,
    adminMass = 1e-05
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About irbesartan</h4><p>Irbesartan is an angiotensin II receptor blocker used to treat high blood pressure (arterial hypertension). It is an approved medicine, authorised in the European Union, and is available both alone and in combination products with diuretics or calcium channel blockers.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q947266\">Wikidata Q947266</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>irbesartan</td></tr><tr><td>population:</td><td>review reference</td></tr><tr><td>source_paper:</td><td>Carlucci_2013</td></tr><tr><td>measured_compound:</td><td>irbesartan</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>irbesartan 428.529 g/mol (drugbank)</td></tr></table><h4>Interpretation flags</h4><ul><li>built from REVIEW reference values (Carlucci_2013) — secondary source</li><li>volume reported by review</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 93600, Tolerance = 1e-9, Interval = 1));
end Irbesartan_Carlucci2013_reference;
