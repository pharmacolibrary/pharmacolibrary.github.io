function p = Irbesartan_Karatza2020_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: irbesartan   source: Karatza_2020 / reference   route: oral
  p.name  = 'Irbesartan_Karatza2020_reference_params';
  p.drug  = 'irbesartan';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 13.8;                % central volume [L]
  p.CL = 13.5;                % clearance [L/h]
  p.Vp = [85.8];             % peripheral volumes [L]
  p.Q  = [17.7];             % inter-compartmental clearances [L/h]
  p.ka = 0.304;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 150.0;             % dose [mg]
end
