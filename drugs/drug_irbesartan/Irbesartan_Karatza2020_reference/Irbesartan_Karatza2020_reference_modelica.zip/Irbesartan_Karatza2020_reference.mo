model Irbesartan_Karatza2020_reference
  parameter Real Cl_ref = 3.75e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.013800000000000002 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.4285294,
    adminMass = 0.00015,
    ka = 8.444444444444444e-05,
    Tlag = 0.0,
    k12 = 0.00035628019323671493,
    k21 = 5.7303807303807304e-05
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>irbesartan</td></tr><tr><td>population:</td><td>reference</td></tr><tr><td>source_paper:</td><td>Karatza_2020</td></tr><tr><td>measured_compound:</td><td>irbesartan</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_2C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>irbesartan 428.529 g/mol (drugbank)</td></tr></table><p><b>Defaulted (base-class default used):</b> Tlag.</p><h4>Interpretation flags</h4><ul><li>apparent-ness (ontology-grounded): parameterization=apparent, measured_compound=irbesartan</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li><li>skipped review gap-fill of TLAG: primary's parameterization (rate-constant / ka-only) does not use it</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Irbesartan_Karatza2020_reference;
