model Remimazolam_Chen2025v2_reference
  parameter Real Cl_ref = 2.2166666666666666e-05 "Cl [m3/s]";
  parameter Real Vd_ref = 0.00635 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.439313,
    adminMass = 1e-05,
    k12 = 0.0007690288713910761,
    k21 = 0.00017316784869976357
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About remimazolam</h4><p>Remimazolam is a benzodiazepine sedative used to produce conscious sedation during medical procedures. It is approved and authorised in the European Union, though it remains a relatively new agent rather than a widely established one.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q7311799\">Wikidata Q7311799</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>remimazolam</td></tr><tr><td>population:</td><td>review reference</td></tr><tr><td>source_paper:</td><td>Chen_2025_2</td></tr><tr><td>measured_compound:</td><td>remimazolam</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_2C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>remimazolam 439.313 g/mol (drugbank)</td></tr></table><h4>Interpretation flags</h4><ul><li>built from REVIEW reference values (Chen_2025_2) — secondary source</li><li>volume reported by review</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Remimazolam_Chen2025v2_reference;
