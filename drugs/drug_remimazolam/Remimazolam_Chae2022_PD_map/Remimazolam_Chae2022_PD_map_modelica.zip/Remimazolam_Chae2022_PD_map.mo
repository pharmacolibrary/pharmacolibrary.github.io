model Remimazolam_Chae2022_PD_map
  "sigmoid_emax exposure-response sweep — Chae_2022 :: MAP (Mean arterial pressure reduction)"
  extends Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep(
    E0 = 0,      // [1]
    Emax = -0.278,  // [1; % × 0.01]
    EC50 = 1.4e-07,  // [1; mg kg-1 × 1e-06]
    gamma = 1,
    exposure_per_s = 1e-06);   // 1 mg kg-1 per second
  // imax_as_negative_emax: Imax (Q323) enters SigmoidEmaxSweep as −Emax
  // defaulted: E0
  // defaulted: gamma
  annotation(experiment(StartTime = 0, StopTime = 1.4, Interval = 0.0028),
    Documentation(info = "<html><body><!-- drug-about --><h4>About remimazolam</h4><p>Remimazolam is a benzodiazepine sedative used to produce conscious sedation during medical procedures. It is approved and authorised in the European Union, though it remains a relatively new agent rather than a widely established one.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q7311799\">Wikidata Q7311799</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h4>Remimazolam_Chae2022_PD_map</h4><p>The steady-state exposure-response curve of Chae D et al., <i>British journal of anaesthesia 129(1):49–57</i> 2022 (<a href=\"https://doi.org/10.1016/j.bja.2022.02.040\">doi:10.1016/j.bja.2022.02.040</a>) — Mean arterial pressure reduction [%] against remimazolam mg kg-1 — obtained by sweeping the driver instead of simulating a dose. Model family: sigmoid_emax.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = (library default) drug-free response (baseline)
  Emax  =       27.8 %        maximal effect term (Maximum percentage reduction of MAP, Q323)
  EC50  =       0.14 mg kg-1  exposure at half of the maximal effect term (ED50, Q321)
  gamma = (library default) Hill coefficient</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep\">SigmoidEmaxSweep</a>; this model only supplies the numbers. The x axis is one mg kg-1 of remimazolam per second of simulated time: there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0   (drug-free)
  exposure = EC50 (0.14 mg kg-1)  response -0.139
  exposure -> infinity  response -0.278</pre></body></html>"));
end Remimazolam_Chae2022_PD_map;
