function p = Remimazolam_Chae2022_PD_map_params()
% Remimazolam_Chae2022_PD_map_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% remimazolam Chae_2022::MAP: sigmoid_emax exposure-response sweep (response = E0 + Emax*frac). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one mg kg-1 per second, in SI inside (kg/m3, s). Response MAP in %. Driver: remimazolam (dose_only).
p.E0 = 0.0;
p.Emax = -0.278;
p.EC50 = 1.4e-07;
p.gamma = 1.0;
p.slope = 0.0;
p.exposure_per_s = 1e-06;
p.stop_time = 1.4;
p.form = 'E0 + Emax*frac';
end
