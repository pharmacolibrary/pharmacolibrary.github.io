function p = Remimazolam_Oh2025_PD_mbp_params()
% Remimazolam_Oh2025_PD_mbp_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% remimazolam Oh_2025::MBP: sigmoid_emax exposure-response sweep (response = E0 + Emax*frac). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one mg (cumulative dose) per second, in SI inside (kg/m3, s). Response MBP in %. Driver: remimazolam (dose_only).
p.E0 = 0.0;
p.Emax = -0.4123;
p.EC50 = 18.6;
p.gamma = 5.92;
p.slope = 0.0;
p.exposure_per_s = 1.0;
p.stop_time = 190.0;
p.form = 'E0 + Emax*frac';
end
