model Remimazolam_Oh2025_PD_mbp
  "sigmoid_emax exposure-response sweep — Oh_2025 :: MBP (fractional mean blood pressure)"
  extends Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep(
    E0 = 0,      // [1]
    Emax = -0.4123,  // [1; % × 0.01]
    EC50 = 18.6,  // [mg (cumulative dose)]
    gamma = 5.92,
    exposure_per_s = 1);   // 1 mg (cumulative dose) per second
  // imax_as_negative_emax: Imax (Q323) enters SigmoidEmaxSweep as −Emax
  // exposure_unit_unresolved: 'mg (cumulative dose)' — the x axis is in the paper's unit, not SI
  // defaulted: E0
  annotation(experiment(StartTime = 0, StopTime = 190, Interval = 0.38),
    Documentation(info = "<html><body><!-- drug-about --><h4>About remimazolam</h4><p>Remimazolam is a benzodiazepine sedative used to produce conscious sedation during medical procedures. It is approved and authorised in the European Union, though it remains a relatively new agent rather than a widely established one.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q7311799\">Wikidata Q7311799</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h4>Remimazolam_Oh2025_PD_mbp</h4><p>The steady-state exposure-response curve of Oh J et al., <i>Drug design, development and therapy 19:9571–9580</i> 2025 (<a href=\"https://doi.org/10.2147/DDDT.S553809\">doi:10.2147/DDDT.S553809</a>) — fractional mean blood pressure [%] against remimazolam mg (cumulative dose) — obtained by sweeping the driver instead of simulating a dose. Model family: sigmoid_emax.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = (library default) drug-free response (baseline)
  Emax  =      41.23 %        maximal effect term (horizontal asymptote range intercept, Q323)
  EC50  =       18.6 mg (cumulative dose) exposure at half of the maximal effect term (inflection point intercept, Q321)
  gamma =       5.92          Hill coefficient (scale parameter (steepness), Q325)</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep\">SigmoidEmaxSweep</a>; this model only supplies the numbers. The x axis is one mg (cumulative dose) of remimazolam per second of simulated time: there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0   (drug-free)
  exposure = EC50 (18.6 mg (cumulative dose))  response -0.2061
  exposure -> infinity  response -0.4123</pre></body></html>"));
end Remimazolam_Oh2025_PD_mbp;
