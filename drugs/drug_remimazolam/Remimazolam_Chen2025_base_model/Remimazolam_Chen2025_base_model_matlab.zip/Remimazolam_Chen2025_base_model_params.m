function p = Remimazolam_Chen2025_base_model_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: remimazolam   source: Chen_2025 / base_model   route: iv_bolus
  % estimated (absent from source): F, dose
  p.name  = 'Remimazolam_Chen2025_base_model_params';
  p.drug  = 'remimazolam';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'iv_bolus';        % 'oral' | 'iv_bolus'
  p.depot = false;             % oral -> first-order absorption depot
  p.Vc = 25.5;                % central volume [L]
  p.CL = 58.2;                % clearance [L/h]
  p.Vp = [34.5];             % peripheral volumes [L]
  p.Q  = [20.0];             % inter-compartmental clearances [L/h]
  p.ka = 0.0;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 10.0;             % dose [mg]
end
