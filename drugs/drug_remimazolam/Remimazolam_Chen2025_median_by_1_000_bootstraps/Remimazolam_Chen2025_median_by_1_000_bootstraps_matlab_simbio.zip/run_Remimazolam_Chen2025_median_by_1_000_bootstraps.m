% Run (SimBiology): build model + dose, simulate 0..24.0 h, plot.
p = Remimazolam_Chen2025_median_by_1_000_bootstraps_params();
[model, dose, variant] = build_sb_pk(p);
sd = simulate_sb(model, variant, dose, 24.0);
