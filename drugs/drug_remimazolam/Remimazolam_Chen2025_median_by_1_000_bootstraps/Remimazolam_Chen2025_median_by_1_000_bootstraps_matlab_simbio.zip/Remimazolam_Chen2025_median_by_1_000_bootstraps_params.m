function p = Remimazolam_Chen2025_median_by_1_000_bootstraps_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: remimazolam   source: Chen_2025 / median_by_1_000_bootstraps   route: iv_bolus
  % estimated (absent from source): F, dose
  p.name  = 'Remimazolam_Chen2025_median_by_1_000_bootstraps_params';
  p.drug  = 'remimazolam';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'iv_bolus';        % 'oral' | 'iv_bolus'
  p.depot = false;             % oral -> first-order absorption depot
  p.Vc = 25.2;                % central volume [L]
  p.CL = 58.7;                % clearance [L/h]
  p.Vp = [37.5];             % peripheral volumes [L]
  p.Q  = [21.9];             % inter-compartmental clearances [L/h]
  p.ka = 0.0;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 10.0;             % dose [mg]
end
