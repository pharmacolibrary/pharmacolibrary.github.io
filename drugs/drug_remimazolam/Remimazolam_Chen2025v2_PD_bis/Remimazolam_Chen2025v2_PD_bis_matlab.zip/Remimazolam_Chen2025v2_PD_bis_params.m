function p = Remimazolam_Chen2025v2_PD_bis_params()
% Remimazolam_Chen2025v2_PD_bis_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% remimazolam Chen_2025_2::BIS: sigmoid_emax exposure-response sweep (response = E0 + Emax*frac). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one ng/mL per second, in SI inside (kg/m3, s). Response BIS in its own unit. Driver: remimazolam (pk_record).
p.E0 = 91.9;
p.Emax = -80.7;
p.EC50 = 0.0008089999999999999;
p.gamma = 1.65;
p.slope = 0.0;
p.exposure_per_s = 1e-06;
p.stop_time = 8100.0;
p.form = 'E0 + Emax*frac';
end
