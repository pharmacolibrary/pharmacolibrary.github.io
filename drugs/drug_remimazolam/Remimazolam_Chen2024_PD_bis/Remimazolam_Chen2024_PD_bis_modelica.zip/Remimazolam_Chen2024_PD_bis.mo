model Remimazolam_Chen2024_PD_bis
  "sigmoid_emax exposure-response sweep — Chen_2024 :: BIS (bispectral index)"
  extends Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep(
    E0 = 92.5,      // [1]
    Emax = -54.5,  // [1]
    EC50 = 0.000504,  // [kg/m3; ng/mL × 1e-06]
    gamma = 1.44,
    exposure_per_s = 1e-06);   // 1 ng/mL per second
  // imax_as_negative_emax: Imax (Q323) enters SigmoidEmaxSweep as −Emax
  annotation(experiment(StartTime = 0, StopTime = 5100, Interval = 10.2),
    Documentation(info = "<html><body><!-- drug-about --><h4>About remimazolam</h4><p>Remimazolam is a benzodiazepine sedative used to produce conscious sedation during medical procedures. It is approved and authorised in the European Union, though it remains a relatively new agent rather than a widely established one.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q7311799\">Wikidata Q7311799</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h4>Remimazolam_Chen2024_PD_bis</h4><p>The steady-state exposure-response curve of Chen Y et al., <i>Pharmaceutics 16(9)</i> 2024 (<a href=\"https://doi.org/10.3390/pharmaceutics16091122\">doi:10.3390/pharmaceutics16091122</a>) — bispectral index against remimazolam ng/mL — obtained by sweeping the driver instead of simulating a dose. Model family: sigmoid_emax.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    =       92.5          drug-free response (baseline) (BIS_baseline, Q324)
  Emax  =       54.5          maximal effect term (Imax, Q323)
  EC50  =        504 ng/mL    exposure at half of the maximal effect term (IC50, Q322)
  gamma =       1.44          Hill coefficient (Hill coefficient, Q325)</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep\">SigmoidEmaxSweep</a>; this model only supplies the numbers. The x axis is one ng/mL of remimazolam per second of simulated time (exposure is in kg/m3): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 92.5   (drug-free)
  exposure = EC50 (504 ng/mL)  response 65.25
  exposure -> infinity  response 38</pre></body></html>"));
end Remimazolam_Chen2024_PD_bis;
