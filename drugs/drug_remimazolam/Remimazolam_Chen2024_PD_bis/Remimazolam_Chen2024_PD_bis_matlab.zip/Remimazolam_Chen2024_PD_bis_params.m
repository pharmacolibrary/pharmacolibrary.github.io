function p = Remimazolam_Chen2024_PD_bis_params()
% Remimazolam_Chen2024_PD_bis_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% remimazolam Chen_2024::BIS: sigmoid_emax exposure-response sweep (response = E0 + Emax*frac). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one ng/mL per second, in SI inside (kg/m3, s). Response BIS in its own unit. Driver: remimazolam (pk_record).
p.E0 = 92.5;
p.Emax = -54.5;
p.EC50 = 0.000504;
p.gamma = 1.44;
p.slope = 0.0;
p.exposure_per_s = 1e-06;
p.stop_time = 5100.0;
p.form = 'E0 + Emax*frac';
end
