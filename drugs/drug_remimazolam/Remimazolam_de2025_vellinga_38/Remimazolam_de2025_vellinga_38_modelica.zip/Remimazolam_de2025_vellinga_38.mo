model Remimazolam_de2025_vellinga_38
  parameter Real Cl_ref = 2.0833333333333333e-05 "Cl [m3/s]";
  parameter Real Vd_ref = 0.00536 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.439313,
    adminMass = 2.5e-06
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About remimazolam</h4><p>Remimazolam is a benzodiazepine sedative used to produce conscious sedation during medical procedures. It is approved and authorised in the European Union, though it remains a relatively new agent rather than a widely established one.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q7311799\">Wikidata Q7311799</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>remimazolam</td></tr><tr><td>population:</td><td>mixed healthy volunteers and surgical/ICU patients (narrative review of popPK models)</td></tr><tr><td>source_paper:</td><td>de_2025</td></tr><tr><td>measured_compound:</td><td>remimazolam</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>Tab2</td></tr><tr><td>input:</td><td>PK_1C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>CNS7054 425.286 g/mol (pubchem); remimazolam 439.313 g/mol (drugbank)</td></tr></table><h4>Interpretation flags</h4><ul><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=remimazolam</li><li>template fit: PK_3M_9C — formed from central; parent 3, metabolites [0]</li><li>population split: 'vellinga (2024) [38]' subgroup of de_2025 (paper reports 2 populations: study (year), vellinga (2024) [38])</li><li>row roles (LLM): model_class=compartmental; 6/6 row label(s) assigned, 9 linked by role</li><li>engineer: parent → metabolite not buildable on PK_3M_9C (None) — the measured compound's 1-compartment model instead</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Remimazolam_de2025_vellinga_38;
