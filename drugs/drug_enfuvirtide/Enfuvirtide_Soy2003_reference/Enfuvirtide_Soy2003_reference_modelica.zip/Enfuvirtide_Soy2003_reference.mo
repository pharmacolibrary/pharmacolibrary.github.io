model Enfuvirtide_Soy2003_reference
  parameter Real Cl_ref = 3.9444444444444444e-07 "Cl [m3/s]";
  parameter Real Vd_ref = 0.00567 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 0.9,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 4.491944999999999,
    adminMass = 0.0001,
    ka = 0.00012638888888888888,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About enfuvirtide</h4><p>Enfuvirtide is an antiviral drug used to treat HIV infection and HIV/AIDS. It is an approved medicine and is authorised in the European Union for HIV infections.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q423327\">Wikidata Q423327</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>enfuvirtide</td></tr><tr><td>population:</td><td>pediatric patients with human immunodeficiency virus</td></tr><tr><td>source_paper:</td><td>Soy_2003</td></tr><tr><td>measured_compound:</td><td>enfuvirtide</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>enfuvirtide 4491.94 g/mol (pubchem)</td></tr></table><p><b>Defaulted (base-class default used):</b> F, Tlag.</p><h4>Interpretation flags</h4><ul><li>dropped unlinked row (NIL): 'mean body weight' — extend the ontology if this is a real PK parameter (source ['Soy_2003:abstract'])</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=enfuvirtide</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li><li>gap-filled Q49 (kabs) from Brochot_2015's review values (primary lacked it)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Enfuvirtide_Soy2003_reference;
