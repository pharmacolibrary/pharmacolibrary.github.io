function p = Secukinumab_RodriguezFernandez2024_PD_pasi_params()
% Secukinumab_RodriguezFernandez2024_PD_pasi_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% secukinumab Rodriguez-Fernandez_2024::PASI: indirect_response_i exposure-response sweep (response = E0/(1 + Emax*frac)). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one mg/L per second, in SI inside (kg/m3, s). Response PASI in no units. Driver: secukinumab (cited_pk).
p.E0 = 0.0;
p.Emax = 1.19;
p.EC50 = 0.009349999999999997;
p.gamma = 1.0;
p.slope = 0.0;
p.exposure_per_s = 0.001;
p.stop_time = 94.0;
p.form = 'E0/(1 + Emax*frac)';
end
