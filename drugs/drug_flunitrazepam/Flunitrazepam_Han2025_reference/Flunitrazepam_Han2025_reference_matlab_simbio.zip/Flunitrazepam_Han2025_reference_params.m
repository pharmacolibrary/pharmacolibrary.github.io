function p = Flunitrazepam_Han2025_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: flunitrazepam   source: Han_2025 / reference   route: iv_bolus
  % estimated (absent from source): F
  p.name  = 'Flunitrazepam_Han2025_reference_params';
  p.drug  = 'flunitrazepam';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'iv_bolus';        % 'oral' | 'iv_bolus'
  p.depot = false;             % oral -> first-order absorption depot
  p.Vc = 2.73;                % central volume [L]
  p.CL = 0.06;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.0;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 1.0;             % dose [mg]
end
