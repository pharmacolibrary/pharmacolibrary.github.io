model Flunitrazepam_GmezSegura2022_reference
  parameter Real Cl_ref = 7.083333333333334e-08 "Cl [m3/s]";
  parameter Real Vd_ref = 0.023030000000000002 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.31328320000000004,
    adminMass = 1e-06
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About flunitrazepam</h4><p>Flunitrazepam is a benzodiazepine sedative used as a hypnotic for insomnia and as an anxiolytic. It remains an approved medicine in some countries but is tightly controlled, and its misuse as an illicit drug has led to restrictions or withdrawal in many places.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q62947\">Wikidata Q62947</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>flunitrazepam</td></tr><tr><td>population:</td><td>review reference</td></tr><tr><td>source_paper:</td><td>Gómez-Segura_2022</td></tr><tr><td>measured_compound:</td><td>flunitrazepam</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>flunitrazepam 313.283 g/mol (drugbank)</td></tr></table><h4>Interpretation flags</h4><ul><li>built from REVIEW reference values (Gómez-Segura_2022) — secondary source</li><li>volume reported by review</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 1209600, Tolerance = 1e-9, Interval = 1));
end Flunitrazepam_GmezSegura2022_reference;
