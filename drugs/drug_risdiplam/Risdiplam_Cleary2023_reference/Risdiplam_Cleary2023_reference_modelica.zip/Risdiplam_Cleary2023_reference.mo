model Risdiplam_Cleary2023_reference
  parameter Real Cl_ref = 7.333333333333333e-07 "Cl [m3/s]";
  parameter Real cov_wt_0 = 0 "wt covariate";
  parameter Real Vd_ref = 0.098 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref*(1 + (0.276)*cov_wt_0),
    Vd = Vd_ref*(1 + (0.86)*cov_wt_0),
    adminDuration = 600,
    adminCount = 1,
    MM = 0.401474,
    adminMass = 1.4e-05,
    ka = 0.0014388888888888889,
    Tlag = 0.0,
    k12 = 1.933106575963719e-06,
    k21 = 2.039229757206076e-06
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About risdiplam</h4><p>Risdiplam is a medicine used to treat spinal muscular atrophy. It is authorised in the European Union.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q48969152\">Wikidata Q48969152</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>risdiplam</td></tr><tr><td>population:</td><td>SMA patients and healthy subjects</td></tr><tr><td>source_paper:</td><td>Cleary_2023</td></tr><tr><td>measured_compound:</td><td>risdiplam</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>Tab2</td></tr><tr><td>input:</td><td>PK_2C_enteral: transit-compartment absorption reported; transit absorption (ktr=0.001439/s, n=0) folded to first-order ka = ktr/(n+1) = 0.001439/s — same mean absorption time, no delay phase</td></tr><tr><td>molar_masses:</td><td>risdiplam 401.474 g/mol (drugbank)</td></tr></table><p><b>Defaulted (base-class default used):</b> Tlag.</p><h4>Interpretation flags</h4><ul><li>column 'unit' classified 'other' by the LLM but kept: the deterministic diagnostic-column test disagrees (a stratum column is a value column, not a statistic)</li><li>covariate level 'Effect of WT on CL/F and Q/F' → Q900:effect_of_wt_on_cl_f_and_q_f = 0.276 (linear_fractional on Q27)</li><li>dropped duplicate Q27 ('Age50—CL/F', value '0.877') — already have one for this compound</li><li>routed 'Age50—Vc/F' → Q314 (omega_cov) to covariance — variability estimate, not a structural parameter</li><li>dropped duplicate Q27 ('Healthy subjects on CL/F', value '0.524') — already have one for this compound</li><li>dropped value-less row: 'CL/F (CV)' (captured trailing unit 'CV' for child rows)</li><li>dropped value-less row: 'ktr (CV)' (captured trailing unit 'CV' for child rows)</li><li>dropped value-less row: 'Vc/F (CV)' (captured trailing unit 'CV' for child rows)</li><li>NIL: refused to back-fill base 'Cmax' from footnote/prose loose number None (source ['Tab2:footnote']); the table cell was unparseable — needs review</li><li>NIL: refused to back-fill base 'allometric_exponent' from footnote/prose loose number None (source ['Tab2:footnote']); the table cell was unparseable — needs review</li><li>implicit units: 'CL/F' → L/h (from the popPK convention: 'The paper describes CL/F as apparent clearance (hepatic clearance). While Table 2 is not fully provided in the excerpt, ')</li><li>implicit units: 'ktr' → 1/h (from the popPK convention: 'ktr is a first-order transit rate constant. By definition, first-order rate constants have units of inverse time (1/h). ')</li><li>implicit units: 'Vc/F' → L (from the popPK convention: 'Vc/F is the apparent volume of distribution of the central compartment. The text notes Vss = 4.2 L/kg, implying Vc/F wou')</li><li>implicit units: 'Q/F' → L/h (from the popPK convention: 'Q/F is the apparent intercompartmental clearance. By convention, intercompartmental clearances are expressed in L/h. The')</li><li>implicit units: 'Vp/F' → L (from the popPK convention: 'Vp/F is the apparent volume of distribution of the peripheral compartment. Similar to Vc/F, the value 92.9 is consistent')</li><li>apparent-ness (ontology-grounded): parameterization=apparent, measured_compound=risdiplam</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 518400, Tolerance = 1e-9, Interval = 1));
end Risdiplam_Cleary2023_reference;
