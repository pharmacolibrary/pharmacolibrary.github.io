model Pyridostigmine_Thakkar2017_reference
  parameter Real Cl_ref = 2.4999999999999998e-05 "Cl [m3/s]";
  parameter Real Vd_ref = 0.024 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.1812117,
    adminMass = 0.00018,
    ka = 0.00025,
    Tlag = 0.0,
    k12 = 0.0012847222222222223
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About pyridostigmine</h4><p>Pyridostigmine is a medication used to treat myasthenia gravis. It is an acetylcholinesterase inhibitor included on the WHO list of essential medicines and is approved, so it remains in widespread use.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q419472\">Wikidata Q419472</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>pyridostigmine</td></tr><tr><td>population:</td><td>review reference</td></tr><tr><td>source_paper:</td><td>Thakkar_2017</td></tr><tr><td>measured_compound:</td><td>pyridostigmine</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_2C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>pyridostigmine 181.212 g/mol (drugbank)</td></tr></table><p><b>Defaulted (base-class default used):</b> Tlag, k21.</p><h4>Interpretation flags</h4><ul><li>built from REVIEW reference values (Thakkar_2017) — secondary source</li><li>volume reported by review</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Pyridostigmine_Thakkar2017_reference;
