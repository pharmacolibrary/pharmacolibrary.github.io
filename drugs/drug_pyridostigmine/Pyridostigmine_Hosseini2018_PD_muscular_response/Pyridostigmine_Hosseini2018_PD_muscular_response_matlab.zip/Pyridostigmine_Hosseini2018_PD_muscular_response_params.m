function p = Pyridostigmine_Hosseini2018_PD_muscular_response_params()
% Pyridostigmine_Hosseini2018_PD_muscular_response_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% pyridostigmine Hosseini_2018::muscular_response: indirect_response_ii exposure-response sweep (response = E0/(1 - Emax*frac)). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one μg/mL per second, in SI inside (kg/m3, s). Response muscular response in % gain. Driver: pyridostigmine (pk_record).
p.E0 = 58.61042183622829;
p.Emax = 1.0;
p.EC50 = 2.8999999999999997e-05;
p.gamma = 1.0;
p.slope = 0.0;
p.exposure_per_s = 0.001;
p.stop_time = 0.29;
p.form = 'E0/(1 - Emax*frac)';
end
