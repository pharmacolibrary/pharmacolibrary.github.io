model Pyridostigmine_Seng2009_reference
  parameter Real Cl_ref = 3.777777777777778e-05 "Cl [m3/s]";
  parameter Real Vd_ref = 0.13 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.1812117,
    adminMass = 0.00018,
    ka = 0.0001888888888888889,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About pyridostigmine</h4><p>Pyridostigmine is a medication used to treat myasthenia gravis. It is an acetylcholinesterase inhibitor included on the WHO list of essential medicines and is approved, so it remains in widespread use.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q419472\">Wikidata Q419472</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>pyridostigmine</td></tr><tr><td>population:</td><td>healthy Chinese males</td></tr><tr><td>source_paper:</td><td>Seng_2009</td></tr><tr><td>measured_compound:</td><td>pyridostigmine</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>pyridostigmine 181.212 g/mol (drugbank)</td></tr></table><p><b>Defaulted (base-class default used):</b> Tlag.</p><h4>Interpretation flags</h4><ul><li>unit_dimension_unknown: 'AChE units per gram haemoglobin' (E)</li><li>dropped PD-category row 'EC50' → Q321 (EC50, category G11) — pharmacodynamic parameters belong to scholarpd, not the PK model (source ['Seng_2009:abstract'])</li><li>apparent-ness (ontology-grounded): parameterization=apparent, measured_compound=pyridostigmine</li><li>held at status:extracted — NIL link or unit issue (mismatch/unknown/normalisation-failed) present</li><li>status held at route_to_review — not promoted</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of TLAG: primary's parameterization (rate-constant / ka-only) does not use it</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Pyridostigmine_Seng2009_reference;
