function p = Pyridostigmine_Seng2009_PD_ache_params()
% Pyridostigmine_Seng2009_PD_ache_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% pyridostigmine Seng_2009::AChE: emax exposure-response sweep (response = E0 + Emax*frac). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one ng/ml per second, in SI inside (kg/m3, s). Response AChE in AChE units per gram haemoglobin. Driver: pyridostigmine (pk_record).
p.E0 = 0.0;
p.Emax = -9.32;
p.EC50 = 5.1899999999999994e-05;
p.gamma = 1.0;
p.slope = 0.0;
p.exposure_per_s = 1e-06;
p.stop_time = 520.0;
p.form = 'E0 + Emax*frac';
end
