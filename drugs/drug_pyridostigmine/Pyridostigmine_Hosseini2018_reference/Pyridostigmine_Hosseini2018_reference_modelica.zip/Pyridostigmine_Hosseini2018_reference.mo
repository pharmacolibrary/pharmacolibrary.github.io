model Pyridostigmine_Hosseini2018_reference
  parameter Real Cl_ref = 5.590277777777778e-09 "Cl [m3/s]";
  parameter Real Vd_ref = 0.005634999999999999 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.1812117,
    adminMass = 1e-05
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About pyridostigmine</h4><p>Pyridostigmine is a medication used to treat myasthenia gravis. It is an acetylcholinesterase inhibitor included on the WHO list of essential medicines and is approved, so it remains in widespread use.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q419472\">Wikidata Q419472</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>pyridostigmine</td></tr><tr><td>population:</td><td>review reference</td></tr><tr><td>source_paper:</td><td>Hosseini_2018</td></tr><tr><td>measured_compound:</td><td>pyridostigmine</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>pyridostigmine 181.212 g/mol (drugbank)</td></tr></table><h4>Interpretation flags</h4><ul><li>built from REVIEW reference values (Hosseini_2018) — secondary source</li><li>volume reported by review</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 3628800, Tolerance = 1e-9, Interval = 1));
end Pyridostigmine_Hosseini2018_reference;
