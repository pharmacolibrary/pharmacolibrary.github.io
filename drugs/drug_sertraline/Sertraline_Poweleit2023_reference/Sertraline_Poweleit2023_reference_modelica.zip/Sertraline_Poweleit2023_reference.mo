model Sertraline_Poweleit2023_reference
  parameter Real Cl_ref = 3.944444444444444e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.428 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.30623,
    adminMass = 5e-05,
    ka = 0.0001388888888888889,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About sertraline</h4><p>Sertraline is an antidepressant used for depression and several anxiety-related conditions, including obsessive-compulsive disorder, panic disorder, and post-traumatic stress disorder. It is an approved, widely used selective serotonin reuptake inhibitor.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q407617\">Wikidata Q407617</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>sertraline</td></tr><tr><td>population:</td><td>psychiatrically hospitalized pediatric patients aged 5-18 years</td></tr><tr><td>source_paper:</td><td>Poweleit_2023</td></tr><tr><td>measured_compound:</td><td>sertraline</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C_enteral: apparent (/F) parameterization ⇒ extravascular dosing</td></tr><tr><td>molar_masses:</td><td>sertraline 306.23 g/mol (drugbank)</td></tr></table><p><b>Defaulted (base-class default used):</b> ka, Tlag.</p><h4>Interpretation flags</h4><ul><li>unit_dimension_unknown: 'L/h/1.73 m2' (CL/F)</li><li>unit_dimension_unknown: 'L/1.73 m2' (V/F)</li><li>dropped duplicate Q27 ('CL/F (sertraline)', value 124) — already have one for this compound</li><li>dropped duplicate Q76 ('V/F (sertraline)', value 4320) — already have one for this compound</li><li>covariate cyp2c19 for Ctrough from footnote/prose kept as documentation only (['Poweleit_2023:abstract'])</li><li>covariate normal metabolizer for Ctrough from footnote/prose kept as documentation only (['Poweleit_2023:abstract'])</li><li>covariate normal metabolizer for AUC ratio from footnote/prose kept as documentation only (['Poweleit_2023:abstract'])</li><li>dropped value-less row: 'p (escitalopram)' (captured trailing unit 'escitalopram' for child rows)</li><li>covariate cyp2c19 for Ctrough from footnote/prose kept as documentation only (['Poweleit_2023:abstract'])</li><li>covariate ultrarapid metabolizer for Ctrough from footnote/prose kept as documentation only (['Poweleit_2023:abstract'])</li><li>covariate ultrarapid metabolizer for AUC ratio from footnote/prose kept as documentation only (['Poweleit_2023:abstract'])</li><li>dropped value-less row: 'p (sertraline)' (captured trailing unit 'sertraline' for child rows)</li><li>dropped value-less row: 'dose reduction (escitalopram, poor metabolizers)'</li><li>dropped value-less row: 'dose reduction (sertraline, poor metabolizers)'</li><li>dropped unlinked row (NIL): 'escitalopram cohort samples' — extend the ontology if this is a real PK parameter (source ['Poweleit_2023:abstract'])</li><li>dropped unlinked row (NIL): 'escitalopram cohort patients' — extend the ontology if this is a real PK parameter (source ['Poweleit_2023:abstract'])</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 432000, Tolerance = 1e-9, Interval = 1));
end Sertraline_Poweleit2023_reference;
