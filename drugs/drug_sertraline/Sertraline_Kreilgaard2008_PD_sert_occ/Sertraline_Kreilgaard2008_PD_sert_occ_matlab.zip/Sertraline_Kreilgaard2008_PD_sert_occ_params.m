function p = Sertraline_Kreilgaard2008_PD_sert_occ_params()
% Sertraline_Kreilgaard2008_PD_sert_occ_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% sertraline Kreilgaard_2008::SERT_occ: sigmoid_emax exposure-response sweep (response = E0 + Emax*frac). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one ng mL À1 per second, in SI inside (kg/m3, s). Response SERT occ in %. Driver: sertraline (cited_pk).
p.E0 = 0.0;
p.Emax = -1.0;
p.EC50 = 7.099999999999999e-06;
p.gamma = 1.2;
p.slope = 0.0;
p.exposure_per_s = 1e-06;
p.stop_time = 71.0;
p.form = 'E0 + Emax*frac';
end
