model Sertraline_Kreilgaard2008_PD_sert_occ
  "sigmoid_emax exposure-response sweep — Kreilgaard_2008 :: SERT occ (SERT occupancy)"
  extends Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep(
    E0 = 0,      // [1]
    Emax = -1,  // [1; % × 0.01]
    EC50 = 7.1e-06,  // [kg/m3; ng mL À1 × 1e-06]
    gamma = 1.2,
    exposure_per_s = 1e-06);   // 1 ng mL À1 per second
  // imax_as_negative_emax: Imax (Q323) enters SigmoidEmaxSweep as −Emax
  // defaulted: E0
  annotation(experiment(StartTime = 0, StopTime = 71, Interval = 0.142),
    Documentation(info = "<html><body><!-- drug-about --><h4>About sertraline</h4><p>Sertraline is an antidepressant used for depression and several anxiety-related conditions, including obsessive-compulsive disorder, panic disorder, and post-traumatic stress disorder. It is an approved, widely used selective serotonin reuptake inhibitor.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q407617\">Wikidata Q407617</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h4>Sertraline_Kreilgaard2008_PD_sert_occ</h4><p>The steady-state exposure-response curve of Kreilgaard M et al., <i>British journal of pharmacology 155(2):276–284</i> 2008 (<a href=\"https://doi.org/10.1038/bjp.2008.243\">doi:10.1038/bjp.2008.243</a>) — SERT occupancy [%] against sertraline ng mL À1 — obtained by sweeping the driver instead of simulating a dose. Model family: sigmoid_emax.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = (library default) drug-free response (baseline)
  Emax  =        100 %        maximal effect term (Emax, Q323)
  EC50  =        7.1 ng mL À1 exposure at half of the maximal effect term (EC50, Q321)
  gamma =        1.2          Hill coefficient (Hill coefficient, Q325)</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep\">SigmoidEmaxSweep</a>; this model only supplies the numbers. The x axis is one ng mL À1 of sertraline per second of simulated time (exposure is in kg/m3): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0   (drug-free)
  exposure = EC50 (7.1 ng mL À1)  response -0.5
  exposure -> infinity  response -1</pre></body></html>"));
end Sertraline_Kreilgaard2008_PD_sert_occ;
