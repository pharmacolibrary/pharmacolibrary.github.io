function p = Sertraline_Kreilgaard2008_PD_5_htp_score_params()
% Sertraline_Kreilgaard2008_PD_5_htp_score_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% sertraline Kreilgaard_2008::5_HTP_score: sigmoid_emax exposure-response sweep (response = E0 + Emax*frac). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one ng mL À1 per second, in SI inside (kg/m3, s). Response 5-HTP score in its own unit. Driver: sertraline (cited_pk).
p.E0 = 0.0;
p.Emax = 1.0;
p.EC50 = 7.999999999999999e-05;
p.gamma = 1.0;
p.slope = 0.0;
p.exposure_per_s = 1e-06;
p.stop_time = 800.0;
p.form = 'E0 + Emax*frac';
end
