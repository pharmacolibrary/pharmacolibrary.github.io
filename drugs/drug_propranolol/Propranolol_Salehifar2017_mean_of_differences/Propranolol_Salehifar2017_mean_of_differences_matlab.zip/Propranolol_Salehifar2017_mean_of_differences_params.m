function p = Propranolol_Salehifar2017_mean_of_differences_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: propranolol   source: Salehifar_2017 / mean_of_differences   route: iv_bolus
  % estimated (absent from source): F
  p.name  = 'Propranolol_Salehifar2017_mean_of_differences_params';
  p.drug  = 'propranolol';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'iv_bolus';        % 'oral' | 'iv_bolus'
  p.depot = false;             % oral -> first-order absorption depot
  p.Vc = 57.4;                % central volume [L]
  p.CL = 70.7;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.0;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 40.0;             % dose [mg]
end
