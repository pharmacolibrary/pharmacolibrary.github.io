// general-linear (2 compartments) — non-mammillary/4C+; central↔peripheral
// edges with clearance Qj; topology flagged for reviewer confirmation.
model Propranolol_Marques2026_reference
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_General_Linear(
    nComp = 2, centralIdx = 1, F = 1,
    V = {0.01207, 0.00927},
    CLelim = {8.036111111111111e-06, 0.0},
    nEdge = 2,
    edge = {{1, 2}, {2, 1}},
    CLedge = {2.9722222222222224e-07, 2.9722222222222224e-07}
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About propranolol</h4><p>Propranolol is a non-selective beta blocker used for conditions such as high blood pressure, angina, heart rhythm problems, migraine, anxiety, essential tremor, and infantile hemangioma. It remains widely used, is listed among WHO essential medicines, and is authorised in the European Union, where an approved product is indicated for hemangioma.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q423364\">Wikidata Q423364</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>propranolol</td></tr><tr><td>population:</td><td>virtual patients</td></tr><tr><td>source_paper:</td><td>Marques_2026</td></tr><tr><td>measured_compound:</td><td>propranolol</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>general_linear</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>pharmaceutics-18-00636-t008</td></tr><tr><td>molar_masses:</td><td>hydroxy-omeprazole 361.416 g/mol (pubchem); omeprazole 345.417 g/mol (pubchem); omeprazole sulphone 361.416 g/mol (pubchem); propranolol 259.343 g/mol (drugbank)</td></tr></table><h4>Interpretation flags</h4><ul><li>apparent-by-design (ADVISORY, codes unchanged): extravascular dosing with no identifiable F, so these reported disposition parameters are likely apparent unless the model puts first-pass in its structure — Q63 (V1 (L)); Q30 (Q (L/h)); Q64 (V2 (L)); Q22 (Cl (L/h))</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=propranolol</li><li>topology: 2 first-order transfer(s) across 4 compounds → general_linear</li><li>template fit: PK_3M_9C — formed from central; parent 2, metabolites [0, 0]</li><li>row roles (LLM): model_class=compartmental; 10/10 row label(s) assigned, 10 linked by role</li><li>skipped review gap-fill of TLAG: primary's parameterization (rate-constant / ka-only) does not use it</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Propranolol_Marques2026_reference;
