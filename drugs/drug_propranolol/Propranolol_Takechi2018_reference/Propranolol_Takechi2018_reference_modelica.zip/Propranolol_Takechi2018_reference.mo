model Propranolol_Takechi2018_reference
  parameter Real Cl_ref = 2.594444444444444e-06 "Cl [m3/s]";
  parameter Real cov_age_0 = 0 "age covariate";
  parameter Real cov_age = 1.0 "age covariate (reference 1.0)";
  parameter Real Vd_ref = 0.146 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref*(1 + (0.0583)*cov_age_0)*(cov_age/1.0)^(1.0),
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.2593434,
    adminMass = 7e-05,
    ka = 0.0002861111111111111,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>propranolol</td></tr><tr><td>population:</td><td>infants with infantile hemangioma</td></tr><tr><td>source_paper:</td><td>Takechi_2018</td></tr><tr><td>measured_compound:</td><td>propranolol</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>tab_1</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>propranolol 259.343 g/mol (drugbank)</td></tr></table><p><b>Defaulted (base-class default used):</b> Tlag.</p><h4>Interpretation flags</h4><ul><li>dropped PD-category row 'Baseline' → Q324 (E0, category G11) — pharmacodynamic parameters belong to scholarpd, not the PK model (source ['tab_1:row10:col1', 'tab_1:row10:col3'])</li><li>dropped PD-category row 'Slope' → Q335 (slope, category G13) — pharmacodynamic parameters belong to scholarpd, not the PK model (source ['tab_1:row11:col1', 'tab_1:row11:col3', 'tab_1:row11:col4'])</li><li>dropped unlinked row (NIL): 'Treatment duration (weeks)' — extend the ontology if this is a real PK parameter (source ['tab_1:row12:col1', 'tab_1:row12:col3', 'tab_1:row12:col4'])</li><li>covariate level 'Gestational age (days) on' → Q900:gestational_age_days_on = 0.0583 (linear_fractional on Q27)</li><li>apparent-ness (ontology-grounded): parameterization=apparent, measured_compound=propranolol</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of TLAG: primary's parameterization (rate-constant / ka-only) does not use it</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 259200, Tolerance = 1e-9, Interval = 1));
end Propranolol_Takechi2018_reference;
