model Cefodizime_SchferKorting1986_reference
  parameter Real Cl_ref = 9.833333333333334e-07 "Cl [m3/s]";
  parameter Real Vd_ref = 0.015300000000000001 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.584669,
    adminMass = 0.002
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About cefodizime</h4><p>Cefodizime is a third-generation cephalosporin antibiotic used against bacterial infections. It is classed as investigational and is not an authorised medicine in the European Union.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q5057292\">Wikidata Q5057292</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>cefodizime</td></tr><tr><td>population:</td><td>healthy male subjects</td></tr><tr><td>source_paper:</td><td>Schäfer-Korting_1986</td></tr><tr><td>measured_compound:</td><td>cefodizime</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>cefodizime 584.669 g/mol (drugbank)</td></tr></table><h4>Interpretation flags</h4><ul><li>dropped duplicate Q26 ('renal clearance of free cefodizime', value 172) — already have one for this compound</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=cefodizime</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Cefodizime_SchferKorting1986_reference;
