model Ipilimumab_Hu2024_reference
  parameter Real Cl_ref = 3.75e-09 "Cl [m3/s]";
  parameter Real cov_sex_0 = 0 "sex covariate";
  parameter Real cov_sex_1 = 0 "sex covariate";
  parameter Real cov_egfr = 1.0 "egfr covariate (reference 1.0)";
  parameter Real Vd_ref = 0.00401 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref*(1 + (-0.0998)*cov_sex_0)*(1 + (0.0195)*cov_sex_1)*(cov_egfr/1.0)^(0.0982),
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    adminMass = 7e-06,
    k12 = 2.486838459407038e-06,
    k21 = 3.600080224628961e-06
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About ipilimumab</h4><p>Ipilimumab is a monoclonal antibody used to treat several cancers, including melanoma, renal cell carcinoma, non-small-cell lung cancer, mesothelioma, and colorectal cancer. It is approved and authorised in the European Union, where it is used in the treatment of these cancers.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q2459042\">Wikidata Q2459042</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>ipilimumab</td></tr><tr><td>population:</td><td>pediatric and adult oncology patients</td></tr><tr><td>source_paper:</td><td>Hu_2024</td></tr><tr><td>measured_compound:</td><td>ipilimumab</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>psp413098-tbl-0005</td></tr><tr><td>input:</td><td>PK_2C: IV (no input phase)</td></tr></table><h4>Interpretation flags</h4><ul><li>table section residual_error: 'Proportional' routed out of structural estimates ('Residual error')</li><li>table section residual_error: 'Proportional' routed out of structural estimates ('Residual error')</li><li>table section residual_error: 'Additive (μg/mL)' routed out of structural estimates ('Residual error')</li><li>table section residual_error: 'Additive (μg/mL)' routed out of structural estimates ('Residual error')</li><li>table section residual_error: 'Proportional' routed out of structural estimates ('Residual error')</li><li>table section residual_error: 'Proportional' routed out of structural estimates ('Residual error')</li><li>column 'parameter note' classified 'other' by the LLM but kept: the deterministic diagnostic-column test disagrees (a stratum column is a value column, not a statistic)</li><li>column 'parameter note' classified 'other' by the LLM but kept: the deterministic diagnostic-column test disagrees (a stratum column is a value column, not a statistic)</li><li>column 'parameter note' classified 'other' by the LLM but kept: the deterministic diagnostic-column test disagrees (a stratum column is a value column, not a statistic)</li><li>column 'parameter note' classified 'other' by the LLM but kept: the deterministic diagnostic-column test disagrees (a stratum column is a value column, not a statistic)</li><li>dropped unlinked row (NIL): 'CL LBM' — extend the ontology if this is a real PK parameter (source ['psp413098-tbl-0005:row6:col2', 'psp413098-tbl-0005:row6:col3'])</li><li>dropped duplicate Q63 ('VC LBM', value '0.932') — already have one for this compound</li><li>dropped unlinked row (NIL): 'CL CNST' — extend the ontology if this is a real PK parameter (source ['psp413098-tbl-0005:row8:col2', 'psp413098-tbl-0005:row8:col3'])</li><li>dropped duplicate Q22 ('CL OTH', value '0.00699') — already have one for this compound</li><li>dropped duplicate Q22 ('CL PEDOTH', value '-0.462') — already have one for this compound</li><li>dropped duplicate Q22 ('CL PEDCNST', value '-0.801') — already have one for this compound</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 15552000, Tolerance = 1e-9, Interval = 1));
end Ipilimumab_Hu2024_reference;
