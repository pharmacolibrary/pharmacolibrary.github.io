model Ibuprofen_Clissold1987_reference
  parameter Real Cl_ref = 1.1111111111111112e-05 "Cl [m3/s]";
  parameter Real Vd_ref = 0.0108 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.2062808,
    adminMass = 3e-05
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About ibuprofen</h4><p>Ibuprofen is a non-steroidal anti-inflammatory medicine used to relieve pain, inflammation and fever, and for conditions such as osteoarthritis, rheumatoid arthritis, migraine and gout. It is widely used and available over the counter in the UK, and is also authorised in the European Union for pain and for treating a heart vessel problem in premature babies.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q186969\">Wikidata Q186969</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>ibuprofen</td></tr><tr><td>population:</td><td>review reference</td></tr><tr><td>source_paper:</td><td>Clissold_1987</td></tr><tr><td>measured_compound:</td><td>ibuprofen</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>ibuprofen 206.281 g/mol (drugbank)</td></tr></table><h4>Interpretation flags</h4><ul><li>built from REVIEW reference values (Clissold_1987) — secondary source</li><li>volume reported by review</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Ibuprofen_Clissold1987_reference;
