model Ibuprofen_Trocniz2000_reference
  parameter Real Cl_ref = 1.125e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.0044 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C_enteral(
    weight = 70.0,
    F = 0.9,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.2062808,
    adminMass = 0.0004,
    ka = 0.00022777777777777775,
    Tlag = 4788.0,
    k12 = 0.00013194444444444443,
    k21 = 8.769721383014433e-05
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About ibuprofen</h4><p>Ibuprofen is a non-steroidal anti-inflammatory medicine used to relieve pain, inflammation and fever, and for conditions such as osteoarthritis, rheumatoid arthritis, migraine and gout. It is widely used and available over the counter in the UK, and is also authorised in the European Union for pain and for treating a heart vessel problem in premature babies.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q186969\">Wikidata Q186969</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>ibuprofen</td></tr><tr><td>population:</td><td>healthy adults</td></tr><tr><td>source_paper:</td><td>Trocóniz_2000</td></tr><tr><td>measured_compound:</td><td>ibuprofen</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>Table II</td></tr><tr><td>input:</td><td>PK_2C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>ibuprofen 206.281 g/mol (drugbank)</td></tr></table><p><b>Defaulted (base-class default used):</b> F.</p><h4>Interpretation flags</h4><ul><li>table section iiv: 'kₐ,susp (h⁻¹)' routed out of structural estimates ('Interindividual variabilityᵃ')</li><li>table section iiv: 'kₐ,grn1 (h⁻¹)' routed out of structural estimates ('Interindividual variabilityᵃ')</li><li>table section iiv: 'tₗag (h)' routed out of structural estimates ('Interindividual variabilityᵃ')</li><li>table section iiv: 'F₁' routed out of structural estimates ('Interindividual variabilityᵃ')</li><li>table section iiv: 'CL (L/h)ᵇ' routed out of structural estimates ('Interindividual variabilityᵃ')</li><li>table section iiv: 'CLd (L/h)ᵇ' routed out of structural estimates ('Interindividual variabilityᵃ')</li><li>table section iiv: 'V2 (L)ᵇ' routed out of structural estimates ('Interindividual variabilityᵃ')</li><li>dropped duplicate Q49 ('kₐ,grn1 (h⁻¹)', value '0.61') — already have one for this compound</li><li>dropped duplicate Q49 ('kₐ,grn2 (h⁻¹)', value '2.26') — already have one for this compound</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=ibuprofen</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Ibuprofen_Trocniz2000_reference;
