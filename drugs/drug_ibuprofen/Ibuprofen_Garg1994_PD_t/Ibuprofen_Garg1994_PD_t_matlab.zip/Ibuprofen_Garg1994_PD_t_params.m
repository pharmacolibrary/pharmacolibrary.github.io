function p = Ibuprofen_Garg1994_PD_t_params()
% Ibuprofen_Garg1994_PD_t_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% ibuprofen Garg_1994::T: indirect_response_i exposure-response sweep (response = E0*(1 - Emax*frac)). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one mg/L per second, in SI inside (kg/m3, s). Response T in degrees Fahrenheit. Driver: ibuprofen (cited_pk).
p.E0 = 110.26785714285714;
p.Emax = 1.0;
p.EC50 = 0.010099999999999998;
p.gamma = 1.0;
p.slope = 0.0;
p.exposure_per_s = 0.001;
p.stop_time = 110.0;
p.form = 'E0*(1 - Emax*frac)';
end
