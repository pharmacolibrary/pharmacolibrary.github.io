model Ibuprofen_Hannam2018_PD_pppm
  "sigmoid_emax exposure-response sweep — Hannam_2018 :: PPPM (Pain score)"
  extends Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep(
    E0 = 0,      // [1]
    Emax = -0.648,  // [pain units]
    EC50 = 0.00395,  // [kg/m3; mg/L × 0.001]
    gamma = 1.48,
    exposure_per_s = 0.001);   // 1 mg/L per second
  // imax_as_negative_emax: Imax (Q323) enters SigmoidEmaxSweep as −Emax
  // defaulted: E0
  annotation(experiment(StartTime = 0, StopTime = 40, Interval = 0.08),
    Documentation(info = "<html><body><!-- drug-about --><h4>About ibuprofen</h4><p>Ibuprofen is a non-steroidal anti-inflammatory medicine used to relieve pain, inflammation and fever, and for conditions such as osteoarthritis, rheumatoid arthritis, migraine and gout. It is widely used and available over the counter in the UK, and is also authorised in the European Union for pain and for treating a heart vessel problem in premature babies.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q186969\">Wikidata Q186969</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h4>Ibuprofen_Hannam2018_PD_pppm</h4><p>The steady-state exposure-response curve of Hannam JA et al., <i>Paediatric anaesthesia 28(10):841–851</i> 2018 (<a href=\"https://doi.org/10.1111/pan.13464\">doi:10.1111/pan.13464</a>) — Pain score [pain units] against ibuprofen mg/L — obtained by sweeping the driver instead of simulating a dose. Model family: sigmoid_emax.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = (library default) drug-free response (baseline)
  Emax  =      0.648 pain units maximal effect term (E MAX, Q323)
  EC50  =       3.95 mg/L     exposure at half of the maximal effect term (C 50,IBU, Q321)
  gamma =       1.48          Hill coefficient (HILL EFFECT, Q325)</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep\">SigmoidEmaxSweep</a>; this model only supplies the numbers. The x axis is one mg/L of ibuprofen per second of simulated time (exposure is in kg/m3): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0   (drug-free)
  exposure = EC50 (3.95 mg/L)  response -0.324
  exposure -> infinity  response -0.648</pre></body></html>"));
end Ibuprofen_Hannam2018_PD_pppm;
