function p = Ibuprofen_Hannam2018_PD_pppm_params()
% Ibuprofen_Hannam2018_PD_pppm_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% ibuprofen Hannam_2018::PPPM: sigmoid_emax exposure-response sweep (response = E0 + Emax*frac). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one mg/L per second, in SI inside (kg/m3, s). Response PPPM in pain units. Driver: ibuprofen (pk_record).
p.E0 = 0.0;
p.Emax = -0.648;
p.EC50 = 0.0039499999999999995;
p.gamma = 1.48;
p.slope = 0.0;
p.exposure_per_s = 0.001;
p.stop_time = 40.0;
p.form = 'E0 + Emax*frac';
end
