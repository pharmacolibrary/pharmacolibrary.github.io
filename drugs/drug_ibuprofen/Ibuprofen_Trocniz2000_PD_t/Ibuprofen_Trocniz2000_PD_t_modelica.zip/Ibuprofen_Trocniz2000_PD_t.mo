model Ibuprofen_Trocniz2000_PD_t
  "indirect_response_i exposure-response sweep — Trocóniz_2000 :: T (body temperature)"
  extends Pharmacolibrary.Interfaces.PartialExposureResponseSweep(
    E0 = 38.8,      // [°C]
    Emax = 0.055,  // type I effect term
    EC50 = 0.00618,  // [kg/m3; mg/L × 0.001]
    gamma = 2.71,
    exposure_per_s = 0.001);   // 1 mg/L per second
equation
  response = E0*(1 - Emax*frac);   // steady state, indirect response type I
  annotation(experiment(StartTime = 0, StopTime = 62, Interval = 0.124),
    Documentation(info = "<html><body><!-- drug-about --><h4>About ibuprofen</h4><p>Ibuprofen is a non-steroidal anti-inflammatory medicine used to relieve pain, inflammation and fever, and for conditions such as osteoarthritis, rheumatoid arthritis, migraine and gout. It is widely used and available over the counter in the UK, and is also authorised in the European Union for pain and for treating a heart vessel problem in premature babies.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q186969\">Wikidata Q186969</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h4>Ibuprofen_Trocniz2000_PD_t</h4><p>The steady-state exposure-response curve of Trocóniz IF et al., <i>Clinical pharmacokinetics 38(6):505–518</i> 2000 (<a href=\"https://doi.org/10.2165/00003088-200038060-00004\">doi:10.2165/00003088-200038060-00004</a>) — body temperature [°C] against ibuprofen mg/L — obtained by sweeping the driver instead of simulating a dose. Model family: indirect_response_i.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    =       38.8 °C       drug-free response (baseline) (T0, Q324)
  Emax  =      0.055          maximal effect term (Emax, Q323)
  EC50  =       6.18 mg/L     exposure at half of the maximal effect term (EC50, Q321)
  gamma =       2.71          Hill coefficient (n, Q325)</pre><p>The algebra is <code>response = E0*(1 - Emax*frac)</code>; this model only supplies the numbers. The x axis is one mg/L of ibuprofen per second of simulated time (exposure is in kg/m3): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 38.8   (drug-free)
  exposure = EC50 (6.18 mg/L)  response 37.73
  exposure -> infinity  response 36.67</pre></body></html>"));
end Ibuprofen_Trocniz2000_PD_t;
