function p = Ibuprofen_Trocniz2000_PD_t_params()
% Ibuprofen_Trocniz2000_PD_t_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% ibuprofen Trocóniz_2000::T: indirect_response_i exposure-response sweep (response = E0*(1 - Emax*frac)). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one mg/L per second, in SI inside (kg/m3, s). Response T in °C. Driver: ibuprofen (pk_record).
p.E0 = 38.8;
p.Emax = 0.055;
p.EC50 = 0.006179999999999999;
p.gamma = 2.71;
p.slope = 0.0;
p.exposure_per_s = 0.001;
p.stop_time = 62.0;
p.form = 'E0*(1 - Emax*frac)';
end
