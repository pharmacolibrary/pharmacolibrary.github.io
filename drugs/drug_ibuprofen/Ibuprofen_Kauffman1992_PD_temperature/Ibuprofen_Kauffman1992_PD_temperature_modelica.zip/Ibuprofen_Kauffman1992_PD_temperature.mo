model Ibuprofen_Kauffman1992_PD_temperature
  "linear exposure-response sweep — Kauffman_1992 :: temperature (temperature)"
  extends Pharmacolibrary.Interfaces.PartialExposureResponseSweep(
    E0 = 0,      // [1]
    Emax = 0, EC50 = 1,      // unused by a line
    exposure_per_s = 0.001);
  parameter Real slope = -0.242   "[°C/mg per liter]";
equation
  response = E0 + slope*exposure;
  // family_inferred: the record's model family is effect_compartment; read from the parameters: a slope and no Emax — linear
  // defaulted: E0
  annotation(experiment(StartTime = 0, StopTime = 1000, Interval = 2),
    Documentation(info = "<html><body><h4>Ibuprofen_Kauffman1992_PD_temperature</h4><p>The steady-state exposure-response curve of Kauffman RE et al., <i>The Journal of pediatrics 121(6):969–973</i> 1992 (<a href=\"https://doi.org/10.1016/s0022-3476(05)80354-3\">doi:10.1016/s0022-3476(05)80354-3</a>) — temperature [°C] against ibuprofen mg/L — obtained by sweeping the driver instead of simulating a dose. Model family: linear.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = (library default) drug-free response (baseline)
  slope =     -0.242 °C/mg per liter change in response per unit of exposure (Slope, Q335)</pre><p>The algebra is <code>response = E0 + slope*exposure</code>; this model only supplies the numbers. The x axis is one mg/L of ibuprofen per second of simulated time (exposure is in kg/m3): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0   (drug-free)</pre></body></html>"));
end Ibuprofen_Kauffman1992_PD_temperature;
