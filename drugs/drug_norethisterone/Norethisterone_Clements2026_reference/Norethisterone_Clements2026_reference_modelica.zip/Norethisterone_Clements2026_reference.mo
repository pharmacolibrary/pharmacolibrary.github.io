model Norethisterone_Clements2026_reference
  parameter Real Cl_ref = 8.101851851851853e-09 "Cl [m3/s]";
  parameter Real Vd_ref = 0.00481 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.29842599999999997,
    adminMass = 2.5e-06,
    k12 = 1.8552206052206052e-06,
    k21 = 7.026465441819773e-07
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About norethisterone</h4><p>Norethisterone is a synthetic progestogen used in hormonal contraception and for conditions such as endometriosis, endometrial hyperplasia, acne, and hypogonadism. It is widely used, appearing in many combined and progestogen-only contraceptive preparations, and is also approved for other investigational uses.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q421352\">Wikidata Q421352</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>norethisterone</td></tr><tr><td>population:</td><td>review reference</td></tr><tr><td>source_paper:</td><td>Clements_2026</td></tr><tr><td>measured_compound:</td><td>norethisterone</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_2C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>norethisterone 298.426 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>built from REVIEW reference values (Clements_2026) — secondary source</li><li>volume reported by review</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 2419200, Tolerance = 1e-9, Interval = 1));
end Norethisterone_Clements2026_reference;
