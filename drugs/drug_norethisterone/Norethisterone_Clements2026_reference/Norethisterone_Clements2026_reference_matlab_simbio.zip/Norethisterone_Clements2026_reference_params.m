function p = Norethisterone_Clements2026_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: norethisterone   source: Clements_2026 / reference   route: iv_bolus
  % estimated (absent from source): F
  p.name  = 'Norethisterone_Clements2026_reference_params';
  p.drug  = 'norethisterone';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'iv_bolus';        % 'oral' | 'iv_bolus'
  p.depot = false;             % oral -> first-order absorption depot
  p.Vc = 4.81;                % central volume [L]
  p.CL = 0.029167;                % clearance [L/h]
  p.Vp = [12.7];             % peripheral volumes [L]
  p.Q  = [0.032125];             % inter-compartmental clearances [L/h]
  p.ka = 0.0;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 2.5;             % dose [mg]
end
