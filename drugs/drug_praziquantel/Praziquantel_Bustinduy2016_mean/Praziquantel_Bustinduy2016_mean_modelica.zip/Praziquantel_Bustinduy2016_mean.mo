model Praziquantel_Bustinduy2016_mean
  parameter Real Cl_ref = 0.00016889444444444444 "Cl [m3/s]";
  parameter Real Vd_ref = 0.47397000000000006 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.31240609999999996,
    adminMass = 0.0028,
    ka = 0.004136111111111111,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About praziquantel</h4><p>Praziquantel is an anthelmintic used to treat parasitic worm infections such as schistosomiasis, cysticercosis, opisthorchiasis, and clonorchiasis. It is widely used in human medicine and is included on the WHO essential medicines list; it is also approved for veterinary use.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q424145\">Wikidata Q424145</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>praziquantel</td></tr><tr><td>population:</td><td>Ugandan children with intestinal schistosomiasis</td></tr><tr><td>source_paper:</td><td>Bustinduy_2016</td></tr><tr><td>measured_compound:</td><td>praziquantel</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>tab3</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>praziquantel 312.406 g/mol (drugbank)</td></tr></table><p><b>Defaulted (base-class default used):</b> Tlag.</p><h4>Interpretation flags</h4><ul><li>apparent-ness (ontology-grounded): parameterization=apparent, measured_compound=praziquantel</li><li>structure disagreement: deterministic 1C vs LLM 2C — review compartment count</li><li>population split: 'mean' subgroup of Bustinduy_2016 (paper reports 4 populations: mean, median, r-pzq, s-pzq)</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary's parameterization (rate-constant / ka-only) does not use it</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Praziquantel_Bustinduy2016_mean;
