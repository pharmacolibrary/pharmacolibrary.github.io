model Isoniazid_Tikiso2022_reference
  parameter Real Cl_ref = 4.416666666666667e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.0443 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 0.9,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.1371393,
    adminMass = 0.0003,
    ka = 0.00038888888888888887,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About isoniazid</h4><p>Isoniazid is an antibiotic used to treat tuberculosis, including pulmonary and miliary forms. It is widely used as a key antituberculous medicine, available alone and in combination products, and is included on the WHO essential medicines list.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q423169\">Wikidata Q423169</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>isoniazid</td></tr><tr><td>population:</td><td>review reference</td></tr><tr><td>source_paper:</td><td>Tikiso_2022</td></tr><tr><td>measured_compound:</td><td>isoniazid</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>isoniazid 137.139 g/mol (drugbank)</td></tr></table><p><b>Defaulted (base-class default used):</b> F, Tlag.</p><h4>Interpretation flags</h4><ul><li>built from REVIEW reference values (Tikiso_2022) — secondary source</li><li>volume reported by review</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Isoniazid_Tikiso2022_reference;
