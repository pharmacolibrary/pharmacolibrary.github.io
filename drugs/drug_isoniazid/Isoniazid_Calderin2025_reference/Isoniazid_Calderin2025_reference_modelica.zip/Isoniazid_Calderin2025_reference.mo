model Isoniazid_Calderin2025_reference
  parameter Real Cl_ref = 1.163888888888889e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.045 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 0.9,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.12311,
    adminMass = 0.00035,
    ka = 0.0008194444444444445,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About isoniazid</h4><p>Isoniazid is an antibiotic used to treat tuberculosis, including pulmonary and miliary forms. It is widely used as a key antituberculous medicine, available alone and in combination products, and is included on the WHO essential medicines list.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q423169\">Wikidata Q423169</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>isoniazid</td></tr><tr><td>population:</td><td>South African adults with tuberculous meningitis</td></tr><tr><td>source_paper:</td><td>Calderin_2025</td></tr><tr><td>measured_compound:</td><td>pyrazinamide, isoniazid</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>T2</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>isoniazid 137.139 g/mol (drugbank); pyrazinamide, isoniazid 123.11 g/mol (paper)</td></tr></table><p><b>Defaulted (base-class default used):</b> F, Tlag.</p><h4>Interpretation flags</h4><ul><li>dropped value-less row: 'Number of absorption transit compartments (.)d'</li><li>dropped value-less row: 'Hepatic blood flow (L/h)b,e'</li><li>salvaged Q22 ('Pyrazinamide clearance ... for the typical individual in the cohort'=4.19) from results prose — parameter table was unreadable</li><li>salvaged Q61 ('Pyrazinamide volume of distribution ... for the typical individual in the cohort'=45.0) from results prose — parameter table was unreadable</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=pyrazinamide, isoniazid</li><li>held at status:extracted — NIL link or unit issue (mismatch/unknown/normalisation-failed) present</li><li>status held at route_to_review — not promoted</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li><li>gap-filled Q49 (kabs) from Al-Shaer_2019's review values (primary lacked it)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 140400, Tolerance = 1e-9, Interval = 1));
end Isoniazid_Calderin2025_reference;
