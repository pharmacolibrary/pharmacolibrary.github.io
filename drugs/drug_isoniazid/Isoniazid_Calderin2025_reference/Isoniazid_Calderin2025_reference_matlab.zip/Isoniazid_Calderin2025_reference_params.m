function p = Isoniazid_Calderin2025_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: isoniazid   source: Calderin_2025 / reference   route: oral
  % estimated (absent from source): F
  p.name  = 'Isoniazid_Calderin2025_reference_params';
  p.drug  = 'isoniazid';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 45.0;                % central volume [L]
  p.CL = 4.19;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 2.95;                % absorption rate [1/h]
  p.F  = 0.9;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 350.0;             % dose [mg]
end
