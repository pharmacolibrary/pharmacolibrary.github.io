function p = Alprazolam_Lau1997_PD_reinforcement_rate_params()
% Alprazolam_Lau1997_PD_reinforcement_rate_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% alprazolam Lau_1997::reinforcement_rate: indirect_response_i exposure-response sweep (response = E0*(1 - Emax*frac)). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one microg/ml per second, in SI inside (kg/m3, s). Response reinforcement rate in its own unit. Driver: alprazolam (cited_pk).
p.E0 = 0.0;
p.Emax = 1.0;
p.EC50 = 1.9999999999999995e-05;
p.gamma = 1.0;
p.slope = 0.0;
p.exposure_per_s = 0.001;
p.stop_time = 0.2;
p.form = 'E0*(1 - Emax*frac)';
end
