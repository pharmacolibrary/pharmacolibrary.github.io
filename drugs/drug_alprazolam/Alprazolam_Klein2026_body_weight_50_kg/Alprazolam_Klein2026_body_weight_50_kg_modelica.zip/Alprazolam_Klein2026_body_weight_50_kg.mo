model Alprazolam_Klein2026_body_weight_50_kg
  parameter Real Cl_ref = 1.976111111111111e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.06753 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.308765,
    adminMass = 2e-06,
    ka = 0.0001388888888888889,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About alprazolam</h4><p>Alprazolam is a short-acting benzodiazepine anxiolytic used to treat anxiety and panic disorders, and also for conditions such as insomnia. It is an approved medicine that is widely used, though it carries a boxed warning and is also encountered as an illicit drug.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q319877\">Wikidata Q319877</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>alprazolam</td></tr><tr><td>population:</td><td>adults and adolescents with epilepsy</td></tr><tr><td>source_paper:</td><td>Klein_2026</td></tr><tr><td>measured_compound:</td><td>alprazolam</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>Table S3</td></tr><tr><td>input:</td><td>PK_1C_enteral: apparent (/F) parameterization ⇒ extravascular dosing</td></tr><tr><td>molar_masses:</td><td>alprazolam 308.765 g/mol (drugbank)</td></tr></table><p><b>Defaulted (base-class default used):</b> ka, Tlag.</p><h4>Interpretation flags</h4><ul><li>unit_dimension_unknown: 'n = 6' (AUC∞)</li><li>unit_dimension_unknown: 'n = 6' (AUClast)</li><li>implicit units: 'AUCinf, h.ng/mL' → h.ng/mL (from the paper text: &quot;The parameter list itself shows 'AUCinf, h.ng/mL = 281.1', and the paper reports AUCinf as plasma exposure of alprazolam&quot;)</li><li>implicit units: 'AUC0–t, h.ng/mL' → h.ng/mL (from the paper text: &quot;The parameter list itself shows 'AUC0–t, h.ng/mL = 270.8', consistent with AUC0–t reported in the paper as plasma exposu&quot;)</li><li>apparent-ness (ontology-grounded): parameterization=apparent, measured_compound=alprazolam</li><li>population split: 'body weight <50 kg (n = 6)' subgroup of Klein_2026 (paper reports 3 populations: all patients (n = 14), body weight <50 kg (n = 6), body weight ≥50 kg (n = 8))</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 126000, Tolerance = 1e-9, Interval = 1));
end Alprazolam_Klein2026_body_weight_50_kg;
