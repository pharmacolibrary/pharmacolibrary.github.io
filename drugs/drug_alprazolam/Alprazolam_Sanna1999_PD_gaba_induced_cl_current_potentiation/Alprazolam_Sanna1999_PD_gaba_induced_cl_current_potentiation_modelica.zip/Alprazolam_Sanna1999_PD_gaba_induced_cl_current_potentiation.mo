model Alprazolam_Sanna1999_PD_gaba_induced_cl_current_potentiation
  "emax exposure-response sweep — Sanna_1999 :: GABA-induced Cl- current potentiation (alpha1 beta2 gamma2S GABAA receptors) (GABA-induced Cl- current potentiation (alpha1 beta2 gamma2S GABAA receptors))"
  extends Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep(
    E0 = 0,      // [1]
    Emax = 0.98,  // [1; % × 0.01]
    EC50 = 5.6e-05,  // [mol/m3; nmol/l × 1e-06]
    gamma = 1,
    exposure_per_s = 1e-06);   // 1 nmol/l per second
  // defaulted: E0
  // defaulted: gamma
  annotation(experiment(StartTime = 0, StopTime = 560, Interval = 1.12),
    Documentation(info = "<html><body><!-- drug-about --><h4>About alprazolam</h4><p>Alprazolam is a short-acting benzodiazepine anxiolytic used to treat anxiety and panic disorders, and also for conditions such as insomnia. It is an approved medicine that is widely used, though it carries a boxed warning and is also encountered as an illicit drug.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q319877\">Wikidata Q319877</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h4>Alprazolam_Sanna1999_PD_gaba_induced_cl_current_potentiation</h4><p>The steady-state exposure-response curve of Sanna E et al., <i>Arzneimittel-Forschung 49(2):88–95</i> 1999 (<a href=\"https://doi.org/10.1055/s-0031-1300366\">doi:10.1055/s-0031-1300366</a>) — GABA-induced Cl- current potentiation (alpha1 beta2 gamma2S GABAA receptors) [% increase] against alprazolam nmol/l — obtained by sweeping the driver instead of simulating a dose. Model family: emax.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = (library default) drug-free response (baseline)
  Emax  =         98 %        maximal effect term (maximum potentiation, Q320)
  EC50  =         56 nmol/l   exposure at half of the maximal effect term (EC50, Q321)
  gamma = (library default) Hill coefficient</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep\">SigmoidEmaxSweep</a>; this model only supplies the numbers. The x axis is one nmol/l of alprazolam per second of simulated time (exposure is in mol/m3): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0   (drug-free)
  exposure = EC50 (56 nmol/l)  response 0.49
  exposure -> infinity  response 0.98</pre></body></html>"));
end Alprazolam_Sanna1999_PD_gaba_induced_cl_current_potentiation;
