function p = Alprazolam_Sanna1999_PD_gaba_induced_cl_current_potentiation_params()
% Alprazolam_Sanna1999_PD_gaba_induced_cl_current_potentiation_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% alprazolam Sanna_1999::GABA_induced_Cl_current_potentiation_alpha1_beta2_gamma2S_GABAA_receptors: emax exposure-response sweep (response = E0 + Emax*frac). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one nmol/l per second, in SI inside (kg/m3, s). Response GABA-induced Cl- current potentiation (alpha1 beta2 gamma2S GABAA receptors) in % increase. Driver: alprazolam (cited_pk).
p.E0 = 0.0;
p.Emax = 0.98;
p.EC50 = 5.6e-05;
p.gamma = 1.0;
p.slope = 0.0;
p.exposure_per_s = 1e-06;
p.stop_time = 560.0;
p.form = 'E0 + Emax*frac';
end
