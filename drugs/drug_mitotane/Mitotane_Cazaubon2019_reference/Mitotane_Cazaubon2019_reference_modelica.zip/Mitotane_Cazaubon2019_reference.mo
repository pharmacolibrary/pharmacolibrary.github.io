model Mitotane_Cazaubon2019_reference
  parameter Real Cl_ref = 8.101851851851853e-07 "Cl [m3/s]";
  parameter Real Vd_ref = 8.9 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 35.0,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.320041,
    adminMass = 0.003,
    ka = 0.0002777777777777778,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About mitotane</h4><p>Mitotane is an antineoplastic drug used to treat adrenal cortex cancer and Cushing's syndrome. It is authorised in the European Union for adrenal cortex tumours and remains in clinical use, though it carries a boxed warning.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q417465\">Wikidata Q417465</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>mitotane</td></tr><tr><td>population:</td><td>adults with adrenocortical carcinoma</td></tr><tr><td>source_paper:</td><td>Cazaubon_2019</td></tr><tr><td>measured_compound:</td><td>mitotane</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>pharmaceutics-11-00566-t002</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>mitotane 320.041 g/mol (drugbank)</td></tr></table><p><b>Defaulted (base-class default used):</b> Tlag.</p><h4>Interpretation flags</h4><ul><li>table section iiv: 'ω V(%)' routed out of structural estimates ('Between-subject variability')</li><li>table section iiv: 'ω Cl (%)' routed out of structural estimates ('Between-subject variability')</li><li>table section residual_error: 'a (constant)' routed out of structural estimates ('Residual variability')</li><li>table section residual_error: 'b (proportional)' routed out of structural estimates ('Residual variability')</li><li>column 'value (rse %)' classified 'rse' by the LLM but kept as the estimate: the header names the point value</li><li>column 'value (rse %)' classified 'rse' by the LLM but kept as the estimate: the header names the point value</li><li>column 'value (rse %)' classified 'rse' by the LLM but kept as the estimate: the header names the point value</li><li>column 'value (rse %)' classified 'rse' by the LLM but kept as the estimate: the header names the point value</li><li>column 'value (rse %)' classified 'rse' by the LLM but kept as the estimate: the header names the point value</li><li>column 'value (rse %)' classified 'rse' by the LLM but kept as the estimate: the header names the point value</li><li>column 'value (rse %)' classified 'rse' by the LLM but kept as the estimate: the header names the point value</li><li>column 'value (rse %)' classified 'rse' by the LLM but kept as the estimate: the header names the point value</li><li>column 'value (rse %)' classified 'rse' by the LLM but kept as the estimate: the header names the point value</li><li>dropped unlinked row (NIL): 'βHDL **' — extend the ontology if this is a real PK parameter (source ['pharmaceutics-11-00566-t002:row7:col1'])</li><li>dropped unlinked row (NIL): 'βTg ***' — extend the ontology if this is a real PK parameter (source ['pharmaceutics-11-00566-t002:row8:col1'])</li><li>dropped unlinked row (NIL): 'plcat_1' — extend the ontology if this is a real PK parameter (source ['pharmaceutics-11-00566-t002:row16:col1'])</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 15552000, Tolerance = 1e-9, Interval = 1));
end Mitotane_Cazaubon2019_reference;
