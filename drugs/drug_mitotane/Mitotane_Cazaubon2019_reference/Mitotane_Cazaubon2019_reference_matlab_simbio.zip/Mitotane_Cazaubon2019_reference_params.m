function p = Mitotane_Cazaubon2019_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: mitotane   source: Cazaubon_2019 / reference   route: oral
  p.name  = 'Mitotane_Cazaubon2019_reference_params';
  p.drug  = 'mitotane';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 8900.0;                % central volume [L]
  p.CL = 2.916667;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 1.0;                % absorption rate [1/h]
  p.F  = 0.35;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 3000.0;             % dose [mg]
end
