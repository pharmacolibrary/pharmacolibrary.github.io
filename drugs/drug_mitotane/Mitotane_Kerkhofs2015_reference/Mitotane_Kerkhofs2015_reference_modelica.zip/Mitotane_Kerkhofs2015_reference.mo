model Mitotane_Kerkhofs2015_reference
  parameter Real Cl_ref = 2.6111111111111113e-07 "Cl [m3/s]";
  parameter Real Vd_ref = 0.161 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.320041,
    adminMass = 1e-05
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About mitotane</h4><p>Mitotane is an antineoplastic drug used to treat adrenal cortex cancer and Cushing's syndrome. It is authorised in the European Union for adrenal cortex tumours and remains in clinical use, though it carries a boxed warning.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q417465\">Wikidata Q417465</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>mitotane</td></tr><tr><td>population:</td><td>patients with adrenocortical carcinoma</td></tr><tr><td>source_paper:</td><td>Kerkhofs_2015</td></tr><tr><td>measured_compound:</td><td>mitotane</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>mitotane 320.041 g/mol (drugbank)</td></tr></table><h4>Interpretation flags</h4><ul><li>unit_dimension_unknown: 'L/kg of lean body mass' (Vss)</li><li>dropped unlinked row (NIL): 'mean prediction error' — extend the ontology if this is a real PK parameter (source ['Kerkhofs_2015:abstract'])</li><li>routed 'error margin' → Q316 (prop_error) to residual_error — variability estimate, not a structural parameter</li><li>implicit units: 'volume of distribution in the steady state' → L (from the popPK convention: 'No unit is stated in the paper or table captions. For population pharmacokinetics, the volume of distribution at steady ')</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=mitotane</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 2419200, Tolerance = 1e-9, Interval = 1));
end Mitotane_Kerkhofs2015_reference;
