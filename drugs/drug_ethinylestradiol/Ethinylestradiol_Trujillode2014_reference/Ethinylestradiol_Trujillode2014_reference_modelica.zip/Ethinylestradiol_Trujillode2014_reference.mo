model Ethinylestradiol_Trujillode2014_reference
  parameter Real Cl_ref = 2.1916666666666667e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.3233 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.2964034,
    adminMass = 1e-05
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About ethinylestradiol</h4><p>Ethinylestradiol is an estrogen used mainly in combined birth control pills, and has also been used for hormone-related conditions such as menopausal problems, hypogonadism, and certain cancers. It is widely used around the world in fixed and sequential combinations with progestogens for hormonal contraception.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q415563\">Wikidata Q415563</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>ethinylestradiol</td></tr><tr><td>population:</td><td>review reference</td></tr><tr><td>source_paper:</td><td>Trujillo-de_2014</td></tr><tr><td>measured_compound:</td><td>ethinylestradiol</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>ethinylestradiol 296.403 g/mol (drugbank)</td></tr></table><h4>Interpretation flags</h4><ul><li>built from REVIEW reference values (Trujillo-de_2014) — secondary source</li><li>volume reported by review</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 518400, Tolerance = 1e-9, Interval = 1));
end Ethinylestradiol_Trujillode2014_reference;
