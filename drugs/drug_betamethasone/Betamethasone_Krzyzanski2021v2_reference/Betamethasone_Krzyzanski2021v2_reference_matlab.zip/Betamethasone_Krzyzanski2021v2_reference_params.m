function p = Betamethasone_Krzyzanski2021v2_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: betamethasone   source: Krzyzanski_2021_2 / reference   route: oral
  p.name  = 'Betamethasone_Krzyzanski2021v2_reference_params';
  p.drug  = 'betamethasone';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 51.3;                % central volume [L]
  p.CL = 0.538;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.46;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 6.0;             % dose [mg]
end
