model Betamethasone_Krzyzanski2021v2_reference
  parameter Real Cl_ref = 2.5805555555555555e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.0513 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.3924611,
    adminMass = 6e-06,
    ka = 0.0001277777777777778,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>betamethasone</td></tr><tr><td>population:</td><td>healthy nonpregnant Indian women</td></tr><tr><td>source_paper:</td><td>Krzyzanski_2021_2</td></tr><tr><td>measured_compound:</td><td>betamethasone</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>Tab4</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>betamethasone 392.461 g/mol (drugbank)</td></tr></table><p><b>Defaulted (base-class default used):</b> Tlag.</p><h4>Interpretation flags</h4><ul><li>the dosed compound is betamethasone; the compartment is betamethasone. Input enters at the reported formation rate, so formation is already accounted for in the input step and the simulated concentration is betamethasone, not betamethasone</li><li>apparent parameters (CLm/F, Vm/F) already contain F and the metabolised fraction, so F=1 and no molar correction is applied — adding either would double-count it</li><li>betamethasone's own concentration-time course is not produced by this model</li><li>dropped duplicate Q49 ('kaIMa, 1/h', value '0.00638') — already have one for this compound</li><li>dropped duplicate Q49 ('kaPO, 1/h', value '0.936') — already have one for this compound</li><li>dropped duplicate Q76 ('VT/FIM, L', value '5.06') — already have one for this compound</li><li>apparent-ness (ontology-grounded): parameterization=apparent, measured_compound=betamethasone</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 93600, Tolerance = 1e-9, Interval = 1));
end Betamethasone_Krzyzanski2021v2_reference;
