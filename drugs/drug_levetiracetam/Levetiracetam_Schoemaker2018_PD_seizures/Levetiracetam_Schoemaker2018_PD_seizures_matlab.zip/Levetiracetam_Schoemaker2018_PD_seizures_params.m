function p = Levetiracetam_Schoemaker2018_PD_seizures_params()
% Levetiracetam_Schoemaker2018_PD_seizures_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% levetiracetam Schoemaker_2018::seizures: emax exposure-response sweep (response = E0 + Emax*frac). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one mg/L per second, in SI inside (kg/m3, s). Response seizures in its own unit. Driver: levetiracetam (pk_record).
p.E0 = 3.900462962962963e-06;
p.Emax = -95.6;
p.EC50 = 0.03139999999999999;
p.gamma = 1.0;
p.slope = 0.0;
p.exposure_per_s = 0.001;
p.stop_time = 320.0;
p.form = 'E0 + Emax*frac';
end
