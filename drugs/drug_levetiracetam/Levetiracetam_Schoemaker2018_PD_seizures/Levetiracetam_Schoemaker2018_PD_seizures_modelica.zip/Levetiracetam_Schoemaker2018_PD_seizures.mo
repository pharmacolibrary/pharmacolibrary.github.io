model Levetiracetam_Schoemaker2018_PD_seizures
  "emax exposure-response sweep — Schoemaker_2018 :: seizures (seizure counts)"
  extends Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep(
    E0 = 3.90046296296e-06,      // [1/s; day−1 × 1.15741e-05]
    Emax = -95.6,  // [% change]
    EC50 = 0.0314,  // [kg/m3; mg/L × 0.001]
    gamma = 1,
    exposure_per_s = 0.001);   // 1 mg/L per second
  // imax_as_negative_emax: Imax (Q323) enters SigmoidEmaxSweep as −Emax
  // defaulted: gamma
  annotation(experiment(StartTime = 0, StopTime = 320, Interval = 0.64),
    Documentation(info = "<html><body><!-- drug-about --><h4>About levetiracetam</h4><p>Levetiracetam is an antiepileptic medicine used to treat epilepsy and various types of seizures, including focal, temporal lobe, frontal lobe, and tonic–clonic seizures. It is an approved drug widely used, with several products authorised in the European Union for epilepsy.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q417227\">Wikidata Q417227</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h4>Levetiracetam_Schoemaker2018_PD_seizures</h4><p>The steady-state exposure-response curve of Schoemaker R et al., <i>Clinical pharmacokinetics 57(7):843–854</i> 2018 (<a href=\"https://doi.org/10.1007/s40262-017-0597-2\">doi:10.1007/s40262-017-0597-2</a>) — seizure counts against levetiracetam mg/L — obtained by sweeping the driver instead of simulating a dose. Model family: emax.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    =      0.337 day−1    drug-free response (baseline) (S 0 adults, Q324)
  Emax  =      -95.6 % change maximal effect term (E max, Q323)
  EC50  =       31.4 mg/L     exposure at half of the maximal effect term (EC50, Q321)
  gamma = (library default) Hill coefficient</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep\">SigmoidEmaxSweep</a>; this model only supplies the numbers. The x axis is one mg/L of levetiracetam per second of simulated time (exposure is in kg/m3): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 3.9e-06   (drug-free)
  exposure = EC50 (31.4 mg/L)  response -47.8
  exposure -> infinity  response -95.6</pre></body></html>"));
end Levetiracetam_Schoemaker2018_PD_seizures;
