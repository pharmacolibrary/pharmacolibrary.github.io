model Levetiracetam_Li2023_base
  parameter Real Cl_ref = 1.1833333333333334e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.0409 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.170212,
    adminMass = 0.0015,
    ka = 0.0008277777777777778,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About levetiracetam</h4><p>Levetiracetam is an antiepileptic medicine used to treat epilepsy and various types of seizures, including focal, temporal lobe, frontal lobe, and tonic–clonic seizures. It is an approved drug widely used, with several products authorised in the European Union for epilepsy.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q417227\">Wikidata Q417227</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>levetiracetam</td></tr><tr><td>population:</td><td>women with epilepsy during pregnancy</td></tr><tr><td>source_paper:</td><td>Li_2023</td></tr><tr><td>measured_compound:</td><td>levetiracetam</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>Table 3</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>levetiracetam 170.212 g/mol (drugbank)</td></tr></table><p><b>Defaulted (base-class default used):</b> Tlag.</p><h4>Interpretation flags</h4><ul><li>apparent-ness (ontology-grounded): parameterization=apparent, measured_compound=levetiracetam</li><li>model-stage split: 'base model estimate' is the base model of Li_2023 (paper reports 2 stages: base model estimate, final model estimate); same population, different model-building step</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li><li>gap-filled Q49 (kabs) from Schoemaker_2018's review values (primary lacked it)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 126000, Tolerance = 1e-9, Interval = 1));
end Levetiracetam_Li2023_base;
