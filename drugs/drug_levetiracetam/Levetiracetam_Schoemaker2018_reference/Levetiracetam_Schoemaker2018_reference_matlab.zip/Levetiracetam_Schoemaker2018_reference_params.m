function p = Levetiracetam_Schoemaker2018_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: levetiracetam   source: Schoemaker_2018 / reference   route: oral
  p.name  = 'Levetiracetam_Schoemaker2018_reference_params';
  p.drug  = 'levetiracetam';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 93.1;                % central volume [L]
  p.CL = 25.2;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 2.98;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 1500.0;             % dose [mg]
end
