model Levetiracetam_Sharpe2024_reference
  parameter Real Cl_ref = 1.4944444444444445e-08 "Cl [m3/s]";
  parameter Real Vd_ref = 0.000832 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 0.9,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.170212,
    adminMass = 0.0015,
    ka = 0.0008277777777777778,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About levetiracetam</h4><p>Levetiracetam is an antiepileptic medicine used to treat epilepsy and various types of seizures, including focal, temporal lobe, frontal lobe, and tonic–clonic seizures. It is an approved drug widely used, with several products authorised in the European Union for epilepsy.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q417227\">Wikidata Q417227</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>levetiracetam</td></tr><tr><td>population:</td><td>term neonates with electrographically confirmed seizures</td></tr><tr><td>source_paper:</td><td>Sharpe_2024</td></tr><tr><td>measured_compound:</td><td>levetiracetam</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>levetiracetam 170.212 g/mol (drugbank)</td></tr></table><p><b>Defaulted (base-class default used):</b> F, Tlag.</p><h4>Interpretation flags</h4><ul><li>dropped unlinked row (NIL): 'weight in kg' — extend the ontology if this is a real PK parameter (source ['Sharpe_2024:abstract', 'Sharpe_2024:abstract'])</li><li>dropped unlinked row (NIL): 'postnatal age in days' — extend the ontology if this is a real PK parameter (source ['Sharpe_2024:abstract'])</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=levetiracetam</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li><li>gap-filled Q49 (kabs) from Schoemaker_2018's review values (primary lacked it)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 259200, Tolerance = 1e-9, Interval = 1));
end Levetiracetam_Sharpe2024_reference;
