model Temozolomide_Bsker2022_reference
  parameter Real Cl_ref = 9.138888888888888e-07 "Cl [m3/s]";
  parameter Real Vd_ref = 0.0105 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 0.9,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.1941508,
    adminMass = 0.0001,
    ka = 0.002677777777777778,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About temozolomide</h4><p>Temozolomide is an alkylating anticancer drug used to treat brain cancers such as glioblastoma, anaplastic astrocytoma and other gliomas, as well as melanoma. It is an approved medicine with several authorised products in the European Union, where it is used for glioma and neuroblastoma, and it is also being investigated for other uses.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q425088\">Wikidata Q425088</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>temozolomide</td></tr><tr><td>population:</td><td>children with malignant central nervous system tumors</td></tr><tr><td>source_paper:</td><td>Büsker_2022</td></tr><tr><td>measured_compound:</td><td>temozolomide</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>Tab2</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>temozolomide 194.151 g/mol (drugbank)</td></tr></table><p><b>Defaulted (base-class default used):</b> F, Tlag.</p><h4>Interpretation flags</h4><ul><li>table section iiv: 'CL' routed out of structural estimates ('Inter-individual variability (CV%h)')</li><li>dropped unlinked row (NIL): 'VCSFe (liter)' — extend the ontology if this is a real PK parameter (source ['Tab2:row5:col1'])</li><li>apparent-by-design (ADVISORY, codes unchanged): extravascular dosing with no identifiable F, so these reported disposition parameters are likely apparent unless the model puts first-pass in its structure — Q22 (CLc (liter/h)); Q63 (Vcd (liter)); Q30 (Qf (liter/h))</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=temozolomide</li><li>structure disagreement: deterministic 1C vs LLM 2C — review compartment count</li><li>1C volume normalization: Q63→Q61 (single-compartment model has no central/peripheral split; 'Vcd (liter)' is the general volume)</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of TLAG: primary's parameterization (rate-constant / ka-only) does not use it</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Temozolomide_Bsker2022_reference;
