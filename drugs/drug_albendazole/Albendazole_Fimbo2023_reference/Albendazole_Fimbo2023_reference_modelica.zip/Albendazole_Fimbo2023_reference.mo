model Albendazole_Fimbo2023_reference
  parameter Real Cl_ref = 2.1383333333333338e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.1461 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C_enteral(
    weight = 70.0,
    F = 0.9,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.26533100000000004,
    adminMass = 0.0004,
    ka = 0.00019672222222222224,
    Tlag = 0.0,
    k12 = 3.882424518974827e-05,
    k21 = 2.738880841246848e-05
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About albendazole</h4><p>Albendazole is an anthelmintic and antiparasitic medicine used to treat worm and protozoal infections such as parasitic helminthiasis, cysticercosis, echinococcosis, giardiasis, and various roundworm and tapeworm diseases. It is widely used in human medicine and is also approved for veterinary use, and it appears on the WHO list of essential medicines.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q411629\">Wikidata Q411629</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>albendazole</td></tr><tr><td>population:</td><td>review reference</td></tr><tr><td>source_paper:</td><td>Fimbo_2023</td></tr><tr><td>measured_compound:</td><td>albendazole</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_2C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>albendazole 265.331 g/mol (drugbank)</td></tr></table><p><b>Defaulted (base-class default used):</b> F, Tlag.</p><h4>Interpretation flags</h4><ul><li>built from REVIEW reference values (Fimbo_2023) — secondary source</li><li>volume reported by review</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 259200, Tolerance = 1e-9, Interval = 1));
end Albendazole_Fimbo2023_reference;
