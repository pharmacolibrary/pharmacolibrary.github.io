function p = Albendazole_Fimbo2023_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: albendazole   source: Fimbo_2023 / reference   route: oral
  % estimated (absent from source): F
  p.name  = 'Albendazole_Fimbo2023_reference_params';
  p.drug  = 'albendazole';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 146.1;                % central volume [L]
  p.CL = 7.698;                % clearance [L/h]
  p.Vp = [207.1];             % peripheral volumes [L]
  p.Q  = [20.42];             % inter-compartmental clearances [L/h]
  p.ka = 0.7082;                % absorption rate [1/h]
  p.F  = 0.9;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 400.0;             % dose [mg]
end
