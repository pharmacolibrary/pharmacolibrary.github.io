model Albendazole_Formentini2001_reference
  parameter Real Cl_ref = 5.833333333333334e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.027800000000000002 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.26533100000000004,
    adminMass = 1e-05
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About albendazole</h4><p>Albendazole is an anthelmintic and antiparasitic medicine used to treat worm and protozoal infections such as parasitic helminthiasis, cysticercosis, echinococcosis, giardiasis, and various roundworm and tapeworm diseases. It is widely used in human medicine and is also approved for veterinary use, and it appears on the WHO list of essential medicines.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q411629\">Wikidata Q411629</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>albendazole</td></tr><tr><td>population:</td><td>review reference</td></tr><tr><td>source_paper:</td><td>Formentini_2001</td></tr><tr><td>measured_compound:</td><td>albendazole</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>albendazole 265.331 g/mol (drugbank)</td></tr></table><h4>Interpretation flags</h4><ul><li>built from REVIEW reference values (Formentini_2001) — secondary source</li><li>volume reported by review</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Albendazole_Formentini2001_reference;
