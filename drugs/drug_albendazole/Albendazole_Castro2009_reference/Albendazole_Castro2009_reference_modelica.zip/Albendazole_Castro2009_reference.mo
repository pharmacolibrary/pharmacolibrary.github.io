model Albendazole_Castro2009_reference
  parameter Real Cl_ref = 3.963888888888889e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.881 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.28132999999999997,
    adminMass = 0.0004,
    ka = 0.00019672222222222224,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About albendazole</h4><p>Albendazole is an anthelmintic and antiparasitic medicine used to treat worm and protozoal infections such as parasitic helminthiasis, cysticercosis, echinococcosis, giardiasis, and various roundworm and tapeworm diseases. It is widely used in human medicine and is also approved for veterinary use, and it appears on the WHO list of essential medicines.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q411629\">Wikidata Q411629</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>albendazole</td></tr><tr><td>population:</td><td>patients with neurocysticercosis</td></tr><tr><td>source_paper:</td><td>Castro_2009</td></tr><tr><td>measured_compound:</td><td>albendazole sulfoxide</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>albendazole 265.331 g/mol (drugbank); albendazole sulfoxide 281.33 g/mol (pubchem)</td></tr></table><p><b>Defaulted (base-class default used):</b> Tlag.</p><h4>Interpretation flags</h4><ul><li>dropped unlinked row (NIL): 'proportion of total population in subpopulation' — extend the ontology if this is a real PK parameter (source ['Castro_2009:abstract'])</li><li>routed 'Interindividual variability in CL/F' → Q312 (IIV) to iiv — variability estimate, not a structural parameter</li><li>metabolite albendazole sulfoxide: Q27→Q351 — only the metabolite is measured and fm is not identifiable, so its CL/V are apparent (fm-divided)</li><li>metabolite albendazole sulfoxide: Q76→Q367 — only the metabolite is measured and fm is not identifiable, so its CL/V are apparent (fm-divided)</li><li>apparent-ness (ontology-grounded): parameterization=apparent, measured_compound=albendazole sulfoxide</li><li>held at status:extracted — NIL link or unit issue (mismatch/unknown/normalisation-failed) present</li><li>template fit: PK_3M_9C — formed from central; parent 1, metabolites [0]</li><li>status held at route_to_review — not promoted</li><li>row roles (LLM): model_class=compartmental; 6/6 row label(s) assigned, 2 linked by role; re-tagged albendazole sulfoxide→parent ×4</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li><li>gap-filled Q27 (CL/F) from Algorta_2022's review values (primary lacked it)</li><li>gap-filled Q76 (V/F) from Algorta_2022's review values (primary lacked it)</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li><li>gap-filled Q49 (kabs) from Fimbo_2023's review values (primary lacked it)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 864000, Tolerance = 1e-9, Interval = 1));
end Albendazole_Castro2009_reference;
