% Run (SimBiology): build model + dose, simulate 0..40.0 h, plot.
p = Lomustine_Rodn2015_reference_params();
[model, dose, variant] = build_sb_pk(p);
sd = simulate_sb(model, variant, dose, 40.0);
