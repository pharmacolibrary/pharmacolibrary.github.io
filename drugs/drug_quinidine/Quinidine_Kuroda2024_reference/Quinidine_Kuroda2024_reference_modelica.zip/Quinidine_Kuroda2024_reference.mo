model Quinidine_Kuroda2024_reference
  parameter Real Cl_ref = 1.361111111111111e-07 "Cl [m3/s]";
  parameter Real Vd_ref = 0.00063 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C_enteral(
    weight = 70.0,
    F = 36.4,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.3244168,
    adminMass = 0.00035,
    ka = 0.0002777777777777778,
    Tlag = 0.0,
    k12 = 0.0012654320987654322,
    k21 = 0.0013512241054613936
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About quinidine</h4><p>Quinidine is a class Ia antiarrhythmic used to treat heart rhythm problems such as atrial fibrillation. It is an approved medicine, though it is not widely used today and has largely been replaced by newer antiarrhythmic drugs.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q412496\">Wikidata Q412496</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>quinidine</td></tr><tr><td>population:</td><td>Thoroughbred racehorses</td></tr><tr><td>source_paper:</td><td>Kuroda_2024</td></tr><tr><td>measured_compound:</td><td>quinidine</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>tab1</td></tr><tr><td>input:</td><td>PK_2C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>quinidine 324.417 g/mol (drugbank)</td></tr></table><p><b>Defaulted (base-class default used):</b> Tlag.</p><h4>Interpretation flags</h4><ul><li>table section iiv: 'V1' routed out of structural estimates ('BSV%')</li><li>table section iiv: 'V2' routed out of structural estimates ('BSV%')</li><li>table section iiv: 'V3' routed out of structural estimates ('BSV%')</li><li>table section iiv: 'CL' routed out of structural estimates ('BSV%')</li><li>table section iiv: 'CL2' routed out of structural estimates ('BSV%')</li><li>table section iiv: 'CL3' routed out of structural estimates ('BSV%')</li><li>table section iiv: 'Kabs' routed out of structural estimates ('BSV%')</li><li>table section iiv: 'F' routed out of structural estimates ('BSV%')</li><li>column 'units' classified 'other' by the LLM but kept: the deterministic diagnostic-column test disagrees (a stratum column is a value column, not a statistic)</li><li>dropped unlinked row (NIL): 'CL3' — extend the ontology if this is a real PK parameter (source ['tab1:row6:col2', 'tab1:row6:col3', 'tab1:row6:col4', 'tab1:row6:col5'])</li><li>unit_dimension_unknown: 'steady-state volume of distribution' (Vss)</li><li>unit_dimension_unknown: 'Mean residence time' (MRT)</li><li>implicit units: 'V1' → L (from the popPK convention: 'V1 is a volume of distribution. In population PK, volumes are typically reported in liters (L). The value 0.63 is consis')</li><li>implicit units: 'V2' → L (from the popPK convention: 'V2 is a volume of distribution. Standard unit for volume parameters in PK is liters (L).')</li><li>implicit units: 'V3' → L (from the popPK convention: 'V3 is a volume of distribution. Standard unit for volume parameters in PK is liters (L).')</li><li>implicit units: 'CL' → L/h (from the popPK convention: 'CL is plasma clearance. Standard unit for clearance in population PK is liters per hour (L/h). The value 0.49 is consist')</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Quinidine_Kuroda2024_reference;
