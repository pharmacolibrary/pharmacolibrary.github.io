function p = Quinidine_Kuroda2024_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: quinidine   source: Kuroda_2024 / reference   route: oral
  p.name  = 'Quinidine_Kuroda2024_reference_params';
  p.drug  = 'quinidine';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 0.63;                % central volume [L]
  p.CL = 0.49;                % clearance [L/h]
  p.Vp = [0.59];             % peripheral volumes [L]
  p.Q  = [2.87];             % inter-compartmental clearances [L/h]
  p.ka = 1.0;                % absorption rate [1/h]
  p.F  = 0.364;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 350.0;             % dose [mg]
end
