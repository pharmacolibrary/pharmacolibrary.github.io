model Riociguat_Saleh2016_reference
  parameter Real Cl_ref = 5.027777777777779e-07 "Cl [m3/s]";
  parameter Real Vd_ref = 0.032299999999999995 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 0.9,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.4224157,
    adminMass = 4.5e-06,
    ka = 0.0006027777777777777,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>riociguat</td></tr><tr><td>population:</td><td>patients with pulmonary arterial hypertension or chronic thromboembolic pulmonary hypertension</td></tr><tr><td>source_paper:</td><td>Saleh_2016</td></tr><tr><td>measured_compound:</td><td>riociguat</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>riociguat 422.416 g/mol (drugbank)</td></tr></table><p><b>Defaulted (base-class default used):</b> F, Tlag.</p><h4>Interpretation flags</h4><ul><li>PK_3M template not built: formation of M1 is not quantified (no CLfm, fm, kfm)</li><li>PK_3M template not built: formation of M1 is not quantified (no CLfm, fm, kfm)</li><li>unit_dimension_unknown: '% increase' (CL)</li><li>dropped duplicate Q22 ('Riociguat clearance', value 120) — already have one for this compound</li><li>metabolite volume: 'M1 volume of distribution' Q63→Q61 for M1 — it is 1-compartment, so its central volume is its only volume</li><li>apparent-by-design (ADVISORY, codes unchanged): extravascular dosing with no identifiable F, so these reported disposition parameters are likely apparent unless the model puts first-pass in its structure — Q22 (riociguat clearance); Q61 (riociguat volume of distribution); Q22 (M1 clearance); Q61 (M1 volume of distribution)</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=riociguat</li><li>template fit: PK_Parent_Metabolite — one metabolite formed from central, both 1-compartment</li><li>row roles (LLM): model_class=compartmental; 7/7 row label(s) assigned, 6 linked by role; re-tagged riociguat→parent ×5, riociguat→M1 ×3</li><li>molar mass: no plausible PubChem entry for 'M1' ('riociguat N-oxide') — left in mass units</li><li>molar mass: none found for 'M1' — its concentrations stay mass-only</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li><li>skipped review gap-fill of V2: primary is PARENT_METABOLITE (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is PARENT_METABOLITE (peripheral family needs ≥2C)</li><li>skipped review gap-fill of TLAG: primary's parameterization (rate-constant / ka-only) does not use it</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 259200, Tolerance = 1e-9, Interval = 1));
end Riociguat_Saleh2016_reference;
