model Oxycodone_Shi2026_reference
  parameter Real Cl_ref = 1.056388888888889e-05 "Cl [m3/s]";
  parameter Real Vd_ref = 0.25075000000000003 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.3153636,
    adminMass = 3e-05
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About oxycodone</h4><p>Oxycodone is an opioid painkiller used to treat pain, including pain from injury and conditions such as fibromyalgia. It is widely used and appears on the WHO list of essential medicines, though it carries a boxed warning and is also misused illicitly.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q407535\">Wikidata Q407535</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>oxycodone</td></tr><tr><td>population:</td><td>review reference</td></tr><tr><td>source_paper:</td><td>Shi_2026</td></tr><tr><td>measured_compound:</td><td>oxycodone</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>oxycodone 315.364 g/mol (drugbank)</td></tr></table><h4>Interpretation flags</h4><ul><li>built from REVIEW reference values (Shi_2026) — secondary source</li><li>volume reported by review</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Oxycodone_Shi2026_reference;
