model Oxycodone_Morse2021_reference
  parameter Real Cl_ref = 0.0009450000000000001 "Cl [m3/s]";
  parameter Real Vd_ref = 6.8740000000000006 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.3153636,
    adminMass = 3e-05,
    k12 = 0.0006223127404390134,
    k21 = 0.0006782587248735972
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About oxycodone</h4><p>Oxycodone is an opioid painkiller used to treat pain, including pain from injury and conditions such as fibromyalgia. It is widely used and appears on the WHO list of essential medicines, though it carries a boxed warning and is also misused illicitly.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q407535\">Wikidata Q407535</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>oxycodone</td></tr><tr><td>population:</td><td>preterm neonates to adults</td></tr><tr><td>source_paper:</td><td>Morse_2021</td></tr><tr><td>measured_compound:</td><td>oxycodone</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_2C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>oxycodone 315.364 g/mol (drugbank)</td></tr></table><h4>Interpretation flags</h4><ul><li>dropped unlinked row (NIL): 'TABS' — extend the ontology if this is a real PK parameter (source ['Morse_2021:abstract', 'Morse_2021:abstract', 'Morse_2021:abstract', 'Morse_2021:abstract'])</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=oxycodone</li><li>held at status:extracted — NIL link or unit issue (mismatch/unknown/normalisation-failed) present</li><li>structure disagreement: deterministic 2C vs LLM 3C — review compartment count</li><li>status held at route_to_review — not promoted</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Oxycodone_Morse2021_reference;
