function p = Oxycodone_Morse2021_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: oxycodone   source: Morse_2021 / reference   route: iv_bolus
  p.name  = 'Oxycodone_Morse2021_reference_params';
  p.drug  = 'oxycodone';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'iv_bolus';        % 'oral' | 'iv_bolus'
  p.depot = false;             % oral -> first-order absorption depot
  p.Vc = 6874.0;                % central volume [L]
  p.CL = 3402.0;                % clearance [L/h]
  p.Vp = [6307.0];             % peripheral volumes [L]
  p.Q  = [15400.0];             % inter-compartmental clearances [L/h]
  p.ka = 0.0;                % absorption rate [1/h]
  p.F  = 0.673;                 % bioavailability [0-1]
  p.Tlag = 0.145;             % absorption lag [h]
  p.dose = 30.0;             % dose [mg]
end
