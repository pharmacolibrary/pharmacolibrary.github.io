model Epcoritamab_Li2025_reference
  parameter Real Cl_ref = 6.13425925925926e-09 "Cl [m3/s]";
  parameter Real Vd_ref = 0.0256 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    adminMass = 0.0001,
    ka = 0.0001388888888888889,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About epcoritamab</h4><p>Epcoritamab, a monoclonal antibody anticancer drug, is used to treat diffuse large B-cell lymphoma. It is approved and authorised in the European Union, with one authorised product there, and remains under investigation for further uses.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q119025940\">Wikidata Q119025940</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>epcoritamab</td></tr><tr><td>population:</td><td>adults with relapsed or refractory B-cell non-Hodgkin lymphoma</td></tr><tr><td>source_paper:</td><td>Li_2025</td></tr><tr><td>measured_compound:</td><td>epcoritamab</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C_enteral: apparent (/F) parameterization ⇒ extravascular dosing</td></tr></table><p><b>Defaulted (base-class default used):</b> ka, Tlag.</p><h4>Interpretation flags</h4><ul><li>apparent-ness (ontology-grounded): parameterization=apparent, measured_compound=epcoritamab</li><li>molar mass: none found for 'epcoritamab' — its concentrations stay mass-only</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 9676800, Tolerance = 1e-9, Interval = 1));
end Epcoritamab_Li2025_reference;
