model Ampicillin_Bardhi2026_reference
  parameter Real Cl_ref = 6.4166666666666665e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.0308 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.34940499999999997,
    adminMass = 0.006
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About ampicillin</h4><p>Ampicillin is a penicillin antibiotic used to treat a range of bacterial infections, including urinary tract infections, meningitis, and respiratory infections. It is an approved medicine on the WHO essential medicines list and is also approved for veterinary use.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q244150\">Wikidata Q244150</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>ampicillin</td></tr><tr><td>population:</td><td>review reference</td></tr><tr><td>source_paper:</td><td>Bardhi_2026</td></tr><tr><td>measured_compound:</td><td>ampicillin</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>ampicillin 349.405 g/mol (drugbank)</td></tr></table><h4>Interpretation flags</h4><ul><li>built from REVIEW reference values (Bardhi_2026) — secondary source</li><li>volume reported by review</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Ampicillin_Bardhi2026_reference;
