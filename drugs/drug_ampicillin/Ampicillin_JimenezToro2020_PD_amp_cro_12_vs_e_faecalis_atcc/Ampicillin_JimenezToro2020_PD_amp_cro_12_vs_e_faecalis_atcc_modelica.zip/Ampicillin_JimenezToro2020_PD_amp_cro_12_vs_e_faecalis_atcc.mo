model Ampicillin_JimenezToro2020_PD_amp_cro_12_vs_e_faecalis_atcc
  "sigmoid_emax exposure-response sweep — Jimenez-Toro_2020 :: AMP + CRO (12) vs E. faecalis ATCC 29212 (bacterial killing)"
  extends Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep(
    E0 = 0,      // [1]
    Emax = -4.34,  // [log10 CFU/g]
    EC50 = 1.36342592593e-09,  // [1/s; mg/kg/day × 1.15741e-11]
    gamma = 3.96,
    exposure_per_s = 1.15740740741e-11);   // 1 mg/kg/day per second
  // imax_as_negative_emax: Imax (Q323) enters SigmoidEmaxSweep as −Emax
  // defaulted: E0
  annotation(experiment(StartTime = 0, StopTime = 1200, Interval = 2.4),
    Documentation(info = "<html><body><!-- drug-about --><h4>About ampicillin</h4><p>Ampicillin is a penicillin antibiotic used to treat a range of bacterial infections, including urinary tract infections, meningitis, and respiratory infections. It is an approved medicine on the WHO essential medicines list and is also approved for veterinary use.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q244150\">Wikidata Q244150</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h4>Ampicillin_JimenezToro2020_PD_amp_cro_12_vs_e_faecalis_atcc</h4><p>The steady-state exposure-response curve of Jimenez-Toro I et al., <i>PloS one 15(12):e0243365</i> 2020 (<a href=\"https://doi.org/10.1371/journal.pone.0243365\">doi:10.1371/journal.pone.0243365</a>) — bacterial killing [log10 CFU/g] against ampicillin mg/kg/day — obtained by sweeping the driver instead of simulating a dose. Model family: sigmoid_emax.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = (library default) drug-free response (baseline)
  Emax  =       4.34 log10 CFU/g maximal effect term (Emax, Q323)
  EC50  =      117.8 mg/kg/day exposure at half of the maximal effect term (ED50, Q321)
  gamma =       3.96          Hill coefficient (Hill’s slope, Q325)</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep\">SigmoidEmaxSweep</a>; this model only supplies the numbers. The x axis is one mg/kg/day of ampicillin per second of simulated time (exposure is in 1/s): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0   (drug-free)
  exposure = EC50 (117.8 mg/kg/day)  response -2.17
  exposure -> infinity  response -4.34</pre></body></html>"));
end Ampicillin_JimenezToro2020_PD_amp_cro_12_vs_e_faecalis_atcc;
