function p = Ampicillin_JimenezToro2020_PD_amp_cro_12_vs_e_faecalis_atcc_params()
% Ampicillin_JimenezToro2020_PD_amp_cro_12_vs_e_faecalis_atcc_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% ampicillin Jimenez-Toro_2020::AMP_CRO_12_vs_E_faecalis_ATCC_29212: sigmoid_emax exposure-response sweep (response = E0 + Emax*frac). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one mg/kg/day per second, in SI inside (kg/m3, s). Response AMP + CRO (12) vs E. faecalis ATCC 29212 in log10 CFU/g. Driver: ampicillin (dose_only).
p.E0 = 0.0;
p.Emax = -4.34;
p.EC50 = 1.3634259259259258e-09;
p.gamma = 3.96;
p.slope = 0.0;
p.exposure_per_s = 1.15740740741e-11;
p.stop_time = 1200.0;
p.form = 'E0 + Emax*frac';
end
