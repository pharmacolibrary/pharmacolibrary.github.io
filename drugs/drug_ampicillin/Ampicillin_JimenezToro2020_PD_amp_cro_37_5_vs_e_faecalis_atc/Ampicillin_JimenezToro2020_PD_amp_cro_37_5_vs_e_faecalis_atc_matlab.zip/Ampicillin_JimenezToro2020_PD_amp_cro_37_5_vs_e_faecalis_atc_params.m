function p = Ampicillin_JimenezToro2020_PD_amp_cro_37_5_vs_e_faecalis_atc_params()
% Ampicillin_JimenezToro2020_PD_amp_cro_37_5_vs_e_faecalis_atc_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% ampicillin Jimenez-Toro_2020::AMP_CRO_37_5_vs_E_faecalis_ATCC_29212: sigmoid_emax exposure-response sweep (response = E0 + Emax*frac). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one mg/kg/day per second, in SI inside (kg/m3, s). Response AMP + CRO (37.5) vs E. faecalis ATCC 29212 in log10 CFU/g. Driver: ampicillin (dose_only).
p.E0 = 0.0;
p.Emax = -4.86;
p.EC50 = 5.972222222222223e-10;
p.gamma = 2.18;
p.slope = 0.0;
p.exposure_per_s = 1.15740740741e-11;
p.stop_time = 520.0;
p.form = 'E0 + Emax*frac';
end
