model Ampicillin_Gastine2022_reference
  parameter Real Cl_ref = 1.9138888888888886e-06 "Cl [m3/s]";
  parameter Real cov_creatinine_0 = 0 "creatinine covariate";
  parameter Real Vd_ref = 0.0264 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C_enteral(
    weight = 70.0,
    F = 0.9,
    Cl = Cl_ref*(1 + (-0.423)*cov_creatinine_0),
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    adminMass = 0.0035,
    ka = 0.0017916666666666667,
    Tlag = 0.0,
    k21 = 3.969440292310247e-05
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About ampicillin</h4><p>Ampicillin is a penicillin antibiotic used to treat a range of bacterial infections, including urinary tract infections, meningitis, and respiratory infections. It is an approved medicine on the WHO essential medicines list and is also approved for veterinary use.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q244150\">Wikidata Q244150</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>ampicillin</td></tr><tr><td>population:</td><td>neonates</td></tr><tr><td>source_paper:</td><td>Gastine_2022</td></tr><tr><td>measured_compound:</td><td>ampicillin and gentamicin</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>dkab413-T2</td></tr><tr><td>input:</td><td>PK_2C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>ampicillin 349.405 g/mol (drugbank)</td></tr></table><p><b>Defaulted (base-class default used):</b> F, Tlag, k12.</p><h4>Interpretation flags</h4><ul><li>table section iiv: 'CLGFR (L/h)' routed out of structural estimates ('IIV (%) (RSE, %)')</li><li>table section iiv: 'Central VdGent (L)' routed out of structural estimates ('IIV (%) (RSE, %)')</li><li>table section iiv: 'CLnon-GFR (L/h)' routed out of structural estimates ('IIV (%) (RSE, %)')</li><li>dropped duplicate Q22 ('CLnon-GFR (L/h)', value '5.3') — already have one for this compound</li><li>dropped duplicate Q63 ('Central VdAmp (L)', value '52.7') — already have one for this compound</li><li>dropped unlinked row (NIL): 'PNAfract (%)' — extend the ontology if this is a real PK parameter (source ['dkab413-T2:row7:col1'])</li><li>dropped unlinked row (NIL): 'PNAcoeff' — extend the ontology if this is a real PK parameter (source ['dkab413-T2:row8:col1'])</li><li>covariate level 'Creatinine on CLGFR' → Q900:creatinine_on_clgfr = -0.423 (linear_fractional on Q22)</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=ampicillin and gentamicin</li><li>molar mass: no plausible PubChem entry for 'ampicillin and gentamicin' ('ampicillin and gentamicin') — left in mass units</li><li>molar mass: none found for 'ampicillin and gentamicin' — its concentrations stay mass-only</li><li>gap-filled Q49 (kabs) from Jimenez-Toro_2020's review values (primary lacked it)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Ampicillin_Gastine2022_reference;
