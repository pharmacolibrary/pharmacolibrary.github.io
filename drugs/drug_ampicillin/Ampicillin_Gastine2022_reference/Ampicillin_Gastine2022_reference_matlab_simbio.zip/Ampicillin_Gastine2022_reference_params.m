function p = Ampicillin_Gastine2022_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: ampicillin   source: Gastine_2022 / reference   route: oral
  % estimated (absent from source): F
  p.name  = 'Ampicillin_Gastine2022_reference_params';
  p.drug  = 'ampicillin';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 26.4;                % central volume [L]
  p.CL = 6.89;                % clearance [L/h]
  p.Vp = [6.69];             % peripheral volumes [L]
  p.Q  = [0.956];             % inter-compartmental clearances [L/h]
  p.ka = 6.45;                % absorption rate [1/h]
  p.F  = 0.9;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 3500.0;             % dose [mg]
end
