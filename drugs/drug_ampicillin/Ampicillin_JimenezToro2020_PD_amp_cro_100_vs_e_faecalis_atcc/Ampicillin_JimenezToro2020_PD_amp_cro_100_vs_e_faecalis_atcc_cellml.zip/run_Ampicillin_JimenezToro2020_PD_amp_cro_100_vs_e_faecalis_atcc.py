#!/usr/bin/env python3
"""Sweep Ampicillin_JimenezToro2020_PD_amp_cro_100_vs_e_faecalis_atcc.cellml — the curve is evaluated directly (one ODE for the swept exposure and
one algebraic response), so no CellML tooling is needed; OpenCOR opens the file as-is.
Writes Ampicillin_JimenezToro2020_PD_amp_cro_100_vs_e_faecalis_atcc.csv/.json/.png next to this script."""
import json, os, math
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

BASE = os.path.join(os.path.dirname(os.path.abspath(__file__)), "Ampicillin_JimenezToro2020_PD_amp_cro_100_vs_e_faecalis_atcc")
E0, Emax, EC50, gamma, slope, exposure_per_s = 0.0, -4.88, 2.974537037037037e-10, 0.88, 0.0, 1.15740740741e-11
def response(exposure):
    frac = exposure**gamma / (EC50**gamma + exposure**gamma) if exposure > 0 else 0.0
    log = math.log
    return E0 + Emax*(exposure**gamma / (EC50**gamma + exposure**gamma))
x = [exposure_per_s * 260.0 * i / 500 for i in range(501)]
y = [response(v) for v in x]
with open(BASE + ".csv", "w") as f:
    f.write("exposure_si,response\n")
    for xi, yi in zip(x, y):
        f.write("%r,%r\n" % (xi, yi))
with open(BASE + ".json", "w") as f:
    json.dump({"model": "Ampicillin_JimenezToro2020_PD_amp_cro_100_vs_e_faecalis_atcc", "exposure_si": x, "response": y}, f, indent=2)
plt.figure(); plt.plot(x, y, linewidth=1.5)
plt.xlabel("exposure [mg/kg/day]"); plt.ylabel("response [log10 CFU/g]")
plt.title("Ampicillin_JimenezToro2020_PD_amp_cro_100_vs_e_faecalis_atcc"); plt.grid(True, alpha=0.3); plt.tight_layout(); plt.savefig(BASE + ".png", dpi=150)
print("wrote %s.csv, %s.json, %s.png" % (BASE, BASE, BASE))
