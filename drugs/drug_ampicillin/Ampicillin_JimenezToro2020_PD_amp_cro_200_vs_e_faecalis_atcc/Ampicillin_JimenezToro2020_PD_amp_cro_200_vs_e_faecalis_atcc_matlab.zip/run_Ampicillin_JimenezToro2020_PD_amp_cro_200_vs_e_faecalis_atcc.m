% run_Ampicillin_JimenezToro2020_PD_amp_cro_200_vs_e_faecalis_atcc  Evaluate the exposure-response curve and plot response against exposure.
% A sweep is a static map: no ODE solver is needed. exposure runs 0..stop_time*exposure_per_s.
p = Ampicillin_JimenezToro2020_PD_amp_cro_200_vs_e_faecalis_atcc_params();
exposure = linspace(0, p.stop_time * p.exposure_per_s, 501);
frac = exposure.^p.gamma ./ (p.EC50^p.gamma + exposure.^p.gamma);
E0 = p.E0; Emax = p.Emax; slope = p.slope;
response = E0 + Emax.*frac;
figure; plot(exposure, response, 'LineWidth', 1.5); grid on;
xlabel('exposure [mg/kg/day]'); ylabel('response [log10 CFU/g]'); title('Ampicillin_JimenezToro2020_PD_amp_cro_200_vs_e_faecalis_atcc', 'Interpreter', 'none');
writematrix([exposure(:) response(:)], 'Ampicillin_JimenezToro2020_PD_amp_cro_200_vs_e_faecalis_atcc.csv');
