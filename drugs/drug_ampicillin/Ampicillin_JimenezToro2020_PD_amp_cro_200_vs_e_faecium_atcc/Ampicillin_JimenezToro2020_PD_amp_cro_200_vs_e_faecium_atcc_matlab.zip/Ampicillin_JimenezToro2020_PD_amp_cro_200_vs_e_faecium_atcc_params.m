function p = Ampicillin_JimenezToro2020_PD_amp_cro_200_vs_e_faecium_atcc_params()
% Ampicillin_JimenezToro2020_PD_amp_cro_200_vs_e_faecium_atcc_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% ampicillin Jimenez-Toro_2020::AMP_CRO_200_vs_E_faecium_ATCC_19434: sigmoid_emax exposure-response sweep (response = E0 + Emax*frac). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one mg/kg/day per second, in SI inside (kg/m3, s). Response AMP + CRO (200) vs E. faecium ATCC 19434 in log10 CFU/g. Driver: ampicillin (dose_only).
p.E0 = 0.0;
p.Emax = -7.65;
p.EC50 = 2.287037037037037e-09;
p.gamma = 3.81;
p.slope = 0.0;
p.exposure_per_s = 1.15740740741e-11;
p.stop_time = 2000.0;
p.form = 'E0 + Emax*frac';
end
