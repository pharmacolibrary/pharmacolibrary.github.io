model Ampicillin_Judy2024_reference
  parameter Real Cl_ref = 2.2888888888888888e-05 "Cl [m3/s]";
  parameter Real Vd_ref = 0.0752 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C_enteral(
    weight = 70.0,
    F = 0.9,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.34940499999999997,
    adminMass = 0.002,
    ka = 0.0017916666666666667,
    Tlag = 0.0,
    k12 = 7.720153664302599e-05,
    k21 = 9.501727586833969e-05
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About ampicillin</h4><p>Ampicillin is a penicillin antibiotic used to treat a range of bacterial infections, including urinary tract infections, meningitis, and respiratory infections. It is an approved medicine on the WHO essential medicines list and is also approved for veterinary use.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q244150\">Wikidata Q244150</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>ampicillin</td></tr><tr><td>population:</td><td>peripartum and laboring women</td></tr><tr><td>source_paper:</td><td>Judy_2024</td></tr><tr><td>measured_compound:</td><td>ampicillin</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_2C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>ampicillin 349.405 g/mol (drugbank)</td></tr></table><p><b>Defaulted (base-class default used):</b> F, Tlag.</p><h4>Interpretation flags</h4><ul><li>routed 'Interpatient variation in CL' → Q312 (IIV) to iiv — variability estimate, not a structural parameter</li><li>routed 'Interpatient variation in V1' → Q312 (IIV) to iiv — variability estimate, not a structural parameter</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=ampicillin</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li><li>gap-filled Q49 (kabs) from Jimenez-Toro_2020's review values (primary lacked it)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Ampicillin_Judy2024_reference;
