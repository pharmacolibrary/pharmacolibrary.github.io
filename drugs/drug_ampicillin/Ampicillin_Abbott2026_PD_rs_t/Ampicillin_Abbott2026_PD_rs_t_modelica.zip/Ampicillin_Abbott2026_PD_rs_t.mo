model Ampicillin_Abbott2026_PD_rs_t
  "sigmoid_emax exposure-response sweep — Abbott_2026 :: rS→T (Switching rate to transiently tolerant state)"
  extends Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep(
    E0 = 0,      // [1]
    Emax = 0.000483333333333,  // [1/s; h-1 × 0.000277778]
    EC50 = 0.0326,  // [kg/m3; μg mL-1 × 0.001]
    gamma = 2.36,
    exposure_per_s = 0.001);   // 1 μg mL-1 per second
  // defaulted: E0
  annotation(experiment(StartTime = 0, StopTime = 330, Interval = 0.66),
    Documentation(info = "<html><body><!-- drug-about --><h4>About ampicillin</h4><p>Ampicillin is a penicillin antibiotic used to treat a range of bacterial infections, including urinary tract infections, meningitis, and respiratory infections. It is an approved medicine on the WHO essential medicines list and is also approved for veterinary use.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q244150\">Wikidata Q244150</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h4>Ampicillin_Abbott2026_PD_rs_t</h4><p>The steady-state exposure-response curve of Abbott K et al., <i>Advanced science (Weinheim, Baden-Wurttemberg, Germany) 13(44):e21993</i> 2026 (<a href=\"https://doi.org/10.1002/advs.202521993\">doi:10.1002/advs.202521993</a>) — Switching rate to transiently tolerant state [h-1] against ampicillin μg mL-1 — obtained by sweeping the driver instead of simulating a dose. Model family: sigmoid_emax.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = (library default) drug-free response (baseline)
  Emax  =       1.74 h-1      maximal effect term (Maximal S→T switching rate, Q320)
  EC50  =       32.6 μg mL-1  exposure at half of the maximal effect term (Half‐maximal concentration for rS→T, Q321)
  gamma =       2.36          Hill coefficient (Hill coefficient for rS→T, Q325)</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep\">SigmoidEmaxSweep</a>; this model only supplies the numbers. The x axis is one μg mL-1 of ampicillin per second of simulated time (exposure is in kg/m3): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0   (drug-free)
  exposure = EC50 (32.6 μg mL-1)  response 0.0002417
  exposure -> infinity  response 0.0004833</pre></body></html>"));
end Ampicillin_Abbott2026_PD_rs_t;
