function p = Ampicillin_Abbott2026_PD_rs_t_params()
% Ampicillin_Abbott2026_PD_rs_t_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% ampicillin Abbott_2026::rS_T: sigmoid_emax exposure-response sweep (response = E0 + Emax*frac). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one μg mL-1 per second, in SI inside (kg/m3, s). Response rS→T in h-1. Driver: ampicillin (cited_pk).
p.E0 = 0.0;
p.Emax = 0.00048333333333333334;
p.EC50 = 0.0326;
p.gamma = 2.36;
p.slope = 0.0;
p.exposure_per_s = 0.001;
p.stop_time = 330.0;
p.form = 'E0 + Emax*frac';
end
