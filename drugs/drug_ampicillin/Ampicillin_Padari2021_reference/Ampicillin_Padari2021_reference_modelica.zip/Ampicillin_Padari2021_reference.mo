model Ampicillin_Padari2021_reference
  parameter Real Cl_ref = 5.555555555555556e-08 "Cl [m3/s]";
  parameter Real Vd_ref = 0.00107 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_3C_enteral(
    weight = 70.0,
    F = 0.9,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.34940499999999997,
    adminMass = 0.002,
    ka = 0.0017916666666666667,
    Tlag = 0.0,
    k12 = 0.0018354101765316719,
    k21 = 0.001890172174099027
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About ampicillin</h4><p>Ampicillin is a penicillin antibiotic used to treat a range of bacterial infections, including urinary tract infections, meningitis, and respiratory infections. It is an approved medicine on the WHO essential medicines list and is also approved for veterinary use.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q244150\">Wikidata Q244150</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>ampicillin</td></tr><tr><td>population:</td><td>preterm and term neonates</td></tr><tr><td>source_paper:</td><td>Padari_2021</td></tr><tr><td>measured_compound:</td><td>ampicillin</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>3C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_3C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>ampicillin 349.405 g/mol (drugbank)</td></tr></table><p><b>Defaulted (base-class default used):</b> F, Tlag, k13, k31.</p><h4>Interpretation flags</h4><ul><li>dropped duplicate Q22 ('CL', value 15.15) — already have one for this compound</li><li>dropped duplicate Q22 ('intercompartmental CL', value 0.39) — already have one for this compound</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=ampicillin</li><li>structure disagreement: deterministic 3C vs LLM 2C — review compartment count</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li><li>gap-filled Q30 (Q) from Onita_2023's review values (primary lacked it)</li><li>gap-filled Q49 (kabs) from Jimenez-Toro_2020's review values (primary lacked it)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 133200, Tolerance = 1e-9, Interval = 1));
end Ampicillin_Padari2021_reference;
