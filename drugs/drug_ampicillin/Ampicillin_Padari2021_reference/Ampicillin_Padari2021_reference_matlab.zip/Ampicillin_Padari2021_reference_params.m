function p = Ampicillin_Padari2021_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: ampicillin   source: Padari_2021 / reference   route: oral
  % estimated (absent from source): F
  p.name  = 'Ampicillin_Padari2021_reference_params';
  p.drug  = 'ampicillin';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 1.07;                % central volume [L]
  p.CL = 0.2;                % clearance [L/h]
  p.Vp = [1.039];             % peripheral volumes [L]
  p.Q  = [7.07];             % inter-compartmental clearances [L/h]
  p.ka = 6.45;                % absorption rate [1/h]
  p.F  = 0.9;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 2000.0;             % dose [mg]
end
