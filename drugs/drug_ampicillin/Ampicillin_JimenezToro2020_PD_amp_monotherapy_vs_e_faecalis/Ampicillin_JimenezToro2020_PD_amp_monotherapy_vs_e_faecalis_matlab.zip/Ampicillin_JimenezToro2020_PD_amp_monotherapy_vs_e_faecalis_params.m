function p = Ampicillin_JimenezToro2020_PD_amp_monotherapy_vs_e_faecalis_params()
% Ampicillin_JimenezToro2020_PD_amp_monotherapy_vs_e_faecalis_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% ampicillin Jimenez-Toro_2020::AMP_monotherapy_vs_E_faecalis_ATCC_51299: sigmoid_emax exposure-response sweep (response = E0 + Emax*frac). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one mg/kg/day per second, in SI inside (kg/m3, s). Response AMP monotherapy vs E. faecalis ATCC 51299 in log10 CFU/g. Driver: ampicillin (dose_only).
p.E0 = 0.0;
p.Emax = -4.77;
p.EC50 = 1.4849537037037037e-09;
p.gamma = 1.1;
p.slope = 0.0;
p.exposure_per_s = 1.15740740741e-11;
p.stop_time = 1300.0;
p.form = 'E0 + Emax*frac';
end
