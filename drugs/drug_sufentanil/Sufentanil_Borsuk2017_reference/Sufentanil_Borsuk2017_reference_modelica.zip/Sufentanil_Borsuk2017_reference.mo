model Sufentanil_Borsuk2017_reference
  parameter Real Cl_ref = 1.4611111111111112e-05 "Cl [m3/s]";
  parameter Real Vd_ref = 0.00763 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C_enteral(
    weight = 70.0,
    F = 0.9,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.386551,
    adminMass = 0.0001,
    ka = 1.2750000000000002e-05,
    Tlag = 0.0,
    k12 = 0.0014744429882044563,
    k21 = 2.3784355179704015e-05
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About sufentanil</h4><p>Sufentanil is a strong opioid used to treat pain, especially as an anesthetic adjunct and for postoperative pain relief. It remains in use, with an authorised product in the European Union, though it carries a boxed warning and is mainly used in controlled hospital settings such as anesthesia.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q417915\">Wikidata Q417915</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>sufentanil</td></tr><tr><td>population:</td><td>children and infants</td></tr><tr><td>source_paper:</td><td>Borsuk_2017</td></tr><tr><td>measured_compound:</td><td>sufentanil</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_2C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>sufentanil 386.551 g/mol (drugbank)</td></tr></table><p><b>Defaulted (base-class default used):</b> F, Tlag.</p><h4>Interpretation flags</h4><ul><li>dropped unlinked row (NIL): 'postmenstrual age of 50% clearance maturation' — extend the ontology if this is a real PK parameter (source ['Borsuk_2017:abstract'])</li><li>dropped PD-category row 'Hill coefficient' → Q325 (Hill, category G11) — pharmacodynamic parameters belong to scholarpd, not the PK model (source ['Borsuk_2017:abstract'])</li><li>apparent-by-design (ADVISORY, codes unchanged): extravascular dosing with no identifiable F, so these reported disposition parameters are likely apparent unless the model puts first-pass in its structure — Q22 (metabolic clearance (CL1)); Q30 (Q); Q63 (VC); Q64 (VT)</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=sufentanil</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li><li>skipped review gap-fill of TLAG: primary's parameterization (rate-constant / ka-only) does not use it</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 259200, Tolerance = 1e-9, Interval = 1));
end Sufentanil_Borsuk2017_reference;
