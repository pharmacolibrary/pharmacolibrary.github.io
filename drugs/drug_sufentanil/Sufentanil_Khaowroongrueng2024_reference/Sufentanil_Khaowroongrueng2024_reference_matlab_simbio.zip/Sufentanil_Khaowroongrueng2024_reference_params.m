function p = Sufentanil_Khaowroongrueng2024_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: sufentanil   source: Khaowroongrueng_2024 / reference   route: iv_bolus
  % estimated (absent from source): F, dose
  p.name  = 'Sufentanil_Khaowroongrueng2024_reference_params';
  p.drug  = 'sufentanil';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'iv_bolus';        % 'oral' | 'iv_bolus'
  p.depot = false;             % oral -> first-order absorption depot
  p.Vc = 72.5;                % central volume [L]
  p.CL = 51.8;                % clearance [L/h]
  p.Vp = [390.0];             % peripheral volumes [L]
  p.Q  = [55.2];             % inter-compartmental clearances [L/h]
  p.ka = 0.0;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 10.0;             % dose [mg]
end
