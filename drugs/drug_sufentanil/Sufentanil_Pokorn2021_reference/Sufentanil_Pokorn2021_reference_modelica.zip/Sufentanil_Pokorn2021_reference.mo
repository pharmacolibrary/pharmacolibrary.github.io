model Sufentanil_Pokorn2021_reference
  parameter Real Cl_ref = 1.2658333333333334e-05 "Cl [m3/s]";
  parameter Real Vd_ref = 0.329 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.386551,
    adminMass = 1e-05
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About sufentanil</h4><p>Sufentanil is a strong opioid used to treat pain, especially as an anesthetic adjunct and for postoperative pain relief. It remains in use, with an authorised product in the European Union, though it carries a boxed warning and is mainly used in controlled hospital settings such as anesthesia.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q417915\">Wikidata Q417915</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>sufentanil</td></tr><tr><td>population:</td><td>ventilated full-term neonates</td></tr><tr><td>source_paper:</td><td>Pokorná_2021</td></tr><tr><td>measured_compound:</td><td>sufentanil</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>sufentanil 386.551 g/mol (drugbank)</td></tr></table><h4>Interpretation flags</h4><ul><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=sufentanil</li><li>1C volume normalization: Q63→Q61 (single-compartment model has no central/peripheral split; 'central volume of distribution (Vdc)' is the general volume)</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 93600, Tolerance = 1e-9, Interval = 1));
end Sufentanil_Pokorn2021_reference;
