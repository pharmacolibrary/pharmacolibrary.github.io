model Sufentanil_Cox1998_PD_eeg
  "sigmoid_emax exposure-response sweep — Cox_1998 :: EEG (Amplitudes in the 0.5 to 4.5 Hz frequency band of the electroencephalogram (EEG))"
  extends Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep(
    E0 = 0,      // [1]
    Emax = 104,  // [microV]
    EC50 = 2.9e-07,  // [kg/m3; ng/ml × 1e-06]
    gamma = 1,
    exposure_per_s = 1e-06);   // 1 ng/ml per second
  // defaulted: E0
  // defaulted: gamma
  annotation(experiment(StartTime = 0, StopTime = 2.9, Interval = 0.0058),
    Documentation(info = "<html><body><!-- drug-about --><h4>About sufentanil</h4><p>Sufentanil is a strong opioid used to treat pain, especially as an anesthetic adjunct and for postoperative pain relief. It remains in use, with an authorised product in the European Union, though it carries a boxed warning and is mainly used in controlled hospital settings such as anesthesia.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q417915\">Wikidata Q417915</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h4>Sufentanil_Cox1998_PD_eeg</h4><p>The steady-state exposure-response curve of Cox EH et al., <i>The Journal of pharmacology and experimental therapeutics 284(3):1095–1103</i> 1998 — Amplitudes in the 0.5 to 4.5 Hz frequency band of the electroencephalogram (EEG) [microV] against sufentanil ng/ml — obtained by sweeping the driver instead of simulating a dose. Model family: sigmoid_emax.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = (library default) drug-free response (baseline)
  Emax  =        104 microV   maximal effect term (Emax, Q320)
  EC50  =       0.29 ng/ml    exposure at half of the maximal effect term (EC50,u, Q321)
  gamma = (library default) Hill coefficient</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep\">SigmoidEmaxSweep</a>; this model only supplies the numbers. The x axis is one ng/ml of sufentanil per second of simulated time (exposure is in kg/m3): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0   (drug-free)
  exposure = EC50 (0.29 ng/ml)  response 52
  exposure -> infinity  response 104</pre></body></html>"));
end Sufentanil_Cox1998_PD_eeg;
