function p = Sufentanil_Cox1998_PD_eeg_params()
% Sufentanil_Cox1998_PD_eeg_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% sufentanil Cox_1998::EEG: sigmoid_emax exposure-response sweep (response = E0 + Emax*frac). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one ng/ml per second, in SI inside (kg/m3, s). Response EEG in microV. Driver: sufentanil (cited_pk).
p.E0 = 0.0;
p.Emax = 104.0;
p.EC50 = 2.9e-07;
p.gamma = 1.0;
p.slope = 0.0;
p.exposure_per_s = 1e-06;
p.stop_time = 2.9;
p.form = 'E0 + Emax*frac';
end
