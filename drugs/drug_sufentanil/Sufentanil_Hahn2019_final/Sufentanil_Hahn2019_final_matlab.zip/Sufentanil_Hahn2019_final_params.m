function p = Sufentanil_Hahn2019_final_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: sufentanil   source: Hahn_2019 / final   route: iv_bolus
  % estimated (absent from source): F, dose
  p.name  = 'Sufentanil_Hahn2019_final_params';
  p.drug  = 'sufentanil';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'iv_bolus';        % 'oral' | 'iv_bolus'
  p.depot = false;             % oral -> first-order absorption depot
  p.Vc = 229.0;                % central volume [L]
  p.CL = 37.8;                % clearance [L/h]
  p.Vp = [1640.0];             % peripheral volumes [L]
  p.Q  = [41.0];             % inter-compartmental clearances [L/h]
  p.ka = 0.0;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 10.0;             % dose [mg]
end
