model Sufentanil_Hahn2019_final
  parameter Real Cl_ref = 1.05e-05 "Cl [m3/s]";
  parameter Real Vd_ref = 0.229 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.386551,
    adminMass = 1e-05,
    k12 = 4.973313925278991e-05,
    k21 = 6.944444444444445e-06
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About sufentanil</h4><p>Sufentanil is a strong opioid used to treat pain, especially as an anesthetic adjunct and for postoperative pain relief. It remains in use, with an authorised product in the European Union, though it carries a boxed warning and is mainly used in controlled hospital settings such as anesthesia.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q417915\">Wikidata Q417915</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>sufentanil</td></tr><tr><td>population:</td><td>critically ill patients supported with extracorporeal membrane oxygenation therapy</td></tr><tr><td>source_paper:</td><td>Hahn_2019</td></tr><tr><td>measured_compound:</td><td>sufentanil</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>Tab2</td></tr><tr><td>input:</td><td>PK_2C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>sufentanil 386.551 g/mol (drugbank)</td></tr></table><h4>Interpretation flags</h4><ul><li>table section iiv: 'ωCL2' routed out of structural estimates ('Inter-individual variability')</li><li>table section iiv: 'ωV22' routed out of structural estimates ('Inter-individual variability')</li><li>table section residual_error: 'σ2proportional' routed out of structural estimates ('Residual variability')</li><li>kept covariate coefficient ΘTemp=0.207 (covariate Temp) — not an ontology parameter</li><li>dropped unlinked row (NIL): 'ΘT.Prot' — extend the ontology if this is a real PK parameter (source ['Tab2:row9:col2', 'Tab2:row9:col3'])</li><li>implicit units: 'ΘCL' → L/h (from the paper text: &quot;In the Results section, the text states: 'decreased values for clearance (CL, 37.8 L h−1...)' and compares it to 'CL, 76&quot;)</li><li>implicit units: 'ΘV1' → L (from the paper text: &quot;In the Results section, the text states: 'increased Vd (V1, 229 L; V2, 1640 L...)' and compares it to 'V1, 37.1 L' in no&quot;)</li><li>implicit units: 'ΘV2' → L (from the paper text: &quot;In the Results section, the text states: 'increased Vd (V1, 229 L; V2, 1640 L...)' and compares it to 'V2, 92.7 L' in no&quot;)</li><li>implicit units: 'ΘQ' → L/h (from the paper text: &quot;In the Results section, the text states: 'decreased values for clearance (... Q, 41 L h−1)' and compares it to 'Q, 52.2 &quot;)</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=sufentanil</li><li>model-stage split: 'final model' is the final model of Hahn_2019 (paper reports 2 stages: final model, structural model (rse%) [shrinkage%]); same population, different model-building step</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Sufentanil_Hahn2019_final;
