function p = Osimertinib_Westra2025_reference_params()
% Auto-generated parent-metabolite PK model (clinical units: mg, L, h).
%   drug: osimertinib   source: Westra_2025 / reference   PK_3M_9C parent + 1 metabolite(s), 2 compartments, oral
%   dA/dt = K*A; C = A./V. K(i,j) is the rate [1/h] at which compartment j feeds i:
%   a metabolic conversion carries MW_dst/MW_src, so one molecule forms one molecule.
%   molar masses: C_central=499.619 g/mol C_M1=485.592 g/mol
  p.name  = 'Osimertinib_Westra2025_reference_params';
  p.drug  = 'osimertinib';
  p.kind  = 'network';
  p.template = 'PK_3M_9C';
  p.states = {'central', 'central_M1'};
  p.V = [966.0, 181.0];          % compartment volumes [L]
  p.K = [-0.019668737060041408, 0.0;
         0.01911652952841991, -0.25580110497237574];
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;
  p.dose_into = 1;   % central
  p.ka = 0.24000000000000002;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h] (in dose_start)
  p.dose = 80.0;             % dose [mg]
  p.dose_start = 0.016666666666666666;   % dose enters from [h] ...
  p.dose_duration = 0.16666666666666666;   % ... at a constant rate for [h]
  p.out_idx = [1.0, 2.0];
  p.out_names = {'C_central', 'C_M1'};
  p.out_labels = {'osimertinib', 'AZ5104'};
end
