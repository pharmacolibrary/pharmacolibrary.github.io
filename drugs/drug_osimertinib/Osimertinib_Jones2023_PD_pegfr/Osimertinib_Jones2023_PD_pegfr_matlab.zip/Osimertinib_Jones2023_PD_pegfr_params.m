function p = Osimertinib_Jones2023_PD_pegfr_params()
% Osimertinib_Jones2023_PD_pegfr_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% osimertinib Jones_2023::pEGFR: indirect_response_iv exposure-response sweep (response = E0/(1 + Emax*frac)). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one μmol/L per second, in SI inside (kg/m3, s). Response pEGFR in its own unit. Driver: osimertinib (pk_record).
p.E0 = 24300.0;
p.Emax = 9.06;
p.EC50 = 0.00016999999999999999;
p.gamma = 1.0;
p.slope = 0.0;
p.exposure_per_s = 0.001;
p.stop_time = 0.26;
p.form = 'E0/(1 + Emax*frac)';
end
