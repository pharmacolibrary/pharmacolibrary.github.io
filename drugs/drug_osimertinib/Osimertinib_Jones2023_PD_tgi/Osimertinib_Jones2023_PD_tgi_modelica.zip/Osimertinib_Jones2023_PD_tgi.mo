model Osimertinib_Jones2023_PD_tgi
  "linear exposure-response sweep — Jones_2023 :: TGI (Tumor growth)"
  extends Pharmacolibrary.Interfaces.PartialExposureResponseSweep(
    E0 = 90.2,      // [mm3]
    Emax = 0, EC50 = 1,      // unused by a line
    exposure_per_s = 1);
  parameter Real slope = 0.0837   "[—]";
equation
  response = E0 + slope*exposure;
  // family_inferred: the record's model family is disease_progression; read from the parameters: a slope and no Emax — linear
  annotation(experiment(StartTime = 0, StopTime = 1000, Interval = 2),
    Documentation(info = "<html><body><!-- drug-about --><h4>About osimertinib</h4><p>Osimertinib is a third-generation EGFR tyrosine kinase inhibitor used to treat non-small-cell lung cancer with a specific mutation. It is approved and authorised in the European Union for non-small-cell lung carcinoma.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q21506464\">Wikidata Q21506464</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h4>Osimertinib_Jones2023_PD_tgi</h4><p>The steady-state exposure-response curve of Jones RDO et al., <i>Molecular cancer therapeutics 22(5):679–690</i> 2023 (<a href=\"https://doi.org/10.1158/1535-7163.MCT-22-0193\">doi:10.1158/1535-7163.MCT-22-0193</a>) — Tumor growth [mm3] against osimertinib and savolitinib — obtained by sweeping the driver instead of simulating a dose. Model family: linear.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    =       90.2 mm3      drug-free response (baseline) (Baseline tumor size, Q324)
  slope =     0.0837 —        change in response per unit of exposure (pEGFR effect on tumor growth (slope), Q335)</pre><p>The algebra is <code>response = E0 + slope*exposure</code>; this model only supplies the numbers. The x axis is one  of osimertinib and savolitinib per second of simulated time: there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 90.2   (drug-free)</pre></body></html>"));
end Osimertinib_Jones2023_PD_tgi;
