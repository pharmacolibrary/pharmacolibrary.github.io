function p = Osimertinib_Jones2023_PD_tgi_params()
% Osimertinib_Jones2023_PD_tgi_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% osimertinib Jones_2023::TGI: linear exposure-response sweep (response = E0 + slope*exposure). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one SI per second, in SI inside (kg/m3, s). Response TGI in mm3. Driver: osimertinib and savolitinib (pk_record).
p.E0 = 90.2;
p.Emax = 0.0;
p.EC50 = 1.0;
p.gamma = 1.0;
p.slope = 0.0837;
p.exposure_per_s = 1.0;
p.stop_time = 1000.0;
p.form = 'E0 + slope*exposure';
end
