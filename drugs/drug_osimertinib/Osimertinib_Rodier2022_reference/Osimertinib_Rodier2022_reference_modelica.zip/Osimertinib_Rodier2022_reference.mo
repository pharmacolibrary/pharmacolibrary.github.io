model Osimertinib_Rodier2022_reference
  parameter Real Cl_ref = 3.8055555555555556e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.974 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.49961900000000004,
    adminMass = 4e-05,
    ka = 6.666666666666667e-05,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About osimertinib</h4><p>Osimertinib is a third-generation EGFR tyrosine kinase inhibitor used to treat non-small-cell lung cancer with a specific mutation. It is approved and authorised in the European Union for non-small-cell lung carcinoma.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q21506464\">Wikidata Q21506464</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>osimertinib</td></tr><tr><td>population:</td><td>adults with advanced EGFR-mutant NSCLC</td></tr><tr><td>source_paper:</td><td>Rodier_2022</td></tr><tr><td>measured_compound:</td><td>osimertinib</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>pharmaceutics-14-01844-t004</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>osimertinib 499.619 g/mol (drugbank)</td></tr></table><p><b>Defaulted (base-class default used):</b> Tlag.</p><h4>Interpretation flags</h4><ul><li>implicit units: 'ka (1/h)' → 1/h (from the paper text: 'The paper states that the “first-order absorption rate constant (ka) was fixed to 0.24 h−1.”')</li><li>apparent-ness (ontology-grounded): parameterization=apparent, measured_compound=osimertinib</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of TLAG: primary's parameterization (rate-constant / ka-only) does not use it</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 950400, Tolerance = 1e-9, Interval = 1));
end Osimertinib_Rodier2022_reference;
