model Epirubicin_Robert1994_reference
  parameter Real Cl_ref = 1.2777777777777777e-05 "Cl [m3/s]";
  parameter Real Vd_ref = 1.0 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.5435193,
    adminMass = 1e-05
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About epirubicin</h4><p>Epirubicin is an anthracycline anticancer drug used to treat cancers such as breast cancer, invasive ductal carcinoma, and gastric adenocarcinoma. It is an approved medicine and is widely used in cancer chemotherapy.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q425122\">Wikidata Q425122</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>epirubicin</td></tr><tr><td>population:</td><td>reference</td></tr><tr><td>source_paper:</td><td>Robert_1994</td></tr><tr><td>measured_compound:</td><td>epirubicin</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>epirubicin 543.519 g/mol (drugbank)</td></tr></table><h4>Interpretation flags</h4><ul><li>unit_dimension_unknown: 'L/h/m2' (CL)</li><li>unit_dimension_unknown: 'L/m2' (Vss)</li><li>implicit units: 'Total plasma clearance' → L/h (from the popPK convention: 'No unit is stated in the provided text. Total plasma clearance is conventionally reported in L/h, consistent with the va')</li><li>implicit units: 'volume of distribution at steady-state' → L (from the popPK convention: 'No unit is stated in the provided text. Steady-state volume of distribution is conventionally reported in L.')</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=epirubicin</li><li>structure disagreement: deterministic 1C vs LLM 2C — review compartment count</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Epirubicin_Robert1994_reference;
