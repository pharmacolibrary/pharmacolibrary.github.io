model Modafinil_Wu2012_reference
  parameter Real Cl_ref = 3.4722222222222224e-07 "Cl [m3/s]";
  parameter Real Vd_ref = 0.00514 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.274334,
    adminMass = 0.0002,
    ka = 0.0001936111111111111,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About modafinil</h4><p>Modafinil is a wakefulness-promoting stimulant used for sleep disorders such as narcolepsy and hypersomnia, and studied for fatigue, ADHD and multiple sclerosis-related tiredness. It is an approved medicine, widely used for narcolepsy, though it carries a boxed warning and is also investigated for other conditions.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q410441\">Wikidata Q410441</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>modafinil</td></tr><tr><td>population:</td><td>healthy volunteers from 5 ethnic groups of China</td></tr><tr><td>source_paper:</td><td>Wu_2012</td></tr><tr><td>measured_compound:</td><td>modafinil acid</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_M1</td></tr><tr><td>final_model_source:</td><td>tab_1</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>modafinil 273.35 g/mol (drugbank); modafinil acid 274.334 g/mol (pubchem)</td></tr></table><p><b>Defaulted (base-class default used):</b> Tlag.</p><h4>Interpretation flags</h4><ul><li>the dosed compound is modafinil; the compartment is modafinil acid. Input enters at the reported formation rate, so formation is already accounted for in the input step and the simulated concentration is modafinil acid, not modafinil</li><li>apparent parameters (CLm/F, Vm/F) already contain F and the metabolised fraction, so F=1 and no molar correction is applied — adding either would double-count it</li><li>modafinil's own concentration-time course is not produced by this model</li><li>PK_3M template not built: the parent has no clearance</li><li>PK_3M template not built: the parent has no clearance</li><li>dropped duplicate Q63 ('θ COV-V1', value '7.60') — already have one for this compound</li><li>unit_dimension_mismatch: '(l)' → Q22 (unit '[length] ** 3' vs ontology '[length] ** 3 / [time]') — route to review</li><li>dropped duplicate Q22 ('(l)', value '2.63') — already have one for this compound</li><li>dropped duplicate Q27 ('CL2/F 1', value None) — already have one for this compound</li><li>dropped value-less row: 'F 2 is the absolute metabolic transformation fraction from modafinil to modafinil acid.'</li><li>dropped value-less row: 'θ COV-V1 is 1 for Han group'</li><li>dropped value-less row: 'θ COV-CL3 is 1 for Han and Mongolian groups.'</li><li>dropped value-less row: 'F 1'</li><li>dropped value-less row: 'F 2'</li><li>unit inherited for V1 (Q63): 'l' from a same-Q-code sibling (this row's label had no unit)</li><li>implicit units: 'CL1/F 1 (l/h) Male' → L/h (from the paper text: &quot;Table 2 lists 'CL1/F1 (l/h)'; abstract states typical clearance in (l/h).&quot;)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Modafinil_Wu2012_reference;
