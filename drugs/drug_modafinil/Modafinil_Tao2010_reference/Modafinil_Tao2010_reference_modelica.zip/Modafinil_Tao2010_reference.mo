model Modafinil_Tao2010_reference
  parameter Real Cl_ref = 9.75e-07 "Cl [m3/s]";
  parameter Real Vd_ref = 0.00385 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.27335000000000004,
    adminMass = 1e-05,
    k12 = 0.0005346320346320346,
    k21 = 4.494177583697234e-05
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About modafinil</h4><p>Modafinil is a wakefulness-promoting stimulant used for sleep disorders such as narcolepsy and hypersomnia, and studied for fatigue, ADHD and multiple sclerosis-related tiredness. It is an approved medicine, widely used for narcolepsy, though it carries a boxed warning and is also investigated for other conditions.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q410441\">Wikidata Q410441</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>modafinil</td></tr><tr><td>population:</td><td>healthy Chinese volunteers of five ethnicities</td></tr><tr><td>source_paper:</td><td>Tao_2010</td></tr><tr><td>measured_compound:</td><td>modafinil</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_2C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>modafinil 273.35 g/mol (drugbank)</td></tr></table><h4>Interpretation flags</h4><ul><li>routed 'interindividual variability in clearance of central compartment' → Q312 (IIV) to iiv — variability estimate, not a structural parameter</li><li>routed 'interindividual variability in clearance of intercompartment' → Q312 (IIV) to iiv — variability estimate, not a structural parameter</li><li>routed 'interindividual variability in volume of the central compartment' → Q312 (IIV) to iiv — variability estimate, not a structural parameter</li><li>unit_dimension_mismatch: 'interindividual variability in volume of the peripheral compartment' → Q64 (unit 'dimensionless' vs ontology '[length] ** 3') — route to review</li><li>dropped duplicate Q64 ('interindividual variability in volume of the peripheral compartment', value 16.6) — already have one for this compound</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=modafinil</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Modafinil_Tao2010_reference;
