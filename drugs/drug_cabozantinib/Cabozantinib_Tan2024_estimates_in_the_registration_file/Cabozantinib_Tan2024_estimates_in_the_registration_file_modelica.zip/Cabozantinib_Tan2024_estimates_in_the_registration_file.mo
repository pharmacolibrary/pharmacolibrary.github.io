model Cabozantinib_Tan2024_estimates_in_the_registration_file
  parameter Real Cl_ref = 6.194444444444445e-07 "Cl [m3/s]";
  parameter Real cov_weight = 1.0 "weight covariate (reference 1.0)";
  parameter Real Vd_ref = 0.0815 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref*(cov_weight/1.0)^(-0.5),
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.501514,
    adminMass = 4e-05,
    ka = 0.00015777777777777776,
    Tlag = 1652.4,
    k12 = 4.839809134287661e-05,
    k21 = 1.8518518518518515e-05
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About cabozantinib</h4><p>Cabozantinib is a protein kinase inhibitor used to treat cancers such as renal cell carcinoma and medullary thyroid cancer. It is authorised in the European Union for thyroid, kidney, and liver cancers and is used in cancer care.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q795057\">Wikidata Q795057</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>cabozantinib</td></tr><tr><td>population:</td><td>metastatic renal cell carcinoma patients</td></tr><tr><td>source_paper:</td><td>Tan_2024</td></tr><tr><td>measured_compound:</td><td>cabozantinib</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>Tab2</td></tr><tr><td>input:</td><td>PK_2C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>cabozantinib 501.514 g/mol (drugbank)</td></tr></table><h4>Interpretation flags</h4><ul><li>dropped duplicate Q49 ('Ka2 (/h)*', value '0.102') — already have one for this compound</li><li>dropped duplicate Q83 ('ALAG2 (h)*', value '16.8') — already have one for this compound</li><li>covariate level 'Dose exponent on Ka1*' → Q900:dose_exponent_on_ka1 = -0.5 (power on Q27)</li><li>dropped duplicate Q27 ('Female on CL/F*,#', value '0.79') — already have one for this compound</li><li>dropped duplicate Q27 ('Asian on CL/F*,#', value '0.73') — already have one for this compound</li><li>dropped value-less row: 'CL/F'</li><li>dropped value-less row: 'Q/F'</li><li>implicit units: 'Vc/F (L)*' → L (from the paper text: 'Table 2 labels the parameter “Vc/F (L)*”.')</li><li>implicit units: 'Vp/F (L)*' → L (from the paper text: 'Table 2 labels the parameter “Vp/F (L)*”.')</li><li>implicit units: 'Q/F (L/h)*' → L/h (from the paper text: 'Table 2 labels the parameter “Q/F (L/h)*”.')</li><li>implicit units: 'Ka1 (/h)*' → 1/h (from the paper text: 'Table 2 labels the parameter “Ka1 (/h)*”.')</li><li>implicit units: 'ALAG1 (h)*' → h (from the paper text: 'Table 2 labels the parameter “ALAG1 (h)*”.')</li><li>apparent-ness (ontology-grounded): parameterization=apparent, measured_compound=cabozantinib</li><li>population split: 'estimates in the registration file' subgroup of Tan_2024 (paper reports 2 populations: estimates in the registration file, estimates of the final poppk model (rse%))</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 518400, Tolerance = 1e-9, Interval = 1));
end Cabozantinib_Tan2024_estimates_in_the_registration_file;
