function p = Cabozantinib_Tan2024_estimates_in_the_registration_file_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: cabozantinib   source: Tan_2024 / estimates_in_the_registration_file   route: oral
  p.name  = 'Cabozantinib_Tan2024_estimates_in_the_registration_file_params';
  p.drug  = 'cabozantinib';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 81.5;                % central volume [L]
  p.CL = 2.23;                % clearance [L/h]
  p.Vp = [213.0];             % peripheral volumes [L]
  p.Q  = [14.2];             % inter-compartmental clearances [L/h]
  p.ka = 0.568;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.459;             % absorption lag [h]
  p.dose = 40.0;             % dose [mg]
end
