model Cabozantinib_Miles2016v2_reference
  parameter Real Cl_ref = 1.2268518518518517e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.34900000000000003 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.501514,
    adminMass = 6e-05,
    ka = 0.0009416666666666667,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About cabozantinib</h4><p>Cabozantinib is a protein kinase inhibitor used to treat cancers such as renal cell carcinoma and medullary thyroid cancer. It is authorised in the European Union for thyroid, kidney, and liver cancers and is used in cancer care.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q795057\">Wikidata Q795057</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>cabozantinib</td></tr><tr><td>population:</td><td>patients with medullary thyroid carcinoma</td></tr><tr><td>source_paper:</td><td>Miles_2016_2</td></tr><tr><td>measured_compound:</td><td>cabozantinib</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>cabozantinib 501.514 g/mol (drugbank)</td></tr></table><p><b>Defaulted (base-class default used):</b> Tlag.</p><h4>Interpretation flags</h4><ul><li>dropped unlinked row (NIL): 'females' — extend the ontology if this is a real PK parameter (source ['Miles_2016_2:abstract'])</li><li>dropped duplicate Q27 ('CL/F (females)', value 83) — already have one for this compound</li><li>apparent-ness (ontology-grounded): parameterization=apparent, measured_compound=cabozantinib</li><li>1C volume normalization: Q290→Q76 (single-compartment model has no central/peripheral split; 'V c/F' is the general volume)</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li><li>gap-filled Q49 (kabs) from Ly_2023's review values (primary lacked it)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 1036800, Tolerance = 1e-9, Interval = 1));
end Cabozantinib_Miles2016v2_reference;
