model Cabozantinib_Ly2023_estimate
  parameter Real Cl_ref = 5.694444444444444e-07 "Cl [m3/s]";
  parameter Real Vd_ref = 0.0988 "Vd [m3]";
  parameter Real cov_weight_0 = 0 "weight covariate";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref*(1 + (2.03)*cov_weight_0),
    adminDuration = 600,
    adminCount = 1,
    MM = 0.501514,
    adminMass = 6e-05,
    ka = 0.0009416666666666667,
    Tlag = 68760.0
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About cabozantinib</h4><p>Cabozantinib is a protein kinase inhibitor used to treat cancers such as renal cell carcinoma and medullary thyroid cancer. It is authorised in the European Union for thyroid, kidney, and liver cancers and is used in cancer care.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q795057\">Wikidata Q795057</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>cabozantinib</td></tr><tr><td>population:</td><td>patients with various cancer types and healthy volunteers</td></tr><tr><td>source_paper:</td><td>Ly_2023</td></tr><tr><td>measured_compound:</td><td>cabozantinib</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>Tab2</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>cabozantinib 501.514 g/mol (drugbank)</td></tr></table><h4>Interpretation flags</h4><ul><li>table section residual_error: 'Healthy subjects' routed out of structural estimates ('Residual variability')</li><li>table section residual_error: 'Patientsa' routed out of structural estimates ('Residual variability')</li><li>covariate effect for Q319 has no base parameter row (kept as unattached equation-variable)</li><li>implicit units: 'CL/F' → L/h (from the paper text: 'Table 2 lists CL/F with unit L/h.')</li><li>implicit units: 'Vc/F' → L (from the paper text: 'Table 2 lists Vc/F with unit L.')</li><li>implicit units: 'Ka' → 1/h (from the paper text: 'Table 2 lists Ka with unit h−1.')</li><li>implicit units: 'V3/F' → L (from the paper text: 'Table 2 lists V3/F with unit L.')</li><li>implicit units: 'Q/F' → L/h (from the paper text: 'Table 2 lists Q/F with unit L/h.')</li><li>implicit units: 'ALAG4' → h (from the paper text: 'Table 2 lists ALAG with unit h; the caption defines ALAG as absorption lag time.')</li><li>apparent-ness (ontology-grounded): parameterization=apparent, measured_compound=cabozantinib</li><li>structure disagreement: deterministic 1C vs LLM 2C — review compartment count</li><li>population split: 'estimate' subgroup of Ly_2023 (paper reports 2 populations: ase, estimate)</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 604800, Tolerance = 1e-9, Interval = 1));
end Cabozantinib_Ly2023_estimate;
