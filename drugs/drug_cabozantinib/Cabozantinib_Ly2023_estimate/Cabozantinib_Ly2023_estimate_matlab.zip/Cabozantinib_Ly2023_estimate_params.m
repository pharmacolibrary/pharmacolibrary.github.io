function p = Cabozantinib_Ly2023_estimate_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: cabozantinib   source: Ly_2023 / estimate   route: oral
  p.name  = 'Cabozantinib_Ly2023_estimate_params';
  p.drug  = 'cabozantinib';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 98.8;                % central volume [L]
  p.CL = 2.05;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 3.39;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 19.1;             % absorption lag [h]
  p.dose = 60.0;             % dose [mg]
end
