function p = Cabozantinib_Nguyen2019_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: cabozantinib   source: Nguyen_2019 / reference   route: oral
  p.name  = 'Cabozantinib_Nguyen2019_reference_params';
  p.drug  = 'cabozantinib';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 212.0;                % central volume [L]
  p.CL = 2.48;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 3.39;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 60.0;             % dose [mg]
end
