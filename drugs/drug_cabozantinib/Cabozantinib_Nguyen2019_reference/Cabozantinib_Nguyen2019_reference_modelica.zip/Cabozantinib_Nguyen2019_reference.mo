model Cabozantinib_Nguyen2019_reference
  parameter Real Cl_ref = 6.888888888888889e-07 "Cl [m3/s]";
  parameter Real Vd_ref = 0.212 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.501514,
    adminMass = 6e-05,
    ka = 0.0009416666666666667,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About cabozantinib</h4><p>Cabozantinib is a protein kinase inhibitor used to treat cancers such as renal cell carcinoma and medullary thyroid cancer. It is authorised in the European Union for thyroid, kidney, and liver cancers and is used in cancer care.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q795057\">Wikidata Q795057</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>cabozantinib</td></tr><tr><td>population:</td><td>healthy volunteers and patients with various cancer types, including hepatocellular carcinoma</td></tr><tr><td>source_paper:</td><td>Nguyen_2019</td></tr><tr><td>measured_compound:</td><td>cabozantinib</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>jcph1467-tbl-0003</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>cabozantinib 501.514 g/mol (drugbank)</td></tr></table><p><b>Defaulted (base-class default used):</b> Tlag.</p><h4>Interpretation flags</h4><ul><li>salvaged Q27 ('CL/F at steady state'=2.48) from results prose — parameter table was unreadable</li><li>salvaged Q290 ('Vc/F'=212) from results prose — parameter table was unreadable</li><li>apparent-ness (ontology-grounded): parameterization=apparent, measured_compound=cabozantinib</li><li>held at status:extracted — NIL link or unit issue (mismatch/unknown/normalisation-failed) present</li><li>1C volume normalization: Q290→Q76 (single-compartment model has no central/peripheral split; 'Vc/F' is the general volume)</li><li>status held at route_to_review — not promoted</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li><li>gap-filled Q49 (kabs) from Ly_2023's review values (primary lacked it)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 1123200, Tolerance = 1e-9, Interval = 1));
end Cabozantinib_Nguyen2019_reference;
