function p = Cabozantinib_Lacy2018_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: cabozantinib   source: Lacy_2018 / reference   route: oral
  p.name  = 'Cabozantinib_Lacy2018_reference_params';
  p.drug  = 'cabozantinib';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 157.178;                % central volume [L]
  p.CL = 2.457;                % clearance [L/h]
  p.Vp = [188.666];             % peripheral volumes [L]
  p.Q  = [30.154];             % inter-compartmental clearances [L/h]
  p.ka = 0.804;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 20.0;             % dose [mg]
end
