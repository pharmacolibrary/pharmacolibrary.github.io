model Cabozantinib_Lacy2018_reference
  parameter Real Cl_ref = 6.825e-07 "Cl [m3/s]";
  parameter Real Vd_ref = 0.157178 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.501514,
    adminMass = 2e-05,
    ka = 0.00022333333333333336,
    Tlag = 0.0,
    k12 = 5.3290607534840184e-05,
    k21 = 4.4396505523576646e-05
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About cabozantinib</h4><p>Cabozantinib is a protein kinase inhibitor used to treat cancers such as renal cell carcinoma and medullary thyroid cancer. It is authorised in the European Union for thyroid, kidney, and liver cancers and is used in cancer care.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q795057\">Wikidata Q795057</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>cabozantinib</td></tr><tr><td>population:</td><td>healthy volunteers and patients with various cancer types</td></tr><tr><td>source_paper:</td><td>Lacy_2018</td></tr><tr><td>measured_compound:</td><td>cabozantinib</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>Tab3</td></tr><tr><td>input:</td><td>PK_2C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>cabozantinib 501.514 g/mol (drugbank)</td></tr></table><p><b>Defaulted (base-class default used):</b> Tlag.</p><h4>Interpretation flags</h4><ul><li>salvaged Q49 ('Ka'=0.804) from results prose — parameter table was unreadable</li><li>salvaged Q27 ('Cl/F'=2.457) from results prose — parameter table was unreadable</li><li>salvaged Q290 ('Vc/F'=157.178) from results prose — parameter table was unreadable</li><li>salvaged Q69 ('Q/F'=30.154) from results prose — parameter table was unreadable</li><li>salvaged Q82 ('Vp/F'=188.666) from results prose — parameter table was unreadable</li><li>apparent-ness (ontology-grounded): parameterization=apparent, measured_compound=cabozantinib</li><li>held at status:extracted — NIL link or unit issue (mismatch/unknown/normalisation-failed) present</li><li>model equation 'ij = θREF·exp(θx·xij),where θREF and θx are fixed-effect parameters and χij is the indicator variable with values of 1 or 0' not bound — neither LHS nor base term 'θREF' linked to an ontology parameter</li><li>status held at route_to_review — not promoted</li><li>skipped review gap-fill of TLAG: primary's parameterization (rate-constant / ka-only) does not use it</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 864000, Tolerance = 1e-9, Interval = 1));
end Cabozantinib_Lacy2018_reference;
