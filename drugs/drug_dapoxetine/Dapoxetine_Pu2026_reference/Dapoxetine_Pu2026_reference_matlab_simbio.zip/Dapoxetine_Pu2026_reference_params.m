function p = Dapoxetine_Pu2026_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: dapoxetine   source: Pu_2026 / reference   route: oral
  p.name  = 'Dapoxetine_Pu2026_reference_params';
  p.drug  = 'dapoxetine';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 65.6;                % central volume [L]
  p.CL = 37.8;                % clearance [L/h]
  p.Vp = [191.7];             % peripheral volumes [L]
  p.Q  = [17.2];             % inter-compartmental clearances [L/h]
  p.ka = 1.29;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.68;             % absorption lag [h]
  p.dose = 30.0;             % dose [mg]
end
