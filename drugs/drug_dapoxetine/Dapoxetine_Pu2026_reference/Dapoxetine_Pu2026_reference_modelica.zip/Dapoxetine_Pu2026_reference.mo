model Dapoxetine_Pu2026_reference
  parameter Real Cl_ref = 1.05e-05 "Cl [m3/s]";
  parameter Real Vd_ref = 0.06559999999999999 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.3054134,
    adminMass = 3e-05,
    ka = 0.00035833333333333333,
    Tlag = 2448.0,
    k12 = 7.28319783197832e-05,
    k21 = 2.4923201762012403e-05
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About dapoxetine</h4><p>Dapoxetine is a urological drug developed for the treatment of premature ejaculation. It is considered investigational in the sources provided and has not been authorised in the European Union, though it has been marketed in some other countries.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q424965\">Wikidata Q424965</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>dapoxetine</td></tr><tr><td>population:</td><td>healthy Chinese male subjects</td></tr><tr><td>source_paper:</td><td>Pu_2026</td></tr><tr><td>measured_compound:</td><td>dapoxetine</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_2C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>dapoxetine 305.413 g/mol (drugbank)</td></tr></table><h4>Interpretation flags</h4><ul><li>apparent-ness (ontology-grounded): parameterization=apparent, measured_compound=dapoxetine</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Dapoxetine_Pu2026_reference;
