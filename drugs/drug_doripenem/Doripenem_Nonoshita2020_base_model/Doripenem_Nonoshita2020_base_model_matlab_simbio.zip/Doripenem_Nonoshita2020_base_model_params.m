function p = Doripenem_Nonoshita2020_base_model_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: doripenem   source: Nonoshita_2020 / base_model   route: iv_bolus
  % estimated (absent from source): F
  p.name  = 'Doripenem_Nonoshita2020_base_model_params';
  p.drug  = 'doripenem';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'iv_bolus';        % 'oral' | 'iv_bolus'
  p.depot = false;             % oral -> first-order absorption depot
  p.Vc = 6.76;                % central volume [L]
  p.CL = 3.89;                % clearance [L/h]
  p.Vp = [8.54];             % peripheral volumes [L]
  p.Q  = [4.62];             % inter-compartmental clearances [L/h]
  p.ka = 0.0;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 250.0;             % dose [mg]
end
