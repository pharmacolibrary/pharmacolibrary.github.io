function p = Doripenem_Wang2022_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: doripenem   source: Wang_2022 / reference   route: oral
  % estimated (absent from source): ka, dose
  p.name  = 'Doripenem_Wang2022_reference_params';
  p.drug  = 'doripenem';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 8.17;                % central volume [L]
  p.CL = 7.2;                % clearance [L/h]
  p.Vp = [6.95];             % peripheral volumes [L]
  p.Q  = [8.54];             % inter-compartmental clearances [L/h]
  p.ka = 0.5;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 100.0;             % dose [mg]
end
