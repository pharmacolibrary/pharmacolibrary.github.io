function p = Doripenem_Nonoshita2020_population_mean_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: doripenem   source: Nonoshita_2020 / population_mean   route: iv_bolus
  % estimated (absent from source): F
  p.name  = 'Doripenem_Nonoshita2020_population_mean_params';
  p.drug  = 'doripenem';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'iv_bolus';        % 'oral' | 'iv_bolus'
  p.depot = false;             % oral -> first-order absorption depot
  p.Vc = 10.04;                % central volume [L]
  p.CL = 3.65;                % clearance [L/h]
  p.Vp = [8.13];             % peripheral volumes [L]
  p.Q  = [3.53];             % inter-compartmental clearances [L/h]
  p.ka = 0.0;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 250.0;             % dose [mg]
end
