model Doripenem_Nonoshita2020_population_mean
  parameter Real Cl_ref = 1.013888888888889e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.010039999999999999 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.42050400000000004,
    adminMass = 0.00025,
    k12 = 9.766489597166889e-05,
    k21 = 0.0001206095394287276
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About doripenem</h4><p>Doripenem is a carbapenem antibiotic that was used to treat bacterial infections, including pneumonia, urinary tract infections, and hospital-acquired infections. It is no longer marketed in the European Union, where its product has been withdrawn.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q411552\">Wikidata Q411552</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>doripenem</td></tr><tr><td>population:</td><td>Japanese ICU patients</td></tr><tr><td>source_paper:</td><td>Nonoshita_2020</td></tr><tr><td>measured_compound:</td><td>doripenem</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>Tab3</td></tr><tr><td>input:</td><td>PK_2C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>doripenem 420.504 g/mol (drugbank)</td></tr></table><h4>Interpretation flags</h4><ul><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=doripenem</li><li>population split: 'population mean' subgroup of Nonoshita_2020 (paper reports 2 populations: base model, population mean)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Doripenem_Nonoshita2020_population_mean;
