model Tadalafil_Mnica2012_PD_relaxation
  "emax exposure-response sweep — Mónica_2012 :: relaxation (relaxation)"
  extends Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep(
    E0 = 0,      // [1]
    Emax = 1.05,  // [1; % × 0.01]
    EC50 = 7.34,  // [μM]
    gamma = 1,
    exposure_per_s = 1);   // 1 μM per second
  // exposure_unit_unresolved: 'μM' — the x axis is in the paper's unit, not SI
  // defaulted: E0
  // defaulted: gamma
  annotation(experiment(StartTime = 0, StopTime = 74, Interval = 0.148),
    Documentation(info = "<html><body><!-- drug-about --><h4>About tadalafil</h4><p>Tadalafil is used to treat erectile dysfunction, enlarged prostate, and pulmonary arterial hypertension. It is widely used and authorised in the European Union for erectile dysfunction and pulmonary hypertension.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q424156\">Wikidata Q424156</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h4>Tadalafil_Mnica2012_PD_relaxation</h4><p>The steady-state exposure-response curve of Mónica FZ et al., <i>Comparative biochemistry and physiology. Toxicology &amp; pharmacology : CBP 155(3):433–439</i> 2012 (<a href=\"https://doi.org/10.1016/j.cbpc.2011.11.003\">doi:10.1016/j.cbpc.2011.11.003</a>) — relaxation [%] against tadalafil μM — obtained by sweeping the driver instead of simulating a dose. Model family: emax.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = (library default) drug-free response (baseline)
  Emax  =        105 %        maximal effect term (E(max), Q320)
  EC50  =       7.34 μM       exposure at half of the maximal effect term (pEC(50), Q321)
  gamma = (library default) Hill coefficient</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep\">SigmoidEmaxSweep</a>; this model only supplies the numbers. The x axis is one μM of tadalafil per second of simulated time: there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0   (drug-free)
  exposure = EC50 (7.34 μM)  response 0.525
  exposure -> infinity  response 1.05</pre></body></html>"));
end Tadalafil_Mnica2012_PD_relaxation;
