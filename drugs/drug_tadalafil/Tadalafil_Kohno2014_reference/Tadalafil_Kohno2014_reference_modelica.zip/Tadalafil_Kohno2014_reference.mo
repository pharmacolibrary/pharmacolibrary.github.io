model Tadalafil_Kohno2014_reference
  parameter Real Cl_ref = 2.897222222222222e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.13090000000000002 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.389404,
    adminMass = 1e-05,
    ka = 0.0001388888888888889,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About tadalafil</h4><p>Tadalafil is used to treat erectile dysfunction, enlarged prostate, and pulmonary arterial hypertension. It is widely used and authorised in the European Union for erectile dysfunction and pulmonary hypertension.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q424156\">Wikidata Q424156</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>tadalafil</td></tr><tr><td>population:</td><td>children with pulmonary arterial hypertension</td></tr><tr><td>source_paper:</td><td>Kohno_2014</td></tr><tr><td>measured_compound:</td><td>tadalafil</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C_enteral: apparent (/F) parameterization ⇒ extravascular dosing</td></tr><tr><td>molar_masses:</td><td>tadalafil 389.404 g/mol (drugbank)</td></tr></table><p><b>Defaulted (base-class default used):</b> ka, Tlag.</p><h4>Interpretation flags</h4><ul><li>dropped unlinked row (NIL): 'unbound tadalafil concentrations of the postdose samples' — extend the ontology if this is a real PK parameter (source ['Kohno_2014:abstract', 'Kohno_2014:abstract'])</li><li>covariate category for IC50 from footnote/prose kept as documentation only (['Kohno_2014:abstract', 'Kohno_2014:abstract'])</li><li>apparent-ness (ontology-grounded): parameterization=apparent, measured_compound=tadalafil</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 158400, Tolerance = 1e-9, Interval = 1));
end Tadalafil_Kohno2014_reference;
