model Tadalafil_Na2019_group_t
  parameter Real Cl_ref = 8.493333333333334e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.23520000000000002 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.389404,
    adminMass = 0.00014,
    ka = 0.00031666666666666665,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About tadalafil</h4><p>Tadalafil is used to treat erectile dysfunction, enlarged prostate, and pulmonary arterial hypertension. It is widely used and authorised in the European Union for erectile dysfunction and pulmonary hypertension.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q424156\">Wikidata Q424156</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>tadalafil</td></tr><tr><td>population:</td><td>male rats</td></tr><tr><td>source_paper:</td><td>Na_2019</td></tr><tr><td>measured_compound:</td><td>tadalafil</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>pharmaceutics-11-00354-t002</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>tadalafil 389.404 g/mol (drugbank)</td></tr></table><p><b>Defaulted (base-class default used):</b> Tlag.</p><h4>Interpretation flags</h4><ul><li>implicit units: 'Ka (1/h)' → 1/h (from the paper text: &quot;The text states: 'Ka indicates the absorption rate constant from the gut compartment to the central compartment.' While &quot;)</li><li>implicit units: 'Ke (1/h)' → 1/h (from the paper text: &quot;The text explicitly states: 'The Ke of Group T (0.13 ± 0.03 h−1) were decreased compared with that of Group N (0.17 ± 0.&quot;)</li><li>apparent-ness (ontology-grounded): parameterization=apparent, measured_compound=tadalafil</li><li>population split: 'group t' subgroup of Na_2019 (paper reports 2 populations: group n, group t)</li><li>skipped review gap-fill of CL: primary's parameterization (rate-constant / ka-only) does not use it</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary's parameterization (rate-constant / ka-only) does not use it</li><li>skipped review gap-fill of TLAG: primary's parameterization (rate-constant / ka-only) does not use it</li><li>derived CL/F=30.576 L/h from Ke × V/F = CL/F (Q47 × Q76); not separately reported</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 108000, Tolerance = 1e-9, Interval = 1));
end Tadalafil_Na2019_group_t;
