function p = Tadalafil_Campos2019_PD_aortic_ring_relaxation_params()
% Tadalafil_Campos2019_PD_aortic_ring_relaxation_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% tadalafil Campos_2019::aortic_ring_relaxation: emax exposure-response sweep (response = E0 + Emax*frac). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one SI per second, in SI inside (kg/m3, s). Response aortic ring relaxation in %. Driver: tadalafil (cited_pk).
p.E0 = 0.0;
p.Emax = 1.213;
p.EC50 = 6.7;
p.gamma = 1.0;
p.slope = 0.0;
p.exposure_per_s = 1.0;
p.stop_time = 67.0;
p.form = 'E0 + Emax*frac';
end
