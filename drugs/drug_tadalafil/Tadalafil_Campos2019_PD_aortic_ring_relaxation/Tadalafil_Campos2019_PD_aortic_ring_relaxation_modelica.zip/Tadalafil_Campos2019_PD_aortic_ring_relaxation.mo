model Tadalafil_Campos2019_PD_aortic_ring_relaxation
  "emax exposure-response sweep — Campos_2019 :: aortic ring relaxation (aortic ring relaxation)"
  extends Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep(
    E0 = 0,      // [1]
    Emax = 1.213,  // [1; % × 0.01]
    EC50 = 6.7,  // [1]
    gamma = 1,
    exposure_per_s = 1);   // 1 unit per second
  // exposure_unit_unresolved: '' — the x axis is in the paper's unit, not SI
  // defaulted: E0
  // defaulted: gamma
  annotation(experiment(StartTime = 0, StopTime = 67, Interval = 0.134),
    Documentation(info = "<html><body><!-- drug-about --><h4>About tadalafil</h4><p>Tadalafil is used to treat erectile dysfunction, enlarged prostate, and pulmonary arterial hypertension. It is widely used and authorised in the European Union for erectile dysfunction and pulmonary hypertension.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q424156\">Wikidata Q424156</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h4>Tadalafil_Campos2019_PD_aortic_ring_relaxation</h4><p>The steady-state exposure-response curve of Campos R et al., <i>Comparative biochemistry and physiology. Toxicology &amp; pharmacology : CBP 222:82–89</i> 2019 (<a href=\"https://doi.org/10.1016/j.cbpc.2019.04.015\">doi:10.1016/j.cbpc.2019.04.015</a>) — aortic ring relaxation [%] against tadalafil — obtained by sweeping the driver instead of simulating a dose. Model family: emax.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = (library default) drug-free response (baseline)
  Emax  =      121.3 %        maximal effect term (Emax, Q320)
  EC50  =        6.7          exposure at half of the maximal effect term (pEC50, Q321)
  gamma = (library default) Hill coefficient</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep\">SigmoidEmaxSweep</a>; this model only supplies the numbers. The x axis is one  of tadalafil per second of simulated time: there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0   (drug-free)
  exposure = EC50 (6.7 )  response 0.6065
  exposure -> infinity  response 1.213</pre></body></html>"));
end Tadalafil_Campos2019_PD_aortic_ring_relaxation;
