model Tadalafil_Staab2004_PD_iief_ef
  "emax exposure-response sweep — Staab_2004 :: IIEF EF (IIEF EF domain score)"
  extends Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep(
    E0 = 0,      // [1]
    Emax = 7.5,  // [points]
    EC50 = 4.7e-06,  // [kg; mg × 1e-06]
    gamma = 1,
    exposure_per_s = 1e-06);   // 1 mg per second
  // defaulted: E0
  // defaulted: gamma
  annotation(experiment(StartTime = 0, StopTime = 47, Interval = 0.094),
    Documentation(info = "<html><body><!-- drug-about --><h4>About tadalafil</h4><p>Tadalafil is used to treat erectile dysfunction, enlarged prostate, and pulmonary arterial hypertension. It is widely used and authorised in the European Union for erectile dysfunction and pulmonary hypertension.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q424156\">Wikidata Q424156</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h4>Tadalafil_Staab2004_PD_iief_ef</h4><p>The steady-state exposure-response curve of Staab A et al., <i>Pharmaceutical research 21(8):1463–1470</i> 2004 (<a href=\"https://doi.org/10.1023/b:pham.0000036922.03519.40\">doi:10.1023/b:pham.0000036922.03519.40</a>) — IIEF EF domain score [points] against tadalafil mg — obtained by sweeping the driver instead of simulating a dose. Model family: emax.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = (library default) drug-free response (baseline)
  Emax  =        7.5 points   maximal effect term (Emax, Q320)
  EC50  =        4.7 mg       exposure at half of the maximal effect term (ED50, Q321)
  gamma = (library default) Hill coefficient</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep\">SigmoidEmaxSweep</a>; this model only supplies the numbers. The x axis is one mg of tadalafil per second of simulated time (exposure is in kg): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0   (drug-free)
  exposure = EC50 (4.7 mg)  response 3.75
  exposure -> infinity  response 7.5</pre></body></html>"));
end Tadalafil_Staab2004_PD_iief_ef;
