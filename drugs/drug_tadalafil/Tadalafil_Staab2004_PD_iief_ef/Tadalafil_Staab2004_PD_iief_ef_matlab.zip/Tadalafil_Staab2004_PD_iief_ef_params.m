function p = Tadalafil_Staab2004_PD_iief_ef_params()
% Tadalafil_Staab2004_PD_iief_ef_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% tadalafil Staab_2004::IIEF_EF: emax exposure-response sweep (response = E0 + Emax*frac). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one mg per second, in SI inside (kg/m3, s). Response IIEF EF in points. Driver: tadalafil (dose_only).
p.E0 = 0.0;
p.Emax = 7.5;
p.EC50 = 4.7e-06;
p.gamma = 1.0;
p.slope = 0.0;
p.exposure_per_s = 1e-06;
p.stop_time = 47.0;
p.form = 'E0 + Emax*frac';
end
