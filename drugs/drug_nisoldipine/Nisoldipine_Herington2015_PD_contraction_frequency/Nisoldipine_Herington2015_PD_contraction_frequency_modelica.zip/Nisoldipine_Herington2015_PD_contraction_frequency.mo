model Nisoldipine_Herington2015_PD_contraction_frequency
  "sigmoid_emax exposure-response sweep — Herington_2015 :: contraction frequency (contraction frequency)"
  extends Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep(
    E0 = 0,      // [1]
    Emax = -90.92,  // [% response from baseline]
    EC50 = 7.43e-07,  // [μM]
    gamma = 1,
    exposure_per_s = 1);   // 1 μM per second
  // inhibition_sign: effect_direction=inhibition with a positive Emax (Q320) — sign flipped
  // exposure_unit_unresolved: 'μM' — the x axis is in the paper's unit, not SI
  // defaulted: E0
  // defaulted: gamma
  annotation(experiment(StartTime = 0, StopTime = 7.5e-06, Interval = 1.5e-08),
    Documentation(info = "<html><body><h4>Nisoldipine_Herington2015_PD_contraction_frequency</h4><p>The steady-state exposure-response curve of Herington JL et al., <i>PloS one 10(11):e0143243</i> 2015 (<a href=\"https://doi.org/10.1371/journal.pone.0143243\">doi:10.1371/journal.pone.0143243</a>) — contraction frequency [% response from baseline] against hit compounds (benzbromarone, dipyridamole, fenoterol hydrobromide, nisoldipine) μM — obtained by sweeping the driver instead of simulating a dose. Model family: sigmoid_emax.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = (library default) drug-free response (baseline)
  Emax  =      90.92 % response from baseline maximal effect term (1388 — Emax ± SEM, Q320)
  EC50  =   7.43e-07 μM       exposure at half of the maximal effect term (1388 — EC50, Q321)
  gamma = (library default) Hill coefficient</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep\">SigmoidEmaxSweep</a>; this model only supplies the numbers. The x axis is one μM of hit compounds (benzbromarone, dipyridamole, fenoterol hydrobromide, nisoldipine) per second of simulated time: there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0   (drug-free)
  exposure = EC50 (7.43e-07 μM)  response -45.46
  exposure -> infinity  response -90.92</pre></body></html>"));
end Nisoldipine_Herington2015_PD_contraction_frequency;
