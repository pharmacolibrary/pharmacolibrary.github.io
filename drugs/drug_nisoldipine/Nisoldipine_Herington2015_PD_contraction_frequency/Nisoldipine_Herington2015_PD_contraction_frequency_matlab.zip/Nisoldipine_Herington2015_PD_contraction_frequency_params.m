function p = Nisoldipine_Herington2015_PD_contraction_frequency_params()
% Nisoldipine_Herington2015_PD_contraction_frequency_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% nisoldipine Herington_2015::contraction_frequency: sigmoid_emax exposure-response sweep (response = E0 + Emax*frac). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one μM per second, in SI inside (kg/m3, s). Response contraction frequency in % response from baseline. Driver: hit compounds (benzbromarone, dipyridamole, fenoterol hydrobromide, nisoldipine) (conc_no_pk).
p.E0 = 0.0;
p.Emax = -90.92;
p.EC50 = 7.43e-07;
p.gamma = 1.0;
p.slope = 0.0;
p.exposure_per_s = 1.0;
p.stop_time = 7.5e-06;
p.form = 'E0 + Emax*frac';
end
