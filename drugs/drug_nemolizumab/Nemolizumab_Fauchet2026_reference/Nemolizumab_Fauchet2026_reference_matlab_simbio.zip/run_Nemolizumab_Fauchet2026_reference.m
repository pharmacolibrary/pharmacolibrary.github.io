% Run (SimBiology): build model + dose, simulate 0..2688.0 h, plot.
p = Nemolizumab_Fauchet2026_reference_params();
[model, dose, variant] = build_sb_pk(p);
sd = simulate_sb(model, variant, dose, 2688.0);
