model Nemolizumab_Fauchet2026_reference
  parameter Real Cl_ref = 3.0439814814814813e-09 "Cl [m3/s]";
  parameter Real cov_albumin_0 = 0 "albumin covariate";
  parameter Real cov_crcl_1 = 0 "crcl covariate";
  parameter Real cov_ethnicity_2 = 0 "ethnicity covariate";
  parameter Real cov_race_3 = 0 "race covariate";
  parameter Real cov_sex_4 = 0 "sex covariate";
  parameter Real Vd_ref = 0.00767 "Vd [m3]";
  parameter Real cov_bodyweight_1 = 0 "bodyweight covariate";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref*(1 + (-1.35)*cov_albumin_0)*(1 + (0.168)*cov_crcl_1)*(1 + (0.226)*cov_ethnicity_2)*(1 + (0.186)*cov_race_3)*(1 + (0.1)*cov_sex_4),
    Vd = Vd_ref*(1 + (-0.535)*cov_albumin_0)*(1 + (0.802)*cov_bodyweight_1),
    adminDuration = 600,
    adminCount = 1,
    adminMass = 3e-05,
    ka = 5.509259259259259e-06,
    Tlag = 3715.2
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About nemolizumab</h4><p>Nemolizumab is a monoclonal antibody used to treat atopic dermatitis and prurigo. It is authorised in the European Union and is also being investigated for further uses.</p><p><small><b>Unverified</b> — written by glm-5.3-flash from general knowledge (no Wikidata entry found) and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>nemolizumab</td></tr><tr><td>population:</td><td>adults and adolescents with moderate to severe atopic dermatitis</td></tr><tr><td>source_paper:</td><td>Fauchet_2026</td></tr><tr><td>measured_compound:</td><td>nemolizumab</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>Table 2</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr></table><h4>Interpretation flags</h4><ul><li>dropped unlinked row (NIL): 'Dose effect on F^b' — extend the ontology if this is a real PK parameter (source ['Fauchet_2026_table_p7_1:row5:col1', 'Fauchet_2026_table_p7_1:row5:col3'])</li><li>covariate effect for Q319 has no base parameter row (kept as unattached equation-variable)</li><li>implicit units: 'K_a (1/day)' → 1/day (from the paper text: &quot;The provided paper text explicitly lists the parameter as 'K A (1/day) 0.476' in the table content section.&quot;)</li><li>apparent-ness (ontology-grounded): parameterization=apparent, measured_compound=nemolizumab</li><li>molar mass: none found for 'nemolizumab' — its concentrations stay mass-only</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 9676800, Tolerance = 1e-9, Interval = 1));
end Nemolizumab_Fauchet2026_reference;
