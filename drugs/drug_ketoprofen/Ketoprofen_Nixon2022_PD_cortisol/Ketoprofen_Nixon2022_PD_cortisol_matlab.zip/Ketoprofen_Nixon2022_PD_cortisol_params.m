function p = Ketoprofen_Nixon2022_PD_cortisol_params()
% Ketoprofen_Nixon2022_PD_cortisol_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% ketoprofen Nixon_2022::cortisol: indirect_response_i exposure-response sweep (response = E0/(1 + Emax*frac)). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one μg/ml per second, in SI inside (kg/m3, s). Response cortisol in % difference. Driver: S-(+)-ketoprofen (conc_no_pk).
p.E0 = 90.91666666666666;
p.Emax = 73.0;
p.EC50 = 0.0025599999999999993;
p.gamma = 1.9;
p.slope = 0.0;
p.exposure_per_s = 0.001;
p.stop_time = 3.9;
p.form = 'E0/(1 + Emax*frac)';
end
