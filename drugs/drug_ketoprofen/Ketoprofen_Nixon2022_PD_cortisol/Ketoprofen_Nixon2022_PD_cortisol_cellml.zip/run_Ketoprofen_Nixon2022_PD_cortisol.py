#!/usr/bin/env python3
"""Sweep Ketoprofen_Nixon2022_PD_cortisol.cellml — the curve is evaluated directly (one ODE for the swept exposure and
one algebraic response), so no CellML tooling is needed; OpenCOR opens the file as-is.
Writes Ketoprofen_Nixon2022_PD_cortisol.csv/.json/.png next to this script."""
import json, os, math
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

BASE = os.path.join(os.path.dirname(os.path.abspath(__file__)), "Ketoprofen_Nixon2022_PD_cortisol")
E0, Emax, EC50, gamma, slope, exposure_per_s = 90.91666666666666, 73.0, 0.0025599999999999993, 1.9, 0.0, 0.001
def response(exposure):
    frac = exposure**gamma / (EC50**gamma + exposure**gamma) if exposure > 0 else 0.0
    log = math.log
    return E0/(1 + Emax*(exposure**gamma / (EC50**gamma + exposure**gamma)))
x = [exposure_per_s * 3.9 * i / 500 for i in range(501)]
y = [response(v) for v in x]
with open(BASE + ".csv", "w") as f:
    f.write("exposure_si,response\n")
    for xi, yi in zip(x, y):
        f.write("%r,%r\n" % (xi, yi))
with open(BASE + ".json", "w") as f:
    json.dump({"model": "Ketoprofen_Nixon2022_PD_cortisol", "exposure_si": x, "response": y}, f, indent=2)
plt.figure(); plt.plot(x, y, linewidth=1.5)
plt.xlabel("exposure [μg/ml]"); plt.ylabel("response [% difference]")
plt.title("Ketoprofen_Nixon2022_PD_cortisol"); plt.grid(True, alpha=0.3); plt.tight_layout(); plt.savefig(BASE + ".png", dpi=150)
print("wrote %s.csv, %s.json, %s.png" % (BASE, BASE, BASE))
