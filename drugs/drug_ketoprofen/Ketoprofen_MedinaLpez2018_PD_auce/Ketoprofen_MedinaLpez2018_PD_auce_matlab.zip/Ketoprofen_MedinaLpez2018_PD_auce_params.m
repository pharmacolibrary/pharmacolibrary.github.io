function p = Ketoprofen_MedinaLpez2018_PD_auce_params()
% Ketoprofen_MedinaLpez2018_PD_auce_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% ketoprofen Medina-López_2018::AUCe: sigmoid_emax exposure-response sweep (response = E0 + Emax*frac). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one μg·h/mL per second, in SI inside (kg/m3, s). Response AUCe in %h. Driver: cumulative (S)-ketoprofen plasma level (not_resolved).
p.E0 = 0.0;
p.Emax = 9079.56;
p.EC50 = 5.49;
p.gamma = 1.64;
p.slope = 0.0;
p.exposure_per_s = 1.0;
p.stop_time = 55.0;
p.form = 'E0 + Emax*frac';
end
