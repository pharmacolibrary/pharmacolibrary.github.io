model Ketoprofen_MedinaLpez2018_PD_auce
  "sigmoid_emax exposure-response sweep — Medina-López_2018 :: AUCe (cumulative antinociceptive effect)"
  extends Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep(
    E0 = 0,      // [1]
    Emax = 9079.56,  // [s; %h × 36]
    EC50 = 5.49,  // [μg·h/mL]
    gamma = 1.64,
    exposure_per_s = 1);   // 1 μg·h/mL per second
  // exposure_unit_unresolved: 'μg·h/mL' — the x axis is in the paper's unit, not SI
  // defaulted: E0
  annotation(experiment(StartTime = 0, StopTime = 55, Interval = 0.11),
    Documentation(info = "<html><body><!-- drug-about --><h4>About ketoprofen</h4><p>Ketoprofen is a non-steroidal anti-inflammatory drug used to treat pain, osteoarthritis, and rheumatoid arthritis. It is an approved medicine, available as topical products for joint and muscular pain as well as systemic anti-inflammatory preparations, and is also approved for veterinary use.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q409192\">Wikidata Q409192</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h4>Ketoprofen_MedinaLpez2018_PD_auce</h4><p>The steady-state exposure-response curve of Medina-López R et al., <i>Pharmaceutics 10(1)</i> 2018 (<a href=\"https://doi.org/10.3390/pharmaceutics10010020\">doi:10.3390/pharmaceutics10010020</a>) — cumulative antinociceptive effect [%h] against cumulative (S)-ketoprofen plasma level μg·h/mL — obtained by sweeping the driver instead of simulating a dose. Model family: sigmoid_emax.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = (library default) drug-free response (baseline)
  Emax  =     252.21 %h       maximal effect term (Emax, Q320)
  EC50  =       5.49 μg·h/mL  exposure at half of the maximal effect term (EC50, Q321)
  gamma =       1.64          Hill coefficient (Response factor, Q325)</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep\">SigmoidEmaxSweep</a>; this model only supplies the numbers. The x axis is one μg·h/mL of cumulative (S)-ketoprofen plasma level per second of simulated time: there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0   (drug-free)
  exposure = EC50 (5.49 μg·h/mL)  response 4540
  exposure -> infinity  response 9080</pre></body></html>"));
end Ketoprofen_MedinaLpez2018_PD_auce;
