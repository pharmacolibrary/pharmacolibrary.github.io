function p = Ketoprofen_Nixon2022_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: ketoprofen   source: Nixon_2022 / reference   route: oral
  p.name  = 'Ketoprofen_Nixon2022_reference_params';
  p.drug  = 'ketoprofen';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 21.1477;                % central volume [L]
  p.CL = 4.2462;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 5.63;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 150.0;             % dose [mg]
end
