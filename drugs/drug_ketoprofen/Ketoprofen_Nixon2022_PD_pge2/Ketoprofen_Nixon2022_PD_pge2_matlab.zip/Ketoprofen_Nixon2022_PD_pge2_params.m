function p = Ketoprofen_Nixon2022_PD_pge2_params()
% Ketoprofen_Nixon2022_PD_pge2_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% ketoprofen Nixon_2022::PGE2: indirect_response_i exposure-response sweep (response = E0/(1 + Emax*frac)). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one μg/ml per second, in SI inside (kg/m3, s). Response PGE2 in % difference. Driver: S-(+)-ketoprofen (conc_no_pk).
p.E0 = 88.54700854700855;
p.Emax = 97.33;
p.EC50 = 7.999999999999998e-05;
p.gamma = 2.07;
p.slope = 0.0;
p.exposure_per_s = 0.001;
p.stop_time = 0.12;
p.form = 'E0/(1 + Emax*frac)';
end
