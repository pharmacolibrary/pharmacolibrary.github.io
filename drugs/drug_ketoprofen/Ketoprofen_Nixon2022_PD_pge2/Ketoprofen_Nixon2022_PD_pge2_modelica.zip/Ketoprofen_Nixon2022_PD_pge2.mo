model Ketoprofen_Nixon2022_PD_pge2
  "indirect_response_i exposure-response sweep — Nixon_2022 :: PGE2 (interstitial fluid prostaglandin E2)"
  extends Pharmacolibrary.Pharmacodynamic.IndirectTurnoverSweep(
    E0 = 88.547008547,      // [% difference]
    Emax = 97.33,  // type IV effect term
    EC50 = 8e-05,  // [kg/m3; μg/ml × 0.001]
    gamma = 2.07,
    exposure_per_s = 0.001);   // 1 μg/ml per second
  // e0_from_kin_kout: no baseline row; E0 = kin/kout (207.2/2.34 = 88.55) — the paper's stated baseline may differ
  // emax_not_a_fraction: type I needs Imax ≤ 1 but the record has 97.33; bound as the reciprocal stimulation form (IV) the paper fitted
  annotation(experiment(StartTime = 0, StopTime = 0.12, Interval = 0.00024),
    Documentation(info = "<html><body><!-- drug-about --><h4>About ketoprofen</h4><p>Ketoprofen is a non-steroidal anti-inflammatory drug used to treat pain, osteoarthritis, and rheumatoid arthritis. It is an approved medicine, available as topical products for joint and muscular pain as well as systemic anti-inflammatory preparations, and is also approved for veterinary use.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q409192\">Wikidata Q409192</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h4>Ketoprofen_Nixon2022_PD_pge2</h4><p>The steady-state exposure-response curve of Nixon E et al., <i>Journal of veterinary pharmacology and therapeutics 45(5):450–466</i> 2022 (<a href=\"https://doi.org/10.1111/jvp.13083\">doi:10.1111/jvp.13083</a>) — interstitial fluid prostaglandin E2 [% difference] against S-(+)-ketoprofen μg/ml — obtained by sweeping the driver instead of simulating a dose. Model family: indirect_response_i.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = 88.547008547 % difference drug-free response (baseline) (kin/kout, Q327/Q328)
  Emax  =      97.33          maximal effect term (Imax, Q323)
  EC50  =       0.08 μg/ml    exposure at half of the maximal effect term (ISF IC50, Q322)
  gamma =       2.07          Hill coefficient (Gamma, Q325)</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.IndirectTurnoverSweep\">IndirectTurnoverSweep</a>; this model only supplies the numbers. The x axis is one μg/ml of S-(+)-ketoprofen per second of simulated time (exposure is in kg/m3): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><p>The effect term enters as a reciprocal (steady state of <code>der(R) = Kin - Kout*(1 + Emax*frac)*R</code>), so EC50 is the exposure at half the maximal STIMULATION of turnover, not at half the response.</p><h4>What it reproduces</h4><pre>  exposure = 0         response 88.55   (drug-free)
  exposure = EC50 (0.08 μg/ml)  response 1.783
  exposure -> infinity  response 0.9005</pre></body></html>"));
end Ketoprofen_Nixon2022_PD_pge2;
