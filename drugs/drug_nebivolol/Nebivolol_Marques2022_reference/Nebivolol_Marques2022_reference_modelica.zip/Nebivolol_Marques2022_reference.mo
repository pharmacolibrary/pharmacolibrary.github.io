model Nebivolol_Marques2022_reference
  parameter Real Cl_ref = 6.111111111111111e-08 "Cl [m3/s]";
  parameter Real Vd_ref = 0.00421 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C_enteral(
    weight = 70.0,
    F = 0.9,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.405435,
    adminMass = 2.5e-06,
    ka = 0.0005722222222222222,
    Tlag = 1080.0,
    k12 = 3.892847717075746e-05,
    k21 = 2.3018102372034958e-05
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About nebivolol</h4><p>Nebivolol is a selective beta blocker used to treat high blood pressure (arterial hypertension). It is an approved medicine, available alone and in fixed combinations with thiazides, calcium channel blockers, ACE inhibitors, ARBs, or lipid-lowering drugs.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q418130\">Wikidata Q418130</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>nebivolol</td></tr><tr><td>population:</td><td>young and healthy individuals</td></tr><tr><td>source_paper:</td><td>Marques_2022</td></tr><tr><td>measured_compound:</td><td>nebivolol</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>pharmaceutics-14-01911-t005</td></tr><tr><td>input:</td><td>PK_2C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>nebivolol 405.435 g/mol (drugbank)</td></tr></table><p><b>Defaulted (base-class default used):</b> F.</p><h4>Interpretation flags</h4><ul><li>dropped unlinked row (NIL): 'b' — extend the ontology if this is a real PK parameter (source ['pharmaceutics-14-01911-t005:row8:col1', 'pharmaceutics-14-01911-t005:row8:col2'])</li><li>implicit units: 'Tlag pop' → h (from the popPK convention: 'Lag time (Tlag) is a time parameter; the standard unit in population PK is hours (h), consistent with the magnitude 0.30')</li><li>implicit units: 'Ka pop' → 1/h (from the popPK convention: 'Absorption rate constant (Ka) is a first-order rate constant; the standard unit is 1/h, consistent with the magnitude 2.')</li><li>implicit units: 'Cl pop' → L/h (from the popPK convention: 'Clearance (Cl) is typically expressed in L/h in population PK; the magnitude 0.22 is consistent with this unit for a dru')</li><li>implicit units: 'V1 pop' → L (from the popPK convention: 'Volume of distribution (V1) is typically expressed in L; the magnitude 4.21 is consistent with this unit.')</li><li>implicit units: 'Q pop' → L/h (from the popPK convention: 'Intercompartmental clearance (Q) is a clearance parameter; the standard unit is L/h, consistent with the magnitude 0.59.')</li><li>implicit units: 'V2 pop' → L (from the popPK convention: 'Volume of distribution (V2) is typically expressed in L; the magnitude 7.12 is consistent with this unit.')</li><li>apparent-by-design (ADVISORY, codes unchanged): extravascular dosing with no identifiable F, so these reported disposition parameters are likely apparent unless the model puts first-pass in its structure — Q22 (Cl pop); Q63 (V1 pop); Q30 (Q pop); Q64 (V2 pop)</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=nebivolol</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 259200, Tolerance = 1e-9, Interval = 1));
end Nebivolol_Marques2022_reference;
