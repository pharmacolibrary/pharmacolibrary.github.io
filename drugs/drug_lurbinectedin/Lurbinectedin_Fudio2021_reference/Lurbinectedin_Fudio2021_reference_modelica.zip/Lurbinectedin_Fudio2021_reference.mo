model Lurbinectedin_Fudio2021_reference
  parameter Real Cl_ref = 3.111111111111111e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.3477 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.78488,
    adminMass = 1e-05
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About lurbinectedin</h4><p>Lurbinectedin is an anticancer medicine used to treat small cell lung cancer. It is an approved antineoplastic agent, with one product authorised in the European Union.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q27254568\">Wikidata Q27254568</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>lurbinectedin</td></tr><tr><td>population:</td><td>review reference</td></tr><tr><td>source_paper:</td><td>Fudio_2021</td></tr><tr><td>measured_compound:</td><td>lurbinectedin</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>lurbinectedin 784.88 g/mol (drugbank)</td></tr></table><h4>Interpretation flags</h4><ul><li>built from REVIEW reference values (Fudio_2021) — secondary source</li><li>volume reported by review</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 432000, Tolerance = 1e-9, Interval = 1));
end Lurbinectedin_Fudio2021_reference;
