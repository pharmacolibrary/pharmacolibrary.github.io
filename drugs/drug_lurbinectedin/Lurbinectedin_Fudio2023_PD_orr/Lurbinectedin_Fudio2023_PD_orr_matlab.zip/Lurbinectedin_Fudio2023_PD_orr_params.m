function p = Lurbinectedin_Fudio2023_PD_orr_params()
% Lurbinectedin_Fudio2023_PD_orr_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% lurbinectedin Fudio_2023::ORR: sigmoid_emax exposure-response sweep (response = E0 + Emax*frac). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one ng·h/L per second, in SI inside (kg/m3, s). Response ORR in its own unit. Driver: unbound plasma lurbinectedin area under the concentration-time curve (AUC u ) (dose_only).
p.E0 = 0.0;
p.Emax = 8.5;
p.EC50 = 877.0;
p.gamma = 1.0;
p.slope = 0.0;
p.exposure_per_s = 1.0;
p.stop_time = 8800.0;
p.form = 'E0 + Emax*frac';
end
