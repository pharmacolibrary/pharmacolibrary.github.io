model Lurbinectedin_Fudio2023_PD_orr
  "sigmoid_emax exposure-response sweep — Fudio_2023 :: ORR (objective response rate (ORR))"
  extends Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep(
    E0 = 0,      // [1]
    Emax = 8.5,  // [1]
    EC50 = 877,  // [ng·h/L]
    gamma = 1,
    exposure_per_s = 1);   // 1 ng·h/L per second
  // exposure_unit_unresolved: 'ng·h/L' — the x axis is in the paper's unit, not SI
  // defaulted: E0
  // defaulted: gamma
  annotation(experiment(StartTime = 0, StopTime = 8800, Interval = 17.6),
    Documentation(info = "<html><body><!-- drug-about --><h4>About lurbinectedin</h4><p>Lurbinectedin is an anticancer medicine used to treat small cell lung cancer. It is an approved antineoplastic agent, with one product authorised in the European Union.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q27254568\">Wikidata Q27254568</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h4>Lurbinectedin_Fudio2023_PD_orr</h4><p>The steady-state exposure-response curve of Fudio S et al., <i>Frontiers in oncology 13:1152371</i> 2023 (<a href=\"https://doi.org/10.3389/fonc.2023.1152371\">doi:10.3389/fonc.2023.1152371</a>) — objective response rate (ORR) against unbound plasma lurbinectedin area under the concentration-time curve (AUC u ) ng·h/L — obtained by sweeping the driver instead of simulating a dose. Model family: sigmoid_emax.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = (library default) drug-free response (baseline)
  Emax  =        8.5          maximal effect term (Emax resistant, Q320)
  EC50  =        877 ng·h/L   exposure at half of the maximal effect term (EC50, Q321)
  gamma = (library default) Hill coefficient</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep\">SigmoidEmaxSweep</a>; this model only supplies the numbers. The x axis is one ng·h/L of unbound plasma lurbinectedin area under the concentration-time curve (AUC u ) per second of simulated time: there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0   (drug-free)
  exposure = EC50 (877 ng·h/L)  response 4.25
  exposure -> infinity  response 8.5</pre></body></html>"));
end Lurbinectedin_Fudio2023_PD_orr;
