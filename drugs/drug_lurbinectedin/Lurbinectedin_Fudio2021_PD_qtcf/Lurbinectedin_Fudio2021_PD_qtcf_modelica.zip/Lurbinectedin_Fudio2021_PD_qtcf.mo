model Lurbinectedin_Fudio2021_PD_qtcf
  "linear exposure-response sweep — Fudio_2021 :: ΔQTcF (change from baseline in Fridericia’s corrected QT interval)"
  extends Pharmacolibrary.Interfaces.PartialExposureResponseSweep(
    E0 = 0,      // [1]
    Emax = 0, EC50 = 1,      // unused by a line
    exposure_per_s = 1e-06);
  parameter Real slope = 0.289   "[ms L/µg]";
equation
  response = E0 + slope*exposure;
  // family_inferred: the record's model family is effect_compartment; read from the parameters: a slope and no Emax — linear
  // defaulted: E0
  annotation(experiment(StartTime = 0, StopTime = 1000, Interval = 2),
    Documentation(info = "<html><body><!-- drug-about --><h4>About lurbinectedin</h4><p>Lurbinectedin is an anticancer medicine used to treat small cell lung cancer. It is an approved antineoplastic agent, with one product authorised in the European Union.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q27254568\">Wikidata Q27254568</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h4>Lurbinectedin_Fudio2021_PD_qtcf</h4><p>The steady-state exposure-response curve of Fudio S et al., <i>Cancer chemotherapy and pharmacology 87(1):113–124</i> 2021 (<a href=\"https://doi.org/10.1007/s00280-020-04153-6\">doi:10.1007/s00280-020-04153-6</a>) — change from baseline in Fridericia’s corrected QT interval [ms] against lurbinectedin µg/L — obtained by sweeping the driver instead of simulating a dose. Model family: linear.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = (library default) drug-free response (baseline)
  slope =      0.289 ms L/µg  change in response per unit of exposure (Slope, Q335)</pre><p>The algebra is <code>response = E0 + slope*exposure</code>; this model only supplies the numbers. The x axis is one µg/L of lurbinectedin per second of simulated time (exposure is in kg/m3): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0   (drug-free)</pre></body></html>"));
end Lurbinectedin_Fudio2021_PD_qtcf;
