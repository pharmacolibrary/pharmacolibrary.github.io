function p = Lurbinectedin_Fudio2021_PD_qtcf_params()
% Lurbinectedin_Fudio2021_PD_qtcf_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% lurbinectedin Fudio_2021::QTcF: linear exposure-response sweep (response = E0 + slope*exposure). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one µg/L per second, in SI inside (kg/m3, s). Response ΔQTcF in ms. Driver: lurbinectedin (pk_record).
p.E0 = 0.0;
p.Emax = 0.0;
p.EC50 = 1.0;
p.gamma = 1.0;
p.slope = 0.289;
p.exposure_per_s = 1e-06;
p.stop_time = 1000.0;
p.form = 'E0 + slope*exposure';
end
