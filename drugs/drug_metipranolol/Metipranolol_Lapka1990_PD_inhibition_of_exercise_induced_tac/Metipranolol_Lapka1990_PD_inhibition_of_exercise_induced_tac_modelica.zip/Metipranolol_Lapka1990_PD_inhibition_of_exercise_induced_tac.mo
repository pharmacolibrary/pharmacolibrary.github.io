model Metipranolol_Lapka1990_PD_inhibition_of_exercise_induced_tac
  "emax exposure-response sweep — Lapka_1990 :: inhibition of exercise-induced tachycardia (inhibition of exercise-induced tachycardia)"
  extends Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep(
    E0 = 0,      // [1]
    Emax = -0.26,  // [1; % × 0.01]
    EC50 = 2.9e-06,  // [kg/m3; ng/ml × 1e-06]
    gamma = 1,
    exposure_per_s = 1e-06);   // 1 ng/ml per second
  // imax_as_negative_emax: Imax (Q323) enters SigmoidEmaxSweep as −Emax
  // defaulted: E0
  // defaulted: gamma
  annotation(experiment(StartTime = 0, StopTime = 29, Interval = 0.058),
    Documentation(info = "<html><body><!-- drug-about --><h4>About metipranolol</h4><p>Metipranolol is a non-selective beta blocker that was used to treat open-angle glaucoma and ocular hypertension, and also as an antihypertensive and antiarrhythmic agent. It has been withdrawn from use, though it was once an approved medicine.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q6593346\">Wikidata Q6593346</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h4>Metipranolol_Lapka1990_PD_inhibition_of_exercise_induced_tac</h4><p>The steady-state exposure-response curve of Lapka R et al., <i>European journal of clinical pharmacology 38(3):243–247</i> 1990 (<a href=\"https://doi.org/10.1007/BF00315024\">doi:10.1007/BF00315024</a>) — inhibition of exercise-induced tachycardia against deacetylmetipranolol ng/ml — obtained by sweeping the driver instead of simulating a dose. Model family: emax.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = (library default) drug-free response (baseline)
  Emax  =         26 %        maximal effect term (Emax, Q323)
  EC50  =        2.9 ng/ml    exposure at half of the maximal effect term (C50, Q322)
  gamma = (library default) Hill coefficient</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep\">SigmoidEmaxSweep</a>; this model only supplies the numbers. The x axis is one ng/ml of deacetylmetipranolol per second of simulated time (exposure is in kg/m3): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0   (drug-free)
  exposure = EC50 (2.9 ng/ml)  response -0.13
  exposure -> infinity  response -0.26</pre></body></html>"));
end Metipranolol_Lapka1990_PD_inhibition_of_exercise_induced_tac;
