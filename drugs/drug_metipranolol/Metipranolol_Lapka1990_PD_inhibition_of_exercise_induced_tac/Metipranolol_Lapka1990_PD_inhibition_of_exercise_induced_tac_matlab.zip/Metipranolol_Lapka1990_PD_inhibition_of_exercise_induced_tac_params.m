function p = Metipranolol_Lapka1990_PD_inhibition_of_exercise_induced_tac_params()
% Metipranolol_Lapka1990_PD_inhibition_of_exercise_induced_tac_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% metipranolol Lapka_1990::inhibition_of_exercise_induced_tachycardia: emax exposure-response sweep (response = E0 + Emax*frac). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one ng/ml per second, in SI inside (kg/m3, s). Response inhibition of exercise-induced tachycardia in its own unit. Driver: deacetylmetipranolol (conc_no_pk).
p.E0 = 0.0;
p.Emax = -0.26;
p.EC50 = 2.8999999999999998e-06;
p.gamma = 1.0;
p.slope = 0.0;
p.exposure_per_s = 1e-06;
p.stop_time = 29.0;
p.form = 'E0 + Emax*frac';
end
