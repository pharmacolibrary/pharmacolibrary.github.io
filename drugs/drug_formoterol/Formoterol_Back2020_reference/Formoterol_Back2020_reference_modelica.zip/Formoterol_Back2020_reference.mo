model Formoterol_Back2020_reference
  parameter Real Cl_ref = 5.111111111111111e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.216 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C_enteral(
    weight = 70.0,
    F = 0.9,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.3444049,
    adminMass = 1.6e-07,
    ka = 0.005472222222222222,
    Tlag = 0.0,
    k12 = 0.0001135545267489712,
    k21 = 0.00023139412997903565
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About formoterol</h4><p>Formoterol is a long-acting inhaled beta-2 agonist used to treat asthma and chronic obstructive pulmonary disease. It is widely used, both alone and in combination inhalers with corticosteroids or anticholinergics, and is an approved medicine.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q637247\">Wikidata Q637247</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>formoterol</td></tr><tr><td>population:</td><td>review reference</td></tr><tr><td>source_paper:</td><td>Back_2020</td></tr><tr><td>measured_compound:</td><td>formoterol</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_2C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>formoterol 344.405 g/mol (drugbank)</td></tr></table><p><b>Defaulted (base-class default used):</b> F, Tlag.</p><h4>Interpretation flags</h4><ul><li>built from REVIEW reference values (Back_2020) — secondary source</li><li>volume reported by review</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 147600, Tolerance = 1e-9, Interval = 1));
end Formoterol_Back2020_reference;
