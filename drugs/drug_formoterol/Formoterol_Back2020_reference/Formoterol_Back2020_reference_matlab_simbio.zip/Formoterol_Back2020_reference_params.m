function p = Formoterol_Back2020_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: formoterol   source: Back_2020 / reference   route: oral
  % estimated (absent from source): F
  p.name  = 'Formoterol_Back2020_reference_params';
  p.drug  = 'formoterol';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 216.0;                % central volume [L]
  p.CL = 18.4;                % clearance [L/h]
  p.Vp = [106.0];             % peripheral volumes [L]
  p.Q  = [88.3];             % inter-compartmental clearances [L/h]
  p.ka = 19.7;                % absorption rate [1/h]
  p.F  = 0.9;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 0.16;             % dose [mg]
end
