model Formoterol_Back2020_PD_fev1
  "indirect_response_iii exposure-response sweep — Back_2020 :: FEV1 (Forced expiratory volume (FEV1))"
  extends Pharmacolibrary.Interfaces.PartialExposureResponseSweep(
    E0 = 0.858,      // [1; % × 0.01]
    Emax = 1,  // type III effect term
    EC50 = 8.1e-11,  // [kg/m3; pg·mL−1 × 1e-09]
    gamma = 1,
    exposure_per_s = 1e-09);   // 1 pg·mL−1 per second
equation
  response = E0*(1 + Emax*frac);   // steady state, indirect response type III
  // defaulted: Emax
  // defaulted: gamma
  annotation(experiment(StartTime = 0, StopTime = 0.81, Interval = 0.00162),
    Documentation(info = "<html><body><!-- drug-about --><h4>About formoterol</h4><p>Formoterol is a long-acting inhaled beta-2 agonist used to treat asthma and chronic obstructive pulmonary disease. It is widely used, both alone and in combination inhalers with corticosteroids or anticholinergics, and is an approved medicine.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q637247\">Wikidata Q637247</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h4>Formoterol_Back2020_PD_fev1</h4><p>The steady-state exposure-response curve of Back HM et al., <i>Pharmaceutics 12(4)</i> 2020 (<a href=\"https://doi.org/10.3390/pharmaceutics12040336\">doi:10.3390/pharmaceutics12040336</a>) — Forced expiratory volume (FEV1) [%FEV1] against formoterol pg·mL−1 — obtained by sweeping the driver instead of simulating a dose. Model family: indirect_response_iii.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    =       85.8 %        drug-free response (baseline) (BASE, Q324)
  Emax  = (library default) maximal effect term
  EC50  =      0.081 pg·mL−1  exposure at half of the maximal effect term (EC50, Q321)
  gamma = (library default) Hill coefficient</pre><p>The algebra is <code>response = E0*(1 + Emax*frac)</code>; this model only supplies the numbers. The x axis is one pg·mL−1 of formoterol per second of simulated time (exposure is in kg/m3): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0.858   (drug-free)
  exposure = EC50 (0.081 pg·mL−1)  response 1.287
  exposure -> infinity  response 1.716</pre></body></html>"));
end Formoterol_Back2020_PD_fev1;
