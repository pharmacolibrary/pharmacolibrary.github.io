function p = Formoterol_Back2020_PD_fev1_params()
% Formoterol_Back2020_PD_fev1_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% formoterol Back_2020::FEV1: indirect_response_iii exposure-response sweep (response = E0*(1 + Emax*frac)). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one pg·mL−1 per second, in SI inside (kg/m3, s). Response FEV1 in %FEV1. Driver: formoterol (pk_record).
p.E0 = 0.858;
p.Emax = 1.0;
p.EC50 = 8.1e-11;
p.gamma = 1.0;
p.slope = 0.0;
p.exposure_per_s = 1e-09;
p.stop_time = 0.81;
p.form = 'E0*(1 + Emax*frac)';
end
