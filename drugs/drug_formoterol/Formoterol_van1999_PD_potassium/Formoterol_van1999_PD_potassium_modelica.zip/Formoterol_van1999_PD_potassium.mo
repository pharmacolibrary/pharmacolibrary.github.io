model Formoterol_van1999_PD_potassium
  "sigmoid_emax exposure-response sweep — van_1999 :: potassium (plasma potassium concentration (hypokalemic effect))"
  extends Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep(
    E0 = 0,      // [1]
    Emax = -2.29,  // [mol/m3; mmol/l × 1]
    EC50 = 1.284e-07,  // [kg/m3; pg/ml × 1e-09]
    gamma = 1,
    exposure_per_s = 1e-09);   // 1 pg/ml per second
  // imax_as_negative_emax: Imax (Q323) enters SigmoidEmaxSweep as −Emax
  // defaulted: E0
  // defaulted: gamma
  annotation(experiment(StartTime = 0, StopTime = 1300, Interval = 2.6),
    Documentation(info = "<html><body><!-- drug-about --><h4>About formoterol</h4><p>Formoterol is a long-acting inhaled beta-2 agonist used to treat asthma and chronic obstructive pulmonary disease. It is widely used, both alone and in combination inhalers with corticosteroids or anticholinergics, and is an approved medicine.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q637247\">Wikidata Q637247</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h4>Formoterol_van1999_PD_potassium</h4><p>The steady-state exposure-response curve of van den Berg BT et al., <i>Pulmonary pharmacology &amp; therapeutics 12(3):185–192</i> 1999 (<a href=\"https://doi.org/10.1006/pupt.1999.0199\">doi:10.1006/pupt.1999.0199</a>) — plasma potassium concentration (hypokalemic effect) [mmol/l] against formoterol pg/ml — obtained by sweeping the driver instead of simulating a dose. Model family: sigmoid_emax.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = (library default) drug-free response (baseline)
  Emax  =       2.29 mmol/l   maximal effect term (Emax, Q323)
  EC50  =      128.4 pg/ml    exposure at half of the maximal effect term (EC50, Q321)
  gamma = (library default) Hill coefficient</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep\">SigmoidEmaxSweep</a>; this model only supplies the numbers. The x axis is one pg/ml of formoterol per second of simulated time (exposure is in kg/m3): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0   (drug-free)
  exposure = EC50 (128.4 pg/ml)  response -1.145
  exposure -> infinity  response -2.29</pre></body></html>"));
end Formoterol_van1999_PD_potassium;
