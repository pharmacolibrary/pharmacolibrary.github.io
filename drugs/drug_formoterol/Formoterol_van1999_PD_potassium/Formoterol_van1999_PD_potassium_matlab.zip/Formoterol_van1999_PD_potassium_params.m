function p = Formoterol_van1999_PD_potassium_params()
% Formoterol_van1999_PD_potassium_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% formoterol van_1999::potassium: sigmoid_emax exposure-response sweep (response = E0 + Emax*frac). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one pg/ml per second, in SI inside (kg/m3, s). Response potassium in mmol/l. Driver: formoterol (cited_pk).
p.E0 = 0.0;
p.Emax = -2.2899999999999996;
p.EC50 = 1.284e-07;
p.gamma = 1.0;
p.slope = 0.0;
p.exposure_per_s = 1e-09;
p.stop_time = 1300.0;
p.form = 'E0 + Emax*frac';
end
