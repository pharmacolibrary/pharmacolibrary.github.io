function p = Fruquintinib_Zhou2025_us1_nct03251378_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: fruquintinib   source: Zhou_2025 / us1_nct03251378   route: oral
  p.name  = 'Fruquintinib_Zhou2025_us1_nct03251378_params';
  p.drug  = 'fruquintinib';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 48.5;                % central volume [L]
  p.CL = 0.808;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 2.52;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.463;             % absorption lag [h]
  p.dose = 1.0;             % dose [mg]
end
