% Run (SimBiology): build model + dose, simulate 0..216.0 h, plot.
p = Fruquintinib_Zhou2025_us1_nct03251378_params();
[model, dose, variant] = build_sb_pk(p);
sd = simulate_sb(model, variant, dose, 216.0);
