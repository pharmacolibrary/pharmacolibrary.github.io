% Run: build params, simulate 0..216.0 h, plot + save Fruquintinib_Zhou2025_us1_nct03251378.png/.csv/.json.
% Interactive display (keep the window open):  octave --persist run_Fruquintinib_Zhou2025_us1_nct03251378.m
here = fileparts(mfilename('fullpath'));
p = Fruquintinib_Zhou2025_us1_nct03251378_params();
out = simulate_pk(p, 0:0.05:216.0);

% figure (shown on screen if interactive) and PNG (works in MATLAB and Octave)
fig = figure; plot(out.t, out.C, 'LineWidth', 1.5); grid on;
xlabel('time [h]'); ylabel('central concentration [mg/L]');
title('fruquintinib — Zhou_2025 (oral)');
print(fig, fullfile(here, 'Fruquintinib_Zhou2025_us1_nct03251378.png'), '-dpng', '-r150');

% CSV (time_h, Cc_mg_per_L)
fid = fopen(fullfile(here, 'Fruquintinib_Zhou2025_us1_nct03251378.csv'), 'w');
fprintf(fid, 'time_h,Cc_mg_per_L\n');
fprintf(fid, '%.10g,%.10g\n', [out.t(:), out.C(:)].');
fclose(fid);

% JSON (summary + arrays; jsonencode with a manual fallback for older versions)
fid = fopen(fullfile(here, 'Fruquintinib_Zhou2025_us1_nct03251378.json'), 'w');
try
  s.model = 'Fruquintinib_Zhou2025_us1_nct03251378'; s.Cmax = out.Cmax; s.Tmax = out.Tmax; s.AUC = out.AUC;
  s.time_h = out.t(:).'; s.Cc_mg_per_L = out.C(:).';
  fprintf(fid, '%s', jsonencode(s));
catch
  fprintf(fid, '{"model":"Fruquintinib_Zhou2025_us1_nct03251378","Cmax":%g,"Tmax":%g,"AUC":%g}', out.Cmax, out.Tmax, out.AUC);
end
fclose(fid);

fprintf('Cmax=%.3g mg/L  Tmax=%.3g h  AUC=%.3g mg*h/L\n', out.Cmax, out.Tmax, out.AUC);
fprintf('wrote Fruquintinib_Zhou2025_us1_nct03251378.png, Fruquintinib_Zhou2025_us1_nct03251378.csv, Fruquintinib_Zhou2025_us1_nct03251378.json\n');
