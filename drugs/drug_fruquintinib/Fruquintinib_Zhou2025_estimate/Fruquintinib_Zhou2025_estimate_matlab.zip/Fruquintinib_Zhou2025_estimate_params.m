function p = Fruquintinib_Zhou2025_estimate_params()
% Auto-generated parent-metabolite PK model (clinical units: mg, L, h).
%   drug: fruquintinib   source: Zhou_2025 / estimate   PK_3M_9C parent + 1 metabolite(s), 2 compartments, oral
%   dA/dt = K*A; C = A./V. K(i,j) is the rate [1/h] at which compartment j feeds i:
%   a metabolic conversion carries MW_dst/MW_src, so one molecule forms one molecule.
%   molar masses: C_central=393.399 g/mol
  p.name  = 'Fruquintinib_Zhou2025_estimate_params';
  p.drug  = 'fruquintinib';
  p.kind  = 'network';
  p.template = 'PK_3M_9C';
  p.states = {'central', 'central_M1'};
  p.V = [50.4, 11.700000000000001];          % compartment volumes [L]
  p.K = [-0.016031746031746032, 0.0;
         0.016031746031746032, -0.01376068376068376];
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;
  p.dose_into = 1;   % central
  p.ka = 2.52;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.4630000000000001;             % absorption lag [h] (in dose_start)
  p.dose = 1.0;             % dose [mg]
  p.dose_start = 0.47966666666666674;   % dose enters from [h] ...
  p.dose_duration = 0.16666666666666666;   % ... at a constant rate for [h]
  p.out_idx = [1.0, 2.0];
  p.out_names = {'C_central', 'C_M1'};
  p.out_labels = {'fruquintinib', 'M11'};
end
