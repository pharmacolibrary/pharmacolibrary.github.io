% Run: build params, simulate 0..240.0 h, plot every molecule + save Fruquintinib_Zhou2025_estimate.png/.csv/.json.
% Interactive display (keep the window open):  octave --persist run_Fruquintinib_Zhou2025_estimate.m
here = fileparts(mfilename('fullpath'));
p = Fruquintinib_Zhou2025_estimate_params();
out = simulate_network(p, 0:0.05:240.0);

fig = figure; semilogy(out.t, max(out.C, 1e-12), 'LineWidth', 1.5); grid on;
legend(p.out_labels, 'Location', 'northeast');
xlabel('time [h]'); ylabel('concentration [mg/L]');
title('fruquintinib — Zhou_2025 (parent + metabolites)');
print(fig, fullfile(here, 'Fruquintinib_Zhou2025_estimate.png'), '-dpng', '-r150');

fid = fopen(fullfile(here, 'Fruquintinib_Zhou2025_estimate.csv'), 'w');
fprintf(fid, 'time_h');
fprintf(fid, ',%s_mg_per_L', p.out_names{:});
fprintf(fid, '\n');
fmt = ['%.10g', repmat(',%.10g', 1, numel(p.out_names)), '\n'];
fprintf(fid, fmt, [out.t(:), out.C].');
fclose(fid);

fid = fopen(fullfile(here, 'Fruquintinib_Zhou2025_estimate.json'), 'w');
try
  s.model = 'Fruquintinib_Zhou2025_estimate'; s.outputs = p.out_names; s.labels = p.out_labels;
  s.Cmax = out.Cmax; s.Tmax = out.Tmax; s.time_h = out.t(:).';
  for j = 1:numel(p.out_names), s.([p.out_names{j} '_mg_per_L']) = out.C(:, j).'; end
  fprintf(fid, '%s', jsonencode(s));
catch
  fprintf(fid, '{"model":"Fruquintinib_Zhou2025_estimate"}');
end
fclose(fid);

for j = 1:numel(p.out_names)
  fprintf('%s (%s): Cmax=%.4g mg/L  Tmax=%.3g h\n', p.out_names{j}, p.out_labels{j}, out.Cmax(j), out.Tmax(j));
end
fprintf('wrote Fruquintinib_Zhou2025_estimate.png, Fruquintinib_Zhou2025_estimate.csv, Fruquintinib_Zhou2025_estimate.json\n');
