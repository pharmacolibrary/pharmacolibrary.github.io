// parent + metabolites (M11): PK_3M_9C — formed from central; parent 1, metabolites [1]
model Fruquintinib_Zhou2025_estimate
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_3M_9C(
    Vd1 = 0.0504,
    q1_m11 = 2.2444444444444445e-07,
    CL1 = 0.0,
    Vd1m1 = 0.0117,
    CLm1 = 4.4722222222222223e-08,
    MW = 0.393399,
    MW_m1 = 0.0,
    F = 1,
    ka = 0.0007,
    Tlag = 1666.8000000000002,
    adminDuration = 600,
    adminCount = 1,
    adminMass = 1e-06
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About fruquintinib</h4><p>Fruquintinib is a protein kinase inhibitor used to treat colorectal cancer. It is an authorised medicine in the European Union for colorectal cancer.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q27259271\">Wikidata Q27259271</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>fruquintinib</td></tr><tr><td>population:</td><td>patients with refractory metastatic colorectal cancer and healthy volunteers</td></tr><tr><td>source_paper:</td><td>Zhou_2025</td></tr><tr><td>measured_compound:</td><td>fruquintinib</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>parent_metabolite</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>jcph70001-tbl-0002</td></tr><tr><td>input:</td><td>PK_3M_9C: absorption rate constant reported; formation of M11: fm not identifiable (CLm/F, Vm/F reported) — all of CL forms it; molar mass not resolved for M11 — set to 0: no molar concentration, formation converts mass 1:1; dose 1 mg (paper)</td></tr><tr><td>molar_masses:</td><td>fruquintinib 393.399 g/mol (drugbank)</td></tr></table><h4>Interpretation flags</h4><ul><li>table section residual_error: 'Fruquintinib proportional error %CV' routed out of structural estimates ('Residual variability')</li><li>table section residual_error: 'Fruquintinib additive error SD (ng/mL)' routed out of structural estimates ('Residual variability')</li><li>table section residual_error: 'M11 proportional error %CV' routed out of structural estimates ('Residual variability')</li><li>table section residual_error: 'M11 additive error SD (ng/mL)' routed out of structural estimates ('Residual variability')</li><li>dropped duplicate Q49 ('Ka ∼ PPI fractional change', value '-0.607') — already have one for this compound</li><li>dropped value-less row: 'F1'</li><li>covariate effect for Q319 has no base parameter row (kept as unattached equation-variable)</li><li>covariate effect for Q319 has no base parameter row (kept as unattached equation-variable)</li><li>covariate effect for Q319 has no base parameter row (kept as unattached equation-variable)</li><li>covariate effect for Q319 has no base parameter row (kept as unattached equation-variable)</li><li>implicit units: 'Ka (1/h)' → 1/h (from the paper text: 'The paper states: “Ka (1/h) = 2.52.”')</li><li>apparent-ness (ontology-grounded): parameterization=apparent, measured_compound=fruquintinib</li><li>template fit: PK_3M_9C — formed from central; parent 1, metabolites [1]</li><li>population split: 'estimate' subgroup of Zhou_2025 (paper reports 8 populations: estimate, fresco‐2/nct04322539 (n = 334), nct01645215 (n = 40), nct01975077 (n = 40), nct04557397 (n = 28), nct04645940 (n = 14), overall (n = 557), us1/nct03251378 (n = 101))</li><li>row roles (LLM): model_class=compartmental; 51/51 row label(s) assigned, 12 linked by role; re-tagged parent→M11 ×18</li><li>molar mass: none of 1 PubChem candidate(s) is 'M11' (LLM) — left in mass units</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 864000, Tolerance = 1e-9, Interval = 1));
end Fruquintinib_Zhou2025_estimate;
