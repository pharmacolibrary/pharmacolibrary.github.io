model Methocarbamol_Rumpler2014_reference
  parameter Real Cl_ref = 1.0488333333333333e-05 "Cl [m3/s]";
  parameter Real Vd_ref = 0.07350000000000001 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.2412405,
    adminMass = 0.003,
    ka = 0.0001388888888888889,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About methocarbamol</h4><p>Methocarbamol is a centrally acting muscle relaxant used for painful muscle spasm, cramps, tetanus and inflammatory myopathy. It is an approved medicine, also approved for veterinary use, and is used fairly widely, though it is not authorised centrally in the European Union.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q411456\">Wikidata Q411456</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>methocarbamol</td></tr><tr><td>population:</td><td>Thoroughbred horses</td></tr><tr><td>source_paper:</td><td>Rumpler_2014</td></tr><tr><td>measured_compound:</td><td>methocarbamol</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C_enteral: apparent (/F) parameterization ⇒ extravascular dosing</td></tr><tr><td>molar_masses:</td><td>methocarbamol 241.24 g/mol (drugbank)</td></tr></table><p><b>Defaulted (base-class default used):</b> ka, Tlag.</p><h4>Interpretation flags</h4><ul><li>dropped duplicate Q57 ('Oral dose of MCBL was characterized by a median (range) terminal half-life', value 2.89) — already have one for this compound</li><li>apparent-ness (ontology-grounded): parameterization=apparent, measured_compound=methocarbamol</li><li>held at status:extracted — NIL link or unit issue (mismatch/unknown/normalisation-failed) present</li><li>status held at route_to_review — not promoted</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Methocarbamol_Rumpler2014_reference;
