function p = Exenatide_Gao2011_PD_ins_params()
% Exenatide_Gao2011_PD_ins_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% exenatide Gao_2011::Ins: indirect_response_iii exposure-response sweep (response = E0*(1 + Emax*frac)). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one nM per second, in SI inside (kg/m3, s). Response Ins in ng/ml. Driver: exendin-4 (pk_record).
p.E0 = 0.27950310559006214;
p.Emax = 6.91;
p.EC50 = 1.29;
p.gamma = 1.0;
p.slope = 0.0;
p.exposure_per_s = 1.0;
p.stop_time = 13.0;
p.form = 'E0*(1 + Emax*frac)';
end
