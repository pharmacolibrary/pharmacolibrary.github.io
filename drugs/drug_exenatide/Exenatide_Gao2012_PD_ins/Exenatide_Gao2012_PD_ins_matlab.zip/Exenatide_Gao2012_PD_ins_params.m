function p = Exenatide_Gao2012_PD_ins_params()
% Exenatide_Gao2012_PD_ins_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% exenatide Gao_2012::Ins: indirect_response_iii exposure-response sweep (response = E0*(1 + Emax*frac)). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one nM per second, in SI inside (kg/m3, s). Response Ins in its own unit. Driver: exendin-4 (cited_pk).
p.E0 = 0.0;
p.Emax = 4.67;
p.EC50 = 0.826;
p.gamma = 1.0;
p.slope = 0.0;
p.exposure_per_s = 1.0;
p.stop_time = 8.3;
p.form = 'E0*(1 + Emax*frac)';
end
