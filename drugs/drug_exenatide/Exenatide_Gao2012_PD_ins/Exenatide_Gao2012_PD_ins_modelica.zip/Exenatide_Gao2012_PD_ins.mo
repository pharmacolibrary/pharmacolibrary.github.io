model Exenatide_Gao2012_PD_ins
  "indirect_response_iii exposure-response sweep — Gao_2012 :: Ins (insulin)"
  extends Pharmacolibrary.Interfaces.PartialExposureResponseSweep(
    E0 = 0,      // [1]
    Emax = 4.67,  // type III effect term
    EC50 = 0.826,  // [nM]
    gamma = 1,
    exposure_per_s = 1);   // 1 nM per second
equation
  response = E0*(1 + Emax*frac);   // steady state, indirect response type III
  // exposure_unit_unresolved: 'nM' — the x axis is in the paper's unit, not SI
  // defaulted: E0
  // defaulted: gamma
  annotation(experiment(StartTime = 0, StopTime = 8.3, Interval = 0.0166),
    Documentation(info = "<html><body><!-- drug-about --><h4>About exenatide</h4><p>Exenatide is a GLP-1 agonist used as an anti-diabetic medication, notably for type 2 diabetes. It is authorised in the European Union and widely used for diabetes, with some additional investigational uses.</p><p><small>Summary written by glm-5.3-flash from <a href=&quot;https://www.wikidata.org/wiki/Q417762&quot;>Wikidata Q417762</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h4>Exenatide_Gao2012_PD_ins</h4><p>The steady-state exposure-response curve of Gao W et al., <i>Drug metabolism and disposition: the biological fate of chemicals 40(5):990–997</i> 2012 (<a href=\"https://doi.org/10.1124/dmd.111.042291\">doi:10.1124/dmd.111.042291</a>) — insulin against exendin-4 nM — obtained by sweeping the driver instead of simulating a dose. Model family: indirect_response_iii.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = (library default) drug-free response (baseline)
  Emax  =       4.67          maximal effect term (Maximal response factor, Q320)
  EC50  =      0.826 nM       exposure at half of the maximal effect term (First receptor binding constant, Q321)
  gamma = (library default) Hill coefficient</pre><p>The algebra is <code>response = E0*(1 + Emax*frac)</code>; this model only supplies the numbers. The x axis is one nM of exendin-4 per second of simulated time: there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0   (drug-free)
  exposure = EC50 (0.826 nM)  response 0
  exposure -> infinity  response 0</pre></body></html>"));
end Exenatide_Gao2012_PD_ins;
