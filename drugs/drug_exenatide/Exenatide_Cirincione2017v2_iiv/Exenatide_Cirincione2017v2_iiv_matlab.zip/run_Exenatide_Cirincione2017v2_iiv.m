% Run: build params, simulate 0..672.0 h, plot + save Exenatide_Cirincione2017v2_iiv.png/.csv/.json.
% Interactive display (keep the window open):  octave --persist run_Exenatide_Cirincione2017v2_iiv.m
here = fileparts(mfilename('fullpath'));
p = Exenatide_Cirincione2017v2_iiv_params();
out = simulate_pk(p, 0:0.05:672.0);

% figure (shown on screen if interactive) and PNG (works in MATLAB and Octave)
fig = figure; plot(out.t, out.C, 'LineWidth', 1.5); grid on;
xlabel('time [h]'); ylabel('central concentration [mg/L]');
title('exenatide — Cirincione_2017_2 (oral)');
print(fig, fullfile(here, 'Exenatide_Cirincione2017v2_iiv.png'), '-dpng', '-r150');

% CSV (time_h, Cc_mg_per_L)
fid = fopen(fullfile(here, 'Exenatide_Cirincione2017v2_iiv.csv'), 'w');
fprintf(fid, 'time_h,Cc_mg_per_L\n');
fprintf(fid, '%.10g,%.10g\n', [out.t(:), out.C(:)].');
fclose(fid);

% JSON (summary + arrays; jsonencode with a manual fallback for older versions)
fid = fopen(fullfile(here, 'Exenatide_Cirincione2017v2_iiv.json'), 'w');
try
  s.model = 'Exenatide_Cirincione2017v2_iiv'; s.Cmax = out.Cmax; s.Tmax = out.Tmax; s.AUC = out.AUC;
  s.time_h = out.t(:).'; s.Cc_mg_per_L = out.C(:).';
  fprintf(fid, '%s', jsonencode(s));
catch
  fprintf(fid, '{"model":"Exenatide_Cirincione2017v2_iiv","Cmax":%g,"Tmax":%g,"AUC":%g}', out.Cmax, out.Tmax, out.AUC);
end
fclose(fid);

fprintf('Cmax=%.3g mg/L  Tmax=%.3g h  AUC=%.3g mg*h/L\n', out.Cmax, out.Tmax, out.AUC);
fprintf('wrote Exenatide_Cirincione2017v2_iiv.png, Exenatide_Cirincione2017v2_iiv.csv, Exenatide_Cirincione2017v2_iiv.json\n');
