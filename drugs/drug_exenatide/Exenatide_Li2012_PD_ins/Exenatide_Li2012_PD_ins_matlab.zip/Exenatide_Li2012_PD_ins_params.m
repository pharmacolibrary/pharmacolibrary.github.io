function p = Exenatide_Li2012_PD_ins_params()
% Exenatide_Li2012_PD_ins_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% exenatide Li_2012::INS: indirect_response_iii exposure-response sweep (response = E0*(1 + Emax*frac)). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one μg/L per second, in SI inside (kg/m3, s). Response INS in mU/L. Driver: exenatide (pk_record).
p.E0 = 10.094786729857821;
p.Emax = 0.822;
p.EC50 = 4.019999999999999e-06;
p.gamma = 1.0;
p.slope = 0.0;
p.exposure_per_s = 1e-06;
p.stop_time = 41.0;
p.form = 'E0*(1 + Emax*frac)';
end
