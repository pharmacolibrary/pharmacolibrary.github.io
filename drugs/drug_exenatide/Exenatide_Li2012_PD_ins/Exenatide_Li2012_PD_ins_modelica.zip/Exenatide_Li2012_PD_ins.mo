model Exenatide_Li2012_PD_ins
  "indirect_response_iii exposure-response sweep — Li_2012 :: INS (serum insulin)"
  extends Pharmacolibrary.Interfaces.PartialExposureResponseSweep(
    E0 = 10.0947867299,      // [mU/L]
    Emax = 0.822,  // type III effect term
    EC50 = 4.02e-06,  // [kg/m3; μg/L × 1e-06]
    gamma = 1,
    exposure_per_s = 1e-06);   // 1 μg/L per second
equation
  response = E0*(1 + Emax*frac);   // steady state, indirect response type III
  // e0_from_kin_kout: no baseline row; E0 = kin/kout (21.3/2.11 = 10.09) — the paper's stated baseline may differ
  // defaulted: gamma
  annotation(experiment(StartTime = 0, StopTime = 41, Interval = 0.082),
    Documentation(info = "<html><body><!-- drug-about --><h4>About exenatide</h4><p>Exenatide is a GLP-1 agonist used as an anti-diabetic medication, notably for type 2 diabetes. It is authorised in the European Union and widely used for diabetes, with some additional investigational uses.</p><p><small>Summary written by glm-5.3-flash from <a href=&quot;https://www.wikidata.org/wiki/Q417762&quot;>Wikidata Q417762</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h4>Exenatide_Li2012_PD_ins</h4><p>The steady-state exposure-response curve of Li XG et al., <i>Acta pharmacologica Sinica 33(11):1379–1386</i> 2012 (<a href=\"https://doi.org/10.1038/aps.2012.33\">doi:10.1038/aps.2012.33</a>) — serum insulin [mU/L] against exenatide μg/L — obtained by sweeping the driver instead of simulating a dose. Model family: indirect_response_iii.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = 10.0947867299 mU/L     drug-free response (baseline) (kin/kout, Q327/Q328)
  Emax  =      0.822          maximal effect term (S m1, Q320)
  EC50  =       4.02 μg/L     exposure at half of the maximal effect term (SC 50, Q321)
  gamma = (library default) Hill coefficient</pre><p>The algebra is <code>response = E0*(1 + Emax*frac)</code>; this model only supplies the numbers. The x axis is one μg/L of exenatide per second of simulated time (exposure is in kg/m3): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 10.09   (drug-free)
  exposure = EC50 (4.02 μg/L)  response 14.24
  exposure -> infinity  response 18.39</pre></body></html>"));
end Exenatide_Li2012_PD_ins;
