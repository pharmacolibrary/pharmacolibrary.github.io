model Tacrolimus_Xiang2025_PD_fpg
  "linear exposure-response sweep — Xiang_2025 :: FPG (fasting plasma glucose)"
  extends Pharmacolibrary.Interfaces.PartialExposureResponseSweep(
    E0 = 4.2,      // [mol/m3; mmol/L × 1]
    Emax = 0, EC50 = 1,      // unused by a line
    exposure_per_s = 1e-06);
  parameter Real slope = 0.264   "[1]";
equation
  response = E0 + slope*exposure;
  annotation(experiment(StartTime = 0, StopTime = 1000, Interval = 2),
    Documentation(info = "<html><body><!-- drug-about --><h4>About tacrolimus</h4><p>Tacrolimus is an immunosuppressive drug used to prevent organ transplant rejection and to treat conditions such as atopic dermatitis, ulcerative colitis, and graft-versus-host disease. It is widely used and authorised in the European Union, available as an approved medicine for transplant and dermatological indications.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q411648\">Wikidata Q411648</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h4>Tacrolimus_Xiang2025_PD_fpg</h4><p>The steady-state exposure-response curve of Xiang Q et al., <i>Drug design, development and therapy 19:8375–8389</i> 2025 (<a href=\"https://doi.org/10.2147/DDDT.S542786\">doi:10.2147/DDDT.S542786</a>) — fasting plasma glucose [mmol/L] against tacrolimus ng/mL — obtained by sweeping the driver instead of simulating a dose. Model family: linear.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    =        4.2 mmol/L   drug-free response (baseline) (FPG0, Q324)
  slope =      0.264          change in response per unit of exposure (β, Q335)</pre><p>The algebra is <code>response = E0 + slope*exposure</code>; this model only supplies the numbers. The x axis is one ng/mL of tacrolimus per second of simulated time (exposure is in kg/m3): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 4.2   (drug-free)</pre></body></html>"));
end Tacrolimus_Xiang2025_PD_fpg;
