function p = Tacrolimus_Xiang2025_PD_fpg_params()
% Tacrolimus_Xiang2025_PD_fpg_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% tacrolimus Xiang_2025::FPG: linear exposure-response sweep (response = E0 + slope*exposure). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one ng/mL per second, in SI inside (kg/m3, s). Response FPG in mmol/L. Driver: tacrolimus (pk_record).
p.E0 = 4.199999999999999;
p.Emax = 0.0;
p.EC50 = 1.0;
p.gamma = 1.0;
p.slope = 0.264;
p.exposure_per_s = 1e-06;
p.stop_time = 1000.0;
p.form = 'E0 + slope*exposure';
end
