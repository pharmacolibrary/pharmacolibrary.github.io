model Tacrolimus_Xiang2025_PD_egfr
  "emax exposure-response sweep — Xiang_2025 :: eGFR (estimated glomerular filtration rate)"
  extends Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep(
    E0 = 52.3,      // [mL/min/1.73 m2]
    Emax = -30,  // [mL/min/1.73 m2]
    EC50 = 1e-05,  // [kg/m3; ng/mL × 1e-06]
    gamma = 1,
    exposure_per_s = 1e-06);   // 1 ng/mL per second
  // imax_as_negative_emax: Imax (Q323) enters SigmoidEmaxSweep as −Emax
  // defaulted: gamma
  annotation(experiment(StartTime = 0, StopTime = 100, Interval = 0.2),
    Documentation(info = "<html><body><!-- drug-about --><h4>About tacrolimus</h4><p>Tacrolimus is an immunosuppressive drug used to prevent organ transplant rejection and to treat conditions such as atopic dermatitis, ulcerative colitis, and graft-versus-host disease. It is widely used and authorised in the European Union, available as an approved medicine for transplant and dermatological indications.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q411648\">Wikidata Q411648</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h4>Tacrolimus_Xiang2025_PD_egfr</h4><p>The steady-state exposure-response curve of Xiang Q et al., <i>Drug design, development and therapy 19:8375–8389</i> 2025 (<a href=\"https://doi.org/10.2147/DDDT.S542786\">doi:10.2147/DDDT.S542786</a>) — estimated glomerular filtration rate [mL/min/1.73 m2] against tacrolimus ng/mL — obtained by sweeping the driver instead of simulating a dose. Model family: emax.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    =       52.3 mL/min/1.73 m2 drug-free response (baseline) (eGFR0, Q324)
  Emax  =         30 mL/min/1.73 m2 maximal effect term (Imax, Q323)
  EC50  =         10 ng/mL    exposure at half of the maximal effect term (IC50, Q322)
  gamma = (library default) Hill coefficient</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep\">SigmoidEmaxSweep</a>; this model only supplies the numbers. The x axis is one ng/mL of tacrolimus per second of simulated time (exposure is in kg/m3): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 52.3   (drug-free)
  exposure = EC50 (10 ng/mL)  response 37.3
  exposure -> infinity  response 22.3</pre></body></html>"));
end Tacrolimus_Xiang2025_PD_egfr;
