function p = Tacrolimus_Xiang2025_PD_egfr_params()
% Tacrolimus_Xiang2025_PD_egfr_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% tacrolimus Xiang_2025::eGFR: emax exposure-response sweep (response = E0 + Emax*frac). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one ng/mL per second, in SI inside (kg/m3, s). Response eGFR in mL/min/1.73 m2. Driver: tacrolimus (pk_record).
p.E0 = 52.3;
p.Emax = -30.0;
p.EC50 = 9.999999999999999e-06;
p.gamma = 1.0;
p.slope = 0.0;
p.exposure_per_s = 1e-06;
p.stop_time = 100.0;
p.form = 'E0 + Emax*frac';
end
