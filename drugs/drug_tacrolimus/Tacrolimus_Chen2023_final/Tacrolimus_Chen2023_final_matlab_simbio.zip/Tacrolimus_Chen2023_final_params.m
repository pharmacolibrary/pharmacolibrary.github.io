function p = Tacrolimus_Chen2023_final_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: tacrolimus   source: Chen_2023 / final   route: oral
  p.name  = 'Tacrolimus_Chen2023_final_params';
  p.drug  = 'tacrolimus';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 1410.0;                % central volume [L]
  p.CL = 15.7;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.502;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.346;             % absorption lag [h]
  p.dose = 5.0;             % dose [mg]
end
