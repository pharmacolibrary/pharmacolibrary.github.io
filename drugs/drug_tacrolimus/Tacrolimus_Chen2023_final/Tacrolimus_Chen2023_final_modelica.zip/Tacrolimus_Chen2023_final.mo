model Tacrolimus_Chen2023_final
  parameter Real Cl_ref = 4.361111111111111e-06 "Cl [m3/s]";
  parameter Boolean cov_category_0 = false "category level 0";
  parameter Boolean cov_category_1 = false "category level 1";
  parameter Boolean cov_category_2 = false "category level 2";
  parameter Real cov_cyp3a5_3 = 0 "cyp3a5 covariate";
  parameter Real Vd_ref = 1.41 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref*(1 + (2.05)*cov_cyp3a5_3) + (1.1333333333333334e-06)*(if cov_category_0 then 1 else 0) + (2.8888888888888894e-06)*(if cov_category_1 then 1 else 0) + (5.2777777777777785e-06)*(if cov_category_2 then 1 else 0),
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.8040182,
    adminMass = 5e-06,
    ka = 0.00013944444444444445,
    Tlag = 1245.6
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About tacrolimus</h4><p>Tacrolimus is an immunosuppressive drug used to prevent organ transplant rejection and to treat conditions such as atopic dermatitis, ulcerative colitis, and graft-versus-host disease. It is widely used and authorised in the European Union, available as an approved medicine for transplant and dermatological indications.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q411648\">Wikidata Q411648</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>tacrolimus</td></tr><tr><td>population:</td><td>adults with myasthenia gravis</td></tr><tr><td>source_paper:</td><td>Chen_2023</td></tr><tr><td>measured_compound:</td><td>tacrolimus</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>psp412966-tbl-0002</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>tacrolimus 804.018 g/mol (drugbank)</td></tr></table><h4>Interpretation flags</h4><ul><li>table section residual_error: 'Proportional error (%)' routed out of structural estimates ('Residual error')</li><li>table section residual_error: 'Proportional error (%)' routed out of structural estimates ('Residual error')</li><li>table section residual_error: 'Proportional error (%)' routed out of structural estimates ('Residual error')</li><li>table section residual_error: 'Proportional error (%)' routed out of structural estimates ('Residual error')</li><li>dropped duplicate Q76 ('TP on V/F', value '-0.0817') — already have one for this compound</li><li>covariate level 'TS0 for Osserman I' → Q900:ts0_for_osserman_i = 4.08 (additive_shift on Q27)</li><li>covariate level 'TS0 for Osserman IIa/IIb' → Q900:ts0_for_osserman_iia_iib = 10.4 (additive_shift on Q27)</li><li>covariate level 'TS0 for Osserman III/IV' → Q900:ts0_for_osserman_iii_iv = 19.0 (additive_shift on Q27)</li><li>dropped PD-category row 'E max' → Q320 (Emax, category G11) — pharmacodynamic parameters belong to scholarpd, not the PK model (source ['psp412966-tbl-0002:row19:col3'])</li><li>dropped unlinked row (NIL): 'EcAUC50 (ng*h/mL)' — extend the ontology if this is a real PK parameter (source ['psp412966-tbl-0002:row20:col3', 'psp412966-tbl-0002:row20:col4'])</li><li>apparent-ness (ontology-grounded): parameterization=apparent, measured_compound=tacrolimus</li><li>model-stage split: 'final model' is the final model of Chen_2023 (paper reports 2 stages: base model, final model); same population, different model-building step</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 1209600, Tolerance = 1e-9, Interval = 1));
end Tacrolimus_Chen2023_final;
