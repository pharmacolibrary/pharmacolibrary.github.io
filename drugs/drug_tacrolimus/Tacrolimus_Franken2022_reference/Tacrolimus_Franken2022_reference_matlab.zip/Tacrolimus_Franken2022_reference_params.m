function p = Tacrolimus_Franken2022_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: tacrolimus   source: Franken_2022 / reference   route: oral
  p.name  = 'Tacrolimus_Franken2022_reference_params';
  p.drug  = 'tacrolimus';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 692.0;                % central volume [L]
  p.CL = 23.0;                % clearance [L/h]
  p.Vp = [5340.0];             % peripheral volumes [L]
  p.Q  = [11.6];             % inter-compartmental clearances [L/h]
  p.ka = 3.58;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.38;             % absorption lag [h]
  p.dose = 5.0;             % dose [mg]
end
