model InterferonAlfa2b_Talal2006_PD_hcv_rna
  "indirect_response_i exposure-response sweep — Talal_2006 :: HCV RNA (HCV RNA)"
  extends Pharmacolibrary.Interfaces.PartialExposureResponseSweep(
    E0 = 0,      // [1]
    Emax = 1,  // type I effect term
    EC50 = 4e-08,  // [kg/m3; microg/L × 1e-06]
    gamma = 1,
    exposure_per_s = 1e-06);   // 1 microg/L per second
equation
  response = E0*(1 - Emax*frac);   // steady state, indirect response type I
  // defaulted: E0
  // defaulted: Emax
  // defaulted: gamma
  annotation(experiment(StartTime = 0, StopTime = 0.4, Interval = 0.0008),
    Documentation(info = "<html><body><!-- drug-about --><h4>About interferon_alfa_2b</h4><p>Interferon alfa-2b is an immunostimulant interferon used to treat several cancers, including hairy cell leukemia, follicular lymphoma, melanoma and multiple myeloma, as well as chronic hepatitis B and C infections. It is an approved medicine, though some European Union products have been withdrawn, and it has also been studied for other uses.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q72483271\">Wikidata Q72483271</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h4>InterferonAlfa2b_Talal2006_PD_hcv_rna</h4><p>The steady-state exposure-response curve of Talal AH et al., <i>Hepatology (Baltimore, Md.) 43(5):943–953</i> 2006 (<a href=\"https://doi.org/10.1002/hep.21136\">doi:10.1002/hep.21136</a>) — HCV RNA against PEG-IFN alpha-2b microg/L — obtained by sweeping the driver instead of simulating a dose. Model family: indirect_response_i.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = (library default) drug-free response (baseline)
  Emax  = (library default) maximal effect term
  EC50  =       0.04 microg/L exposure at half of the maximal effect term (EC50, Q321)
  gamma = (library default) Hill coefficient</pre><p>The algebra is <code>response = E0*(1 - Emax*frac)</code>; this model only supplies the numbers. The x axis is one microg/L of PEG-IFN alpha-2b per second of simulated time (exposure is in kg/m3): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0   (drug-free)
  exposure = EC50 (0.04 microg/L)  response 0
  exposure -> infinity  response 0</pre></body></html>"));
end InterferonAlfa2b_Talal2006_PD_hcv_rna;
