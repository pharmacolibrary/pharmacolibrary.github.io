function p = InterferonAlfa2b_GarcaGarca2016_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: interferon_alfa_2b   source: García-García_2016 / reference   route: oral
  % estimated (absent from source): dose
  p.name  = 'InterferonAlfa2b_GarcaGarca2016_reference_params';
  p.drug  = 'interferon_alfa_2b';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 38.4;                % central volume [L]
  p.CL = 1.8;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.15;                % absorption rate [1/h]
  p.F  = 0.22;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 100.0;             % dose [mg]
end
