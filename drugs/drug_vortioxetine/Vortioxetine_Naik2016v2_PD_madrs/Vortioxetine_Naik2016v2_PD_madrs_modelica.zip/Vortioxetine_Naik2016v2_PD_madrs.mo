model Vortioxetine_Naik2016v2_PD_madrs
  "emax exposure-response sweep — Naik_2016_2 :: ΔMADRS (change in MADRS score from baseline)"
  extends Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep(
    E0 = 0,      // [1]
    Emax = -7,  // [1]
    EC50 = 2.49e-05,  // [kg/m3; ng/mL × 1e-06]
    gamma = 1,
    exposure_per_s = 1e-06);   // 1 ng/mL per second
  // imax_as_negative_emax: Imax (Q323) enters SigmoidEmaxSweep as −Emax
  // defaulted: E0
  // defaulted: gamma
  annotation(experiment(StartTime = 0, StopTime = 250, Interval = 0.5),
    Documentation(info = "<html><body><!-- drug-about --><h4>About vortioxetine</h4><p>Vortioxetine is an antidepressant used to treat major depressive disorder and, according to some sources, anxiety. It is authorised in the European Union and is used as an approved medicine, though it also remains under investigation for other uses.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q3563148\">Wikidata Q3563148</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h4>Vortioxetine_Naik2016v2_PD_madrs</h4><p>The steady-state exposure-response curve of Naik H et al., <i>Basic &amp; clinical pharmacology &amp; toxicology 118(5):344–355</i> 2016 (<a href=\"https://doi.org/10.1111/bcpt.12513\">doi:10.1111/bcpt.12513</a>) — change in MADRS score from baseline against vortioxetine ng/mL — obtained by sweeping the driver instead of simulating a dose. Model family: emax.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = (library default) drug-free response (baseline)
  Emax  =          7          maximal effect term (Emax, Q323)
  EC50  =       24.9 ng/mL    exposure at half of the maximal effect term (Half-maximal effective concentration, Q321)
  gamma = (library default) Hill coefficient</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep\">SigmoidEmaxSweep</a>; this model only supplies the numbers. The x axis is one ng/mL of vortioxetine per second of simulated time (exposure is in kg/m3): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0   (drug-free)
  exposure = EC50 (24.9 ng/mL)  response -3.5
  exposure -> infinity  response -7</pre></body></html>"));
end Vortioxetine_Naik2016v2_PD_madrs;
