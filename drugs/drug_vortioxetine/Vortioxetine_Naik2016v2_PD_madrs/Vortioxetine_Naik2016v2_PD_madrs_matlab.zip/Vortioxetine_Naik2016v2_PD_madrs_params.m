function p = Vortioxetine_Naik2016v2_PD_madrs_params()
% Vortioxetine_Naik2016v2_PD_madrs_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% vortioxetine Naik_2016_2::MADRS: emax exposure-response sweep (response = E0 + Emax*frac). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one ng/mL per second, in SI inside (kg/m3, s). Response ΔMADRS in its own unit. Driver: vortioxetine (pk_record).
p.E0 = 0.0;
p.Emax = -7.0;
p.EC50 = 2.49e-05;
p.gamma = 1.0;
p.slope = 0.0;
p.exposure_per_s = 1e-06;
p.stop_time = 250.0;
p.form = 'E0 + Emax*frac';
end
