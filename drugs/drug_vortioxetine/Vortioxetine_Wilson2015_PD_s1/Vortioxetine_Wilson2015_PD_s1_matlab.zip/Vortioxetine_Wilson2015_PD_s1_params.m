function p = Vortioxetine_Wilson2015_PD_s1_params()
% Vortioxetine_Wilson2015_PD_s1_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% vortioxetine Wilson_2015::S1: linear exposure-response sweep (response = E0 + slope*exposure). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one ng/mL per second, in SI inside (kg/m3, s). Response S1 in min. Driver: vortioxetine (cited_pk).
p.E0 = 2520.0;
p.Emax = 0.0;
p.EC50 = 1.0;
p.gamma = 1.0;
p.slope = 43200000.00000001;
p.exposure_per_s = 1e-06;
p.stop_time = 1000.0;
p.form = 'E0 + slope*exposure';
end
