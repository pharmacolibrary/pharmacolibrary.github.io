model Vortioxetine_Wilson2015_PD_waso
  "linear exposure-response sweep — Wilson_2015 :: ΔWASO (Wake after sleep onset (change from baseline))"
  extends Pharmacolibrary.Interfaces.PartialExposureResponseSweep(
    E0 = 96,      // [s; min × 60]
    Emax = 0, EC50 = 1,      // unused by a line
    exposure_per_s = 1e-06);
  parameter Real slope = 28800000   "[meter ** 3 * second / kilogram; min/ng/mL × 6e+07]";
equation
  response = E0 + slope*exposure;
  annotation(experiment(StartTime = 0, StopTime = 1000, Interval = 2),
    Documentation(info = "<html><body><!-- drug-about --><h4>About vortioxetine</h4><p>Vortioxetine is an antidepressant used to treat major depressive disorder and, according to some sources, anxiety. It is authorised in the European Union and is used as an approved medicine, though it also remains under investigation for other uses.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q3563148\">Wikidata Q3563148</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h4>Vortioxetine_Wilson2015_PD_waso</h4><p>The steady-state exposure-response curve of Wilson S et al., <i>Journal of psychopharmacology (Oxford, England) 29(10):1085–1091</i> 2015 (<a href=\"https://doi.org/10.1177/0269881115599387\">doi:10.1177/0269881115599387</a>) — Wake after sleep onset (change from baseline) [min] against vortioxetine ng/mL — obtained by sweeping the driver instead of simulating a dose. Model family: linear.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    =        1.6 min      drug-free response (baseline) (E0, Q324)
  slope =       0.48 min/ng/mL change in response per unit of exposure (k, Q335)</pre><p>The algebra is <code>response = E0 + slope*exposure</code>; this model only supplies the numbers. The x axis is one ng/mL of vortioxetine per second of simulated time (exposure is in kg/m3): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 96   (drug-free)</pre></body></html>"));
end Vortioxetine_Wilson2015_PD_waso;
