function p = Vortioxetine_Wilson2015_PD_rol_params()
% Vortioxetine_Wilson2015_PD_rol_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% vortioxetine Wilson_2015::ROL: sigmoid_emax exposure-response sweep (response = E0 + Emax*frac). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one ng/mL per second, in SI inside (kg/m3, s). Response ΔROL in min. Driver: vortioxetine (cited_pk).
p.E0 = 144.0;
p.Emax = 15000.0;
p.EC50 = 2.1e-05;
p.gamma = 2.5;
p.slope = 0.0;
p.exposure_per_s = 1e-06;
p.stop_time = 210.0;
p.form = 'E0 + Emax*frac';
end
