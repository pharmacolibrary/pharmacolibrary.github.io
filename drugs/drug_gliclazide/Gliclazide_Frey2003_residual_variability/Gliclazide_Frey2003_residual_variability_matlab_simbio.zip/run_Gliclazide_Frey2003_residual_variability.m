% Run (SimBiology): build model + dose, simulate 0..96.0 h, plot.
p = Gliclazide_Frey2003_residual_variability_params();
[model, dose, variant] = build_sb_pk(p);
sd = simulate_sb(model, variant, dose, 96.0);
