function p = Gliclazide_Mim2023_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: gliclazide   source: Mim_2023 / reference   route: oral
  p.name  = 'Gliclazide_Mim2023_reference_params';
  p.drug  = 'gliclazide';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 19.6;                % central volume [L]
  p.CL = 1.08;                % clearance [L/h]
  p.Vp = [8.78];             % peripheral volumes [L]
  p.Q  = [26.1];             % inter-compartmental clearances [L/h]
  p.ka = 1.4;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 60.0;             % dose [mg]
end
