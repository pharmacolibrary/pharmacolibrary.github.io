function p = Benznidazole_Frade2022_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: benznidazole   source: Frade_2022 / reference   route: oral
  % estimated (absent from source): F
  p.name  = 'Benznidazole_Frade2022_reference_params';
  p.drug  = 'benznidazole';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 37.66;                % central volume [L]
  p.CL = 6.32;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 1.67;                % absorption rate [1/h]
  p.F  = 0.9;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 400.0;             % dose [mg]
end
