model Benznidazole_Frade2022_reference
  parameter Real Cl_ref = 1.7555555555555556e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.03766 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 0.9,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.260253,
    adminMass = 0.0004,
    ka = 0.00046388888888888885,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About benznidazole</h4><p>Benznidazole is an antiparasitic medicine used to treat trypanosomiasis (Chagas disease). It is on the WHO list of essential medicines and is used mainly in regions where Chagas disease occurs.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q425300\">Wikidata Q425300</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>benznidazole</td></tr><tr><td>population:</td><td>Brazilian patients with chronic Chagas disease</td></tr><tr><td>source_paper:</td><td>Frade_2022</td></tr><tr><td>measured_compound:</td><td>benznidazole</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>t2</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>benznidazole 260.253 g/mol (drugbank)</td></tr></table><p><b>Defaulted (base-class default used):</b> F, Tlag.</p><h4>Interpretation flags</h4><ul><li>dropped value-less row: 'CL'</li><li>dropped value-less row: 'V'</li><li>dropped value-less row: 'Ka'</li><li>dropped value-less row: 'SD'</li><li>dropped value-less row: 'CV'</li><li>apparent-by-design (ADVISORY, codes unchanged): extravascular dosing with no identifiable F, so these reported disposition parameters are likely apparent unless the model puts first-pass in its structure — Q22 (CL (L/h)); Q61 (V (L))</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=benznidazole</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of TLAG: primary's parameterization (rate-constant / ka-only) does not use it</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Benznidazole_Frade2022_reference;
