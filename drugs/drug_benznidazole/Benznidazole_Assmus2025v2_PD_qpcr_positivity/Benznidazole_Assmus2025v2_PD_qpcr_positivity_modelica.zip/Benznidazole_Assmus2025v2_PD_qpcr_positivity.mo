model Benznidazole_Assmus2025v2_PD_qpcr_positivity
  "linear exposure-response sweep — Assmus_2025_2 :: qPCR positivity (qPCR positivity (proportion of T. cruzi qPCR-positive blood samples post-treatment))"
  extends Pharmacolibrary.Interfaces.PartialExposureResponseSweep(
    E0 = 0,      // [1]
    Emax = 0, EC50 = 1,      // unused by a line
    exposure_per_s = 1);
  parameter Real slope = 0.911   "[1]";
equation
  response = E0 + slope*exposure;
  // family_inferred: the record's model family is categorical; read from the parameters: a slope and no Emax — linear
  // defaulted: E0
  annotation(experiment(StartTime = 0, StopTime = 1000, Interval = 2),
    Documentation(info = "<html><body><!-- drug-about --><h4>About benznidazole</h4><p>Benznidazole is an antiparasitic medicine used to treat trypanosomiasis (Chagas disease). It is on the WHO list of essential medicines and is used mainly in regions where Chagas disease occurs.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q425300\">Wikidata Q425300</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h4>Benznidazole_Assmus2025v2_PD_qpcr_positivity</h4><p>The steady-state exposure-response curve of Assmus F et al., <i>PLoS neglected tropical diseases 19(9):e0013522</i> 2025 (<a href=\"https://doi.org/10.1371/journal.pntd.0013522\">doi:10.1371/journal.pntd.0013522</a>) — qPCR positivity (proportion of T. cruzi qPCR-positive blood samples post-treatment) against benznidazole mg/L (CMAX), mg×h/L (AUC∞), days (T&gt;IC90), weeks/days (duration) — obtained by sweeping the driver instead of simulating a dose. Model family: linear.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = (library default) drug-free response (baseline)
  slope =      0.911          change in response per unit of exposure (Odds ratio, Ct value, Q335)</pre><p>The algebra is <code>response = E0 + slope*exposure</code>; this model only supplies the numbers. The x axis is one mg/L (CMAX), mg×h/L (AUC∞), days (T&gt;IC90), weeks/days (duration) of benznidazole per second of simulated time: there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0   (drug-free)</pre></body></html>"));
end Benznidazole_Assmus2025v2_PD_qpcr_positivity;
