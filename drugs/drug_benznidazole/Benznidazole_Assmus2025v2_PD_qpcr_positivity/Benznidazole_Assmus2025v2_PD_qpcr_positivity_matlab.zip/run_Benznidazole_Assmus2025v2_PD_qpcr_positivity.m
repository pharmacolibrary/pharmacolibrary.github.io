% run_Benznidazole_Assmus2025v2_PD_qpcr_positivity  Evaluate the exposure-response curve and plot response against exposure.
% A sweep is a static map: no ODE solver is needed. exposure runs 0..stop_time*exposure_per_s.
p = Benznidazole_Assmus2025v2_PD_qpcr_positivity_params();
exposure = linspace(0, p.stop_time * p.exposure_per_s, 501);
frac = exposure.^p.gamma ./ (p.EC50^p.gamma + exposure.^p.gamma);
E0 = p.E0; Emax = p.Emax; slope = p.slope;
response = E0 + slope.*exposure;
figure; plot(exposure, response, 'LineWidth', 1.5); grid on;
xlabel('exposure [mg/L (CMAX), mg×h/L (AUC∞), days (T>IC90), weeks/days (duration)]'); ylabel('response []'); title('Benznidazole_Assmus2025v2_PD_qpcr_positivity', 'Interpreter', 'none');
writematrix([exposure(:) response(:)], 'Benznidazole_Assmus2025v2_PD_qpcr_positivity.csv');
