function p = Benznidazole_Assmus2025v2_PD_qpcr_positivity_params()
% Benznidazole_Assmus2025v2_PD_qpcr_positivity_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% benznidazole Assmus_2025_2::qPCR_positivity: linear exposure-response sweep (response = E0 + slope*exposure). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one mg/L (CMAX), mg×h/L (AUC∞), days (T>IC90), weeks/days (duration) per second, in SI inside (kg/m3, s). Response qPCR positivity in its own unit. Driver: benznidazole (pk_record).
p.E0 = 0.0;
p.Emax = 0.0;
p.EC50 = 1.0;
p.gamma = 1.0;
p.slope = 0.911;
p.exposure_per_s = 1.0;
p.stop_time = 1000.0;
p.form = 'E0 + slope*exposure';
end
