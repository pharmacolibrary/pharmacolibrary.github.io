function p = GinkgoFolium_Van2025_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: ginkgo_folium   source: Van_2025 / reference   route: iv_bolus
  % estimated (absent from source): F, dose
  p.name  = 'GinkgoFolium_Van2025_reference_params';
  p.drug  = 'ginkgo_folium';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'iv_bolus';        % 'oral' | 'iv_bolus'
  p.depot = false;             % oral -> first-order absorption depot
  p.Vc = 10.4;                % central volume [L]
  p.CL = 3.26;                % clearance [L/h]
  p.Vp = [10.4];             % peripheral volumes [L]
  p.Q  = [0.518];             % inter-compartmental clearances [L/h]
  p.ka = 0.0;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 10.0;             % dose [mg]
end
