function p = GinkgoFolium_Dumas2026_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: ginkgo_folium   source: Dumas_2026 / reference   route: iv_bolus
  % estimated (absent from source): F, dose
  p.name  = 'GinkgoFolium_Dumas2026_reference_params';
  p.drug  = 'ginkgo_folium';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'iv_bolus';        % 'oral' | 'iv_bolus'
  p.depot = false;             % oral -> first-order absorption depot
  p.Vc = 3.25;                % central volume [L]
  p.CL = 0.004038;                % clearance [L/h]
  p.Vp = [4.55];             % peripheral volumes [L]
  p.Q  = [0.018];             % inter-compartmental clearances [L/h]
  p.ka = 0.0;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 10.0;             % dose [mg]
end
