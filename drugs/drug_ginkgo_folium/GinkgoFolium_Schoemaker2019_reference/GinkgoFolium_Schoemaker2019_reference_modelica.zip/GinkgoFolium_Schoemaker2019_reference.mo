model GinkgoFolium_Schoemaker2019_reference
  parameter Real Cl_ref = 1.111111111111111e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.07 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C_enteral(
    weight = 70.0,
    F = 0.9,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    adminMass = 0.00012,
    ka = 0.0002777777777777778,
    Tlag = 0.0,
    k12 = 1.587301587301587e-05,
    k21 = 2.7777777777777776e-05
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About ginkgo_folium</h4><p>Ginkgo biloba leaf extract is a herbal medicine used for dementia and other cognitive disorders. It is widely available as a nutraceutical and approved product, used mainly in Europe for memory and circulation problems.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q104444041\">Wikidata Q104444041</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>ginkgo_folium</td></tr><tr><td>population:</td><td>review reference</td></tr><tr><td>source_paper:</td><td>Schoemaker_2019</td></tr><tr><td>measured_compound:</td><td>ginkgo_folium</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_2C_enteral: absorption rate constant reported</td></tr></table><p><b>Defaulted (base-class default used):</b> F, Tlag.</p><h4>Interpretation flags</h4><ul><li>built from REVIEW reference values (Schoemaker_2019) — secondary source</li><li>volume reported by review</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 259200, Tolerance = 1e-9, Interval = 1));
end GinkgoFolium_Schoemaker2019_reference;
