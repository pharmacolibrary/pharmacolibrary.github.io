model GinkgoFolium_Schneider2025_reference
  parameter Real Cl_ref = 2.5e-09 "Cl [m3/s]";
  parameter Real Vd_ref = 0.0028 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    adminMass = 1e-05,
    k12 = 0.001884920634920635,
    k21 = 6.854256854256854e-05
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About ginkgo_folium</h4><p>Ginkgo biloba leaf extract is a herbal medicine used for dementia and other cognitive disorders. It is widely available as a nutraceutical and approved product, used mainly in Europe for memory and circulation problems.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q104444041\">Wikidata Q104444041</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>ginkgo_folium</td></tr><tr><td>population:</td><td>review reference</td></tr><tr><td>source_paper:</td><td>Schneider_2025</td></tr><tr><td>measured_compound:</td><td>ginkgo_folium</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_2C: IV (no input phase)</td></tr></table><h4>Interpretation flags</h4><ul><li>built from REVIEW reference values (Schneider_2025) — secondary source</li><li>volume reported by review</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 4233600, Tolerance = 1e-9, Interval = 1));
end GinkgoFolium_Schneider2025_reference;
