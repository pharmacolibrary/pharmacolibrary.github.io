model Inositol_Taghizadeh2022_PD_ip1
  "emax exposure-response sweep — Taghizadeh_2022 :: IP1 (IP1)"
  extends Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep(
    E0 = 0,      // [1]
    Emax = 0.71,  // [1; % × 0.01]
    EC50 = 8.5,  // [µM]
    gamma = 1,
    exposure_per_s = 1);   // 1 µM per second
  // exposure_unit_unresolved: 'µM' — the x axis is in the paper's unit, not SI
  // defaulted: E0
  // defaulted: gamma
  annotation(experiment(StartTime = 0, StopTime = 85, Interval = 0.17),
    Documentation(info = "<html><body><!-- drug-about --><h4>About inositol</h4><p>Inositol is a sugar-like compound once classed as a B vitamin and marketed as a vitamin preparation. It is no longer regarded as an essential vitamin and has been withdrawn as a drug, though it persists as a dietary supplement.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q407997\">Wikidata Q407997</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h4>Inositol_Taghizadeh2022_PD_ip1</h4><p>The steady-state exposure-response curve of Taghizadeh MS et al., <i>Scientific reports 12(1):9215</i> 2022 (<a href=\"https://doi.org/10.1038/s41598-022-13142-z\">doi:10.1038/s41598-022-13142-z</a>) — IP1 against inositol phosphate µM — obtained by sweeping the driver instead of simulating a dose. Model family: emax.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = (library default) drug-free response (baseline)
  Emax  =         71 %        maximal effect term (Emax, Q320)
  EC50  =        8.5 µM       exposure at half of the maximal effect term (EC50, Q321)
  gamma = (library default) Hill coefficient</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep\">SigmoidEmaxSweep</a>; this model only supplies the numbers. The x axis is one µM of inositol phosphate per second of simulated time: there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0   (drug-free)
  exposure = EC50 (8.5 µM)  response 0.355
  exposure -> infinity  response 0.71</pre></body></html>"));
end Inositol_Taghizadeh2022_PD_ip1;
