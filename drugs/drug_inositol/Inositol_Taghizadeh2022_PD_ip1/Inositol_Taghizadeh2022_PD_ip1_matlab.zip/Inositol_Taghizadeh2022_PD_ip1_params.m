function p = Inositol_Taghizadeh2022_PD_ip1_params()
% Inositol_Taghizadeh2022_PD_ip1_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% inositol Taghizadeh_2022::IP1: emax exposure-response sweep (response = E0 + Emax*frac). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one µM per second, in SI inside (kg/m3, s). Response IP1 in its own unit. Driver: inositol phosphate (not_resolved).
p.E0 = 0.0;
p.Emax = 0.71;
p.EC50 = 8.5;
p.gamma = 1.0;
p.slope = 0.0;
p.exposure_per_s = 1.0;
p.stop_time = 85.0;
p.form = 'E0 + Emax*frac';
end
