model Inositol_Phelps2013_estimate
  parameter Real Cl_ref = 1.3202777777777777e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.035805000000000003 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.1801559,
    adminMass = 0.0042
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About inositol</h4><p>Inositol is a sugar-like compound once classed as a B vitamin and marketed as a vitamin preparation. It is no longer regarded as an essential vitamin and has been withdrawn as a drug, though it persists as a dietary supplement.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q407997\">Wikidata Q407997</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>inositol</td></tr><tr><td>population:</td><td>preterm infants</td></tr><tr><td>source_paper:</td><td>Phelps_2013</td></tr><tr><td>measured_compound:</td><td>inositol</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>T7</td></tr><tr><td>input:</td><td>PK_1C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>inositol 180.156 g/mol (drugbank)</td></tr></table><h4>Interpretation flags</h4><ul><li>unit_dimension_unknown: 'volume' (V)</li><li>unit_dimension_unknown: 'clearance' (CL)</li><li>dropped PD-category row 'R (endogenous infusion rate)' → Q327 (kin, category G11) — pharmacodynamic parameters belong to scholarpd, not the PK model (source ['Phelps_2013_table_4:row3:col2'])</li><li>unit_dimension_unknown: 'elimination rate; Cl/V' (kel)</li><li>unit_dimension_unknown: 'half-life; 0.693/k' (t1/2z)</li><li>unit_dimension_unknown: 'endogenous concentration; R/Cl' (E)</li><li>implicit units: 'V (volume)' → L/kg (from the paper text: &quot;The text states: 'The central volume of distribution was 0.5115 l/kg' and later 'central volume of distribution of 0.511&quot;)</li><li>implicit units: 'Cl (clearance)' → L/kg/h (from the paper text: &quot;The text states: 'the clearance 0.0679 l/kg/h'.&quot;)</li><li>implicit units: 'k (elimination rate; Cl/V)' → 1/h (from the popPK convention: 'The elimination rate constant (k) is defined as Cl/V. Given Cl is in L/kg/h and V is in L/kg, the units cancel to 1/h. T')</li><li>implicit units: 't1/2 (half-life; 0.693/k)' → h (from the paper text: &quot;The text states: 'the half life 5.22 h' and 'half life of 5.22 h'.&quot;)</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=inositol</li><li>held at status:extracted — NIL link or unit issue (mismatch/unknown/normalisation-failed) present</li><li>status held at route_to_review — not promoted</li><li>population split: 'estimate' subgroup of Phelps_2013 (paper reports 2 populations: covariate estimate(standard error), estimate)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 97200, Tolerance = 1e-9, Interval = 1));
end Inositol_Phelps2013_estimate;
