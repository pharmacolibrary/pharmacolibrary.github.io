model Inositol_Phelps2016_reference
  parameter Real Cl_ref = 1.197777777777778e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.039270000000000006 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.1801559,
    adminMass = 1e-05
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About inositol</h4><p>Inositol is a sugar-like compound once classed as a B vitamin and marketed as a vitamin preparation. It is no longer regarded as an essential vitamin and has been withdrawn as a drug, though it persists as a dietary supplement.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q407997\">Wikidata Q407997</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>inositol</td></tr><tr><td>population:</td><td>preterm infants</td></tr><tr><td>source_paper:</td><td>Phelps_2016</td></tr><tr><td>measured_compound:</td><td>inositol</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>T4</td></tr><tr><td>input:</td><td>PK_1C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>inositol 180.156 g/mol (drugbank)</td></tr></table><h4>Interpretation flags</h4><ul><li>column 'units' classified 'other' by the LLM but kept: the deterministic diagnostic-column test disagrees (a stratum column is a value column, not a statistic)</li><li>column 'volume (uv)' classified 'other' by the LLM but kept: the deterministic diagnostic-column test disagrees (a stratum column is a value column, not a statistic)</li><li>column 'clearance (ucl)' classified 'other' by the LLM but kept: the deterministic diagnostic-column test disagrees (a stratum column is a value column, not a statistic)</li><li>column 'clearance (ucl)' classified 'other' by the LLM but kept: the deterministic diagnostic-column test disagrees (a stratum column is a value column, not a statistic)</li><li>column 'endogenous infusion rate (ur)' classified 'other' by the LLM but kept: the deterministic diagnostic-column test disagrees (a stratum column is a value column, not a statistic)</li><li>unit_dimension_unknown: 'Standard Error' (V)</li><li>unit_dimension_unknown: 'Standard Error' (CL)</li><li>unit_dimension_unknown: 'Standard Error' (R1)</li><li>unit_dimension_unknown: 'Standard Error' (kel)</li><li>unit_dimension_unknown: 'Standard Error' (t1/2z)</li><li>unit_dimension_unknown: 'Standard Error' (equation variable)</li><li>unit_dimension_unknown: 'uV' (V)</li><li>dropped duplicate Q61 ('Volume (uV)', value '0.1181') — already have one for this compound</li><li>unit_dimension_unknown: 'uCl' (CL)</li><li>dropped duplicate Q22 ('Clearance (uCl)', value '0.3508') — already have one for this compound</li><li>dropped PD-category row 'Endogenous infusion rate (uR)' → Q328 (kout, category G11) — pharmacodynamic parameters belong to scholarpd, not the PK model (source ['Phelps_2016_table_5:row2:col2', 'Phelps_2016_table_5:row2:col3'])</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 115200, Tolerance = 1e-9, Interval = 1));
end Inositol_Phelps2016_reference;
