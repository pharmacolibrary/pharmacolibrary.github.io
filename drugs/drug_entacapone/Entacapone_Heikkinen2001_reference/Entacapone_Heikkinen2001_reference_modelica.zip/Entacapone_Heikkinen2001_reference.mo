model Entacapone_Heikkinen2001_reference
  parameter Real Cl_ref = 1.3649999999999996e-05 "Cl [m3/s]";
  parameter Real Vd_ref = 0.005600000000000001 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 25.0,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.305286,
    adminMass = 0.001,
    ka = 0.013888888888888888,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About entacapone</h4><p>Entacapone is a COMT inhibitor used to treat Parkinson's disease. It is an approved medicine, authorised in the European Union for Parkinson's disease.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q416444\">Wikidata Q416444</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>entacapone</td></tr><tr><td>population:</td><td>healthy male volunteers</td></tr><tr><td>source_paper:</td><td>Heikkinen_2001</td></tr><tr><td>measured_compound:</td><td>entacapone</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>entacapone 305.286 g/mol (drugbank)</td></tr></table><p><b>Defaulted (base-class default used):</b> Tlag.</p><h4>Interpretation flags</h4><ul><li>unit_dimension_unknown: 'ng h/ml' (AUC)</li><li>unit_dimension_unknown: 'ng h/ml' (AUC)</li><li>dropped duplicate Q88 ('AUC (oral)', value 497) — already have one for this compound</li><li>implicit units: 'AUC (i.v.)' → mg·h/L (from the popPK convention: 'No unit stated in text, caption, or footnotes. AUC after i.v. dosing is conventionally reported in mg·h/L in population ')</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=entacapone</li><li>held at status:extracted — NIL link or unit issue (mismatch/unknown/normalisation-failed) present</li><li>structure disagreement: deterministic 1C vs LLM 2C — review compartment count</li><li>1C volume normalization: Q63→Q61 (single-compartment model has no central/peripheral split; 'Vc' is the general volume)</li><li>status held at route_to_review — not promoted</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li><li>gap-filled Q49 (kabs) from Senek_2020's review values (primary lacked it)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Entacapone_Heikkinen2001_reference;
