function p = Entacapone_Heikkinen2001_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: entacapone   source: Heikkinen_2001 / reference   route: oral
  p.name  = 'Entacapone_Heikkinen2001_reference_params';
  p.drug  = 'entacapone';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 5.6;                % central volume [L]
  p.CL = 49.14;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 50.0;                % absorption rate [1/h]
  p.F  = 0.25;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 1000.0;             % dose [mg]
end
