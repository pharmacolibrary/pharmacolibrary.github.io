function p = PotassiumCanrenoate_Suyagh2012_median_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: potassium_canrenoate   source: Suyagh_2012 / median   route: oral
  % estimated (absent from source): ka, dose
  p.name  = 'PotassiumCanrenoate_Suyagh2012_median_params';
  p.drug  = 'potassium_canrenoate';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 19.62;                % central volume [L]
  p.CL = 1.33;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.5;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 100.0;             % dose [mg]
end
