model Pyronaridine_Ayyoub2015_reference
  parameter Real Cl_ref = 4.363425925925926e-06 "Cl [m3/s]";
  parameter Real cov_age_0 = 0 "age covariate";
  parameter Real Vd_ref = 0.156 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref*(1 + (0.624)*cov_age_0),
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.51806,
    adminMass = 0.00042,
    ka = 0.0002071759259259259,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About pyronaridine</h4><p>Pyronaridine is an antimalarial drug used to treat malaria, available as a combination with an artemisinin derivative. It is considered investigational and is not authorised in the European Union.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q7263674\">Wikidata Q7263674</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>pyronaridine</td></tr><tr><td>population:</td><td>pediatric malaria patients younger than 16 years with uncomplicated malaria</td></tr><tr><td>source_paper:</td><td>Ayyoub_2015</td></tr><tr><td>measured_compound:</td><td>pyronaridine</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>T2</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>pyronaridine 518.06 g/mol (drugbank)</td></tr></table><p><b>Defaulted (base-class default used):</b> Tlag.</p><h4>Interpretation flags</h4><ul><li>table section iiv: 'CL/F' routed out of structural estimates ('IIV')</li><li>table section iiv: 'CL/F' routed out of structural estimates ('IIV')</li><li>table section iiv: 'CL/F' routed out of structural estimates ('IIV')</li><li>table section iiv: 'CL/F' routed out of structural estimates ('IIV')</li><li>table section iiv: 'CL/F' routed out of structural estimates ('IIV')</li><li>table section iiv: 'V2/F' routed out of structural estimates ('IIV')</li><li>table section iiv: 'V2/F' routed out of structural estimates ('IIV')</li><li>table section iiv: 'V2/F' routed out of structural estimates ('IIV')</li><li>table section iiv: 'V2/F' routed out of structural estimates ('IIV')</li><li>table section iiv: 'V2/F' routed out of structural estimates ('IIV')</li><li>table section iiv: 'V3/F' routed out of structural estimates ('IIV')</li><li>table section iiv: 'V3/F' routed out of structural estimates ('IIV')</li><li>table section iiv: 'V3/F' routed out of structural estimates ('IIV')</li><li>table section iiv: 'V3/F' routed out of structural estimates ('IIV')</li><li>table section iiv: 'V3/F' routed out of structural estimates ('IIV')</li><li>covariate level 'θ6 age on V3/F' → Q900:6_age_on_v3_f = 0.624 (linear_fractional on Q27)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 140400, Tolerance = 1e-9, Interval = 1));
end Pyronaridine_Ayyoub2015_reference;
