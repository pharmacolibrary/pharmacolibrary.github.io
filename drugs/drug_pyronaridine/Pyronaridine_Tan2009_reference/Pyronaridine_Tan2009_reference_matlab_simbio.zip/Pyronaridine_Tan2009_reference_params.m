function p = Pyronaridine_Tan2009_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: pyronaridine   source: Tan_2009 / reference   route: oral
  % estimated (absent from source): dose
  p.name  = 'Pyronaridine_Tan2009_reference_params';
  p.drug  = 'pyronaridine';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 70.5;                % central volume [L]
  p.CL = 1190.0;                % clearance [L/h]
  p.Vp = [1210.0];             % peripheral volumes [L]
  p.Q  = [5.74];             % inter-compartmental clearances [L/h]
  p.ka = 3.85;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 100.0;             % dose [mg]
end
