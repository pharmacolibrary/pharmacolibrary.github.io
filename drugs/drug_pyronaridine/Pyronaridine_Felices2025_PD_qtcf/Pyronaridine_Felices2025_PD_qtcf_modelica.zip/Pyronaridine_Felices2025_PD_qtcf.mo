model Pyronaridine_Felices2025_PD_qtcf
  "linear exposure-response sweep — Felices_2025 :: ΔQTcF (Change from baseline in Fridericia-corrected QT interval (ΔQTcF))"
  extends Pharmacolibrary.Interfaces.PartialExposureResponseSweep(
    E0 = 0,      // [1]
    Emax = 0, EC50 = 1,      // unused by a line
    exposure_per_s = 1e-06);
  parameter Real slope = 0.0094   "[msec per ng/mL]";
equation
  response = E0 + slope*exposure;
  // defaulted: E0
  annotation(experiment(StartTime = 0, StopTime = 1000, Interval = 2),
    Documentation(info = "<html><body><!-- drug-about --><h4>About pyronaridine</h4><p>Pyronaridine is an antimalarial drug used to treat malaria, available as a combination with an artemisinin derivative. It is considered investigational and is not authorised in the European Union.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q7263674\">Wikidata Q7263674</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h4>Pyronaridine_Felices2025_PD_qtcf</h4><p>The steady-state exposure-response curve of Felices M et al., <i>Clinical and translational science 18(7):e70305</i> 2025 (<a href=\"https://doi.org/10.1111/cts.70305\">doi:10.1111/cts.70305</a>) — Change from baseline in Fridericia-corrected QT interval (ΔQTcF) [msec] against pyronaridine ng/mL — obtained by sweeping the driver instead of simulating a dose. Model family: linear.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = (library default) drug-free response (baseline)
  Emax  =       25.7 msec     maximal effect term (θ11 PQP E max, Q320)
  slope =     0.0094 msec per ng/mL change in response per unit of exposure (θ2 PYR slope, Q335)</pre><p>The algebra is <code>response = E0 + slope*exposure</code>; this model only supplies the numbers. The x axis is one ng/mL of pyronaridine per second of simulated time (exposure is in kg/m3): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0   (drug-free)</pre></body></html>"));
end Pyronaridine_Felices2025_PD_qtcf;
