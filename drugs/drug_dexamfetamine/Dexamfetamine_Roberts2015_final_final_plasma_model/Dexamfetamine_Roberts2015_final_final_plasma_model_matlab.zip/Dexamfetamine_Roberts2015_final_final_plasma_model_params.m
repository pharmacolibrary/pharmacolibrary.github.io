function p = Dexamfetamine_Roberts2015_final_final_plasma_model_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: dexamfetamine   source: Roberts_2015 / final_final_plasma_model   route: oral
  % estimated (absent from source): ka
  p.name  = 'Dexamfetamine_Roberts2015_final_final_plasma_model_params';
  p.drug  = 'dexamfetamine';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 377.0;                % central volume [L]
  p.CL = 28.3;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.5;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 10.0;             % dose [mg]
end
