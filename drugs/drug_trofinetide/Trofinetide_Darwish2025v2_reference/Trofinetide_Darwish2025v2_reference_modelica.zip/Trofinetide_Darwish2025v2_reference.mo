model Trofinetide_Darwish2025v2_reference
  parameter Real Cl_ref = 3.2500000000000002e-06 "Cl [m3/s]";
  parameter Real cov_age = 1.0 "age covariate (reference 1.0)";
  parameter Real Vd_ref = 0.025 "Vd [m3]";
  parameter Boolean cov_category_0 = false "category level 0";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C_enteral(
    weight = 70.0,
    F = 0.9,
    Cl = Cl_ref*(cov_age/1.0)^(0.556),
    Vd = Vd_ref + (0.00116)*(if cov_category_0 then 1 else 0),
    adminDuration = 600,
    adminCount = 1,
    MM = 0.315326,
    adminMass = 0.002,
    ka = 0.00010944444444444445,
    Tlag = 0.0,
    k12 = 1.5777777777777775e-05,
    k21 = 1.1142498430634024e-05
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About trofinetide</h4><p>Trofinetide is a nervous system drug used for Rett syndrome. It is an approved medicine, though its status in the European Union is still under re-examination.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q27294917\">Wikidata Q27294917</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>trofinetide</td></tr><tr><td>population:</td><td>healthy volunteers and pediatric and adult patients with Rett syndrome, TBI, or fragile X syndrome</td></tr><tr><td>source_paper:</td><td>Darwish_2025_2</td></tr><tr><td>measured_compound:</td><td>trofinetide</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>Tab2</td></tr><tr><td>input:</td><td>PK_2C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>trofinetide 315.326 g/mol (drugbank)</td></tr></table><p><b>Defaulted (base-class default used):</b> F, Tlag.</p><h4>Interpretation flags</h4><ul><li>table section iiv: 'CL' routed out of structural estimates ('Interindividual variability')</li><li>table section iiv: 'Vc' routed out of structural estimates ('Interindividual variability')</li><li>table section iiv: 'Q' routed out of structural estimates ('Interindividual variability')</li><li>table section iiv: 'Vp' routed out of structural estimates ('Interindividual variability')</li><li>table section iiv: 'F1' routed out of structural estimates ('Interindividual variability')</li><li>table section residual_error: 'Healthy subjects' routed out of structural estimates ('Residual variability (exponential)')</li><li>table section residual_error: 'Healthy subjects' routed out of structural estimates ('Residual variability (exponential)')</li><li>table section residual_error: 'Patients with RTT, TBI or FXS' routed out of structural estimates ('Residual variability (exponential)')</li><li>table section residual_error: 'Patients with RTT, TBI or FXS' routed out of structural estimates ('Residual variability (exponential)')</li><li>table section residual_error: 'Minimum value of objective function' routed out of structural estimates ('Residual variability (exponential)')</li><li>dropped value-less row: 'Shift in CL for RTT = 1'</li><li>covariate level 'Covariate exponent of age on Vc' → Q900:covariate_exponent_of_age_on_vc = 0.556 (power on Q22)</li><li>dropped value-less row: 'Shift in Vp for TBI = 1'</li><li>dropped value-less row: 'Shift in ka for FED'</li><li>dropped value-less row: 'Shift in F1 for FED'</li><li>dropped value-less row: 'Shift in F1 for 18 g dose'</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Trofinetide_Darwish2025v2_reference;
