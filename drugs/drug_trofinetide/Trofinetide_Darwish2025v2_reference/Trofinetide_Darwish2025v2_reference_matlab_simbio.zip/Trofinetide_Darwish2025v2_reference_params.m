function p = Trofinetide_Darwish2025v2_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: trofinetide   source: Darwish_2025_2 / reference   route: oral
  % estimated (absent from source): F
  p.name  = 'Trofinetide_Darwish2025v2_reference_params';
  p.drug  = 'trofinetide';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 25.0;                % central volume [L]
  p.CL = 11.7;                % clearance [L/h]
  p.Vp = [35.4];             % peripheral volumes [L]
  p.Q  = [1.42];             % inter-compartmental clearances [L/h]
  p.ka = 0.394;                % absorption rate [1/h]
  p.F  = 0.9;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 2000.0;             % dose [mg]
end
