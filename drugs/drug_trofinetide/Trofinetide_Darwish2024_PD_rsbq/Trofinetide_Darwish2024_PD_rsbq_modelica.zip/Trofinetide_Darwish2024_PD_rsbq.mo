model Trofinetide_Darwish2024_PD_rsbq
  "linear exposure-response sweep — Darwish_2024 :: RSBQ (RSBQ total score)"
  extends Pharmacolibrary.Interfaces.PartialExposureResponseSweep(
    E0 = 41.61,      // [1]
    Emax = 0, EC50 = 1,      // unused by a line
    exposure_per_s = 1);
  parameter Real slope = -1.05092592593e-07   "[1 / second; 1/day × 1.15741e-05]";
equation
  response = E0 + slope*exposure;
  annotation(experiment(StartTime = 0, StopTime = 1000, Interval = 2),
    Documentation(info = "<html><body><!-- drug-about --><h4>About trofinetide</h4><p>Trofinetide is a nervous system drug used for Rett syndrome. It is an approved medicine, though its status in the European Union is still under re-examination.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q27294917\">Wikidata Q27294917</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h4>Trofinetide_Darwish2024_PD_rsbq</h4><p>The steady-state exposure-response curve of Darwish M et al., <i>Advances in therapy 41(4):1462–1480</i> 2024 (<a href=\"https://doi.org/10.1007/s12325-024-02796-y\">doi:10.1007/s12325-024-02796-y</a>) — RSBQ total score against trofinetide μg·h/mL — obtained by sweeping the driver instead of simulating a dose. Model family: linear.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    =      41.61          drug-free response (baseline) (Baseline RSBQ total score, Q324)
  slope =   -0.00908 1/day    change in response per unit of exposure (Slope for time, Q335)</pre><p>The algebra is <code>response = E0 + slope*exposure</code>; this model only supplies the numbers. The x axis is one μg·h/mL of trofinetide per second of simulated time: there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 41.61   (drug-free)</pre></body></html>"));
end Trofinetide_Darwish2024_PD_rsbq;
