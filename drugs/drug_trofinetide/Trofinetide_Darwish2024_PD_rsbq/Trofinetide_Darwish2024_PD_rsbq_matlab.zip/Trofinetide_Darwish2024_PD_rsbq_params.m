function p = Trofinetide_Darwish2024_PD_rsbq_params()
% Trofinetide_Darwish2024_PD_rsbq_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% trofinetide Darwish_2024::RSBQ: linear exposure-response sweep (response = E0 + slope*exposure). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one μg·h/mL per second, in SI inside (kg/m3, s). Response RSBQ in its own unit. Driver: trofinetide (cited_pk).
p.E0 = 41.61;
p.Emax = 0.0;
p.EC50 = 1.0;
p.gamma = 1.0;
p.slope = -1.0509259259259258e-07;
p.exposure_per_s = 1.0;
p.stop_time = 1000.0;
p.form = 'E0 + slope*exposure';
end
