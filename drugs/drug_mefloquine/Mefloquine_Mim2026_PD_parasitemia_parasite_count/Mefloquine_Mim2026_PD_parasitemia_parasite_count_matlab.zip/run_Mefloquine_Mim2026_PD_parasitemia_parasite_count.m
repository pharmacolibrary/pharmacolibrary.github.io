% run_Mefloquine_Mim2026_PD_parasitemia_parasite_count  Evaluate the exposure-response curve and plot response against exposure.
% A sweep is a static map: no ODE solver is needed. exposure runs 0..stop_time*exposure_per_s.
p = Mefloquine_Mim2026_PD_parasitemia_parasite_count_params();
exposure = linspace(0, p.stop_time * p.exposure_per_s, 501);
frac = exposure.^p.gamma ./ (p.EC50^p.gamma + exposure.^p.gamma);
E0 = p.E0; Emax = p.Emax; slope = p.slope;
response = E0.*(1 - Emax.*frac);
figure; plot(exposure, response, 'LineWidth', 1.5); grid on;
xlabel('exposure [nM]'); ylabel('response [%]'); title('Mefloquine_Mim2026_PD_parasitemia_parasite_count', 'Interpreter', 'none');
writematrix([exposure(:) response(:)], 'Mefloquine_Mim2026_PD_parasitemia_parasite_count.csv');
