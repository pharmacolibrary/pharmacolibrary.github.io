model Mefloquine_Mim2026_PD_parasitemia_parasite_count
  "indirect_response_i exposure-response sweep — Mim_2026 :: parasitemia (parasite count) (parasitemia (parasite count))"
  extends Pharmacolibrary.Interfaces.PartialExposureResponseSweep(
    E0 = 0,      // [1]
    Emax = 1,  // type I effect term
    EC50 = 29.1,  // [nM]
    gamma = 1,
    exposure_per_s = 1);   // 1 nM per second
equation
  response = E0*(1 - Emax*frac);   // steady state, indirect response type I
  // exposure_unit_unresolved: 'nM' — the x axis is in the paper's unit, not SI
  // defaulted: E0
  // defaulted: Emax
  // defaulted: gamma
  annotation(experiment(StartTime = 0, StopTime = 300, Interval = 0.6),
    Documentation(info = "<html><body><!-- drug-about --><h4>About mefloquine</h4><p>Mefloquine is an antimalarial drug used to treat and prevent malaria, including forms caused by Plasmodium falciparum and Plasmodium vivax. It remains an approved medicine and appears on the WHO list of essential medicines, so it is still used worldwide for malaria treatment and prophylaxis.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q736270\">Wikidata Q736270</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h4>Mefloquine_Mim2026_PD_parasitemia_parasite_count</h4><p>The steady-state exposure-response curve of Mim SR et al., <i>Antimicrobial agents and chemotherapy 70(3):e0171725</i> 2026 (<a href=\"https://doi.org/10.1128/aac.01717-25\">doi:10.1128/aac.01717-25</a>) — parasitemia (parasite count) [%] against mefloquine (and artesunate) nM — obtained by sweeping the driver instead of simulating a dose. Model family: indirect_response_i.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = (library default) drug-free response (baseline)
  Emax  = (library default) maximal effect term
  EC50  =       29.1 nM       exposure at half of the maximal effect term (Half-maximal inhibitory concentration, IC 50 (MQ), Q322)
  gamma = (library default) Hill coefficient</pre><p>The algebra is <code>response = E0*(1 - Emax*frac)</code>; this model only supplies the numbers. The x axis is one nM of mefloquine (and artesunate) per second of simulated time: there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0   (drug-free)
  exposure = EC50 (29.1 nM)  response 0
  exposure -> infinity  response 0</pre></body></html>"));
end Mefloquine_Mim2026_PD_parasitemia_parasite_count;
