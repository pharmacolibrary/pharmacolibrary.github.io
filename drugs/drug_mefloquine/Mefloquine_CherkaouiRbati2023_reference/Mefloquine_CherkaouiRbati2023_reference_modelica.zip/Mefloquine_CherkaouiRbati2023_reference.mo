model Mefloquine_CherkaouiRbati2023_reference
  parameter Real Cl_ref = 1.322222222222222e-07 "Cl [m3/s]";
  parameter Real Vd_ref = 0.00858 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.37831220000000004,
    adminMass = 1e-05,
    k12 = 0.0012011137011137011,
    k21 = 0.00017985262749660658
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About mefloquine</h4><p>Mefloquine is an antimalarial drug used to treat and prevent malaria, including forms caused by Plasmodium falciparum and Plasmodium vivax. It remains an approved medicine and appears on the WHO list of essential medicines, so it is still used worldwide for malaria treatment and prophylaxis.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q736270\">Wikidata Q736270</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>mefloquine</td></tr><tr><td>population:</td><td>review reference</td></tr><tr><td>source_paper:</td><td>Cherkaoui-Rbati_2023</td></tr><tr><td>measured_compound:</td><td>mefloquine</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_2C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>mefloquine 378.312 g/mol (drugbank)</td></tr></table><h4>Interpretation flags</h4><ul><li>built from REVIEW reference values (Cherkaoui-Rbati_2023) — secondary source</li><li>volume reported by review</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 259200, Tolerance = 1e-9, Interval = 1));
end Mefloquine_CherkaouiRbati2023_reference;
