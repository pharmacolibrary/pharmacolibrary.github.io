model Mefloquine_Rufener2018_reference
  parameter Real Cl_ref = 3.8888888888888884e-09 "Cl [m3/s]";
  parameter Real Vd_ref = 0.0010400000000000001 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.37831220000000004,
    adminMass = 0.007,
    ka = 8.333333333333333e-05,
    Tlag = 0.0,
    k12 = 7.21153846153846e-06,
    k21 = 1.0148849797023003e-06
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About mefloquine</h4><p>Mefloquine is an antimalarial drug used to treat and prevent malaria, including forms caused by Plasmodium falciparum and Plasmodium vivax. It remains an approved medicine and appears on the WHO list of essential medicines, so it is still used worldwide for malaria treatment and prophylaxis.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q736270\">Wikidata Q736270</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>mefloquine</td></tr><tr><td>population:</td><td>mice infected with E. multilocularis eggs</td></tr><tr><td>source_paper:</td><td>Rufener_2018</td></tr><tr><td>measured_compound:</td><td>mefloquine</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>table 1</td></tr><tr><td>input:</td><td>PK_2C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>mefloquine 378.312 g/mol (drugbank)</td></tr></table><p><b>Defaulted (base-class default used):</b> Tlag.</p><h4>Interpretation flags</h4><ul><li>salvaged Q49 ('k a'=0.3) from results prose — parameter table was unreadable</li><li>salvaged Q27 ('CL/F'=0.014) from results prose — parameter table was unreadable</li><li>salvaged Q69 ('CL d /F'=0.027) from results prose — parameter table was unreadable</li><li>salvaged Q290 ('V 1 /F'=1.04) from results prose — parameter table was unreadable</li><li>salvaged Q82 ('V 2 /F'=7.39) from results prose — parameter table was unreadable</li><li>apparent-ness (ontology-grounded): parameterization=apparent, measured_compound=mefloquine</li><li>held at status:extracted — NIL link or unit issue (mismatch/unknown/normalisation-failed) present</li><li>status held at route_to_review — not promoted</li><li>skipped review gap-fill of TLAG: primary's parameterization (rate-constant / ka-only) does not use it</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 1036800, Tolerance = 1e-9, Interval = 1));
end Mefloquine_Rufener2018_reference;
