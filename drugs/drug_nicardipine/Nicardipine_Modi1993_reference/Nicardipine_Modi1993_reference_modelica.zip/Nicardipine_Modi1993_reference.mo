model Nicardipine_Modi1993_reference
  parameter Real Cl_ref = 1.7888888888888892e-05 "Cl [m3/s]";
  parameter Real Vd_ref = 0.01925 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.479525,
    adminMass = 9e-05
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About nicardipine</h4><p>Nicardipine is a dihydropyridine calcium channel blocker used to treat arterial hypertension and angina pectoris. It is an approved drug, though it is not authorised in the European Union.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q729213\">Wikidata Q729213</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>nicardipine</td></tr><tr><td>population:</td><td>healthy males</td></tr><tr><td>source_paper:</td><td>Modi_1993</td></tr><tr><td>measured_compound:</td><td>nicardipine</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>nicardipine 479.525 g/mol (drugbank)</td></tr></table><h4>Interpretation flags</h4><ul><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=nicardipine</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Nicardipine_Modi1993_reference;
