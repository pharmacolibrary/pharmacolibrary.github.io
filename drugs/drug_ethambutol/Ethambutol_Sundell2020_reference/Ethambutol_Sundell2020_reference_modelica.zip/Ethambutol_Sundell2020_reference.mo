model Ethambutol_Sundell2020_reference
  parameter Real Cl_ref = 2.1500000000000004e-05 "Cl [m3/s]";
  parameter Real Vd_ref = 0.0762 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.20430979999999999,
    adminMass = 0.0012,
    ka = 0.0004472222222222222,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About ethambutol</h4><p>Ethambutol is an antituberculous drug used to treat tuberculosis, including pulmonary tuberculosis, and Mycobacterium avium-intracellulare infections. It is widely used worldwide and appears on the WHO list of essential medicines, both alone and in fixed-dose combinations with other tuberculosis drugs.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q412318\">Wikidata Q412318</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>ethambutol</td></tr><tr><td>population:</td><td>adult patients coinfected with tuberculosis and HIV</td></tr><tr><td>source_paper:</td><td>Sundell_2020</td></tr><tr><td>measured_compound:</td><td>ethambutol</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>ethambutol 204.31 g/mol (drugbank)</td></tr></table><p><b>Defaulted (base-class default used):</b> Tlag.</p><h4>Interpretation flags</h4><ul><li>dropped unlinked row (NIL): 'doses of 30 mg/kg of body weight and 50 mg/kg for G/G and G/A carriers, respectively' — extend the ontology if this is a real PK parameter (source ['Sundell_2020:abstract'])</li><li>apparent-ness (ontology-grounded): parameterization=apparent, measured_compound=ethambutol</li><li>held at status:extracted — NIL link or unit issue (mismatch/unknown/normalisation-failed) present</li><li>status held at route_to_review — not promoted</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li><li>gap-filled Q49 (kabs) from Srivastava_2022_2's review values (primary lacked it)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Ethambutol_Sundell2020_reference;
