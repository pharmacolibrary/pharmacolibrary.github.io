function p = Ethambutol_Sundell2020_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: ethambutol   source: Sundell_2020 / reference   route: oral
  p.name  = 'Ethambutol_Sundell2020_reference_params';
  p.drug  = 'ethambutol';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 76.2;                % central volume [L]
  p.CL = 77.4;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 1.61;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 1200.0;             % dose [mg]
end
