model Ethambutol_Srivastava2022v2_reference
  parameter Real Cl_ref = 6.394444444444444e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.2858 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 0.9,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.20430979999999999,
    adminMass = 0.0012,
    ka = 0.0004472222222222222,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About ethambutol</h4><p>Ethambutol is an antituberculous drug used to treat tuberculosis, including pulmonary tuberculosis, and Mycobacterium avium-intracellulare infections. It is widely used worldwide and appears on the WHO list of essential medicines, both alone and in fixed-dose combinations with other tuberculosis drugs.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q412318\">Wikidata Q412318</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>ethambutol</td></tr><tr><td>population:</td><td>review reference</td></tr><tr><td>source_paper:</td><td>Srivastava_2022_2</td></tr><tr><td>measured_compound:</td><td>ethambutol</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>ethambutol 204.31 g/mol (drugbank)</td></tr></table><p><b>Defaulted (base-class default used):</b> F, Tlag.</p><h4>Interpretation flags</h4><ul><li>built from REVIEW reference values (Srivastava_2022_2) — secondary source</li><li>volume reported by review</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 162000, Tolerance = 1e-9, Interval = 1));
end Ethambutol_Srivastava2022v2_reference;
