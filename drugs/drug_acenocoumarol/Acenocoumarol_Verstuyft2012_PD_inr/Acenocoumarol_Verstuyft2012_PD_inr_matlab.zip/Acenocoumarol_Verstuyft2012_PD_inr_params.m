function p = Acenocoumarol_Verstuyft2012_PD_inr_params()
% Acenocoumarol_Verstuyft2012_PD_inr_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% acenocoumarol Verstuyft_2012::INR: indirect_response_i exposure-response sweep (response = E0*(1 - Emax*frac)). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one mg L per second, in SI inside (kg/m3, s). Response INR in its own unit. Driver: S-acenocoumarol (pk_record).
p.E0 = 1.13;
p.Emax = 1.0;
p.EC50 = 0.0023;
p.gamma = 1.2;
p.slope = 0.0;
p.exposure_per_s = 1.0;
p.stop_time = 0.023;
p.form = 'E0*(1 - Emax*frac)';
end
