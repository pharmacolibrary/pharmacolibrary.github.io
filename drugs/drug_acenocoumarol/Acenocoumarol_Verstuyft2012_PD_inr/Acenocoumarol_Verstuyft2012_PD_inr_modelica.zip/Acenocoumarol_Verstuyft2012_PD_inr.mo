model Acenocoumarol_Verstuyft2012_PD_inr
  "indirect_response_i exposure-response sweep — Verstuyft_2012 :: INR (international normalized ratio)"
  extends Pharmacolibrary.Interfaces.PartialExposureResponseSweep(
    E0 = 1.13,      // [1]
    Emax = 1,  // type I effect term
    EC50 = 0.0023,  // [mg L]
    gamma = 1.2,
    exposure_per_s = 1);   // 1 mg L per second
equation
  response = E0*(1 - Emax*frac);   // steady state, indirect response type I
  // exposure_unit_unresolved: 'mg L' — the x axis is in the paper's unit, not SI
  // defaulted: Emax
  annotation(experiment(StartTime = 0, StopTime = 0.023, Interval = 4.6e-05),
    Documentation(info = "<html><body><!-- drug-about --><h4>About acenocoumarol</h4><p>Acenocoumarol is an anticoagulant, a vitamin K antagonist used to prevent and treat blood clots. It is an approved medicine and is used mainly in Europe, where it is often preferred over warfarin in some countries.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q304088\">Wikidata Q304088</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h4>Acenocoumarol_Verstuyft2012_PD_inr</h4><p>The steady-state exposure-response curve of Verstuyft C et al., <i>Clinical pharmacokinetics 51(1):41–53</i> 2012 (<a href=\"https://doi.org/10.2165/11595560-000000000-00000\">doi:10.2165/11595560-000000000-00000</a>) — international normalized ratio against S-acenocoumarol mg L — obtained by sweeping the driver instead of simulating a dose. Model family: indirect_response_i.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    =       1.13          drug-free response (baseline) (Baseline INR, Q324)
  Emax  = (library default) maximal effect term
  EC50  =     0.0023 mg L     exposure at half of the maximal effect term (C 50, Q322)
  gamma =        1.2          Hill coefficient (g, Q325)</pre><p>The algebra is <code>response = E0*(1 - Emax*frac)</code>; this model only supplies the numbers. The x axis is one mg L of S-acenocoumarol per second of simulated time: there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 1.13   (drug-free)
  exposure = EC50 (0.0023 mg L)  response 0.565
  exposure -> infinity  response 0</pre></body></html>"));
end Acenocoumarol_Verstuyft2012_PD_inr;
