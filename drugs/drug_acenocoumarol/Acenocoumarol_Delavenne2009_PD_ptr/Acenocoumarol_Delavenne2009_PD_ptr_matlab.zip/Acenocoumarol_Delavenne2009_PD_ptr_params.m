function p = Acenocoumarol_Delavenne2009_PD_ptr_params()
% Acenocoumarol_Delavenne2009_PD_ptr_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% acenocoumarol Delavenne_2009::PTr: indirect_response_i exposure-response sweep (response = E0*(1 - Emax*frac)). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one mg/L per second, in SI inside (kg/m3, s). Response PTr in %. Driver: acenocoumarol (pk_record).
p.E0 = 0.9440000000000001;
p.Emax = 1.0;
p.EC50 = 5.0999999999999986e-05;
p.gamma = 1.0;
p.slope = 0.0;
p.exposure_per_s = 0.001;
p.stop_time = 0.51;
p.form = 'E0*(1 - Emax*frac)';
end
