model Acenocoumarol_Delavenne2009_PD_ptr
  "indirect_response_i exposure-response sweep — Delavenne_2009 :: PTr (prothrombin time ratio)"
  extends Pharmacolibrary.Interfaces.PartialExposureResponseSweep(
    E0 = 0.944,      // [1; % × 0.01]
    Emax = 1,  // type I effect term
    EC50 = 5.1e-05,  // [kg/m3; mg/L × 0.001]
    gamma = 1,
    exposure_per_s = 0.001);   // 1 mg/L per second
equation
  response = E0*(1 - Emax*frac);   // steady state, indirect response type I
  // defaulted: Emax
  // defaulted: gamma
  annotation(experiment(StartTime = 0, StopTime = 0.51, Interval = 0.00102),
    Documentation(info = "<html><body><!-- drug-about --><h4>About acenocoumarol</h4><p>Acenocoumarol is an anticoagulant, a vitamin K antagonist used to prevent and treat blood clots. It is an approved medicine and is used mainly in Europe, where it is often preferred over warfarin in some countries.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q304088\">Wikidata Q304088</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h4>Acenocoumarol_Delavenne2009_PD_ptr</h4><p>The steady-state exposure-response curve of Delavenne X et al., <i>Fundamental &amp; clinical pharmacology 23(1):127–135</i> 2009 (<a href=\"https://doi.org/10.1111/j.1472-8206.2008.00642.x\">doi:10.1111/j.1472-8206.2008.00642.x</a>) — prothrombin time ratio [%] against acenocoumarol mg/L — obtained by sweeping the driver instead of simulating a dose. Model family: indirect_response_i.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    =       94.4 %        drug-free response (baseline) (PTr0, Q324)
  Emax  = (library default) maximal effect term
  EC50  =      0.051 mg/L     exposure at half of the maximal effect term (CF50, Q321)
  gamma = (library default) Hill coefficient</pre><p>The algebra is <code>response = E0*(1 - Emax*frac)</code>; this model only supplies the numbers. The x axis is one mg/L of acenocoumarol per second of simulated time (exposure is in kg/m3): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0.944   (drug-free)
  exposure = EC50 (0.051 mg/L)  response 0.472
  exposure -> infinity  response 0</pre></body></html>"));
end Acenocoumarol_Delavenne2009_PD_ptr;
