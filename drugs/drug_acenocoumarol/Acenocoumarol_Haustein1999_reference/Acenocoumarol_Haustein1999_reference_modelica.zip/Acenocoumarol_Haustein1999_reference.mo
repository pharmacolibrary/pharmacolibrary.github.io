model Acenocoumarol_Haustein1999_reference
  parameter Real Cl_ref = 1.5500000000000002e-07 "Cl [m3/s]";
  parameter Real Vd_ref = 0.0084 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.35332549999999996,
    adminMass = 1e-05
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About acenocoumarol</h4><p>Acenocoumarol is an anticoagulant, a vitamin K antagonist used to prevent and treat blood clots. It is an approved medicine and is used mainly in Europe, where it is often preferred over warfarin in some countries.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q304088\">Wikidata Q304088</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>acenocoumarol</td></tr><tr><td>population:</td><td>review reference</td></tr><tr><td>source_paper:</td><td>Haustein_1999</td></tr><tr><td>measured_compound:</td><td>acenocoumarol</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>acenocoumarol 353.325 g/mol (drugbank)</td></tr></table><h4>Interpretation flags</h4><ul><li>built from REVIEW reference values (Haustein_1999) — secondary source</li><li>volume reported by review</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 259200, Tolerance = 1e-9, Interval = 1));
end Acenocoumarol_Haustein1999_reference;
