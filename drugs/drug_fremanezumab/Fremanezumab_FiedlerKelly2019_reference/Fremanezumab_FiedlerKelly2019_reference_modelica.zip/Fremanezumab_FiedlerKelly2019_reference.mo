model Fremanezumab_FiedlerKelly2019_reference
  parameter Real Cl_ref = 5.324074074074074e-08 "Cl [m3/s]";
  parameter Real Vd_ref = 0.00298 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C_enteral(
    weight = 70.0,
    F = 0.658,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    adminMass = 0.000225,
    ka = 0.00018287037037037038,
    Tlag = 6937.92,
    k12 = 1.0175863783246334e-06,
    k21 = 1.7630275624461673e-06
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About fremanezumab</h4><p>Fremanezumab is a monoclonal antibody used to prevent migraine, including migraine with and without aura. It is an approved CGRP-antagonist medicine authorised in the European Union for migraine prevention.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q39048381\">Wikidata Q39048381</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>fremanezumab</td></tr><tr><td>population:</td><td>healthy subjects and patients with migraine</td></tr><tr><td>source_paper:</td><td>Fiedler-Kelly_2019</td></tr><tr><td>measured_compound:</td><td>fremanezumab</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>bcp14096-tbl-0002</td></tr><tr><td>input:</td><td>PK_2C_enteral: absorption rate constant reported</td></tr></table><h4>Interpretation flags</h4><ul><li>dropped duplicate Q63 ('Vc,SC: Central volume of distribution SC (L)e', value '19.9') — already have one for this compound</li><li>dropped unlinked row (NIL): 'Minimum value of the objective function = 73303.561' — extend the ontology if this is a real PK parameter (source ['bcp14096-tbl-0002:row15:col1', 'bcp14096-tbl-0002:row15:col2', 'bcp14096-tbl-0002:row15:col3', 'bcp14096-tbl-0002:row15:col4'])</li><li>covariate effect for Q319 has no base parameter row (kept as unattached equation-variable)</li><li>covariate effect for Q319 has no base parameter row (kept as unattached equation-variable)</li><li>implicit units: 'Vc,iv: Central volume of distribution IV (L)d' → L (from the paper text: &quot;The abstract states 'central distribution volume (1.88 L)' and the results section states 'central CL and Vc,SC were 0.0&quot;)</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=fremanezumab</li><li>molar mass: none found for 'fremanezumab' — its concentrations stay mass-only</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 259200, Tolerance = 1e-9, Interval = 1));
end Fremanezumab_FiedlerKelly2019_reference;
