model Fremanezumab_Jones2021_previously_developed_adult_model_appl
  parameter Real Cl_ref = 1.0439814814814816e-09 "Cl [m3/s]";
  parameter Real Vd_ref = 0.00188 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C_enteral(
    weight = 70.0,
    F = 0.658,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    adminMass = 0.00012,
    ka = 2.083333333333333e-06,
    Tlag = 6937.92,
    k12 = 1.6129826635145786e-06,
    k21 = 1.7630275624461673e-06
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About fremanezumab</h4><p>Fremanezumab is a monoclonal antibody used to prevent migraine, including migraine with and without aura. It is an approved CGRP-antagonist medicine authorised in the European Union for migraine prevention.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q39048381\">Wikidata Q39048381</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>fremanezumab</td></tr><tr><td>population:</td><td>pediatric patients with migraine</td></tr><tr><td>source_paper:</td><td>Jones_2021</td></tr><tr><td>measured_compound:</td><td>fremanezumab</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>pharmaceutics-13-00785-t001</td></tr><tr><td>input:</td><td>PK_2C_enteral: absorption rate constant reported</td></tr></table><h4>Interpretation flags</h4><ul><li>table section iiv: 'Residual variability proportional component' routed out of structural estimates ('Interindividual variability in ka')</li><li>table section iiv: 'Residual variability additive component' routed out of structural estimates ('Interindividual variability in ka')</li><li>covariate effect for Q319 has no base parameter row (kept as unattached equation-variable)</li><li>covariate effect for Q319 has no base parameter row (kept as unattached equation-variable)</li><li>implicit units: 'ka: absorption rate constant (1/day)' → 1/day (from the paper text: &quot;Text excerpt: 'a fixed lag time of 0.0803 days was applied' and the parameter list in the prompt specifies '(1/day)'. Wh&quot;)</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=fremanezumab</li><li>population split: 'previously developed adult model applied to pediatric data' subgroup of Jones_2021 (paper reports 2 populations: pediatric model to support phase 3 development 1, previously developed adult model applied to pediatric data)</li><li>molar mass: none found for 'fremanezumab' — its concentrations stay mass-only</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 7862400, Tolerance = 1e-9, Interval = 1));
end Fremanezumab_Jones2021_previously_developed_adult_model_appl;
