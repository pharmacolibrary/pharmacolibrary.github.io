% Run (SimBiology): build model + dose, simulate 0..2184.0 h, plot.
p = Fremanezumab_Jones2021_reference_params();
[model, dose, variant] = build_sb_pk(p);
sd = simulate_sb(model, variant, dose, 2184.0);
