model Melatonin_Wang2024_reference
  parameter Real Cl_ref = 0.00010130555555555556 "Cl [m3/s]";
  parameter Real Vd_ref = 0.042280000000000005 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.2322783,
    adminMass = 1e-05
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About melatonin</h4><p>Melatonin, a hormone made by the pineal gland, is used as a hypnotic for sleep problems such as jet lag, and in the EU also for sleep disorders in autism. It is widely used, with authorised products in the European Union, and is also available as a supplement and approved for veterinary use.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q180912\">Wikidata Q180912</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>melatonin</td></tr><tr><td>population:</td><td>review reference</td></tr><tr><td>source_paper:</td><td>Wang_2024</td></tr><tr><td>measured_compound:</td><td>melatonin</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>melatonin 232.278 g/mol (drugbank)</td></tr></table><h4>Interpretation flags</h4><ul><li>built from REVIEW reference values (Wang_2024) — secondary source</li><li>volume reported by review</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Melatonin_Wang2024_reference;
