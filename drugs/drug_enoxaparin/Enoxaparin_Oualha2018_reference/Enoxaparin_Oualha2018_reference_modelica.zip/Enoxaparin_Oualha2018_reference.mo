model Enoxaparin_Oualha2018_reference
  parameter Real Cl_ref = 3.4166666666666664e-07 "Cl [m3/s]";
  parameter Real Vd_ref = 0.0146 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    adminMass = 1e-05
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About enoxaparin</h4><p>Enoxaparin is a low molecular weight heparin used as an antithrombotic to prevent and treat blood clots. It is an approved medicine and is widely used in human medicine.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q105969996\">Wikidata Q105969996</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>enoxaparin</td></tr><tr><td>population:</td><td>paediatric liver transplantation</td></tr><tr><td>source_paper:</td><td>Oualha_2018</td></tr><tr><td>measured_compound:</td><td>anti-Xa activity</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C: IV (no input phase)</td></tr></table><h4>Interpretation flags</h4><ul><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=anti-Xa activity</li><li>molar mass: no plausible PubChem entry for 'anti-Xa activity' ('no full name in the paper') — left in mass units</li><li>molar mass: none found for 'enoxaparin' — its concentrations stay mass-only</li><li>molar mass: none found for 'anti-Xa activity' — its concentrations stay mass-only</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li><li>review gap-fill skipped: this record measures 'anti-Xa activity', not enoxaparin — the review values are the parent's</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 151200, Tolerance = 1e-9, Interval = 1));
end Enoxaparin_Oualha2018_reference;
