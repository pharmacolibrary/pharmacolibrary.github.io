model Lacosamide_Li2025_boostrap
  parameter Real Cl_ref = 4.1944444444444446e-07 "Cl [m3/s]";
  parameter Real Vd_ref = 0.023600000000000003 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.2502936,
    adminMass = 0.0003,
    ka = 0.0006805555555555556,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About lacosamide</h4><p>Lacosamide is an anticonvulsant medicine used to treat epilepsy, including partial-onset seizures, and has also been studied for diabetic neuropathy. It is an approved drug with several products authorised in the European Union, where it is used for epilepsy.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q420077\">Wikidata Q420077</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>lacosamide</td></tr><tr><td>population:</td><td>children with epilepsy</td></tr><tr><td>source_paper:</td><td>Li_2025</td></tr><tr><td>measured_compound:</td><td>lacosamide</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>Tab2</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>lacosamide 250.294 g/mol (drugbank)</td></tr></table><p><b>Defaulted (base-class default used):</b> Tlag.</p><h4>Interpretation flags</h4><ul><li>dropped unlinked row (NIL): 'CL-BW' — extend the ontology if this is a real PK parameter (source ['Tab2:row7:col3', 'Tab2:row7:col5', 'Tab2:row19:col3', 'Tab2:row19:col5'])</li><li>dropped unlinked row (NIL): 'CL-rs12769205*GA' — extend the ontology if this is a real PK parameter (source ['Tab2:row20:col3', 'Tab2:row20:col5'])</li><li>dropped unlinked row (NIL): 'CL-rs12769205*GG' — extend the ontology if this is a real PK parameter (source ['Tab2:row21:col3', 'Tab2:row21:col5'])</li><li>implicit units: 'Ka' → 1/h (from the paper text: 'ka was fixed at 2.45 h−1, based on values reported in a previous study')</li><li>apparent-ness (ontology-grounded): parameterization=apparent, measured_compound=lacosamide</li><li>population split: 'boostrap' subgroup of Li_2025 (paper reports 2 populations: boostrap, final models)</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of TLAG: primary's parameterization (rate-constant / ka-only) does not use it</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 259200, Tolerance = 1e-9, Interval = 1));
end Lacosamide_Li2025_boostrap;
