model Lacosamide_Wu2026_reference
  parameter Real Cl_ref = 3.9444444444444444e-07 "Cl [m3/s]";
  parameter Real Vd_ref = 0.009949999999999999 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.2502936,
    adminMass = 0.0003,
    ka = 3.611111111111111e-05,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About lacosamide</h4><p>Lacosamide is an anticonvulsant medicine used to treat epilepsy, including partial-onset seizures, and has also been studied for diabetic neuropathy. It is an approved drug with several products authorised in the European Union, where it is used for epilepsy.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q420077\">Wikidata Q420077</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>lacosamide</td></tr><tr><td>population:</td><td>Chinese children and adults with epilepsy</td></tr><tr><td>source_paper:</td><td>Wu_2026</td></tr><tr><td>measured_compound:</td><td>lacosamide</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>lacosamide 250.294 g/mol (drugbank)</td></tr></table><p><b>Defaulted (base-class default used):</b> Tlag.</p><h4>Interpretation flags</h4><ul><li>dropped value-less row: 'LCM clearance (CL)' (captured trailing unit 'CL' for child rows)</li><li>unit_dimension_unknown: 'fold' (CL)</li><li>unit_dimension_unknown: 'fixed' (kabs)</li><li>dropped duplicate Q22 ('CL', value 1.19) — already have one for this compound</li><li>implicit units: 'LCM CL' → L/h (from the popPK convention: 'Clearance (CL) in population pharmacokinetics is conventionally expressed in volume per time, typically L/h for most sma')</li><li>implicit units: 'absorption rate constant' → 1/h (from the popPK convention: 'First-order absorption rate constants (kabs) are conventionally expressed in reciprocal time, typically 1/h in populatio')</li><li>apparent-ness (ontology-grounded): parameterization=apparent, measured_compound=lacosamide</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of TLAG: primary's parameterization (rate-constant / ka-only) does not use it</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 172800, Tolerance = 1e-9, Interval = 1));
end Lacosamide_Wu2026_reference;
