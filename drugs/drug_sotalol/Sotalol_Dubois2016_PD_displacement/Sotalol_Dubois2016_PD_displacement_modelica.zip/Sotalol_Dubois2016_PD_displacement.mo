model Sotalol_Dubois2016_PD_displacement
  "emax exposure-response sweep — Dubois_2016 :: Displacement (displacement of [3H]-dofetilide)"
  extends Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep(
    E0 = 0.997,      // [1; % × 0.01]
    Emax = -1.03,  // [1; % × 0.01]
    EC50 = 56.4,  // [μM]
    gamma = 1,
    exposure_per_s = 1);   // 1 μM per second
  // imax_as_negative_emax: Imax (Q323) enters SigmoidEmaxSweep as −Emax
  // exposure_unit_unresolved: 'μM' — the x axis is in the paper's unit, not SI
  // defaulted: gamma
  annotation(experiment(StartTime = 0, StopTime = 570, Interval = 1.14),
    Documentation(info = "<html><body><!-- drug-about --><h4>About sotalol</h4><p>Sotalol is a non-selective beta blocker with additional antiarrhythmic activity, used to treat heart rhythm problems such as atrial fibrillation, ventricular fibrillation, and supraventricular tachycardia. It is an approved medicine that remains in use, though it carries a boxed warning.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q413591\">Wikidata Q413591</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h4>Sotalol_Dubois2016_PD_displacement</h4><p>The steady-state exposure-response curve of Dubois VF et al., <i>British journal of pharmacology 173(19):2819–2832</i> 2016 (<a href=\"https://doi.org/10.1111/bph.13558\">doi:10.1111/bph.13558</a>) — displacement of [3H]-dofetilide [%] against sotalol μM — obtained by sweeping the driver instead of simulating a dose. Model family: emax.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    =       99.7 %        drug-free response (baseline) (I 0, Q324)
  Emax  =        103 %        maximal effect term (I max, Q323)
  EC50  =       56.4 μM       exposure at half of the maximal effect term (IC 50, Q322)
  gamma = (library default) Hill coefficient</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep\">SigmoidEmaxSweep</a>; this model only supplies the numbers. The x axis is one μM of sotalol per second of simulated time: there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0.997   (drug-free)
  exposure = EC50 (56.4 μM)  response 0.482
  exposure -> infinity  response -0.033</pre></body></html>"));
end Sotalol_Dubois2016_PD_displacement;
