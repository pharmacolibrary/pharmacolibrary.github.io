function p = Sotalol_Dubois2016_PD_displacement_params()
% Sotalol_Dubois2016_PD_displacement_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% sotalol Dubois_2016::Displacement: emax exposure-response sweep (response = E0 + Emax*frac). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one μM per second, in SI inside (kg/m3, s). Response Displacement in %. Driver: sotalol (cited_pk).
p.E0 = 0.997;
p.Emax = -1.03;
p.EC50 = 56.4;
p.gamma = 1.0;
p.slope = 0.0;
p.exposure_per_s = 1.0;
p.stop_time = 570.0;
p.form = 'E0 + Emax*frac';
end
