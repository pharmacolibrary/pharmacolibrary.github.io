model Sotalol_Yellepeddi2025_reference
  parameter Real Cl_ref = 2.638888888888889e-06 "Cl [m3/s]";
  parameter Real cov_crcl_0 = 0 "crcl covariate";
  parameter Real Vd_ref = 0.038200000000000005 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C_enteral(
    weight = 70.0,
    F = 1.6,
    Cl = Cl_ref*(1 + (0.7)*cov_crcl_0),
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.272364,
    adminMass = 6e-05,
    ka = 5.555555555555556e-05,
    Tlag = 0.0,
    k12 = 0.0005184700407213496,
    k21 = 0.000222284574136426
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About sotalol</h4><p>Sotalol is a non-selective beta blocker with additional antiarrhythmic activity, used to treat heart rhythm problems such as atrial fibrillation, ventricular fibrillation, and supraventricular tachycardia. It is an approved medicine that remains in use, though it carries a boxed warning.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q413591\">Wikidata Q413591</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>sotalol</td></tr><tr><td>population:</td><td>adults with atrial arrhythmias</td></tr><tr><td>source_paper:</td><td>Yellepeddi_2025</td></tr><tr><td>measured_compound:</td><td>sotalol</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>psp413302-tbl-0002</td></tr><tr><td>input:</td><td>PK_2C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>sotalol 272.364 g/mol (drugbank)</td></tr></table><p><b>Defaulted (base-class default used):</b> Tlag.</p><h4>Interpretation flags</h4><ul><li>unit_dimension_unknown: 'Vc*[WTKG/104]θ' (V1)</li><li>dropped duplicate Q63 ('θWT on Vc (Vc*[WTKG/104]θ)', value '1.1') — already have one for this compound</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=sotalol</li><li>held at status:extracted — NIL link or unit issue (mismatch/unknown/normalisation-failed) present</li><li>status held at route_to_review — not promoted</li><li>skipped review gap-fill of TLAG: primary's parameterization (rate-constant / ka-only) does not use it</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 104400, Tolerance = 1e-9, Interval = 1));
end Sotalol_Yellepeddi2025_reference;
