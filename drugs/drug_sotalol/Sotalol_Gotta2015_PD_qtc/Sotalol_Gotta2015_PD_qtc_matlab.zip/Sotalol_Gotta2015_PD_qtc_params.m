function p = Sotalol_Gotta2015_PD_qtc_params()
% Sotalol_Gotta2015_PD_qtc_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% sotalol Gotta_2015::QTc: sigmoid_emax exposure-response sweep (response = E0 + Emax*frac). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one μM per second, in SI inside (kg/m3, s). Response QTc in ms. Driver: sotalol (pk_record).
p.E0 = 0.249;
p.Emax = 0.055;
p.EC50 = 10.1;
p.gamma = 1.1;
p.slope = 0.0;
p.exposure_per_s = 1.0;
p.stop_time = 110.0;
p.form = 'E0 + Emax*frac';
end
