model Sotalol_Gotta2015_PD_qtc
  "sigmoid_emax exposure-response sweep — Gotta_2015 :: QTc (QTc)"
  extends Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep(
    E0 = 0.249,      // [s; ms × 0.001]
    Emax = 0.055,  // [s; ms × 0.001]
    EC50 = 10.1,  // [μM]
    gamma = 1.1,
    exposure_per_s = 1);   // 1 μM per second
  // exposure_unit_unresolved: 'μM' — the x axis is in the paper's unit, not SI
  annotation(experiment(StartTime = 0, StopTime = 110, Interval = 0.22),
    Documentation(info = "<html><body><!-- drug-about --><h4>About sotalol</h4><p>Sotalol is a non-selective beta blocker with additional antiarrhythmic activity, used to treat heart rhythm problems such as atrial fibrillation, ventricular fibrillation, and supraventricular tachycardia. It is an approved medicine that remains in use, though it carries a boxed warning.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q413591\">Wikidata Q413591</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h4>Sotalol_Gotta2015_PD_qtc</h4><p>The steady-state exposure-response curve of Gotta V et al., <i>British journal of pharmacology 172(17):4364–4379</i> 2015 (<a href=\"https://doi.org/10.1111/bph.13218\">doi:10.1111/bph.13218</a>) — QTc [ms] against sotalol μM — obtained by sweeping the driver instead of simulating a dose. Model family: sigmoid_emax.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    =        249 ms       drug-free response (baseline) (QTcBL60, Q324)
  Emax  =         55 ms       maximal effect term (Emax, Q320)
  EC50  =       10.1 μM       exposure at half of the maximal effect term (EC50, Q321)
  gamma =        1.1          Hill coefficient (Hill coefficient, Q325)</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep\">SigmoidEmaxSweep</a>; this model only supplies the numbers. The x axis is one μM of sotalol per second of simulated time: there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0.249   (drug-free)
  exposure = EC50 (10.1 μM)  response 0.2765
  exposure -> infinity  response 0.304</pre></body></html>"));
end Sotalol_Gotta2015_PD_qtc;
