model Potassium_Li2022v2_reference
  parameter Real Cl_ref = 2.1064814814814816e-09 "Cl [m3/s]";
  parameter Real Vd_ref = 0.0066500000000000005 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 0.9,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.0390983,
    adminMass = 0.0001,
    ka = 5.358796296296296e-06,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About potassium</h4><p>Potassium is used to treat or prevent low potassium levels in the blood, often in combination products with diuretics such as thiazides. It is an approved, widely used medicine, available in combination formulations with diuretics.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q703\">Wikidata Q703</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>potassium</td></tr><tr><td>population:</td><td>review reference</td></tr><tr><td>source_paper:</td><td>Li_2022_2</td></tr><tr><td>measured_compound:</td><td>potassium</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>potassium 39.0983 g/mol (drugbank)</td></tr></table><p><b>Defaulted (base-class default used):</b> F, Tlag.</p><h4>Interpretation flags</h4><ul><li>built from REVIEW reference values (Li_2022_2) — secondary source</li><li>volume reported by review</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 12096000, Tolerance = 1e-9, Interval = 1));
end Potassium_Li2022v2_reference;
