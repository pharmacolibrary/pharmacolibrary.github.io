function p = Nintedanib_Hartmann2026_PD_fvc_params()
% Nintedanib_Hartmann2026_PD_fvc_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% nintedanib Hartmann_2026::FVC: emax exposure-response sweep (response = E0 + Emax*frac). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one nM per second, in SI inside (kg/m3, s). Response FVC in %. Driver: nintedanib (cited_pk).
p.E0 = 0.549;
p.Emax = 1.321393261845007e-09;
p.EC50 = 8.05;
p.gamma = 1.0;
p.slope = 0.0;
p.exposure_per_s = 1.0;
p.stop_time = 81.0;
p.form = 'E0 + Emax*frac';
end
