model Nintedanib_Hartmann2026_PD_fvc
  "emax exposure-response sweep — Hartmann_2026 :: FVC (FVC %predicted)"
  extends Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep(
    E0 = 0.549,      // [1; % × 0.01]
    Emax = 1.32139326185e-09,  // [1/s; %/year × 3.16881e-10]
    EC50 = 8.05,  // [nM]
    gamma = 1,
    exposure_per_s = 1);   // 1 nM per second
  // exposure_unit_unresolved: 'nM' — the x axis is in the paper's unit, not SI
  // defaulted: gamma
  annotation(experiment(StartTime = 0, StopTime = 81, Interval = 0.162),
    Documentation(info = "<html><body><!-- drug-about --><h4>About nintedanib</h4><p>Nintedanib is a protein kinase inhibitor used to treat idiopathic pulmonary fibrosis and other interstitial lung diseases, and also certain lung cancers. It is authorised in the European Union for several fibrotic lung conditions and non-small-cell lung cancer.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q15149723\">Wikidata Q15149723</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h4>Nintedanib_Hartmann2026_PD_fvc</h4><p>The steady-state exposure-response curve of Hartmann S et al., <i>CPT: pharmacometrics &amp; systems pharmacology 15(1):e70135</i> 2026 (<a href=\"https://doi.org/10.1002/psp4.70135\">doi:10.1002/psp4.70135</a>) — FVC %predicted [%] against nintedanib nM — obtained by sweeping the driver instead of simulating a dose. Model family: emax.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    =       54.9 %        drug-free response (baseline) (Baseline, Q324)
  Emax  =       4.17 %/year   maximal effect term (Rate of change in FVC %predicted at maximum drug effect (Emax), Q320)
  EC50  =       8.05 nM       exposure at half of the maximal effect term (EC50, Q321)
  gamma = (library default) Hill coefficient</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep\">SigmoidEmaxSweep</a>; this model only supplies the numbers. The x axis is one nM of nintedanib per second of simulated time: there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0.549   (drug-free)
  exposure = EC50 (8.05 nM)  response 0.549
  exposure -> infinity  response 0.549</pre></body></html>"));
end Nintedanib_Hartmann2026_PD_fvc;
