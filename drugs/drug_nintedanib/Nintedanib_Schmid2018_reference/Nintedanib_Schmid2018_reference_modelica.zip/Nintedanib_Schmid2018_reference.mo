model Nintedanib_Schmid2018_reference
  parameter Real Cl_ref = 0.0002761111111111111 "Cl [m3/s]";
  parameter Real Vd_ref = 0.265 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.5396248,
    adminMass = 0.00038,
    ka = 2.261111111111111e-05,
    Tlag = 2480.3999999999996
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About nintedanib</h4><p>Nintedanib is a protein kinase inhibitor used to treat idiopathic pulmonary fibrosis and other interstitial lung diseases, and also certain lung cancers. It is authorised in the European Union for several fibrotic lung conditions and non-small-cell lung cancer.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q15149723\">Wikidata Q15149723</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>nintedanib</td></tr><tr><td>population:</td><td>patients with idiopathic pulmonary fibrosis</td></tr><tr><td>source_paper:</td><td>Schmid_2018</td></tr><tr><td>measured_compound:</td><td>nintedanib</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>nintedanib 539.625 g/mol (drugbank)</td></tr></table><h4>Interpretation flags</h4><ul><li>apparent-ness (ontology-grounded): parameterization=apparent, measured_compound=nintedanib</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 136800, Tolerance = 1e-9, Interval = 1));
end Nintedanib_Schmid2018_reference;
