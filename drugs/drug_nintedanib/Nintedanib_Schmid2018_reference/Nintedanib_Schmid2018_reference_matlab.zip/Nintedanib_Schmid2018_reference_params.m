function p = Nintedanib_Schmid2018_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: nintedanib   source: Schmid_2018 / reference   route: oral
  % Vc is the record's Vss — no central volume was reported; 1-compartment reading
  p.name  = 'Nintedanib_Schmid2018_reference_params';
  p.drug  = 'nintedanib';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 265.0;                % central volume [L]
  p.CL = 994.0;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.0814;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.689;             % absorption lag [h]
  p.dose = 380.0;             % dose [mg]
end
