model Varenicline_Lummis2011_PD_rmax
  "emax exposure-response sweep — Lummis_2011 :: Rmax (5-HT3 receptor activation (human, Xenopus oocytes))"
  extends Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep(
    E0 = 0,      // [1]
    Emax = 0.8,  // [1; % × 0.01]
    EC50 = 5.9,  // [μM]
    gamma = 1,
    exposure_per_s = 1);   // 1 μM per second
  // exposure_unit_unresolved: 'μM' — the x axis is in the paper's unit, not SI
  // defaulted: E0
  // defaulted: gamma
  annotation(experiment(StartTime = 0, StopTime = 59, Interval = 0.118),
    Documentation(info = "<html><body><!-- drug-about --><h4>About varenicline</h4><p>Varenicline is a medicine used to help people stop smoking (tobacco use cessation). It is an approved drug and is authorised in the European Union.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q411330\">Wikidata Q411330</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h4>Varenicline_Lummis2011_PD_rmax</h4><p>The steady-state exposure-response curve of Lummis SC et al., <i>The Journal of pharmacology and experimental therapeutics 339(1):125–131</i> 2011 (<a href=\"https://doi.org/10.1124/jpet.111.185306\">doi:10.1124/jpet.111.185306</a>) — 5-HT3 receptor activation (human, Xenopus oocytes) [%] against varenicline μM — obtained by sweeping the driver instead of simulating a dose. Model family: emax.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = (library default) drug-free response (baseline)
  Emax  =         80 %        maximal effect term (Rmax, Q320)
  EC50  =        5.9 μM       exposure at half of the maximal effect term (EC50, Q321)
  gamma = (library default) Hill coefficient</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep\">SigmoidEmaxSweep</a>; this model only supplies the numbers. The x axis is one μM of varenicline per second of simulated time: there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0   (drug-free)
  exposure = EC50 (5.9 μM)  response 0.4
  exposure -> infinity  response 0.8</pre></body></html>"));
end Varenicline_Lummis2011_PD_rmax;
