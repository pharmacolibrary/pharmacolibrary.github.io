function p = Varenicline_Lummis2011_PD_rmax_params()
% Varenicline_Lummis2011_PD_rmax_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% varenicline Lummis_2011::Rmax: emax exposure-response sweep (response = E0 + Emax*frac). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one μM per second, in SI inside (kg/m3, s). Response Rmax in %. Driver: varenicline (cited_pk).
p.E0 = 0.0;
p.Emax = 0.8;
p.EC50 = 5.9;
p.gamma = 1.0;
p.slope = 0.0;
p.exposure_per_s = 1.0;
p.stop_time = 59.0;
p.form = 'E0 + Emax*frac';
end
