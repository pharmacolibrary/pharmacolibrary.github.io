function p = Varenicline_Lummis2011_PD_rmax_2_params()
% Varenicline_Lummis2011_PD_rmax_2_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% varenicline Lummis_2011::Rmax::2: emax exposure-response sweep (response = E0 + Emax*frac). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one μM per second, in SI inside (kg/m3, s). Response Rmax in %. Driver: varenicline (cited_pk).
p.E0 = 0.0;
p.Emax = 0.35000000000000003;
p.EC50 = 18.0;
p.gamma = 1.0;
p.slope = 0.0;
p.exposure_per_s = 1.0;
p.stop_time = 180.0;
p.form = 'E0 + Emax*frac';
end
