model Varenicline_Glatard2019_reference
  parameter Real Cl_ref = 2.6666666666666664e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.211 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.211268,
    adminMass = 1e-06,
    ka = 0.0002722222222222222,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About varenicline</h4><p>Varenicline is a medicine used to help people stop smoking (tobacco use cessation). It is an approved drug and is authorised in the European Union.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q411330\">Wikidata Q411330</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>varenicline</td></tr><tr><td>population:</td><td>adult smokers from the general population</td></tr><tr><td>source_paper:</td><td>Glatard_2019</td></tr><tr><td>measured_compound:</td><td>varenicline</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>Table 2</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>varenicline 211.268 g/mol (drugbank)</td></tr></table><p><b>Defaulted (base-class default used):</b> Tlag.</p><h4>Interpretation flags</h4><ul><li>salvaged Q27 ('CL/F'=9.6) from results prose — parameter table was unreadable</li><li>salvaged Q76 ('V/F'=211) from results prose — parameter table was unreadable</li><li>salvaged Q22 ('CL/F estimate for a 70-kg individual with normal creatinine clearance in Hom-Alt/Het-Alt individuals'=8.5) from results prose — parameter table was unreadable</li><li>apparent-ness (ontology-grounded): parameterization=apparent, measured_compound=varenicline</li><li>held at status:extracted — NIL link or unit issue (mismatch/unknown/normalisation-failed) present</li><li>status held at route_to_review — not promoted</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li><li>gap-filled Q49 (kabs) from Glatard_2019's review values (primary lacked it)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 345600, Tolerance = 1e-9, Interval = 1));
end Varenicline_Glatard2019_reference;
