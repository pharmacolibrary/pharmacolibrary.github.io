model Emapalumab_Brossard2025_reference
  parameter Real Cl_ref = 3.9722222222222225e-09 "Cl [m3/s]";
  parameter Real Vd_ref = 0.0030800000000000003 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    adminMass = 1e-05,
    k12 = 9.469696969696968e-06,
    k21 = 6.814641744548287e-06
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About emapalumab</h4><p>Emapalumab is a monoclonal antibody used to treat hemophagocytic lymphohistiocytosis, an immune system disease. It is an approved immunosuppressant, though a marketing application for one product was refused in the European Union.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q28209889\">Wikidata Q28209889</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>emapalumab</td></tr><tr><td>population:</td><td>review reference</td></tr><tr><td>source_paper:</td><td>Brossard_2025</td></tr><tr><td>measured_compound:</td><td>emapalumab</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_2C: IV (no input phase)</td></tr></table><h4>Interpretation flags</h4><ul><li>built from REVIEW reference values (Brossard_2025) — secondary source</li><li>volume reported by review</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 3024000, Tolerance = 1e-9, Interval = 1));
end Emapalumab_Brossard2025_reference;
