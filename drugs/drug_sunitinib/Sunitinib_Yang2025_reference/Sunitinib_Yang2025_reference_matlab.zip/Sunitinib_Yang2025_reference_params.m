function p = Sunitinib_Yang2025_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: sunitinib   source: Yang_2025 / reference   route: oral
  p.name  = 'Sunitinib_Yang2025_reference_params';
  p.drug  = 'sunitinib';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 379.0;                % central volume [L]
  p.CL = 33.7;                % clearance [L/h]
  p.Vp = [239.0];             % peripheral volumes [L]
  p.Q  = [134.0];             % inter-compartmental clearances [L/h]
  p.ka = 0.341;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 33.0;             % dose [mg]
end
