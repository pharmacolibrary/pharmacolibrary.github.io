model Sunitinib_Yang2025_reference
  parameter Real Cl_ref = 9.361111111111111e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.379 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.3984738,
    adminMass = 3.3e-05,
    ka = 9.472222222222222e-05,
    Tlag = 0.0,
    k12 = 9.821166813251246e-05,
    k21 = 0.00015574151557415155
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About sunitinib</h4><p>Sunitinib is a protein kinase inhibitor used to treat several cancers, including kidney cancer, gastrointestinal stromal tumors, and neuroendocrine tumors. It is an approved medicine, authorised in the European Union, and widely used in cancer care.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q417542\">Wikidata Q417542</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>sunitinib</td></tr><tr><td>population:</td><td>review reference</td></tr><tr><td>source_paper:</td><td>Yang_2025</td></tr><tr><td>measured_compound:</td><td>sunitinib</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_2C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>sunitinib 398.474 g/mol (drugbank)</td></tr></table><p><b>Defaulted (base-class default used):</b> Tlag.</p><h4>Interpretation flags</h4><ul><li>built from REVIEW reference values (Yang_2025) — secondary source</li><li>volume reported by review</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 172800, Tolerance = 1e-9, Interval = 1));
end Sunitinib_Yang2025_reference;
