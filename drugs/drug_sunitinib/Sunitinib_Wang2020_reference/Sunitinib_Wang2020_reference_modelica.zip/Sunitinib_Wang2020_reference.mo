model Sunitinib_Wang2020_reference
  parameter Real Cl_ref = 6.6944444444444455e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 1.07 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.3984738,
    adminMass = 3.3e-05,
    ka = 0.00010555555555555555,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About sunitinib</h4><p>Sunitinib is a protein kinase inhibitor used to treat several cancers, including kidney cancer, gastrointestinal stromal tumors, and neuroendocrine tumors. It is an approved medicine, authorised in the European Union, and widely used in cancer care.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q417542\">Wikidata Q417542</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>sunitinib</td></tr><tr><td>population:</td><td>pediatric patients with solid tumors</td></tr><tr><td>source_paper:</td><td>Wang_2020</td></tr><tr><td>measured_compound:</td><td>sunitinib</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>Tab3</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>SU012662 370.428 g/mol (pubchem); sunitinib 398.474 g/mol (drugbank)</td></tr></table><p><b>Defaulted (base-class default used):</b> Tlag.</p><h4>Interpretation flags</h4><ul><li>dropped duplicate Q290 ('BSA on Vc/F', value '1.47') — already have one for this compound</li><li>implicit units: 'CL/F, L/hc' → L/h (from the paper text: 'The paper states: “the estimated typical values for CL/F and Vc/F were 24.1 L/h and 1070 L, respectively.”')</li><li>implicit units: 'Vc/F, Lc' → L (from the paper text: 'The paper states: “the estimated typical values for CL/F and Vc/F were 24.1 L/h and 1070 L, respectively.”')</li><li>apparent-ness (ontology-grounded): parameterization=apparent, measured_compound=sunitinib</li><li>template fit: PK_3M_9C — formed from central; parent 2, metabolites [0]</li><li>row roles (LLM): model_class=compartmental; 12/12 row label(s) assigned, 12 linked by role; re-tagged sunitinib→parent ×12, SU012662→parent ×12</li><li>engineer: parent → metabolite not buildable on PK_3M_9C (None) — the measured compound's 1-compartment model instead</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 604800, Tolerance = 1e-9, Interval = 1));
end Sunitinib_Wang2020_reference;
