model Tapentadol_Watson2019_reference
  parameter Real Cl_ref = 4.722222222222223e-05 "Cl [m3/s]";
  parameter Real Vd_ref = 0.685 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.22133850000000002,
    adminMass = 7e-05,
    ka = 0.0005638888888888888,
    Tlag = 889.2
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About tapentadol</h4><p>Tapentadol is an opioid painkiller used to treat moderate to severe pain, including pain associated with fibromyalgia. It is an approved medicine and is widely used as an analgesic, though it carries a boxed warning.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q414463\">Wikidata Q414463</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>tapentadol</td></tr><tr><td>population:</td><td>pediatric patients with acute pain</td></tr><tr><td>source_paper:</td><td>Watson_2019</td></tr><tr><td>measured_compound:</td><td>tapentadol</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>T0005</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>tapentadol 221.339 g/mol (drugbank)</td></tr></table><h4>Interpretation flags</h4><ul><li>dropped unlinked row (NIL): 'NONMEM' — extend the ontology if this is a real PK parameter (source ['T0005:row1:col1'])</li><li>routed 'Cov CL/F-V/F' → Q314 (omega_cov) to covariance — variability estimate, not a structural parameter</li><li>routed 'Cov CL/F-Ka' → Q314 (omega_cov) to covariance — variability estimate, not a structural parameter</li><li>routed 'Cov V/F-Ka' → Q314 (omega_cov) to covariance — variability estimate, not a structural parameter</li><li>covariate effect for Q319 has no base parameter row (kept as unattached equation-variable)</li><li>covariate effect for Q319 has no base parameter row (kept as unattached equation-variable)</li><li>apparent-ness (ontology-grounded): parameterization=apparent, measured_compound=tapentadol</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Tapentadol_Watson2019_reference;
