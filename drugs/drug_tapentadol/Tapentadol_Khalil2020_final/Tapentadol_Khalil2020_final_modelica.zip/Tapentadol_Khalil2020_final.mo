model Tapentadol_Khalil2020_final
  parameter Real Cl_ref = 1.2749999999999998e-05 "Cl [m3/s]";
  parameter Real Vd_ref = 0.188 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 0.195,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.22133850000000002,
    adminMass = 2.1e-05,
    ka = 0.0004555555555555555,
    Tlag = 925.2
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About tapentadol</h4><p>Tapentadol is an opioid painkiller used to treat moderate to severe pain, including pain associated with fibromyalgia. It is an approved medicine and is widely used as an analgesic, though it carries a boxed warning.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q414463\">Wikidata Q414463</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>tapentadol</td></tr><tr><td>population:</td><td>children from birth to <18 years old with acute pain</td></tr><tr><td>source_paper:</td><td>Khalil_2020</td></tr><tr><td>measured_compound:</td><td>tapentadol</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>t0003</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>tapentadol 221.339 g/mol (drugbank)</td></tr></table><h4>Interpretation flags</h4><ul><li>dropped unlinked row (NIL): 'Pop. Estimate' — extend the ontology if this is a real PK parameter (source ['t0003:row1:col5'])</li><li>dropped unlinked row (NIL): 'PMA50 (wks)' — extend the ontology if this is a real PK parameter (source ['t0003:row7:col4', 't0003:row7:col5', 't0003:row7:col6'])</li><li>unit_dimension_unknown: 'wks −1' (kel)</li><li>dropped duplicate Q22 ('Cov CL-V', value '0.031') — already have one for this compound</li><li>covariate effect for Q325 has no base parameter row (kept as unattached equation-variable)</li><li>covariate effect for Q319 has no base parameter row (kept as unattached equation-variable)</li><li>covariate effect for Q319 has no base parameter row (kept as unattached equation-variable)</li><li>implicit units: 'k (wks −1)' → 1/week (from the paper text: &quot;The parameter string provided in the input is 'k (wks −1) = 0.013', which explicitly states the unit as 'wks −1' (invers&quot;)</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=tapentadol</li><li>structure disagreement: deterministic 1C vs LLM 2C — review compartment count</li><li>model-stage split: 'final model with estimated exponents' is the final model of Khalil_2020 (paper reports 2 stages: final model with estimated exponents, final model with fixed exponents); same population, different model-building step</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary's parameterization (rate-constant / ka-only) does not use it</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Tapentadol_Khalil2020_final;
