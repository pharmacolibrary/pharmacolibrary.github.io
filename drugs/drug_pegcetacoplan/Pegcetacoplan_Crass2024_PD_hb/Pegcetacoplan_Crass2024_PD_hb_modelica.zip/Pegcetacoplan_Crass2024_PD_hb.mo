model Pegcetacoplan_Crass2024_PD_hb
  "sigmoid_emax exposure-response sweep — Crass_2024 :: Hb (hemoglobin)"
  extends Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep(
    E0 = 87.4,      // [kg/m3; g/dL × 10]
    Emax = 510,  // [kg/m3; g/dL × 10]
    EC50 = 0.337,  // [kg/m3; μg/mL × 0.001]
    gamma = 4.66,
    exposure_per_s = 0.001);   // 1 μg/mL per second
  annotation(experiment(StartTime = 0, StopTime = 3400, Interval = 6.8),
    Documentation(info = "<html><body><!-- drug-about --><h4>About pegcetacoplan</h4><p>Pegcetacoplan is a complement inhibitor used to treat paroxysmal nocturnal hemoglobinuria. It is authorised in the European Union and also has ophthalmological uses, though it carries a boxed warning.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q106863504\">Wikidata Q106863504</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h4>Pegcetacoplan_Crass2024_PD_hb</h4><p>The steady-state exposure-response curve of Crass RL et al., <i>Drugs in R&amp;D 24(4):563–573</i> 2024 (<a href=\"https://doi.org/10.1007/s40268-024-00500-7\">doi:10.1007/s40268-024-00500-7</a>) — hemoglobin [g/dL] against pegcetacoplan μg/mL — obtained by sweeping the driver instead of simulating a dose. Model family: sigmoid_emax.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    =       8.74 g/dL     drug-free response (baseline) (Baseline concentration, Q324)
  Emax  =         51 g/dL     maximal effect term (E max , % change from baseline, Q320)
  EC50  =        337 μg/mL    exposure at half of the maximal effect term (EC50, μg/mL pegcetacoplan, Q321)
  gamma =       4.66          Hill coefficient (Hill sigmoidicity coefficient, Q325)</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep\">SigmoidEmaxSweep</a>; this model only supplies the numbers. The x axis is one μg/mL of pegcetacoplan per second of simulated time (exposure is in kg/m3): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 87.4   (drug-free)
  exposure = EC50 (337 μg/mL)  response 342.4
  exposure -> infinity  response 597.4</pre></body></html>"));
end Pegcetacoplan_Crass2024_PD_hb;
