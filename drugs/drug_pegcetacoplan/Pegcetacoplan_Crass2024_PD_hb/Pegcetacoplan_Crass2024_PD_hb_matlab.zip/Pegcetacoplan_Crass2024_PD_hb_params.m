function p = Pegcetacoplan_Crass2024_PD_hb_params()
% Pegcetacoplan_Crass2024_PD_hb_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% pegcetacoplan Crass_2024::Hb: sigmoid_emax exposure-response sweep (response = E0 + Emax*frac). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one μg/mL per second, in SI inside (kg/m3, s). Response Hb in g/dL. Driver: pegcetacoplan (pk_record).
p.E0 = 87.39999999999999;
p.Emax = 509.9999999999999;
p.EC50 = 0.3369999999999999;
p.gamma = 4.66;
p.slope = 0.0;
p.exposure_per_s = 0.001;
p.stop_time = 3400.0;
p.form = 'E0 + Emax*frac';
end
