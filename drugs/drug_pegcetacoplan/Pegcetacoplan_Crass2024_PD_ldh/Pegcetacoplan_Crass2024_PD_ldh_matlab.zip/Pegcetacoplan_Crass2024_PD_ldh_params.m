function p = Pegcetacoplan_Crass2024_PD_ldh_params()
% Pegcetacoplan_Crass2024_PD_ldh_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% pegcetacoplan Crass_2024::LDH: sigmoid_emax exposure-response sweep (response = E0 + Emax*frac). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one μg/mL per second, in SI inside (kg/m3, s). Response LDH in U/L. Driver: pegcetacoplan (pk_record).
p.E0 = 3.1882350123263995e-21;
p.Emax = -1.5276959434063997e-22;
p.EC50 = 0.18699999999999997;
p.gamma = 3.42;
p.slope = 0.0;
p.exposure_per_s = 0.001;
p.stop_time = 1900.0;
p.form = 'E0 + Emax*frac';
end
