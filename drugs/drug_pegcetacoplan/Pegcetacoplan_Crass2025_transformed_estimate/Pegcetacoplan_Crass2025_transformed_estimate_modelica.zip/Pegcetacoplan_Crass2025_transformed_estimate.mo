model Pegcetacoplan_Crass2025_transformed_estimate
  parameter Real Cl_ref = 3.761574074074074e-09 "Cl [m3/s]";
  parameter Real cov_sex_0 = 0 "sex covariate";
  parameter Real Vd_ref = 0.00183 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref*(1 + (0.751)*cov_sex_0),
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    adminMass = 4e-06,
    ka = 6.111111111111111e-07,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About pegcetacoplan</h4><p>Pegcetacoplan is a complement inhibitor used to treat paroxysmal nocturnal hemoglobinuria. It is authorised in the European Union and also has ophthalmological uses, though it carries a boxed warning.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q106863504\">Wikidata Q106863504</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>pegcetacoplan</td></tr><tr><td>population:</td><td>patients with geographic atrophy or neovascular age-related macular degeneration</td></tr><tr><td>source_paper:</td><td>Crass_2025</td></tr><tr><td>measured_compound:</td><td>pegcetacoplan</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>tab_1</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr></table><p><b>Defaulted (base-class default used):</b> Tlag.</p><h4>Interpretation flags</h4><ul><li>table section residual_error: 'Log additive' routed out of structural estimates ('Residual variability, %')</li><li>apparent-ness (ontology-grounded): parameterization=apparent, measured_compound=pegcetacoplan</li><li>1C volume normalization: Q290→Q76 (single-compartment model has no central/peripheral split; 'VC/F, L' is the general volume)</li><li>population split: 'transformed estimate*' subgroup of Crass_2025 (paper reports 2 populations: estimate, transformed estimate*)</li><li>molar mass: none found for 'pegcetacoplan' — its concentrations stay mass-only</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of TLAG: primary's parameterization (rate-constant / ka-only) does not use it</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 6652800, Tolerance = 1e-9, Interval = 1));
end Pegcetacoplan_Crass2025_transformed_estimate;
