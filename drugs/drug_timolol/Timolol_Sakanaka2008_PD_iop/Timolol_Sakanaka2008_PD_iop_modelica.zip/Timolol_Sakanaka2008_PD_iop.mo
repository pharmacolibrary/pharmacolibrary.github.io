model Timolol_Sakanaka2008_PD_iop
  "indirect_response_i exposure-response sweep — Sakanaka_2008 :: IOP (intraocular pressure)"
  extends Pharmacolibrary.Interfaces.PartialExposureResponseSweep(
    E0 = 0,      // [1]
    Emax = 0.0663,  // type I effect term
    EC50 = 0.000268,  // [mol/m3; nmol/ml × 0.001]
    gamma = 1,
    exposure_per_s = 0.001);   // 1 nmol/ml per second
equation
  response = E0*(1 - Emax*frac);   // steady state, indirect response type I
  // defaulted: E0
  // defaulted: gamma
  annotation(experiment(StartTime = 0, StopTime = 2.7, Interval = 0.0054),
    Documentation(info = "<html><body><!-- drug-about --><h4>About timolol</h4><p>Timolol is a non-selective beta blocker used for high blood pressure, angina, after a heart attack, and as eye drops for glaucoma and raised eye pressure. It is an approved medicine and is listed as a WHO essential medicine, so it is widely used worldwide.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q413994\">Wikidata Q413994</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h4>Timolol_Sakanaka2008_PD_iop</h4><p>The steady-state exposure-response curve of Sakanaka K et al., <i>Biological &amp; pharmaceutical bulletin 31(8):1590–1595</i> 2008 (<a href=\"https://doi.org/10.1248/bpb.31.1590\">doi:10.1248/bpb.31.1590</a>) — intraocular pressure [mmHg] against timolol nmol/ml — obtained by sweeping the driver instead of simulating a dose. Model family: indirect_response_i.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = (library default) drug-free response (baseline)
  Emax  =     0.0663          maximal effect term (I max TM, Q323)
  EC50  =      0.268 nmol/ml  exposure at half of the maximal effect term (IC 50 TM, Q322)
  gamma = (library default) Hill coefficient</pre><p>The algebra is <code>response = E0*(1 - Emax*frac)</code>; this model only supplies the numbers. The x axis is one nmol/ml of timolol per second of simulated time (exposure is in mol/m3): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0   (drug-free)
  exposure = EC50 (0.268 nmol/ml)  response 0
  exposure -> infinity  response 0</pre></body></html>"));
end Timolol_Sakanaka2008_PD_iop;
