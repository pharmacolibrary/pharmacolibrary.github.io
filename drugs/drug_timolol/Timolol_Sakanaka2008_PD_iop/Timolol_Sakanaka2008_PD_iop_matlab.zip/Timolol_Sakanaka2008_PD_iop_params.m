function p = Timolol_Sakanaka2008_PD_iop_params()
% Timolol_Sakanaka2008_PD_iop_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% timolol Sakanaka_2008::IOP: indirect_response_i exposure-response sweep (response = E0*(1 - Emax*frac)). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one nmol/ml per second, in SI inside (kg/m3, s). Response IOP in mmHg. Driver: timolol (cited_pk).
p.E0 = 0.0;
p.Emax = 0.0663;
p.EC50 = 0.000268;
p.gamma = 1.0;
p.slope = 0.0;
p.exposure_per_s = 0.001;
p.stop_time = 2.7;
p.form = 'E0*(1 - Emax*frac)';
end
