model Yohimbine_Dimaio2011v2_reference
  parameter Real Cl_ref = 1.575e-05 "Cl [m3/s]";
  parameter Real Vd_ref = 0.231 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.3544427,
    adminMass = 1e-05
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About yohimbine</h4><p>Yohimbine is an alpha-2 blocker used for erectile dysfunction and hypoactive sexual desire disorder. It is classified for erectile dysfunction in urological drug groups and has approved and veterinary-approved status, though some products have been withdrawn; it is not authorised in the European Union.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q412226\">Wikidata Q412226</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>yohimbine</td></tr><tr><td>population:</td><td>healthy adult horses</td></tr><tr><td>source_paper:</td><td>Dimaio_2011_2</td></tr><tr><td>measured_compound:</td><td>yohimbine</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>yohimbine 354.443 g/mol (drugbank)</td></tr></table><h4>Interpretation flags</h4><ul><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=yohimbine</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Yohimbine_Dimaio2011v2_reference;
