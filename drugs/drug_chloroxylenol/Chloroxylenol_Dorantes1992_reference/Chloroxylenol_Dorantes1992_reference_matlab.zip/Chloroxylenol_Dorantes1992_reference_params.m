function p = Chloroxylenol_Dorantes1992_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: chloroxylenol   source: Dorantes_1992 / reference   route: iv_bolus
  % estimated (absent from source): dose
  % Vc is the record's Vss — no central volume was reported; 1-compartment reading
  p.name  = 'Chloroxylenol_Dorantes1992_reference_params';
  p.drug  = 'chloroxylenol';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'iv_bolus';        % 'oral' | 'iv_bolus'
  p.depot = false;             % oral -> first-order absorption depot
  p.Vc = 22.4;                % central volume [L]
  p.CL = 14.6;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.0;                % absorption rate [1/h]
  p.F  = 0.21;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 10.0;             % dose [mg]
end
