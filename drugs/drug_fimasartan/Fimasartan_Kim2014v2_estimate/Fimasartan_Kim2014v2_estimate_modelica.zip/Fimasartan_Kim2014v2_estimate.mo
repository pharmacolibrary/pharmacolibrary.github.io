model Fimasartan_Kim2014v2_estimate
  parameter Real Cl_ref = 2.138888888888889e-05 "Cl [m3/s]";
  parameter Real Vd_ref = 0.28600000000000003 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C_enteral(
    weight = 70.0,
    F = 0.9,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.5016499999999999,
    adminMass = 0.00012,
    ka = 0.0010555555555555555,
    Tlag = 0.0,
    k12 = 1.884226884226884e-05,
    k21 = 2.6546250684181715e-05
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About fimasartan</h4><p>Fimasartan is an angiotensin II receptor blocker developed for the treatment of high blood pressure (essential hypertension). It is considered investigational in major drug databases and is not authorised in the European Union; it is used mainly in a few Asian countries such as South Korea.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q8563179\">Wikidata Q8563179</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>fimasartan</td></tr><tr><td>population:</td><td>patients with renal impairment and healthy volunteers</td></tr><tr><td>source_paper:</td><td>Kim_2014_2</td></tr><tr><td>measured_compound:</td><td>fimasartan</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>t5-dddt-8-1723</td></tr><tr><td>input:</td><td>PK_2C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>fimasartan 501.65 g/mol (drugbank)</td></tr></table><p><b>Defaulted (base-class default used):</b> F, Tlag.</p><h4>Interpretation flags</h4><ul><li>dropped unlinked row (NIL): 'F1=θ6^GRP*' — extend the ontology if this is a real PK parameter (source ['t5-dddt-8-1723:row7:col1'])</li><li>dropped unlinked row (NIL): 'θ6' — extend the ontology if this is a real PK parameter (source ['t5-dddt-8-1723:row8:col1'])</li><li>apparent-by-design (ADVISORY, codes unchanged): extravascular dosing with no identifiable F, so these reported disposition parameters are likely apparent unless the model puts first-pass in its structure — Q22 (CL (L/h)); Q63 (Vc (L)); Q64 (Vp (L)); Q30 (Q (L/h))</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=fimasartan</li><li>population split: 'estimate' subgroup of Kim_2014_2 (paper reports 4 populations: estimate, healthy volunteers(n=8), p-value‡, ri patients(n=8))</li><li>skipped review gap-fill of TLAG: primary's parameterization (rate-constant / ka-only) does not use it</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Fimasartan_Kim2014v2_estimate;
