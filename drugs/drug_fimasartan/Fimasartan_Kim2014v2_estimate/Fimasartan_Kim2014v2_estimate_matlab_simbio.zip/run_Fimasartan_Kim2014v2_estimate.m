% Run (SimBiology): build model + dose, simulate 0..24.0 h, plot.
p = Fimasartan_Kim2014v2_estimate_params();
[model, dose, variant] = build_sb_pk(p);
sd = simulate_sb(model, variant, dose, 24.0);
