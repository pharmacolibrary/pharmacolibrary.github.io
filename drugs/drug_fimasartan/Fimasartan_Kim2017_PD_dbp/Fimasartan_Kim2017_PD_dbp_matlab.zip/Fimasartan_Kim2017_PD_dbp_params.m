function p = Fimasartan_Kim2017_PD_dbp_params()
% Fimasartan_Kim2017_PD_dbp_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% fimasartan Kim_2017::DBP: indirect_response_i exposure-response sweep (response = E0/(1 + Emax*frac)). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one ng/mL per second, in SI inside (kg/m3, s). Response DBP in mmHg. Driver: fimasartan (pk_record).
p.E0 = 82.3;
p.Emax = 33.8;
p.EC50 = 4.8200000000000004e-06;
p.gamma = 1.0;
p.slope = 0.0;
p.exposure_per_s = 1e-06;
p.stop_time = 7.3;
p.form = 'E0/(1 + Emax*frac)';
end
