model Fimasartan_Kim2017_PD_sbp
  "indirect_response_i exposure-response sweep — Kim_2017 :: SBP (Systolic blood pressure)"
  extends Pharmacolibrary.Pharmacodynamic.IndirectTurnoverSweep(
    E0 = 131,      // [mmHg]
    Emax = 21.3,  // type IV effect term
    EC50 = 2.28e-06,  // [kg/m3; ng/mL × 1e-06]
    gamma = 1,
    exposure_per_s = 1e-06);   // 1 ng/mL per second
  // emax_not_a_fraction: type I needs Imax ≤ 1 but the record has 21.3; bound as the reciprocal stimulation form (IV) the paper fitted
  // defaulted: gamma
  annotation(experiment(StartTime = 0, StopTime = 3.5, Interval = 0.007),
    Documentation(info = "<html><body><!-- drug-about --><h4>About fimasartan</h4><p>Fimasartan is an angiotensin II receptor blocker developed for the treatment of high blood pressure (essential hypertension). It is considered investigational in major drug databases and is not authorised in the European Union; it is used mainly in a few Asian countries such as South Korea.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q8563179\">Wikidata Q8563179</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h4>Fimasartan_Kim2017_PD_sbp</h4><p>The steady-state exposure-response curve of Kim CO et al., <i>Translational and clinical pharmacology 25(1):43–51</i> 2017 (<a href=\"https://doi.org/10.12793/tcp.2017.25.1.43\">doi:10.12793/tcp.2017.25.1.43</a>) — Systolic blood pressure [mmHg] against fimasartan ng/mL — obtained by sweeping the driver instead of simulating a dose. Model family: indirect_response_i.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    =        131 mmHg     drug-free response (baseline) (Base, Q324)
  Emax  =       21.3          maximal effect term (Emax, Q323)
  EC50  =       2.28 ng/mL    exposure at half of the maximal effect term (EC50,H, Q322)
  gamma = (library default) Hill coefficient</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.IndirectTurnoverSweep\">IndirectTurnoverSweep</a>; this model only supplies the numbers. The x axis is one ng/mL of fimasartan per second of simulated time (exposure is in kg/m3): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><p>The effect term enters as a reciprocal (steady state of <code>der(R) = Kin - Kout*(1 + Emax*frac)*R</code>), so EC50 is the exposure at half the maximal STIMULATION of turnover, not at half the response.</p><h4>What it reproduces</h4><pre>  exposure = 0         response 131   (drug-free)
  exposure = EC50 (2.28 ng/mL)  response 11.24
  exposure -> infinity  response 5.874</pre></body></html>"));
end Fimasartan_Kim2017_PD_sbp;
