function p = Fimasartan_Kim2017_PD_sbp_params()
% Fimasartan_Kim2017_PD_sbp_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% fimasartan Kim_2017::SBP: indirect_response_i exposure-response sweep (response = E0/(1 + Emax*frac)). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one ng/mL per second, in SI inside (kg/m3, s). Response SBP in mmHg. Driver: fimasartan (pk_record).
p.E0 = 131.0;
p.Emax = 21.3;
p.EC50 = 2.2799999999999998e-06;
p.gamma = 1.0;
p.slope = 0.0;
p.exposure_per_s = 1e-06;
p.stop_time = 3.5;
p.form = 'E0/(1 + Emax*frac)';
end
