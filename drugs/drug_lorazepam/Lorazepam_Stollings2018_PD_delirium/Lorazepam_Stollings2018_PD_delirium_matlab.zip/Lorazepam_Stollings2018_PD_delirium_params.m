function p = Lorazepam_Stollings2018_PD_delirium_params()
% Lorazepam_Stollings2018_PD_delirium_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% lorazepam Stollings_2018::delirium: log_linear exposure-response sweep (response = E0 + slope*log(exposure)). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one ng/mL per second, in SI inside (kg/m3, s). Response delirium in its own unit. Driver: lorazepam (cited_pk).
p.E0 = 0.0;
p.Emax = 0.0;
p.EC50 = 1.0;
p.gamma = 1.0;
p.slope = 13.2;
p.exposure_per_s = 1e-06;
p.stop_time = 1000.0;
p.form = 'E0 + slope*log(exposure)';
end
