model Lorazepam_Stollings2018_PD_delirium
  "log_linear exposure-response sweep — Stollings_2018 :: delirium (next-day delirium)"
  extends Pharmacolibrary.Interfaces.PartialExposureResponseSweep(
    E0 = 0,      // [1]
    Emax = 0, EC50 = 1,      // unused by a line
    exposure_per_s = 1e-06);
  parameter Real slope = 13.2   "[1]";
equation
  response = E0 + slope*log(exposure);
  // defaulted: E0
  annotation(experiment(StartTime = 0, StopTime = 1000, Interval = 2),
    Documentation(info = "<html><body><!-- drug-about --><h4>About lorazepam</h4><p>Lorazepam is a benzodiazepine used for anxiety and anxiety disorders, insomnia, status epilepticus and other epileptic seizures, catatonia, vomiting, and related sleep-wake and neurotic disorders. It is an approved medicine and appears on the WHO list of essential medicines, so it is widely used, though it carries a boxed warning.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q408265\">Wikidata Q408265</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h4>Lorazepam_Stollings2018_PD_delirium</h4><p>The steady-state exposure-response curve of Stollings JL et al., <i>The Annals of pharmacotherapy 52(6):513–521</i> 2018 (<a href=\"https://doi.org/10.1177/1060028017753480\">doi:10.1177/1060028017753480</a>) — next-day delirium against lorazepam ng/mL — obtained by sweeping the driver instead of simulating a dose. Model family: log_linear.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = (library default) drug-free response (baseline)
  slope =       13.2          change in response per unit of exposure (odds ratio, Q335)</pre><p>The algebra is <code>response = E0 + slope*log(exposure)</code>; this model only supplies the numbers. The x axis is one ng/mL of lorazepam per second of simulated time (exposure is in kg/m3): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p></body></html>"));
end Lorazepam_Stollings2018_PD_delirium;
