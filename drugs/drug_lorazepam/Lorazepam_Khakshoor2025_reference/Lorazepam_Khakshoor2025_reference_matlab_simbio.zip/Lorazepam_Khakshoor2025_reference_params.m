function p = Lorazepam_Khakshoor2025_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: lorazepam   source: Khakshoor_2025 / reference   route: iv_bolus
  % estimated (absent from source): F
  p.name  = 'Lorazepam_Khakshoor2025_reference_params';
  p.drug  = 'lorazepam';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'iv_bolus';        % 'oral' | 'iv_bolus'
  p.depot = false;             % oral -> first-order absorption depot
  p.Vc = 13.849872;                % central volume [L]
  p.CL = 0.6;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.0;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 2.5;             % dose [mg]
end
