function p = Lorazepam_NielsenKudsk1983_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: lorazepam   source: Nielsen-Kudsk_1983 / reference   route: oral
  p.name  = 'Lorazepam_NielsenKudsk1983_reference_params';
  p.drug  = 'lorazepam';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 86.8;                % central volume [L]
  p.CL = 4.3519;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.5;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.8;             % absorption lag [h]
  p.dose = 2.5;             % dose [mg]
end
