model Lorazepam_NielsenKudsk1983_reference
  parameter Real Cl_ref = 1.208861111111111e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.0868 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.321158,
    adminMass = 2.5e-06,
    ka = 0.0001388888888888889,
    Tlag = 2880.0
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About lorazepam</h4><p>Lorazepam is a benzodiazepine used for anxiety and anxiety disorders, insomnia, status epilepticus and other epileptic seizures, catatonia, vomiting, and related sleep-wake and neurotic disorders. It is an approved medicine and appears on the WHO list of essential medicines, so it is widely used, though it carries a boxed warning.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q408265\">Wikidata Q408265</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>lorazepam</td></tr><tr><td>population:</td><td>healthy adults</td></tr><tr><td>source_paper:</td><td>Nielsen-Kudsk_1983</td></tr><tr><td>measured_compound:</td><td>lorazepam</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_2C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>lorazepam 321.158 g/mol (drugbank)</td></tr></table><p><b>Defaulted (base-class default used):</b> k12, k21.</p><h4>Interpretation flags</h4><ul><li>dropped duplicate Q57 ('Mean biological half-life', value 14.01) — already have one for this compound</li><li>dropped duplicate Q61 ('Vd-area', value 1.24) — already have one for this compound</li><li>dropped value-less row: 'Half-life of the absorption phase'</li><li>apparent-ness (ontology-grounded): parameterization=apparent, measured_compound=lorazepam</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li><li>gap-filled Q49 (kabs) from Chen_2024's review values (primary lacked it)</li><li>gap-filled Q83 (tlag) from Panetta_2024's review values (primary lacked it)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 345600, Tolerance = 1e-9, Interval = 1));
end Lorazepam_NielsenKudsk1983_reference;
