function p = Lorazepam_Gupta1990_PD_trkn_params()
% Lorazepam_Gupta1990_PD_trkn_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% lorazepam Gupta_1990::TRKN: sigmoid_emax exposure-response sweep (response = E0 + Emax*frac). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one ng/ml per second, in SI inside (kg/m3, s). Response TRKN in its own unit. Driver: lorazepam (pk_record).
p.E0 = 0.0;
p.Emax = -418.0;
p.EC50 = 3.5799999999999996e-05;
p.gamma = 6.29;
p.slope = 0.0;
p.exposure_per_s = 1e-06;
p.stop_time = 360.0;
p.form = 'E0 + Emax*frac';
end
