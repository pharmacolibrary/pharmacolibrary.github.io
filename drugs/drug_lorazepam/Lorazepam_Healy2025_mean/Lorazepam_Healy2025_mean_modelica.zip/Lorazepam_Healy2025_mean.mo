model Lorazepam_Healy2025_mean
  parameter Real Cl_ref = 4.511111111111111e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.00115 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.321158,
    adminMass = 2.5e-06
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About lorazepam</h4><p>Lorazepam is a benzodiazepine used for anxiety and anxiety disorders, insomnia, status epilepticus and other epileptic seizures, catatonia, vomiting, and related sleep-wake and neurotic disorders. It is an approved medicine and appears on the WHO list of essential medicines, so it is widely used, though it carries a boxed warning.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q408265\">Wikidata Q408265</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>lorazepam</td></tr><tr><td>population:</td><td>mechanically ventilated pediatric ICU patients</td></tr><tr><td>source_paper:</td><td>Healy_2025</td></tr><tr><td>measured_compound:</td><td>lorazepam</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>T3</td></tr><tr><td>input:</td><td>PK_2C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>lorazepam 321.158 g/mol (drugbank)</td></tr></table><p><b>Defaulted (base-class default used):</b> k12, k21.</p><h4>Interpretation flags</h4><ul><li>salvaged Q22 ('clearance (CL)'=0.232) from results prose — parameter table was unreadable</li><li>salvaged Q63 ('central volume of distribution (Vc)'=1.15) from results prose — parameter table was unreadable</li><li>salvaged Q61 ('volume of distribution'=1.37) from results prose — parameter table was unreadable</li><li>implicit units: 'Cmax' → ng/mL (from the paper text: &quot;Text states 'median target concentrations around 500 ng/ml'; Cmax is a concentration, so ng/mL.&quot;)</li><li>implicit units: 'AUC' → ng·h/mL (from the popPK convention: 'AUC is concentration × time; with concentrations in ng/mL and time in h, the standard unit is ng·h/mL.')</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=lorazepam</li><li>held at status:extracted — NIL link or unit issue (mismatch/unknown/normalisation-failed) present</li><li>status held at route_to_review — not promoted</li><li>population split: 'mean' subgroup of Healy_2025 (paper reports 2 populations: mean, median)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Lorazepam_Healy2025_mean;
