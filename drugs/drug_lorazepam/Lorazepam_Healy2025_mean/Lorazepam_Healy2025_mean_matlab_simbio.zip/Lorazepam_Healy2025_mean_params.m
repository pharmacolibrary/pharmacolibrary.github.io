function p = Lorazepam_Healy2025_mean_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: lorazepam   source: Healy_2025 / mean   route: iv_bolus
  % estimated (absent from source): F
  p.name  = 'Lorazepam_Healy2025_mean_params';
  p.drug  = 'lorazepam';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'iv_bolus';        % 'oral' | 'iv_bolus'
  p.depot = false;             % oral -> first-order absorption depot
  p.Vc = 1.15;                % central volume [L]
  p.CL = 16.24;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.0;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 2.5;             % dose [mg]
end
