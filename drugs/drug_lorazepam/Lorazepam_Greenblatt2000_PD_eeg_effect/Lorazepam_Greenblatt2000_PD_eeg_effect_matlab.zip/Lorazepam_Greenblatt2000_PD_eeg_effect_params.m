function p = Lorazepam_Greenblatt2000_PD_eeg_effect_params()
% Lorazepam_Greenblatt2000_PD_eeg_effect_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% lorazepam Greenblatt_2000::EEG_effect: emax exposure-response sweep (response = E0 + Emax*frac). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one ng/mL per second, in SI inside (kg/m3, s). Response EEG effect in % over baseline. Driver: lorazepam (pk_record).
p.E0 = 0.0;
p.Emax = 12.7;
p.EC50 = 1.3099999999999998e-05;
p.gamma = 1.0;
p.slope = 0.0;
p.exposure_per_s = 1e-06;
p.stop_time = 140.0;
p.form = 'E0 + Emax*frac';
end
