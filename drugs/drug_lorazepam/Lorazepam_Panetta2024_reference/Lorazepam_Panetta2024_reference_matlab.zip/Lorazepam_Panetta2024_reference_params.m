function p = Lorazepam_Panetta2024_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: lorazepam   source: Panetta_2024 / reference   route: oral
  p.name  = 'Lorazepam_Panetta2024_reference_params';
  p.drug  = 'lorazepam';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 945.54233;                % central volume [L]
  p.CL = 58.0;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.48;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.8;             % absorption lag [h]
  p.dose = 2.5;             % dose [mg]
end
