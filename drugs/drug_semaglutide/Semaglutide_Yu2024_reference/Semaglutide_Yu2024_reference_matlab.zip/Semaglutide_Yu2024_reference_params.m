function p = Semaglutide_Yu2024_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: semaglutide   source: Yu_2024 / reference   route: oral
  p.name  = 'Semaglutide_Yu2024_reference_params';
  p.drug  = 'semaglutide';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 20.0;                % central volume [L]
  p.CL = 1.05;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.38;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 10.5;             % dose [mg]
end
