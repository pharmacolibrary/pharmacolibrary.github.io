% Run (SimBiology): build model + dose, simulate 0..1008.0 h, plot.
p = Semaglutide_Carlsson2018_base_params();
[model, dose, variant] = build_sb_pk(p);
sd = simulate_sb(model, variant, dose, 1008.0);
