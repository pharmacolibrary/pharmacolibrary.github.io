% Run (SimBiology): build model + dose, simulate 0..840.0 h, plot.
p = Semaglutide_Overgaard2019_two_compartment_final_model_params();
[model, dose, variant] = build_sb_pk(p);
sd = simulate_sb(model, variant, dose, 840.0);
