model Capivasertib_Fernandez2025_reference
  parameter Real Cl_ref = 1.6555555555555556e-05 "Cl [m3/s]";
  parameter Real Vd_ref = 0.049 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.42891500000000005,
    adminMass = 8e-05,
    ka = 0.0001225,
    Tlag = 0.0,
    k12 = 0.0001326530612244898,
    k21 = 5.752212389380531e-05
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About capivasertib</h4><p>Capivasertib is a protein kinase inhibitor used to treat breast cancer. It is authorised in the European Union for breast cancer and is also being investigated for other uses.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q27074756\">Wikidata Q27074756</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>capivasertib</td></tr><tr><td>population:</td><td>patients with cancer from six Phase I–III trials</td></tr><tr><td>source_paper:</td><td>Fernandez_2025</td></tr><tr><td>measured_compound:</td><td>capivasertib</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>cts70286-tbl-0002</td></tr><tr><td>input:</td><td>PK_2C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>capivasertib 428.915 g/mol (drugbank)</td></tr></table><p><b>Defaulted (base-class default used):</b> Tlag.</p><h4>Interpretation flags</h4><ul><li>dropped PD-category row 'Maximum inhibition of CL/F; I max' → Q323 (Imax, category G11) — pharmacodynamic parameters belong to scholarpd, not the PK model (source ['cts70286-tbl-0002:row6:col1', 'cts70286-tbl-0002:row6:col2'])</li><li>unit_dimension_unknown: 'LogitF1' (Fab)</li><li>unit_dimension_unknown: 'T50' (equation variable)</li><li>unit_dimension_unknown: 'Q4/F' (Q/F)</li><li>unit_dimension_unknown: 'V4/F' (V3/F)</li><li>unit_dimension_unknown: 'D2' (D1)</li><li>dropped unlinked row (NIL): 'Relationship between I max and planned capivasertib dose (I max_dose)' — extend the ontology if this is a real PK parameter (source ['cts70286-tbl-0002:row15:col1', 'cts70286-tbl-0002:row15:col2'])</li><li>unit_dimension_unknown: 'CL0_BBW' (allometric_exponent)</li><li>unit_dimension_unknown: 'F1_BBW' (equation variable)</li><li>dropped duplicate Q900 ('Relationship between LogitF1 and body weight (F1_BBW)', value '-1.27') — already have one for this compound</li><li>unit_dimension_unknown: 'CL0_AGE' (CL/F)</li><li>dropped duplicate Q27 ('Relationship between CL0/F and age (CL0_AGE)', value '-0.314') — already have one for this compound</li><li>covariate effect for Q83 has no base parameter row (kept as unattached equation-variable)</li><li>dropped duplicate covariate effect 'category'/'' on Q83 — ambiguous identity (two shifts cannot share one category)</li><li>implicit units: 'First‐order absorption rate constant; Ka (1/h)' → 1/h (from the paper text: 'The parameter is labeled “First‐order absorption rate constant; Ka (1/h) = 0.441.”')</li><li>implicit units: 'Apparent inter‐compartmental clearance of second peripheral compartment, L/h (Q4/F)' → L/h (from the paper text: 'The parameter is labeled “Apparent inter‐compartmental clearance of second peripheral compartment, L/h (Q4/F) = 23.4.”')</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Capivasertib_Fernandez2025_reference;
