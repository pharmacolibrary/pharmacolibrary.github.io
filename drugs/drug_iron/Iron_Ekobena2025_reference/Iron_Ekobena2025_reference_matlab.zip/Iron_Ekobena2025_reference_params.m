function p = Iron_Ekobena2025_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: iron   source: Ekobena_2025 / reference   route: oral
  % estimated (absent from source): dose
  p.name  = 'Iron_Ekobena2025_reference_params';
  p.drug  = 'iron';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 11.6;                % central volume [L]
  p.CL = 0.504;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 2.6;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.235;             % absorption lag [h]
  p.dose = 100.0;             % dose [mg]
end
