model Iron_Xu2026_reference
  parameter Real Cl_ref = 2.5231481481481483e-09 "Cl [m3/s]";
  parameter Real Vd_ref = 0.0015400000000000001 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.055845,
    adminMass = 0.0001,
    ka = 1.3541666666666667e-06,
    Tlag = 0.0,
    k12 = 1.1123136123136122e-06
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About iron</h4><p>Iron is used to treat iron deficiency anemia and hypochromic anemia. It is an approved medication, available in multivitamin-mineral combinations and other iron preparations, and is widely used as a supplement.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q677\">Wikidata Q677</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>iron</td></tr><tr><td>population:</td><td>review reference</td></tr><tr><td>source_paper:</td><td>Xu_2026</td></tr><tr><td>measured_compound:</td><td>iron</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_2C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>iron 55.845 g/mol (drugbank)</td></tr></table><p><b>Defaulted (base-class default used):</b> Tlag, k21.</p><h4>Interpretation flags</h4><ul><li>built from REVIEW reference values (Xu_2026) — secondary source</li><li>volume reported by review</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 4838400, Tolerance = 1e-9, Interval = 1));
end Iron_Xu2026_reference;
