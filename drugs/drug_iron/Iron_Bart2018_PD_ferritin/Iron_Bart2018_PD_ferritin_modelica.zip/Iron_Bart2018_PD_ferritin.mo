model Iron_Bart2018_PD_ferritin
  "linear exposure-response sweep — Bart_2018 :: ferritin (Serum ferritin)"
  extends Pharmacolibrary.Interfaces.PartialExposureResponseSweep(
    E0 = 0,      // [1]
    Emax = 0, EC50 = 1,      // unused by a line
    exposure_per_s = 1e-06);
  parameter Real slope = 2.1e-13   "[kilogram ** 2 / meter ** 3; µg·l-1·mg-1 × 1e-12]";
equation
  response = E0 + slope*exposure;
  // defaulted: E0
  annotation(experiment(StartTime = 0, StopTime = 1000, Interval = 2),
    Documentation(info = "<html><body><!-- drug-about --><h4>About iron</h4><p>Iron is used to treat iron deficiency anemia and hypochromic anemia. It is an approved medication, available in multivitamin-mineral combinations and other iron preparations, and is widely used as a supplement.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q677\">Wikidata Q677</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h4>Iron_Bart2018_PD_ferritin</h4><p>The steady-state exposure-response curve of Bart NK et al., <i>Journal of applied physiology (Bethesda, Md. : 1985) 125(6):1710–1719</i> 2018 (<a href=\"https://doi.org/10.1152/japplphysiol.00339.2018\">doi:10.1152/japplphysiol.00339.2018</a>) — Serum ferritin [µg/l] against iron mg — obtained by sweeping the driver instead of simulating a dose. Model family: linear.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = (library default) drug-free response (baseline)
  slope =       0.21 µg·l-1·mg-1 change in response per unit of exposure (slope, Q335)</pre><p>The algebra is <code>response = E0 + slope*exposure</code>; this model only supplies the numbers. The x axis is one mg of iron per second of simulated time (exposure is in kg): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0   (drug-free)</pre></body></html>"));
end Iron_Bart2018_PD_ferritin;
