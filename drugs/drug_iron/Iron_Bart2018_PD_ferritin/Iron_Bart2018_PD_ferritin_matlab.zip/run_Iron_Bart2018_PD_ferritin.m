% run_Iron_Bart2018_PD_ferritin  Evaluate the exposure-response curve and plot response against exposure.
% A sweep is a static map: no ODE solver is needed. exposure runs 0..stop_time*exposure_per_s.
p = Iron_Bart2018_PD_ferritin_params();
exposure = linspace(0, p.stop_time * p.exposure_per_s, 501);
frac = exposure.^p.gamma ./ (p.EC50^p.gamma + exposure.^p.gamma);
E0 = p.E0; Emax = p.Emax; slope = p.slope;
response = E0 + slope.*exposure;
figure; plot(exposure, response, 'LineWidth', 1.5); grid on;
xlabel('exposure [mg]'); ylabel('response [µg/l]'); title('Iron_Bart2018_PD_ferritin', 'Interpreter', 'none');
writematrix([exposure(:) response(:)], 'Iron_Bart2018_PD_ferritin.csv');
