function p = Iron_Bart2018_PD_ferritin_params()
% Iron_Bart2018_PD_ferritin_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% iron Bart_2018::ferritin: linear exposure-response sweep (response = E0 + slope*exposure). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one mg per second, in SI inside (kg/m3, s). Response ferritin in µg/l. Driver: iron (dose_only).
p.E0 = 0.0;
p.Emax = 0.0;
p.EC50 = 1.0;
p.gamma = 1.0;
p.slope = 2.1e-13;
p.exposure_per_s = 1e-06;
p.stop_time = 1000.0;
p.form = 'E0 + slope*exposure';
end
