model Veliparib_Salem2014_reference
  parameter Real Cl_ref = 5.805555555555555e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.17300000000000001 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.24429230000000002,
    adminMass = 0.0001,
    ka = 0.0001388888888888889,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About veliparib</h4><p>Veliparib is a PARP inhibitor being studied as an anticancer treatment. It remains investigational and is not an approved medicine.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q7919041\">Wikidata Q7919041</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>veliparib</td></tr><tr><td>population:</td><td>patients with non-hematologic malignancies</td></tr><tr><td>source_paper:</td><td>Salem_2014</td></tr><tr><td>measured_compound:</td><td>veliparib</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C_enteral: apparent (/F) parameterization ⇒ extravascular dosing</td></tr><tr><td>molar_masses:</td><td>veliparib 244.292 g/mol (drugbank)</td></tr></table><p><b>Defaulted (base-class default used):</b> ka, Tlag.</p><h4>Interpretation flags</h4><ul><li>dropped value-less row: 'CLCR'</li><li>dropped value-less row: 'LBM'</li><li>apparent-ness (ontology-grounded): parameterization=apparent, measured_compound=veliparib</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 104400, Tolerance = 1e-9, Interval = 1));
end Veliparib_Salem2014_reference;
