model AminocaproicAcid_Stricker2013_reference
  parameter Real Cl_ref = 5.333333333333333e-07 "Cl [m3/s]";
  parameter Real Vd_ref = 0.00127 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.1311729,
    adminMass = 0.016,
    k12 = 0.0005564304461942256,
    k21 = 0.00027931488801054017
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About aminocaproic_acid</h4><p>Aminocaproic acid is an antifibrinolytic medicine used to treat or prevent bleeding. It is an approved drug, used mainly as a hemostatic agent to control excessive bleeding.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q255968\">Wikidata Q255968</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>aminocaproic_acid</td></tr><tr><td>population:</td><td>infants undergoing craniofacial reconstruction surgery</td></tr><tr><td>source_paper:</td><td>Stricker_2013</td></tr><tr><td>measured_compound:</td><td>epsilon-aminocaproic acid</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_2C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>aminocaproic_acid 131.173 g/mol (drugbank); epsilon-aminocaproic acid 131.173 g/mol (drugbank)</td></tr></table><h4>Interpretation flags</h4><ul><li>dropped unlinked row (NIL): 'Intra-operative clearance' — extend the ontology if this is a real PK parameter (source ['Stricker_2013:abstract'])</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=epsilon-aminocaproic acid</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end AminocaproicAcid_Stricker2013_reference;
