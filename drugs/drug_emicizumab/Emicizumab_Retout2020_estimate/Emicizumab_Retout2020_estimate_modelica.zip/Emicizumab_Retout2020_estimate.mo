model Emicizumab_Retout2020_estimate
  parameter Real Cl_ref = 7.555555555555557e-08 "Cl [m3/s]";
  parameter Real Vd_ref = 0.010400000000000001 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    adminMass = 0.000105,
    ka = 0.0001488888888888889,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About emicizumab</h4><p>Emicizumab, a monoclonal antibody, is used to treat hemophilia A. It is an approved medicine authorised in the European Union.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q27155409\">Wikidata Q27155409</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>emicizumab</td></tr><tr><td>population:</td><td>adult and pediatric persons with hemophilia A</td></tr><tr><td>source_paper:</td><td>Retout_2020</td></tr><tr><td>measured_compound:</td><td>emicizumab</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>Tab4</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr></table><p><b>Defaulted (base-class default used):</b> Tlag.</p><h4>Interpretation flags</h4><ul><li>table section iiv: 'CL/F' routed out of structural estimates ('Inter-individual variabilitya')</li><li>table section iiv: 'V/F' routed out of structural estimates ('Inter-individual variabilitya')</li><li>table section iiv: 'KA' routed out of structural estimates ('Inter-individual variabilitya')</li><li>table section iiv: 'Correlation CL/F–V/F' routed out of structural estimates ('Inter-individual variabilitya')</li><li>dropped unlinked row (NIL): 'Fixed effects (BW 70 kg; ALB 45 g/L; age < 30 years)' — extend the ontology if this is a real PK parameter (source ['Tab4:row1:col2'])</li><li>dropped duplicate Q27 ('Effect of BW on CL/F', value '0.911') — already have one for this compound</li><li>dropped duplicate Q76 ('Effect of BW on V/F', value '1.00') — already have one for this compound</li><li>dropped unlinked row (NIL): 'Condition numbere' — extend the ontology if this is a real PK parameter (source ['Tab4:row20:col2'])</li><li>implicit units: 'CL/F' → L/h (from the popPK convention: 'The paper does not explicitly state the unit for CL/F in the provided text or table captions. However, CL/F is an appare')</li><li>implicit units: 'V/F' → L (from the popPK convention: 'The paper does not explicitly state the unit for V/F in the provided text or table captions. V/F is an apparent volume o')</li><li>implicit units: 'KA' → 1/h (from the popPK convention: 'The paper does not explicitly state the unit for KA in the provided text or table captions. KA is a first-order absorpti')</li><li>apparent-ness (ontology-grounded): parameterization=apparent, measured_compound=emicizumab</li><li>population split: 'estimate' subgroup of Retout_2020 (paper reports 4 populations: 1.5 mg/kg qw, 3 mg/kg q2w, 6 mg/kg q4w, estimate)</li><li>molar mass: none found for 'emicizumab' — its concentrations stay mass-only</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 518400, Tolerance = 1e-9, Interval = 1));
end Emicizumab_Retout2020_estimate;
