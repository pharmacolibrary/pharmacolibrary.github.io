% Run: build params, simulate 0..144.0 h, plot + save Emicizumab_Retout2020_estimate.png/.csv/.json.
% Interactive display (keep the window open):  octave --persist run_Emicizumab_Retout2020_estimate.m
here = fileparts(mfilename('fullpath'));
p = Emicizumab_Retout2020_estimate_params();
out = simulate_pk(p, 0:0.05:144.0);

% figure (shown on screen if interactive) and PNG (works in MATLAB and Octave)
fig = figure; plot(out.t, out.C, 'LineWidth', 1.5); grid on;
xlabel('time [h]'); ylabel('central concentration [mg/L]');
title('emicizumab — Retout_2020 (oral)');
print(fig, fullfile(here, 'Emicizumab_Retout2020_estimate.png'), '-dpng', '-r150');

% CSV (time_h, Cc_mg_per_L)
fid = fopen(fullfile(here, 'Emicizumab_Retout2020_estimate.csv'), 'w');
fprintf(fid, 'time_h,Cc_mg_per_L\n');
fprintf(fid, '%.10g,%.10g\n', [out.t(:), out.C(:)].');
fclose(fid);

% JSON (summary + arrays; jsonencode with a manual fallback for older versions)
fid = fopen(fullfile(here, 'Emicizumab_Retout2020_estimate.json'), 'w');
try
  s.model = 'Emicizumab_Retout2020_estimate'; s.Cmax = out.Cmax; s.Tmax = out.Tmax; s.AUC = out.AUC;
  s.time_h = out.t(:).'; s.Cc_mg_per_L = out.C(:).';
  fprintf(fid, '%s', jsonencode(s));
catch
  fprintf(fid, '{"model":"Emicizumab_Retout2020_estimate","Cmax":%g,"Tmax":%g,"AUC":%g}', out.Cmax, out.Tmax, out.AUC);
end
fclose(fid);

fprintf('Cmax=%.3g mg/L  Tmax=%.3g h  AUC=%.3g mg*h/L\n', out.Cmax, out.Tmax, out.AUC);
fprintf('wrote Emicizumab_Retout2020_estimate.png, Emicizumab_Retout2020_estimate.csv, Emicizumab_Retout2020_estimate.json\n');
