function p = Emicizumab_Retout2020_estimate_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: emicizumab   source: Retout_2020 / estimate   route: oral
  p.name  = 'Emicizumab_Retout2020_estimate_params';
  p.drug  = 'emicizumab';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 10.4;                % central volume [L]
  p.CL = 0.272;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.536;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 105.0;             % dose [mg]
end
