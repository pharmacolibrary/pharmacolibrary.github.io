model Doxycycline_Zhang2019_PD_kill_rate
  "sigmoid_emax exposure-response sweep — Zhang_2019 :: kill rate (kill rate)"
  extends Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep(
    E0 = 0,      // [1]
    Emax = -1.66666666667e-05,  // [1/s; h−1 × 0.000277778]
    EC50 = 0.00078,  // [kg/m3; μg/ml × 0.001]
    gamma = 2.98,
    exposure_per_s = 0.001);   // 1 μg/ml per second
  // imax_as_negative_emax: Imax (Q323) enters SigmoidEmaxSweep as −Emax
  // defaulted: E0
  annotation(experiment(StartTime = 0, StopTime = 7.8, Interval = 0.0156),
    Documentation(info = "<html><body><h4>Doxycycline_Zhang2019_PD_kill_rate</h4><p>The steady-state exposure-response curve of Zhang H et al., <i>Frontiers in pharmacology 10:1088</i> 2019 (<a href=\"https://doi.org/10.3389/fphar.2019.01088\">doi:10.3389/fphar.2019.01088</a>) — kill rate [h−1] against doxycycline μg/ml — obtained by sweeping the driver instead of simulating a dose. Model family: sigmoid_emax.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = (library default) drug-free response (baseline)
  Emax  =       0.06 h−1      maximal effect term (E max, Q323)
  EC50  =       0.78 μg/ml    exposure at half of the maximal effect term (EC50, Q321)
  gamma =       2.98          Hill coefficient (Hill’s slope, Q325)</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep\">SigmoidEmaxSweep</a>; this model only supplies the numbers. The x axis is one μg/ml of doxycycline per second of simulated time (exposure is in kg/m3): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0   (drug-free)
  exposure = EC50 (0.78 μg/ml)  response -8.333e-06
  exposure -> infinity  response -1.667e-05</pre></body></html>"));
end Doxycycline_Zhang2019_PD_kill_rate;
