function p = Doxycycline_Zhang2019_PD_kill_rate_params()
% Doxycycline_Zhang2019_PD_kill_rate_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% doxycycline Zhang_2019::kill_rate: sigmoid_emax exposure-response sweep (response = E0 + Emax*frac). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one μg/ml per second, in SI inside (kg/m3, s). Response kill rate in h−1. Driver: doxycycline (cited_pk).
p.E0 = 0.0;
p.Emax = -1.6666666666666667e-05;
p.EC50 = 0.0007799999999999999;
p.gamma = 2.98;
p.slope = 0.0;
p.exposure_per_s = 0.001;
p.stop_time = 7.8;
p.form = 'E0 + Emax*frac';
end
