function p = Doxycycline_Toutain2025_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: doxycycline   source: Toutain_2025 / reference   route: iv_bolus
  % estimated (absent from source): F
  p.name  = 'Doxycycline_Toutain2025_reference_params';
  p.drug  = 'doxycycline';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'iv_bolus';        % 'oral' | 'iv_bolus'
  p.depot = false;             % oral -> first-order absorption depot
  p.Vc = 13.44;                % central volume [L]
  p.CL = 18.13;                % clearance [L/h]
  p.Vp = [41.65];             % peripheral volumes [L]
  p.Q  = [82.53];             % inter-compartmental clearances [L/h]
  p.ka = 0.0;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 1400.0;             % dose [mg]
end
