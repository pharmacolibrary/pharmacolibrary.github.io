function p = Doxycycline_Zhang2016_PD_kill_rate_params()
% Doxycycline_Zhang2016_PD_kill_rate_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% doxycycline Zhang_2016::kill_rate: sigmoid_emax exposure-response sweep (response = E0 + Emax*frac). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one μg/mL per second, in SI inside (kg/m3, s). Response kill rate in h−1. Driver: doxycycline (cited_pk).
p.E0 = 2.3;
p.Emax = -3.0555555555555554e-05;
p.EC50 = 0.0003199999999999999;
p.gamma = 2.11;
p.slope = 0.0;
p.exposure_per_s = 0.001;
p.stop_time = 3.2;
p.form = 'E0 + Emax*frac';
end
