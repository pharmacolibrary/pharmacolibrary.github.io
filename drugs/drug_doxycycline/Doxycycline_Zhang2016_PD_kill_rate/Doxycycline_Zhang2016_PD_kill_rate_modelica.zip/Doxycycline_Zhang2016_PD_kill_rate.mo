model Doxycycline_Zhang2016_PD_kill_rate
  "sigmoid_emax exposure-response sweep — Zhang_2016 :: kill rate (kill rate)"
  extends Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep(
    E0 = 2.3,      // [log10 CFU/mL]
    Emax = -3.05555555556e-05,  // [1/s; h−1 × 0.000277778]
    EC50 = 0.00032,  // [kg/m3; μg/mL × 0.001]
    gamma = 2.11,
    exposure_per_s = 0.001);   // 1 μg/mL per second
  // imax_as_negative_emax: Imax (Q323) enters SigmoidEmaxSweep as −Emax
  annotation(experiment(StartTime = 0, StopTime = 3.2, Interval = 0.0064),
    Documentation(info = "<html><body><h4>Doxycycline_Zhang2016_PD_kill_rate</h4><p>The steady-state exposure-response curve of Zhang N et al., <i>Frontiers in microbiology 7:653</i> 2016 (<a href=\"https://doi.org/10.3389/fmicb.2016.00653\">doi:10.3389/fmicb.2016.00653</a>) — kill rate [h−1] against doxycycline μg/mL — obtained by sweeping the driver instead of simulating a dose. Model family: sigmoid_emax.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    =        2.3 log10 CFU/mL drug-free response (baseline) (E0 (log10 CFU/mL), Q324)
  Emax  =       0.11 h−1      maximal effect term (Emax, Q323)
  EC50  =       0.32 μg/mL    exposure at half of the maximal effect term (EC50, Q321)
  gamma =       2.11          Hill coefficient (Hill’s slope, Q325)</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep\">SigmoidEmaxSweep</a>; this model only supplies the numbers. The x axis is one μg/mL of doxycycline per second of simulated time (exposure is in kg/m3): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 2.3   (drug-free)
  exposure = EC50 (0.32 μg/mL)  response 2.3
  exposure -> infinity  response 2.3</pre></body></html>"));
end Doxycycline_Zhang2016_PD_kill_rate;
