function p = Doxycycline_Zhang2016_PD_e_params()
% Doxycycline_Zhang2016_PD_e_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% doxycycline Zhang_2016::E: sigmoid_emax exposure-response sweep (response = E0 + Emax*frac). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one μg/mL per second, in SI inside (kg/m3, s). Response E in log10(CFU/mL) reduction. Driver: doxycycline (cited_pk).
p.E0 = 2.3;
p.Emax = -5.82;
p.EC50 = 0.07912;
p.gamma = 1.45;
p.slope = 0.0;
p.exposure_per_s = 0.0009999999999999998;
p.stop_time = 791.2;
p.form = 'E0 + Emax*frac';
end
