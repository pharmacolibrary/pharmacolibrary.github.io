model Doxycycline_Zhang2016_PD_e
  "sigmoid_emax exposure-response sweep — Zhang_2016 :: E (antimycoplasmal effect)"
  extends Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep(
    E0 = 2.3,      // [log10 CFU/mL]
    Emax = -5.82,  // [log10 CFU/mL]
    EC50 = 0.07912,  // [kg/m3; μg/mL × 0.001]
    gamma = 1.45,
    exposure_per_s = 0.0009999999999999998);   // 1 μg/mL per second
  // imax_as_negative_emax: Imax (Q323) enters SigmoidEmaxSweep as −Emax
  annotation(experiment(StartTime = 0, StopTime = 791.2, Interval = 1.5824));
end Doxycycline_Zhang2016_PD_e;
