function p = Doxycycline_Thompson2019_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: doxycycline   source: Thompson_2019 / reference   route: iv_bolus
  p.name  = 'Doxycycline_Thompson2019_reference_params';
  p.drug  = 'doxycycline';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'iv_bolus';        % 'oral' | 'iv_bolus'
  p.depot = false;             % oral -> first-order absorption depot
  p.Vc = 96.8;                % central volume [L]
  p.CL = 3.32;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.0;                % absorption rate [1/h]
  p.F  = 0.896;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 100.0;             % dose [mg]
end
