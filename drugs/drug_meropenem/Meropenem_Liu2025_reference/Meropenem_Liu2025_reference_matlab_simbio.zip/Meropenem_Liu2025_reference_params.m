function p = Meropenem_Liu2025_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: meropenem   source: Liu_2025 / reference   route: iv_bolus
  % estimated (absent from source): F
  p.name  = 'Meropenem_Liu2025_reference_params';
  p.drug  = 'meropenem';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'iv_bolus';        % 'oral' | 'iv_bolus'
  p.depot = false;             % oral -> first-order absorption depot
  p.Vc = 107.1;                % central volume [L]
  p.CL = 16.8;                % clearance [L/h]
  p.Vp = [424.2];             % peripheral volumes [L]
  p.Q  = [0.98];             % inter-compartmental clearances [L/h]
  p.ka = 0.0;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 3000.0;             % dose [mg]
end
