model Meropenem_Liu2025_reference
  parameter Real Cl_ref = 4.666666666666667e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.1071 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.383463,
    adminMass = 0.003,
    k12 = 2.541757443718228e-06,
    k21 = 6.417308397506418e-07
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About meropenem</h4><p>Meropenem is a carbapenem antibiotic used to treat serious bacterial infections such as appendicitis, urinary tract infections, peritonitis, respiratory infections, meningitis, and infections caused by E. coli, Pseudomonas, and Bacteroides. It is an approved medicine, appears on the WHO list of essential medicines, and is widely used in hospitals for severe infections.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q421670\">Wikidata Q421670</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>meropenem</td></tr><tr><td>population:</td><td>review reference</td></tr><tr><td>source_paper:</td><td>Liu_2025</td></tr><tr><td>measured_compound:</td><td>meropenem</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_2C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>meropenem 383.463 g/mol (drugbank)</td></tr></table><h4>Interpretation flags</h4><ul><li>built from REVIEW reference values (Liu_2025) — secondary source</li><li>volume reported by review</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Meropenem_Liu2025_reference;
