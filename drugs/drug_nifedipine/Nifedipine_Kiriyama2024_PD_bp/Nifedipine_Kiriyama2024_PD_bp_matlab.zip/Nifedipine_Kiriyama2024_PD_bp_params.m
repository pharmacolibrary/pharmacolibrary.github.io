function p = Nifedipine_Kiriyama2024_PD_bp_params()
% Nifedipine_Kiriyama2024_PD_bp_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% nifedipine Kiriyama_2024::BP: indirect_response_i exposure-response sweep (response = E0/(1 + Emax*frac)). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one ng/mL per second, in SI inside (kg/m3, s). Response BP in mmHg. Driver: nifedipine (pk_record).
p.E0 = 96.8;
p.Emax = 67.1;
p.EC50 = 8.63e-05;
p.gamma = 1.0;
p.slope = 0.0;
p.exposure_per_s = 1e-06;
p.stop_time = 130.0;
p.form = 'E0/(1 + Emax*frac)';
end
