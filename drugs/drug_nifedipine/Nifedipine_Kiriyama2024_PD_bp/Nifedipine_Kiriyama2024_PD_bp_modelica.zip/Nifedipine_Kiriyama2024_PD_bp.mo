model Nifedipine_Kiriyama2024_PD_bp
  "indirect_response_i exposure-response sweep — Kiriyama_2024 :: BP (blood pressure)"
  extends Pharmacolibrary.Pharmacodynamic.IndirectTurnoverSweep(
    E0 = 96.8,      // [mmHg]
    Emax = 67.1,  // type IV effect term
    EC50 = 8.63e-05,  // [kg/m3; ng/mL × 1e-06]
    gamma = 1,
    exposure_per_s = 1e-06);   // 1 ng/mL per second
  // emax_not_a_fraction: type I needs Imax ≤ 1 but the record has 67.1; bound as the reciprocal stimulation form (IV) the paper fitted
  // defaulted: gamma
  annotation(experiment(StartTime = 0, StopTime = 130, Interval = 0.26),
    Documentation(info = "<html><body><!-- drug-about --><h4>About nifedipine</h4><p>Nifedipine is a calcium channel blocker used to treat high blood pressure and angina. It is widely used and appears on the WHO list of essential medicines, and is also being investigated for other uses.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q39111\">Wikidata Q39111</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h4>Nifedipine_Kiriyama2024_PD_bp</h4><p>The steady-state exposure-response curve of Kiriyama A et al., <i>Pharmacology research &amp; perspectives 12(4):e1249</i> 2024 (<a href=\"https://doi.org/10.1002/prp2.1249\">doi:10.1002/prp2.1249</a>) — blood pressure [mmHg] against nifedipine ng/mL — obtained by sweeping the driver instead of simulating a dose. Model family: indirect_response_i.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    =       96.8 mmHg     drug-free response (baseline) (E0, Q324)
  Emax  =       67.1          maximal effect term (Emax,1, Q323)
  EC50  =       86.3 ng/mL    exposure at half of the maximal effect term (EC50,1, Q321)
  gamma = (library default) Hill coefficient</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.IndirectTurnoverSweep\">IndirectTurnoverSweep</a>; this model only supplies the numbers. The x axis is one ng/mL of nifedipine per second of simulated time (exposure is in kg/m3): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><p>The effect term enters as a reciprocal (steady state of <code>der(R) = Kin - Kout*(1 + Emax*frac)*R</code>), so EC50 is the exposure at half the maximal STIMULATION of turnover, not at half the response.</p><h4>What it reproduces</h4><pre>  exposure = 0         response 96.8   (drug-free)
  exposure = EC50 (86.3 ng/mL)  response 2.802
  exposure -> infinity  response 1.421</pre></body></html>"));
end Nifedipine_Kiriyama2024_PD_bp;
