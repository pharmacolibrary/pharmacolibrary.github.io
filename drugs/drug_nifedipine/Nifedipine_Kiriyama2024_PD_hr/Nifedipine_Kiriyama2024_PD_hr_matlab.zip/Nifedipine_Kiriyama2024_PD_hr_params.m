function p = Nifedipine_Kiriyama2024_PD_hr_params()
% Nifedipine_Kiriyama2024_PD_hr_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% nifedipine Kiriyama_2024::HR: sigmoid_emax exposure-response sweep (response = E0 + Emax*frac). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one ng/mL per second, in SI inside (kg/m3, s). Response HR in beat/min. Driver: nifedipine (pk_record).
p.E0 = 306.0;
p.Emax = -63.3;
p.EC50 = 0.00011499999999999999;
p.gamma = 0.931;
p.slope = 0.0;
p.exposure_per_s = 1e-06;
p.stop_time = 1200.0;
p.form = 'E0 + Emax*frac';
end
