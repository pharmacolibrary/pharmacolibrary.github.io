model Nifedipine_Kiriyama2024_PD_hr
  "sigmoid_emax exposure-response sweep — Kiriyama_2024 :: HR (heart rate)"
  extends Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep(
    E0 = 306,      // [beat/min]
    Emax = -63.3,  // [beat/min]
    EC50 = 0.000115,  // [kg/m3; ng/mL × 1e-06]
    gamma = 0.931,
    exposure_per_s = 1e-06);   // 1 ng/mL per second
  // imax_as_negative_emax: Imax (Q323) enters SigmoidEmaxSweep as −Emax
  annotation(experiment(StartTime = 0, StopTime = 1200, Interval = 2.4),
    Documentation(info = "<html><body><!-- drug-about --><h4>About nifedipine</h4><p>Nifedipine is a calcium channel blocker used to treat high blood pressure and angina. It is widely used and appears on the WHO list of essential medicines, and is also being investigated for other uses.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q39111\">Wikidata Q39111</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h4>Nifedipine_Kiriyama2024_PD_hr</h4><p>The steady-state exposure-response curve of Kiriyama A et al., <i>Pharmacology research &amp; perspectives 12(4):e1249</i> 2024 (<a href=\"https://doi.org/10.1002/prp2.1249\">doi:10.1002/prp2.1249</a>) — heart rate [beat/min] against nifedipine ng/mL — obtained by sweeping the driver instead of simulating a dose. Model family: sigmoid_emax.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    =        306 beat/min drug-free response (baseline) (E0, Q324)
  Emax  =       63.3 beat/min maximal effect term (Emax, Q323)
  EC50  =        115 ng/mL    exposure at half of the maximal effect term (EC50, Q321)
  gamma =      0.931          Hill coefficient (γ, Q325)</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep\">SigmoidEmaxSweep</a>; this model only supplies the numbers. The x axis is one ng/mL of nifedipine per second of simulated time (exposure is in kg/m3): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 306   (drug-free)
  exposure = EC50 (115 ng/mL)  response 274.4
  exposure -> infinity  response 242.7</pre></body></html>"));
end Nifedipine_Kiriyama2024_PD_hr;
