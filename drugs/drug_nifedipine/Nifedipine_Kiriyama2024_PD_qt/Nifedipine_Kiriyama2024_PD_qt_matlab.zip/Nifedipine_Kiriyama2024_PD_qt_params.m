function p = Nifedipine_Kiriyama2024_PD_qt_params()
% Nifedipine_Kiriyama2024_PD_qt_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% nifedipine Kiriyama_2024::QT: sigmoid_emax exposure-response sweep (response = E0 + Emax*frac). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one ng/mL per second, in SI inside (kg/m3, s). Response QT in msec. Driver: nifedipine (pk_record).
p.E0 = 0.07579999999999999;
p.Emax = 0.07629999999999999;
p.EC50 = 0.003227;
p.gamma = 0.857;
p.slope = 0.0;
p.exposure_per_s = 1e-06;
p.stop_time = 33000.0;
p.form = 'E0 + Emax*frac';
end
