function p = Nifedipine_Li2025_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: nifedipine   source: Li_2025 / reference   route: oral
  % estimated (absent from source): ka
  p.name  = 'Nifedipine_Li2025_reference_params';
  p.drug  = 'nifedipine';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 103.88;                % central volume [L]
  p.CL = 18.74;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.5;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 30.0;             % dose [mg]
end
