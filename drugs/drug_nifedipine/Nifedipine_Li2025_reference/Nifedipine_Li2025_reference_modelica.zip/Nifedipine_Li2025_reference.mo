model Nifedipine_Li2025_reference
  parameter Real Cl_ref = 5.205555555555556e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.10388 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.34633460000000005,
    adminMass = 3e-05,
    ka = 0.0001388888888888889,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>nifedipine</td></tr><tr><td>population:</td><td>hypertensive patients in plateau and plain areas</td></tr><tr><td>source_paper:</td><td>Li_2025</td></tr><tr><td>measured_compound:</td><td>nifedipine</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C_enteral: apparent (/F) parameterization ⇒ extravascular dosing</td></tr><tr><td>molar_masses:</td><td>nifedipine 346.335 g/mol (drugbank)</td></tr></table><p><b>Defaulted (base-class default used):</b> ka, Tlag.</p><h4>Interpretation flags</h4><ul><li>routed 'interindividual variability of CL' → Q312 (IIV) to iiv — variability estimate, not a structural parameter</li><li>unit_dimension_unknown: 'times higher than that in the plain area' (CL)</li><li>implicit units: 'CL of patients in the plateau area' → L/h (from the popPK convention: 'No unit is stated in the provided text or table captions. For total clearance (CL) in population pharmacokinetics, the s')</li><li>apparent-ness (ontology-grounded): parameterization=apparent, measured_compound=nifedipine</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Nifedipine_Li2025_reference;
