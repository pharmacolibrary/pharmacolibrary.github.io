model Nifedipine_Fu2022_reference
  parameter Real Cl_ref = 1.3758333333333335e-05 "Cl [m3/s]";
  parameter Real Vd_ref = 2.33024 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.34633460000000005,
    adminMass = 3e-05
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About nifedipine</h4><p>Nifedipine is a calcium channel blocker used to treat high blood pressure and angina. It is widely used and appears on the WHO list of essential medicines, and is also being investigated for other uses.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q39111\">Wikidata Q39111</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>nifedipine</td></tr><tr><td>population:</td><td>patients with chronic kidney disease</td></tr><tr><td>source_paper:</td><td>Fu_2022</td></tr><tr><td>measured_compound:</td><td>nifedipine</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>t0003</td></tr><tr><td>input:</td><td>PK_1C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>nifedipine 346.335 g/mol (drugbank)</td></tr></table><h4>Interpretation flags</h4><ul><li>table section iiv: 'tvV(L)' routed out of structural estimates ('IIV (%)')</li><li>table section iiv: 'tvCL(L/h)' routed out of structural estimates ('IIV (%)')</li><li>table section iiv: 'tvK0(mg/h)' routed out of structural estimates ('IIV (%)')</li><li>dropped unlinked row (NIL): 'dVdALT' — extend the ontology if this is a real PK parameter (source ['t0003:row4:col1', 't0003:row4:col2', 't0003:row4:col3', 't0003:row4:col5', 't0003:row4:col6', 't0003:row4:col7'])</li><li>dropped unlinked row (NIL): 'dCLdPTH' — extend the ontology if this is a real PK parameter (source ['t0003:row5:col1', 't0003:row5:col2', 't0003:row5:col5', 't0003:row5:col6'])</li><li>dropped unlinked row (NIL): 'dCLdAge' — extend the ontology if this is a real PK parameter (source ['t0003:row6:col1', 't0003:row6:col2', 't0003:row6:col5', 't0003:row6:col6'])</li><li>dropped unlinked row (NIL): 'dCLdHb' — extend the ontology if this is a real PK parameter (source ['t0003:row7:col1', 't0003:row7:col2', 't0003:row7:col5', 't0003:row7:col6'])</li><li>dropped unlinked row (NIL): 'stdev0' — extend the ontology if this is a real PK parameter (source ['t0003:row8:col1', 't0003:row8:col2', 't0003:row8:col3', 't0003:row8:col5', 't0003:row8:col6', 't0003:row8:col7'])</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=nifedipine</li><li>bound model equation to Q40 (Fab): F = tvV/F*{(ALT/14)^</li><li>Q40 (Fab) is equation-defined: value moved to equation-variable 'F'; equation kept verbatim</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 604800, Tolerance = 1e-9, Interval = 1));
end Nifedipine_Fu2022_reference;
