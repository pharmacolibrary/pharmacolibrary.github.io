function p = Nifedipine_Liu2022_PD_sbp_params()
% Nifedipine_Liu2022_PD_sbp_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% nifedipine Liu_2022::SBP: emax exposure-response sweep (response = E0 + Emax*frac). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one ng/ml per second, in SI inside (kg/m3, s). Response SBP in mmHg. Driver: nifedipine (cited_pk).
p.E0 = 0.0;
p.Emax = -30.0;
p.EC50 = 1.212e-05;
p.gamma = 1.0;
p.slope = 0.0;
p.exposure_per_s = 1e-06;
p.stop_time = 130.0;
p.form = 'E0 + Emax*frac';
end
