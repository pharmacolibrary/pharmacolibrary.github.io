model Nifedipine_Liu2022_PD_sbp
  "emax exposure-response sweep — Liu_2022 :: SBP (systolic blood pressure)"
  extends Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep(
    E0 = 0,      // [1]
    Emax = -30,  // [mmHg]
    EC50 = 1.212e-05,  // [kg/m3; ng/ml × 1e-06]
    gamma = 1,
    exposure_per_s = 1e-06);   // 1 ng/ml per second
  // imax_as_negative_emax: Imax (Q323) enters SigmoidEmaxSweep as −Emax
  // defaulted: E0
  // defaulted: gamma
  annotation(experiment(StartTime = 0, StopTime = 130, Interval = 0.26),
    Documentation(info = "<html><body><!-- drug-about --><h4>About nifedipine</h4><p>Nifedipine is a calcium channel blocker used to treat high blood pressure and angina. It is widely used and appears on the WHO list of essential medicines, and is also being investigated for other uses.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q39111\">Wikidata Q39111</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h4>Nifedipine_Liu2022_PD_sbp</h4><p>The steady-state exposure-response curve of Liu H et al., <i>Frontiers in pharmacology 13:970539</i> 2022 (<a href=\"https://doi.org/10.3389/fphar.2022.970539\">doi:10.3389/fphar.2022.970539</a>) — systolic blood pressure [mmHg] against nifedipine ng/ml — obtained by sweeping the driver instead of simulating a dose. Model family: emax.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = (library default) drug-free response (baseline)
  Emax  =        -30 mmHg     maximal effect term (Emax, Q323)
  EC50  =      12.12 ng/ml    exposure at half of the maximal effect term (EC50, Q321)
  gamma = (library default) Hill coefficient</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep\">SigmoidEmaxSweep</a>; this model only supplies the numbers. The x axis is one ng/ml of nifedipine per second of simulated time (exposure is in kg/m3): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0   (drug-free)
  exposure = EC50 (12.12 ng/ml)  response -15
  exposure -> infinity  response -30</pre></body></html>"));
end Nifedipine_Liu2022_PD_sbp;
