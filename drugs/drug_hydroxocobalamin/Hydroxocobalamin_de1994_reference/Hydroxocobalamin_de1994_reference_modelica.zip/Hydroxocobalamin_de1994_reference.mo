model Hydroxocobalamin_de1994_reference
  parameter Real Cl_ref = 1.611111111111111e-07 "Cl [m3/s]";
  parameter Real Vd_ref = 0.0343 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 1.3463551,
    adminMass = 2e-08
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About hydroxocobalamin</h4><p>Hydroxocobalamin, a vitamin B12 preparation, is used to treat vitamin B12 deficiency such as pernicious anemia and certain neuropathies, and also serves as an antidote for poisoning. It is an approved medicine included on the WHO essential medicines list, and an EMA-authorised product is available in the European Union for treating poisoning.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q73972\">Wikidata Q73972</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>hydroxocobalamin</td></tr><tr><td>population:</td><td>conscious dogs</td></tr><tr><td>source_paper:</td><td>de_1994</td></tr><tr><td>measured_compound:</td><td>hydroxocobalamin</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>hydroxocobalamin 1346.36 g/mol (drugbank)</td></tr></table><h4>Interpretation flags</h4><ul><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=hydroxocobalamin</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 133200, Tolerance = 1e-9, Interval = 1));
end Hydroxocobalamin_de1994_reference;
