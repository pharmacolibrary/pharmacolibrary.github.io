model Rivastigmine_Gobburu2001_reference
  parameter Real Cl_ref = 3.3333333333333335e-05 "Cl [m3/s]";
  parameter Real Vd_ref = 0.23600000000000002 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.2503367,
    adminMass = 9e-06,
    ka = 0.0001388888888888889,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About rivastigmine</h4><p>Rivastigmine is an anticholinesterase medicine used to treat dementia, including Alzheimer's disease and Parkinson's disease dementia. It is approved and widely used, with several products authorised in the European Union for these conditions.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q411887\">Wikidata Q411887</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>rivastigmine</td></tr><tr><td>population:</td><td>patients with Alzheimer's disease</td></tr><tr><td>source_paper:</td><td>Gobburu_2001</td></tr><tr><td>measured_compound:</td><td>rivastigmine</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C_enteral: apparent (/F) parameterization ⇒ extravascular dosing</td></tr><tr><td>molar_masses:</td><td>rivastigmine 250.337 g/mol (drugbank)</td></tr></table><p><b>Defaulted (base-class default used):</b> ka, Tlag.</p><h4>Interpretation flags</h4><ul><li>dropped PD-category row 'equilibration half-life' → Q326 (ke0, category G11) — pharmacodynamic parameters belong to scholarpd, not the PK model (source ['Gobburu_2001:abstract', 'Gobburu_2001:abstract'])</li><li>metabolite volume: 'volume of distribution' Q63→Q61 for ZNS 114-666 (NAP 226-90) — it is 1-compartment, so its central volume is its only volume</li><li>apparent-ness (ontology-grounded): parameterization=apparent, measured_compound=rivastigmine</li><li>held at status:extracted — NIL link or unit issue (mismatch/unknown/normalisation-failed) present</li><li>topology: transfer parameter unlinked (Q100) — add Kfm/formation-rate/rate-constant to the ontology; routing to review</li><li>template fit: none — noncompartmental model — not a compartmental parent–metabolite model</li><li>status held at route_to_review — not promoted</li><li>row roles (LLM): model_class=noncompartmental; 6/6 row label(s) assigned, 4 linked by role; re-tagged rivastigmine→parent ×3, rivastigmine→ZNS 114-666 (NAP 226-90) ×4</li><li>molar mass: no plausible PubChem entry for 'ZNS 114-666 (NAP 226-90)' ('ZNS 114-666 (NAP 226-90)') — left in mass units</li><li>molar mass: none found for 'ZNS 114-666 (NAP 226-90)' — its concentrations stay mass-only</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li><li>skipped review gap-fill of V2: primary is PARENT_METABOLITE (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is PARENT_METABOLITE (peripheral family needs ≥2C)</li><li>engineer: parent → metabolite not buildable on PK_3M_9C (None) — the measured compound's 1-compartment model instead</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Rivastigmine_Gobburu2001_reference;
