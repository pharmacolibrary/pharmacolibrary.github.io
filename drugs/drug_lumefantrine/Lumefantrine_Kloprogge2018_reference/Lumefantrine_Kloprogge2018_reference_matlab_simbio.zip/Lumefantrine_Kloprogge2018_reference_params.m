function p = Lumefantrine_Kloprogge2018_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: lumefantrine   source: Kloprogge_2018 / reference   route: oral
  p.name  = 'Lumefantrine_Kloprogge2018_reference_params';
  p.drug  = 'lumefantrine';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 11.2;                % central volume [L]
  p.CL = 1.35;                % clearance [L/h]
  p.Vp = [59.0];             % peripheral volumes [L]
  p.Q  = [0.344];             % inter-compartmental clearances [L/h]
  p.ka = 0.0386;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 120.0;             % dose [mg]
end
