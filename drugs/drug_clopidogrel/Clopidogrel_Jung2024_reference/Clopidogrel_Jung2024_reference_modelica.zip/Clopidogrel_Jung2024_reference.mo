// parent + metabolites (clopidogrel H4, clopidogrel carboxylic acid): PK_3M_3C — hepatic compartment; parent 2 + hepatic, metabolites [1, 2]
model Clopidogrel_Jung2024_reference
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_3M_3C(
    Vd1 = 1.46392,
    Vd2 = 1.46392,
    Vd3 = 2.82398,
    q12 = 0.0002349166666666667,
    q21 = 0.0002349166666666667,
    q1_m11 = 0.0003085760000000001,
    q1_m21 = 0.0021600320000000005,
    CL1 = 0.00010285866666666669,
    Vd1m1 = 0.05145,
    CLm1 = 2.0625e-05,
    Vd1m2 = 0.01734,
    CLm2 = 2.0133333333333333e-06,
    Vd2m2 = 0.05189,
    qm21_m22 = 0.00016331388888888887,
    qm22_m21 = 0.00016331388888888887,
    MW = 0.321822,
    MW_m1 = 0.35583,
    MW_m2 = 0.3078,
    F = 1.0,
    ka = 0.0054555555555555555,
    Tlag = 705.6,
    adminDuration = 600,
    adminCount = 1,
    adminMass = 7.5e-05
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About clopidogrel</h4><p>Clopidogrel is an antiplatelet medicine used to lower the risk of heart attack, stroke, and other clot-related cardiovascular problems in people at high risk. It is widely used and remains authorised in the European Union, where several approved products are marketed for conditions such as acute coronary syndrome, myocardial infarction, and stroke.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q410237\">Wikidata Q410237</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>clopidogrel</td></tr><tr><td>population:</td><td>healthy male participants</td></tr><tr><td>source_paper:</td><td>Jung_2024</td></tr><tr><td>measured_compound:</td><td>clopidogrel</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>general_linear</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>psp413053-tbl-0002</td></tr><tr><td>input:</td><td>PK_3M_3C: absorption rate constant reported; hepatic volume not reported separately — set equal to the central volume (as Jung_2024 fixes Vc = VH); formation of clopidogrel H4: 0.120 = 0.12 of CL (the paper's fm scheme); formation of clopidogrel carboxylic acid: 0.84 = 0.84 of CL (the paper's fm scheme); F = 1: first pass is the hepatic compartment (absorption complete, no bioavailability reported); dose 75 mg (paper)</td></tr><tr><td>molar_masses:</td><td>clopidogrel 321.822 g/mol (drugbank); clopidogrel H4 355.83 g/mol (paper); clopidogrel carboxylic acid 307.8 g/mol (paper)</td></tr></table><h4>Interpretation flags</h4><ul><li>dropped value-less row: 'Cor(Vc, CLc)' (captured trailing unit 'Vc, CLc' for child rows)</li><li>linked 'Q c (L/h)' → Q369 (QH): hepatic ⇄ central exchange of a hepatic-compartment model, not the peripheral Q</li><li>dropped duplicate Q30 ('Q m2 (L/h)', value '4.476') — already have one for this compound</li><li>dropped PD-category row 'K in' → Q327 (kin, category G11) — pharmacodynamic parameters belong to scholarpd, not the PK model (source ['psp413053-tbl-0002:row27:col1', 'psp413053-tbl-0002:row27:col2'])</li><li>dropped PD-category row 'K out (h−1)' → Q328 (kout, category G11) — pharmacodynamic parameters belong to scholarpd, not the PK model (source ['psp413053-tbl-0002:row28:col1'])</li><li>dropped PD-category row 'E max' → Q320 (Emax, category G11) — pharmacodynamic parameters belong to scholarpd, not the PK model (source ['psp413053-tbl-0002:row29:col1', 'psp413053-tbl-0002:row29:col2'])</li><li>dropped PD-category row 'EC50 (ng/mL)' → Q321 (EC50, category G11) — pharmacodynamic parameters belong to scholarpd, not the PK model (source ['psp413053-tbl-0002:row30:col1'])</li><li>dropped PD-category row 'Hill' → Q325 (Hill, category G11) — pharmacodynamic parameters belong to scholarpd, not the PK model (source ['psp413053-tbl-0002:row31:col1'])</li><li>metabolite volume: 'V m1 (L)' Q63→Q61 for clopidogrel H4 — it is 1-compartment, so its central volume is its only volume</li><li>apparent-by-design (ADVISORY, codes unchanged): extravascular dosing with no identifiable F, so these reported disposition parameters are likely apparent unless the model puts first-pass in its structure — Q63 (V c (=VH) (L)); Q64 (V p (L)); Q22 (CLc (L/h)); Q30 (Q p (L/h)); Q61 (V m1 (L)); Q22 (CLm1 (L/h)); Q63 (V m2 (L)); Q64 (V p2 (L))</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=clopidogrel</li><li>topology: 2 first-order transfer(s) across 4 compounds → general_linear</li><li>template fit: PK_3M_3C — hepatic compartment; parent 2 + hepatic, metabolites [1, 2] (site hepatic: 'the record carries a hepatic compartment parameter (Q369)')</li><li>row roles: 2 per-group rows of clopidogrel H4 covariate_effect but 0 reference group(s) — kept as printed</li><li>row roles: 2 per-group rows of clopidogrel carboxylic acid covariate_effect but 0 reference group(s) — kept as printed</li><li>row roles (LLM): model_class=compartmental; 29/29 row label(s) assigned, 22 linked by role; re-tagged parent→clopidogrel carboxylic acid ×12, parent→clopidogrel H4 ×7, parent→PRU ×8</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Clopidogrel_Jung2024_reference;
