#!/usr/bin/env python3
"""Simulate Clopidogrel_Jung2024_reference.sbml (0..24.0 h) — a parent and its metabolites — with Tellurium/
libRoadRunner; writes Clopidogrel_Jung2024_reference.csv, Clopidogrel_Jung2024_reference.json and Clopidogrel_Jung2024_reference.png next to this script."""
import json
import os

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import tellurium as te

BASE = os.path.join(os.path.dirname(os.path.abspath(__file__)), "Clopidogrel_Jung2024_reference")
OUT = {'C_central': 'clopidogrel', 'C_M1': 'clopidogrel H4', 'C_M2': 'clopidogrel carboxylic acid'}                        # output -> molecule
r = te.loadSBMLModel(BASE + ".sbml")
r.integrator.relative_tolerance = 1e-8
r.integrator.absolute_tolerance = 1e-12
res = r.simulate(0, 24.0, 2001, ["time"] + list(OUT))
t = [float(x) for x in res[:, 0]]
cols = {o: [float(x) for x in res[:, i + 1]] for i, o in enumerate(OUT)}

with open(BASE + ".csv", "w") as f:
    f.write("time_h," + ",".join(o + "_mg_per_L" for o in OUT) + "\n")
    for k, ti in enumerate(t):
        f.write("%r," % ti + ",".join("%r" % cols[o][k] for o in OUT) + "\n")
with open(BASE + ".json", "w") as f:
    json.dump({"model": "Clopidogrel_Jung2024_reference", "stop_time_h": 24.0, "labels": OUT, "time_h": t,
               **{o + "_mg_per_L": cols[o] for o in OUT}}, f, indent=2)

plt.figure()
for o in OUT:
    plt.semilogy(t, [max(c, 1e-12) for c in cols[o]], linewidth=1.5, label=f"{OUT[o]} ({o})")
plt.xlabel("time [h]"); plt.ylabel("concentration [mg/L]"); plt.legend()
plt.title("Clopidogrel_Jung2024_reference"); plt.grid(True, alpha=0.3); plt.tight_layout()
plt.savefig(BASE + ".png", dpi=150)
print("wrote %s.csv, %s.json, %s.png" % (BASE, BASE, BASE))
