function p = Clopidogrel_Lee2012_PD_platelet_aggregation_params()
% Clopidogrel_Lee2012_PD_platelet_aggregation_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% clopidogrel Lee_2012::platelet_aggregation: indirect_response_i exposure-response sweep (response = E0*(1 - Emax*frac)). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one ng/mL per second, in SI inside (kg/m3, s). Response platelet aggregation in %. Driver: SR26334 (pk_record).
p.E0 = 0.667;
p.Emax = 0.292;
p.EC50 = 6.2899999999999996e-09;
p.gamma = 1.0;
p.slope = 0.0;
p.exposure_per_s = 1e-06;
p.stop_time = 0.063;
p.form = 'E0*(1 - Emax*frac)';
end
