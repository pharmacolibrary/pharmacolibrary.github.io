model Clopidogrel_Koh2025_PD_txb2
  "indirect_response_ii exposure-response sweep — Koh_2025 :: TXB2 (thromboxane B2)"
  extends Pharmacolibrary.Interfaces.PartialExposureResponseSweep(
    E0 = 2.639999999999999e-05,      // [kg/m3; μg/L × 1e-06]
    Emax = 1.0,  // type II effect term
    EC50 = 3.5999999999999996,  // [mol/m3; mol/L × 1000]
    gamma = 1.0,
    exposure_per_s = 999.9999999999999);   // 1 mol/L per second
equation
  response = E0/(1 - Emax*frac);   // steady state, indirect response type II
  annotation(experiment(StartTime = 0, StopTime = 0.036, Interval = 7.2e-05));
end Clopidogrel_Koh2025_PD_txb2;
