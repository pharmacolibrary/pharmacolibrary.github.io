model Fluoxetine_Burlot2026_reference
  parameter Real Cl_ref = 1.7555555555555556e-05 "Cl [m3/s]";
  parameter Real Vd_ref = 0.855 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.3093261,
    adminMass = 1e-05
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About fluoxetine</h4><p>Fluoxetine is a selective serotonin reuptake inhibitor antidepressant used for conditions such as depression and mood disorders, anxiety and panic disorders, obsessive-compulsive disorder, post-traumatic stress disorder, and bulimia nervosa. It is widely used in human medicine and is also an approved veterinary drug; it appears on the WHO list of essential medicines.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q422244\">Wikidata Q422244</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>fluoxetine</td></tr><tr><td>population:</td><td>review reference</td></tr><tr><td>source_paper:</td><td>Burlot_2026</td></tr><tr><td>measured_compound:</td><td>fluoxetine</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>fluoxetine 309.326 g/mol (drugbank)</td></tr></table><h4>Interpretation flags</h4><ul><li>built from REVIEW reference values (Burlot_2026) — secondary source</li><li>volume reported by review</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 169200, Tolerance = 1e-9, Interval = 1));
end Fluoxetine_Burlot2026_reference;
