function p = Baclofen_Imbert2015_PD_ocds_params()
% Baclofen_Imbert2015_PD_ocds_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% baclofen Imbert_2015::OCDS: emax exposure-response sweep (response = E0 + Emax*frac). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one mg/l per second, in SI inside (kg/m3, s). Response OCDS in its own unit. Driver: baclofen (cited_pk).
p.E0 = 0.0;
p.Emax = -0.72;
p.EC50 = 0.012599999999999997;
p.gamma = 1.0;
p.slope = 0.0;
p.exposure_per_s = 0.001;
p.stop_time = 130.0;
p.form = 'E0 + Emax*frac';
end
