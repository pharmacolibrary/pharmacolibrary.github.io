model Baclofen_Vourch2019_reference
  parameter Real Cl_ref = 3.75e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.105 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.213661,
    adminMass = 5e-05,
    ka = 0.0006111111111111112,
    Tlag = 1332.0
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About baclofen</h4><p>Baclofen is a centrally acting muscle relaxant used for spasticity and related neurological conditions such as multiple sclerosis, cerebral palsy, and spinal cord injury. It is an approved medicine in widespread use, though it carries a boxed warning.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q413717\">Wikidata Q413717</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>baclofen</td></tr><tr><td>population:</td><td>ICU patients with unhealthy alcohol use</td></tr><tr><td>source_paper:</td><td>Vourch_2019</td></tr><tr><td>measured_compound:</td><td>baclofen</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>baclofen 213.661 g/mol (drugbank)</td></tr></table><h4>Interpretation flags</h4><ul><li>dropped value-less row: 'renal failure significantly increased baclofen exposure'</li><li>dropped value-less row: 'renal failure significantly decreased baclofen clearance'</li><li>dropped value-less row: 'no difference was found regarding baclofen exposure'</li><li>dropped value-less row: 'plasma peak concentration'</li><li>apparent-ness (ontology-grounded): parameterization=apparent, measured_compound=baclofen</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 104400, Tolerance = 1e-9, Interval = 1));
end Baclofen_Vourch2019_reference;
