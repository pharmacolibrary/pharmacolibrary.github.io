model Baclofen_Simon2018_reference
  parameter Real Cl_ref = 3.222222222222222e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.0728 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.213661,
    adminMass = 5e-05,
    ka = 0.0004555555555555555,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About baclofen</h4><p>Baclofen is a centrally acting muscle relaxant used for spasticity and related neurological conditions such as multiple sclerosis, cerebral palsy, and spinal cord injury. It is an approved medicine in widespread use, though it carries a boxed warning.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q413717\">Wikidata Q413717</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>baclofen</td></tr><tr><td>population:</td><td>adults with alcohol use disorder</td></tr><tr><td>source_paper:</td><td>Simon_2018</td></tr><tr><td>measured_compound:</td><td>baclofen</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>T2</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>baclofen 213.661 g/mol (drugbank)</td></tr></table><p><b>Defaulted (base-class default used):</b> Tlag.</p><h4>Interpretation flags</h4><ul><li>table section iiv: 'ω(CL/F)' routed out of structural estimates ('BETWEEN SUBJECT VARIABILITY')</li><li>table section iiv: 'ω(CL/F)' routed out of structural estimates ('BETWEEN SUBJECT VARIABILITY')</li><li>table section iiv: 'ω(CL/F)' routed out of structural estimates ('BETWEEN SUBJECT VARIABILITY')</li><li>table section iiv: 'ω(Vd/F)' routed out of structural estimates ('BETWEEN SUBJECT VARIABILITY')</li><li>table section iiv: 'ω(Vd/F)' routed out of structural estimates ('BETWEEN SUBJECT VARIABILITY')</li><li>table section iiv: 'ω(Vd/F)' routed out of structural estimates ('BETWEEN SUBJECT VARIABILITY')</li><li>table section iiv: 'ω(Ka)' routed out of structural estimates ('BETWEEN SUBJECT VARIABILITY')</li><li>table section iiv: 'ω(Ka)' routed out of structural estimates ('BETWEEN SUBJECT VARIABILITY')</li><li>table section iiv: 'ω(Ka)' routed out of structural estimates ('BETWEEN SUBJECT VARIABILITY')</li><li>table section residual_error: 'σ exponential' routed out of structural estimates ('RESIDUAL VARIABILITY')</li><li>table section residual_error: 'σ exponential' routed out of structural estimates ('RESIDUAL VARIABILITY')</li><li>table section residual_error: 'σ exponential' routed out of structural estimates ('RESIDUAL VARIABILITY')</li><li>implicit units: 'Ka (1/h)' → 1/h (from the paper text: &quot;The abstract explicitly states: 'absorption constant (Ka) 1.64 1/h (1.34–2)'.&quot;)</li><li>apparent-ness (ontology-grounded): parameterization=apparent, measured_compound=baclofen</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Baclofen_Simon2018_reference;
