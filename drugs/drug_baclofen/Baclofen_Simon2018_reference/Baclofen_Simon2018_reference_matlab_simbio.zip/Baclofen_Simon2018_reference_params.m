function p = Baclofen_Simon2018_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: baclofen   source: Simon_2018 / reference   route: oral
  p.name  = 'Baclofen_Simon2018_reference_params';
  p.drug  = 'baclofen';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 72.8;                % central volume [L]
  p.CL = 11.6;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 1.64;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 50.0;             % dose [mg]
end
