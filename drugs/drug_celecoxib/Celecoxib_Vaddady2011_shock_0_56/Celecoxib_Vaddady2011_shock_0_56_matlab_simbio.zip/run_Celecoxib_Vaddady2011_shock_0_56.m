% Run (SimBiology): build model + dose, simulate 0..336.0 h, plot.
p = Celecoxib_Vaddady2011_shock_0_56_params();
[model, dose, variant] = build_sb_pk(p);
sd = simulate_sb(model, variant, dose, 336.0);
