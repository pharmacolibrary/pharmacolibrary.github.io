model Celecoxib_Vaddady2011_shock_43
  parameter Real Cl_ref = 5.833333333333334e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.0228 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    adminMass = 3.5e-05
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About celecoxib</h4><p>Celecoxib is a non-steroidal anti-inflammatory drug (a COX-2 inhibitor) used to treat pain and inflammatory joint conditions such as osteoarthritis, rheumatoid arthritis, and ankylosing spondylitis, and also familial adenomatous polyposis. It is an approved medicine, widely used for these conditions, though it carries a boxed warning and one EU product has been withdrawn.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q408801\">Wikidata Q408801</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>celecoxib</td></tr><tr><td>population:</td><td>pigs in hemorrhagic shock and normotensive pigs</td></tr><tr><td>source_paper:</td><td>Vaddady_2011</td></tr><tr><td>measured_compound:</td><td>THC and celecoxib</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>tab_2</td></tr><tr><td>input:</td><td>PK_1C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>celecoxib 381.372 g/mol (drugbank)</td></tr></table><h4>Interpretation flags</h4><ul><li>unit_dimension_unknown: 'n 5 3' (Vss)</li><li>unit_dimension_unknown: 'n 5 3' (t1/2z)</li><li>salvaged Q22 ('clearance'=21) from results prose — parameter table was unreadable</li><li>implicit units: 'V ss' → L (from the popPK convention: 'The paper defines Vss as the volume of distribution at steady state. In population PK, volumes of distribution are conve')</li><li>implicit units: 'T 1/2' → h (from the popPK convention: 'The paper defines T1/2 as the terminal half-life. In population PK, half-lives are conventionally expressed in hours (h)')</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=THC and celecoxib</li><li>held at status:extracted — NIL link or unit issue (mismatch/unknown/normalisation-failed) present</li><li>status held at route_to_review — not promoted</li><li>population split: 'shock 4 (n 5 3)' subgroup of Vaddady_2011 (paper reports 4 populations: normo 1 (n 5 6), shock 0.5 (n 5 6), shock 1 (n 5 10), shock 4 (n 5 3))</li><li>molar mass: no plausible PubChem entry for 'THC and celecoxib' ('THC and celecoxib') — left in mass units</li><li>molar mass: none found for 'THC and celecoxib' — its concentrations stay mass-only</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 691200, Tolerance = 1e-9, Interval = 1));
end Celecoxib_Vaddady2011_shock_43;
