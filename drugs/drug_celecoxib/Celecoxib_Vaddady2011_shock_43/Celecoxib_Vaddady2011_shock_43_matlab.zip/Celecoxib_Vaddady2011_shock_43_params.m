function p = Celecoxib_Vaddady2011_shock_43_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: celecoxib   source: Vaddady_2011 / shock_43   route: iv_bolus
  % estimated (absent from source): F
  % Vc is the record's Vss — no central volume was reported; 1-compartment reading
  p.name  = 'Celecoxib_Vaddady2011_shock_43_params';
  p.drug  = 'celecoxib';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'iv_bolus';        % 'oral' | 'iv_bolus'
  p.depot = false;             % oral -> first-order absorption depot
  p.Vc = 22.8;                % central volume [L]
  p.CL = 21.0;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.0;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 35.0;             % dose [mg]
end
