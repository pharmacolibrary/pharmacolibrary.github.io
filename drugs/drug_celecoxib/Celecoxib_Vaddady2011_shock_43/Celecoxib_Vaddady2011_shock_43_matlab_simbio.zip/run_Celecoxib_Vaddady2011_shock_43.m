% Run (SimBiology): build model + dose, simulate 0..192.0 h, plot.
p = Celecoxib_Vaddady2011_shock_43_params();
[model, dose, variant] = build_sb_pk(p);
sd = simulate_sb(model, variant, dose, 192.0);
