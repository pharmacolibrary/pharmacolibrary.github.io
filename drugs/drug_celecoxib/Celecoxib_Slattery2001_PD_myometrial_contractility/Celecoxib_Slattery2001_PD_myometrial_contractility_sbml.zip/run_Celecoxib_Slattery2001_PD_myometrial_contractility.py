#!/usr/bin/env python3
"""Sweep Celecoxib_Slattery2001_PD_myometrial_contractility.sbml with Tellurium/libRoadRunner: response against exposure.

Simulated time is the swept exposure (exposure = exposure_per_s * time), so the x axis of the
plot is `exposure`, not time. Writes Celecoxib_Slattery2001_PD_myometrial_contractility.csv/.json/.png next to this script.
"""
import json, os
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import tellurium as te

BASE = os.path.join(os.path.dirname(os.path.abspath(__file__)), "Celecoxib_Slattery2001_PD_myometrial_contractility")
r = te.loadSBMLModel(BASE + ".sbml")
res = r.simulate(0, 62.0, 500, ["time", "exposure", "response"])
x = [float(v) for v in res[:, 1]]; y = [float(v) for v in res[:, 2]]
with open(BASE + ".csv", "w") as f:
    f.write("exposure_si,response\n")
    for xi, yi in zip(x, y):
        f.write("%r,%r\n" % (xi, yi))
with open(BASE + ".json", "w") as f:
    json.dump({"model": "Celecoxib_Slattery2001_PD_myometrial_contractility", "exposure_si": x, "response": y}, f, indent=2)
plt.figure(); plt.plot(x, y, linewidth=1.5)
plt.xlabel("exposure [Ϫlog 10 mol/L]"); plt.ylabel("response [%]")
plt.title("Celecoxib_Slattery2001_PD_myometrial_contractility"); plt.grid(True, alpha=0.3); plt.tight_layout(); plt.savefig(BASE + ".png", dpi=150)
print("wrote %s.csv, %s.json, %s.png" % (BASE, BASE, BASE))
