model Celecoxib_Slattery2001_PD_myometrial_contractility
  "sigmoid_emax exposure-response sweep — Slattery_2001 :: myometrial contractility (myometrial contractility)"
  extends Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep(
    E0 = 0,      // [1]
    Emax = -0.6908,  // [1; % × 0.01]
    EC50 = 6.15,  // [Ϫlog 10 mol/L]
    gamma = 1,
    exposure_per_s = 1);   // 1 Ϫlog 10 mol/L per second
  // imax_as_negative_emax: Imax (Q323) enters SigmoidEmaxSweep as −Emax
  // exposure_unit_unresolved: 'Ϫlog 10 mol/L' — the x axis is in the paper's unit, not SI
  // defaulted: E0
  // defaulted: gamma
  annotation(experiment(StartTime = 0, StopTime = 62, Interval = 0.124),
    Documentation(info = "<html><body><!-- drug-about --><h4>About celecoxib</h4><p>Celecoxib is a non-steroidal anti-inflammatory drug (a COX-2 inhibitor) used to treat pain and inflammatory joint conditions such as osteoarthritis, rheumatoid arthritis, and ankylosing spondylitis, and also familial adenomatous polyposis. It is an approved medicine, widely used for these conditions, though it carries a boxed warning and one EU product has been withdrawn.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q408801\">Wikidata Q408801</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h4>Celecoxib_Slattery2001_PD_myometrial_contractility</h4><p>The steady-state exposure-response curve of Slattery MM et al., <i>Obstetrics and gynecology 98(4):563–569</i> 2001 (<a href=\"https://doi.org/10.1016/s0029-7844(01)01522-8\">doi:10.1016/s0029-7844(01)01522-8</a>) — myometrial contractility [%] against celecoxib Ϫlog 10 mol/L — obtained by sweeping the driver instead of simulating a dose. Model family: sigmoid_emax.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = (library default) drug-free response (baseline)
  Emax  =      69.08 %        maximal effect term (mean maximal inhibition, Q323)
  EC50  =       6.15 Ϫlog 10 mol/L exposure at half of the maximal effect term (EC 50, Q322)
  gamma = (library default) Hill coefficient</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep\">SigmoidEmaxSweep</a>; this model only supplies the numbers. The x axis is one Ϫlog 10 mol/L of celecoxib per second of simulated time: there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0   (drug-free)
  exposure = EC50 (6.15 Ϫlog 10 mol/L)  response -0.3454
  exposure -> infinity  response -0.6908</pre></body></html>"));
end Celecoxib_Slattery2001_PD_myometrial_contractility;
