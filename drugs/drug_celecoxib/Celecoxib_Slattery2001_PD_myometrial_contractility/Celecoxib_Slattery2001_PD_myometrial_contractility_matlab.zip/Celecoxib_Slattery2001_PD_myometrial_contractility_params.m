function p = Celecoxib_Slattery2001_PD_myometrial_contractility_params()
% Celecoxib_Slattery2001_PD_myometrial_contractility_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% celecoxib Slattery_2001::myometrial_contractility: sigmoid_emax exposure-response sweep (response = E0 + Emax*frac). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one Ϫlog 10 mol/L per second, in SI inside (kg/m3, s). Response myometrial contractility in %. Driver: celecoxib (cited_pk).
p.E0 = 0.0;
p.Emax = -0.6908;
p.EC50 = 6.15;
p.gamma = 1.0;
p.slope = 0.0;
p.exposure_per_s = 1.0;
p.stop_time = 62.0;
p.form = 'E0 + Emax*frac';
end
