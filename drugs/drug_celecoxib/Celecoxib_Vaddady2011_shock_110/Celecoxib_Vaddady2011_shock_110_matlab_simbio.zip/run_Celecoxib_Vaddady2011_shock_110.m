% Run (SimBiology): build model + dose, simulate 0..24.0 h, plot.
p = Celecoxib_Vaddady2011_shock_110_params();
[model, dose, variant] = build_sb_pk(p);
sd = simulate_sb(model, variant, dose, 24.0);
