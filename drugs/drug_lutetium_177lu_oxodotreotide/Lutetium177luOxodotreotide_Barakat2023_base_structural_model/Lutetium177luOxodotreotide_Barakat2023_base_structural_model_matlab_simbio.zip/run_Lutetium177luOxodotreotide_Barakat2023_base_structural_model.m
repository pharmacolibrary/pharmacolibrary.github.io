% Run (SimBiology): build model + dose, simulate 0..120.0 h, plot.
p = Lutetium177luOxodotreotide_Barakat2023_base_structural_model_params();
[model, dose, variant] = build_sb_pk(p);
sd = simulate_sb(model, variant, dose, 120.0);
