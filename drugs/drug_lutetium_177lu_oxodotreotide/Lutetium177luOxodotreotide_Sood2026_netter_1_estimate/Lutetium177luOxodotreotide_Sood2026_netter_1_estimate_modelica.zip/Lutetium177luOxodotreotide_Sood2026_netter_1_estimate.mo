model Lutetium177luOxodotreotide_Sood2026_netter_1_estimate
  parameter Real Cl_ref = 1.3750000000000002e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.02159 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    adminMass = 1e-05,
    k12 = 6.149966548299109e-05,
    k21 = 6.568279880176987e-06
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About lutetium_177lu_oxodotreotide</h4><p>Lutetium (177Lu) oxodotreotide is a therapeutic radiopharmaceutical used to treat neuroendocrine tumours. It is authorised in the European Union, where it is used in specialised settings for this indication.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q27273888\">Wikidata Q27273888</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>lutetium_177lu_oxodotreotide</td></tr><tr><td>population:</td><td>adolescent and adult patients with somatostatin receptor–positive gastroenteropancreatic neuroendocrine tumors</td></tr><tr><td>source_paper:</td><td>Sood_2026</td></tr><tr><td>measured_compound:</td><td>lutetium_177lu_oxodotreotide</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>tbl5</td></tr><tr><td>input:</td><td>PK_2C: IV (no input phase)</td></tr></table><h4>Interpretation flags</h4><ul><li>routed 'Cor CL ∼ Vc' → Q314 (omega_cov) to covariance — variability estimate, not a structural parameter</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=lutetium_177lu_oxodotreotide</li><li>population split: 'netter-1 estimate' subgroup of Sood_2026 (paper reports 3 populations: estimate with study effect, netter-1 estimate, netter-p estimate)</li><li>molar mass: none found for 'lutetium_177lu_oxodotreotide' — its concentrations stay mass-only</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Lutetium177luOxodotreotide_Sood2026_netter_1_estimate;
