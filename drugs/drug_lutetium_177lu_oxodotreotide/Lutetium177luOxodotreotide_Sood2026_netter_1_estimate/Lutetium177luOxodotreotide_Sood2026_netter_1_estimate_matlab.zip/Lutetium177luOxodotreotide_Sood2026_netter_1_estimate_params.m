function p = Lutetium177luOxodotreotide_Sood2026_netter_1_estimate_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: lutetium_177lu_oxodotreotide   source: Sood_2026 / netter_1_estimate   route: iv_bolus
  % estimated (absent from source): F, dose
  p.name  = 'Lutetium177luOxodotreotide_Sood2026_netter_1_estimate_params';
  p.drug  = 'lutetium_177lu_oxodotreotide';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'iv_bolus';        % 'oral' | 'iv_bolus'
  p.depot = false;             % oral -> first-order absorption depot
  p.Vc = 21.59;                % central volume [L]
  p.CL = 4.95;                % clearance [L/h]
  p.Vp = [202.15];             % peripheral volumes [L]
  p.Q  = [4.78];             % inter-compartmental clearances [L/h]
  p.ka = 0.0;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 10.0;             % dose [mg]
end
