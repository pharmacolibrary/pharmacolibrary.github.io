model Lamotrigine_CastelBranco2005_PD_anticonvulsant_profile_again
  "sigmoid_emax exposure-response sweep — Castel-Branco_2005 :: anticonvulsant profile against maximal electroshock seizure stimulation (anticonvulsant profile against maximal electroshock seizure stimulation)"
  extends Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep(
    E0 = 0,      // [1]
    Emax = 1,  // [1; % × 0.01]
    EC50 = 0.00344,  // [kg/m3; mg/L × 0.001]
    gamma = 8.64,
    exposure_per_s = 0.001);   // 1 mg/L per second
  // defaulted: E0
  annotation(experiment(StartTime = 0, StopTime = 35, Interval = 0.07),
    Documentation(info = "<html><body><!-- drug-about --><h4>About lamotrigine</h4><p>Lamotrigine is an anticonvulsant used to treat epilepsy and bipolar disorder, and has also been used for other neurological and psychiatric conditions. It is widely used and is included on the WHO list of essential medicines.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q410346\">Wikidata Q410346</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h4>Lamotrigine_CastelBranco2005_PD_anticonvulsant_profile_again</h4><p>The steady-state exposure-response curve of Castel-Branco MM et al., <i>Fundamental &amp; clinical pharmacology 19(6):669–675</i> 2005 (<a href=\"https://doi.org/10.1111/j.1472-8206.2005.00380.x\">doi:10.1111/j.1472-8206.2005.00380.x</a>) — anticonvulsant profile against maximal electroshock seizure stimulation against lamotrigine mg/L — obtained by sweeping the driver instead of simulating a dose. Model family: sigmoid_emax.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = (library default) drug-free response (baseline)
  Emax  =        100 %        maximal effect term (Emax, Q320)
  EC50  =       3.44 mg/L     exposure at half of the maximal effect term (EC50, Q321)
  gamma =       8.64          Hill coefficient (gamma, Q325)</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep\">SigmoidEmaxSweep</a>; this model only supplies the numbers. The x axis is one mg/L of lamotrigine per second of simulated time (exposure is in kg/m3): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0   (drug-free)
  exposure = EC50 (3.44 mg/L)  response 0.5
  exposure -> infinity  response 1</pre></body></html>"));
end Lamotrigine_CastelBranco2005_PD_anticonvulsant_profile_again;
