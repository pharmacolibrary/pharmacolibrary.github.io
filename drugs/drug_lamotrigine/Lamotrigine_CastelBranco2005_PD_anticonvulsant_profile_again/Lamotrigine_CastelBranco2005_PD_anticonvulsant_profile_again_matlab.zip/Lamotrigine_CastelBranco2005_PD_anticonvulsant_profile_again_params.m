function p = Lamotrigine_CastelBranco2005_PD_anticonvulsant_profile_again_params()
% Lamotrigine_CastelBranco2005_PD_anticonvulsant_profile_again_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% lamotrigine Castel-Branco_2005::anticonvulsant_profile_against_maximal_electroshock_seizure_stimulation: sigmoid_emax exposure-response sweep (response = E0 + Emax*frac). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one mg/L per second, in SI inside (kg/m3, s). Response anticonvulsant profile against maximal electroshock seizure stimulation in its own unit. Driver: lamotrigine (cited_pk).
p.E0 = 0.0;
p.Emax = 1.0;
p.EC50 = 0.0034399999999999995;
p.gamma = 8.64;
p.slope = 0.0;
p.exposure_per_s = 0.001;
p.stop_time = 35.0;
p.form = 'E0 + Emax*frac';
end
