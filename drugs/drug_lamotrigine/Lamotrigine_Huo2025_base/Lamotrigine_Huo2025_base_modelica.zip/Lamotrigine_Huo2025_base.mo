model Lamotrigine_Huo2025_base
  parameter Real Cl_ref = 9.527777777777779e-07 "Cl [m3/s]";
  parameter Real Vd_ref = 0.0688 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 0.9,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.256091,
    adminMass = 2.5e-05,
    ka = 0.0005361111111111111,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About lamotrigine</h4><p>Lamotrigine is an anticonvulsant used to treat epilepsy and bipolar disorder, and has also been used for other neurological and psychiatric conditions. It is widely used and is included on the WHO list of essential medicines.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q410346\">Wikidata Q410346</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>lamotrigine</td></tr><tr><td>population:</td><td>Chinese epileptic patients during the peripregnancy period</td></tr><tr><td>source_paper:</td><td>Huo_2025</td></tr><tr><td>measured_compound:</td><td>lamotrigine</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>t0004</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>lamotrigine 256.091 g/mol (drugbank)</td></tr></table><p><b>Defaulted (base-class default used):</b> F, Tlag.</p><h4>Interpretation flags</h4><ul><li>apparent-by-design (ADVISORY, codes unchanged): extravascular dosing with no identifiable F, so these reported disposition parameters are likely apparent unless the model puts first-pass in its structure — Q61 (Vd (L)); Q22 (CL (L/h))</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=lamotrigine</li><li>model-stage split: 'base model' is the base model of Huo_2025 (paper reports 2 stages: base model, final model); same population, different model-building step</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of TLAG: primary's parameterization (rate-constant / ka-only) does not use it</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 259200, Tolerance = 1e-9, Interval = 1));
end Lamotrigine_Huo2025_base;
