model Meloxicam_Aoyama2017_reference
  parameter Real Cl_ref = 1.0861111111111112e-07 "Cl [m3/s]";
  parameter Real cov_cyp2c9_0 = 0 "cyp2c9 covariate";
  parameter Real cov_cyp2c9_1 = 0 "cyp2c9 covariate";
  parameter Real Vd_ref = 0.00779 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 0.425,
    Cl = Cl_ref*(1 + (-0.147)*cov_cyp2c9_0)*(1 + (-0.4)*cov_cyp2c9_1),
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.351401,
    adminMass = 7.5e-06,
    ka = 0.0005555555555555556,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About meloxicam</h4><p>Meloxicam is a nonsteroidal anti-inflammatory drug used to treat osteoarthritis and other forms of arthritis. It is an approved medicine, also approved for veterinary use, and is widely used for inflammatory joint disease.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q414028\">Wikidata Q414028</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>meloxicam</td></tr><tr><td>population:</td><td>healthy males</td></tr><tr><td>source_paper:</td><td>Aoyama_2017</td></tr><tr><td>measured_compound:</td><td>meloxicam</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>psp412259-tbl-0002</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>meloxicam 351.401 g/mol (drugbank)</td></tr></table><p><b>Defaulted (base-class default used):</b> Tlag.</p><h4>Interpretation flags</h4><ul><li>covariate level 'CYP2C9 *2 on CL' → Q900:cyp2c9_2_on_cl = -0.147 (linear_fractional on Q22)</li><li>dropped unlinked row (NIL): 'LBM on Vd' — extend the ontology if this is a real PK parameter (source ['psp412259-tbl-0002:row6:col1', 'psp412259-tbl-0002:row6:col3'])</li><li>dropped unlinked row (NIL): 'DT (h)' — extend the ontology if this is a real PK parameter (source ['psp412259-tbl-0002:row10:col1', 'psp412259-tbl-0002:row10:col3'])</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=meloxicam</li><li>skipped review gap-fill of TLAG: primary's parameterization (rate-constant / ka-only) does not use it</li><li>engineer: parent → metabolite not buildable on PK_3M_9C (None) — the measured compound's 1-compartment model instead</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 259200, Tolerance = 1e-9, Interval = 1));
end Meloxicam_Aoyama2017_reference;
