function p = Meloxicam_Giraudel2005_PD_skin_temperature_difference_params()
% Meloxicam_Giraudel2005_PD_skin_temperature_difference_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% meloxicam Giraudel_2005::Skin_temperature_difference: indirect_response_i exposure-response sweep (response = E0/(1 + Emax*frac)). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one ng ml-1 per second, in SI inside (kg/m3, s). Response Skin temperature difference in 1C. Driver: meloxicam (pk_record).
p.E0 = 10.317100792751981;
p.Emax = 68.5;
p.EC50 = 0.001298;
p.gamma = 6.4;
p.slope = 0.0;
p.exposure_per_s = 1e-06;
p.stop_time = 6700.0;
p.form = 'E0/(1 + Emax*frac)';
end
