function p = Meloxicam_Giraudel2005_PD_body_temperature_params()
% Meloxicam_Giraudel2005_PD_body_temperature_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% meloxicam Giraudel_2005::Body_temperature: indirect_response_iv exposure-response sweep (response = E0/(1 + Emax*frac)). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one ng ml-1 per second, in SI inside (kg/m3, s). Response Body temperature in 1C. Driver: meloxicam (pk_record).
p.E0 = 40.5;
p.Emax = 1.0;
p.EC50 = 0.0007769999999999999;
p.gamma = 6.1;
p.slope = 0.0;
p.exposure_per_s = 1e-06;
p.stop_time = 7000.0;
p.form = 'E0/(1 + Emax*frac)';
end
