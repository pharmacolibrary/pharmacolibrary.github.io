function p = Meloxicam_Toutain2004_PD_clinical_lameness_score_params()
% Meloxicam_Toutain2004_PD_clinical_lameness_score_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% meloxicam Toutain_2004::clinical_lameness_score: sigmoid_emax exposure-response sweep (response = E0 + Emax*frac). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one ng/mL per second, in SI inside (kg/m3, s). Response clinical lameness score in units. Driver: meloxicam (cited_pk).
p.E0 = 0.0;
p.Emax = -9.16;
p.EC50 = 0.000195;
p.gamma = 1.0;
p.slope = 0.0;
p.exposure_per_s = 1e-06;
p.stop_time = 2000.0;
p.form = 'E0 + Emax*frac';
end
