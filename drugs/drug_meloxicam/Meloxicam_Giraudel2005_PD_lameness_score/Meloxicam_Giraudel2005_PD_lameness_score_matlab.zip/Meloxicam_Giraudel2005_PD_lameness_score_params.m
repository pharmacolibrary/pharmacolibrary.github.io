function p = Meloxicam_Giraudel2005_PD_lameness_score_params()
% Meloxicam_Giraudel2005_PD_lameness_score_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% meloxicam Giraudel_2005::Lameness_score: indirect_response_i exposure-response sweep (response = E0/(1 + Emax*frac)). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one ng ml-1 per second, in SI inside (kg/m3, s). Response Lameness score in no unit. Driver: meloxicam (pk_record).
p.E0 = 20.0;
p.Emax = 75.4;
p.EC50 = 0.0009109999999999999;
p.gamma = 8.2;
p.slope = 0.0;
p.exposure_per_s = 1e-06;
p.stop_time = 5400.0;
p.form = 'E0/(1 + Emax*frac)';
end
