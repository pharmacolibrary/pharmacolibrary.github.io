model Meloxicam_Giraudel2005_PD_lameness_score
  "indirect_response_i exposure-response sweep — Giraudel_2005 :: Lameness score (Lameness score)"
  extends Pharmacolibrary.Pharmacodynamic.IndirectTurnoverSweep(
    E0 = 20,      // [no unit]
    Emax = 75.4,  // type IV effect term
    EC50 = 0.000911,  // [kg/m3; ng ml-1 × 1e-06]
    gamma = 8.2,
    exposure_per_s = 1e-06);   // 1 ng ml-1 per second
  // e0_from_kin_kout: no baseline row; E0 = kin/kout (494/24.7 = 20) — the paper's stated baseline may differ
  // emax_not_a_fraction: type I needs Imax ≤ 1 but the record has 75.4; bound as the reciprocal stimulation form (IV) the paper fitted
  annotation(experiment(StartTime = 0, StopTime = 5400, Interval = 10.8),
    Documentation(info = "<html><body><!-- drug-about --><h4>About meloxicam</h4><p>Meloxicam is a nonsteroidal anti-inflammatory drug used to treat osteoarthritis and other forms of arthritis. It is an approved medicine, also approved for veterinary use, and is widely used for inflammatory joint disease.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q414028\">Wikidata Q414028</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h4>Meloxicam_Giraudel2005_PD_lameness_score</h4><p>The steady-state exposure-response curve of Giraudel JM et al., <i>British journal of pharmacology 146(5):642–653</i> 2005 (<a href=\"https://doi.org/10.1038/sj.bjp.0706372\">doi:10.1038/sj.bjp.0706372</a>) — Lameness score [no unit] against meloxicam ng ml-1 — obtained by sweeping the driver instead of simulating a dose. Model family: indirect_response_i.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    =         20 no unit  drug-free response (baseline) (kin/kout, Q327/Q328)
  Emax  =       75.4          maximal effect term (I max, Q323)
  EC50  =        911 ng ml-1  exposure at half of the maximal effect term (IC 50, Q322)
  gamma =        8.2          Hill coefficient (n, Q325)</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.IndirectTurnoverSweep\">IndirectTurnoverSweep</a>; this model only supplies the numbers. The x axis is one ng ml-1 of meloxicam per second of simulated time (exposure is in kg/m3): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><p>The effect term enters as a reciprocal (steady state of <code>der(R) = Kin - Kout*(1 + Emax*frac)*R</code>), so EC50 is the exposure at half the maximal STIMULATION of turnover, not at half the response.</p><h4>What it reproduces</h4><pre>  exposure = 0         response 20   (drug-free)
  exposure = EC50 (911 ng ml-1)  response 0.5168
  exposure -> infinity  response 0.2618</pre></body></html>"));
end Meloxicam_Giraudel2005_PD_lameness_score;
