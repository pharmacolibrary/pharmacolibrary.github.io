function p = Meloxicam_Giraudel2005_PD_overall_locomotion_variable_params()
% Meloxicam_Giraudel2005_PD_overall_locomotion_variable_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% meloxicam Giraudel_2005::Overall_locomotion_variable: indirect_response_i exposure-response sweep (response = E0/(1 + Emax*frac)). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one ng ml-1 per second, in SI inside (kg/m3, s). Response Overall locomotion variable in %. Driver: meloxicam (pk_record).
p.E0 = 60.0;
p.Emax = 64.1;
p.EC50 = 0.000841;
p.gamma = 10.0;
p.slope = 0.0;
p.exposure_per_s = 1e-06;
p.stop_time = 5600.0;
p.form = 'E0/(1 + Emax*frac)';
end
