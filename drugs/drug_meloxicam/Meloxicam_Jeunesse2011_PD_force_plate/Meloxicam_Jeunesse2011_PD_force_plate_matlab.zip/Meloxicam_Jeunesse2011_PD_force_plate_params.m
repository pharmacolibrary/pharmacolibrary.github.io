function p = Meloxicam_Jeunesse2011_PD_force_plate_params()
% Meloxicam_Jeunesse2011_PD_force_plate_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% meloxicam Jeunesse_2011::Force_Plate: indirect_response_ii exposure-response sweep (response = E0/(1 - Emax*frac)). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one Nanograms per milliliter per second, in SI inside (kg/m3, s). Response Force Plate in kg/kg. Driver: meloxicam (cited_pk).
p.E0 = 2.5214521452145213;
p.Emax = 1.0;
p.EC50 = 68.0;
p.gamma = 2.27;
p.slope = 0.0;
p.exposure_per_s = 1.0;
p.stop_time = 680.0;
p.form = 'E0/(1 - Emax*frac)';
end
