function p = Meloxicam_Giraudel2005_PD_pain_score_params()
% Meloxicam_Giraudel2005_PD_pain_score_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% meloxicam Giraudel_2005::Pain_score: indirect_response_i exposure-response sweep (response = E0/(1 + Emax*frac)). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one ng ml-1 per second, in SI inside (kg/m3, s). Response Pain score in %. Driver: meloxicam (pk_record).
p.E0 = 98.36021505376343;
p.Emax = 247.9;
p.EC50 = 0.000883;
p.gamma = 10.0;
p.slope = 0.0;
p.exposure_per_s = 1e-06;
p.stop_time = 5100.0;
p.form = 'E0/(1 + Emax*frac)';
end
