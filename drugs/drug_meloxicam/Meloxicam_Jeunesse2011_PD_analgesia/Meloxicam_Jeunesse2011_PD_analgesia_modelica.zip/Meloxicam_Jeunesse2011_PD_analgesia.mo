model Meloxicam_Jeunesse2011_PD_analgesia
  "indirect_response_ii exposure-response sweep — Jeunesse_2011 :: Analgesia (Paw withdrawal time)"
  extends Pharmacolibrary.Interfaces.PartialExposureResponseSweep(
    E0 = 8.00744878957,      // [s]
    Emax = 1,  // type II effect term
    EC50 = 61,  // [Nanograms per milliliter]
    gamma = 1.13,
    exposure_per_s = 1);   // 1 Nanograms per milliliter per second
equation
  response = E0/(1 - Emax*frac);   // steady state, indirect response type II
  // e0_from_kin_kout: no baseline row; E0 = kin/kout (43/5.37 = 8.007) — the paper's stated baseline may differ
  // exposure_unit_unresolved: 'Nanograms per milliliter' — the x axis is in the paper's unit, not SI
  annotation(experiment(StartTime = 0, StopTime = 610, Interval = 1.22),
    Documentation(info = "<html><body><!-- drug-about --><h4>About meloxicam</h4><p>Meloxicam is a nonsteroidal anti-inflammatory drug used to treat osteoarthritis and other forms of arthritis. It is an approved medicine, also approved for veterinary use, and is widely used for inflammatory joint disease.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q414028\">Wikidata Q414028</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h4>Meloxicam_Jeunesse2011_PD_analgesia</h4><p>The steady-state exposure-response curve of Jeunesse EC et al., <i>The Journal of pharmacology and experimental therapeutics 338(2):548–558</i> 2011 (<a href=\"https://doi.org/10.1124/jpet.110.178350\">doi:10.1124/jpet.110.178350</a>) — Paw withdrawal time [s] against meloxicam Nanograms per milliliter — obtained by sweeping the driver instead of simulating a dose. Model family: indirect_response_ii.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = 8.00744878957 s        drug-free response (baseline) (kin/kout, Q327/Q328)
  Emax  =          1          maximal effect term (Maximal possible clinical effect (between 0 and 1), Q323)
  EC50  =         61 Nanograms per milliliter exposure at half of the maximal effect term (Plasma meloxicam IC 50 on the time development of kaolin inflammation, Q322)
  gamma =       1.13          Hill coefficient (Hill coefficient associated with IC 50B, Q325)</pre><p>The algebra is <code>response = E0/(1 - Emax*frac)</code>; this model only supplies the numbers. The x axis is one Nanograms per milliliter of meloxicam per second of simulated time: there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 8.007   (drug-free)
  exposure = EC50 (61 Nanograms per milliliter)  response 16.01
  exposure -> infinity  response inf</pre></body></html>"));
end Meloxicam_Jeunesse2011_PD_analgesia;
