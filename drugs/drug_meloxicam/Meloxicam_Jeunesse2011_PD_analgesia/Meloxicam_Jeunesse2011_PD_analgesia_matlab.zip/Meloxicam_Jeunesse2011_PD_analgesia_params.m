function p = Meloxicam_Jeunesse2011_PD_analgesia_params()
% Meloxicam_Jeunesse2011_PD_analgesia_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% meloxicam Jeunesse_2011::Analgesia: indirect_response_ii exposure-response sweep (response = E0/(1 - Emax*frac)). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one Nanograms per milliliter per second, in SI inside (kg/m3, s). Response Analgesia in s. Driver: meloxicam (cited_pk).
p.E0 = 8.007448789571695;
p.Emax = 1.0;
p.EC50 = 61.0;
p.gamma = 1.13;
p.slope = 0.0;
p.exposure_per_s = 1.0;
p.stop_time = 610.0;
p.form = 'E0/(1 - Emax*frac)';
end
