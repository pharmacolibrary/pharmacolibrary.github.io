% Run (SimBiology): build model + dose, simulate 0..44.0 h, plot.
p = Tolvaptan_Plosker2010_reference_params();
[model, dose, variant] = build_sb_pk(p);
sd = simulate_sb(model, variant, dose, 44.0);
