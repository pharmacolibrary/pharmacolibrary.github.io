model Desvenlafaxine_MangasSanjun2023_reference
  parameter Real Cl_ref = 3.3333333333333333e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.019 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 0.9,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.26337520000000003,
    adminMass = 0.0001,
    ka = 0.005833333333333334,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About desvenlafaxine</h4><p>Desvenlafaxine is an antidepressant, a serotonin and noradrenaline reuptake inhibitor, used to treat depression and studied for anxiety. It is approved and used in several countries, but a marketing application in the European Union was withdrawn, so it is not authorised there.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q2419445\">Wikidata Q2419445</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>desvenlafaxine</td></tr><tr><td>population:</td><td>healthy adults</td></tr><tr><td>source_paper:</td><td>Mangas-Sanjuán_2023</td></tr><tr><td>measured_compound:</td><td>desvenlafaxine</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>pharmaceutics-15-00409-t003</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>desvenlafaxine 263.375 g/mol (drugbank)</td></tr></table><p><b>Defaulted (base-class default used):</b> F, Tlag.</p><h4>Interpretation flags</h4><ul><li>table section iiv: 'ka (%)' routed out of structural estimates ('Inter-individual variability')</li><li>table section iiv: 'ka (%)' routed out of structural estimates ('Inter-individual variability')</li><li>table section iiv: 'ka (%)' routed out of structural estimates ('Inter-individual variability')</li><li>table section iiv: 'ka (%)' routed out of structural estimates ('Inter-individual variability')</li><li>table section iiv: 'ka (%)' routed out of structural estimates ('Inter-individual variability')</li><li>table section iiv: 'ka (%)' routed out of structural estimates ('Inter-individual variability')</li><li>table section iiv: 'ktr (%)' routed out of structural estimates ('Inter-individual variability')</li><li>table section iiv: 'ktr (%)' routed out of structural estimates ('Inter-individual variability')</li><li>table section iiv: 'ktr (%)' routed out of structural estimates ('Inter-individual variability')</li><li>table section iiv: 'ktr (%)' routed out of structural estimates ('Inter-individual variability')</li><li>table section iiv: 'ktr (%)' routed out of structural estimates ('Inter-individual variability')</li><li>table section iiv: 'ktr (%)' routed out of structural estimates ('Inter-individual variability')</li><li>table section iiv: 'CL (%)' routed out of structural estimates ('Inter-individual variability')</li><li>table section iiv: 'CL (%)' routed out of structural estimates ('Inter-individual variability')</li><li>table section iiv: 'CL (%)' routed out of structural estimates ('Inter-individual variability')</li><li>table section iiv: 'CL (%)' routed out of structural estimates ('Inter-individual variability')</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Desvenlafaxine_MangasSanjun2023_reference;
