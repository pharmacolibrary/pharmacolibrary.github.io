model Thiopental_Russo1997v3_reference
  parameter Real Cl_ref = 2.823333333333333e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.1526 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 0.9,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.242338,
    adminMass = 0.0001,
    ka = 0.00046666666666666666,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About thiopental</h4><p>Thiopental is a barbiturate used as a general anesthetic and also as a hypnotic and sedative. It is an approved drug, also approved for veterinary use, though some products have been withdrawn in places.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q55186498\">Wikidata Q55186498</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>thiopental</td></tr><tr><td>population:</td><td>pediatric patients with increased intracranial pressure</td></tr><tr><td>source_paper:</td><td>Russo_1997_3</td></tr><tr><td>measured_compound:</td><td>thiopental</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>thiopental 242.338 g/mol (drugbank)</td></tr></table><p><b>Defaulted (base-class default used):</b> F, Tlag.</p><h4>Interpretation flags</h4><ul><li>dropped duplicate Q57 ('elimination half-life in adults', value 17.5) — already have one for this compound</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=thiopental</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li><li>gap-filled Q49 (kabs) from Solana-Altabella_2025's review values (primary lacked it)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 259200, Tolerance = 1e-9, Interval = 1));
end Thiopental_Russo1997v3_reference;
