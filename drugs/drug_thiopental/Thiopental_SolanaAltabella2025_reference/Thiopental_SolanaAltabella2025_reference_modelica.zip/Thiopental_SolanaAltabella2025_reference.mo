model Thiopental_SolanaAltabella2025_reference
  parameter Real Cl_ref = 5.472222222222222e-07 "Cl [m3/s]";
  parameter Real Vd_ref = 0.23413295841281265 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C_enteral(
    weight = 70.0,
    F = 0.9,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.242338,
    adminMass = 0.0001,
    ka = 0.00046666666666666666,
    Tlag = 0.0,
    k12 = 6.643898262340624e-07,
    k21 = 7.093923547772508e-07
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About thiopental</h4><p>Thiopental is a barbiturate used as a general anesthetic and also as a hypnotic and sedative. It is an approved drug, also approved for veterinary use, though some products have been withdrawn in places.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q55186498\">Wikidata Q55186498</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>thiopental</td></tr><tr><td>population:</td><td>review reference</td></tr><tr><td>source_paper:</td><td>Solana-Altabella_2025</td></tr><tr><td>measured_compound:</td><td>thiopental</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_2C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>thiopental 242.338 g/mol (drugbank)</td></tr></table><p><b>Defaulted (base-class default used):</b> F, Tlag.</p><h4>Interpretation flags</h4><ul><li>built from REVIEW reference values (Solana-Altabella_2025) — secondary source</li><li>central volume derived from CL·t½/ln2</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 1555200, Tolerance = 1e-9, Interval = 1));
end Thiopental_SolanaAltabella2025_reference;
