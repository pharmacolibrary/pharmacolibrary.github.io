// parent + metabolites (dihydromorphine): PK_3M_3C — first-pass formation; parent 1 + hepatic, metabolites [1]
model Dihydrocodeine_Webb2001_reference
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_3M_3C(
    Vd1 = 0.203,
    Vd2 = 0.203,
    q12 = 2.4999999999999998e-05,
    q21 = 2.4999999999999998e-05,
    q1_m11 = 1.791666666666667e-07,
    CL1 = 1.176527777777778e-05,
    Vd1m1 = 0.2,
    CLm1 = 1.8833333333333335e-05,
    MW = 0.30138010000000004,
    MW_m1 = 0.287359,
    F = 1,
    ka = 0.0030555555555555557,
    Tlag = 1080.0,
    adminDuration = 600,
    adminCount = 1,
    adminMass = 9e-05
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About dihydrocodeine</h4><p>Dihydrocodeine is an opioid painkiller used to treat pain and cough. It is an approved medicine, available alone and in combination with non-opioid analgesics, and is used fairly widely in some countries.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q377270\">Wikidata Q377270</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>dihydrocodeine</td></tr><tr><td>population:</td><td>healthy volunteers</td></tr><tr><td>source_paper:</td><td>Webb_2001</td></tr><tr><td>measured_compound:</td><td>dihydrocodeine</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>parent_metabolite</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_3M_3C: absorption rate constant reported; hepatic volume not reported separately — set equal to the central volume (as Jung_2024 fixes Vc = VH); formation of dihydromorphine: fm=0.015 × CL; dose 90 mg (paper)</td></tr><tr><td>molar_masses:</td><td>dihydrocodeine 301.38 g/mol (drugbank); dihydromorphine 287.359 g/mol (pubchem)</td></tr></table><p><b>Defaulted (base-class default used):</b> q12/q21 (hepatic flow, 90 L/h).</p><h4>Interpretation flags</h4><ul><li>dropped unlinked row (NIL): 'P' — extend the ontology if this is a real PK parameter (source ['Webb_2001:abstract'])</li><li>dropped unlinked row (NIL): 'Mean pain AUC changes' — extend the ontology if this is a real PK parameter (source ['Webb_2001:abstract'])</li><li>dropped unlinked row (NIL): 'Caucasians' — extend the ontology if this is a real PK parameter (source ['Webb_2001:abstract'])</li><li>dropped unlinked row (NIL): 'Asians' — extend the ontology if this is a real PK parameter (source ['Webb_2001:abstract'])</li><li>dropped unlinked row (NIL): 'aged' — extend the ontology if this is a real PK parameter (source ['Webb_2001:abstract'])</li><li>dropped unlinked row (NIL): 'DHC/DHM ratio' — extend the ontology if this is a real PK parameter (source ['Webb_2001:abstract'])</li><li>unit_dimension_unknown: 'lhx1' (CL/F)</li><li>unit_dimension_unknown: 'hx1' (kabs)</li><li>unit_dimension_unknown: 'hx1' (kel)</li><li>dropped duplicate Q45 ('fm(DHM) 1stpass', value 0.022) — already have one for this compound</li><li>unit_dimension_unknown: 'DHM' (kel)</li><li>unit_dimension_unknown: 'DHM' (V1)</li><li>dropped PD-category row 'ke0' → Q326 (ke0, category G11) — pharmacodynamic parameters belong to scholarpd, not the PK model (source ['Webb_2001:abstract', 'Webb_2001:abstract', 'Webb_2001:abstract'])</li><li>implicit units: 'CL/F' → L/h (from the popPK convention: 'CL/F is a clearance parameter. In population PK, clearance is conventionally expressed in L/h. The value 43 is consisten')</li><li>implicit units: 'ka' → 1/h (from the popPK convention: 'ka is a first-order absorption rate constant. Rate constants are conventionally expressed in 1/h. The value 11 is consis')</li><li>implicit units: 'kel' → 1/h (from the popPK convention: 'kel is a first-order elimination rate constant. Rate constants are conventionally expressed in 1/h. The value 0.216 is c')</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Dihydrocodeine_Webb2001_reference;
