function p = Dihydrocodeine_Webb2001_reference_params()
% Auto-generated parent-metabolite PK model (clinical units: mg, L, h).
%   drug: dihydrocodeine   source: Webb_2001 / reference   PK_3M_3C parent + 1 metabolite(s), 3 compartments, oral
%   dA/dt = K*A; C = A./V. K(i,j) is the rate [1/h] at which compartment j feeds i:
%   a metabolic conversion carries MW_dst/MW_src, so one molecule forms one molecule.
%   molar masses: C_central=301.38 g/mol C_M1=287.359 g/mol
  p.name  = 'Dihydrocodeine_Webb2001_reference_params';
  p.drug  = 'dihydrocodeine';
  p.kind  = 'network';
  p.template = 'PK_3M_3C';
  p.states = {'hepatic', 'central', 'central_M1'};
  p.V = [203.0, 203.0, 200.0];          % compartment volumes [L]
  p.K = [-0.6551724137931034, 0.4433497536945812, 0.0;
         0.4433497536945812, -0.4433497536945812, 0.0;
         0.0030295205846330546, 0.0, -0.3390000000000001];
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;
  p.dose_into = 1;   % hepatic
  p.ka = 11.0;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.3;             % absorption lag [h] (in dose_start)
  p.dose = 90.0;             % dose [mg]
  p.dose_start = 0.31666666666666665;   % dose enters from [h] ...
  p.dose_duration = 0.16666666666666666;   % ... at a constant rate for [h]
  p.out_idx = [2.0, 3.0];
  p.out_names = {'C_central', 'C_M1'};
  p.out_labels = {'dihydrocodeine', 'dihydromorphine'};
end
