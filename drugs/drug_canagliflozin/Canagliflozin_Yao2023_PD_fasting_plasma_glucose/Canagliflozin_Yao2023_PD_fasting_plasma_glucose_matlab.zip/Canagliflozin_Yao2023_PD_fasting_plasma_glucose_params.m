function p = Canagliflozin_Yao2023_PD_fasting_plasma_glucose_params()
% Canagliflozin_Yao2023_PD_fasting_plasma_glucose_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% canagliflozin Yao_2023::fasting_plasma_glucose: emax exposure-response sweep (response = E0 + Emax*frac). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one ng/mL·h per second, in SI inside (kg/m3, s). Response fasting plasma glucose in FPG. Driver: dapagliflozin, canagliflozin, empagliflozin (cited_pk).
p.E0 = 0.0;
p.Emax = 0.606;
p.EC50 = 56.6;
p.gamma = 1.0;
p.slope = 0.0;
p.exposure_per_s = 1.0;
p.stop_time = 570.0;
p.form = 'E0 + Emax*frac';
end
