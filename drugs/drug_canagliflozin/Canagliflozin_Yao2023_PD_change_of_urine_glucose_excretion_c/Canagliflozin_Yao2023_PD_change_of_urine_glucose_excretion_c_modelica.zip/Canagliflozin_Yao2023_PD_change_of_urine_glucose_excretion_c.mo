model Canagliflozin_Yao2023_PD_change_of_urine_glucose_excretion_c
  "emax exposure-response sweep — Yao_2023 :: change of urine glucose excretion corrected by FPG (name)"
  extends Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep(
    E0 = 0,      // [1]
    Emax = 0.606,  // [unit]
    EC50 = 56.6,  // [ng/mL·h]
    gamma = 1,
    exposure_per_s = 1);   // 1 ng/mL·h per second
  // exposure_unit_unresolved: 'ng/mL·h' — the x axis is in the paper's unit, not SI
  // defaulted: E0
  // defaulted: gamma
  annotation(experiment(StartTime = 0, StopTime = 570, Interval = 1.14),
    Documentation(info = "<html><body><h4>Canagliflozin_Yao2023_PD_change_of_urine_glucose_excretion_c</h4><p>The steady-state exposure-response curve of Yao X et al., <i>CPT: pharmacometrics &amp; systems pharmacology 12(4):487–499</i> 2023 (<a href=\"https://doi.org/10.1002/psp4.12934\">doi:10.1002/psp4.12934</a>) — name [ΔUGEc] against dapagliflozin, canagliflozin, empagliflozin ng/mL·h — obtained by sweeping the driver instead of simulating a dose. Model family: emax.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = (library default) drug-free response (baseline)
  Emax  =      0.606 unit     maximal effect term (Emax (g/(mg/dL)) — Estimates, Q320)
  EC50  =       56.6 ng/mL·h  exposure at half of the maximal effect term (Dapa‐EC50 (ng/mL·h) — Estimates, Q321)
  gamma = (library default) Hill coefficient</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep\">SigmoidEmaxSweep</a>; this model only supplies the numbers. The x axis is one ng/mL·h of dapagliflozin, canagliflozin, empagliflozin per second of simulated time: there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0   (drug-free)
  exposure = EC50 (56.6 ng/mL·h)  response 0.303
  exposure -> infinity  response 0.606</pre></body></html>"));
end Canagliflozin_Yao2023_PD_change_of_urine_glucose_excretion_c;
