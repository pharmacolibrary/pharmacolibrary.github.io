model Canagliflozin_Yao2023_PD_change_of_urine_glucose_excretion_c
  "emax exposure-response sweep — Yao_2023 :: change of urine glucose excretion corrected by FPG (name)"
  extends Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep(
    E0 = 0.0,      // [1]
    Emax = 0.606,  // [unit]
    EC50 = 56.6,  // [ng/mL·h]
    gamma = 1.0,
    exposure_per_s = 1.0);   // 1 ng/mL·h per second
  // exposure_unit_unresolved: 'ng/mL·h' — the x axis is in the paper's unit, not SI
  // defaulted: E0
  // defaulted: gamma
  annotation(experiment(StartTime = 0, StopTime = 566, Interval = 1.132));
end Canagliflozin_Yao2023_PD_change_of_urine_glucose_excretion_c;
