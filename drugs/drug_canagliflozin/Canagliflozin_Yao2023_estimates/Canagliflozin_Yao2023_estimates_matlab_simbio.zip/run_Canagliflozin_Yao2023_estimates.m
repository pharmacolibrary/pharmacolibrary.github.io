% Run (SimBiology): build model + dose, simulate 0..25.0 h, plot.
p = Canagliflozin_Yao2023_estimates_params();
[model, dose, variant] = build_sb_pk(p);
sd = simulate_sb(model, variant, dose, 25.0);
