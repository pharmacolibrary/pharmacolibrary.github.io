model Canagliflozin_Yao2023_reference
  parameter Real Cl_ref = 1.1805555555555556e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.030600000000000002 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.444516,
    adminMass = 1e-05,
    k12 = 1.2436456063907045e-05
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About canagliflozin</h4><p>Canagliflozin is an anti-diabetic medicine used to treat type 2 diabetes mellitus. It is an approved SGLT2 inhibitor and is authorised in the European Union.</p><p><small>Summary written by glm-5.3-flash from <a href=&quot;https://www.wikidata.org/wiki/Q5030940&quot;>Wikidata Q5030940</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>canagliflozin</td></tr><tr><td>population:</td><td>healthy subjects and patients with T2DM</td></tr><tr><td>source_paper:</td><td>Yao_2023</td></tr><tr><td>measured_compound:</td><td>canagliflozin</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>psp412934-tbl-0001</td></tr><tr><td>input:</td><td>PK_2C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>canagliflozin 444.516 g/mol (drugbank)</td></tr></table><p><b>Defaulted (base-class default used):</b> k21.</p><h4>Interpretation flags</h4><ul><li>table section iiv: 'CL (L/h)' routed out of structural estimates ('IIV (%)')</li><li>table section iiv: 'Vc (L)' routed out of structural estimates ('IIV (%)')</li><li>table section iiv: 'VT (L)' routed out of structural estimates ('IIV (%)')</li><li>table section iiv: 'K t (h−1)' routed out of structural estimates ('IIV (%)')</li><li>table section iiv: 'CL (L/h)' routed out of structural estimates ('IIV (%)')</li><li>table section iiv: 'Vc (L)' routed out of structural estimates ('IIV (%)')</li><li>table section iiv: 'CLD' routed out of structural estimates ('IIV (%)')</li><li>table section iiv: 'VT (L)' routed out of structural estimates ('IIV (%)')</li><li>table section iiv: 'K t (h−1)' routed out of structural estimates ('IIV (%)')</li><li>table section iiv: 'CL (L/h)' routed out of structural estimates ('IIV (%)')</li><li>table section iiv: 'Vc (L)' routed out of structural estimates ('IIV (%)')</li><li>table section iiv: 'VT (L)' routed out of structural estimates ('IIV (%)')</li><li>table section iiv: 'K t (h−1)' routed out of structural estimates ('IIV (%)')</li><li>table section iiv: 'FPGbaseline (mg/dL)' routed out of structural estimates ('IIV (%)')</li><li>table section iiv: 'Pfmax1 (mg/dL)' routed out of structural estimates ('IIV (%)')</li><li>table section iiv: 'Pfmax3 (mg/dL)' routed out of structural estimates ('IIV (%)')</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 90000, Tolerance = 1e-9, Interval = 1));
end Canagliflozin_Yao2023_reference;
