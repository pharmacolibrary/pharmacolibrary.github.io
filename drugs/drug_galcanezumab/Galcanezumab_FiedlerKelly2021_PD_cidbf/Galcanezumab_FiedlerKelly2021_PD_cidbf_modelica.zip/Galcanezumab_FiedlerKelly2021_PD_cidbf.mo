model Galcanezumab_FiedlerKelly2021_PD_cidbf
  "emax exposure-response sweep — Fiedler-Kelly_2021 :: CIDBF (capsaicin-induced dermal blood flow)"
  extends Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep(
    E0 = 0,      // [1]
    Emax = -0.705,  // [1; % × 0.01]
    EC50 = 0.00106,  // [kg/m3; ng/mL × 1e-06]
    gamma = 1,
    exposure_per_s = 1e-06);   // 1 ng/mL per second
  // family_inferred: the record's model family is effect_compartment; read from the parameters: Emax/Imax and EC50/IC50 without a Hill coefficient — Emax
  // imax_as_negative_emax: Imax (Q323) enters SigmoidEmaxSweep as −Emax
  // defaulted: E0
  // defaulted: gamma
  annotation(experiment(StartTime = 0, StopTime = 11000, Interval = 22),
    Documentation(info = "<html><body><!-- drug-about --><h4>About galcanezumab</h4><p>Galcanezumab is a humanized monoclonal antibody used to prevent migraine attacks. It is an approved medicine, authorised in the European Union for migraine, and is also under investigation for other uses.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q25326707\">Wikidata Q25326707</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h4>Galcanezumab_FiedlerKelly2021_PD_cidbf</h4><p>The steady-state exposure-response curve of Fiedler-Kelly J et al., <i>Clinical pharmacology in drug development 10(5):440–452</i> 2021 (<a href=\"https://doi.org/10.1002/cpdd.929\">doi:10.1002/cpdd.929</a>) — capsaicin-induced dermal blood flow against galcanezumab ng/mL — obtained by sweeping the driver instead of simulating a dose. Model family: emax.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = (library default) drug-free response (baseline)
  Emax  =       70.5 %        maximal effect term (maximum inhibitory effect, Q323)
  EC50  =       1060 ng/mL    exposure at half of the maximal effect term (IC50, Q322)
  gamma = (library default) Hill coefficient</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep\">SigmoidEmaxSweep</a>; this model only supplies the numbers. The x axis is one ng/mL of galcanezumab per second of simulated time (exposure is in kg/m3): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0   (drug-free)
  exposure = EC50 (1060 ng/mL)  response -0.3525
  exposure -> infinity  response -0.705</pre></body></html>"));
end Galcanezumab_FiedlerKelly2021_PD_cidbf;
