function p = Galcanezumab_FiedlerKelly2021_PD_cidbf_params()
% Galcanezumab_FiedlerKelly2021_PD_cidbf_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% galcanezumab Fiedler-Kelly_2021::CIDBF: emax exposure-response sweep (response = E0 + Emax*frac). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one ng/mL per second, in SI inside (kg/m3, s). Response CIDBF in its own unit. Driver: galcanezumab (pk_record).
p.E0 = 0.0;
p.Emax = -0.705;
p.EC50 = 0.00106;
p.gamma = 1.0;
p.slope = 0.0;
p.exposure_per_s = 1e-06;
p.stop_time = 11000.0;
p.form = 'E0 + Emax*frac';
end
