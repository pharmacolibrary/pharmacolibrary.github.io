model Perampanel_Yu2025_reference
  parameter Real Cl_ref = 4.9166666666666664e-08 "Cl [m3/s]";
  parameter Real Vd_ref = 0.227 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.34939299999999995,
    adminMass = 8e-06,
    ka = 0.0009361111111111112,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About perampanel</h4><p>Perampanel is an antiepileptic medicine used to treat epilepsy, including partial seizures and tonic–clonic seizures. It is authorised in the European Union and is an approved drug, though it carries a boxed warning.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q868658\">Wikidata Q868658</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>perampanel</td></tr><tr><td>population:</td><td>pediatric patients with epilepsy</td></tr><tr><td>source_paper:</td><td>Yu_2025</td></tr><tr><td>measured_compound:</td><td>perampanel</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>t0002</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>perampanel 349.393 g/mol (drugbank)</td></tr></table><p><b>Defaulted (base-class default used):</b> Tlag.</p><h4>Interpretation flags</h4><ul><li>dropped unlinked row (NIL): 'AGE' — extend the ontology if this is a real PK parameter (source ['t0002:row5:col1', 't0002:row5:col2', 't0002:row5:col3', 't0002:row5:col4', 't0002:row5:col5', 't0002:row5:col6', 't0002:row5:col7', 't0002:row5:col8'])</li><li>dropped unlinked row (NIL): 'Oxcarbazepine' — extend the ontology if this is a real PK parameter (source ['t0002:row6:col1', 't0002:row6:col2', 't0002:row6:col3', 't0002:row6:col4', 't0002:row6:col5', 't0002:row6:col6', 't0002:row6:col7', 't0002:row6:col8'])</li><li>dropped unlinked row (NIL): 'Sodium valproate' — extend the ontology if this is a real PK parameter (source ['t0002:row7:col1', 't0002:row7:col2', 't0002:row7:col3', 't0002:row7:col4', 't0002:row7:col5', 't0002:row7:col6', 't0002:row7:col7', 't0002:row7:col8'])</li><li>dropped unlinked row (NIL): 'Carbamazepine' — extend the ontology if this is a real PK parameter (source ['t0002:row8:col1', 't0002:row8:col2', 't0002:row8:col3', 't0002:row8:col4', 't0002:row8:col5', 't0002:row8:col6', 't0002:row8:col7', 't0002:row8:col8'])</li><li>implicit units: 'KAa' → 1/h (from the popPK convention: 'The paper does not explicitly state the unit for KA in the provided text or table notes. However, KA (absorption rate co')</li><li>apparent-ness (ontology-grounded): parameterization=apparent, measured_compound=perampanel</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of TLAG: primary's parameterization (rate-constant / ka-only) does not use it</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 15552000, Tolerance = 1e-9, Interval = 1));
end Perampanel_Yu2025_reference;
