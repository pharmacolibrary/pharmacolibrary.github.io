model Perampanel_Silva2023_base
  parameter Real Cl_ref = 1.866666666666667e-07 "Cl [m3/s]";
  parameter Real Vd_ref = 0.033100000000000004 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.34939299999999995,
    adminMass = 2e-06
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About perampanel</h4><p>Perampanel is an antiepileptic medicine used to treat epilepsy, including partial seizures and tonic–clonic seizures. It is authorised in the European Union and is an approved drug, though it carries a boxed warning.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q868658\">Wikidata Q868658</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>perampanel</td></tr><tr><td>population:</td><td>adults with refractory epilepsy</td></tr><tr><td>source_paper:</td><td>Silva_2023</td></tr><tr><td>measured_compound:</td><td>perampanel</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>pharmaceutics-15-01704-t002</td></tr><tr><td>input:</td><td>PK_1C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>perampanel 349.393 g/mol (drugbank)</td></tr></table><h4>Interpretation flags</h4><ul><li>dropped unlinked row (NIL): 'IPVCL (%)' — extend the ontology if this is a real PK parameter (source ['pharmaceutics-15-01704-t002:row6:col1', 'pharmaceutics-15-01704-t002:row6:col2'])</li><li>dropped unlinked row (NIL): 'REproportional (%)' — extend the ontology if this is a real PK parameter (source ['pharmaceutics-15-01704-t002:row7:col1', 'pharmaceutics-15-01704-t002:row7:col2'])</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=perampanel</li><li>model-stage split: 'base model' is the base model of Silva_2023 (paper reports 2 stages: base model, final model); same population, different model-building step</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 691200, Tolerance = 1e-9, Interval = 1));
end Perampanel_Silva2023_base;
