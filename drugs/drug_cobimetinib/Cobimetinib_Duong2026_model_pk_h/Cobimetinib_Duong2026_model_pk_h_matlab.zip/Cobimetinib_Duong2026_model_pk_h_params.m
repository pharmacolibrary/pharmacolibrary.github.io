function p = Cobimetinib_Duong2026_model_pk_h_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: cobimetinib   source: Duong_2026 / model_pk_h   route: oral
  p.name  = 'Cobimetinib_Duong2026_model_pk_h_params';
  p.drug  = 'cobimetinib';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 806.0;                % central volume [L]
  p.CL = 149.1;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 2.0;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 60.0;             % dose [mg]
end
