function p = Atenolol_Baek2008_carvedilol_25_mg_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: atenolol   source: Baek_2008 / carvedilol_25_mg   route: oral
  p.name  = 'Atenolol_Baek2008_carvedilol_25_mg_params';
  p.drug  = 'atenolol';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 1561.78;                % central volume [L]
  p.CL = 94.64;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 4.52;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 25.0;             % dose [mg]
end
