function p = Mitoxantrone_Brandon2026_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: mitoxantrone   source: Brandon_2026 / reference   route: iv_bolus
  % estimated (absent from source): F, dose
  p.name  = 'Mitoxantrone_Brandon2026_reference_params';
  p.drug  = 'mitoxantrone';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'iv_bolus';        % 'oral' | 'iv_bolus'
  p.depot = false;             % oral -> first-order absorption depot
  p.Vc = 23.2;                % central volume [L]
  p.CL = 39.1;                % clearance [L/h]
  p.Vp = [85.9];             % peripheral volumes [L]
  p.Q  = [27.6];             % inter-compartmental clearances [L/h]
  p.ka = 0.0;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 10.0;             % dose [mg]
end
