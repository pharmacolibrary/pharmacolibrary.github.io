model Mitoxantrone_Brandon2026_reference
  parameter Real Cl_ref = 1.0861111111111112e-05 "Cl [m3/s]";
  parameter Real cov_wt_0 = 0 "wt covariate";
  parameter Real cov_wt_1 = 0 "wt covariate";
  parameter Real Vd_ref = 0.0232 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref*(1 + (1.0)*cov_wt_0)*(1 + (0.75)*cov_wt_1),
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.4444809,
    adminMass = 1e-05,
    k12 = 0.0003304597701149426,
    k21 = 8.925106713232442e-05
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About mitoxantrone</h4><p>Mitoxantrone is a cytotoxic drug used to treat several cancers, including breast cancer, prostate cancer, lymphoma and acute myeloid leukemia, and is also used in multiple sclerosis. It is an approved medicine, but carries a boxed warning, so its use is restricted to specialist care.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q239426\">Wikidata Q239426</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>mitoxantrone</td></tr><tr><td>population:</td><td>children with acute myeloid leukaemia</td></tr><tr><td>source_paper:</td><td>Brandon_2026</td></tr><tr><td>measured_compound:</td><td>mitoxantrone</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>bcp70436-tbl-0002</td></tr><tr><td>input:</td><td>PK_2C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>mitoxantrone 444.481 g/mol (drugbank)</td></tr></table><h4>Interpretation flags</h4><ul><li>covariate level 'WT effect on V1 V2' → Q900:wt_effect_on_v1_v2 = 1 (linear_fractional on Q22)</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=mitoxantrone</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Mitoxantrone_Brandon2026_reference;
