model Mitoxantrone_Launay1989_reference
  parameter Real Cl_ref = 6.5000000000000004e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.38549 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.4444809,
    adminMass = 1e-05
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About mitoxantrone</h4><p>Mitoxantrone is a cytotoxic drug used to treat several cancers, including breast cancer, prostate cancer, lymphoma and acute myeloid leukemia, and is also used in multiple sclerosis. It is an approved medicine, but carries a boxed warning, so its use is restricted to specialist care.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q239426\">Wikidata Q239426</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>mitoxantrone</td></tr><tr><td>population:</td><td>patients with breast cancer or acute nonlymphocytic leukemia</td></tr><tr><td>source_paper:</td><td>Launay_1989</td></tr><tr><td>measured_compound:</td><td>mitoxantrone</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>mitoxantrone 444.481 g/mol (drugbank)</td></tr></table><h4>Interpretation flags</h4><ul><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=mitoxantrone</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 864000, Tolerance = 1e-9, Interval = 1));
end Mitoxantrone_Launay1989_reference;
