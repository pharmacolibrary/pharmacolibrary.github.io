function p = Mitoxantrone_Launay1989_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: mitoxantrone   source: Launay_1989 / reference   route: iv_bolus
  % estimated (absent from source): F, dose
  p.name  = 'Mitoxantrone_Launay1989_reference_params';
  p.drug  = 'mitoxantrone';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'iv_bolus';        % 'oral' | 'iv_bolus'
  p.depot = false;             % oral -> first-order absorption depot
  p.Vc = 385.49;                % central volume [L]
  p.CL = 23.4;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.0;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 10.0;             % dose [mg]
end
