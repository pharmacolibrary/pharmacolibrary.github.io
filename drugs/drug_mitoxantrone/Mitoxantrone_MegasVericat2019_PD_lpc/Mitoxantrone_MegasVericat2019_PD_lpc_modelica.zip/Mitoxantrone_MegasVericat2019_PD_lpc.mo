model Mitoxantrone_MegasVericat2019_PD_lpc
  "sigmoid_emax exposure-response sweep — Megías-Vericat_2019 :: LPC (live pathological cells (natural log of LPC))"
  extends Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep(
    E0 = 7443,      // [cells]
    Emax = -1,  // [unitless]
    EC50 = 0.329,  // [μM]
    gamma = 0.77,
    exposure_per_s = 1);   // 1 μM per second
  // imax_as_negative_emax: Imax (Q323) enters SigmoidEmaxSweep as −Emax
  // exposure_unit_unresolved: 'μM' — the x axis is in the paper's unit, not SI
  annotation(experiment(StartTime = 0, StopTime = 3.3, Interval = 0.0066),
    Documentation(info = "<html><body><!-- drug-about --><h4>About mitoxantrone</h4><p>Mitoxantrone is a cytotoxic drug used to treat several cancers, including breast cancer, prostate cancer, lymphoma and acute myeloid leukemia, and is also used in multiple sclerosis. It is an approved medicine, but carries a boxed warning, so its use is restricted to specialist care.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q239426\">Wikidata Q239426</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h4>Mitoxantrone_MegasVericat2019_PD_lpc</h4><p>The steady-state exposure-response curve of Megías-Vericat JE et al., <i>Mediterranean journal of hematology and infectious diseases 11(1):e2019016</i> 2019 (<a href=\"https://doi.org/10.4084/MJHID.2019.016\">doi:10.4084/MJHID.2019.016</a>) — live pathological cells (natural log of LPC) [cells] against Mitoxantrone μM — obtained by sweeping the driver instead of simulating a dose. Model family: sigmoid_emax.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    =       7443 cells    drug-free response (baseline) (LPC0, Q324)
  Emax  =          1 unitless maximal effect term (Emax, Q323)
  EC50  =      0.329 μM       exposure at half of the maximal effect term (EC50, Q321)
  gamma =       0.77          Hill coefficient (γ, Q325)</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep\">SigmoidEmaxSweep</a>; this model only supplies the numbers. The x axis is one μM of Mitoxantrone per second of simulated time: there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 7443   (drug-free)
  exposure = EC50 (0.329 μM)  response 7442
  exposure -> infinity  response 7442</pre></body></html>"));
end Mitoxantrone_MegasVericat2019_PD_lpc;
