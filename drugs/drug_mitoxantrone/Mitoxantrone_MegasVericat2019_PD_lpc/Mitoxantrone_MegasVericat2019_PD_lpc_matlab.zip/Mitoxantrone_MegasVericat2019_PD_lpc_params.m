function p = Mitoxantrone_MegasVericat2019_PD_lpc_params()
% Mitoxantrone_MegasVericat2019_PD_lpc_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% mitoxantrone Megías-Vericat_2019::LPC: sigmoid_emax exposure-response sweep (response = E0 + Emax*frac). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one μM per second, in SI inside (kg/m3, s). Response LPC in cells. Driver: Mitoxantrone (cited_pk).
p.E0 = 7443.0;
p.Emax = -1.0;
p.EC50 = 0.329;
p.gamma = 0.77;
p.slope = 0.0;
p.exposure_per_s = 1.0;
p.stop_time = 3.3;
p.form = 'E0 + Emax*frac';
end
