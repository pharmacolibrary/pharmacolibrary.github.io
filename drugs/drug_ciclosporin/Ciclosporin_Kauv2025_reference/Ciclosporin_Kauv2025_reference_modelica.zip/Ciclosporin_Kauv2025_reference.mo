model Ciclosporin_Kauv2025_reference
  parameter Real Cl_ref = 3.972222222222223e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.0274 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 1.202635,
    adminMass = 0.00025,
    ka = 0.0003361111111111111,
    Tlag = 900.0,
    k12 = 7.299270072992701e-07,
    k21 = 3.0316810671517355e-09
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About ciclosporin</h4><p>Ciclosporin is an immunosuppressant used to treat autoimmune conditions such as rheumatoid arthritis, systemic lupus erythematosus, myasthenia gravis, and graft-versus-host disease, as well as certain eye conditions like dry eye syndromes. It is widely used and is included on the WHO essential medicines list; several products are authorised in the European Union, mainly for eye conditions, and it is also approved for veterinary use.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q367700\">Wikidata Q367700</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>ciclosporin</td></tr><tr><td>population:</td><td>review reference</td></tr><tr><td>source_paper:</td><td>Kauv_2025</td></tr><tr><td>measured_compound:</td><td>ciclosporin</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_2C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>ciclosporin 1202.63 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>built from REVIEW reference values (Kauv_2025) — secondary source</li><li>volume reported by review</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Ciclosporin_Kauv2025_reference;
