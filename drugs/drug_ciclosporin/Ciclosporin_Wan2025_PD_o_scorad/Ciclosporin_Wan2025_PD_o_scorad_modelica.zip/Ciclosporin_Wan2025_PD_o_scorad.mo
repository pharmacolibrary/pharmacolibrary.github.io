model Ciclosporin_Wan2025_PD_o_scorad
  "linear exposure-response sweep — Wan_2025 :: o-SCORAD (o-SCORAD scores)"
  extends Pharmacolibrary.Interfaces.PartialExposureResponseSweep(
    E0 = 0,      // [1]
    Emax = 0, EC50 = 1,      // unused by a line
    exposure_per_s = 1);
  parameter Real slope = -4.495   "[1]";
equation
  response = E0 + slope*exposure;
  // defaulted: E0
  annotation(experiment(StartTime = 0, StopTime = 1000, Interval = 2),
    Documentation(info = "<html><body><!-- drug-about --><h4>About ciclosporin</h4><p>Ciclosporin is an immunosuppressant used to treat autoimmune conditions such as rheumatoid arthritis, systemic lupus erythematosus, myasthenia gravis, and graft-versus-host disease, as well as certain eye conditions like dry eye syndromes. It is widely used and is included on the WHO essential medicines list; several products are authorised in the European Union, mainly for eye conditions, and it is also approved for veterinary use.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q367700\">Wikidata Q367700</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h4>Ciclosporin_Wan2025_PD_o_scorad</h4><p>The steady-state exposure-response curve of Wan M et al., <i>Clinical and experimental dermatology 50(8):1623–1627</i> 2025 (<a href=\"https://doi.org/10.1093/ced/llaf147\">doi:10.1093/ced/llaf147</a>) — o-SCORAD scores against ciclosporin — obtained by sweeping the driver instead of simulating a dose. Model family: linear.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = (library default) drug-free response (baseline)
  slope =     -4.495          change in response per unit of exposure (β, Q335)</pre><p>The algebra is <code>response = E0 + slope*exposure</code>; this model only supplies the numbers. The x axis is one  of ciclosporin per second of simulated time: there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0   (drug-free)</pre></body></html>"));
end Ciclosporin_Wan2025_PD_o_scorad;
