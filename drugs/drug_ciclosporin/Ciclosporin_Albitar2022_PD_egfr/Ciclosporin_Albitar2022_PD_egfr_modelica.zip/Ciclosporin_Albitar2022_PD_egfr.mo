model Ciclosporin_Albitar2022_PD_egfr
  "emax exposure-response sweep — Albitar_2022 :: eGFR (renal graft function response, quantified as estimated glomerular filtration rate (eGFR))"
  extends Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep(
    E0 = 12.9,      // [mL·min-1·1.73 m-2]
    Emax = 50.7,  // [mL·min-1·1.73 m-2]
    EC50 = 1740,  // [ng·h·mL-1]
    gamma = 1,
    exposure_per_s = 1);   // 1 ng·h·mL-1 per second
  // exposure_unit_unresolved: 'ng·h·mL-1' — the x axis is in the paper's unit, not SI
  // defaulted: gamma
  annotation(experiment(StartTime = 0, StopTime = 18000, Interval = 36),
    Documentation(info = "<html><body><!-- drug-about --><h4>About ciclosporin</h4><p>Ciclosporin is an immunosuppressant used to treat autoimmune conditions such as rheumatoid arthritis, systemic lupus erythematosus, myasthenia gravis, and graft-versus-host disease, as well as certain eye conditions like dry eye syndromes. It is widely used and is included on the WHO essential medicines list; several products are authorised in the European Union, mainly for eye conditions, and it is also approved for veterinary use.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q367700\">Wikidata Q367700</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h4>Ciclosporin_Albitar2022_PD_egfr</h4><p>The steady-state exposure-response curve of Albitar O et al., <i>Therapeutic drug monitoring 44(2):282–289</i> 2022 (<a href=\"https://doi.org/10.1097/FTD.0000000000000916\">doi:10.1097/FTD.0000000000000916</a>) — renal graft function response, quantified as estimated glomerular filtration rate (eGFR) [mL·min-1·1.73 m-2] against cyclosporine ng·h·mL-1 — obtained by sweeping the driver instead of simulating a dose. Model family: emax.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    =       12.9 mL·min-1·1.73 m-2 drug-free response (baseline) (baseline renal graft level, Q324)
  Emax  =       50.7 mL·min-1·1.73 m-2 maximal effect term (maximum effect, Q320)
  EC50  =       1740 ng·h·mL-1 exposure at half of the maximal effect term (area under the concentration-time curve achieving 50% of the maximum effect, Q321)
  gamma = (library default) Hill coefficient</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep\">SigmoidEmaxSweep</a>; this model only supplies the numbers. The x axis is one ng·h·mL-1 of cyclosporine per second of simulated time: there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 12.9   (drug-free)
  exposure = EC50 (1740 ng·h·mL-1)  response 38.25
  exposure -> infinity  response 63.6</pre></body></html>"));
end Ciclosporin_Albitar2022_PD_egfr;
