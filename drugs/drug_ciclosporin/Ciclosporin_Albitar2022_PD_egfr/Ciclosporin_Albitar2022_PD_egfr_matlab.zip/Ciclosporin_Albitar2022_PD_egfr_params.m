function p = Ciclosporin_Albitar2022_PD_egfr_params()
% Ciclosporin_Albitar2022_PD_egfr_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% ciclosporin Albitar_2022::eGFR: emax exposure-response sweep (response = E0 + Emax*frac). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one ng·h·mL-1 per second, in SI inside (kg/m3, s). Response eGFR in mL·min-1·1.73 m-2. Driver: cyclosporine (dose_only).
p.E0 = 12.9;
p.Emax = 50.7;
p.EC50 = 1740.0;
p.gamma = 1.0;
p.slope = 0.0;
p.exposure_per_s = 1.0;
p.stop_time = 18000.0;
p.form = 'E0 + Emax*frac';
end
