function p = Ciclosporin_Wan2025_PD_easi_params()
% Ciclosporin_Wan2025_PD_easi_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% ciclosporin Wan_2025::EASI: linear exposure-response sweep (response = E0 + slope*exposure). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one SI per second, in SI inside (kg/m3, s). Response EASI in its own unit. Driver: ciclosporin (cited_pk).
p.E0 = 0.0;
p.Emax = 0.0;
p.EC50 = 1.0;
p.gamma = 1.0;
p.slope = -0.586;
p.exposure_per_s = 1.0;
p.stop_time = 1000.0;
p.form = 'E0 + slope*exposure';
end
