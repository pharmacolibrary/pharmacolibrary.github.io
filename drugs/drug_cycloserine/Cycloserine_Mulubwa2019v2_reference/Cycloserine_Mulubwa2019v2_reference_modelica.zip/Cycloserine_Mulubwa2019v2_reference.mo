model Cycloserine_Mulubwa2019v2_reference
  parameter Real Cl_ref = 3.833333333333333e-07 "Cl [m3/s]";
  parameter Real Vd_ref = 0.010492143954369076 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.1020919,
    adminMass = 0.00075,
    ka = 3.7500000000000003e-05,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About cycloserine</h4><p>Cycloserine is an antibiotic used to treat tuberculosis and has also been studied for Gaucher's disease. It is an approved medicine, appears on the WHO essential medicines list, and is used mainly as part of tuberculosis treatment.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q418508\">Wikidata Q418508</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>cycloserine</td></tr><tr><td>population:</td><td>review reference</td></tr><tr><td>source_paper:</td><td>Mulubwa_2019_2</td></tr><tr><td>measured_compound:</td><td>cycloserine</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>cycloserine 102.092 g/mol (drugbank)</td></tr></table><p><b>Defaulted (base-class default used):</b> Tlag.</p><h4>Interpretation flags</h4><ul><li>built from REVIEW reference values (Mulubwa_2019_2) — secondary source</li><li>central volume derived from CL·t½/ln2</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 259200, Tolerance = 1e-9, Interval = 1));
end Cycloserine_Mulubwa2019v2_reference;
