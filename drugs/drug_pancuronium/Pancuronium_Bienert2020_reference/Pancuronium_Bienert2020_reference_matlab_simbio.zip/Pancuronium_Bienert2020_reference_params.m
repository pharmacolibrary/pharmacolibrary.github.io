function p = Pancuronium_Bienert2020_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: pancuronium   source: Bienert_2020 / reference   route: oral
  % estimated (absent from source): ka, dose
  p.name  = 'Pancuronium_Bienert2020_reference_params';
  p.drug  = 'pancuronium';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 25.8;                % central volume [L]
  p.CL = 34.14;                % clearance [L/h]
  p.Vp = [478.0];             % peripheral volumes [L]
  p.Q  = [113.4];             % inter-compartmental clearances [L/h]
  p.ka = 0.5;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 100.0;             % dose [mg]
end
