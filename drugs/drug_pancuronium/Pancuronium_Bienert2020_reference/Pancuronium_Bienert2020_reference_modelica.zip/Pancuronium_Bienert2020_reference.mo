model Pancuronium_Bienert2020_reference
  parameter Real Cl_ref = 9.483333333333333e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.0258 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.5728619,
    adminMass = 0.0001,
    ka = 0.0001388888888888889,
    Tlag = 0.0,
    k12 = 0.0012209302325581395,
    k21 = 6.589958158995816e-05
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About pancuronium</h4><p>Pancuronium is a non-depolarising neuromuscular blocking agent used to relax muscles, for example during surgery. It is an approved medicine and remains in use as a peripherally acting muscle relaxant.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q424297\">Wikidata Q424297</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>pancuronium</td></tr><tr><td>population:</td><td>review reference</td></tr><tr><td>source_paper:</td><td>Bienert_2020</td></tr><tr><td>measured_compound:</td><td>pancuronium</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_2C_enteral: apparent (/F) parameterization ⇒ extravascular dosing</td></tr><tr><td>molar_masses:</td><td>pancuronium 572.862 g/mol (drugbank)</td></tr></table><p><b>Defaulted (base-class default used):</b> ka, Tlag.</p><h4>Interpretation flags</h4><ul><li>built from REVIEW reference values (Bienert_2020) — secondary source</li><li>volume reported by review</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Pancuronium_Bienert2020_reference;
