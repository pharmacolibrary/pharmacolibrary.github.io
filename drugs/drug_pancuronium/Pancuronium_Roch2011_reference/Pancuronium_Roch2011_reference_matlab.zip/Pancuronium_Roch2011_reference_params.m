function p = Pancuronium_Roch2011_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: pancuronium   source: Roch_2011 / reference   route: iv_bolus
  % estimated (absent from source): F, dose
  p.name  = 'Pancuronium_Roch2011_reference_params';
  p.drug  = 'pancuronium';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'iv_bolus';        % 'oral' | 'iv_bolus'
  p.depot = false;             % oral -> first-order absorption depot
  p.Vc = 0.96;                % central volume [L]
  p.CL = 0.21;                % clearance [L/h]
  p.Vp = [2.8];             % peripheral volumes [L]
  p.Q  = [8.16];             % inter-compartmental clearances [L/h]
  p.ka = 0.0;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 10.0;             % dose [mg]
end
