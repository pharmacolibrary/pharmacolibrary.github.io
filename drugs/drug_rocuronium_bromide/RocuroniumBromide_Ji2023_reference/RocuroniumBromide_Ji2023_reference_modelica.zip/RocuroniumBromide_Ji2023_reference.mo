model RocuroniumBromide_Ji2023_reference
  parameter Real Cl_ref = 1.1666666666666668e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.00149 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.5297742,
    adminMass = 1e-05,
    k12 = 0.0021029082774049216,
    k21 = 0.0013864306784660769
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About rocuronium_bromide</h4><p>Rocuronium bromide is a non-depolarising neuromuscular blocking agent (muscle relaxant) used to relax muscles, for example during surgery and procedures requiring intubation. It is an approved medicine and is widely used in anaesthesia, mainly in hospital settings.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q185331\">Wikidata Q185331</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>rocuronium_bromide</td></tr><tr><td>population:</td><td>review reference</td></tr><tr><td>source_paper:</td><td>Ji_2023</td></tr><tr><td>measured_compound:</td><td>rocuronium_bromide</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_2C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>rocuronium_bromide 529.774 g/mol (drugbank)</td></tr></table><h4>Interpretation flags</h4><ul><li>built from REVIEW reference values (Ji_2023) — secondary source</li><li>volume reported by review</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end RocuroniumBromide_Ji2023_reference;
