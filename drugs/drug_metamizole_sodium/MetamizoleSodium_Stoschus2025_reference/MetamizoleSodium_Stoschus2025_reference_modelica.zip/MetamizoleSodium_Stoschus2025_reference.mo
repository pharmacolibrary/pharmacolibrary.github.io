model MetamizoleSodium_Stoschus2025_reference
  parameter Real Cl_ref = 1.0555555555555557e-07 "Cl [m3/s]";
  parameter Real Vd_ref = 0.0343 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 0.9,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.333338,
    adminMass = 0.0007,
    ka = 0.0005277777777777777,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>metamizole_sodium</td></tr><tr><td>population:</td><td>review reference</td></tr><tr><td>source_paper:</td><td>Stoschus_2025</td></tr><tr><td>measured_compound:</td><td>metamizole_sodium</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>metamizole_sodium 333.338 g/mol (pubchem)</td></tr></table><p><b>Defaulted (base-class default used):</b> F, Tlag.</p><h4>Interpretation flags</h4><ul><li>built from REVIEW reference values (Stoschus_2025) — secondary source</li><li>volume reported by review</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 1209600, Tolerance = 1e-9, Interval = 1));
end MetamizoleSodium_Stoschus2025_reference;
