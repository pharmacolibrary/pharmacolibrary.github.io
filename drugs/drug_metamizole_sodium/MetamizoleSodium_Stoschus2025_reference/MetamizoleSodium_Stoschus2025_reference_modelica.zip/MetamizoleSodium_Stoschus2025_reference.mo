model MetamizoleSodium_Stoschus2025_reference
  parameter Real Cl_ref = 8.722222222222221e-08 "Cl [m3/s]";
  parameter Real Vd_ref = 0.0343 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.333338,
    adminMass = 0.003,
    ka = 0.0005277777777777777,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About metamizole_sodium</h4><p>Metamizole (dipyrone) is a pyrazolone painkiller and fever reducer used to treat pain and fever. It has been withdrawn in some countries over safety concerns, though it remains available in others.</p><p><small><b>Unverified</b> — written by glm-5.3-flash from general knowledge (no Wikidata entry found) and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>metamizole_sodium</td></tr><tr><td>population:</td><td>review reference</td></tr><tr><td>source_paper:</td><td>Stoschus_2025</td></tr><tr><td>measured_compound:</td><td>metamizole_sodium</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>metamizole_sodium 333.338 g/mol (pubchem)</td></tr></table><p><b>Defaulted (base-class default used):</b> Tlag.</p><h4>Interpretation flags</h4><ul><li>built from REVIEW reference values (Stoschus_2025) — secondary source</li><li>volume reported by review</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 1382400, Tolerance = 1e-9, Interval = 1));
end MetamizoleSodium_Stoschus2025_reference;
