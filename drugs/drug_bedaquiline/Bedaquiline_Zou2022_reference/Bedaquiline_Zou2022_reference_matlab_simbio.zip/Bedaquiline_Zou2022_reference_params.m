function p = Bedaquiline_Zou2022_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: bedaquiline   source: Zou_2022 / reference   route: oral
  p.name  = 'Bedaquiline_Zou2022_reference_params';
  p.drug  = 'bedaquiline';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 227.0;                % central volume [L]
  p.CL = 4.54;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.447;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 86.0;             % dose [mg]
end
