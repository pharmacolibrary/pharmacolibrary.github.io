model Bedaquiline_Zou2022_reference
  parameter Real Cl_ref = 1.261111111111111e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.227 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.555505,
    adminMass = 8.6e-05,
    ka = 0.00012416666666666666,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About bedaquiline</h4><p>Bedaquiline is an antituberculous drug used to treat multidrug-resistant pulmonary tuberculosis. It is authorised in the European Union and is included on the WHO list of essential medicines, so it is used widely for this indication.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q1257318\">Wikidata Q1257318</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>bedaquiline</td></tr><tr><td>population:</td><td>adult patients with multidrug-resistant tuberculosis</td></tr><tr><td>source_paper:</td><td>Zou_2022</td></tr><tr><td>measured_compound:</td><td>bedaquiline</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>T3</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>bedaquiline 555.505 g/mol (drugbank)</td></tr></table><p><b>Defaulted (base-class default used):</b> Tlag.</p><h4>Interpretation flags</h4><ul><li>table section iiv: 'η(CL/F)' routed out of structural estimates ('Interindividual variability (%)')</li><li>table section iiv: 'η(CL/F)' routed out of structural estimates ('Interindividual variability (%)')</li><li>table section iiv: 'η(Vc/F)' routed out of structural estimates ('Interindividual variability (%)')</li><li>table section iiv: 'η(Vc/F)' routed out of structural estimates ('Interindividual variability (%)')</li><li>table section residual_error: 'εprop' routed out of structural estimates ('Residual variability (%)')</li><li>table section residual_error: 'εprop' routed out of structural estimates ('Residual variability (%)')</li><li>dropped duplicate Q27 ('θGGT on CL/F', value '-0.476') — already have one for this compound</li><li>dropped duplicate Q27 ('θrs319952 on CL/F', value '-1.4') — already have one for this compound</li><li>apparent-ness (ontology-grounded): parameterization=apparent, measured_compound=bedaquiline</li><li>1C volume normalization: Q290→Q76 (single-compartment model has no central/peripheral split; 'Vc/F (L)' is the general volume)</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of TLAG: primary's parameterization (rate-constant / ka-only) does not use it</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 691200, Tolerance = 1e-9, Interval = 1));
end Bedaquiline_Zou2022_reference;
