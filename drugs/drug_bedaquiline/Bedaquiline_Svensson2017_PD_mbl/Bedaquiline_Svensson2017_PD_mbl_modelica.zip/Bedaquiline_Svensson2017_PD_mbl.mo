model Bedaquiline_Svensson2017_PD_mbl
  "emax exposure-response sweep — Svensson_2017 :: MBL (mycobacterial load (MBL))"
  extends Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep(
    E0 = 0,      // [1]
    Emax = -1,  // [FIX]
    EC50 = 0.00142,  // [kg/m3; mg/L × 0.001]
    gamma = 1,
    exposure_per_s = 0.001);   // 1 mg/L per second
  // imax_as_negative_emax: Imax (Q323) enters SigmoidEmaxSweep as −Emax
  // defaulted: E0
  // defaulted: gamma
  annotation(experiment(StartTime = 0, StopTime = 15, Interval = 0.03),
    Documentation(info = "<html><body><!-- drug-about --><h4>About bedaquiline</h4><p>Bedaquiline is an antituberculous drug used to treat multidrug-resistant pulmonary tuberculosis. It is authorised in the European Union and is included on the WHO list of essential medicines, so it is used widely for this indication.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q1257318\">Wikidata Q1257318</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h4>Bedaquiline_Svensson2017_PD_mbl</h4><p>The steady-state exposure-response curve of Svensson EM et al., <i>The Journal of antimicrobial chemotherapy 72(12):3398–3405</i> 2017 (<a href=\"https://doi.org/10.1093/jac/dkx317\">doi:10.1093/jac/dkx317</a>) — mycobacterial load (MBL) [n bacteria/inoculum] against bedaquiline mg/L — obtained by sweeping the driver instead of simulating a dose. Model family: emax.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = (library default) drug-free response (baseline)
  Emax  =         -1 FIX      maximal effect term (bedaquiline maximal effect on half-life MBL, Q323)
  EC50  =       1.42 mg/L     exposure at half of the maximal effect term (EC50 bedaquiline effect on half-life MBL, Q321)
  gamma = (library default) Hill coefficient</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep\">SigmoidEmaxSweep</a>; this model only supplies the numbers. The x axis is one mg/L of bedaquiline per second of simulated time (exposure is in kg/m3): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0   (drug-free)
  exposure = EC50 (1.42 mg/L)  response -0.5
  exposure -> infinity  response -1</pre></body></html>"));
end Bedaquiline_Svensson2017_PD_mbl;
