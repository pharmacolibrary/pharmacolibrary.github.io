function p = Bedaquiline_Svensson2017_PD_mbl_params()
% Bedaquiline_Svensson2017_PD_mbl_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% bedaquiline Svensson_2017::MBL: emax exposure-response sweep (response = E0 + Emax*frac). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one mg/L per second, in SI inside (kg/m3, s). Response MBL in n bacteria/inoculum. Driver: bedaquiline (cited_pk).
p.E0 = 0.0;
p.Emax = -1.0;
p.EC50 = 0.0014199999999999996;
p.gamma = 1.0;
p.slope = 0.0;
p.exposure_per_s = 0.001;
p.stop_time = 15.0;
p.form = 'E0 + Emax*frac';
end
