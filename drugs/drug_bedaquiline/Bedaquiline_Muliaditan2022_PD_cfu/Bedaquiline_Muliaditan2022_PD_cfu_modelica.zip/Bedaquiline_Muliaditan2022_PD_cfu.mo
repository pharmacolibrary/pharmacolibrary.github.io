model Bedaquiline_Muliaditan2022_PD_cfu
  "emax exposure-response sweep — Muliaditan_2022 :: CFU (bacterial growth dynamics of fast-growing M. tuberculosis)"
  extends Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep(
    E0 = 0,      // [1]
    Emax = -1.86388888889e-05,  // [1/s; h−1 × 0.000277778]
    EC50 = 0.000192,  // [kg/m3; mg·L−1 × 0.001]
    gamma = 1,
    exposure_per_s = 0.001);   // 1 mg·L−1 per second
  // imax_as_negative_emax: Imax (Q323) enters SigmoidEmaxSweep as −Emax
  // defaulted: E0
  // defaulted: gamma
  annotation(experiment(StartTime = 0, StopTime = 2, Interval = 0.004),
    Documentation(info = "<html><body><!-- drug-about --><h4>About bedaquiline</h4><p>Bedaquiline is an antituberculous drug used to treat multidrug-resistant pulmonary tuberculosis. It is authorised in the European Union and is included on the WHO list of essential medicines, so it is used widely for this indication.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q1257318\">Wikidata Q1257318</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h4>Bedaquiline_Muliaditan2022_PD_cfu</h4><p>The steady-state exposure-response curve of Muliaditan M et al., <i>British journal of pharmacology 179(6):1251–1263</i> 2022 (<a href=\"https://doi.org/10.1111/bph.15688\">doi:10.1111/bph.15688</a>) — bacterial growth dynamics of fast-growing M. tuberculosis [log10 CFU per lung] against bedaquiline mg·L−1 — obtained by sweeping the driver instead of simulating a dose. Model family: emax.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = (library default) drug-free response (baseline)
  Emax  =     0.0671 h−1      maximal effect term (Maximum killing rate, Q323)
  EC50  =      0.192 mg·L−1   exposure at half of the maximal effect term (Potency against fast‐growing population, HDA infection route, Q322)
  gamma = (library default) Hill coefficient</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep\">SigmoidEmaxSweep</a>; this model only supplies the numbers. The x axis is one mg·L−1 of bedaquiline per second of simulated time (exposure is in kg/m3): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0   (drug-free)
  exposure = EC50 (0.192 mg·L−1)  response -9.319e-06
  exposure -> infinity  response -1.864e-05</pre></body></html>"));
end Bedaquiline_Muliaditan2022_PD_cfu;
