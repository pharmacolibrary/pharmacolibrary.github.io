function p = Bedaquiline_Muliaditan2022_PD_cfu_2_params()
% Bedaquiline_Muliaditan2022_PD_cfu_2_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% bedaquiline Muliaditan_2022::CFU::2: emax exposure-response sweep (response = E0 + Emax*frac). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one mg·L−1 per second, in SI inside (kg/m3, s). Response CFU in log10 CFU per lung. Driver: bedaquiline (cited_pk).
p.E0 = 0.0;
p.Emax = -1.863888888888889e-05;
p.EC50 = 0.0030399999999999993;
p.gamma = 1.0;
p.slope = 0.0;
p.exposure_per_s = 0.001;
p.stop_time = 31.0;
p.form = 'E0 + Emax*frac';
end
