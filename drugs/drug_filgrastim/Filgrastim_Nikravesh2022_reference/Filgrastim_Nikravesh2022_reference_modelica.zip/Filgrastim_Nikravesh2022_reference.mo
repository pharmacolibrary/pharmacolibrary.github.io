model Filgrastim_Nikravesh2022_reference
  parameter Real Cl_ref = 8.419444444444443e-07 "Cl [m3/s]";
  parameter Real Vd_ref = 0.007433774737188562 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    adminMass = 0.0001,
    ka = 0.0003388888888888889,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About filgrastim</h4><p>Filgrastim, a granulocyte colony-stimulating factor, is used to treat neutropenia and related blood disorders, and to support patients with cancers such as leukemia and lymphoma. It is widely used and appears on the WHO essential medicines list, with several products authorised in the European Union.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q3151081\">Wikidata Q3151081</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>filgrastim</td></tr><tr><td>population:</td><td>review reference</td></tr><tr><td>source_paper:</td><td>Nikravesh_2022</td></tr><tr><td>measured_compound:</td><td>filgrastim</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr></table><p><b>Defaulted (base-class default used):</b> Tlag.</p><h4>Interpretation flags</h4><ul><li>built from REVIEW reference values (Nikravesh_2022) — secondary source</li><li>central volume derived from CL·t½/ln2</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Filgrastim_Nikravesh2022_reference;
