model Filgrastim_Wang2001_PD_anc
  "indirect_response_iii exposure-response sweep — Wang_2001 :: ANC (absolute neutrophil count)"
  extends Pharmacolibrary.Interfaces.PartialExposureResponseSweep(
    E0 = 0,      // [1]
    Emax = 12.7,  // type III effect term
    EC50 = 4.72e-06,  // [kg/m3; ng/ml × 1e-06]
    gamma = 1.34,
    exposure_per_s = 1e-06);   // 1 ng/ml per second
equation
  response = E0*(1 + Emax*frac);   // steady state, indirect response type III
  // defaulted: E0
  annotation(experiment(StartTime = 0, StopTime = 48, Interval = 0.096),
    Documentation(info = "<html><body><!-- drug-about --><h4>About filgrastim</h4><p>Filgrastim, a granulocyte colony-stimulating factor, is used to treat neutropenia and related blood disorders, and to support patients with cancers such as leukemia and lymphoma. It is widely used and appears on the WHO essential medicines list, with several products authorised in the European Union.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q3151081\">Wikidata Q3151081</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h4>Filgrastim_Wang2001_PD_anc</h4><p>The steady-state exposure-response curve of Wang B et al., <i>Journal of pharmacokinetics and pharmacodynamics 28(4):321–342</i> 2001 (<a href=\"https://doi.org/10.1023/a:1011534529622\">doi:10.1023/a:1011534529622</a>) — absolute neutrophil count against Filgrastim ng/ml — obtained by sweeping the driver instead of simulating a dose. Model family: indirect_response_iii.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = (library default) drug-free response (baseline)
  Emax  =       12.7          maximal effect term (Emax, Q320)
  EC50  =       4.72 ng/ml    exposure at half of the maximal effect term (EC50, Q321)
  gamma =       1.34          Hill coefficient (Hill, Q325)</pre><p>The algebra is <code>response = E0*(1 + Emax*frac)</code>; this model only supplies the numbers. The x axis is one ng/ml of Filgrastim per second of simulated time (exposure is in kg/m3): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0   (drug-free)
  exposure = EC50 (4.72 ng/ml)  response 0
  exposure -> infinity  response 0</pre></body></html>"));
end Filgrastim_Wang2001_PD_anc;
