function p = Filgrastim_Wang2001_PD_anc_params()
% Filgrastim_Wang2001_PD_anc_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% filgrastim Wang_2001::ANC: indirect_response_iii exposure-response sweep (response = E0*(1 + Emax*frac)). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one ng/ml per second, in SI inside (kg/m3, s). Response ANC in its own unit. Driver: Filgrastim (pk_record).
p.E0 = 0.0;
p.Emax = 12.7;
p.EC50 = 4.72e-06;
p.gamma = 1.34;
p.slope = 0.0;
p.exposure_per_s = 1e-06;
p.stop_time = 48.0;
p.form = 'E0*(1 + Emax*frac)';
end
