model Sotrovimab_Sager2023_reference
  parameter Real Cl_ref = 1.5393518518518518e-08 "Cl [m3/s]";
  parameter Real cov_bmi = 1.0 "bmi covariate (reference 1.0)";
  parameter Boolean cov_category_1 = false "category level 1";
  parameter Real Vd_ref = 0.0022 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref*(cov_bmi/1.0)^(20.0) + (1.3773148148148148e-07)*(if cov_category_1 then 1 else 0),
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    adminMass = 0.00025,
    k12 = 7.838804713804713e-06,
    k21 = 1.3064674523007855e-05
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About sotrovimab</h4><p>Sotrovimab is a monoclonal antibody used to treat COVID-19. It has been approved and used against COVID-19, though its marketing authorisation in the European Union has been withdrawn.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q106943333\">Wikidata Q106943333</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>sotrovimab</td></tr><tr><td>population:</td><td>patients with mild to moderate COVID-19</td></tr><tr><td>source_paper:</td><td>Sager_2023</td></tr><tr><td>measured_compound:</td><td>sotrovimab</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>psp412958-tbl-0001</td></tr><tr><td>input:</td><td>PK_2C: IV (no input phase)</td></tr></table><h4>Interpretation flags</h4><ul><li>covariate level 'Power of BMI effect' → Q900:power_of_bmi_effect = 20.0 (power on Q22)</li><li>covariate level 'Proportional shift in female participants' → Q900:proportional_shift_in_female_participants = 11.9 (additive_shift on Q22)</li><li>dropped unlinked row (NIL): 'Rate of input (mg/h)' — extend the ontology if this is a real PK parameter (source ['psp412958-tbl-0001:row20:col1', 'psp412958-tbl-0001:row20:col2'])</li><li>dropped unlinked row (NIL): 'Minimum value of the objective function = 48,830.476' — extend the ontology if this is a real PK parameter (source ['psp412958-tbl-0001:row33:col1', 'psp412958-tbl-0001:row33:col2', 'psp412958-tbl-0001:row33:col3', 'psp412958-tbl-0001:row33:col4'])</li><li>covariate effect for Q319 has no base parameter row (kept as unattached equation-variable)</li><li>covariate effect for Q49 has no base parameter row (kept as unattached equation-variable)</li><li>covariate effect for Q900 has no base parameter row (kept as unattached equation-variable)</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=sotrovimab</li><li>molar mass: none found for 'sotrovimab' — its concentrations stay mass-only</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 518400, Tolerance = 1e-9, Interval = 1));
end Sotrovimab_Sager2023_reference;
