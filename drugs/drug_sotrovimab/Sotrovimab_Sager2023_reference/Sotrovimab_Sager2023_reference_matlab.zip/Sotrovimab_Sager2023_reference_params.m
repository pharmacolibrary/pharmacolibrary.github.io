function p = Sotrovimab_Sager2023_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: sotrovimab   source: Sager_2023 / reference   route: iv_bolus
  p.name  = 'Sotrovimab_Sager2023_reference_params';
  p.drug  = 'sotrovimab';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'iv_bolus';        % 'oral' | 'iv_bolus'
  p.depot = false;             % oral -> first-order absorption depot
  p.Vc = 2.2;                % central volume [L]
  p.CL = 0.055417;                % clearance [L/h]
  p.Vp = [1.32];             % peripheral volumes [L]
  p.Q  = [0.062083];             % inter-compartmental clearances [L/h]
  p.ka = 0.0;                % absorption rate [1/h]
  p.F  = 0.0264;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 250.0;             % dose [mg]
end
