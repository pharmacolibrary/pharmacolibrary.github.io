model Sotrovimab_SnchezPearson2025_reference
  parameter Real Cl_ref = 9.375e-10 "Cl [m3/s]";
  parameter Real Vd_ref = 0.006059999999999999 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    adminMass = 0.0005
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About sotrovimab</h4><p>Sotrovimab is a monoclonal antibody used to treat COVID-19. It has been approved and used against COVID-19, though its marketing authorisation in the European Union has been withdrawn.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q106943333\">Wikidata Q106943333</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>sotrovimab</td></tr><tr><td>population:</td><td>review reference</td></tr><tr><td>source_paper:</td><td>Sánchez-Pearson_2025</td></tr><tr><td>measured_compound:</td><td>sotrovimab</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C: IV (no input phase)</td></tr></table><h4>Interpretation flags</h4><ul><li>built from REVIEW reference values (Sánchez-Pearson_2025) — secondary source</li><li>volume reported by review</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 15552000, Tolerance = 1e-9, Interval = 1));
end Sotrovimab_SnchezPearson2025_reference;
