model Niraparib_Quesada2025_reference
  parameter Real Cl_ref = 3.1666666666666667e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 1.014 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.320396,
    adminMass = 0.0003,
    ka = 0.0002361111111111111,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About niraparib</h4><p>Niraparib is a PARP inhibitor anticancer medicine used to treat ovarian, fallopian tube, and peritoneal cancers. It is authorised in the European Union and is an approved drug, used in cancer care.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q25326660\">Wikidata Q25326660</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>niraparib</td></tr><tr><td>population:</td><td>review reference</td></tr><tr><td>source_paper:</td><td>Quesada_2025</td></tr><tr><td>measured_compound:</td><td>niraparib</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>niraparib 320.396 g/mol (drugbank)</td></tr></table><p><b>Defaulted (base-class default used):</b> Tlag.</p><h4>Interpretation flags</h4><ul><li>built from REVIEW reference values (Quesada_2025) — secondary source</li><li>volume reported by review</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 1123200, Tolerance = 1e-9, Interval = 1));
end Niraparib_Quesada2025_reference;
