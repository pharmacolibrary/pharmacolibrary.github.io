model Niraparib_Gaffney2026_reference
  parameter Real Cl_ref = 4.416666666666667e-06 "Cl [m3/s]";
  parameter Real cov_weight = 1.0 "weight covariate (reference 1.0)";
  parameter Real Vd_ref = 0.45 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref*(cov_weight/1.0)^(0.287)*(cov_weight/1.0)^(0.363)*(cov_weight/1.0)^(1.02)*(cov_weight/1.0)^(0.742),
    Vd = Vd_ref*(cov_weight/1.0)^(0.577),
    adminDuration = 600,
    adminCount = 1,
    MM = 0.320396,
    adminMass = 0.0003,
    ka = 0.0002361111111111111,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About niraparib</h4><p>Niraparib is a PARP inhibitor anticancer medicine used to treat ovarian, fallopian tube, and peritoneal cancers. It is authorised in the European Union and is an approved drug, used in cancer care.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q25326660\">Wikidata Q25326660</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>niraparib</td></tr><tr><td>population:</td><td>patients with advanced solid tumors or ovarian cancer</td></tr><tr><td>source_paper:</td><td>Gaffney_2026</td></tr><tr><td>measured_compound:</td><td>niraparib</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>jcph70210-tbl-0003</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>niraparib 320.396 g/mol (drugbank)</td></tr></table><p><b>Defaulted (base-class default used):</b> Tlag.</p><h4>Interpretation flags</h4><ul><li>dropped duplicate Q290 ('Vp1/F, L', value '395') — already have one for this compound</li><li>dropped duplicate Q69 ('Q2/F, L/h', value '2.19') — already have one for this compound</li><li>covariate level 'CL/F ∼ CrCLBL exponent' → Q900:cl_f_crclbl_exponent = 0.287 (power on Q27)</li><li>covariate level 'Vc/F ∼ ALBBL exponent' → Q900:vc_f_albbl_exponent = 0.363 (power on Q27)</li><li>covariate level 'Vp1/F ∼ ALBBL exponent' → Q900:vp1_f_albbl_exponent = 1.02 (power on Q27)</li><li>dropped unlinked row (NIL): 'F1 ∼ fed fractional change' — extend the ontology if this is a real PK parameter (source ['jcph70210-tbl-0003:row15:col1', 'jcph70210-tbl-0003:row15:col2'])</li><li>dropped duplicate Q81 ('MTT ∼ fed fractional change', value '1.15') — already have one for this compound</li><li>covariate effect for Q319 has no base parameter row (kept as unattached equation-variable)</li><li>apparent-ness (ontology-grounded): parameterization=apparent, measured_compound=niraparib</li><li>structure disagreement: deterministic 1C vs LLM 3C — review compartment count</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>gap-filled Q49 (kabs) from Quesada_2025's review values (primary lacked it)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 432000, Tolerance = 1e-9, Interval = 1));
end Niraparib_Gaffney2026_reference;
