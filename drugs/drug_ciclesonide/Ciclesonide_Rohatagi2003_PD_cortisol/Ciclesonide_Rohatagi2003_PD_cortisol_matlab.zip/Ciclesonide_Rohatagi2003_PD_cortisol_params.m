function p = Ciclesonide_Rohatagi2003_PD_cortisol_params()
% Ciclesonide_Rohatagi2003_PD_cortisol_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% ciclesonide Rohatagi_2003::cortisol: indirect_response_i exposure-response sweep (response = E0*(1 - Emax*frac)). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one ng/mL per second, in SI inside (kg/m3, s). Response cortisol in ng/h. Driver: ciclesonide--active principle (CIC-AP) (conc_no_pk).
p.E0 = 0.0;
p.Emax = 1.0;
p.EC50 = 8.799999999999999e-07;
p.gamma = 1.0;
p.slope = 0.0;
p.exposure_per_s = 1e-06;
p.stop_time = 8.8;
p.form = 'E0*(1 - Emax*frac)';
end
