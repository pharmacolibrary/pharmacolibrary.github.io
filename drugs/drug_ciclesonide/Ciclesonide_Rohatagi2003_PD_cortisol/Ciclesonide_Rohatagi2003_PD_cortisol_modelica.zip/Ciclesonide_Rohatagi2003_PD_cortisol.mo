model Ciclesonide_Rohatagi2003_PD_cortisol
  "indirect_response_i exposure-response sweep — Rohatagi_2003 :: cortisol (endogenous cortisol)"
  extends Pharmacolibrary.Interfaces.PartialExposureResponseSweep(
    E0 = 0,      // [1]
    Emax = 1,  // type I effect term
    EC50 = 8.8e-07,  // [kg/m3; ng/mL × 1e-06]
    gamma = 1,
    exposure_per_s = 1e-06);   // 1 ng/mL per second
equation
  response = E0*(1 - Emax*frac);   // steady state, indirect response type I
  // defaulted: E0
  // defaulted: Emax
  // defaulted: gamma
  annotation(experiment(StartTime = 0, StopTime = 8.8, Interval = 0.0176),
    Documentation(info = "<html><body><!-- drug-about --><h4>About ciclesonide</h4><p>Ciclesonide is a glucocorticoid used to treat allergic rhinitis and obstructive airway diseases such as asthma. It is an approved medicine, available as a nasal spray and as an inhaler, and is used in routine clinical practice.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q5119448\">Wikidata Q5119448</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h4>Ciclesonide_Rohatagi2003_PD_cortisol</h4><p>The steady-state exposure-response curve of Rohatagi S et al., <i>Journal of clinical pharmacology 43(4):365–378</i> 2003 (<a href=\"https://doi.org/10.1177/0091270002250998\">doi:10.1177/0091270002250998</a>) — endogenous cortisol [ng/h] against ciclesonide--active principle (CIC-AP) ng/mL — obtained by sweeping the driver instead of simulating a dose. Model family: indirect_response_i.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = (library default) drug-free response (baseline)
  Emax  = (library default) maximal effect term
  EC50  =       0.88 ng/mL    exposure at half of the maximal effect term (EC50 of CIC-AP, Q321)
  gamma = (library default) Hill coefficient</pre><p>The algebra is <code>response = E0*(1 - Emax*frac)</code>; this model only supplies the numbers. The x axis is one ng/mL of ciclesonide--active principle (CIC-AP) per second of simulated time (exposure is in kg/m3): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0   (drug-free)
  exposure = EC50 (0.88 ng/mL)  response 0
  exposure -> infinity  response 0</pre></body></html>"));
end Ciclesonide_Rohatagi2003_PD_cortisol;
