function p = Rosuvastatin_Courlet2021_PD_non_hdl_c_params()
% Rosuvastatin_Courlet2021_PD_non_hdl_c_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% rosuvastatin Courlet_2021::non_HDL_C: indirect_response_i exposure-response sweep (response = E0*(1 - Emax*frac)). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one ng/mL per second, in SI inside (kg/m3, s). Response non-HDL-C in mmol/L. Driver: rosuvastatin (pk_record).
p.E0 = 3.5999999999999996;
p.Emax = 1.0;
p.EC50 = 1.58e-05;
p.gamma = 1.0;
p.slope = 0.0;
p.exposure_per_s = 1e-06;
p.stop_time = 160.0;
p.form = 'E0*(1 - Emax*frac)';
end
