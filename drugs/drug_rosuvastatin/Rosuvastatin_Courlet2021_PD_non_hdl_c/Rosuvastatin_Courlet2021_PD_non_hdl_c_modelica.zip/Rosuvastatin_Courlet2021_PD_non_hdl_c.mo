model Rosuvastatin_Courlet2021_PD_non_hdl_c
  "indirect_response_i exposure-response sweep — Courlet_2021 :: non-HDL-C (non-HDL-cholesterol)"
  extends Pharmacolibrary.Interfaces.PartialExposureResponseSweep(
    E0 = 3.6,      // [mol/m3; mmol·L−1 × 1]
    Emax = 1,  // type I effect term
    EC50 = 1.58e-05,  // [kg/m3; ng/mL × 1e-06]
    gamma = 1,
    exposure_per_s = 1e-06);   // 1 ng/mL per second
equation
  response = E0*(1 - Emax*frac);   // steady state, indirect response type I
  // defaulted: Emax
  // defaulted: gamma
  annotation(experiment(StartTime = 0, StopTime = 160, Interval = 0.32),
    Documentation(info = "<html><body><!-- drug-about --><h4>About rosuvastatin</h4><p>Rosuvastatin is a statin used to treat lipid metabolism disorders such as hypercholesterolemia, atherosclerosis, and related heart disease. It is an approved medicine, widely used, and also available in fixed combinations with other lipid-modifying agents.</p><p><small>Summary written by glm-5.3-flash from <a href=&quot;https://www.wikidata.org/wiki/Q415159&quot;>Wikidata Q415159</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h4>Rosuvastatin_Courlet2021_PD_non_hdl_c</h4><p>The steady-state exposure-response curve of Courlet P et al., <i>Clinical pharmacokinetics 60(3):379–390</i> 2021 (<a href=\"https://doi.org/10.1007/s40262-020-00946-3\">doi:10.1007/s40262-020-00946-3</a>) — non-HDL-cholesterol [mmol/L] against rosuvastatin ng/mL — obtained by sweeping the driver instead of simulating a dose. Model family: indirect_response_i.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    =        3.6 mmol·L−1 drug-free response (baseline) (Baseline, Q324)
  Emax  = (library default) maximal effect term
  EC50  =       15.8 ng/mL    exposure at half of the maximal effect term (IC50, Q322)
  gamma = (library default) Hill coefficient</pre><p>The algebra is <code>response = E0*(1 - Emax*frac)</code>; this model only supplies the numbers. The x axis is one ng/mL of rosuvastatin per second of simulated time (exposure is in kg/m3): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 3.6   (drug-free)
  exposure = EC50 (15.8 ng/mL)  response 1.8
  exposure -> infinity  response 0</pre></body></html>"));
end Rosuvastatin_Courlet2021_PD_non_hdl_c;
