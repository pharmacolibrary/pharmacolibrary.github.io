model Rosuvastatin_Macpherson2016_final
  parameter Real Cl_ref = 4.361111111111111e-05 "Cl [m3/s]";
  parameter Real Vd_ref = 0.316 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.481538,
    adminMass = 5e-06,
    ka = 5.0833333333333333e-05,
    Tlag = 0.0,
    k12 = 8.113572433192685e-05,
    k21 = 4.735664737511801e-06
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About rosuvastatin</h4><p>Rosuvastatin is a statin used to treat lipid metabolism disorders such as hypercholesterolemia, atherosclerosis, and related heart disease. It is an approved medicine, widely used, and also available in fixed combinations with other lipid-modifying agents.</p><p><small>Summary written by glm-5.3-flash from <a href=&quot;https://www.wikidata.org/wiki/Q415159&quot;>Wikidata Q415159</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>rosuvastatin</td></tr><tr><td>population:</td><td>pediatric patients with heterozygous familial hypercholesterolemia</td></tr><tr><td>source_paper:</td><td>Macpherson_2016</td></tr><tr><td>measured_compound:</td><td>rosuvastatin</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>Table 2</td></tr><tr><td>input:</td><td>PK_2C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>rosuvastatin 481.538 g/mol (drugbank)</td></tr></table><p><b>Defaulted (base-class default used):</b> Tlag.</p><h4>Interpretation flags</h4><ul><li>dropped unlinked row (NIL): 'OFV' — extend the ontology if this is a real PK parameter (source ['Macpherson_2016_table_p6_1:row12:col1'])</li><li>dropped unlinked row (NIL): 'Condition no.' — extend the ontology if this is a real PK parameter (source ['Macpherson_2016_table_p6_1:row14:col1'])</li><li>apparent-ness (ontology-grounded): parameterization=apparent, measured_compound=rosuvastatin</li><li>model-stage split: 'final base model' is the final model of Macpherson_2016 (paper reports 3 stages: covariate model 1, final base model, final model); same population, different model-building step</li><li>skipped review gap-fill of TLAG: primary's parameterization (rate-constant / ka-only) does not use it</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Rosuvastatin_Macpherson2016_final;
