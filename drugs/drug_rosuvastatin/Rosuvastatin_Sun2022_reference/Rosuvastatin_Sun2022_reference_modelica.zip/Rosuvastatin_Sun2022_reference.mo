model Rosuvastatin_Sun2022_reference
  parameter Real Cl_ref = 1.2138888888888891e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.059680000000000004 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.481538,
    adminMass = 1e-05
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About rosuvastatin</h4><p>Rosuvastatin is a statin used to treat lipid metabolism disorders such as hypercholesterolemia, atherosclerosis, and related heart disease. It is an approved medicine, widely used, and also available in fixed combinations with other lipid-modifying agents.</p><p><small>Summary written by glm-5.3-flash from <a href=&quot;https://www.wikidata.org/wiki/Q415159&quot;>Wikidata Q415159</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>rosuvastatin</td></tr><tr><td>population:</td><td>review reference</td></tr><tr><td>source_paper:</td><td>Sun_2022</td></tr><tr><td>measured_compound:</td><td>rosuvastatin</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>rosuvastatin 481.538 g/mol (drugbank)</td></tr></table><h4>Interpretation flags</h4><ul><li>built from REVIEW reference values (Sun_2022) — secondary source</li><li>volume reported by review</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 172800, Tolerance = 1e-9, Interval = 1));
end Rosuvastatin_Sun2022_reference;
