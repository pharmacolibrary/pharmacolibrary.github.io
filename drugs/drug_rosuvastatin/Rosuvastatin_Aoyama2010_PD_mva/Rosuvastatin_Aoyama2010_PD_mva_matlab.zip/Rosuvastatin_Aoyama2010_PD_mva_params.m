function p = Rosuvastatin_Aoyama2010_PD_mva_params()
% Rosuvastatin_Aoyama2010_PD_mva_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% rosuvastatin Aoyama_2010::MVA: indirect_response_i exposure-response sweep (response = E0*(1 - Emax*frac)). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one ng/ml per second, in SI inside (kg/m3, s). Response MVA in ng/ml. Driver: rosuvastatin (pk_record).
p.E0 = 0.0;
p.Emax = 1.0;
p.EC50 = 1.9699999999999998e-06;
p.gamma = 1.65;
p.slope = 0.0;
p.exposure_per_s = 1e-06;
p.stop_time = 20.0;
p.form = 'E0*(1 - Emax*frac)';
end
