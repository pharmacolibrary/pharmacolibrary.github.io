model Rosuvastatin_Yang2011_PD_ldl_c
  "emax exposure-response sweep — Yang_2011 :: LDL-C (LDL-C reduction (%))"
  extends Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep(
    E0 = -0.008020000000000001,      // [1; % × 0.01]
    Emax = -0.5700000000000001,  // [1; % × 0.01]
    EC50 = 1.7399999999999999e-06,  // [kg; mg × 1e-06]
    gamma = 1.0,
    exposure_per_s = 1e-06);   // 1 mg per second
  // inhibition_sign: effect_direction=inhibition with a positive Emax (Q320) — sign flipped
  // defaulted: gamma
  annotation(experiment(StartTime = 0, StopTime = 17.4, Interval = 0.0348));
end Rosuvastatin_Yang2011_PD_ldl_c;
