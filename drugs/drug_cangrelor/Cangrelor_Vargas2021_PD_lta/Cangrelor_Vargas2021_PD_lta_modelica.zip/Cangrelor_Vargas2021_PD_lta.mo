model Cangrelor_Vargas2021_PD_lta
  "emax exposure-response sweep — Vargas_2021 :: LTA (maximal platelet aggregation)"
  extends Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep(
    E0 = 0,      // [1]
    Emax = -1.008,  // [1; % × 0.01]
    EC50 = 5.8e-06,  // [kg/m3; ng/mL × 1e-06]
    gamma = 1,
    exposure_per_s = 1e-06);   // 1 ng/mL per second
  // imax_as_negative_emax: Imax (Q323) enters SigmoidEmaxSweep as −Emax
  // defaulted: E0
  // defaulted: gamma
  annotation(experiment(StartTime = 0, StopTime = 58, Interval = 0.116),
    Documentation(info = "<html><body><!-- drug-about --><h4>About cangrelor</h4><p>Cangrelor is a platelet aggregation inhibitor used to prevent blood clots in patients with acute coronary syndrome or undergoing vascular surgical procedures. It is an approved medicine with an authorised product in the European Union.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q3655338\">Wikidata Q3655338</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h4>Cangrelor_Vargas2021_PD_lta</h4><p>The steady-state exposure-response curve of Vargas D et al., <i>Journal of thrombosis and haemostasis : JTH 19(1):202–211</i> 2021 (<a href=\"https://doi.org/10.1111/jth.15141\">doi:10.1111/jth.15141</a>) — maximal platelet aggregation [%] against cangrelor ng/mL — obtained by sweeping the driver instead of simulating a dose. Model family: emax.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = (library default) drug-free response (baseline)
  Emax  =      100.8 %        maximal effect term (Emax, Q323)
  EC50  =        5.8 ng/mL    exposure at half of the maximal effect term (EC 50, Q322)
  gamma = (library default) Hill coefficient</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep\">SigmoidEmaxSweep</a>; this model only supplies the numbers. The x axis is one ng/mL of cangrelor per second of simulated time (exposure is in kg/m3): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0   (drug-free)
  exposure = EC50 (5.8 ng/mL)  response -0.504
  exposure -> infinity  response -1.008</pre></body></html>"));
end Cangrelor_Vargas2021_PD_lta;
