function p = Cangrelor_Vargas2021_PD_lta_params()
% Cangrelor_Vargas2021_PD_lta_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% cangrelor Vargas_2021::LTA: emax exposure-response sweep (response = E0 + Emax*frac). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one ng/mL per second, in SI inside (kg/m3, s). Response LTA in %. Driver: cangrelor (pk_record).
p.E0 = 0.0;
p.Emax = -1.008;
p.EC50 = 5.7999999999999995e-06;
p.gamma = 1.0;
p.slope = 0.0;
p.exposure_per_s = 1e-06;
p.stop_time = 58.0;
p.form = 'E0 + Emax*frac';
end
