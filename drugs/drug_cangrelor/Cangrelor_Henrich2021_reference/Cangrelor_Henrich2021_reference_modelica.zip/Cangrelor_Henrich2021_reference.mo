model Cangrelor_Henrich2021_reference
  parameter Real Cl_ref = 2.363888888888889e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.017 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C_enteral(
    weight = 70.0,
    F = 0.9,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.77635,
    adminMass = 0.0001,
    ka = 0.0016527777777777778,
    Tlag = 0.0,
    k12 = 5.212418300653595e-05,
    k21 = 1.723951578037181e-05
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About cangrelor</h4><p>Cangrelor is a platelet aggregation inhibitor used to prevent blood clots in patients with acute coronary syndrome or undergoing vascular surgical procedures. It is an approved medicine with an authorised product in the European Union.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q3655338\">Wikidata Q3655338</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>cangrelor</td></tr><tr><td>population:</td><td>review reference</td></tr><tr><td>source_paper:</td><td>Henrich_2021</td></tr><tr><td>measured_compound:</td><td>cangrelor</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_2C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>cangrelor 776.35 g/mol (drugbank)</td></tr></table><p><b>Defaulted (base-class default used):</b> F, Tlag.</p><h4>Interpretation flags</h4><ul><li>built from REVIEW reference values (Henrich_2021) — secondary source</li><li>volume reported by review</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Cangrelor_Henrich2021_reference;
