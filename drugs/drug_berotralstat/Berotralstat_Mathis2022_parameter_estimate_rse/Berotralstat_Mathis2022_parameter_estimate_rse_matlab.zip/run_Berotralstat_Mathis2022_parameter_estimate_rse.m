% Run: build params, simulate 0..144.0 h, plot + save Berotralstat_Mathis2022_parameter_estimate_rse.png/.csv/.json.
% Interactive display (keep the window open):  octave --persist run_Berotralstat_Mathis2022_parameter_estimate_rse.m
here = fileparts(mfilename('fullpath'));
p = Berotralstat_Mathis2022_parameter_estimate_rse_params();
out = simulate_pk(p, 0:0.05:144.0);

% figure (shown on screen if interactive) and PNG (works in MATLAB and Octave)
fig = figure; plot(out.t, out.C, 'LineWidth', 1.5); grid on;
xlabel('time [h]'); ylabel('central concentration [mg/L]');
title('berotralstat — Mathis_2022 (oral)');
print(fig, fullfile(here, 'Berotralstat_Mathis2022_parameter_estimate_rse.png'), '-dpng', '-r150');

% CSV (time_h, Cc_mg_per_L)
fid = fopen(fullfile(here, 'Berotralstat_Mathis2022_parameter_estimate_rse.csv'), 'w');
fprintf(fid, 'time_h,Cc_mg_per_L\n');
fprintf(fid, '%.10g,%.10g\n', [out.t(:), out.C(:)].');
fclose(fid);

% JSON (summary + arrays; jsonencode with a manual fallback for older versions)
fid = fopen(fullfile(here, 'Berotralstat_Mathis2022_parameter_estimate_rse.json'), 'w');
try
  s.model = 'Berotralstat_Mathis2022_parameter_estimate_rse'; s.Cmax = out.Cmax; s.Tmax = out.Tmax; s.AUC = out.AUC;
  s.time_h = out.t(:).'; s.Cc_mg_per_L = out.C(:).';
  fprintf(fid, '%s', jsonencode(s));
catch
  fprintf(fid, '{"model":"Berotralstat_Mathis2022_parameter_estimate_rse","Cmax":%g,"Tmax":%g,"AUC":%g}', out.Cmax, out.Tmax, out.AUC);
end
fclose(fid);

fprintf('Cmax=%.3g mg/L  Tmax=%.3g h  AUC=%.3g mg*h/L\n', out.Cmax, out.Tmax, out.AUC);
fprintf('wrote Berotralstat_Mathis2022_parameter_estimate_rse.png, Berotralstat_Mathis2022_parameter_estimate_rse.csv, Berotralstat_Mathis2022_parameter_estimate_rse.json\n');
