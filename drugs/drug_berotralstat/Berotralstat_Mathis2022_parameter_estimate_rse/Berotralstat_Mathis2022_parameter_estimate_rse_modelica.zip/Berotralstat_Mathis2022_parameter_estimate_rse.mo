model Berotralstat_Mathis2022_parameter_estimate_rse
  parameter Real Cl_ref = 1.3138888888888888e-05 "Cl [m3/s]";
  parameter Real Vd_ref = 1.6500000000000001 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 0.497,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.562573,
    adminMass = 1e-05,
    ka = 0.0003111111111111111,
    Tlag = 1684.8000000000002
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About berotralstat</h4><p>Berotralstat is a medicine used to treat hereditary angioedema. It is authorised in the European Union and is an approved drug, though it has also been investigated for other uses.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q104529366\">Wikidata Q104529366</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>berotralstat</td></tr><tr><td>population:</td><td>healthy subjects and patients with hereditary angioedema</td></tr><tr><td>source_paper:</td><td>Mathis_2022</td></tr><tr><td>measured_compound:</td><td>berotralstat</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>cts13233-tbl-0001</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>berotralstat 562.573 g/mol (drugbank)</td></tr></table><h4>Interpretation flags</h4><ul><li>dropped duplicate Q48 ('K32 (1/h)', value '0.0309') — already have one for this compound</li><li>dropped duplicate Q48 ('K24 (1/h)', value '0.00281') — already have one for this compound</li><li>dropped duplicate Q48 ('K42 (1/h)', value '0.00136') — already have one for this compound</li><li>dropped duplicate Q61 ('Volume as a function of weight', value '1.00') — already have one for this compound</li><li>implicit units: 'Ka (1/h)' → 1/h (from the popPK convention: 'The paper does not explicitly state the unit for Ka in the text or table footnotes. However, Ka is an absorption rate co')</li><li>implicit units: 'K23 (1/h)' → 1/h (from the popPK convention: 'The paper does not explicitly state the unit for K23 in the text or table footnotes. K23 is a micro-rate constant (first')</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=berotralstat</li><li>structure disagreement: deterministic 1C vs LLM 2C — review compartment count</li><li>population split: 'parameter estimate (rse%)' subgroup of Mathis_2022 (paper reports 6 populations: adolescents (12–18 years), low weight adults (60–80 kg), normal weight adults (80–100 kg), overweight adults (100–120 kg), parameter estimate (rse%), underweight adults (40–60 kg))</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 518400, Tolerance = 1e-9, Interval = 1));
end Berotralstat_Mathis2022_parameter_estimate_rse;
