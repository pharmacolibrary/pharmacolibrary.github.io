model Cladribine_Lu2024_reference
  parameter Real Cl_ref = 1.6666666666666667e-05 "Cl [m3/s]";
  parameter Real Vd_ref = 1.25 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.285687,
    adminMass = 6.3e-06
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About cladribine</h4><p>Cladribine is a purine analogue medicine used to treat hairy cell leukemia and multiple sclerosis, and has also been used for other leukemias and lymphomas. It is approved and authorised in the European Union, where it is used for multiple sclerosis and hairy cell leukemia.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q414030\">Wikidata Q414030</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>cladribine</td></tr><tr><td>population:</td><td>review reference</td></tr><tr><td>source_paper:</td><td>Lu_2024</td></tr><tr><td>measured_compound:</td><td>cladribine</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>cladribine 285.687 g/mol (drugbank)</td></tr></table><h4>Interpretation flags</h4><ul><li>built from REVIEW reference values (Lu_2024) — secondary source</li><li>volume reported by review</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 345600, Tolerance = 1e-9, Interval = 1));
end Cladribine_Lu2024_reference;
