model Diclofenac_Yuan2017_reference
  parameter Real Cl_ref = 2.2500000000000002e-07 "Cl [m3/s]";
  parameter Real Vd_ref = 0.0012900000000000001 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.296149,
    adminMass = 0.0001
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About diclofenac</h4><p>Diclofenac is a non-steroidal anti-inflammatory drug and painkiller used for painful and inflammatory conditions such as osteoarthritis, rheumatoid arthritis, gout, migraine, and other musculoskeletal problems. It is widely used in human medicine in many forms, including tablets, skin preparations, and eye drops, and is also approved for veterinary use.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q244408\">Wikidata Q244408</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>diclofenac</td></tr><tr><td>population:</td><td>review reference</td></tr><tr><td>source_paper:</td><td>Yuan_2017</td></tr><tr><td>measured_compound:</td><td>diclofenac</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>diclofenac 296.149 g/mol (drugbank)</td></tr></table><h4>Interpretation flags</h4><ul><li>built from REVIEW reference values (Yuan_2017) — secondary source</li><li>volume reported by review</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Diclofenac_Yuan2017_reference;
