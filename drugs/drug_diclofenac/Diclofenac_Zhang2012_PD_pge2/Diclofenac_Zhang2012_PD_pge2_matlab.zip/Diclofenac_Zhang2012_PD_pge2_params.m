function p = Diclofenac_Zhang2012_PD_pge2_params()
% Diclofenac_Zhang2012_PD_pge2_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% diclofenac Zhang_2012::PGE2: sigmoid_emax exposure-response sweep (response = E0 + Emax*frac). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one µg/mL per second, in SI inside (kg/m3, s). Response PGE2 in its own unit. Driver: diclofenac (cited_pk).
p.E0 = 6.39e-05;
p.Emax = -5.48e-05;
p.EC50 = 0.0012999999999999997;
p.gamma = 1.0;
p.slope = 0.0;
p.exposure_per_s = 0.0009999999999999998;
p.stop_time = 13.0;
p.form = 'E0 + Emax*frac';
end
