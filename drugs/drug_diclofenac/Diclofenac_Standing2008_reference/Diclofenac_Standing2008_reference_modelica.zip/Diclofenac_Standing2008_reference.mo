model Diclofenac_Standing2008_reference
  parameter Real Cl_ref = 0.001049611111111111 "Cl [m3/s]";
  parameter Real Vd_ref = 0.3388 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.296149,
    adminMass = 5e-05,
    ka = 0.0001388888888888889,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About diclofenac</h4><p>Diclofenac is a non-steroidal anti-inflammatory drug and painkiller used for painful and inflammatory conditions such as osteoarthritis, rheumatoid arthritis, gout, migraine, and other musculoskeletal problems. It is widely used in human medicine in many forms, including tablets, skin preparations, and eye drops, and is also approved for veterinary use.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q244408\">Wikidata Q244408</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>diclofenac</td></tr><tr><td>population:</td><td>adult volunteers and paediatric patients</td></tr><tr><td>source_paper:</td><td>Standing_2008</td></tr><tr><td>measured_compound:</td><td>diclofenac</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>tab_1</td></tr><tr><td>input:</td><td>PK_1C_enteral: apparent (/F) parameterization ⇒ extravascular dosing</td></tr><tr><td>molar_masses:</td><td>diclofenac 296.149 g/mol (drugbank)</td></tr></table><p><b>Defaulted (base-class default used):</b> ka, Tlag.</p><h4>Interpretation flags</h4><ul><li>salvaged Q27 ('CL/F'=53.98) from results prose — parameter table was unreadable</li><li>salvaged Q76 ('VD/F'=4.84) from results prose — parameter table was unreadable</li><li>apparent-ness (ontology-grounded): parameterization=apparent, measured_compound=diclofenac</li><li>held at status:extracted — NIL link or unit issue (mismatch/unknown/normalisation-failed) present</li><li>status held at route_to_review — not promoted</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Diclofenac_Standing2008_reference;
