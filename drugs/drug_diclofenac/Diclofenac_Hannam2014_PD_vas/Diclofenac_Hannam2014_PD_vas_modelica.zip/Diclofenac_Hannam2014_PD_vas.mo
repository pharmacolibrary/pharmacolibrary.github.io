model Diclofenac_Hannam2014_PD_vas
  "emax exposure-response sweep — Hannam_2014 :: VAS (pain)"
  extends Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep(
    E0 = 0,      // [1]
    Emax = -4.9,  // [VAS 0-10]
    EC50 = 0.00123,  // [kg/m3; mg·l(-1) × 0.001]
    gamma = 1,
    exposure_per_s = 0.001);   // 1 mg·l(-1) per second
  // imax_as_negative_emax: Imax (Q323) enters SigmoidEmaxSweep as −Emax
  // defaulted: E0
  // defaulted: gamma
  annotation(experiment(StartTime = 0, StopTime = 13, Interval = 0.026),
    Documentation(info = "<html><body><!-- drug-about --><h4>About diclofenac</h4><p>Diclofenac is a non-steroidal anti-inflammatory drug and painkiller used for painful and inflammatory conditions such as osteoarthritis, rheumatoid arthritis, gout, migraine, and other musculoskeletal problems. It is widely used in human medicine in many forms, including tablets, skin preparations, and eye drops, and is also approved for veterinary use.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q244408\">Wikidata Q244408</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h4>Diclofenac_Hannam2014_PD_vas</h4><p>The steady-state exposure-response curve of Hannam JA et al., <i>Paediatric anaesthesia 24(9):953–961</i> 2014 (<a href=\"https://doi.org/10.1111/pan.12422\">doi:10.1111/pan.12422</a>) — pain [VAS 0-10] against diclofenac mg·l(-1) — obtained by sweeping the driver instead of simulating a dose. Model family: emax.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = (library default) drug-free response (baseline)
  Emax  =        4.9 VAS 0-10 maximal effect term (EMAX, Q323)
  EC50  =       1.23 mg·l(-1) exposure at half of the maximal effect term (C50, Q321)
  gamma = (library default) Hill coefficient</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep\">SigmoidEmaxSweep</a>; this model only supplies the numbers. The x axis is one mg·l(-1) of diclofenac per second of simulated time (exposure is in kg/m3): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0   (drug-free)
  exposure = EC50 (1.23 mg·l(-1))  response -2.45
  exposure -> infinity  response -4.9</pre></body></html>"));
end Diclofenac_Hannam2014_PD_vas;
