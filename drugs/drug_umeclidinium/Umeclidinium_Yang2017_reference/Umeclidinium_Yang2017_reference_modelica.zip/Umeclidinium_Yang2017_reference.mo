model Umeclidinium_Yang2017_reference
  parameter Real Cl_ref = 7.138888888888889e-05 "Cl [m3/s]";
  parameter Real Vd_ref = 0.804 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.428596,
    adminMass = 0.0001,
    ka = 0.0001388888888888889,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About umeclidinium</h4><p>Umeclidinium is an inhaled anticholinergic medicine used to treat chronic obstructive pulmonary disease, often in combination with other inhaled drugs. It is authorised in the European Union and widely used as a maintenance inhalation treatment for COPD.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q17125410\">Wikidata Q17125410</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>umeclidinium</td></tr><tr><td>population:</td><td>adults with asthma</td></tr><tr><td>source_paper:</td><td>Yang_2017</td></tr><tr><td>measured_compound:</td><td>umeclidinium</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C_enteral: apparent (/F) parameterization ⇒ extravascular dosing</td></tr><tr><td>molar_masses:</td><td>umeclidinium 428.596 g/mol (pubchem)</td></tr></table><p><b>Defaulted (base-class default used):</b> ka, Tlag.</p><h4>Interpretation flags</h4><ul><li>unit_dimension_unknown: 'pg h/mL' (AUCt)</li><li>implicit units: 'AUC0-24 median' → mg·h/L (from the popPK convention: 'No unit stated in text, caption, or footnotes. AUC0-24 for an antibacterial is conventionally expressed in mg·h/L; a val')</li><li>apparent-ness (ontology-grounded): parameterization=apparent, measured_compound=umeclidinium</li><li>1C volume normalization: Q290→Q76 (single-compartment model has no central/peripheral split; 'V c/F' is the general volume)</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Umeclidinium_Yang2017_reference;
