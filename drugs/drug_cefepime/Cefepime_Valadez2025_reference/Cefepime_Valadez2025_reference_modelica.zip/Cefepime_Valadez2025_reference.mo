model Cefepime_Valadez2025_reference
  parameter Real Cl_ref = 8.666666666666668e-07 "Cl [m3/s]";
  parameter Real Vd_ref = 0.023 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.48056099999999996,
    adminMass = 0.004
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About cefepime</h4><p>Cefepime is a fourth-generation cephalosporin antibiotic used to treat serious bacterial infections such as pneumonia, sepsis, urinary tract infections, and infections caused by gram-negative bacteria including Pseudomonas. It is an approved antibiotic in widespread clinical use, typically given by injection in hospital settings for severe infections.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q2552927\">Wikidata Q2552927</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>cefepime</td></tr><tr><td>population:</td><td>review reference</td></tr><tr><td>source_paper:</td><td>Valadez_2025</td></tr><tr><td>measured_compound:</td><td>cefepime</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>cefepime 480.561 g/mol (drugbank)</td></tr></table><h4>Interpretation flags</h4><ul><li>built from REVIEW reference values (Valadez_2025) — secondary source</li><li>volume reported by review</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 93600, Tolerance = 1e-9, Interval = 1));
end Cefepime_Valadez2025_reference;
