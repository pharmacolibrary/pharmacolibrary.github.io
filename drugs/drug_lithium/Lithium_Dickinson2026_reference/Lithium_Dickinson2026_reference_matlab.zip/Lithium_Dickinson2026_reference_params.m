function p = Lithium_Dickinson2026_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: lithium   source: Dickinson_2026 / reference   route: oral
  % estimated (absent from source): dose
  p.name  = 'Lithium_Dickinson2026_reference_params';
  p.drug  = 'lithium';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 15.0;                % central volume [L]
  p.CL = 0.787;                % clearance [L/h]
  p.Vp = [0.671];             % peripheral volumes [L]
  p.Q  = [0.0093];             % inter-compartmental clearances [L/h]
  p.ka = 2.58;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.836;             % absorption lag [h]
  p.dose = 100.0;             % dose [mg]
end
