model Lithium_Dickinson2026_reference
  parameter Real Cl_ref = 2.186111111111111e-07 "Cl [m3/s]";
  parameter Real Vd_ref = 0.015 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.00694,
    adminMass = 0.0001,
    ka = 0.0007166666666666667,
    Tlag = 3009.6,
    k12 = 1.722222222222222e-07,
    k21 = 3.84997516145057e-06
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About lithium</h4><p>Lithium is a mood-stabilising psychiatric medicine used mainly for bipolar disorder and other mood-related conditions. It remains widely used and is included on the WHO list of essential medicines, though it carries a boxed warning.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q152763\">Wikidata Q152763</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>lithium</td></tr><tr><td>population:</td><td>review reference</td></tr><tr><td>source_paper:</td><td>Dickinson_2026</td></tr><tr><td>measured_compound:</td><td>lithium</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_2C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>lithium 6.94 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>built from REVIEW reference values (Dickinson_2026) — secondary source</li><li>volume reported by review</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 259200, Tolerance = 1e-9, Interval = 1));
end Lithium_Dickinson2026_reference;
