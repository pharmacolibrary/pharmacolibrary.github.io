function p = Lithium_Gijsen2021_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: lithium   source: Gijsen_2021 / reference   route: iv_bolus
  % estimated (absent from source): F, dose
  p.name  = 'Lithium_Gijsen2021_reference_params';
  p.drug  = 'lithium';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'iv_bolus';        % 'oral' | 'iv_bolus'
  p.depot = false;             % oral -> first-order absorption depot
  p.Vc = 25.6;                % central volume [L]
  p.CL = 14.7;                % clearance [L/h]
  p.Vp = [8.02];             % peripheral volumes [L]
  p.Q  = [5.51];             % inter-compartmental clearances [L/h]
  p.ka = 0.0;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 10.0;             % dose [mg]
end
