function p = Lithium_Jermain1991_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: lithium   source: Jermain_1991 / reference   route: oral
  % estimated (absent from source): F, dose
  % Vc is the record's Vss — no central volume was reported; 1-compartment reading
  p.name  = 'Lithium_Jermain1991_reference_params';
  p.drug  = 'lithium';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 32.8;                % central volume [L]
  p.CL = 1.36;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 1.03;                % absorption rate [1/h]
  p.F  = 0.9;                 % bioavailability [0-1]
  p.Tlag = 0.186;             % absorption lag [h]
  p.dose = 100.0;             % dose [mg]
end
