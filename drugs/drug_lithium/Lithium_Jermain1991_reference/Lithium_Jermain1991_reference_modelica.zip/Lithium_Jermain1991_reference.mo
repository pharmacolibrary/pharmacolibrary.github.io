model Lithium_Jermain1991_reference
  parameter Real Cl_ref = 3.777777777777778e-07 "Cl [m3/s]";
  parameter Real Vd_ref = 0.032799999999999996 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 0.9,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.00694,
    adminMass = 0.0001,
    ka = 0.0002861111111111111,
    Tlag = 669.6
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About lithium</h4><p>Lithium is a mood-stabilising psychiatric medicine used mainly for bipolar disorder and other mood-related conditions. It remains widely used and is included on the WHO list of essential medicines, though it carries a boxed warning.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q152763\">Wikidata Q152763</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>lithium</td></tr><tr><td>population:</td><td>psychiatric inpatients receiving lithium</td></tr><tr><td>source_paper:</td><td>Jermain_1991</td></tr><tr><td>measured_compound:</td><td>lithium</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>lithium 6.94 g/mol (pubchem)</td></tr></table><p><b>Defaulted (base-class default used):</b> F.</p><h4>Interpretation flags</h4><ul><li>covariate category for IIV from footnote/prose kept as documentation only (['Jermain_1991:abstract'])</li><li>routed 'coefficient of variation' → Q316 (prop_error) to residual_error — variability estimate, not a structural parameter</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=lithium</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li><li>skipped review gap-fill of V from Adamiszak_2025: its label names a different analyte ('flu') — 'volume of distribution (V) of FLU'</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li><li>gap-filled Q49 (kabs) from Aurélie_2023's review values (primary lacked it)</li><li>gap-filled Q83 (tlag) from Aurélie_2023's review values (primary lacked it)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 345600, Tolerance = 1e-9, Interval = 1));
end Lithium_Jermain1991_reference;
