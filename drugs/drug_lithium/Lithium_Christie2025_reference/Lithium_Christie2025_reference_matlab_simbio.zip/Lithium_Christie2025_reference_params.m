function p = Lithium_Christie2025_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: lithium   source: Christie_2025 / reference   route: oral
  % estimated (absent from source): F, dose
  p.name  = 'Lithium_Christie2025_reference_params';
  p.drug  = 'lithium';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 6.293;                % central volume [L]
  p.CL = 165.06;                % clearance [L/h]
  p.Vp = [41.16];             % peripheral volumes [L]
  p.Q  = [187.32];             % inter-compartmental clearances [L/h]
  p.ka = 29.04;                % absorption rate [1/h]
  p.F  = 0.9;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 100.0;             % dose [mg]
end
