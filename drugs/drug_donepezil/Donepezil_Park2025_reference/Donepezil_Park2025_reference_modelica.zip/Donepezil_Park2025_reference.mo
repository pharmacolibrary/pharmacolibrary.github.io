model Donepezil_Park2025_reference
  parameter Real Cl_ref = 2.6583333333333334e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.0582 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C_enteral(
    weight = 70.0,
    F = 0.9,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.3795,
    adminMass = 7e-05,
    ka = 4.805555555555556e-07,
    Tlag = 1076400.0,
    k12 = 0.0004772814051164567,
    k21 = 1.3550135501355015e-05
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About donepezil</h4><p>Donepezil is an acetylcholinesterase inhibitor used to treat Alzheimer's disease and other forms of dementia, including vascular and Lewy body dementia. It is an approved medicine, widely used for dementia, and has also been investigated for other memory-related conditions.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q415081\">Wikidata Q415081</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>donepezil</td></tr><tr><td>population:</td><td>healthy male adults</td></tr><tr><td>source_paper:</td><td>Park_2025</td></tr><tr><td>measured_compound:</td><td>donepezil</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>pharmaceutics-17-01517-t006</td></tr><tr><td>input:</td><td>PK_2C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>donepezil 379.5 g/mol (pubchem)</td></tr></table><p><b>Defaulted (base-class default used):</b> F.</p><h4>Interpretation flags</h4><ul><li>dropped duplicate Q49 ('KA4, 1/h', value '0.0113') — already have one for this compound</li><li>dropped unlinked row (NIL): 'F3' — extend the ontology if this is a real PK parameter (source ['pharmaceutics-17-01517-t006:row8:col1', 'pharmaceutics-17-01517-t006:row8:col2', 'pharmaceutics-17-01517-t006:row8:col3'])</li><li>dropped unlinked row (NIL): 'F4' — extend the ontology if this is a real PK parameter (source ['pharmaceutics-17-01517-t006:row9:col1', 'pharmaceutics-17-01517-t006:row9:col2', 'pharmaceutics-17-01517-t006:row9:col3'])</li><li>dropped duplicate Q83 ('ALAG4', value '1130') — already have one for this compound</li><li>routed 'ε1 (additive), ng/mL' → Q317 (add_error) to residual_error — variability estimate, not a structural parameter</li><li>routed 'ε2 (proportional) a' → Q316 (prop_error) to residual_error — variability estimate, not a structural parameter</li><li>implicit units: 'Q' → L/h (from the paper text: &quot;Text states: 'The intercompartmental clearance (Q) in GB-5001A model was fixed at 100 L/h in the final model.'&quot;)</li><li>implicit units: 'D1' → h (from the popPK convention: 'D1 is a duration of zero-order input; durations are conventionally expressed in hours in population PK models, and no un')</li><li>implicit units: 'ALAG3' → h (from the popPK convention: 'ALAG3 is an absorption lag time; lag times are conventionally expressed in hours in population PK models, and no unit is')</li><li>apparent-by-design (ADVISORY, codes unchanged): extravascular dosing with no identifiable F, so these reported disposition parameters are likely apparent unless the model puts first-pass in its structure — Q22 (CL, L/h); Q63 (V1, L); Q64 (V2, L); Q30 (Q)</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=donepezil</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 6652800, Tolerance = 1e-9, Interval = 1));
end Donepezil_Park2025_reference;
