function p = Donepezil_Lee2022_sr_1_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: donepezil   source: Lee_2022 / sr_1   route: oral
  p.name  = 'Donepezil_Lee2022_sr_1_params';
  p.drug  = 'donepezil';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 3048.69;                % central volume [L]
  p.CL = 612.6318;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 2.73;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.54;             % absorption lag [h]
  p.dose = 4.562;             % dose [mg]
end
