model Donepezil_Lee2022_sr_1
  parameter Real Cl_ref = 0.0001701755 "Cl [m3/s]";
  parameter Real Vd_ref = 3.04869 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.3795,
    adminMass = 4.5620000000000005e-06,
    ka = 0.0007583333333333333,
    Tlag = 1944.0000000000002
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About donepezil</h4><p>Donepezil is an acetylcholinesterase inhibitor used to treat Alzheimer's disease and other forms of dementia, including vascular and Lewy body dementia. It is an approved medicine, widely used for dementia, and has also been investigated for other memory-related conditions.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q415081\">Wikidata Q415081</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>donepezil</td></tr><tr><td>population:</td><td>Beagle dogs</td></tr><tr><td>source_paper:</td><td>Lee_2022</td></tr><tr><td>measured_compound:</td><td>donepezil</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>pharmaceutics-14-01226-t004</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>donepezil 379.5 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>dropped unlinked row (NIL): 'Dose (mg)' — extend the ontology if this is a real PK parameter (source ['Lee_2022_table_3:row0:col2'])</li><li>unit_dimension_unknown: 'n = 3' (MRT)</li><li>implicit units: 'MRT (h) b' → h (from the paper text: &quot;The table entry itself is labeled 'MRT (h)', indicating the unit is hours; footnote b defines MRT as mean residence time&quot;)</li><li>apparent-ness (ontology-grounded): parameterization=apparent, measured_compound=donepezil</li><li>population split: 'sr-1 (n = 3)' subgroup of Lee_2022 (paper reports 5 populations: ir (n = 3), population mean, sr-1 (n = 3), sr-2 (n = 3), sr-3 (n = 3))</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li><li>gap-filled Q49 (kabs) from Bakker_2021's review values (primary lacked it)</li><li>gap-filled Q83 (tlag) from Bakker_2021's review values (primary lacked it)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Donepezil_Lee2022_sr_1;
