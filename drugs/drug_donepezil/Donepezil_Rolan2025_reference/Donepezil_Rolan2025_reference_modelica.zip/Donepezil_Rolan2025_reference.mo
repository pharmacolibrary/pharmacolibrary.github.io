model Donepezil_Rolan2025_reference
  parameter Real Cl_ref = 1.322222222222222e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.0643 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.3795,
    adminMass = 7.5e-06,
    ka = 0.00048333333333333334,
    Tlag = 3240.0
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About donepezil</h4><p>Donepezil is an acetylcholinesterase inhibitor used to treat Alzheimer's disease and other forms of dementia, including vascular and Lewy body dementia. It is an approved medicine, widely used for dementia, and has also been investigated for other memory-related conditions.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q415081\">Wikidata Q415081</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>donepezil</td></tr><tr><td>population:</td><td>review reference</td></tr><tr><td>source_paper:</td><td>Rolan_2025</td></tr><tr><td>measured_compound:</td><td>donepezil</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>donepezil 379.5 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>built from REVIEW reference values (Rolan_2025) — secondary source</li><li>volume reported by review</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 259200, Tolerance = 1e-9, Interval = 1));
end Donepezil_Rolan2025_reference;
