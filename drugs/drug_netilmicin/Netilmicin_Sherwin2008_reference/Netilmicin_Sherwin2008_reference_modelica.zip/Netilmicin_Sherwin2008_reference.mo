model Netilmicin_Sherwin2008_reference
  parameter Real Cl_ref = 5.3333333333333334e-08 "Cl [m3/s]";
  parameter Real Vd_ref = 0.0015 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.475587,
    adminMass = 0.00035
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About netilmicin</h4><p>Netilmicin is an aminoglycoside antibiotic used to treat serious bacterial infections, including eye infections. It is an approved medicine and is used mainly in hospital settings for severe infections, given by injection, with ophthalmic formulations also available.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q2553496\">Wikidata Q2553496</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>netilmicin</td></tr><tr><td>population:</td><td>neonates</td></tr><tr><td>source_paper:</td><td>Sherwin_2008</td></tr><tr><td>measured_compound:</td><td>netilmicin</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>netilmicin 475.587 g/mol (drugbank)</td></tr></table><h4>Interpretation flags</h4><ul><li>dropped unlinked row (NIL): 'CWT/2' — extend the ontology if this is a real PK parameter (source ['Sherwin_2008:abstract', 'Sherwin_2008:abstract'])</li><li>dropped unlinked row (NIL): 'PMA/40' — extend the ontology if this is a real PK parameter (source ['Sherwin_2008:abstract'])</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=netilmicin</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 100800, Tolerance = 1e-9, Interval = 1));
end Netilmicin_Sherwin2008_reference;
