model Canrenone_Suyagh2013_reference
  parameter Real Cl_ref = 3.083333333333334e-07 "Cl [m3/s]";
  parameter Real Vd_ref = 0.02048 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.3404559,
    adminMass = 0.0001,
    ka = 0.0001388888888888889,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About canrenone</h4><p>Canrenone is an antimineralocorticoid (aldosterone antagonist) that has been investigated for use as a potassium-sparing diuretic in cardiovascular conditions. It is considered investigational and is not an approved medicine in the European Union.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q5033475\">Wikidata Q5033475</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>canrenone</td></tr><tr><td>population:</td><td>paediatric patients</td></tr><tr><td>source_paper:</td><td>Suyagh_2013</td></tr><tr><td>measured_compound:</td><td>canrenone</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C_enteral: apparent (/F) parameterization ⇒ extravascular dosing</td></tr><tr><td>molar_masses:</td><td>canrenone 340.456 g/mol (drugbank); potassium canrenoate 396.568 g/mol (pubchem)</td></tr></table><p><b>Defaulted (base-class default used):</b> ka, Tlag.</p><h4>Interpretation flags</h4><ul><li>dropped duplicate Q57 ('Estimated half-life of canrenone based on matched plasma concentrations', value 19.37) — already have one for this compound</li><li>apparent-ness (ontology-grounded): parameterization=apparent, measured_compound=canrenone</li><li>template fit: none — noncompartmental model — not a compartmental parent–metabolite model</li><li>row roles (LLM): model_class=noncompartmental; 4/4 row label(s) assigned, 0 linked by role</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 432000, Tolerance = 1e-9, Interval = 1));
end Canrenone_Suyagh2013_reference;
