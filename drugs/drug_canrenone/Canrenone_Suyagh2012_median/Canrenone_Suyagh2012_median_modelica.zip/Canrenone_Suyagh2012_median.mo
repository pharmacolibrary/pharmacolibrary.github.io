model Canrenone_Suyagh2012_median
  parameter Real Cl_ref = 0.00022166666666666667 "Cl [m3/s]";
  parameter Real Vd_ref = 1.4027999999999998 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.3404559,
    adminMass = 0.0001,
    ka = 0.016066666666666667,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About canrenone</h4><p>Canrenone is an antimineralocorticoid (aldosterone antagonist) that has been investigated for use as a potassium-sparing diuretic in cardiovascular conditions. It is considered investigational and is not an approved medicine in the European Union.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q5033475\">Wikidata Q5033475</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>canrenone</td></tr><tr><td>population:</td><td>paediatric patients</td></tr><tr><td>source_paper:</td><td>Suyagh_2012</td></tr><tr><td>measured_compound:</td><td>canrenone</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>tab_0</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>canrenone 340.456 g/mol (drugbank); potassium canrenoate 396.568 g/mol (pubchem)</td></tr></table><p><b>Defaulted (base-class default used):</b> Tlag.</p><h4>Interpretation flags</h4><ul><li>the dosed compound is canrenone; the compartment is canrenone. Input enters at the reported formation rate, so formation is already accounted for in the input step and the simulated concentration is canrenone, not canrenone</li><li>apparent parameters (CLm/F, Vm/F) already contain F and the metabolised fraction, so F=1 and no molar correction is applied — adding either would double-count it</li><li>canrenone's own concentration-time course is not produced by this model</li><li>dropped duplicate Q27 ('CL/F (l h -1 )', value '1.33') — already have one for this compound</li><li>dropped duplicate Q290 ('V/F (l)', value '19.62') — already have one for this compound</li><li>dropped duplicate Q27 ('CL/F (l h -1 kg -1 )*', value '0.32') — already have one for this compound</li><li>dropped duplicate Q290 ('V/F (l kg -1 )*', value '5.35') — already have one for this compound</li><li>metabolite canrenone: Q27→Q351 — only the metabolite is measured and fm is not identifiable, so its CL/V are apparent (fm-divided)</li><li>apparent-ness (ontology-grounded): parameterization=apparent, measured_compound=canrenone</li><li>template fit: none — only the metabolite is modelled — no parent compartment</li><li>1C volume normalization: Q290→Q76 (single-compartment model has no central/peripheral split; 'V/F (l 70 kg -1 )' is the general volume)</li><li>population split: 'median' subgroup of Suyagh_2012 (paper reports 2 populations: final pharmacokinetic model, median)</li><li>row roles (LLM): model_class=compartmental; 11/11 row label(s) assigned, 31 linked by role</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of TLAG: primary's parameterization (rate-constant / ka-only) does not use it</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 259200, Tolerance = 1e-9, Interval = 1));
end Canrenone_Suyagh2012_median;
