function p = DarbepoetinAlfa_Jeon2021_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: darbepoetin_alfa   source: Jeon_2021 / reference   route: iv_bolus
  % estimated (absent from source): F
  p.name  = 'DarbepoetinAlfa_Jeon2021_reference_params';
  p.drug  = 'darbepoetin_alfa';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'iv_bolus';        % 'oral' | 'iv_bolus'
  p.depot = false;             % oral -> first-order absorption depot
  p.Vc = 16.23;                % central volume [L]
  p.CL = 0.15;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.0;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 0.0045;             % dose [mg]
end
