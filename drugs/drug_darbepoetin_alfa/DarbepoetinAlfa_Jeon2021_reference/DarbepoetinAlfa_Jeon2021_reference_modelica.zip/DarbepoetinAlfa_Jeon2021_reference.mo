model DarbepoetinAlfa_Jeon2021_reference
  parameter Real Cl_ref = 4.166666666666666e-08 "Cl [m3/s]";
  parameter Real Vd_ref = 0.01623 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    adminMass = 4.500000000000001e-09
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About darbepoetin_alfa</h4><p>Darbepoetin alfa is an antianemic medicine used to treat anemia, including anemia linked to chronic kidney failure and cancer treatment. It is an approved medicine authorised in the European Union, though it carries a boxed warning.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q2178381\">Wikidata Q2178381</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>darbepoetin_alfa</td></tr><tr><td>population:</td><td>review reference</td></tr><tr><td>source_paper:</td><td>Jeon_2021</td></tr><tr><td>measured_compound:</td><td>darbepoetin_alfa</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C: IV (no input phase)</td></tr></table><h4>Interpretation flags</h4><ul><li>built from REVIEW reference values (Jeon_2021) — secondary source</li><li>volume reported by review</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 1382400, Tolerance = 1e-9, Interval = 1));
end DarbepoetinAlfa_Jeon2021_reference;
