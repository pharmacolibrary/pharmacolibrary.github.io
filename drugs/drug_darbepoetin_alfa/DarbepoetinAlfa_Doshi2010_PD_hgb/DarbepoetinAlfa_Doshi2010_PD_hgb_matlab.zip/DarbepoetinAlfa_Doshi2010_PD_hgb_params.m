function p = DarbepoetinAlfa_Doshi2010_PD_hgb_params()
% DarbepoetinAlfa_Doshi2010_PD_hgb_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% darbepoetin_alfa Doshi_2010::Hgb: indirect_response_iii exposure-response sweep (response = E0*(1 + Emax*frac)). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one ng/mL per second, in SI inside (kg/m3, s). Response Hgb in its own unit. Driver: darbepoetin alfa (conc_no_pk).
p.E0 = 0.0;
p.Emax = 64.0;
p.EC50 = 4.0999999999999994e-07;
p.gamma = 1.0;
p.slope = 0.0;
p.exposure_per_s = 1e-06;
p.stop_time = 4.1;
p.form = 'E0*(1 + Emax*frac)';
end
