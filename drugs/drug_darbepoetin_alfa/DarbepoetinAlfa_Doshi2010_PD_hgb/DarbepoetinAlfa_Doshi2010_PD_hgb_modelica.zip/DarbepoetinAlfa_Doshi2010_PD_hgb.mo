model DarbepoetinAlfa_Doshi2010_PD_hgb
  "indirect_response_iii exposure-response sweep — Doshi_2010 :: Hgb (Hgb concentration)"
  extends Pharmacolibrary.Interfaces.PartialExposureResponseSweep(
    E0 = 0,      // [1]
    Emax = 64,  // type III effect term
    EC50 = 4.1e-07,  // [kg/m3; ng/mL × 1e-06]
    gamma = 1,
    exposure_per_s = 1e-06);   // 1 ng/mL per second
equation
  response = E0*(1 + Emax*frac);   // steady state, indirect response type III
  // defaulted: E0
  // defaulted: gamma
  annotation(experiment(StartTime = 0, StopTime = 4.1, Interval = 0.0082),
    Documentation(info = "<html><body><!-- drug-about --><h4>About darbepoetin_alfa</h4><p>Darbepoetin alfa is an antianemic medicine used to treat anemia, including anemia linked to chronic kidney failure and cancer treatment. It is an approved medicine authorised in the European Union, though it carries a boxed warning.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q2178381\">Wikidata Q2178381</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h4>DarbepoetinAlfa_Doshi2010_PD_hgb</h4><p>The steady-state exposure-response curve of Doshi S et al., <i>Journal of clinical pharmacology 50(9 Suppl):75S–90S</i> 2010 (<a href=\"https://doi.org/10.1177/0091270010377201\">doi:10.1177/0091270010377201</a>) — Hgb concentration against darbepoetin alfa ng/mL — obtained by sweeping the driver instead of simulating a dose. Model family: indirect_response_iii.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = (library default) drug-free response (baseline)
  Emax  =         64          maximal effect term (efficacy, Q320)
  EC50  =       0.41 ng/mL    exposure at half of the maximal effect term (drug potency, Q321)
  gamma = (library default) Hill coefficient</pre><p>The algebra is <code>response = E0*(1 + Emax*frac)</code>; this model only supplies the numbers. The x axis is one ng/mL of darbepoetin alfa per second of simulated time (exposure is in kg/m3): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0   (drug-free)
  exposure = EC50 (0.41 ng/mL)  response 0
  exposure -> infinity  response 0</pre></body></html>"));
end DarbepoetinAlfa_Doshi2010_PD_hgb;
