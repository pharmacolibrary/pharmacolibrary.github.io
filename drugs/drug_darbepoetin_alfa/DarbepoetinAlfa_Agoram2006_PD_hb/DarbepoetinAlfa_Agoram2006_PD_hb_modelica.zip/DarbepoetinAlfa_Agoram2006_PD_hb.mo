model DarbepoetinAlfa_Agoram2006_PD_hb
  "indirect_response_iii exposure-response sweep — Agoram_2006 :: Hb (hemoglobin)"
  extends Pharmacolibrary.Interfaces.PartialExposureResponseSweep(
    E0 = 0,      // [1]
    Emax = 43.7,  // type III effect term
    EC50 = 3.68e-06,  // [kg/m3; ng/mL × 1e-06]
    gamma = 1,
    exposure_per_s = 1e-06);   // 1 ng/mL per second
equation
  response = E0*(1 + Emax*frac);   // steady state, indirect response type III
  // defaulted: E0
  // defaulted: gamma
  annotation(experiment(StartTime = 0, StopTime = 37, Interval = 0.074),
    Documentation(info = "<html><body><!-- drug-about --><h4>About darbepoetin_alfa</h4><p>Darbepoetin alfa is an antianemic medicine used to treat anemia, including anemia linked to chronic kidney failure and cancer treatment. It is an approved medicine authorised in the European Union, though it carries a boxed warning.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q2178381\">Wikidata Q2178381</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h4>DarbepoetinAlfa_Agoram2006_PD_hb</h4><p>The steady-state exposure-response curve of Agoram B et al., <i>The AAPS journal 8(3):E552–E563</i> 2006 (<a href=\"https://doi.org/10.1208/aapsj080364\">doi:10.1208/aapsj080364</a>) — hemoglobin against darbepoetin_alfa ng/mL — obtained by sweeping the driver instead of simulating a dose. Model family: indirect_response_iii.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = (library default) drug-free response (baseline)
  Emax  =       43.7          maximal effect term (incremental maximum stimulation of hemoglobin production, Q320)
  EC50  =       3.68 ng/mL    exposure at half of the maximal effect term (darbepoetin alfa serum concentration at half-maximal stimulation, Q321)
  gamma = (library default) Hill coefficient</pre><p>The algebra is <code>response = E0*(1 + Emax*frac)</code>; this model only supplies the numbers. The x axis is one ng/mL of darbepoetin_alfa per second of simulated time (exposure is in kg/m3): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0   (drug-free)
  exposure = EC50 (3.68 ng/mL)  response 0
  exposure -> infinity  response 0</pre></body></html>"));
end DarbepoetinAlfa_Agoram2006_PD_hb;
