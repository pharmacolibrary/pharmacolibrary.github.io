function p = DarbepoetinAlfa_Agoram2006_PD_hb_params()
% DarbepoetinAlfa_Agoram2006_PD_hb_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% darbepoetin_alfa Agoram_2006::Hb: indirect_response_iii exposure-response sweep (response = E0*(1 + Emax*frac)). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one ng/mL per second, in SI inside (kg/m3, s). Response Hb in its own unit. Driver: darbepoetin_alfa (pk_record).
p.E0 = 0.0;
p.Emax = 43.7;
p.EC50 = 3.68e-06;
p.gamma = 1.0;
p.slope = 0.0;
p.exposure_per_s = 1e-06;
p.stop_time = 37.0;
p.form = 'E0*(1 + Emax*frac)';
end
