function p = DarbepoetinAlfa_Doshi2010_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: darbepoetin_alfa   source: Doshi_2010 / reference   route: iv_bolus
  p.name  = 'DarbepoetinAlfa_Doshi2010_reference_params';
  p.drug  = 'darbepoetin_alfa';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'iv_bolus';        % 'oral' | 'iv_bolus'
  p.depot = false;             % oral -> first-order absorption depot
  p.Vc = 5.9;                % central volume [L]
  p.CL = 0.141667;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.0;                % absorption rate [1/h]
  p.F  = 0.44;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 0.0045;             % dose [mg]
end
