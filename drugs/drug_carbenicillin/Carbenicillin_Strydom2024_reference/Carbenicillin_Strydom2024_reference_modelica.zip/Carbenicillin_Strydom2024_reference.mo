model Carbenicillin_Strydom2024_reference
  parameter Real Cl_ref = 9.11111111111111e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.049 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.37839999999999996,
    adminMass = 0.0001,
    ka = 0.0003055555555555556,
    Tlag = 0.0,
    k12 = 4.535147392290249e-06,
    k21 = 1.5873015873015876e-05
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About carbenicillin</h4><p>Carbenicillin is an extended-spectrum penicillin antibiotic used to treat urinary tract infections, prostatitis, and other gram-negative bacterial infections. It is an approved antibacterial for systemic use, though it is not authorised in the European Union and is now little used, having largely been replaced by newer agents.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q1050019\">Wikidata Q1050019</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>carbenicillin</td></tr><tr><td>population:</td><td>review reference</td></tr><tr><td>source_paper:</td><td>Strydom_2024</td></tr><tr><td>measured_compound:</td><td>carbenicillin</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_2C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>carbenicillin 378.4 g/mol (drugbank)</td></tr></table><p><b>Defaulted (base-class default used):</b> Tlag.</p><h4>Interpretation flags</h4><ul><li>built from REVIEW reference values (Strydom_2024) — secondary source</li><li>volume reported by review</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Carbenicillin_Strydom2024_reference;
