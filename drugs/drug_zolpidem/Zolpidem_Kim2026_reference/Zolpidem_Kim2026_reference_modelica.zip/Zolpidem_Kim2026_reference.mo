model Zolpidem_Kim2026_reference
  parameter Real Cl_ref = 5e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.064 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.3073895,
    adminMass = 1e-05,
    ka = 0.00325,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About zolpidem</h4><p>Zolpidem is a sedative-hypnotic used to treat insomnia and other sleep disorders. It is an approved medicine, widely used as a short-term sleep aid, though it is a controlled drug in many countries.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q218842\">Wikidata Q218842</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>zolpidem</td></tr><tr><td>population:</td><td>healthy Korean volunteers</td></tr><tr><td>source_paper:</td><td>Kim_2026</td></tr><tr><td>measured_compound:</td><td>zolpidem</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>psp470208-tbl-0002</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>zolpidem 307.389 g/mol (drugbank)</td></tr></table><p><b>Defaulted (base-class default used):</b> Tlag.</p><h4>Interpretation flags</h4><ul><li>table section iiv: 'Proportional residual error (%)' routed out of structural estimates ('IIV BIO (%CV)')</li><li>apparent-ness (ontology-grounded): parameterization=apparent, measured_compound=zolpidem</li><li>1C volume normalization: Q290→Q76 (single-compartment model has no central/peripheral split; 'Vc/F (L)' is the general volume)</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of TLAG: primary's parameterization (rate-constant / ka-only) does not use it</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Zolpidem_Kim2026_reference;
