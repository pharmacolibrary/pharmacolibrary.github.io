model Zolpidem_Kim2026_PD_dsst
  "sigmoid_emax exposure-response sweep — Kim_2026 :: DSST (digit symbol substitution test)"
  extends Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep(
    E0 = 68.2,      // [score]
    Emax = -14.4,  // [score]
    EC50 = 0.000205,  // [kg/m3; μg/L × 1e-06]
    gamma = 2.54,
    exposure_per_s = 1e-06);   // 1 μg/L per second
  // imax_as_negative_emax: Imax (Q323) enters SigmoidEmaxSweep as −Emax
  annotation(experiment(StartTime = 0, StopTime = 2100, Interval = 4.2),
    Documentation(info = "<html><body><!-- drug-about --><h4>About zolpidem</h4><p>Zolpidem is a sedative-hypnotic used to treat insomnia and other sleep disorders. It is an approved medicine, widely used as a short-term sleep aid, though it is a controlled drug in many countries.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q218842\">Wikidata Q218842</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h4>Zolpidem_Kim2026_PD_dsst</h4><p>The steady-state exposure-response curve of Kim HC et al., <i>CPT: pharmacometrics &amp; systems pharmacology 15(3):e70208</i> 2026 (<a href=\"https://doi.org/10.1002/psp4.70208\">doi:10.1002/psp4.70208</a>) — digit symbol substitution test [score] against zolpidem μg/L — obtained by sweeping the driver instead of simulating a dose. Model family: sigmoid_emax.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    =       68.2 score    drug-free response (baseline) (BASE, Q324)
  Emax  =       14.4 score    maximal effect term (MAXlearn, Q323)
  EC50  =        205 μg/L     exposure at half of the maximal effect term (IC50, Q322)
  gamma =       2.54          Hill coefficient (HILL, Q325)</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep\">SigmoidEmaxSweep</a>; this model only supplies the numbers. The x axis is one μg/L of zolpidem per second of simulated time (exposure is in kg/m3): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 68.2   (drug-free)
  exposure = EC50 (205 μg/L)  response 61
  exposure -> infinity  response 53.8</pre></body></html>"));
end Zolpidem_Kim2026_PD_dsst;
