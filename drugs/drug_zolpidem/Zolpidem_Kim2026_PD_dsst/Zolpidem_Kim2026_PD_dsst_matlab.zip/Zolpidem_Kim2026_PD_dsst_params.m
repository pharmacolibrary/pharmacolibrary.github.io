function p = Zolpidem_Kim2026_PD_dsst_params()
% Zolpidem_Kim2026_PD_dsst_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% zolpidem Kim_2026::DSST: sigmoid_emax exposure-response sweep (response = E0 + Emax*frac). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one μg/L per second, in SI inside (kg/m3, s). Response DSST in score. Driver: zolpidem (pk_record).
p.E0 = 68.2;
p.Emax = -14.4;
p.EC50 = 0.00020499999999999994;
p.gamma = 2.54;
p.slope = 0.0;
p.exposure_per_s = 1e-06;
p.stop_time = 2100.0;
p.form = 'E0 + Emax*frac';
end
