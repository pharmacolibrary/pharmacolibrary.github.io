model Zolpidem_Cha2024_reference
  parameter Real Cl_ref = 4.694444444444444e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.061700000000000005 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.3073895,
    adminMass = 1e-05,
    ka = 0.0015027777777777778,
    Tlag = 1418.4
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About zolpidem</h4><p>Zolpidem is a sedative-hypnotic used to treat insomnia and other sleep disorders. It is an approved medicine, widely used as a short-term sleep aid, though it is a controlled drug in many countries.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q218842\">Wikidata Q218842</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>zolpidem</td></tr><tr><td>population:</td><td>healthy adults</td></tr><tr><td>source_paper:</td><td>Cha_2024</td></tr><tr><td>measured_compound:</td><td>zolpidem</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>pharmaceutics-16-00689-t002</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>zolpidem 307.389 g/mol (drugbank)</td></tr></table><h4>Interpretation flags</h4><ul><li>table section iiv: 'ω2 Ka (CV b %)' routed out of structural estimates ('Interindividual variability (IIV)')</li><li>table section iiv: 'ω2 Ka (CV b %)' routed out of structural estimates ('Interindividual variability (IIV)')</li><li>table section iiv: 'ω2 Ka (CV b %)' routed out of structural estimates ('Interindividual variability (IIV)')</li><li>table section iiv: 'ω2 Vd (CV%)' routed out of structural estimates ('Interindividual variability (IIV)')</li><li>table section iiv: 'ω2 Vd (CV%)' routed out of structural estimates ('Interindividual variability (IIV)')</li><li>table section iiv: 'ω2 Vd (CV%)' routed out of structural estimates ('Interindividual variability (IIV)')</li><li>table section iiv: 'ω2 CL (CV%)' routed out of structural estimates ('Interindividual variability (IIV)')</li><li>table section iiv: 'ω2 CL (CV%)' routed out of structural estimates ('Interindividual variability (IIV)')</li><li>table section iiv: 'ω2 CL (CV%)' routed out of structural estimates ('Interindividual variability (IIV)')</li><li>table section iiv: 'ρVd-CL' routed out of structural estimates ('Interindividual variability (IIV)')</li><li>table section iiv: 'ρVd-CL' routed out of structural estimates ('Interindividual variability (IIV)')</li><li>table section iiv: 'ρVd-CL' routed out of structural estimates ('Interindividual variability (IIV)')</li><li>table section residual_error: 'Proportional error' routed out of structural estimates ('Residual variability')</li><li>table section residual_error: 'Proportional error' routed out of structural estimates ('Residual variability')</li><li>table section residual_error: 'Proportional error' routed out of structural estimates ('Residual variability')</li><li>column 'bootstrap' classified 'other' by the LLM but kept: the deterministic diagnostic-column test disagrees (a stratum column is a value column, not a statistic)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Zolpidem_Cha2024_reference;
