model Zolpidem_Perrais1999_PD_mipsc_duration
  "sigmoid_emax exposure-response sweep — Perrais_1999 :: mIPSC duration (mIPSC duration (relative to control))"
  extends Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep(
    E0 = 0,      // [1]
    Emax = 221,  // [% of control duration]
    EC50 = 5.8,  // [µM]
    gamma = 0.36,
    exposure_per_s = 1);   // 1 µM per second
  // exposure_unit_unresolved: 'µM' — the x axis is in the paper's unit, not SI
  // defaulted: E0
  annotation(experiment(StartTime = 0, StopTime = 58, Interval = 0.116),
    Documentation(info = "<html><body><!-- drug-about --><h4>About zolpidem</h4><p>Zolpidem is a sedative-hypnotic used to treat insomnia and other sleep disorders. It is an approved medicine, widely used as a short-term sleep aid, though it is a controlled drug in many countries.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q218842\">Wikidata Q218842</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h4>Zolpidem_Perrais1999_PD_mipsc_duration</h4><p>The steady-state exposure-response curve of Perrais D et al., <i>The Journal of neuroscience : the official journal of the Society for Neuroscience 19(2):578–588</i> 1999 (<a href=\"https://doi.org/10.1523/JNEUROSCI.19-02-00578.1999\">doi:10.1523/JNEUROSCI.19-02-00578.1999</a>) — mIPSC duration (relative to control) [% of control] against zolpidem µM — obtained by sweeping the driver instead of simulating a dose. Model family: sigmoid_emax.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = (library default) drug-free response (baseline)
  Emax  =        221 % of control duration maximal effect term (maximal relative increase of the duration, Q320)
  EC50  =        5.8 µM       exposure at half of the maximal effect term (EC50, Q321)
  gamma =       0.36          Hill coefficient (Hill coefficient, Q325)</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep\">SigmoidEmaxSweep</a>; this model only supplies the numbers. The x axis is one µM of zolpidem per second of simulated time: there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0   (drug-free)
  exposure = EC50 (5.8 µM)  response 110.5
  exposure -> infinity  response 221</pre></body></html>"));
end Zolpidem_Perrais1999_PD_mipsc_duration;
