function p = Zolpidem_Perrais1999_PD_mipsc_duration_params()
% Zolpidem_Perrais1999_PD_mipsc_duration_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% zolpidem Perrais_1999::mIPSC_duration: sigmoid_emax exposure-response sweep (response = E0 + Emax*frac). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one µM per second, in SI inside (kg/m3, s). Response mIPSC duration in % of control. Driver: zolpidem (cited_pk).
p.E0 = 0.0;
p.Emax = 221.0;
p.EC50 = 5.8;
p.gamma = 0.36;
p.slope = 0.0;
p.exposure_per_s = 1.0;
p.stop_time = 58.0;
p.form = 'E0 + Emax*frac';
end
