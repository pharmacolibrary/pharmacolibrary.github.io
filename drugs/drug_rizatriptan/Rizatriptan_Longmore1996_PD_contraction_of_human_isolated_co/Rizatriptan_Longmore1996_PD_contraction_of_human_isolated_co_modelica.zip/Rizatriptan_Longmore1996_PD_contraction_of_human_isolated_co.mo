model Rizatriptan_Longmore1996_PD_contraction_of_human_isolated_co
  "sigmoid_emax exposure-response sweep — Longmore_1996 :: contraction of human isolated coronary artery (contraction of human isolated coronary artery)"
  extends Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep(
    E0 = 0,      // [1]
    Emax = 22.2,  // [% 45 mM KCl]
    EC50 = 1.02,  // [mM]
    gamma = 1,
    exposure_per_s = 1);   // 1 mM per second
  // exposure_unit_unresolved: 'mM' — the x axis is in the paper's unit, not SI
  // defaulted: E0
  // defaulted: gamma
  annotation(experiment(StartTime = 0, StopTime = 11, Interval = 0.022),
    Documentation(info = "<html><body><h4>Rizatriptan_Longmore1996_PD_contraction_of_human_isolated_co</h4><p>The steady-state exposure-response curve of Longmore J et al., <i>British journal of clinical pharmacology 42(4):431–441</i> 1996 (<a href=\"https://doi.org/10.1046/j.1365-2125.1996.04217.x\">doi:10.1046/j.1365-2125.1996.04217.x</a>) — contraction of human isolated coronary artery [% 45 mM KCl] against rizatriptan mM — obtained by sweeping the driver instead of simulating a dose. Model family: sigmoid_emax.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = (library default) drug-free response (baseline)
  Emax  =       22.2 % 45 mM KCl maximal effect term (E max, Q320)
  EC50  =       1.02 mM       exposure at half of the maximal effect term (EC 50, Q321)
  gamma = (library default) Hill coefficient</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep\">SigmoidEmaxSweep</a>; this model only supplies the numbers. The x axis is one mM of rizatriptan per second of simulated time: there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0   (drug-free)
  exposure = EC50 (1.02 mM)  response 11.1
  exposure -> infinity  response 22.2</pre></body></html>"));
end Rizatriptan_Longmore1996_PD_contraction_of_human_isolated_co;
