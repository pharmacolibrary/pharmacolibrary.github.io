function p = Rizatriptan_Longmore1996_PD_contraction_of_human_isolated_co_params()
% Rizatriptan_Longmore1996_PD_contraction_of_human_isolated_co_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% rizatriptan Longmore_1996::contraction_of_human_isolated_coronary_artery: sigmoid_emax exposure-response sweep (response = E0 + Emax*frac). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one mM per second, in SI inside (kg/m3, s). Response contraction of human isolated coronary artery in % 45 mM KCl. Driver: rizatriptan (conc_no_pk).
p.E0 = 0.0;
p.Emax = 22.2;
p.EC50 = 1.02;
p.gamma = 1.0;
p.slope = 0.0;
p.exposure_per_s = 1.0;
p.stop_time = 11.0;
p.form = 'E0 + Emax*frac';
end
