% run_Rizatriptan_Longmore1996_PD_contraction_of_human_isolated_co  Evaluate the exposure-response curve and plot response against exposure.
% A sweep is a static map: no ODE solver is needed. exposure runs 0..stop_time*exposure_per_s.
p = Rizatriptan_Longmore1996_PD_contraction_of_human_isolated_co_params();
exposure = linspace(0, p.stop_time * p.exposure_per_s, 501);
frac = exposure.^p.gamma ./ (p.EC50^p.gamma + exposure.^p.gamma);
E0 = p.E0; Emax = p.Emax; slope = p.slope;
response = E0 + Emax.*frac;
figure; plot(exposure, response, 'LineWidth', 1.5); grid on;
xlabel('exposure [mM]'); ylabel('response [% 45 mM KCl]'); title('Rizatriptan_Longmore1996_PD_contraction_of_human_isolated_co', 'Interpreter', 'none');
writematrix([exposure(:) response(:)], 'Rizatriptan_Longmore1996_PD_contraction_of_human_isolated_co.csv');
