model Voxelotor_Savic2022_reference
  parameter Real Cl_ref = 1.7055555555555554e-06 "Cl [m3/s]";
  parameter Real cov_cyp3a4_0 = 0 "cyp3a4 covariate";
  parameter Real Vd_ref = 0.333 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref*(1 + (0.39)*cov_cyp3a4_0),
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.33737900000000004,
    adminMass = 0.0005,
    ka = 0.0006611111111111111,
    Tlag = 0.0,
    k12 = 3.2532532532532534e-07,
    k21 = 1.4983863531581375e-06
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About voxelotor</h4><p>Voxelotor is a hematological drug developed for the treatment of sickle cell anemia. Its marketing in the European Union has been suspended, so it is no longer available there.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q60761545\">Wikidata Q60761545</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>voxelotor</td></tr><tr><td>population:</td><td>adults and adolescents with sickle cell disease</td></tr><tr><td>source_paper:</td><td>Savic_2022</td></tr><tr><td>measured_compound:</td><td>voxelotor</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>psp412731-tbl-0002</td></tr><tr><td>input:</td><td>PK_2C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>voxelotor 337.379 g/mol (drugbank)</td></tr></table><p><b>Defaulted (base-class default used):</b> Tlag.</p><h4>Interpretation flags</h4><ul><li>table section iiv: 'BSV CL/F, % CV' routed out of structural estimates ('Between subject or occasion variability')</li><li>table section iiv: 'BSV CL/F, % CV' routed out of structural estimates ('Between subject or occasion variability')</li><li>table section iiv: 'CL/F‐V c/F BSV correlation' routed out of structural estimates ('Between subject or occasion variability')</li><li>table section iiv: 'BSV V c/F, % CV' routed out of structural estimates ('Between subject or occasion variability')</li><li>table section iiv: 'BSV V c/F, % CV' routed out of structural estimates ('Between subject or occasion variability')</li><li>table section iiv: 'BSV K bp, % CV' routed out of structural estimates ('Between subject or occasion variability')</li><li>table section iiv: 'BSV K bp, % CV' routed out of structural estimates ('Between subject or occasion variability')</li><li>table section iiv: 'K bp‐R bp BSV correlation' routed out of structural estimates ('Between subject or occasion variability')</li><li>table section iiv: 'BSV R bp, % CV' routed out of structural estimates ('Between subject or occasion variability')</li><li>table section iiv: 'BSV R bp, % CV' routed out of structural estimates ('Between subject or occasion variability')</li><li>table section iiv: 'BOV on CL/F, % CV' routed out of structural estimates ('Between subject or occasion variability')</li><li>table section iiv: 'BOV on CL/F, % CV' routed out of structural estimates ('Between subject or occasion variability')</li><li>table section residual_error: 'Proportional error, plasma (%)' routed out of structural estimates ('Residual variability')</li><li>table section residual_error: 'Proportional error, whole blood (%)' routed out of structural estimates ('Residual variability')</li><li>table section residual_error: 'Additive error, whole blood (ng/ml)' routed out of structural estimates ('Residual variability')</li><li>dropped unlinked row (NIL): 'R bp' — extend the ontology if this is a real PK parameter (source ['psp412731-tbl-0002:row6:col1'])</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 691200, Tolerance = 1e-9, Interval = 1));
end Voxelotor_Savic2022_reference;
