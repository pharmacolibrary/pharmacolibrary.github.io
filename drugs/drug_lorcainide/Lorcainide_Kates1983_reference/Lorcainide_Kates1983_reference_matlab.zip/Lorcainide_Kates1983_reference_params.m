function p = Lorcainide_Kates1983_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: lorcainide   source: Kates_1983 / reference   route: iv_bolus
  % estimated (absent from source): F
  % Vc is the record's Vss — no central volume was reported; 1-compartment reading
  p.name  = 'Lorcainide_Kates1983_reference_params';
  p.drug  = 'lorcainide';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'iv_bolus';        % 'oral' | 'iv_bolus'
  p.depot = false;             % oral -> first-order absorption depot
  p.Vc = 443.1;                % central volume [L]
  p.CL = 60.48;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.0;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 200.0;             % dose [mg]
end
