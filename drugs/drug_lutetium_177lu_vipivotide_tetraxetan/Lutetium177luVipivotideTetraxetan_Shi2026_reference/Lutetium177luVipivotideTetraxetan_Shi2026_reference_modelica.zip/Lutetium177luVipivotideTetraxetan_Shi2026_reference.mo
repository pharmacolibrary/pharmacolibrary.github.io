model Lutetium177luVipivotideTetraxetan_Shi2026_reference
  parameter Real Cl_ref = 4.5000000000000003e-07 "Cl [m3/s]";
  parameter Real Vd_ref = 0.123 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 1.2141,
    adminMass = 1e-05
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About lutetium_177lu_vipivotide_tetraxetan</h4><p>Lutetium vipivotide tetraxetan is a therapeutic radiopharmaceutical used to treat prostate cancer, including castration-resistant disease. It is authorised in the European Union and is also being investigated for further uses.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q111353661\">Wikidata Q111353661</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>lutetium_177lu_vipivotide_tetraxetan</td></tr><tr><td>population:</td><td>review reference</td></tr><tr><td>source_paper:</td><td>Shi_2026</td></tr><tr><td>measured_compound:</td><td>lutetium_177lu_vipivotide_tetraxetan</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>lutetium_177lu_vipivotide_tetraxetan 1214.1 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>built from REVIEW reference values (Shi_2026) — secondary source</li><li>volume reported by review</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 950400, Tolerance = 1e-9, Interval = 1));
end Lutetium177luVipivotideTetraxetan_Shi2026_reference;
