model Lisinopril_Sandra2024_reference
  parameter Real Cl_ref = 0.00047055555555555555 "Cl [m3/s]";
  parameter Real Vd_ref = 2.1965999999999997 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 0.9,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.4054879,
    adminMass = 1e-05,
    ka = 2.0833333333333333e-05,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About lisinopril</h4><p>Lisinopril is an ACE inhibitor used to treat high blood pressure, heart failure, and after a heart attack. It is an approved medicine, widely used in general practice, and also available in fixed combinations with diuretics or other cardiovascular drugs.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q412208\">Wikidata Q412208</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>lisinopril</td></tr><tr><td>population:</td><td>hypertensive children and adolescents with normal to mildly reduced kidney function</td></tr><tr><td>source_paper:</td><td>Sandra_2024</td></tr><tr><td>measured_compound:</td><td>lisinopril</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>lisinopril 405.488 g/mol (drugbank)</td></tr></table><p><b>Defaulted (base-class default used):</b> F, Tlag.</p><h4>Interpretation flags</h4><ul><li>dropped value-less row: 'total body weight on elimination clearance'</li><li>dropped value-less row: 'total body weight on distribution volume'</li><li>dropped value-less row: 'estimated glomerular filtration rate (eGFR) on elimination clearance'</li><li>covariate egfr for CL from footnote/prose kept as documentation only (['Sandra_2024:abstract', 'Sandra_2024:abstract'])</li><li>apparent-by-design (ADVISORY, codes unchanged): extravascular dosing with no identifiable F, so these reported disposition parameters are likely apparent unless the model puts first-pass in its structure — Q61 (volume of distribution); Q22 (elimination clearance)</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=lisinopril</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of TLAG: primary's parameterization (rate-constant / ka-only) does not use it</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 162000, Tolerance = 1e-9, Interval = 1));
end Lisinopril_Sandra2024_reference;
