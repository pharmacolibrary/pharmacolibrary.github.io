model Lisinopril_Bellissant1996_PD_baf
  "sigmoid_emax exposure-response sweep — Bellissant_1996 :: BAF (brachial artery flow)"
  extends Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep(
    E0 = 0,      // [1]
    Emax = 7.5e-07,  // [m3/s; ml/min × 1.66667e-08]
    EC50 = 2.4e-05,  // [kg/m3; ng/ml × 1e-06]
    gamma = 3.2,
    exposure_per_s = 1e-06);   // 1 ng/ml per second
  // defaulted: E0
  annotation(experiment(StartTime = 0, StopTime = 240, Interval = 0.48),
    Documentation(info = "<html><body><!-- drug-about --><h4>About lisinopril</h4><p>Lisinopril is an ACE inhibitor used to treat high blood pressure, heart failure, and after a heart attack. It is an approved medicine, widely used in general practice, and also available in fixed combinations with diuretics or other cardiovascular drugs.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q412208\">Wikidata Q412208</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h4>Lisinopril_Bellissant1996_PD_baf</h4><p>The steady-state exposure-response curve of Bellissant E et al., <i>Journal of cardiovascular pharmacology 28(3):470–478</i> 1996 (<a href=\"https://doi.org/10.1097/00005344-199609000-00018\">doi:10.1097/00005344-199609000-00018</a>) — brachial artery flow [ml/min] against lisinopril ng/ml — obtained by sweeping the driver instead of simulating a dose. Model family: sigmoid_emax.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = (library default) drug-free response (baseline)
  Emax  =         45 ml/min   maximal effect term (Emax, Q320)
  EC50  =         24 ng/ml    exposure at half of the maximal effect term (CE50, Q321)
  gamma =        3.2          Hill coefficient (gamma, Q325)</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep\">SigmoidEmaxSweep</a>; this model only supplies the numbers. The x axis is one ng/ml of lisinopril per second of simulated time (exposure is in kg/m3): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0   (drug-free)
  exposure = EC50 (24 ng/ml)  response 3.75e-07
  exposure -> infinity  response 7.5e-07</pre></body></html>"));
end Lisinopril_Bellissant1996_PD_baf;
