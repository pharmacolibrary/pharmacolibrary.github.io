function p = Lisinopril_Bellissant1996_PD_bvr_params()
% Lisinopril_Bellissant1996_PD_bvr_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% lisinopril Bellissant_1996::BVR: sigmoid_emax exposure-response sweep (response = E0 + Emax*frac). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one ng/ml per second, in SI inside (kg/m3, s). Response BVR in mm Hg . s/ml. Driver: lisinopril (cited_pk).
p.E0 = 0.0;
p.Emax = -0.45;
p.EC50 = 2.2e-05;
p.gamma = 3.1;
p.slope = 0.0;
p.exposure_per_s = 1e-06;
p.stop_time = 220.0;
p.form = 'E0 + Emax*frac';
end
