model Ergotamine_Kudupoje2018_PD_ne_normalized_contraction
  "sigmoid_emax exposure-response sweep — Kudupoje_2018 :: NE-normalized % contraction (Norepinephrine normalized percent contractile response)"
  extends Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep(
    E0 = 0.057,      // [1; % × 0.01]
    Emax = 0.885,  // [1; % × 0.01]
    EC50 = 6.66,  // [−Log [ETA]]
    gamma = 1,
    exposure_per_s = 1);   // 1 −Log [ETA] per second
  // exposure_unit_unresolved: '−Log [ETA]' — the x axis is in the paper's unit, not SI
  // defaulted: gamma
  annotation(experiment(StartTime = 0, StopTime = 67, Interval = 0.134),
    Documentation(info = "<html><body><h4>Ergotamine_Kudupoje2018_PD_ne_normalized_contraction</h4><p>The steady-state exposure-response curve of Kudupoje MB et al., <i>Toxins 10(2)</i> 2018 (<a href=\"https://doi.org/10.3390/toxins10020058\">doi:10.3390/toxins10020058</a>) — Norepinephrine normalized percent contractile response [%] against ergotamine tartrate −Log [ETA] — obtained by sweeping the driver instead of simulating a dose. Model family: sigmoid_emax.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    =        5.7 %        drug-free response (baseline) (Minimum contractile response, Q324)
  Emax  =       88.5 %        maximal effect term (Maximum contractile response, Q320)
  EC50  =       6.66 −Log [ETA] exposure at half of the maximal effect term (Log EC50, Q321)
  gamma = (library default) Hill coefficient</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep\">SigmoidEmaxSweep</a>; this model only supplies the numbers. The x axis is one −Log [ETA] of ergotamine tartrate per second of simulated time: there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0.057   (drug-free)
  exposure = EC50 (6.66 −Log [ETA])  response 0.4995
  exposure -> infinity  response 0.942</pre></body></html>"));
end Ergotamine_Kudupoje2018_PD_ne_normalized_contraction;
