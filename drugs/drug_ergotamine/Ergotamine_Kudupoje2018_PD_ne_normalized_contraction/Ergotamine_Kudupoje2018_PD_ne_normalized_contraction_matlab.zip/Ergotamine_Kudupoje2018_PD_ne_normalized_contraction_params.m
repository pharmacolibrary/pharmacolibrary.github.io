function p = Ergotamine_Kudupoje2018_PD_ne_normalized_contraction_params()
% Ergotamine_Kudupoje2018_PD_ne_normalized_contraction_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% ergotamine Kudupoje_2018::NE_normalized_contraction: sigmoid_emax exposure-response sweep (response = E0 + Emax*frac). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one −Log [ETA] per second, in SI inside (kg/m3, s). Response NE-normalized % contraction in %. Driver: ergotamine tartrate (not_resolved).
p.E0 = 0.057;
p.Emax = 0.885;
p.EC50 = 6.66;
p.gamma = 1.0;
p.slope = 0.0;
p.exposure_per_s = 1.0;
p.stop_time = 67.0;
p.form = 'E0 + Emax*frac';
end
