function p = Isavuconazole_Caballero2023_PD_n_params()
% Isavuconazole_Caballero2023_PD_n_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% isavuconazole Caballero_2023::N: sigmoid_emax exposure-response sweep (response = E0 + Emax*frac). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one mg/L per second, in SI inside (kg/m3, s). Response N in log CFU/mL. Driver: isavuconazole (cited_pk).
p.E0 = 0.0;
p.Emax = -5.500000000000001e-06;
p.EC50 = 6.829999999999998e-05;
p.gamma = 1.58;
p.slope = 0.0;
p.exposure_per_s = 0.001;
p.stop_time = 0.69;
p.form = 'E0 + Emax*frac';
end
