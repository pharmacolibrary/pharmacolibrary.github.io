model Isavuconazole_Caballero2023_PD_n
  "sigmoid_emax exposure-response sweep — Caballero_2023 :: N (number of viable cells)"
  extends Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep(
    E0 = 0,      // [1]
    Emax = -5.5e-06,  // [1/s; h−1 × 0.000277778]
    EC50 = 6.83e-05,  // [kg/m3; mg/L × 0.001]
    gamma = 1.58,
    exposure_per_s = 0.001);   // 1 mg/L per second
  // imax_as_negative_emax: Imax (Q323) enters SigmoidEmaxSweep as −Emax
  // defaulted: E0
  annotation(experiment(StartTime = 0, StopTime = 0.69, Interval = 0.00138),
    Documentation(info = "<html><body><!-- drug-about --><h4>About isavuconazole</h4><p>Isavuconazole is a triazole antifungal used to treat aspergillosis, a fungal infection. It is authorised in the European Union and is an approved medicine, though also still under investigation for other uses.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q6079042\">Wikidata Q6079042</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h4>Isavuconazole_Caballero2023_PD_n</h4><p>The steady-state exposure-response curve of Caballero U et al., <i>CPT: pharmacometrics &amp; systems pharmacology 12(6):770–782</i> 2023 (<a href=\"https://doi.org/10.1002/psp4.12949\">doi:10.1002/psp4.12949</a>) — number of viable cells [log CFU/mL] against isavuconazole mg/L — obtained by sweeping the driver instead of simulating a dose. Model family: sigmoid_emax.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = (library default) drug-free response (baseline)
  Emax  =     0.0198 h−1      maximal effect term (E maxISV, Q323)
  EC50  =     0.0683 mg/L     exposure at half of the maximal effect term (EC50ISV, Q321)
  gamma =       1.58          Hill coefficient (h ISV, Q325)</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep\">SigmoidEmaxSweep</a>; this model only supplies the numbers. The x axis is one mg/L of isavuconazole per second of simulated time (exposure is in kg/m3): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0   (drug-free)
  exposure = EC50 (0.0683 mg/L)  response -2.75e-06
  exposure -> infinity  response -5.5e-06</pre></body></html>"));
end Isavuconazole_Caballero2023_PD_n;
