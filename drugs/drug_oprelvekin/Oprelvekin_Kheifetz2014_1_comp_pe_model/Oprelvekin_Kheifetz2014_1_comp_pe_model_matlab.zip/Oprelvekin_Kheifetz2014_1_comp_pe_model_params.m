function p = Oprelvekin_Kheifetz2014_1_comp_pe_model_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: oprelvekin   source: Kheifetz_2014 / 1_comp_pe_model   route: oral
  % estimated (absent from source): F
  p.name  = 'Oprelvekin_Kheifetz2014_1_comp_pe_model_params';
  p.drug  = 'oprelvekin';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 173.0;                % central volume [L]
  p.CL = 13.3;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.152;                % absorption rate [1/h]
  p.F  = 0.9;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 3.5;             % dose [mg]
end
