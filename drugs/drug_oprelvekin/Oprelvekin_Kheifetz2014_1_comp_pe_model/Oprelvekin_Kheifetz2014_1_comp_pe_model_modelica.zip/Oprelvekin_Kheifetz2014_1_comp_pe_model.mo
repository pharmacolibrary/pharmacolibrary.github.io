model Oprelvekin_Kheifetz2014_1_comp_pe_model
  parameter Real Cl_ref = 3.6944444444444446e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.17300000000000001 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 0.9,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    adminMass = 3.5e-06,
    ka = 4.222222222222222e-05,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About oprelvekin</h4><p>Oprelvekin is a recombinant interleukin that acts as an immunostimulant in the treatment of cancer-related conditions. It was approved at one point but has been withdrawn and is no longer in general use.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q7098691\">Wikidata Q7098691</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>oprelvekin</td></tr><tr><td>population:</td><td>healthy males</td></tr><tr><td>source_paper:</td><td>Kheifetz_2014</td></tr><tr><td>measured_compound:</td><td>oprelvekin</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>Table S1</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr></table><p><b>Defaulted (base-class default used):</b> F, Tlag.</p><h4>Interpretation flags</h4><ul><li>dropped diagnostic row 'CNᵇ' → Q318 (shrinkage) — reported statistic, not a parameter</li><li>dropped unlinked row (NIL): 'CNᶜ' — extend the ontology if this is a real PK parameter (source ['Kheifetz_2014_table_p3_1:row11:col11'])</li><li>dropped unlinked row (NIL): 'nLL' — extend the ontology if this is a real PK parameter (source ['Kheifetz_2014_table_p3_1:row12:col11', 'Kheifetz_2014_table_p3_1:row12:col12'])</li><li>dropped unlinked row (NIL): 'AIC' — extend the ontology if this is a real PK parameter (source ['Kheifetz_2014_table_p3_1:row13:col11', 'Kheifetz_2014_table_p3_1:row13:col12'])</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=oprelvekin</li><li>structure disagreement: deterministic 1C vs LLM 2C — review compartment count</li><li>1C volume normalization: Q63→Q61 (single-compartment model has no central/peripheral split; 'V₁, l' is the general volume)</li><li>population split: '1 comp. pe model' subgroup of Kheifetz_2014 (paper reports 4 populations: 1 comp. pe model, 2 comp. ce model, 2 comp. pe model, 3 comp. pe model)</li><li>molar mass: none found for 'oprelvekin' — its concentrations stay mass-only</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li><li>gap-filled Q49 (kabs) from Myzithras_2022's review values (primary lacked it)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 259200, Tolerance = 1e-9, Interval = 1));
end Oprelvekin_Kheifetz2014_1_comp_pe_model;
