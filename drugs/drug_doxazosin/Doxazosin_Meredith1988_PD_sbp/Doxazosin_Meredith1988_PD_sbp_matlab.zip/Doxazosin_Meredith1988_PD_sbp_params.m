function p = Doxazosin_Meredith1988_PD_sbp_params()
% Doxazosin_Meredith1988_PD_sbp_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% doxazosin Meredith_1988::SBP: linear exposure-response sweep (response = E0 + slope*exposure). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one SI per second, in SI inside (kg/m3, s). Response SBP in mmHg. Driver: doxazosin (cited_pk).
p.E0 = 0.0;
p.Emax = 0.0;
p.EC50 = 1.0;
p.gamma = 1.0;
p.slope = -2.05;
p.exposure_per_s = 1.0;
p.stop_time = 1000.0;
p.form = 'E0 + slope*exposure';
end
