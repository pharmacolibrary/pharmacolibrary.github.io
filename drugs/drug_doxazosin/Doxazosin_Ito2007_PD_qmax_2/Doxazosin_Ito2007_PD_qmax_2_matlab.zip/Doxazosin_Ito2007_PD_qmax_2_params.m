function p = Doxazosin_Ito2007_PD_qmax_2_params()
% Doxazosin_Ito2007_PD_qmax_2_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% doxazosin Ito_2007::Qmax::2: linear exposure-response sweep (response = E0 + slope*exposure). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one ng ml -1 per second, in SI inside (kg/m3, s). Response Qmax in ml s -1. Driver: doxazosin (cited_pk).
p.E0 = 9.530000000000001e-08;
p.Emax = 0.0;
p.EC50 = 1.0;
p.gamma = 1.0;
p.slope = 2.9700000000000006e-10;
p.exposure_per_s = 1e-06;
p.stop_time = 1000.0;
p.form = 'E0 + slope*exposure';
end
