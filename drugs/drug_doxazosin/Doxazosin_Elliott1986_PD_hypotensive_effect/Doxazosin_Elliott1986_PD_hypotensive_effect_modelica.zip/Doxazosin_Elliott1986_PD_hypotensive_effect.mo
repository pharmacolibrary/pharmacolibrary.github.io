model Doxazosin_Elliott1986_PD_hypotensive_effect
  "linear exposure-response sweep — Elliott_1986 :: hypotensive effect (hypotensive effect)"
  extends Pharmacolibrary.Interfaces.PartialExposureResponseSweep(
    E0 = 0,      // [1]
    Emax = 0, EC50 = 1,      // unused by a line
    exposure_per_s = 1e-06);
  parameter Real slope = -2.5   "[mmHg ng-1 ml-1]";
equation
  response = E0 + slope*exposure;
  // family_inferred: the record's model family is effect_compartment; read from the parameters: a slope and no Emax — linear
  // defaulted: E0
  annotation(experiment(StartTime = 0, StopTime = 1000, Interval = 2),
    Documentation(info = "<html><body><!-- drug-about --><h4>About doxazosin</h4><p>Doxazosin is an alpha-blocker used to treat high blood pressure and urinary problems caused by an enlarged prostate. It is an approved medicine, used widely in general practice for these conditions.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q419939\">Wikidata Q419939</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h4>Doxazosin_Elliott1986_PD_hypotensive_effect</h4><p>The steady-state exposure-response curve of Elliott HL et al., <i>British journal of clinical pharmacology 21 Suppl 1(Suppl 1):27S–31S</i> 1986 (<a href=\"https://doi.org/10.1111/j.1365-2125.1986.tb02850.x\">doi:10.1111/j.1365-2125.1986.tb02850.x</a>) — hypotensive effect [mmHg] against doxazosin ng ml-1 — obtained by sweeping the driver instead of simulating a dose. Model family: linear.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = (library default) drug-free response (baseline)
  slope =       -2.5 mmHg ng-1 ml-1 change in response per unit of exposure (responsiveness, Q335)</pre><p>The algebra is <code>response = E0 + slope*exposure</code>; this model only supplies the numbers. The x axis is one ng ml-1 of doxazosin per second of simulated time (exposure is in kg/m3): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0   (drug-free)</pre></body></html>"));
end Doxazosin_Elliott1986_PD_hypotensive_effect;
