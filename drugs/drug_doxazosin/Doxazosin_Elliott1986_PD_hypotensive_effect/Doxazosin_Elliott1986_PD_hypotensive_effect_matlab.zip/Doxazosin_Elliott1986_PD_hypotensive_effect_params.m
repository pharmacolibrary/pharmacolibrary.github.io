function p = Doxazosin_Elliott1986_PD_hypotensive_effect_params()
% Doxazosin_Elliott1986_PD_hypotensive_effect_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% doxazosin Elliott_1986::hypotensive_effect: linear exposure-response sweep (response = E0 + slope*exposure). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one ng ml-1 per second, in SI inside (kg/m3, s). Response hypotensive effect in mmHg. Driver: doxazosin (cited_pk).
p.E0 = 0.0;
p.Emax = 0.0;
p.EC50 = 1.0;
p.gamma = 1.0;
p.slope = -2.5;
p.exposure_per_s = 1e-06;
p.stop_time = 1000.0;
p.form = 'E0 + slope*exposure';
end
