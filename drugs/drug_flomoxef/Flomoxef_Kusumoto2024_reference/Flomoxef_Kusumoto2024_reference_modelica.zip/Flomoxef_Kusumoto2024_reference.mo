model Flomoxef_Kusumoto2024_reference
  parameter Real Cl_ref = 8.250000000000001e-07 "Cl [m3/s]";
  parameter Real Vd_ref = 0.00327 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.49645999999999996,
    adminMass = 0.002
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About flomoxef</h4><p>Flomoxef is a second-generation cephalosporin antibiotic used to treat bacterial infections. It is not an approved medicine in major markets such as the European Union and is considered investigational, though it has seen clinical use in some Asian countries.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q5459999\">Wikidata Q5459999</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>flomoxef</td></tr><tr><td>population:</td><td>review reference</td></tr><tr><td>source_paper:</td><td>Kusumoto_2024</td></tr><tr><td>measured_compound:</td><td>flomoxef</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>flomoxef 496.46 g/mol (drugbank)</td></tr></table><h4>Interpretation flags</h4><ul><li>built from REVIEW reference values (Kusumoto_2024) — secondary source</li><li>volume reported by review</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Flomoxef_Kusumoto2024_reference;
