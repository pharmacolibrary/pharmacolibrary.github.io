function p = Spiramycin_Elazab2021_iv_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: spiramycin   source: Elazab_2021 / iv   route: iv_bolus
  % estimated (absent from source): F
  p.name  = 'Spiramycin_Elazab2021_iv_params';
  p.drug  = 'spiramycin';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'iv_bolus';        % 'oral' | 'iv_bolus'
  p.depot = false;             % oral -> first-order absorption depot
  p.Vc = 231.0;                % central volume [L]
  p.CL = 47.6;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.0;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 1190.0;             % dose [mg]
end
