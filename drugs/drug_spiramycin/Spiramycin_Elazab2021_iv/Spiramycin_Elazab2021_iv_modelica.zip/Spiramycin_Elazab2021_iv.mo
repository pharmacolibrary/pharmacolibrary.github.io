model Spiramycin_Elazab2021_iv
  parameter Real Cl_ref = 1.3222222222222223e-05 "Cl [m3/s]";
  parameter Real Vd_ref = 0.231 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.8430650000000001,
    adminMass = 0.00119
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About spiramycin</h4><p>Spiramycin is a macrolide antibiotic used to treat bacterial infections and has also been used as a coccidiostat. It remains an approved antibacterial for systemic use, available alone and in combination with other antibiotics, though it has been withdrawn in some markets.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q422265\">Wikidata Q422265</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>spiramycin</td></tr><tr><td>population:</td><td>chickens</td></tr><tr><td>source_paper:</td><td>Elazab_2021</td></tr><tr><td>measured_compound:</td><td>spiramycin</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>pathogens-10-01238-t001</td></tr><tr><td>input:</td><td>PK_1C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>spiramycin 843.065 g/mol (drugbank)</td></tr></table><h4>Interpretation flags</h4><ul><li>implicit units: 'λz (1/h)' → 1/h (from the popPK convention: 'The parameter is the elimination rate constant (λz). The paper text states the half-life is in hours (&quot;3.97 h&quot;) and clea')</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=spiramycin</li><li>population split: 'iv' subgroup of Elazab_2021 (paper reports 2 populations: iv, oral)</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary's parameterization (rate-constant / ka-only) does not use it</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Spiramycin_Elazab2021_iv;
