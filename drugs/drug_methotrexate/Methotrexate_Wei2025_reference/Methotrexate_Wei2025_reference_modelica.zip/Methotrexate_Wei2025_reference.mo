model Methotrexate_Wei2025_reference
  parameter Real Cl_ref = 2.361111111111111e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.03352 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C_enteral(
    weight = 70.0,
    F = 0.9,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.4544393,
    adminMass = 2.5e-06,
    ka = 3.101851851851852e-06,
    Tlag = 1296.0,
    k12 = 3.314770617873243e-07,
    k21 = 6.734006734006734e-06
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About methotrexate</h4><p>Methotrexate is a folic acid antagonist used as an anticancer drug for various cancers such as leukemia and lymphoma, and as an immunosuppressive disease-modifying antirheumatic drug for conditions like rheumatoid arthritis, psoriasis, and other inflammatory diseases. It is widely used and is included on the WHO essential medicines list; in the European Union several products are authorised for psoriasis and various forms of arthritis.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q422232\">Wikidata Q422232</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>methotrexate</td></tr><tr><td>population:</td><td>adult patients with primary central nervous system lymphoma</td></tr><tr><td>source_paper:</td><td>Wei_2025</td></tr><tr><td>measured_compound:</td><td>methotrexate</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>tab_3</td></tr><tr><td>input:</td><td>PK_2C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>methotrexate 454.439 g/mol (drugbank)</td></tr></table><p><b>Defaulted (base-class default used):</b> F.</p><h4>Interpretation flags</h4><ul><li>dropped duplicate Q30 ('Q 2 (L/h)', value '0.09') — already have one for this compound</li><li>dropped duplicate Q63 ('V P1 (L)', value '18.32') — already have one for this compound</li><li>dropped unlinked row (NIL): 'θ eGFR' — extend the ontology if this is a real PK parameter (source ['tab_3:row8:col1', 'tab_3:row8:col3', 'tab_3:row8:col5', 'tab_3:row8:col7'])</li><li>dropped unlinked row (NIL): 'Θ BUN' — extend the ontology if this is a real PK parameter (source ['tab_3:row9:col1', 'tab_3:row9:col3', 'tab_3:row9:col5', 'tab_3:row9:col7'])</li><li>dropped unlinked row (NIL): 'θ ALT' — extend the ontology if this is a real PK parameter (source ['tab_3:row10:col1', 'tab_3:row10:col3', 'tab_3:row10:col5', 'tab_3:row10:col7'])</li><li>dropped unlinked row (NIL): 'θ TP' — extend the ontology if this is a real PK parameter (source ['tab_3:row11:col1', 'tab_3:row11:col5', 'tab_3:row11:col7'])</li><li>dropped unlinked row (NIL): 'θ ABCC4-ABCG2-ADORA2A' — extend the ontology if this is a real PK parameter (source ['tab_3:row12:col7'])</li><li>unit_dimension_unknown: 'proportional' (prop_error)</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=methotrexate</li><li>held at status:extracted — NIL link or unit issue (mismatch/unknown/normalisation-failed) present</li><li>status held at route_to_review — not promoted</li><li>gap-filled Q64 (V2) from Rosario_2017's review values (primary lacked it)</li><li>gap-filled Q49 (kabs) from Pan_2026's review values (primary lacked it)</li><li>gap-filled Q83 (tlag) from Tan_2024's review values (primary lacked it)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 1036800, Tolerance = 1e-9, Interval = 1));
end Methotrexate_Wei2025_reference;
