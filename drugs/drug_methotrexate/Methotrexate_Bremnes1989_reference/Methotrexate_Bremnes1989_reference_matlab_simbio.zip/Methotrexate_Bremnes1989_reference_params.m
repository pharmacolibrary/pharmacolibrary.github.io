function p = Methotrexate_Bremnes1989_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: methotrexate   source: Bremnes_1989 / reference   route: oral
  % estimated (absent from source): F
  p.name  = 'Methotrexate_Bremnes1989_reference_params';
  p.drug  = 'methotrexate';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 350.0;                % central volume [L]
  p.CL = 7.63;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.011167;                % absorption rate [1/h]
  p.F  = 0.9;                 % bioavailability [0-1]
  p.Tlag = 0.36;             % absorption lag [h]
  p.dose = 2.5;             % dose [mg]
end
