function p = Methotrexate_Chen2025_PD_das28_params()
% Methotrexate_Chen2025_PD_das28_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% methotrexate Chen_2025::DAS28: sigmoid_emax exposure-response sweep (response = E0 + Emax*frac). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one week per second, in SI inside (kg/m3, s). Response DAS28 in %. Driver: methotrexate (dose_only).
p.E0 = 0.0;
p.Emax = -0.549;
p.EC50 = 12458880.0;
p.gamma = 1.0;
p.slope = 0.0;
p.exposure_per_s = 604800.0;
p.stop_time = 210.0;
p.form = 'E0 + Emax*frac';
end
