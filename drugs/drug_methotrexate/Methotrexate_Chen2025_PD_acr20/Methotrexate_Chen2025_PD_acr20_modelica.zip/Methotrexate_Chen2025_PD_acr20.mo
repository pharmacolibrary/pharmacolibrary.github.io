model Methotrexate_Chen2025_PD_acr20
  "sigmoid_emax exposure-response sweep — Chen_2025 :: ACR20 (ACR20 response)"
  extends Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep(
    E0 = 0,      // [1]
    Emax = 0.703,  // [1; % × 0.01]
    EC50 = 4046112,  // [s; week × 604800]
    gamma = 1,
    exposure_per_s = 604800);   // 1 week per second
  // defaulted: E0
  // defaulted: gamma
  annotation(experiment(StartTime = 0, StopTime = 67, Interval = 0.134),
    Documentation(info = "<html><body><h4>Methotrexate_Chen2025_PD_acr20</h4><p>The steady-state exposure-response curve of Chen S et al., <i>Journal of clinical pharmacology 65(10):1310–1321</i> 2025 (<a href=\"https://doi.org/10.1002/jcph.70039\">doi:10.1002/jcph.70039</a>) — ACR20 response [%] against methotrexate week — obtained by sweeping the driver instead of simulating a dose. Model family: sigmoid_emax.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = (library default) drug-free response (baseline)
  Emax  =       70.3 %        maximal effect term (Emax-ACR20, Q320)
  EC50  =       6.69 week     exposure at half of the maximal effect term (ET50-ACR20, Q321)
  gamma = (library default) Hill coefficient</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep\">SigmoidEmaxSweep</a>; this model only supplies the numbers. The x axis is one week of methotrexate per second of simulated time (exposure is in s): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0   (drug-free)
  exposure = EC50 (6.69 week)  response 0.3515
  exposure -> infinity  response 0.703</pre></body></html>"));
end Methotrexate_Chen2025_PD_acr20;
