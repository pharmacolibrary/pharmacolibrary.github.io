model Methotrexate_Yu2025_reference
  parameter Real Cl_ref = 1.175e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.01384 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C_enteral(
    weight = 70.0,
    F = 0.9,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.4544393,
    adminMass = 2.5e-06,
    ka = 3.101851851851852e-06,
    Tlag = 1296.0,
    k12 = 2.4887604367373153e-06,
    k21 = 7.043853669620541e-06
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About methotrexate</h4><p>Methotrexate is a folic acid antagonist used as an anticancer drug for various cancers such as leukemia and lymphoma, and as an immunosuppressive disease-modifying antirheumatic drug for conditions like rheumatoid arthritis, psoriasis, and other inflammatory diseases. It is widely used and is included on the WHO essential medicines list; in the European Union several products are authorised for psoriasis and various forms of arthritis.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q422232\">Wikidata Q422232</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>methotrexate</td></tr><tr><td>population:</td><td>pediatric patients with acute lymphoblastic leukemia</td></tr><tr><td>source_paper:</td><td>Yu_2025</td></tr><tr><td>measured_compound:</td><td>methotrexate</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>t0002</td></tr><tr><td>input:</td><td>PK_2C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>methotrexate 454.439 g/mol (drugbank)</td></tr></table><p><b>Defaulted (base-class default used):</b> F.</p><h4>Interpretation flags</h4><ul><li>dropped duplicate Q22 ('θCL age ≤1 (L/h)', value '0.65') — already have one for this compound</li><li>kept covariate coefficient θGFR=0.354 (covariate GFR) — not an ontology parameter</li><li>kept covariate coefficient θBSA=0.76 (covariate BSA) — not an ontology parameter</li><li>kept covariate coefficient θWT=0.35 (covariate WT) — not an ontology parameter</li><li>kept covariate coefficient θBUN=-0.1553 (covariate BUN) — not an ontology parameter</li><li>routed 'Interindividual variability ωCL (%)' → Q312 (IIV) to iiv — variability estimate, not a structural parameter</li><li>routed 'Interindividual variability ωQ (%)' → Q312 (IIV) to iiv — variability estimate, not a structural parameter</li><li>routed 'Interindividual variability ωV2 (%)' → Q312 (IIV) to iiv — variability estimate, not a structural parameter</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=methotrexate</li><li>gap-filled Q49 (kabs) from Pan_2026's review values (primary lacked it)</li><li>gap-filled Q83 (tlag) from Tan_2024's review values (primary lacked it)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 1036800, Tolerance = 1e-9, Interval = 1));
end Methotrexate_Yu2025_reference;
