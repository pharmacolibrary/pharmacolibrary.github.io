function p = Paliperidone_Kozielska2012_reference_params()
% Auto-generated parent-metabolite PK model (clinical units: mg, L, h).
%   drug: paliperidone   source: Kozielska_2012 / reference   PK_3M_3C parent + 1 metabolite(s), 5 compartments, oral
%   dA/dt = K*A; C = A./V. K(i,j) is the rate [1/h] at which compartment j feeds i:
%   a metabolic conversion carries MW_dst/MW_src, so one molecule forms one molecule.
%   molar masses: C_central=426.484 g/mol C_M1=426.484 g/mol
  p.name  = 'Paliperidone_Kozielska2012_reference_params';
  p.drug  = 'paliperidone';
  p.kind  = 'network';
  p.template = 'PK_3M_3C';
  p.states = {'hepatic', 'central', 'peripheral', 'central_M1', 'peripheral_M1'};
  p.V = [89.60000000000001, 89.60000000000001, 11.760000000000002, 84.7, 19.67];          % compartment volumes [L]
  p.K = [-1.5958705357142853, 1.0044642857142854, 0.0, 0.0, 0.0;
         1.0044642857142854, -1.0740736607142853, 0.5303571428571427, 0.0, 0.0;
         0.0, 0.069609375, -0.5303571428571427, 0.0, 0.0;
         0.5914062499999999, 0.0, 0.0, -1.06198347107438, 0.8718861209964411;
         0.0, 0.0, 0.0, 0.20247933884297517, -0.8718861209964411];
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;
  p.dose_into = 1;   % hepatic
  p.ka = 2.9;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.17;             % absorption lag [h] (in dose_start)
  p.dose = 0.7;             % dose [mg]
  p.dose_start = 0.18666666666666668;   % dose enters from [h] ...
  p.dose_duration = 0.16666666666666666;   % ... at a constant rate for [h]
  p.out_idx = [2.0, 4.0];
  p.out_names = {'C_central', 'C_M1'};
  p.out_labels = {'risperidone', 'paliperidone'};
end
