model Clofazimine_Abdelwahab2026_PD_qtcf
  "emax exposure-response sweep — Abdelwahab_2026 :: QTcF (QTcF)"
  extends Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep(
    E0 = 0,      // [1]
    Emax = 0.0445,  // [s; ms × 0.001]
    EC50 = 0.000903,  // [kg/m3; mg/L × 0.001]
    gamma = 1,
    exposure_per_s = 0.001);   // 1 mg/L per second
  // defaulted: E0
  // defaulted: gamma
  annotation(experiment(StartTime = 0, StopTime = 9.1, Interval = 0.0182),
    Documentation(info = "<html><body><!-- drug-about --><h4>About clofazimine</h4><p>Clofazimine is an antibacterial drug used to treat leprosy, and has also been used for other mycobacterial infections and inflammatory skin conditions such as pyoderma gangrenosum. It remains in use and is included on the WHO list of essential medicines, though it is not authorised in the European Union.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q418611\">Wikidata Q418611</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h4>Clofazimine_Abdelwahab2026_PD_qtcf</h4><p>The steady-state exposure-response curve of Abdelwahab MT et al., <i>Antimicrobial agents and chemotherapy 70(4):e0139925</i> 2026 (<a href=\"https://doi.org/10.1128/aac.01399-25\">doi:10.1128/aac.01399-25</a>) — QTcF [ms] against Clofazimine mg/L — obtained by sweeping the driver instead of simulating a dose. Model family: emax.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = (library default) drug-free response (baseline)
  Emax  =       44.5 ms       maximal effect term (Emax, Q320)
  EC50  =      0.903 mg/L     exposure at half of the maximal effect term (EC50 CFZ, Q321)
  gamma = (library default) Hill coefficient</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep\">SigmoidEmaxSweep</a>; this model only supplies the numbers. The x axis is one mg/L of Clofazimine per second of simulated time (exposure is in kg/m3): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0   (drug-free)
  exposure = EC50 (0.903 mg/L)  response 0.02225
  exposure -> infinity  response 0.0445</pre></body></html>"));
end Clofazimine_Abdelwahab2026_PD_qtcf;
