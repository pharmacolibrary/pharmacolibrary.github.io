function p = Clofazimine_Abdelwahab2026_PD_qtcf_params()
% Clofazimine_Abdelwahab2026_PD_qtcf_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% clofazimine Abdelwahab_2026::QTcF: emax exposure-response sweep (response = E0 + Emax*frac). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one mg/L per second, in SI inside (kg/m3, s). Response QTcF in ms. Driver: Clofazimine (cited_pk).
p.E0 = 0.0;
p.Emax = 0.0445;
p.EC50 = 0.0009029999999999998;
p.gamma = 1.0;
p.slope = 0.0;
p.exposure_per_s = 0.001;
p.stop_time = 9.1;
p.form = 'E0 + Emax*frac';
end
