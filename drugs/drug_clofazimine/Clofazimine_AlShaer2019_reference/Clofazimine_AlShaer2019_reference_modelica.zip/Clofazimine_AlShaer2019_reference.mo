model Clofazimine_AlShaer2019_reference
  parameter Real Cl_ref = 1.7277777777777778e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.0605 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.47339600000000004,
    adminMass = 0.0001,
    ka = 0.0008194444444444445,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About clofazimine</h4><p>Clofazimine is an antibacterial drug used to treat leprosy, and has also been used for other mycobacterial infections and inflammatory skin conditions such as pyoderma gangrenosum. It remains in use and is included on the WHO list of essential medicines, though it is not authorised in the European Union.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q418611\">Wikidata Q418611</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>clofazimine</td></tr><tr><td>population:</td><td>review reference</td></tr><tr><td>source_paper:</td><td>Al-Shaer_2019</td></tr><tr><td>measured_compound:</td><td>clofazimine</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>clofazimine 473.396 g/mol (drugbank)</td></tr></table><p><b>Defaulted (base-class default used):</b> Tlag.</p><h4>Interpretation flags</h4><ul><li>built from REVIEW reference values (Al-Shaer_2019) — secondary source</li><li>volume reported by review</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 126000, Tolerance = 1e-9, Interval = 1));
end Clofazimine_AlShaer2019_reference;
