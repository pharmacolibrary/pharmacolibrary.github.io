function p = Clofazimine_Zhang2022_PD_fecal_consistency_score_auc0_192_2_params()
% Clofazimine_Zhang2022_PD_fecal_consistency_score_auc0_192_2_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% clofazimine Zhang_2022::fecal_consistency_score_AUC0_192::2: linear exposure-response sweep (response = E0 + slope*exposure). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one ng/mL per second, in SI inside (kg/m3, s). Response fecal consistency score AUC0-192 in its own unit. Driver: clofazimine (cited_pk).
p.E0 = 0.0;
p.Emax = 0.0;
p.EC50 = 1.0;
p.gamma = 1.0;
p.slope = -0.00481;
p.exposure_per_s = 1e-06;
p.stop_time = 1000.0;
p.form = 'E0 + slope*exposure';
end
