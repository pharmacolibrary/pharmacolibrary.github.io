model TebipenemPivoxil_Ganesan2023_reference
  parameter Real Cl_ref = 1.3305555555555554e-07 "Cl [m3/s]";
  parameter Real Vd_ref = 0.0385 "Vd [m3]";
  parameter Real cov_weight = 1.0 "weight covariate (reference 1.0)";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref*(cov_weight/1.0)^(2.09),
    adminDuration = 600,
    adminCount = 1,
    MM = 0.383481,
    adminMass = 0.0006,
    ka = 0.00034166666666666666,
    Tlag = 0.0,
    k12 = 1.608946608946609e-05,
    k21 = 0.00012798438934802573
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About tebipenem_pivoxil</h4><p>Tebipenem pivoxil is an investigational carbapenem (beta-lactam) antibacterial being studied as a treatment for bacterial infections. It is not yet an approved medicine and remains in the investigational stage.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q1623593\">Wikidata Q1623593</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>tebipenem_pivoxil</td></tr><tr><td>population:</td><td>adults with cUTI/AP and healthy adults</td></tr><tr><td>source_paper:</td><td>Ganesan_2023</td></tr><tr><td>measured_compound:</td><td>tebipenem</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>T2</td></tr><tr><td>input:</td><td>PK_2C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>tebipenem 383.481 g/mol (pubchem); tebipenem_pivoxil 497.63 g/mol (drugbank)</td></tr></table><p><b>Defaulted (base-class default used):</b> Tlag.</p><h4>Interpretation flags</h4><ul><li>dropped value-less row: 'Parameter'</li><li>dropped unlinked row (NIL): 'CLR, MAX' — extend the ontology if this is a real PK parameter (source ['T2:row4:col1', 'T2:row4:col2', 'T2:row4:col4', 'T2:row4:col5', 'T2:row4:col6'])</li><li>dropped unlinked row (NIL): 'CLR, CLcr 50' — extend the ontology if this is a real PK parameter (source ['T2:row5:col1', 'T2:row5:col2', 'T2:row5:col4', 'T2:row5:col5', 'T2:row5:col6'])</li><li>dropped PD-category row 'CLR, Hill' → Q325 (Hill, category G11) — pharmacodynamic parameters belong to scholarpd, not the PK model (source ['T2:row6:col1', 'T2:row6:col2', 'T2:row6:col4', 'T2:row6:col5', 'T2:row6:col6'])</li><li>unit_dimension_unknown: 'slope' (CL/F)</li><li>dropped duplicate Q290 ('Vc/F:Infection status', value '-0.29') — already have one for this compound</li><li>dropped unlinked row (NIL): 'Vp/F:BSA (slope)' — extend the ontology if this is a real PK parameter (source ['T2:row13:col1', 'T2:row13:col2', 'T2:row13:col4', 'T2:row13:col5', 'T2:row13:col6'])</li><li>dropped unlinked row (NIL): 'Vp/F:Infection status' — extend the ontology if this is a real PK parameter (source ['T2:row14:col1', 'T2:row14:col2', 'T2:row14:col4', 'T2:row14:col5', 'T2:row14:col6'])</li><li>unit_dimension_unknown: 'fasted' (kabs)</li><li>unit_dimension_unknown: 'fed' (kabs)</li><li>dropped duplicate Q49 ('Ka (fed)', value '3.04') — already have one for this compound</li><li>dropped duplicate Q49 ('Ka:Dose effect', value '-0.478') — already have one for this compound</li><li>dropped unlinked row (NIL): 'Ka:Infection status' — extend the ontology if this is a real PK parameter (source ['T2:row18:col1', 'T2:row18:col2', 'T2:row18:col4', 'T2:row18:col5', 'T2:row18:col6'])</li><li>dropped unlinked row (NIL): 'RVprop, plasma' — extend the ontology if this is a real PK parameter (source ['T2:row26:col2', 'T2:row26:col3', 'T2:row26:col4', 'T2:row26:col5', 'T2:row26:col6'])</li><li>dropped unlinked row (NIL): 'RVprop, urine' — extend the ontology if this is a real PK parameter (source ['T2:row27:col2', 'T2:row27:col3', 'T2:row27:col4', 'T2:row27:col5', 'T2:row27:col6'])</li><li>dropped unlinked row (NIL): 'RVadd, urine' — extend the ontology if this is a real PK parameter (source ['T2:row28:col1', 'T2:row28:col2', 'T2:row28:col3', 'T2:row28:col4', 'T2:row28:col5', 'T2:row28:col6'])</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 1036800, Tolerance = 1e-9, Interval = 1));
end TebipenemPivoxil_Ganesan2023_reference;
