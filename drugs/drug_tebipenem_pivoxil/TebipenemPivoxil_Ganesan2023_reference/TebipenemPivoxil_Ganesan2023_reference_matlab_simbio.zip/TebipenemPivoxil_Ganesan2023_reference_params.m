function p = TebipenemPivoxil_Ganesan2023_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: tebipenem_pivoxil   source: Ganesan_2023 / reference   route: oral
  p.name  = 'TebipenemPivoxil_Ganesan2023_reference_params';
  p.drug  = 'tebipenem_pivoxil';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 38.5;                % central volume [L]
  p.CL = 0.479;                % clearance [L/h]
  p.Vp = [4.84];             % peripheral volumes [L]
  p.Q  = [2.23];             % inter-compartmental clearances [L/h]
  p.ka = 1.23;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 600.0;             % dose [mg]
end
