model Savolitinib_Jones2023_PD_pmet
  "emax exposure-response sweep — Jones_2023 :: pMET (pMET)"
  extends Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep(
    E0 = 17200,      // [—]
    Emax = -0.98,  // [—]
    EC50 = 1.3e-06,  // [mol/m3; nmol/L × 1e-06]
    gamma = 1,
    exposure_per_s = 1e-06);   // 1 nmol/L per second
  // imax_as_negative_emax: Imax (Q323) enters SigmoidEmaxSweep as −Emax
  // defaulted: gamma
  annotation(experiment(StartTime = 0, StopTime = 13, Interval = 0.026),
    Documentation(info = "<html><body><!-- drug-about --><h4>About savolitinib</h4><p>Savolitinib is an investigational anticancer drug, a c-MET kinase inhibitor being studied as a protein kinase inhibitor for treating cancer. It is not yet an approved medicine and has no marketing authorisation in the European Union; it remains under clinical investigation.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q27254463\">Wikidata Q27254463</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h4>Savolitinib_Jones2023_PD_pmet</h4><p>The steady-state exposure-response curve of Jones RDO et al., <i>Molecular cancer therapeutics 22(5):679–690</i> 2023 (<a href=\"https://doi.org/10.1158/1535-7163.MCT-22-0193\">doi:10.1158/1535-7163.MCT-22-0193</a>) — pMET against savolitinib nmol/L — obtained by sweeping the driver instead of simulating a dose. Model family: emax.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    =      17200 —        drug-free response (baseline) (pMET baseline, Q324)
  Emax  =      -0.98 —        maximal effect term (pMET Emax, Q323)
  EC50  =        1.3 nmol/L   exposure at half of the maximal effect term (pMET EC50, Q321)
  gamma = (library default) Hill coefficient</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep\">SigmoidEmaxSweep</a>; this model only supplies the numbers. The x axis is one nmol/L of savolitinib per second of simulated time (exposure is in mol/m3): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 1.72e+04   (drug-free)
  exposure = EC50 (1.3 nmol/L)  response 1.72e+04
  exposure -> infinity  response 1.72e+04</pre></body></html>"));
end Savolitinib_Jones2023_PD_pmet;
