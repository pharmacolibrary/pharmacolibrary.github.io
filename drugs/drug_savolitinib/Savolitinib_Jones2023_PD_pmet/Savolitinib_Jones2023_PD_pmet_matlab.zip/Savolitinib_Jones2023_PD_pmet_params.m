function p = Savolitinib_Jones2023_PD_pmet_params()
% Savolitinib_Jones2023_PD_pmet_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% savolitinib Jones_2023::pMET: emax exposure-response sweep (response = E0 + Emax*frac). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one nmol/L per second, in SI inside (kg/m3, s). Response pMET in its own unit. Driver: savolitinib (pk_record).
p.E0 = 17200.0;
p.Emax = -0.98;
p.EC50 = 1.3e-06;
p.gamma = 1.0;
p.slope = 0.0;
p.exposure_per_s = 1e-06;
p.stop_time = 13.0;
p.form = 'E0 + Emax*frac';
end
