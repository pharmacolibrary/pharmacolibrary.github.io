model Savolitinib_Jones2023_PD_pegfr
  "indirect_response_iv exposure-response sweep — Jones_2023 :: pEGFR (pEGFR)"
  extends Pharmacolibrary.Pharmacodynamic.IndirectTurnoverSweep(
    E0 = 24300,      // [—]
    Emax = 9.06,  // type IV effect term
    EC50 = 0.00017,  // [mol/m3; μmol/L × 0.001]
    gamma = 1,
    exposure_per_s = 0.001);   // 1 μmol/L per second
  // defaulted: gamma
  annotation(experiment(StartTime = 0, StopTime = 0.26, Interval = 0.00052),
    Documentation(info = "<html><body><!-- drug-about --><h4>About savolitinib</h4><p>Savolitinib is an investigational anticancer drug, a c-MET kinase inhibitor being studied as a protein kinase inhibitor for treating cancer. It is not yet an approved medicine and has no marketing authorisation in the European Union; it remains under clinical investigation.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q27254463\">Wikidata Q27254463</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h4>Savolitinib_Jones2023_PD_pegfr</h4><p>The steady-state exposure-response curve of Jones RDO et al., <i>Molecular cancer therapeutics 22(5):679–690</i> 2023 (<a href=\"https://doi.org/10.1158/1535-7163.MCT-22-0193\">doi:10.1158/1535-7163.MCT-22-0193</a>) — pEGFR against savolitinib μmol/L — obtained by sweeping the driver instead of simulating a dose. Model family: indirect_response_iv.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    =      24300 —        drug-free response (baseline) (pEGFR baseline, Q324)
  Emax  =       9.06          maximal effect term (pEGFR Emax (proportional increase Kout), Q320)
  EC50  =       0.17 μmol/L   exposure at half of the maximal effect term (pEGFR EC50base, Q321)
  gamma = (library default) Hill coefficient</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.IndirectTurnoverSweep\">IndirectTurnoverSweep</a>; this model only supplies the numbers. The x axis is one μmol/L of savolitinib per second of simulated time (exposure is in mol/m3): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><p>The effect term enters as a reciprocal (steady state of <code>der(R) = Kin - Kout*(1 + Emax*frac)*R</code>), so EC50 is the exposure at half the maximal STIMULATION of turnover, not at half the response.</p><h4>What it reproduces</h4><pre>  exposure = 0         response 2.43e+04   (drug-free)
  exposure = EC50 (0.17 μmol/L)  response 4394
  exposure -> infinity  response 2416</pre></body></html>"));
end Savolitinib_Jones2023_PD_pegfr;
