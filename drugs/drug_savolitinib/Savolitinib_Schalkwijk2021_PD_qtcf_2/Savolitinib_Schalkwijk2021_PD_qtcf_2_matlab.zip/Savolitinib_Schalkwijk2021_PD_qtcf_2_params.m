function p = Savolitinib_Schalkwijk2021_PD_qtcf_2_params()
% Savolitinib_Schalkwijk2021_PD_qtcf_2_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% savolitinib Schalkwijk_2021::QTcF::2: emax exposure-response sweep (response = E0 + Emax*frac). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one nM per second, in SI inside (kg/m3, s). Response ΔΔQTcF in ms. Driver: savolitinib and M2 (active moiety) (conc_no_pk).
p.E0 = 0.0;
p.Emax = 0.0185;
p.EC50 = 5709.0;
p.gamma = 1.0;
p.slope = 0.0;
p.exposure_per_s = 1.0;
p.stop_time = 58000.0;
p.form = 'E0 + Emax*frac';
end
