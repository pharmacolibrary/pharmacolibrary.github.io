model Savolitinib_Schalkwijk2021_PD_qtcf_2
  "emax exposure-response sweep — Schalkwijk_2021 :: ΔΔQTcF (ΔΔQTcF)"
  extends Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep(
    E0 = 0,      // [1]
    Emax = 0.0185,  // [s; ms × 0.001]
    EC50 = 5709,  // [nM]
    gamma = 1,
    exposure_per_s = 1);   // 1 nM per second
  // exposure_unit_unresolved: 'nM' — the x axis is in the paper's unit, not SI
  // defaulted: E0
  // defaulted: gamma
  annotation(experiment(StartTime = 0, StopTime = 58000, Interval = 116),
    Documentation(info = "<html><body><!-- drug-about --><h4>About savolitinib</h4><p>Savolitinib is an investigational anticancer drug, a c-MET kinase inhibitor being studied as a protein kinase inhibitor for treating cancer. It is not yet an approved medicine and has no marketing authorisation in the European Union; it remains under clinical investigation.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q27254463\">Wikidata Q27254463</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h4>Savolitinib_Schalkwijk2021_PD_qtcf_2</h4><p>The steady-state exposure-response curve of Schalkwijk S et al., <i>The AAPS journal 23(3):46</i> 2021 (<a href=\"https://doi.org/10.1208/s12248-021-00573-1\">doi:10.1208/s12248-021-00573-1</a>) — ΔΔQTcF [ms] against savolitinib and M2 (active moiety) nM — obtained by sweeping the driver instead of simulating a dose. Model family: emax.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = (library default) drug-free response (baseline)
  Emax  =       18.5 ms       maximal effect term (maximal increase in ΔΔQTcF, Q320)
  EC50  =       5709 nM       exposure at half of the maximal effect term (EC50, Q321)
  gamma = (library default) Hill coefficient</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep\">SigmoidEmaxSweep</a>; this model only supplies the numbers. The x axis is one nM of savolitinib and M2 (active moiety) per second of simulated time: there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0   (drug-free)
  exposure = EC50 (5709 nM)  response 0.00925
  exposure -> infinity  response 0.0185</pre></body></html>"));
end Savolitinib_Schalkwijk2021_PD_qtcf_2;
