model Savolitinib_Jones2023_PD_tgi
  "linear exposure-response sweep — Jones_2023 :: TGI (tumor growth)"
  extends Pharmacolibrary.Interfaces.PartialExposureResponseSweep(
    E0 = 90.2,      // [mm3]
    Emax = 0, EC50 = 1,      // unused by a line
    exposure_per_s = 1);
  parameter Real slope = 0.0837   "[—]";
equation
  response = E0 + slope*exposure;
  // family_inferred: the record's model family is disease_progression; read from the parameters: a slope and no Emax — linear
  annotation(experiment(StartTime = 0, StopTime = 1000, Interval = 2),
    Documentation(info = "<html><body><!-- drug-about --><h4>About savolitinib</h4><p>Savolitinib is an investigational anticancer drug, a c-MET kinase inhibitor being studied as a protein kinase inhibitor for treating cancer. It is not yet an approved medicine and has no marketing authorisation in the European Union; it remains under clinical investigation.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q27254463\">Wikidata Q27254463</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h4>Savolitinib_Jones2023_PD_tgi</h4><p>The steady-state exposure-response curve of Jones RDO et al., <i>Molecular cancer therapeutics 22(5):679–690</i> 2023 (<a href=\"https://doi.org/10.1158/1535-7163.MCT-22-0193\">doi:10.1158/1535-7163.MCT-22-0193</a>) — tumor growth [mm3] against savolitinib and osimertinib — obtained by sweeping the driver instead of simulating a dose. Model family: linear.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    =       90.2 mm3      drug-free response (baseline) (Baseline tumor size, Q324)
  slope =     0.0837 —        change in response per unit of exposure (pEGFR effect on tumor growth (slope), Q335)</pre><p>The algebra is <code>response = E0 + slope*exposure</code>; this model only supplies the numbers. The x axis is one  of savolitinib and osimertinib per second of simulated time: there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 90.2   (drug-free)</pre></body></html>"));
end Savolitinib_Jones2023_PD_tgi;
