model PotassiumSalicylate_Kotschwar2009_period_2
  parameter Real Cl_ref = 5.016666666666666e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.014 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 0.9,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.17621199999999998,
    adminMass = 0.0035,
    ka = 6.111111111111111e-05,
    Tlag = 10116.0
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About potassium_salicylate</h4><p>Potassium salicylate is a salicylic acid derivative classified as an analgesic and antipyretic for the nervous system. Its current availability and extent of use are unclear, as no regulatory or marketing information is provided.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q7234718\">Wikidata Q7234718</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>potassium_salicylate</td></tr><tr><td>population:</td><td>bovine calves</td></tr><tr><td>source_paper:</td><td>Kotschwar_2009</td></tr><tr><td>measured_compound:</td><td>salicylate</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>tab_1</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>potassium_salicylate 176.212 g/mol (pubchem); salicylate 176.212 g/mol (pubchem)</td></tr></table><p><b>Defaulted (base-class default used):</b> F.</p><h4>Interpretation flags</h4><ul><li>dropped unlinked row (NIL): 'Cortisol (nmol/L)' — extend the ontology if this is a real PK parameter (source ['tab_1:row3:col3', 'tab_1:row3:col5', 'tab_1:row3:col6', 'tab_1:row3:col7'])</li><li>dropped unlinked row (NIL): 'Heart rate (bpm)' — extend the ontology if this is a real PK parameter (source ['tab_1:row8:col3', 'tab_1:row8:col5', 'tab_1:row8:col6', 'tab_1:row8:col7'])</li><li>dropped unlinked row (NIL): 'Electrodermal activity' — extend the ontology if this is a real PK parameter (source ['tab_1:row10:col3', 'tab_1:row10:col5', 'tab_1:row10:col6', 'tab_1:row10:col7'])</li><li>salvaged Q61 ('V d'=0.2) from results prose — parameter table was unreadable</li><li>salvaged Q23 ('CL B'=4.3) from results prose — parameter table was unreadable</li><li>implicit units: 'CL B' → mL/min/kg (from the paper text: &quot;The text explicitly states: 'CL B was 4.3 ± 0.2 mL/min•kg'.&quot;)</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=salicylate</li><li>held at status:extracted — NIL link or unit issue (mismatch/unknown/normalisation-failed) present</li><li>status held at route_to_review — not promoted</li><li>population split: 'period 2' subgroup of Kotschwar_2009 (paper reports 4 populations: mean ± se, period 1, period 2, period 3)</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li><li>gap-filled Q49 (kabs) from Koh_2025's review values (primary lacked it)</li><li>gap-filled Q83 (tlag) from Koh_2025's review values (primary lacked it)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end PotassiumSalicylate_Kotschwar2009_period_2;
