model PotassiumSalicylate_Buntenktter2017_reference
  parameter Real Cl_ref = 1.5983333333333334e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.04233646305290299 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.17621199999999998,
    adminMass = 0.007,
    ka = 0.0001388888888888889,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About potassium_salicylate</h4><p>Potassium salicylate is a salicylic acid derivative classified as an analgesic and antipyretic for the nervous system. Its current availability and extent of use are unclear, as no regulatory or marketing information is provided.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q7234718\">Wikidata Q7234718</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>potassium_salicylate</td></tr><tr><td>population:</td><td>review reference</td></tr><tr><td>source_paper:</td><td>Buntenkötter_2017</td></tr><tr><td>measured_compound:</td><td>potassium_salicylate</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C_enteral: apparent (/F) parameterization ⇒ extravascular dosing</td></tr><tr><td>molar_masses:</td><td>potassium_salicylate 176.212 g/mol (pubchem)</td></tr></table><p><b>Defaulted (base-class default used):</b> ka, Tlag.</p><h4>Interpretation flags</h4><ul><li>built from REVIEW reference values (Buntenkötter_2017) — secondary source</li><li>central volume derived from CL·t½/ln2</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 93600, Tolerance = 1e-9, Interval = 1));
end PotassiumSalicylate_Buntenktter2017_reference;
