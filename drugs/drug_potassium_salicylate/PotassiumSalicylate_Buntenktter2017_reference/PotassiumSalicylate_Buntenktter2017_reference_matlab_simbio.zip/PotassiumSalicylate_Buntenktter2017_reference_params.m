function p = PotassiumSalicylate_Buntenktter2017_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: potassium_salicylate   source: Buntenkötter_2017 / reference   route: oral
  % estimated (absent from source): ka
  p.name  = 'PotassiumSalicylate_Buntenktter2017_reference_params';
  p.drug  = 'potassium_salicylate';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 42.336463;                % central volume [L]
  p.CL = 5.754;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.5;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 7000.0;             % dose [mg]
end
