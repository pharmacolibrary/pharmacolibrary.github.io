model Omeprazole_McCann2023_reference
  parameter Real Cl_ref = 1.8055555555555557e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.226 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 0.9,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.345416,
    adminMass = 2e-05,
    ka = 9.027777777777779e-05,
    Tlag = 9000.0
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About omeprazole</h4><p>Omeprazole is a proton-pump inhibitor used for acid-related stomach problems such as reflux disease, ulcers, gastritis, and Zollinger–Ellison syndrome. It is widely used, appears on the WHO essential medicines list, and is approved for both human and veterinary use.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q422210\">Wikidata Q422210</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>omeprazole</td></tr><tr><td>population:</td><td>review reference</td></tr><tr><td>source_paper:</td><td>McCann_2023</td></tr><tr><td>measured_compound:</td><td>omeprazole</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>omeprazole 345.416 g/mol (drugbank)</td></tr></table><p><b>Defaulted (base-class default used):</b> F.</p><h4>Interpretation flags</h4><ul><li>built from REVIEW reference values (McCann_2023) — secondary source</li><li>volume reported by review</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 518400, Tolerance = 1e-9, Interval = 1));
end Omeprazole_McCann2023_reference;
