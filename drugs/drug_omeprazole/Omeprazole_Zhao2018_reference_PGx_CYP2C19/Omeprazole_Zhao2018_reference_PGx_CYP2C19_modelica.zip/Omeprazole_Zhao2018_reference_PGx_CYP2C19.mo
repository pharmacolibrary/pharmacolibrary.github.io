model Omeprazole_Zhao2018_reference_PGx_CYP2C19
  "Omeprazole_Zhao2018_reference with the CYP2C19 phenotype as a parameter (Zhao_2018)"
  import PGx = Pharmacolibrary.Pharmacogenomics.PGx;
  parameter PGx.MetabolizerStatus metabolizer = PGx.MetabolizerStatus.Normal
    "CYP2C19 phenotype — the reference is the record's own model"
    annotation(Dialog(group = "Pharmacogenomics"), Evaluate = false);
  parameter Real q1_m11_by_phenotype[6] = {1.82777777778e-07, 1.82777777778e-07, 1.82777777778e-07, 1.82777777778e-07, 1.82777777778e-07, 4.96841511979e-07};
  extends Omeprazole_Zhao2018_reference(q1_m11 = q1_m11_by_phenotype[Integer(metabolizer)]);
  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About omeprazole</h4><p>Omeprazole is a proton-pump inhibitor used for acid-related stomach problems such as reflux disease, ulcers, gastritis, and Zollinger–Ellison syndrome. It is widely used, appears on the WHO essential medicines list, and is approved for both human and veterinary use.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q422210\">Wikidata Q422210</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --></body></html>"));
end Omeprazole_Zhao2018_reference_PGx_CYP2C19;
