// parent + metabolites (5-hydroxy-omeprazole, omeprazole sulfone): PK_3M_9C — formed from central; parent 1, metabolites [1, 1]
model Omeprazole_Zhao2018_reference
  parameter Real Q370_5_hydroxy_omeprazole_ref = 1.827777777777778e-07 "θ2 [SI]";
  parameter Real cov_cyp2c19_0 = 0 "cyp2c19 covariate";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_3M_9C(
    Vd1 = 0.000513,
    q1_m11 = Q370_5_hydroxy_omeprazole_ref*(1 + (1.0)*cov_cyp2c19_0),
    q1_m21 = 3.888888888888889e-08,
    CL1 = max(((Q370_5_hydroxy_omeprazole_ref*(1 + (1.0)*cov_cyp2c19_0)) + 3.888888888888889e-08) - ((Q370_5_hydroxy_omeprazole_ref*(1 + (1.0)*cov_cyp2c19_0)) + 3.888888888888889e-08), 0),
    Vd1m1 = 0.001,
    CLm1 = 2.35e-07,
    Vd1m2 = 0.001,
    CLm2 = 3.611111111111111e-08,
    MW = 0.345416,
    MW_m1 = 0.361416,
    MW_m2 = 0.361416,
    F = 1,
    ka = 0.00026388888888888886,
    Tlag = 9000.0,
    adminDuration = 600,
    adminCount = 1,
    adminMass = 7e-05
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About omeprazole</h4><p>Omeprazole is a proton-pump inhibitor used for acid-related stomach problems such as reflux disease, ulcers, gastritis, and Zollinger–Ellison syndrome. It is widely used, appears on the WHO essential medicines list, and is approved for both human and veterinary use.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q422210\">Wikidata Q422210</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>omeprazole</td></tr><tr><td>population:</td><td>neonates and young infants</td></tr><tr><td>source_paper:</td><td>Zhao_2018</td></tr><tr><td>measured_compound:</td><td>omeprazole</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>general_linear</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>tab_1</td></tr><tr><td>input:</td><td>PK_3M_9C: absorption rate constant reported; parent clearance = Σ formation clearances (no other elimination route); formation of 5-hydroxy-omeprazole: CLfm; formation of omeprazole sulfone: CLfm; dose 70 mg (paper); covariate effects applied (1): f_cyp2c19_em_um — typical subject by default</td></tr><tr><td>molar_masses:</td><td>5-hydroxy-omeprazole 361.416 g/mol (pubchem); omeprazole 345.416 g/mol (drugbank); omeprazole sulfone 361.416 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>table section iiv: 'Ka' routed out of structural estimates ('Interindividual variability (%)')</li><li>table section iiv: 'Ka' routed out of structural estimates ('Interindividual variability (%)')</li><li>table section iiv: 'Ka' routed out of structural estimates ('Interindividual variability (%)')</li><li>table section iiv: 'Ka' routed out of structural estimates ('Interindividual variability (%)')</li><li>table section iiv: 'V 1 /F' routed out of structural estimates ('Interindividual variability (%)')</li><li>table section iiv: 'V 1 /F' routed out of structural estimates ('Interindividual variability (%)')</li><li>table section iiv: 'V 1 /F' routed out of structural estimates ('Interindividual variability (%)')</li><li>table section iiv: 'V 1 /F' routed out of structural estimates ('Interindividual variability (%)')</li><li>table section iiv: 'CL OMZ-M1' routed out of structural estimates ('Interindividual variability (%)')</li><li>table section iiv: 'CL OMZ-M1' routed out of structural estimates ('Interindividual variability (%)')</li><li>table section iiv: 'CL OMZ-M1' routed out of structural estimates ('Interindividual variability (%)')</li><li>table section iiv: 'CL OMZ-M1' routed out of structural estimates ('Interindividual variability (%)')</li><li>table section iiv: 'CL OMZ-M2' routed out of structural estimates ('Interindividual variability (%)')</li><li>table section iiv: 'CL OMZ-M2' routed out of structural estimates ('Interindividual variability (%)')</li><li>table section iiv: 'CL OMZ-M2' routed out of structural estimates ('Interindividual variability (%)')</li><li>table section iiv: 'CL OMZ-M2' routed out of structural estimates ('Interindividual variability (%)')</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Omeprazole_Zhao2018_reference;
