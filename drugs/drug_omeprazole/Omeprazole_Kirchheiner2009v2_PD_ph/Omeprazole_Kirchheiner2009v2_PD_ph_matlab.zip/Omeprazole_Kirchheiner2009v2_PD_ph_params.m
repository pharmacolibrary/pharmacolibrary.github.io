function p = Omeprazole_Kirchheiner2009v2_PD_ph_params()
% Omeprazole_Kirchheiner2009v2_PD_ph_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% omeprazole Kirchheiner_2009_2::pH: emax exposure-response sweep (response = E0 + Emax*frac). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one mg/day per second, in SI inside (kg/m3, s). Response pH in its own unit. Driver: omeprazole (dose_only).
p.E0 = 3.06;
p.Emax = 1.2455999999999999e-08;
p.EC50 = 6.273148148148149e-10;
p.gamma = 1.0;
p.slope = 0.0;
p.exposure_per_s = 1.15740740741e-11;
p.stop_time = 550.0;
p.form = 'E0 + Emax*frac';
end
