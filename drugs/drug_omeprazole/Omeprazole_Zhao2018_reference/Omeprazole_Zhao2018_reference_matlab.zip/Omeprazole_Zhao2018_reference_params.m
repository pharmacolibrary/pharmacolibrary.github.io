function p = Omeprazole_Zhao2018_reference_params()
% Auto-generated parent-metabolite PK model (clinical units: mg, L, h).
%   drug: omeprazole   source: Zhao_2018 / reference   PK_3M_9C parent + 2 metabolite(s), 3 compartments, oral
%   dA/dt = K*A; C = A./V. K(i,j) is the rate [1/h] at which compartment j feeds i:
%   a metabolic conversion carries MW_dst/MW_src, so one molecule forms one molecule.
%   molar masses: C_central=345.416 g/mol C_M1=361.416 g/mol C_M2=361.416 g/mol
  p.name  = 'Omeprazole_Zhao2018_reference_params';
  p.drug  = 'omeprazole';
  p.kind  = 'network';
  p.template = 'PK_3M_9C';
  p.states = {'central', 'central_M1', 'central_M2'};
  p.V = [0.513, 1.0, 1.0];          % compartment volumes [L]
  p.K = [-1.5555555555555556, 0.0, 0.0;
         1.3420646984593678, -0.846, 0.0;
         0.2855456805232698, 0.0, -0.13];
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;
  p.dose_into = 1;   % central
  p.ka = 0.95;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 2.5;             % absorption lag [h] (in dose_start)
  p.dose = 70.0;             % dose [mg]
  p.dose_start = 2.5166666666666666;   % dose enters from [h] ...
  p.dose_duration = 0.16666666666666666;   % ... at a constant rate for [h]
  p.out_idx = [1.0, 2.0, 3.0];
  p.out_names = {'C_central', 'C_M1', 'C_M2'};
  p.out_labels = {'omeprazole', '5-hydroxy-omeprazole', 'omeprazole sulfone'};
end
