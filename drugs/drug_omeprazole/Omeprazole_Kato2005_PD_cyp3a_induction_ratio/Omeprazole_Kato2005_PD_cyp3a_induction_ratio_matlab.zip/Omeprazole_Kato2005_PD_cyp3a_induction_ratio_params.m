function p = Omeprazole_Kato2005_PD_cyp3a_induction_ratio_params()
% Omeprazole_Kato2005_PD_cyp3a_induction_ratio_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% omeprazole Kato_2005::CYP3A_induction_ratio: emax exposure-response sweep (response = E0 + Emax*frac). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one micromol/L per second, in SI inside (kg/m3, s). Response CYP3A induction ratio in its own unit. Driver: omeprazole (cited_pk).
p.E0 = 0.0;
p.Emax = 2.36;
p.EC50 = 0.00022499999999999997;
p.gamma = 1.0;
p.slope = 0.0;
p.exposure_per_s = 0.001;
p.stop_time = 2.3;
p.form = 'E0 + Emax*frac';
end
