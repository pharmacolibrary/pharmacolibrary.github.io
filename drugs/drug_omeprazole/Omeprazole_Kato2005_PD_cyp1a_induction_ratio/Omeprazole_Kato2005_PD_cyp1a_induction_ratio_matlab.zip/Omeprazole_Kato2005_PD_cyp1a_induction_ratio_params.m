function p = Omeprazole_Kato2005_PD_cyp1a_induction_ratio_params()
% Omeprazole_Kato2005_PD_cyp1a_induction_ratio_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% omeprazole Kato_2005::CYP1A_induction_ratio: emax exposure-response sweep (response = E0 + Emax*frac). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one micromol/L per second, in SI inside (kg/m3, s). Response CYP1A induction ratio in its own unit. Driver: omeprazole (cited_pk).
p.E0 = 0.0;
p.Emax = 12.02;
p.EC50 = 7.499999999999998e-05;
p.gamma = 1.0;
p.slope = 0.0;
p.exposure_per_s = 0.001;
p.stop_time = 0.75;
p.form = 'E0 + Emax*frac';
end
