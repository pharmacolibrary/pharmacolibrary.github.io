model Omeprazole_Kato2005_PD_cyp1a_induction_ratio
  "emax exposure-response sweep — Kato_2005 :: CYP1A induction ratio (CYP1A enzyme induction ratio)"
  extends Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep(
    E0 = 0,      // [1]
    Emax = 12.02,  // [1]
    EC50 = 7.5e-05,  // [mol/m3; micromol/L × 0.001]
    gamma = 1,
    exposure_per_s = 0.001);   // 1 micromol/L per second
  // defaulted: E0
  // defaulted: gamma
  annotation(experiment(StartTime = 0, StopTime = 0.75, Interval = 0.0015),
    Documentation(info = "<html><body><!-- drug-about --><h4>About omeprazole</h4><p>Omeprazole is a proton-pump inhibitor used for acid-related stomach problems such as reflux disease, ulcers, gastritis, and Zollinger–Ellison syndrome. It is widely used, appears on the WHO essential medicines list, and is approved for both human and veterinary use.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q422210\">Wikidata Q422210</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h4>Omeprazole_Kato2005_PD_cyp1a_induction_ratio</h4><p>The steady-state exposure-response curve of Kato M et al., <i>Drug metabolism and pharmacokinetics 20(4):236–243</i> 2005 (<a href=\"https://doi.org/10.2133/dmpk.20.236\">doi:10.2133/dmpk.20.236</a>) — CYP1A enzyme induction ratio against omeprazole micromol/L — obtained by sweeping the driver instead of simulating a dose. Model family: emax.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = (library default) drug-free response (baseline)
  Emax  =      12.02          maximal effect term (Emax, Q320)
  EC50  =      0.075 micromol/L exposure at half of the maximal effect term (EC50, Q321)
  gamma = (library default) Hill coefficient</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep\">SigmoidEmaxSweep</a>; this model only supplies the numbers. The x axis is one micromol/L of omeprazole per second of simulated time (exposure is in mol/m3): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0   (drug-free)
  exposure = EC50 (0.075 micromol/L)  response 6.01
  exposure -> infinity  response 12.02</pre></body></html>"));
end Omeprazole_Kato2005_PD_cyp1a_induction_ratio;
