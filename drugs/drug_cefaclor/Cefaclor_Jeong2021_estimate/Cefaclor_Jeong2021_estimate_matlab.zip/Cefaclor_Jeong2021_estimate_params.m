function p = Cefaclor_Jeong2021_estimate_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: cefaclor   source: Jeong_2021 / estimate   route: oral
  p.name  = 'Cefaclor_Jeong2021_estimate_params';
  p.drug  = 'cefaclor';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 22.59326;                % central volume [L]
  p.CL = 27.166883;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 5.203;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.245;             % absorption lag [h]
  p.dose = 250.0;             % dose [mg]
end
