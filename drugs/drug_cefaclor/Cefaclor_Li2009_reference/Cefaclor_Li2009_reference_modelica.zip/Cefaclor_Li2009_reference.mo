model Cefaclor_Li2009_reference
  parameter Real Cl_ref = 5.783333333333333e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.0289 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.367807,
    adminMass = 0.001,
    ka = 0.0001388888888888889,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About cefaclor</h4><p>Cefaclor is a second-generation cephalosporin antibiotic used to treat bacterial infections such as tonsillitis, otitis media, urinary tract infections, bronchitis, and pneumonia. It is an approved antibiotic that remains in general clinical use for these common infections.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q415167\">Wikidata Q415167</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>cefaclor</td></tr><tr><td>population:</td><td>review reference</td></tr><tr><td>source_paper:</td><td>Li_2009</td></tr><tr><td>measured_compound:</td><td>cefaclor</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C_enteral: apparent (/F) parameterization ⇒ extravascular dosing</td></tr><tr><td>molar_masses:</td><td>cefaclor 367.807 g/mol (drugbank)</td></tr></table><p><b>Defaulted (base-class default used):</b> ka, Tlag.</p><h4>Interpretation flags</h4><ul><li>built from REVIEW reference values (Li_2009) — secondary source</li><li>volume reported by review</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Cefaclor_Li2009_reference;
