model Zanamivir_Zuo2020_final
  parameter Real Cl_ref = 1.8944444444444446e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.0123 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.3323098,
    adminMass = 0.0001,
    k12 = 0.00010885275519421862,
    k21 = 0.00020535105657805048
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About zanamivir</h4><p>Zanamivir is an antiviral medicine used to treat and prevent influenza. It is authorised in the European Union for human influenza and remains an approved drug.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q146075\">Wikidata Q146075</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>zanamivir</td></tr><tr><td>population:</td><td>healthy adults and hospitalized adult and pediatric subjects with influenza</td></tr><tr><td>source_paper:</td><td>Zuo_2020</td></tr><tr><td>measured_compound:</td><td>zanamivir</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>cts12697-tbl-0002</td></tr><tr><td>input:</td><td>PK_2C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>zanamivir 332.31 g/mol (drugbank)</td></tr></table><h4>Interpretation flags</h4><ul><li>table section iiv: 'IIVCL, CV% (% η‐shrinkage)' routed out of structural estimates ('IIV')</li><li>table section iiv: 'IIVV1, CV% (% η‐shrinkage)' routed out of structural estimates ('IIV')</li><li>table section residual_error: 'Proportional error, CV% (% RSE)' routed out of structural estimates ('Residual variability')</li><li>table section residual_error: 'Additive error (μg/mL), SD (% RSE)' routed out of structural estimates ('Residual variability')</li><li>dropped duplicate Q22 ('CL ~ FLU', value '0.756') — already have one for this compound</li><li>dropped unlinked row (NIL): 'V1/V2 ~ Study (NAI114346)' — extend the ontology if this is a real PK parameter (source ['cts12697-tbl-0002:row13:col4'])</li><li>covariate effect for Q900 has no base parameter row (kept as unattached equation-variable)</li><li>covariate effect for Q335 has no base parameter row (kept as unattached equation-variable)</li><li>covariate effect for Q319 has no base parameter row (kept as unattached equation-variable)</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=zanamivir</li><li>model-stage split: 'final model' is the final model of Zuo_2020 (paper reports 3 stages: base model, final model, full model); same population, different model-building step</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Zanamivir_Zuo2020_final;
