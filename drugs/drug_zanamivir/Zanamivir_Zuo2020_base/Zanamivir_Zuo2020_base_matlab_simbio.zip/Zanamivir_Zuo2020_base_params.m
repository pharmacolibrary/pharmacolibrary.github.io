function p = Zanamivir_Zuo2020_base_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: zanamivir   source: Zuo_2020 / base   route: iv_bolus
  % estimated (absent from source): F
  p.name  = 'Zanamivir_Zuo2020_base_params';
  p.drug  = 'zanamivir';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'iv_bolus';        % 'oral' | 'iv_bolus'
  p.depot = false;             % oral -> first-order absorption depot
  p.Vc = 12.9;                % central volume [L]
  p.CL = 4.12;                % clearance [L/h]
  p.Vp = [4.32];             % peripheral volumes [L]
  p.Q  = [2.59];             % inter-compartmental clearances [L/h]
  p.ka = 0.0;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 100.0;             % dose [mg]
end
