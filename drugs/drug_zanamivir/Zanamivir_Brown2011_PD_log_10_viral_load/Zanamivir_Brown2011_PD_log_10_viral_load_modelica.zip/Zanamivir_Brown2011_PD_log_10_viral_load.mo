model Zanamivir_Brown2011_PD_log_10_viral_load
  "indirect_response_i exposure-response sweep — Brown_2011 :: log(10) viral load (log(10) viral load)"
  extends Pharmacolibrary.Interfaces.PartialExposureResponseSweep(
    E0 = 0,      // [1]
    Emax = 0.99,  // type I effect term
    EC50 = 1.68e-05,  // [kg/m3; mg/liter × 0.001]
    gamma = 1,
    exposure_per_s = 0.001);   // 1 mg/liter per second
equation
  response = E0*(1 - Emax*frac);   // steady state, indirect response type I
  // defaulted: E0
  // defaulted: gamma
  annotation(experiment(StartTime = 0, StopTime = 0.17, Interval = 0.00034),
    Documentation(info = "<html><body><!-- drug-about --><h4>About zanamivir</h4><p>Zanamivir is an antiviral medicine used to treat and prevent influenza. It is authorised in the European Union for human influenza and remains an approved drug.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q146075\">Wikidata Q146075</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h4>Zanamivir_Brown2011_PD_log_10_viral_load</h4><p>The steady-state exposure-response curve of Brown AN et al., <i>Antimicrobial agents and chemotherapy 55(4):1747–1753</i> 2011 (<a href=\"https://doi.org/10.1128/AAC.01629-10\">doi:10.1128/AAC.01629-10</a>) — log(10) viral load against zanamivir mg/liter — obtained by sweeping the driver instead of simulating a dose. Model family: indirect_response_i.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = (library default) drug-free response (baseline)
  Emax  =       0.99          maximal effect term (maximum extent of inhibition, Q323)
  EC50  =     0.0168 mg/liter exposure at half of the maximal effect term (50% inhibitory concentration, Q322)
  gamma = (library default) Hill coefficient</pre><p>The algebra is <code>response = E0*(1 - Emax*frac)</code>; this model only supplies the numbers. The x axis is one mg/liter of zanamivir per second of simulated time (exposure is in kg/m3): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0   (drug-free)
  exposure = EC50 (0.0168 mg/liter)  response 0
  exposure -> infinity  response 0</pre></body></html>"));
end Zanamivir_Brown2011_PD_log_10_viral_load;
