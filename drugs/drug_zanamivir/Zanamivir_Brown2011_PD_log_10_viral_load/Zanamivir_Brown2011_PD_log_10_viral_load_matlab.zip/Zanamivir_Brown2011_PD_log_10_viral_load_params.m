function p = Zanamivir_Brown2011_PD_log_10_viral_load_params()
% Zanamivir_Brown2011_PD_log_10_viral_load_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% zanamivir Brown_2011::log_10_viral_load: indirect_response_i exposure-response sweep (response = E0*(1 - Emax*frac)). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one mg/liter per second, in SI inside (kg/m3, s). Response log(10) viral load in its own unit. Driver: zanamivir (pk_record).
p.E0 = 0.0;
p.Emax = 0.99;
p.EC50 = 1.6799999999999995e-05;
p.gamma = 1.0;
p.slope = 0.0;
p.exposure_per_s = 0.001;
p.stop_time = 0.17;
p.form = 'E0*(1 - Emax*frac)';
end
