model Zanamivir_Wollacott2016_reference
  parameter Real Cl_ref = 3.916666666666666e-09 "Cl [m3/s]";
  parameter Real Vd_ref = 0.005089 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.3323098,
    adminMass = 0.0012
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About zanamivir</h4><p>Zanamivir is an antiviral medicine used to treat and prevent influenza. It is authorised in the European Union for human influenza and remains an approved drug.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q146075\">Wikidata Q146075</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>zanamivir</td></tr><tr><td>population:</td><td>review reference</td></tr><tr><td>source_paper:</td><td>Wollacott_2016</td></tr><tr><td>measured_compound:</td><td>zanamivir</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>zanamivir 332.31 g/mol (drugbank)</td></tr></table><h4>Interpretation flags</h4><ul><li>built from REVIEW reference values (Wollacott_2016) — secondary source</li><li>volume reported by review</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 4838400, Tolerance = 1e-9, Interval = 1));
end Zanamivir_Wollacott2016_reference;
