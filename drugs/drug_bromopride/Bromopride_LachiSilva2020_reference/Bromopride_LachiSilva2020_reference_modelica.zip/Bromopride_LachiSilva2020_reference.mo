model Bromopride_LachiSilva2020_reference
  parameter Real Cl_ref = 1.3000000000000001e-05 "Cl [m3/s]";
  parameter Real Vd_ref = 0.23 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 0.9,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.344247,
    adminMass = 2e-05,
    ka = 2.2222222222222223e-05,
    Tlag = 1692.0
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>bromopride</td></tr><tr><td>population:</td><td>healthy adults</td></tr><tr><td>source_paper:</td><td>Lachi-Silva_2020</td></tr><tr><td>measured_compound:</td><td>bromopride</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>bromopride 344.247 g/mol (drugbank)</td></tr></table><p><b>Defaulted (base-class default used):</b> F.</p><h4>Interpretation flags</h4><ul><li>dropped unlinked row (NIL): 'duration of the zero-order absorption (Tk0)' — extend the ontology if this is a real PK parameter (source ['Lachi-Silva_2020:abstract'])</li><li>unit_dimension_unknown: 'l h - 1' (CL)</li><li>implicit units: 'clearance' → L/h (from the popPK convention: 'No unit is stated in the provided text or table captions. For a total clearance parameter with a value of 46.8, the stan')</li><li>apparent-by-design (ADVISORY, codes unchanged): extravascular dosing with no identifiable F, so these reported disposition parameters are likely apparent unless the model puts first-pass in its structure — Q61 (volume of distribution); Q22 (clearance)</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=bromopride</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 259200, Tolerance = 1e-9, Interval = 1));
end Bromopride_LachiSilva2020_reference;
