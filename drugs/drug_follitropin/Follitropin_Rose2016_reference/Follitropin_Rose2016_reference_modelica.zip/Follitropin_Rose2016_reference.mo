model Follitropin_Rose2016_reference
  parameter Real Cl_ref = 1.175e-07 "Cl [m3/s]";
  parameter Real Vd_ref = 0.024300000000000002 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    adminMass = 0.0001,
    ka = 4.111111111111111e-05,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About follitropin</h4><p>Follitropin, a follicle-stimulating hormone preparation, is used to treat infertility. It is an approved medicine, used widely in fertility treatment.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q20817286\">Wikidata Q20817286</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>follitropin</td></tr><tr><td>population:</td><td>gonadotropin downregulated healthy women</td></tr><tr><td>source_paper:</td><td>Rose_2016</td></tr><tr><td>measured_compound:</td><td>FSH</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>Tab2</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr></table><p><b>Defaulted (base-class default used):</b> Tlag.</p><h4>Interpretation flags</h4><ul><li>table section iiv: 'CL/F (L/h)' routed out of structural estimates ('IIV CV%')</li><li>table section iiv: 'V/F (L)' routed out of structural estimates ('IIV CV%')</li><li>table section iiv: 'k tr (h−1)' routed out of structural estimates ('IIV CV%')</li><li>table section iiv: 'FSHbl (µg/L)' routed out of structural estimates ('IIV CV%')</li><li>dropped unlinked row (NIL): 'FSHbl (µg/L)' — extend the ontology if this is a real PK parameter (source ['Tab2:row5:col1'])</li><li>dropped unlinked row (NIL): 'Progblef' — extend the ontology if this is a real PK parameter (source ['Tab2:row6:col1'])</li><li>dropped unlinked row (NIL): 'InhBef' — extend the ontology if this is a real PK parameter (source ['Tab2:row7:col1'])</li><li>apparent-ness (ontology-grounded): parameterization=apparent, measured_compound=FSH</li><li>molar mass: none found for 'follitropin' — its concentrations stay mass-only</li><li>molar mass: none found for 'FSH' — its concentrations stay mass-only</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of TLAG: primary's parameterization (rate-constant / ka-only) does not use it</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 777600, Tolerance = 1e-9, Interval = 1));
end Follitropin_Rose2016_reference;
