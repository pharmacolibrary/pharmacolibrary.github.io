model Olanzapine_Johnson2011_reference
  parameter Real Cl_ref = 6.066666666666667e-05 "Cl [m3/s]";
  parameter Real Vd_ref = 0.2919 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C_enteral(
    weight = 70.0,
    F = 0.9,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.31243200000000004,
    adminMass = 7e-07,
    ka = 0.00016666666666666666,
    Tlag = 0.0,
    k12 = 0.0001112443378630429,
    k21 = 0.00020802192326856
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About olanzapine</h4><p>Olanzapine is an atypical antipsychotic used to treat schizophrenia, bipolar disorder including acute mania, and other psychotic disorders in adults. It is widely used and authorised in the European Union, where several products remain on the market.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q201872\">Wikidata Q201872</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>olanzapine</td></tr><tr><td>population:</td><td>rats</td></tr><tr><td>source_paper:</td><td>Johnson_2011</td></tr><tr><td>measured_compound:</td><td>olanzapine</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>Tab3</td></tr><tr><td>input:</td><td>PK_2C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>olanzapine 312.432 g/mol (drugbank)</td></tr></table><p><b>Defaulted (base-class default used):</b> F, Tlag.</p><h4>Interpretation flags</h4><ul><li>table section residual_error: 'Proportional error' routed out of structural estimates ('Residual variability')</li><li>table section residual_error: 'Proportional error' routed out of structural estimates ('Residual variability')</li><li>table section residual_error: 'Proportional error' routed out of structural estimates ('Residual variability')</li><li>dropped unlinked row (NIL): 'IAV-CL (%CV)' — extend the ontology if this is a real PK parameter (source ['Tab3:row7:col1', 'Tab3:row7:col2', 'Tab3:row7:col3'])</li><li>dropped unlinked row (NIL): 'IAV-F1 (%CV)' — extend the ontology if this is a real PK parameter (source ['Tab3:row8:col1', 'Tab3:row8:col2', 'Tab3:row8:col3'])</li><li>dropped value-less row: '%RSE'</li><li>NIL: refused to back-fill base 'IIV' from footnote/prose loose number None (source ['Tab3:footnote']); the table cell was unparseable — needs review</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=olanzapine</li><li>gap-filled Q49 (kabs) from Johnson_2011's review values (primary lacked it)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Olanzapine_Johnson2011_reference;
