function p = Olanzapine_Johnson2011_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: olanzapine   source: Johnson_2011 / reference   route: oral
  % estimated (absent from source): F
  p.name  = 'Olanzapine_Johnson2011_reference_params';
  p.drug  = 'olanzapine';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 291.9;                % central volume [L]
  p.CL = 218.4;                % clearance [L/h]
  p.Vp = [156.1];             % peripheral volumes [L]
  p.Q  = [116.9];             % inter-compartmental clearances [L/h]
  p.ka = 0.6;                % absorption rate [1/h]
  p.F  = 0.9;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 0.7;             % dose [mg]
end
