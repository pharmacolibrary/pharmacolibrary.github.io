function p = Olanzapine_Eugene2017_PD_d2ro_params()
% Olanzapine_Eugene2017_PD_d2ro_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% olanzapine Eugene_2017::D2RO: emax exposure-response sweep (response = E0 + Emax*frac). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one mg/day per second, in SI inside (kg/m3, s). Response D2RO in %. Driver: olanzapine (dose_only).
p.E0 = 0.0;
p.Emax = 0.856;
p.EC50 = 5.960648148148148e-11;
p.gamma = 1.0;
p.slope = 0.0;
p.exposure_per_s = 1.15740740741e-11;
p.stop_time = 52.0;
p.form = 'E0 + Emax*frac';
end
