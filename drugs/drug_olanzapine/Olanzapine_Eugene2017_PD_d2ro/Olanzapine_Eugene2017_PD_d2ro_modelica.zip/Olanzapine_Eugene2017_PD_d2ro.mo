model Olanzapine_Eugene2017_PD_d2ro
  "emax exposure-response sweep — Eugene_2017 :: D2RO (dopamine D2-receptor occupancy)"
  extends Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep(
    E0 = 0,      // [1]
    Emax = 0.856,  // [1; % × 0.01]
    EC50 = 5.96064814815e-11,  // [kg/s; mg/day × 1.15741e-11]
    gamma = 1,
    exposure_per_s = 1.15740740741e-11);   // 1 mg/day per second
  // defaulted: E0
  // defaulted: gamma
  annotation(experiment(StartTime = 0, StopTime = 52, Interval = 0.104),
    Documentation(info = "<html><body><!-- drug-about --><h4>About olanzapine</h4><p>Olanzapine is an atypical antipsychotic used to treat schizophrenia, bipolar disorder including acute mania, and other psychotic disorders in adults. It is widely used and authorised in the European Union, where several products remain on the market.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q201872\">Wikidata Q201872</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h4>Olanzapine_Eugene2017_PD_d2ro</h4><p>The steady-state exposure-response curve of Eugene AR et al., <i>Nordic journal of psychiatry 71(6):417–424</i> 2017 (<a href=\"https://doi.org/10.1080/08039488.2017.1314011\">doi:10.1080/08039488.2017.1314011</a>) — dopamine D2-receptor occupancy [%] against olanzapine mg/day — obtained by sweeping the driver instead of simulating a dose. Model family: emax.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = (library default) drug-free response (baseline)
  Emax  =       85.6 %        maximal effect term (Emax, Q320)
  EC50  =       5.15 mg/day   exposure at half of the maximal effect term (ED50-Men, Q321)
  gamma = (library default) Hill coefficient</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep\">SigmoidEmaxSweep</a>; this model only supplies the numbers. The x axis is one mg/day of olanzapine per second of simulated time (exposure is in kg/s): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0   (drug-free)
  exposure = EC50 (5.15 mg/day)  response 0.428
  exposure -> infinity  response 0.856</pre></body></html>"));
end Olanzapine_Eugene2017_PD_d2ro;
