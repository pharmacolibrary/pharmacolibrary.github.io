model Olanzapine_Zang2024_reference
  parameter Real Cl_ref = 2.8833333333333334e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.6587 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.31243200000000004,
    adminMass = 1e-05,
    ka = 8.333333333333333e-05,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About olanzapine</h4><p>Olanzapine is an atypical antipsychotic used to treat schizophrenia, bipolar disorder including acute mania, and other psychotic disorders in adults. It is widely used and authorised in the European Union, where several products remain on the market.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q201872\">Wikidata Q201872</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>olanzapine</td></tr><tr><td>population:</td><td>pediatric Chinese patients with psychiatric disorders</td></tr><tr><td>source_paper:</td><td>Zang_2024</td></tr><tr><td>measured_compound:</td><td>olanzapine</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>olanzapine 312.432 g/mol (drugbank)</td></tr></table><p><b>Defaulted (base-class default used):</b> Tlag.</p><h4>Interpretation flags</h4><ul><li>unit_dimension_unknown: 'L∕h' (CL/F)</li><li>dropped duplicate Q27 ('CL∕F (L∕h)', value None) — already have one for this compound</li><li>apparent-ness (ontology-grounded): parameterization=apparent, measured_compound=olanzapine</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of TLAG: primary's parameterization (rate-constant / ka-only) does not use it</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 864000, Tolerance = 1e-9, Interval = 1));
end Olanzapine_Zang2024_reference;
