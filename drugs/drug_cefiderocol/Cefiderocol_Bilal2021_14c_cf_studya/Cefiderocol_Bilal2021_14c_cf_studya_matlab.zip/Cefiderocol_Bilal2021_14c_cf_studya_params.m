function p = Cefiderocol_Bilal2021_14c_cf_studya_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: cefiderocol   source: Bilal_2021 / 14c_cf_studya   route: iv_bolus
  % estimated (absent from source): F
  p.name  = 'Cefiderocol_Bilal2021_14c_cf_studya_params';
  p.drug  = 'cefiderocol';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'iv_bolus';        % 'oral' | 'iv_bolus'
  p.depot = false;             % oral -> first-order absorption depot
  p.Vc = 15.8;                % central volume [L]
  p.CL = 4.78;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.0;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 100.0;             % dose [mg]
end
