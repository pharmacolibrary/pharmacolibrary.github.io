model Cefiderocol_Zahr2022_reference
  parameter Real Cl_ref = 2.0500000000000003e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.017 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.75221,
    adminMass = 0.00075
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About cefiderocol</h4><p>Cefiderocol is a siderophore cephalosporin antibiotic used to treat infections caused by Gram-negative bacteria. It is an approved antibacterial, authorised in the European Union, though it is also being investigated for further uses.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q27289472\">Wikidata Q27289472</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>cefiderocol</td></tr><tr><td>population:</td><td>critically ill adult patients</td></tr><tr><td>source_paper:</td><td>Zahr_2022</td></tr><tr><td>measured_compound:</td><td>cefiderocol</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>pharmaceutics-14-02786-t003</td></tr><tr><td>input:</td><td>PK_1C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>cefiderocol 752.21 g/mol (drugbank)</td></tr></table><h4>Interpretation flags</h4><ul><li>dropped unlinked row (NIL): 'V2U, L' — extend the ontology if this is a real PK parameter (source ['pharmaceutics-14-02786-t003:row4:col1', 'pharmaceutics-14-02786-t003:row4:col2'])</li><li>dropped duplicate Q24 ('CKD effect on CLU', value '0.426') — already have one for this compound</li><li>covariate effect for Q46 has no base parameter row (kept as unattached equation-variable)</li><li>implicit units: 'CLU, L/h per CKD = 100' → L/h (from the paper text: &quot;The paper explicitly states the unit in the equation for the final covariate sub-model: 'The final covariate sub-model f&quot;)</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=cefiderocol</li><li>structure disagreement: deterministic 1C vs LLM 2C — review compartment count</li><li>1C volume normalization: Q63→Q61 (single-compartment model has no central/peripheral split; 'V1U, L' is the general volume)</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Cefiderocol_Zahr2022_reference;
