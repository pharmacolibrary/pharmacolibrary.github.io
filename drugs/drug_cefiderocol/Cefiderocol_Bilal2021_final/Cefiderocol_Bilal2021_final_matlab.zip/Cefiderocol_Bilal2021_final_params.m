function p = Cefiderocol_Bilal2021_final_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: cefiderocol   source: Bilal_2021 / final   route: iv_bolus
  % estimated (absent from source): F
  p.name  = 'Cefiderocol_Bilal2021_final_params';
  p.drug  = 'cefiderocol';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'iv_bolus';        % 'oral' | 'iv_bolus'
  p.depot = false;             % oral -> first-order absorption depot
  p.Vc = 7.78;                % central volume [L]
  p.CL = 4.04;                % clearance [L/h]
  p.Vp = [5.77];             % peripheral volumes [L]
  p.Q  = [6.19];             % inter-compartmental clearances [L/h]
  p.ka = 0.0;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 100.0;             % dose [mg]
end
