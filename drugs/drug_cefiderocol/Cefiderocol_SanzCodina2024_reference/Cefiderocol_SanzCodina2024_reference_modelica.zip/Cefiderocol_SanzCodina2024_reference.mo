model Cefiderocol_SanzCodina2024_reference
  parameter Real Cl_ref = 3.055555555555555e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.011300000000000001 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.75221,
    adminMass = 0.002,
    k12 = 0.0006219272369714847,
    k21 = 0.0004654157468727005
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About cefiderocol</h4><p>Cefiderocol is a siderophore cephalosporin antibiotic used to treat infections caused by Gram-negative bacteria. It is an approved antibacterial, authorised in the European Union, though it is also being investigated for further uses.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q27289472\">Wikidata Q27289472</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>cefiderocol</td></tr><tr><td>population:</td><td>healthy volunteers</td></tr><tr><td>source_paper:</td><td>Sanz-Codina_2024</td></tr><tr><td>measured_compound:</td><td>cefiderocol</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>dkae359-T2</td></tr><tr><td>input:</td><td>PK_2C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>cefiderocol 752.21 g/mol (drugbank)</td></tr></table><h4>Interpretation flags</h4><ul><li>table section iiv: 'CL (CV%)' routed out of structural estimates ('Inter-individual variability')</li><li>table section iiv: 'Vc (CV%)' routed out of structural estimates ('Inter-individual variability')</li><li>table section iiv: 'TFsub (CV%)' routed out of structural estimates ('Inter-individual variability')</li><li>table section iiv: 'TFmus (CV%)' routed out of structural estimates ('Inter-individual variability')</li><li>table section residual_error: 'Propplasma (CV%)' routed out of structural estimates ('Residual error')</li><li>table section residual_error: 'Proptissue (CV%)' routed out of structural estimates ('Residual error')</li><li>table section residual_error: 'Addtissue (mg/L)' routed out of structural estimates ('Residual error')</li><li>dropped unlinked row (NIL): 'TFsub' — extend the ontology if this is a real PK parameter (source ['dkae359-T2:row7:col2'])</li><li>dropped unlinked row (NIL): 'TFmus' — extend the ontology if this is a real PK parameter (source ['dkae359-T2:row8:col2'])</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=cefiderocol</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Cefiderocol_SanzCodina2024_reference;
