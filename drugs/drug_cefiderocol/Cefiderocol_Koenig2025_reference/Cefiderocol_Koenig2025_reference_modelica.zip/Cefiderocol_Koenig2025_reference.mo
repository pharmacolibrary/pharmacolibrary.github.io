model Cefiderocol_Koenig2025_reference
  parameter Real Cl_ref = 6.388888888888888e-07 "Cl [m3/s]";
  parameter Real Vd_ref = 0.0048 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.75221,
    adminMass = 0.006
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About cefiderocol</h4><p>Cefiderocol is a siderophore cephalosporin antibiotic used to treat infections caused by Gram-negative bacteria. It is an approved antibacterial, authorised in the European Union, though it is also being investigated for further uses.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q27289472\">Wikidata Q27289472</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>cefiderocol</td></tr><tr><td>population:</td><td>critically-ill patients receiving ECMO</td></tr><tr><td>source_paper:</td><td>Koenig_2025</td></tr><tr><td>measured_compound:</td><td>cefiderocol</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>cefiderocol 752.21 g/mol (drugbank)</td></tr></table><h4>Interpretation flags</h4><ul><li>dropped unlinked row (NIL): 'Mean protein binding' — extend the ontology if this is a real PK parameter (source ['Koenig_2025:abstract'])</li><li>dropped unlinked row (NIL): 'total steady-state AUC24h' — extend the ontology if this is a real PK parameter (source ['Koenig_2025:abstract'])</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=cefiderocol</li><li>1C volume normalization: Q63→Q61 (single-compartment model has no central/peripheral split; 'volume of the central compartment (V)' is the general volume)</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary's parameterization (rate-constant / ka-only) does not use it</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Cefiderocol_Koenig2025_reference;
