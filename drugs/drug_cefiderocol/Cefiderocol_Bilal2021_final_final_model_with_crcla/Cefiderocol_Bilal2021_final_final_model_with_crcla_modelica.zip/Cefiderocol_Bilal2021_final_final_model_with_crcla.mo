model Cefiderocol_Bilal2021_final_final_model_with_crcla
  parameter Real Cl_ref = 1.3416666666666666e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.00758 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.75221,
    adminMass = 0.0001,
    k12 = 0.0001997214892993257,
    k21 = 0.00027326514239871643
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About cefiderocol</h4><p>Cefiderocol is a siderophore cephalosporin antibiotic used to treat infections caused by Gram-negative bacteria. It is an approved antibacterial, authorised in the European Union, though it is also being investigated for further uses.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q27289472\">Wikidata Q27289472</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>cefiderocol</td></tr><tr><td>population:</td><td>mixed</td></tr><tr><td>source_paper:</td><td>Bilal_2021</td></tr><tr><td>measured_compound:</td><td>cefiderocol</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>Tab2</td></tr><tr><td>input:</td><td>PK_2C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>cefiderocol 752.21 g/mol (drugbank)</td></tr></table><h4>Interpretation flags</h4><ul><li>dropped unlinked row (NIL): 'Parameter' — extend the ontology if this is a real PK parameter (source ['Tab2:row0:col5', 'Tab2:row0:col6'])</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=cefiderocol</li><li>structure disagreement: deterministic 2C vs LLM 3C — review compartment count</li><li>model-stage split: 'final model*** with crcla(n = 1624)' is the final model of Bilal_2021 (paper reports 6 stages: [14c] cf-studya, final model* withcrcla (n = 3427), final model** with crcla(n = 2571), final model*** with crcla(n = 1624), phase i pk, safety, and tolerability study, phase i study in renally impaired subjects); same population, different model-building step</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Cefiderocol_Bilal2021_final_final_model_with_crcla;
