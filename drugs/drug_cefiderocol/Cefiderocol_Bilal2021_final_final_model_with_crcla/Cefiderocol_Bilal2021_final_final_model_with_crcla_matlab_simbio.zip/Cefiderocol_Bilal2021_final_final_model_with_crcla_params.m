function p = Cefiderocol_Bilal2021_final_final_model_with_crcla_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: cefiderocol   source: Bilal_2021 / final_final_model_with_crcla   route: iv_bolus
  % estimated (absent from source): F
  p.name  = 'Cefiderocol_Bilal2021_final_final_model_with_crcla_params';
  p.drug  = 'cefiderocol';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'iv_bolus';        % 'oral' | 'iv_bolus'
  p.depot = false;             % oral -> first-order absorption depot
  p.Vc = 7.58;                % central volume [L]
  p.CL = 4.83;                % clearance [L/h]
  p.Vp = [5.54];             % peripheral volumes [L]
  p.Q  = [5.45];             % inter-compartmental clearances [L/h]
  p.ka = 0.0;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 100.0;             % dose [mg]
end
