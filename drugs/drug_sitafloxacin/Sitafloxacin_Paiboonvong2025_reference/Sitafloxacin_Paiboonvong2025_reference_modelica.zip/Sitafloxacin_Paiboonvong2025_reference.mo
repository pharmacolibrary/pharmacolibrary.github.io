model Sitafloxacin_Paiboonvong2025_reference
  parameter Real Cl_ref = 2.6287393162393163e-06 "Cl [m3/s]";
  parameter Real cov_age_0 = 0 "age covariate";
  parameter Real Vd_ref = 0.15615384615384617 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref*(1 + (2.58)*cov_age_0),
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.8736799999999999,
    adminMass = 0.0001,
    ka = 0.0001388888888888889,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About sitafloxacin</h4><p>Sitafloxacin is a fluoroquinolone antibacterial investigated for treating bacterial infections. It is not authorised in the European Union and remains investigational.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q3962322\">Wikidata Q3962322</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>sitafloxacin</td></tr><tr><td>population:</td><td>critically ill Thai patients with pneumonia</td></tr><tr><td>source_paper:</td><td>Paiboonvong_2025</td></tr><tr><td>measured_compound:</td><td>sitafloxacin</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>prp270081-tbl-0002</td></tr><tr><td>input:</td><td>PK_1C_enteral: apparent (/F) parameterization ⇒ extravascular dosing</td></tr><tr><td>molar_masses:</td><td>sitafloxacin 873.68 g/mol (drugbank)</td></tr></table><p><b>Defaulted (base-class default used):</b> ka, Tlag.</p><h4>Interpretation flags</h4><ul><li>table section iiv: 'F' routed out of structural estimates ('%CV for IIV a (%RSE) b')</li><li>table section iiv: 'F' routed out of structural estimates ('95%CI for IIV b')</li><li>table section iiv: 'CL/F (L/h/52 kg)' routed out of structural estimates ('%CV for IIV a (%RSE) b')</li><li>table section iiv: 'CL/F (L/h/52 kg)' routed out of structural estimates ('95%CI for IIV b')</li><li>table section iiv: 'MTT (hr)' routed out of structural estimates ('%CV for IIV a (%RSE) b')</li><li>table section iiv: 'MTT (hr)' routed out of structural estimates ('95%CI for IIV b')</li><li>table section iiv: 'PC' routed out of structural estimates ('%CV for IIV a (%RSE) b')</li><li>table section iiv: 'PC' routed out of structural estimates ('95%CI for IIV b')</li><li>dropped unlinked row (NIL): 'V/FELF (L)' — extend the ontology if this is a real PK parameter (source ['prp270081-tbl-0002:row5:col1'])</li><li>dropped unlinked row (NIL): 'Q/FELF (L/h/52 kg)' — extend the ontology if this is a real PK parameter (source ['prp270081-tbl-0002:row6:col1', 'prp270081-tbl-0002:row6:col2'])</li><li>dropped unlinked row (NIL): 'PC' — extend the ontology if this is a real PK parameter (source ['prp270081-tbl-0002:row8:col1', 'prp270081-tbl-0002:row8:col2'])</li><li>covariate level 'AGE on F (%)' → Q900:age_on_f = 2.58 (linear_fractional on Q27)</li><li>apparent-ness (ontology-grounded): parameterization=apparent, measured_compound=sitafloxacin</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 259200, Tolerance = 1e-9, Interval = 1));
end Sitafloxacin_Paiboonvong2025_reference;
