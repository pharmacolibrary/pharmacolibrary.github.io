model Didanosine_Pai1992_reference
  parameter Real Cl_ref = 1.3611111111111111e-05 "Cl [m3/s]";
  parameter Real Vd_ref = 0.012599999999999998 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 0.34,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.2362273,
    adminMass = 0.0004,
    ka = 0.00036111111111111115,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About didanosine</h4><p>Didanosine is an antiviral nucleoside analogue used to treat HIV infection and AIDS. It is an approved medicine and has been included on the WHO list of essential medicines, though it carries a boxed warning.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q422606\">Wikidata Q422606</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>didanosine</td></tr><tr><td>population:</td><td>patients with AIDS or AIDS-related complex</td></tr><tr><td>source_paper:</td><td>Pai_1992</td></tr><tr><td>measured_compound:</td><td>didanosine</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>didanosine 236.227 g/mol (drugbank)</td></tr></table><p><b>Defaulted (base-class default used):</b> Tlag.</p><h4>Interpretation flags</h4><ul><li>dropped value-less row: 'Interindividual variability (omega) was (%CV) 22.3 and 71.0 for CL and Vc'</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=didanosine</li><li>1C volume normalization: Q63→Q61 (single-compartment model has no central/peripheral split; 'central compartment volume, Vc' is the general volume)</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of TLAG: primary's parameterization (rate-constant / ka-only) does not use it</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Didanosine_Pai1992_reference;
