function p = Didanosine_Pai1992_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: didanosine   source: Pai_1992 / reference   route: oral
  p.name  = 'Didanosine_Pai1992_reference_params';
  p.drug  = 'didanosine';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 12.6;                % central volume [L]
  p.CL = 49.0;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 1.3;                % absorption rate [1/h]
  p.F  = 0.34;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 400.0;             % dose [mg]
end
