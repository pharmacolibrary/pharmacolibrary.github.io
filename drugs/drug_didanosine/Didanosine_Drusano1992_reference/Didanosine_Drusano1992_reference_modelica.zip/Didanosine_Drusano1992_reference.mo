model Didanosine_Drusano1992_reference
  parameter Real Cl_ref = 1.3250000000000002e-05 "Cl [m3/s]";
  parameter Real Vd_ref = 0.0188 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.2362273,
    adminMass = 1e-05
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About didanosine</h4><p>Didanosine is an antiviral nucleoside analogue used to treat HIV infection and AIDS. It is an approved medicine and has been included on the WHO list of essential medicines, though it carries a boxed warning.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q422606\">Wikidata Q422606</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>didanosine</td></tr><tr><td>population:</td><td>HIV-infected patients</td></tr><tr><td>source_paper:</td><td>Drusano_1992</td></tr><tr><td>measured_compound:</td><td>ddI</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>ddI 236.227 g/mol (drugbank); didanosine 236.227 g/mol (drugbank)</td></tr></table><h4>Interpretation flags</h4><ul><li>unit_dimension_unknown: 'liters/h/70 kg of body weight' (CL)</li><li>implicit units: 'Clearance of the drug from plasma' → L/h (from the popPK convention: 'No unit is provided in the text or table. For a total clearance (CL) parameter in population pharmacokinetics, the most ')</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=ddI</li><li>held at status:extracted — NIL link or unit issue (mismatch/unknown/normalisation-failed) present</li><li>1C volume normalization: Q63→Q61 (single-compartment model has no central/peripheral split; 'volume of distribution in the central compartment' is the general volume)</li><li>status held at route_to_review — not promoted</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Didanosine_Drusano1992_reference;
