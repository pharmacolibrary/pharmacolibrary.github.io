function p = Didanosine_Drusano1992_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: didanosine   source: Drusano_1992 / reference   route: iv_bolus
  % estimated (absent from source): dose
  p.name  = 'Didanosine_Drusano1992_reference_params';
  p.drug  = 'didanosine';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'iv_bolus';        % 'oral' | 'iv_bolus'
  p.depot = false;             % oral -> first-order absorption depot
  p.Vc = 18.8;                % central volume [L]
  p.CL = 47.7;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.0;                % absorption rate [1/h]
  p.F  = 0.27;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 10.0;             % dose [mg]
end
