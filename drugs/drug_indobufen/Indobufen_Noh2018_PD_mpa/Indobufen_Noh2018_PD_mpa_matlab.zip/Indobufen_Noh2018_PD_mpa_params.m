function p = Indobufen_Noh2018_PD_mpa_params()
% Indobufen_Noh2018_PD_mpa_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% indobufen Noh_2018::MPA: sigmoid_emax exposure-response sweep (response = E0 + Emax*frac). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one mg/L per second, in SI inside (kg/m3, s). Response MPA in %. Driver: S-indobufen and R-indobufen (conc_no_pk).
p.E0 = 0.0;
p.Emax = -0.0638;
p.EC50 = 0.006749999999999999;
p.gamma = 1.0;
p.slope = 0.0;
p.exposure_per_s = 0.001;
p.stop_time = 68.0;
p.form = 'E0 + Emax*frac';
end
