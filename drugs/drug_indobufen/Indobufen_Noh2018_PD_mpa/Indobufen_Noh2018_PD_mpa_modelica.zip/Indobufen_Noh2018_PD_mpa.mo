model Indobufen_Noh2018_PD_mpa
  "sigmoid_emax exposure-response sweep — Noh_2018 :: MPA (platelet aggregation inhibition)"
  extends Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep(
    E0 = 0,      // [1]
    Emax = -0.0638,  // [1; % × 0.01]
    EC50 = 0.00675,  // [kg/m3; mg/L × 0.001]
    gamma = 1,
    exposure_per_s = 0.001);   // 1 mg/L per second
  // imax_as_negative_emax: Imax (Q323) enters SigmoidEmaxSweep as −Emax
  // defaulted: E0
  // defaulted: gamma
  annotation(experiment(StartTime = 0, StopTime = 68, Interval = 0.136),
    Documentation(info = "<html><body><h4>Indobufen_Noh2018_PD_mpa</h4><p>The steady-state exposure-response curve of Noh YH et al., <i>Translational and clinical pharmacology 26(4):160–165</i> 2018 (<a href=\"https://doi.org/10.12793/tcp.2018.26.4.160\">doi:10.12793/tcp.2018.26.4.160</a>) — platelet aggregation inhibition [%] against S-indobufen and R-indobufen mg/L — obtained by sweeping the driver instead of simulating a dose. Model family: sigmoid_emax.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = (library default) drug-free response (baseline)
  Emax  =       6.38 %        maximal effect term (Imax — Estimate, Q323)
  EC50  =       6.75 mg/L     exposure at half of the maximal effect term (C50, S — Estimate, Q321)
  gamma = (library default) Hill coefficient</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep\">SigmoidEmaxSweep</a>; this model only supplies the numbers. The x axis is one mg/L of S-indobufen and R-indobufen per second of simulated time (exposure is in kg/m3): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0   (drug-free)
  exposure = EC50 (6.75 mg/L)  response -0.0319
  exposure -> infinity  response -0.0638</pre></body></html>"));
end Indobufen_Noh2018_PD_mpa;
