function p = Naproxen_Josa2001_PD_carrageenin_induced_edema_params()
% Naproxen_Josa2001_PD_carrageenin_induced_edema_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% naproxen Josa_2001::carrageenin_induced_edema: indirect_response_i exposure-response sweep (response = E0*(1 - Emax*frac)). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one microg/ml per second, in SI inside (kg/m3, s). Response carrageenin-induced edema in its own unit. Driver: naproxen (cited_pk).
p.E0 = 0.0;
p.Emax = 1.0;
p.EC50 = 0.004129999999999999;
p.gamma = 1.0;
p.slope = 0.0;
p.exposure_per_s = 0.001;
p.stop_time = 42.0;
p.form = 'E0*(1 - Emax*frac)';
end
