model Naproxen_Josa2001_PD_carrageenin_induced_edema
  "indirect_response_i exposure-response sweep — Josa_2001 :: carrageenin-induced edema (anti-inflammatory effect)"
  extends Pharmacolibrary.Interfaces.PartialExposureResponseSweep(
    E0 = 0,      // [1]
    Emax = 1,  // type I effect term
    EC50 = 0.00413,  // [kg/m3; microg/ml × 0.001]
    gamma = 1,
    exposure_per_s = 0.001);   // 1 microg/ml per second
equation
  response = E0*(1 - Emax*frac);   // steady state, indirect response type I
  // defaulted: E0
  // defaulted: Emax
  // defaulted: gamma
  annotation(experiment(StartTime = 0, StopTime = 42, Interval = 0.084),
    Documentation(info = "<html><body><!-- drug-about --><h4>About naproxen</h4><p>Naproxen is a non-steroidal anti-inflammatory drug used to treat pain, inflammation, and conditions such as osteoarthritis, rheumatoid arthritis, ankylosing spondylitis, gout, and migraine. It is widely used and available in many forms, including oral and topical preparations, and is also approved for veterinary use.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q1215575\">Wikidata Q1215575</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h4>Naproxen_Josa2001_PD_carrageenin_induced_edema</h4><p>The steady-state exposure-response curve of Josa M et al., <i>The Journal of pharmacology and experimental therapeutics 297(1):198–205</i> 2001 — anti-inflammatory effect against naproxen microg/ml — obtained by sweeping the driver instead of simulating a dose. Model family: indirect_response_i.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = (library default) drug-free response (baseline)
  Emax  = (library default) maximal effect term
  EC50  =       4.13 microg/ml exposure at half of the maximal effect term (IC(50), Q322)
  gamma = (library default) Hill coefficient</pre><p>The algebra is <code>response = E0*(1 - Emax*frac)</code>; this model only supplies the numbers. The x axis is one microg/ml of naproxen per second of simulated time (exposure is in kg/m3): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0   (drug-free)
  exposure = EC50 (4.13 microg/ml)  response 0
  exposure -> infinity  response 0</pre></body></html>"));
end Naproxen_Josa2001_PD_carrageenin_induced_edema;
