model Naproxen_Huntjens2006_PD_txb2_2
  "sigmoid_emax exposure-response sweep — Huntjens_2006 :: TXB2 (TXB2 inhibition (in vitro rat))"
  extends Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep(
    E0 = 0.000272,      // [kg/m3; ng ml-1 × 1e-06]
    Emax = -5.7e-06,  // [kg/m3; ng ml-1 × 1e-06]
    EC50 = 72.4,  // [mM]
    gamma = 1.88,
    exposure_per_s = 1);   // 1 mM per second
  // imax_as_negative_emax: Imax (Q323) enters SigmoidEmaxSweep as −Emax
  // exposure_unit_unresolved: 'mM' — the x axis is in the paper's unit, not SI
  annotation(experiment(StartTime = 0, StopTime = 730, Interval = 1.46),
    Documentation(info = "<html><body><!-- drug-about --><h4>About naproxen</h4><p>Naproxen is a non-steroidal anti-inflammatory drug used to treat pain, inflammation, and conditions such as osteoarthritis, rheumatoid arthritis, ankylosing spondylitis, gout, and migraine. It is widely used and available in many forms, including oral and topical preparations, and is also approved for veterinary use.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q1215575\">Wikidata Q1215575</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h4>Naproxen_Huntjens2006_PD_txb2_2</h4><p>The steady-state exposure-response curve of Huntjens DR et al., <i>British journal of pharmacology 148(4):396–404</i> 2006 (<a href=\"https://doi.org/10.1038/sj.bjp.0706737\">doi:10.1038/sj.bjp.0706737</a>) — TXB2 inhibition (in vitro rat) [ng ml-1] against naproxen mM — obtained by sweeping the driver instead of simulating a dose. Model family: sigmoid_emax.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    =        272 ng ml-1  drug-free response (baseline) (I0 y Intercept, Q324)
  Emax  =        5.7 ng ml-1  maximal effect term (Imax, Q323)
  EC50  =       72.4 mM       exposure at half of the maximal effect term (IC50, Q322)
  gamma =       1.88          Hill coefficient (Hill coefficient, Q325)</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep\">SigmoidEmaxSweep</a>; this model only supplies the numbers. The x axis is one mM of naproxen per second of simulated time: there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0.000272   (drug-free)
  exposure = EC50 (72.4 mM)  response 0.0002692
  exposure -> infinity  response 0.0002663</pre></body></html>"));
end Naproxen_Huntjens2006_PD_txb2_2;
