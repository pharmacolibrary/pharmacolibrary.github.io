function p = Naproxen_Huntjens2006_PD_pge2_3_params()
% Naproxen_Huntjens2006_PD_pge2_3_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% naproxen Huntjens_2006::PGE2::3: sigmoid_emax exposure-response sweep (response = E0 + Emax*frac). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one mM per second, in SI inside (kg/m3, s). Response PGE2 in ng ml-1. Driver: naproxen (pk_record).
p.E0 = 2.3399999999999996e-05;
p.Emax = -7e-08;
p.EC50 = 79.5;
p.gamma = 2.66;
p.slope = 0.0;
p.exposure_per_s = 1.0;
p.stop_time = 800.0;
p.form = 'E0 + Emax*frac';
end
