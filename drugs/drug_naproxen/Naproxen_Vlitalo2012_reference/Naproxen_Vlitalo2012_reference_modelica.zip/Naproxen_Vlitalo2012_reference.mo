model Naproxen_Vlitalo2012_reference
  parameter Real Cl_ref = 1.7222222222222222e-07 "Cl [m3/s]";
  parameter Real Vd_ref = 0.0125 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.2302592,
    adminMass = 0.0005,
    ka = 6.583333333333333e-05,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About naproxen</h4><p>Naproxen is a non-steroidal anti-inflammatory drug used to treat pain, inflammation, and conditions such as osteoarthritis, rheumatoid arthritis, ankylosing spondylitis, gout, and migraine. It is widely used and available in many forms, including oral and topical preparations, and is also approved for veterinary use.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q1215575\">Wikidata Q1215575</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>naproxen</td></tr><tr><td>population:</td><td>healthy children</td></tr><tr><td>source_paper:</td><td>Välitalo_2012</td></tr><tr><td>measured_compound:</td><td>naproxen</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>naproxen 230.259 g/mol (drugbank)</td></tr></table><h4>Interpretation flags</h4><ul><li>apparent-ness (ontology-grounded): parameterization=apparent, measured_compound=naproxen</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li><li>gap-filled Q49 (kabs) from Björnsson_2011's review values (primary lacked it)</li><li>gap-filled Q83 (tlag) from Yoo_2026's review values (primary lacked it)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 345600, Tolerance = 1e-9, Interval = 1));
end Naproxen_Vlitalo2012_reference;
