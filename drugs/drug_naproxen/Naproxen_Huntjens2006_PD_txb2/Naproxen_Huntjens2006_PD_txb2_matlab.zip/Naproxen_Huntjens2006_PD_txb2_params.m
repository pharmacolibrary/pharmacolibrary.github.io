function p = Naproxen_Huntjens2006_PD_txb2_params()
% Naproxen_Huntjens2006_PD_txb2_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% naproxen Huntjens_2006::TXB2: sigmoid_emax exposure-response sweep (response = E0 + Emax*frac). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one ng ml-1 per second, in SI inside (kg/m3, s). Response TXB2 in ng ml-1. Driver: naproxen (pk_record).
p.E0 = 0.00025299999999999997;
p.Emax = -1.2199999999999998e-05;
p.EC50 = 0.001353;
p.gamma = 1.46;
p.slope = 0.0;
p.exposure_per_s = 1e-06;
p.stop_time = 14000.0;
p.form = 'E0 + Emax*frac';
end
