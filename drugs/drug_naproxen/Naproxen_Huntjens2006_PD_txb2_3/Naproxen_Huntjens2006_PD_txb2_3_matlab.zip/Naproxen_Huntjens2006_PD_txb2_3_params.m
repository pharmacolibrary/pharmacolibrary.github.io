function p = Naproxen_Huntjens2006_PD_txb2_3_params()
% Naproxen_Huntjens2006_PD_txb2_3_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% naproxen Huntjens_2006::TXB2::3: sigmoid_emax exposure-response sweep (response = E0 + Emax*frac). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one mM per second, in SI inside (kg/m3, s). Response TXB2 in ng ml-1. Driver: naproxen (pk_record).
p.E0 = 0.000235;
p.Emax = -2.0199999999999997e-06;
p.EC50 = 48.3;
p.gamma = 1.81;
p.slope = 0.0;
p.exposure_per_s = 1.0;
p.stop_time = 490.0;
p.form = 'E0 + Emax*frac';
end
