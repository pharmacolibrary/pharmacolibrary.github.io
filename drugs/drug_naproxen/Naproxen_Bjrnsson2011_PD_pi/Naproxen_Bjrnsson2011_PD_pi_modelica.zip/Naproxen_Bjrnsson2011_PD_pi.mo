model Naproxen_Bjrnsson2011_PD_pi
  "sigmoid_emax exposure-response sweep — Björnsson_2011 :: PI (pain intensity)"
  extends Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep(
    E0 = 52.7,      // [mm]
    Emax = -1,  // [mm]
    EC50 = 0.135,  // [mol/m3; mmol l -1 × 1]
    gamma = 1.61,
    exposure_per_s = 1);   // 1 mmol l -1 per second
  // inhibition_sign: effect_direction=inhibition with a positive Emax (Q320) — sign flipped
  annotation(experiment(StartTime = 0, StopTime = 1.4, Interval = 0.0028),
    Documentation(info = "<html><body><!-- drug-about --><h4>About naproxen</h4><p>Naproxen is a non-steroidal anti-inflammatory drug used to treat pain, inflammation, and conditions such as osteoarthritis, rheumatoid arthritis, ankylosing spondylitis, gout, and migraine. It is widely used and available in many forms, including oral and topical preparations, and is also approved for veterinary use.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q1215575\">Wikidata Q1215575</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h4>Naproxen_Bjrnsson2011_PD_pi</h4><p>The steady-state exposure-response curve of Björnsson MA et al., <i>British journal of clinical pharmacology 71(6):899–906</i> 2011 (<a href=\"https://doi.org/10.1111/j.1365-2125.2011.03924.x\">doi:10.1111/j.1365-2125.2011.03924.x</a>) — pain intensity [mm] against unbound naproxen mmol l -1 — obtained by sweeping the driver instead of simulating a dose. Model family: sigmoid_emax.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    =       52.7 mm       drug-free response (baseline) (PIbaseline, Q324)
  Emax  =          1 mm       maximal effect term (Emax, Q320)
  EC50  =      0.135 mmol l -1 exposure at half of the maximal effect term (EC50, Q321)
  gamma =       1.61          Hill coefficient (g, Q325)</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep\">SigmoidEmaxSweep</a>; this model only supplies the numbers. The x axis is one mmol l -1 of unbound naproxen per second of simulated time (exposure is in mol/m3): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 52.7   (drug-free)
  exposure = EC50 (0.135 mmol l -1)  response 52.2
  exposure -> infinity  response 51.7</pre></body></html>"));
end Naproxen_Bjrnsson2011_PD_pi;
