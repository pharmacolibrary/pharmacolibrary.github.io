function p = Naproxen_Bjrnsson2011_PD_pi_params()
% Naproxen_Bjrnsson2011_PD_pi_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% naproxen Björnsson_2011::PI: sigmoid_emax exposure-response sweep (response = E0 + Emax*frac). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one mmol l -1 per second, in SI inside (kg/m3, s). Response PI in mm. Driver: unbound naproxen (not_resolved).
p.E0 = 52.7;
p.Emax = -1.0;
p.EC50 = 0.13499999999999998;
p.gamma = 1.61;
p.slope = 0.0;
p.exposure_per_s = 1.0;
p.stop_time = 1.4;
p.form = 'E0 + Emax*frac';
end
