model Naproxen_Blaser2021_PD_6_keto_pgf1
  "sigmoid_emax exposure-response sweep — Blaser_2021 :: 6-keto-PGF1α (urinary 6-keto-PGF1α excretion)"
  extends Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep(
    E0 = 167.16,      // [pg/mg creatinine]
    Emax = -133.56,  // [pg/mg creatinine]
    EC50 = 0.034,  // [µM]
    gamma = 7.2,
    exposure_per_s = 1);   // 1 µM per second
  // imax_as_negative_emax: Imax (Q323) enters SigmoidEmaxSweep as −Emax
  // exposure_unit_unresolved: 'µM' — the x axis is in the paper's unit, not SI
  annotation(experiment(StartTime = 0, StopTime = 0.34, Interval = 0.00068),
    Documentation(info = "<html><body><!-- drug-about --><h4>About naproxen</h4><p>Naproxen is a non-steroidal anti-inflammatory drug used to treat pain, inflammation, and conditions such as osteoarthritis, rheumatoid arthritis, ankylosing spondylitis, gout, and migraine. It is widely used and available in many forms, including oral and topical preparations, and is also approved for veterinary use.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q1215575\">Wikidata Q1215575</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h4>Naproxen_Blaser2021_PD_6_keto_pgf1</h4><p>The steady-state exposure-response curve of Blaser LS et al., <i>Frontiers in pharmacology 12:620635</i> 2021 (<a href=\"https://doi.org/10.3389/fphar.2021.620635\">doi:10.3389/fphar.2021.620635</a>) — urinary 6-keto-PGF1α excretion [pg/mg creatinine] against naproxen µM — obtained by sweeping the driver instead of simulating a dose. Model family: sigmoid_emax.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    =     167.16 pg/mg creatinine drug-free response (baseline) (E0, Q324)
  Emax  =     133.56 pg/mg creatinine maximal effect term (Emax, Q323)
  EC50  =      0.034 µM       exposure at half of the maximal effect term (EC50, Q321)
  gamma =        7.2          Hill coefficient (N, Q325)</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep\">SigmoidEmaxSweep</a>; this model only supplies the numbers. The x axis is one µM of naproxen per second of simulated time: there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 167.2   (drug-free)
  exposure = EC50 (0.034 µM)  response 100.4
  exposure -> infinity  response 33.6</pre></body></html>"));
end Naproxen_Blaser2021_PD_6_keto_pgf1;
