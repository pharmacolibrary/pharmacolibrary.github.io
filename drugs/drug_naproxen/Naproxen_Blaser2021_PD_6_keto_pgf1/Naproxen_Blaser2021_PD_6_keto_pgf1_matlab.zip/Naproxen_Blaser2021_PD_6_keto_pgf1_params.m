function p = Naproxen_Blaser2021_PD_6_keto_pgf1_params()
% Naproxen_Blaser2021_PD_6_keto_pgf1_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% naproxen Blaser_2021::6_keto_PGF1: sigmoid_emax exposure-response sweep (response = E0 + Emax*frac). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one µM per second, in SI inside (kg/m3, s). Response 6-keto-PGF1α in pg/mg creatinine. Driver: naproxen (cited_pk).
p.E0 = 167.16;
p.Emax = -133.56;
p.EC50 = 0.034;
p.gamma = 7.2;
p.slope = 0.0;
p.exposure_per_s = 1.0;
p.stop_time = 0.34;
p.form = 'E0 + Emax*frac';
end
