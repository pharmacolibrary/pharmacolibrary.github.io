function p = Naproxen_Huntjens2006_PD_pge2_params()
% Naproxen_Huntjens2006_PD_pge2_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% naproxen Huntjens_2006::PGE2: sigmoid_emax exposure-response sweep (response = E0 + Emax*frac). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one ng ml-1 per second, in SI inside (kg/m3, s). Response PGE2 in ng ml-1. Driver: naproxen (pk_record).
p.E0 = 6.59e-05;
p.Emax = -2.68e-06;
p.EC50 = 0.002951;
p.gamma = 1.02;
p.slope = 0.0;
p.exposure_per_s = 1e-06;
p.stop_time = 30000.0;
p.form = 'E0 + Emax*frac';
end
