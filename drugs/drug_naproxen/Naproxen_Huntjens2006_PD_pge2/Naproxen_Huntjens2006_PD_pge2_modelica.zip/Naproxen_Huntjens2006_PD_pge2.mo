model Naproxen_Huntjens2006_PD_pge2
  "sigmoid_emax exposure-response sweep — Huntjens_2006 :: PGE2 (PGE2 inhibition (in vivo rat))"
  extends Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep(
    E0 = 6.59e-05,      // [kg/m3; ng ml-1 × 1e-06]
    Emax = -2.68e-06,  // [kg/m3; ng ml-1 × 1e-06]
    EC50 = 0.002951,  // [kg/m3; ng ml-1 × 1e-06]
    gamma = 1.02,
    exposure_per_s = 1e-06);   // 1 ng ml-1 per second
  // imax_as_negative_emax: Imax (Q323) enters SigmoidEmaxSweep as −Emax
  annotation(experiment(StartTime = 0, StopTime = 30000, Interval = 60),
    Documentation(info = "<html><body><!-- drug-about --><h4>About naproxen</h4><p>Naproxen is a non-steroidal anti-inflammatory drug used to treat pain, inflammation, and conditions such as osteoarthritis, rheumatoid arthritis, ankylosing spondylitis, gout, and migraine. It is widely used and available in many forms, including oral and topical preparations, and is also approved for veterinary use.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q1215575\">Wikidata Q1215575</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h4>Naproxen_Huntjens2006_PD_pge2</h4><p>The steady-state exposure-response curve of Huntjens DR et al., <i>British journal of pharmacology 148(4):396–404</i> 2006 (<a href=\"https://doi.org/10.1038/sj.bjp.0706737\">doi:10.1038/sj.bjp.0706737</a>) — PGE2 inhibition (in vivo rat) [ng ml-1] against naproxen ng ml-1 — obtained by sweeping the driver instead of simulating a dose. Model family: sigmoid_emax.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    =       65.9 ng ml-1  drug-free response (baseline) (I0, Q324)
  Emax  =       2.68 ng ml-1  maximal effect term (Imax y Intercept, Q323)
  EC50  =       2951 ng ml-1  exposure at half of the maximal effect term (IC50, Q322)
  gamma =       1.02          Hill coefficient (Hill coefficient, Q325)</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep\">SigmoidEmaxSweep</a>; this model only supplies the numbers. The x axis is one ng ml-1 of naproxen per second of simulated time (exposure is in kg/m3): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 6.59e-05   (drug-free)
  exposure = EC50 (2951 ng ml-1)  response 6.456e-05
  exposure -> infinity  response 6.322e-05</pre></body></html>"));
end Naproxen_Huntjens2006_PD_pge2;
