function p = Naproxen_Huntjens2006_PD_pge2_2_params()
% Naproxen_Huntjens2006_PD_pge2_2_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% naproxen Huntjens_2006::PGE2::2: sigmoid_emax exposure-response sweep (response = E0 + Emax*frac). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one mM per second, in SI inside (kg/m3, s). Response PGE2 in ng ml-1. Driver: naproxen (pk_record).
p.E0 = 2.67e-05;
p.Emax = -3.5e-07;
p.EC50 = 30.7;
p.gamma = 0.95;
p.slope = 0.0;
p.exposure_per_s = 1.0;
p.stop_time = 310.0;
p.form = 'E0 + Emax*frac';
end
