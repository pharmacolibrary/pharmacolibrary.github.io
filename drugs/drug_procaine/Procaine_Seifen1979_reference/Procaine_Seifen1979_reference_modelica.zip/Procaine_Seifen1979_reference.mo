model Procaine_Seifen1979_reference
  parameter Real Cl_ref = 9.333333333333334e-05 "Cl [m3/s]";
  parameter Real Vd_ref = 0.0357 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.2363101,
    adminMass = 1e-05
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About procaine</h4><p>Procaine is a local anesthetic used to relieve pain, for example in procedures involving the skin, eye, or hemorrhoids. It is an approved drug, also approved for veterinary use, and remains in use mainly as a local anesthetic.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q423741\">Wikidata Q423741</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>procaine</td></tr><tr><td>population:</td><td>women undergoing hysterectomy</td></tr><tr><td>source_paper:</td><td>Seifen_1979</td></tr><tr><td>measured_compound:</td><td>procaine</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>procaine 236.31 g/mol (drugbank)</td></tr></table><h4>Interpretation flags</h4><ul><li>dropped unlinked row (NIL): 'fraction of drug in the central compartment' — extend the ontology if this is a real PK parameter (source ['Seifen_1979:abstract', 'Seifen_1979:abstract'])</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=procaine</li><li>structure disagreement: deterministic 1C vs LLM 2C — review compartment count</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li><li>gap-filled Q61 (V) from Olivarez_2022's review values (primary lacked it)</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Procaine_Seifen1979_reference;
