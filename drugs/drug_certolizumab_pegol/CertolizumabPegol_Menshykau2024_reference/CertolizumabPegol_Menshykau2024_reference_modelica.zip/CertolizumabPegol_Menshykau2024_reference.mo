model CertolizumabPegol_Menshykau2024_reference
  parameter Real Cl_ref = 4.814814814814815e-09 "Cl [m3/s]";
  parameter Real Vd_ref = 0.00786 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    adminMass = 0.0002,
    ka = 2.731481481481481e-06,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About certolizumab_pegol</h4><p>Certolizumab pegol is a TNF-alpha inhibitor used to treat inflammatory conditions such as rheumatoid arthritis, Crohn's disease, and ankylosing spondylitis. It is an approved medicine, authorised in the European Union, and is also being investigated for further uses.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q412909\">Wikidata Q412909</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>certolizumab_pegol</td></tr><tr><td>population:</td><td>pregnant women with chronic inflammatory diseases</td></tr><tr><td>source_paper:</td><td>Menshykau_2024</td></tr><tr><td>measured_compound:</td><td>certolizumab_pegol</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>psp413220-tbl-0001</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr></table><p><b>Defaulted (base-class default used):</b> Tlag.</p><h4>Interpretation flags</h4><ul><li>dropped duplicate Q319 ('V‐WT', value '0.552') — already have one for this compound</li><li>dropped unlinked row (NIL): 'CL/F trimester 3 proportionality factor' — extend the ontology if this is a real PK parameter (source ['psp413220-tbl-0001:row6:col1', 'psp413220-tbl-0001:row6:col2'])</li><li>dropped unlinked row (NIL): 'CL/F trimester 2 proportionality factor' — extend the ontology if this is a real PK parameter (source ['psp413220-tbl-0001:row7:col1', 'psp413220-tbl-0001:row7:col2'])</li><li>dropped unlinked row (NIL): 'CL/F trimester 1 proportionality factor' — extend the ontology if this is a real PK parameter (source ['psp413220-tbl-0001:row8:col1', 'psp413220-tbl-0001:row8:col2'])</li><li>dropped unlinked row (NIL): 'ADA Titer CL proportional' — extend the ontology if this is a real PK parameter (source ['psp413220-tbl-0001:row9:col1', 'psp413220-tbl-0001:row9:col2'])</li><li>implicit units: 'ka (1/day)' → 1/day (from the paper text: &quot;The abstract explicitly states 'K a = 0.236 1/day' and the introduction mentions 'first-order absorption rate constant, &quot;)</li><li>apparent-ness (ontology-grounded): parameterization=apparent, measured_compound=certolizumab_pegol</li><li>molar mass: none found for 'certolizumab_pegol' — its concentrations stay mass-only</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of TLAG: primary's parameterization (rate-constant / ka-only) does not use it</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 7257600, Tolerance = 1e-9, Interval = 1));
end CertolizumabPegol_Menshykau2024_reference;
