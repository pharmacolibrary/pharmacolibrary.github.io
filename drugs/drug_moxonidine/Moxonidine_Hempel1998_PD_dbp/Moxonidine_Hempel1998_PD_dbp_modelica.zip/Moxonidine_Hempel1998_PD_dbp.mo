model Moxonidine_Hempel1998_PD_dbp
  "emax exposure-response sweep — Hempel_1998 :: DBP (diastolic blood pressure)"
  extends Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep(
    E0 = 0,      // [1]
    Emax = -0.167,  // [1; % × 0.01]
    EC50 = 9.45e-07,  // [kg/m3; microgram/L × 1e-06]
    gamma = 1,
    exposure_per_s = 1e-06);   // 1 microgram/L per second
  // family_inferred: the record's model family is effect_compartment; read from the parameters: Emax/Imax and EC50/IC50 without a Hill coefficient — Emax
  // imax_as_negative_emax: Imax (Q323) enters SigmoidEmaxSweep as −Emax
  // defaulted: E0
  // defaulted: gamma
  annotation(experiment(StartTime = 0, StopTime = 9.5, Interval = 0.019),
    Documentation(info = "<html><body><!-- drug-about --><h4>About moxonidine</h4><p>Moxonidine is an antihypertensive drug used to treat high blood pressure. It is an approved medicine, used mainly in Europe, and is also available in combination with a diuretic.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q419944\">Wikidata Q419944</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h4>Moxonidine_Hempel1998_PD_dbp</h4><p>The steady-state exposure-response curve of Hempel G et al., <i>Clinical pharmacology and therapeutics 64(6):622–635</i> 1998 (<a href=\"https://doi.org/10.1016/S0009-9236(98)90053-4\">doi:10.1016/S0009-9236(98)90053-4</a>) — diastolic blood pressure against moxonidine microgram/L — obtained by sweeping the driver instead of simulating a dose. Model family: emax.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = (library default) drug-free response (baseline)
  Emax  =       16.7 %        maximal effect term (Emax, Q323)
  EC50  =      0.945 microgram/L exposure at half of the maximal effect term (EC50, Q321)
  gamma = (library default) Hill coefficient</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep\">SigmoidEmaxSweep</a>; this model only supplies the numbers. The x axis is one microgram/L of moxonidine per second of simulated time (exposure is in kg/m3): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0   (drug-free)
  exposure = EC50 (0.945 microgram/L)  response -0.0835
  exposure -> infinity  response -0.167</pre></body></html>"));
end Moxonidine_Hempel1998_PD_dbp;
