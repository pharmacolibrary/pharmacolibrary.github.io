function p = Moxonidine_Hempel1998_PD_dbp_params()
% Moxonidine_Hempel1998_PD_dbp_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% moxonidine Hempel_1998::DBP: emax exposure-response sweep (response = E0 + Emax*frac). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one microgram/L per second, in SI inside (kg/m3, s). Response DBP in its own unit. Driver: moxonidine (pk_record).
p.E0 = 0.0;
p.Emax = -0.167;
p.EC50 = 9.449999999999997e-07;
p.gamma = 1.0;
p.slope = 0.0;
p.exposure_per_s = 1e-06;
p.stop_time = 9.5;
p.form = 'E0 + Emax*frac';
end
