function p = Moxonidine_Bohmann1994_PD_s_i_outflow_params()
% Moxonidine_Bohmann1994_PD_s_i_outflow_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% moxonidine Bohmann_1994::S_I_outflow: sigmoid_emax exposure-response sweep (response = E0 + Emax*frac). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one nmol/l per second, in SI inside (kg/m3, s). Response S-I outflow in its own unit. Driver: moxonidine (cited_pk).
p.E0 = 0.0;
p.Emax = -0.97;
p.EC50 = 6.25e-05;
p.gamma = 1.0;
p.slope = 0.0;
p.exposure_per_s = 1e-06;
p.stop_time = 630.0;
p.form = 'E0 + Emax*frac';
end
