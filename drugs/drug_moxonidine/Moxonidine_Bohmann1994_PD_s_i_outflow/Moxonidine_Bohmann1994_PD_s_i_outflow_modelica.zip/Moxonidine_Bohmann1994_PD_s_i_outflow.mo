model Moxonidine_Bohmann1994_PD_s_i_outflow
  "sigmoid_emax exposure-response sweep — Bohmann_1994 :: S-I outflow (stimulation induced (S-I) outflow of radioactivity)"
  extends Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep(
    E0 = 0,      // [1]
    Emax = -0.97,  // [1; % × 0.01]
    EC50 = 6.25e-05,  // [mol/m3; nmol/l × 1e-06]
    gamma = 1,
    exposure_per_s = 1e-06);   // 1 nmol/l per second
  // imax_as_negative_emax: Imax (Q323) enters SigmoidEmaxSweep as −Emax
  // defaulted: E0
  // defaulted: gamma
  annotation(experiment(StartTime = 0, StopTime = 630, Interval = 1.26),
    Documentation(info = "<html><body><!-- drug-about --><h4>About moxonidine</h4><p>Moxonidine is an antihypertensive drug used to treat high blood pressure. It is an approved medicine, used mainly in Europe, and is also available in combination with a diuretic.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q419944\">Wikidata Q419944</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h4>Moxonidine_Bohmann1994_PD_s_i_outflow</h4><p>The steady-state exposure-response curve of Bohmann C et al., <i>Naunyn-Schmiedeberg's archives of pharmacology 349(2):118–124</i> 1994 (<a href=\"https://doi.org/10.1007/BF00169827\">doi:10.1007/BF00169827</a>) — stimulation induced (S-I) outflow of radioactivity against moxonidine nmol/l — obtained by sweeping the driver instead of simulating a dose. Model family: sigmoid_emax.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = (library default) drug-free response (baseline)
  Emax  =         97 %        maximal effect term (maximum, Q323)
  EC50  =       62.5 nmol/l   exposure at half of the maximal effect term (EC50, Q321)
  gamma = (library default) Hill coefficient</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep\">SigmoidEmaxSweep</a>; this model only supplies the numbers. The x axis is one nmol/l of moxonidine per second of simulated time (exposure is in mol/m3): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0   (drug-free)
  exposure = EC50 (62.5 nmol/l)  response -0.485
  exposure -> infinity  response -0.97</pre></body></html>"));
end Moxonidine_Bohmann1994_PD_s_i_outflow;
