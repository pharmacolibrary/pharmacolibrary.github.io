function p = Moxonidine_Trocniz2000_PD_dbp_params()
% Moxonidine_Trocniz2000_PD_dbp_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% moxonidine Trocóniz_2000::DBP: emax exposure-response sweep (response = E0 + Emax*frac). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one microg/L per second, in SI inside (kg/m3, s). Response DBP in mm Hg. Driver: moxonidine (cited_pk).
p.E0 = 0.0;
p.Emax = -30.9;
p.EC50 = 1.3299999999999998e-06;
p.gamma = 1.0;
p.slope = 0.0;
p.exposure_per_s = 1e-06;
p.stop_time = 14.0;
p.form = 'E0 + Emax*frac';
end
