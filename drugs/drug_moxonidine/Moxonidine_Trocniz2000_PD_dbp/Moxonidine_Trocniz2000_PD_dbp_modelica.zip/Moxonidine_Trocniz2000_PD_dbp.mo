model Moxonidine_Trocniz2000_PD_dbp
  "emax exposure-response sweep — Trocóniz_2000 :: DBP (24-hour ambulatory diastolic blood pressure)"
  extends Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep(
    E0 = 0,      // [1]
    Emax = -30.9,  // [mm Hg]
    EC50 = 1.33e-06,  // [kg/m3; microg/L × 1e-06]
    gamma = 1,
    exposure_per_s = 1e-06);   // 1 microg/L per second
  // family_inferred: the record's model family is effect_compartment; read from the parameters: Emax/Imax and EC50/IC50 without a Hill coefficient — Emax
  // imax_as_negative_emax: Imax (Q323) enters SigmoidEmaxSweep as −Emax
  // defaulted: E0
  // defaulted: gamma
  annotation(experiment(StartTime = 0, StopTime = 14, Interval = 0.028),
    Documentation(info = "<html><body><!-- drug-about --><h4>About moxonidine</h4><p>Moxonidine is an antihypertensive drug used to treat high blood pressure. It is an approved medicine, used mainly in Europe, and is also available in combination with a diuretic.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q419944\">Wikidata Q419944</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h4>Moxonidine_Trocniz2000_PD_dbp</h4><p>The steady-state exposure-response curve of Trocóniz IF et al., <i>Clinical pharmacology and therapeutics 68(1):18–27</i> 2000 (<a href=\"https://doi.org/10.1067/mcp.2000.106907\">doi:10.1067/mcp.2000.106907</a>) — 24-hour ambulatory diastolic blood pressure [mm Hg] against moxonidine microg/L — obtained by sweeping the driver instead of simulating a dose. Model family: emax.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = (library default) drug-free response (baseline)
  Emax  =       30.9 mm Hg    maximal effect term (Emax, Q323)
  EC50  =       1.33 microg/L exposure at half of the maximal effect term (C50, Q321)
  gamma = (library default) Hill coefficient</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep\">SigmoidEmaxSweep</a>; this model only supplies the numbers. The x axis is one microg/L of moxonidine per second of simulated time (exposure is in kg/m3): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0   (drug-free)
  exposure = EC50 (1.33 microg/L)  response -15.45
  exposure -> infinity  response -30.9</pre></body></html>"));
end Moxonidine_Trocniz2000_PD_dbp;
