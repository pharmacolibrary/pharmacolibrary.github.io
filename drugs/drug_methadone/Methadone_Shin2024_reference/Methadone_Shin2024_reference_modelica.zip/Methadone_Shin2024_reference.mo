model Methadone_Shin2024_reference
  parameter Real Cl_ref = 2.191666666666667e-05 "Cl [m3/s]";
  parameter Real Vd_ref = 0.686 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.3094452,
    adminMass = 2.5e-05
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About methadone</h4><p>Methadone is an opioid used to treat opiate dependence and is also used for pain relief. It is an approved medicine, listed as a WHO essential medicine, and is widely used, though it carries a boxed warning.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q179996\">Wikidata Q179996</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>methadone</td></tr><tr><td>population:</td><td>healthy adult ferrets</td></tr><tr><td>source_paper:</td><td>Shin_2024</td></tr><tr><td>measured_compound:</td><td>methadone</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>methadone 309.445 g/mol (drugbank)</td></tr></table><h4>Interpretation flags</h4><ul><li>unit_dimension_unknown: 'mL min-1 kg-1' (CL)</li><li>implicit units: 'systemic clearance (Clss)' → L/h (from the popPK convention: 'No unit stated in text or table footnotes. Systemic (total) clearance in population PK is conventionally expressed in L/')</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=methadone</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Methadone_Shin2024_reference;
