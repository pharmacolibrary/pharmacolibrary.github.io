// general-linear (2 compartments) — non-mammillary/4C+; central↔peripheral
// edges with clearance Qj; topology flagged for reviewer confirmation.
model Methadone_Ward2014_reference
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_General_Linear(
    nComp = 2, centralIdx = 1, F = 1,
    V = {1.5050000000000001, 5.257},
    CLelim = {0.00018375, 0.0},
    nEdge = 2,
    edge = {{1, 2}, {2, 1}},
    CLedge = {0.006319444444444445, 0.006319444444444445}
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About methadone</h4><p>Methadone is an opioid used to treat opiate dependence and is also used for pain relief. It is an approved medicine, listed as a WHO essential medicine, and is widely used, though it carries a boxed warning.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q179996\">Wikidata Q179996</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>methadone</td></tr><tr><td>population:</td><td>neonates, infants, and children</td></tr><tr><td>source_paper:</td><td>Ward_2014</td></tr><tr><td>measured_compound:</td><td>methadone</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>general_linear</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>molar_masses:</td><td>EDDP 277.411 g/mol (pubchem); EMDP 263.384 g/mol (pubchem); methadone 309.445 g/mol (drugbank)</td></tr></table><h4>Interpretation flags</h4><ul><li>covariate category for kcomp from footnote/prose kept as documentation only (['Ward_2014:abstract'])</li><li>dropped unlinked row (NIL): 'regimen in neonates' — extend the ontology if this is a real PK parameter (source ['Ward_2014:abstract'])</li><li>dropped PD-category row 'target concentration' → Q321 (EC50, category G11) — pharmacodynamic parameters belong to scholarpd, not the PK model (source ['Ward_2014:abstract'])</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=methadone</li><li>topology: 2 first-order transfer(s) across 5 compounds → general_linear</li><li>template fit: none — a metabolite is formed from another metabolite (a chain)</li><li>row roles (LLM): model_class=compartmental; 12/12 row label(s) assigned, 9 linked by role; re-tagged methadone→parent ×6, methadone→EDDP ×2, methadone→EMDP ×1</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Methadone_Ward2014_reference;
