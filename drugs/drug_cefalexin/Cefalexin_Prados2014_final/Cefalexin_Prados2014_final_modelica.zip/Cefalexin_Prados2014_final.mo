model Cefalexin_Prados2014_final
  parameter Real Cl_ref = 3.7352777777777776e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.039549999999999995 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.347389,
    adminMass = 0.00175,
    ka = 0.0003861111111111111,
    Tlag = 514.8
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About cefalexin</h4><p>Cefalexin is a first-generation cephalosporin antibiotic used to treat bacterial infections such as urinary tract infections, skin infections like cellulitis, pharyngitis, respiratory infections, and pneumonia. It is widely used in human medicine and is also approved for veterinary use, and it appears on the WHO list of essential medicines.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q411417\">Wikidata Q411417</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>cefalexin</td></tr><tr><td>population:</td><td>adult and aged dogs</td></tr><tr><td>source_paper:</td><td>Prados_2014</td></tr><tr><td>measured_compound:</td><td>cephalexin</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>tab3</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>cefalexin 347.389 g/mol (pubchem); cephalexin 347.389 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>table section residual_error: 'Proportional (%)' routed out of structural estimates ('Residual variability')</li><li>table section residual_error: 'Additive (mg/L)' routed out of structural estimates ('Residual variability')</li><li>NIL: refused to back-fill base 'kel' from footnote/prose loose number None (source ['tab3:footnote']); the table cell was unparseable — needs review</li><li>apparent-ness (ontology-grounded): parameterization=apparent, measured_compound=cephalexin</li><li>model-stage split: 'final model mean estimatea (s.e)' is the final model of Prados_2014 (paper reports 2 stages: base model mean estimate (s.e), final model mean estimatea (s.e)); same population, different model-building step</li><li>skipped review gap-fill of CL: primary's parameterization (rate-constant / ka-only) does not use it</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary's parameterization (rate-constant / ka-only) does not use it</li><li>derived CL/F=13.447 L/h from Ke × V/F = CL/F (Q47 × Q76); not separately reported</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Cefalexin_Prados2014_final;
