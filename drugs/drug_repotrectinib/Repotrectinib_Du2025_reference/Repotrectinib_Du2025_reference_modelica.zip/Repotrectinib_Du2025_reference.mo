model Repotrectinib_Du2025_reference
  parameter Real Cl_ref = 1.972222222222222e-06 "Cl [m3/s]";
  parameter Real cov_body_weight_0 = 0 "body weight covariate";
  parameter Real cov_age_1 = 0 "age covariate";
  parameter Real Vd_ref = 0.0198 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref*(1 + (0.477)*cov_body_weight_0)*(1 + (-0.292)*cov_age_1),
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.355373,
    adminMass = 1e-05,
    k12 = 6.986531986531987e-05,
    k21 = 6.259426847662143e-06
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About repotrectinib</h4><p>Repotrectinib is a protein kinase inhibitor used to treat non-small-cell lung cancer. It is an approved medicine and is authorised in the European Union.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q123499554\">Wikidata Q123499554</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>repotrectinib</td></tr><tr><td>population:</td><td>healthy volunteers and patients with advanced solid tumors harboring ALK, ROS1, or NTRK1-3 rearrangements</td></tr><tr><td>source_paper:</td><td>Du_2025</td></tr><tr><td>measured_compound:</td><td>repotrectinib</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>psp470036-tbl-0002</td></tr><tr><td>input:</td><td>PK_2C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>repotrectinib 355.373 g/mol (drugbank)</td></tr></table><h4>Interpretation flags</h4><ul><li>table section iiv: 'ω 2 CLH; IIV on CL for healthy volunteers' routed out of structural estimates ('Interindividual variability (IIV)')</li><li>table section iiv: 'ω 2 CLH; IIV on CL for healthy volunteers' routed out of structural estimates ('Interindividual variability (IIV)')</li><li>table section iiv: 'ω 2 CLH; IIV on CL for healthy volunteers' routed out of structural estimates ('Interindividual variability (IIV)')</li><li>table section iiv: 'ω 2 CLH; IIV on CL for healthy volunteers' routed out of structural estimates ('Interindividual variability (IIV)')</li><li>table section iiv: 'ω 2 VC; IIV on VC' routed out of structural estimates ('Interindividual variability (IIV)')</li><li>table section iiv: 'ω 2 VC; IIV on VC' routed out of structural estimates ('Interindividual variability (IIV)')</li><li>table section iiv: 'ω 2 VC; IIV on VC' routed out of structural estimates ('Interindividual variability (IIV)')</li><li>table section iiv: 'ω 2 VC; IIV on VC' routed out of structural estimates ('Interindividual variability (IIV)')</li><li>table section iiv: 'ω 2 Q; IIV on Q' routed out of structural estimates ('Interindividual variability (IIV)')</li><li>table section iiv: 'ω 2 Q; IIV on Q' routed out of structural estimates ('Interindividual variability (IIV)')</li><li>table section iiv: 'ω 2 Q; IIV on Q' routed out of structural estimates ('Interindividual variability (IIV)')</li><li>table section iiv: 'ω 2 Q; IIV on Q' routed out of structural estimates ('Interindividual variability (IIV)')</li><li>table section iiv: 'ω 2 KA; IIV on KA' routed out of structural estimates ('Interindividual variability (IIV)')</li><li>table section iiv: 'ω 2 KA; IIV on KA' routed out of structural estimates ('Interindividual variability (IIV)')</li><li>table section iiv: 'ω 2 KA; IIV on KA' routed out of structural estimates ('Interindividual variability (IIV)')</li><li>table section iiv: 'ω 2 KA; IIV on KA' routed out of structural estimates ('Interindividual variability (IIV)')</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Repotrectinib_Du2025_reference;
