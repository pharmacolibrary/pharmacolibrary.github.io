function p = Omadacycline_Singh2024_PD_cfu_ml_params()
% Omadacycline_Singh2024_PD_cfu_ml_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% omadacycline Singh_2024::CFU_mL: sigmoid_emax exposure-response sweep (response = E0 + Emax*frac). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one AUC0-24/MIC ratio per second, in SI inside (kg/m3, s). Response CFU/mL in log10 CFU/mL. Driver: omadacycline (cited_pk).
p.E0 = 0.0;
p.Emax = -4.64;
p.EC50 = 22.86;
p.gamma = 1.0;
p.slope = 0.0;
p.exposure_per_s = 1.0;
p.stop_time = 230.0;
p.form = 'E0 + Emax*frac';
end
