model Omadacycline_Singh2024_PD_cfu_ml
  "sigmoid_emax exposure-response sweep — Singh_2024 :: CFU/mL (Mycobacterium tuberculosis bacterial load)"
  extends Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep(
    E0 = 0,      // [1]
    Emax = -4.64,  // [log10 CFU/mL]
    EC50 = 22.86,  // [AUC0-24/MIC ratio]
    gamma = 1,
    exposure_per_s = 1);   // 1 AUC0-24/MIC ratio per second
  // imax_as_negative_emax: Imax (Q323) enters SigmoidEmaxSweep as −Emax
  // exposure_unit_unresolved: 'AUC0-24/MIC ratio' — the x axis is in the paper's unit, not SI
  // defaulted: E0
  // defaulted: gamma
  annotation(experiment(StartTime = 0, StopTime = 230, Interval = 0.46),
    Documentation(info = "<html><body><!-- drug-about --><h4>About omadacycline</h4><p>Omadacycline is a tetracycline-class antibacterial used to treat bacterial infections. It is an approved medicine, but it is not authorised in the European Union.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q15426992\">Wikidata Q15426992</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h4>Omadacycline_Singh2024_PD_cfu_ml</h4><p>The steady-state exposure-response curve of Singh S et al., <i>Antimicrobial agents and chemotherapy 68(2):e0108023</i> 2024 (<a href=\"https://doi.org/10.1128/aac.01080-23\">doi:10.1128/aac.01080-23</a>) — Mycobacterium tuberculosis bacterial load [log10 CFU/mL] against omadacycline AUC0-24/MIC ratio — obtained by sweeping the driver instead of simulating a dose. Model family: sigmoid_emax.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = (library default) drug-free response (baseline)
  Emax  =       4.64 log10 CFU/mL maximal effect term (Emax, Q323)
  EC50  =      22.86 AUC0-24/MIC ratio exposure at half of the maximal effect term (EC50, Q321)
  gamma = (library default) Hill coefficient</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep\">SigmoidEmaxSweep</a>; this model only supplies the numbers. The x axis is one AUC0-24/MIC ratio of omadacycline per second of simulated time: there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0   (drug-free)
  exposure = EC50 (22.86 AUC0-24/MIC ratio)  response -2.32
  exposure -> infinity  response -4.64</pre></body></html>"));
end Omadacycline_Singh2024_PD_cfu_ml;
