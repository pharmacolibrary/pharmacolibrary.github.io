model Omadacycline_Lakota2020_reference
  parameter Real Cl_ref = 2.861111111111111e-06 "Cl [m3/s]";
  parameter Boolean cov_food_0 = false "food level 0";
  parameter Boolean cov_food_1 = false "food level 1";
  parameter Real Vd_ref = 0.0211 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C_enteral(
    weight = 70.0,
    F = 0.9,
    Cl = Cl_ref + (4.666666666666666e-07)*(if cov_food_0 then 1 else 0) + (9.972222222222222e-07)*(if cov_food_1 then 1 else 0),
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.5566599999999999,
    adminMass = 0.0001,
    ka = 0.00048333333333333334,
    Tlag = 0.0,
    k12 = 0.0002804107424960505,
    k21 = 7.405089695452648e-05
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About omadacycline</h4><p>Omadacycline is a tetracycline-class antibacterial used to treat bacterial infections. It is an approved medicine, but it is not authorised in the European Union.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q15426992\">Wikidata Q15426992</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>omadacycline</td></tr><tr><td>population:</td><td>mixed</td></tr><tr><td>source_paper:</td><td>Lakota_2020</td></tr><tr><td>measured_compound:</td><td>omadacycline</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>T2</td></tr><tr><td>input:</td><td>PK_2C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>omadacycline 556.66 g/mol (drugbank)</td></tr></table><p><b>Defaulted (base-class default used):</b> F, Tlag.</p><h4>Interpretation flags</h4><ul><li>dropped unlinked row (NIL): 'Proportional change in females' — extend the ontology if this is a real PK parameter (source ['T2:row2:col1', 'T2:row2:col2', 'T2:row5:col1', 'T2:row5:col2', 'T2:row7:col1', 'T2:row7:col2', 'T2:row10:col1', 'T2:row10:col2'])</li><li>dropped duplicate Q22 ('CLd1 (liters/h)', value '101') — already have one for this compound</li><li>dropped unlinked row (NIL): 'F0' — extend the ontology if this is a real PK parameter (source ['T2:row12:col1', 'T2:row12:col2'])</li><li>dropped unlinked row (NIL): 'Fmax' — extend the ontology if this is a real PK parameter (source ['T2:row13:col1', 'T2:row13:col2'])</li><li>dropped unlinked row (NIL): 'AMTIME50 (h)' — extend the ontology if this is a real PK parameter (source ['T2:row15:col1', 'T2:row15:col2'])</li><li>covariate level 'Proportional increase for consuming food predose' → Q900:proportional_increase_for_consuming_food_predose = 1.68 (additive_shift on Q22)</li><li>covariate level 'Proportional increase for consuming food with dairy products predose' → Q900:proportional_increase_for_consuming_food_with_dairy_products_predose = 3.59 (additive_shift on Q22)</li><li>dropped unlinked row (NIL): 'γ' — extend the ontology if this is a real PK parameter (source ['T2:row18:col1', 'T2:row18:col2'])</li><li>dropped unlinked row (NIL): 'ELF FRACb' — extend the ontology if this is a real PK parameter (source ['T2:row19:col1', 'T2:row19:col2'])</li><li>covariate effect for Q31 has no base parameter row (kept as unattached equation-variable)</li><li>apparent-by-design (ADVISORY, codes unchanged): extravascular dosing with no identifiable F, so these reported disposition parameters are likely apparent unless the model puts first-pass in its structure — Q22 (CL (liters/h)); Q63 (Vc (liters)); Q64 (Vp1 (liters)); Q30 (CLd2 (liters/h))</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=omadacycline</li><li>structure disagreement: deterministic 2C vs LLM 3C — review compartment count</li><li>skipped review gap-fill of TLAG: primary's parameterization (rate-constant / ka-only) does not use it</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Omadacycline_Lakota2020_reference;
