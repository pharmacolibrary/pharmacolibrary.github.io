function p = Omadacycline_VanScoy2020_PD_change_in_the_log10_cfu_ml_from_params()
% Omadacycline_VanScoy2020_PD_change_in_the_log10_cfu_ml_from_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% omadacycline VanScoy_2020::change_in_the_log10_CFU_ml_from_baseline_at_24_h: sigmoid_emax exposure-response sweep (response = E0 + Emax*frac). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one mg · h/liter (total-drug ELF AUC/MIC ratio) per second, in SI inside (kg/m3, s). Response change in the log10 CFU/ml from baseline at 24 h in its own unit. Driver: omadacycline (cited_pk).
p.E0 = 2.8;
p.Emax = -8.81;
p.EC50 = 9.29;
p.gamma = 1.66;
p.slope = 0.0;
p.exposure_per_s = 1.0;
p.stop_time = 93.0;
p.form = 'E0 + Emax*frac';
end
