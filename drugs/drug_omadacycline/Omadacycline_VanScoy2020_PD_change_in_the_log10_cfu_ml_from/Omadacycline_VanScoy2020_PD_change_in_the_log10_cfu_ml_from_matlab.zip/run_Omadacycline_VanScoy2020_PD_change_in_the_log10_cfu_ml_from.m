% run_Omadacycline_VanScoy2020_PD_change_in_the_log10_cfu_ml_from  Evaluate the exposure-response curve and plot response against exposure.
% A sweep is a static map: no ODE solver is needed. exposure runs 0..stop_time*exposure_per_s.
p = Omadacycline_VanScoy2020_PD_change_in_the_log10_cfu_ml_from_params();
exposure = linspace(0, p.stop_time * p.exposure_per_s, 501);
frac = exposure.^p.gamma ./ (p.EC50^p.gamma + exposure.^p.gamma);
E0 = p.E0; Emax = p.Emax; slope = p.slope;
response = E0 + Emax.*frac;
figure; plot(exposure, response, 'LineWidth', 1.5); grid on;
xlabel('exposure [mg · h/liter (total-drug ELF AUC/MIC ratio)]'); ylabel('response []'); title('Omadacycline_VanScoy2020_PD_change_in_the_log10_cfu_ml_from', 'Interpreter', 'none');
writematrix([exposure(:) response(:)], 'Omadacycline_VanScoy2020_PD_change_in_the_log10_cfu_ml_from.csv');
