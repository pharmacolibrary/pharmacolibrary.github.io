model Omadacycline_VanScoy2020_PD_change_in_the_log10_cfu_ml_from
  "sigmoid_emax exposure-response sweep — VanScoy_2020 :: change in the log10 CFU/ml from baseline at 24 h (change in the log10 CFU/ml from baseline at 24 h)"
  extends Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep(
    E0 = 2.8,      // [1]
    Emax = -8.81,  // [1]
    EC50 = 9.29,  // [mg · h/liter (total-drug ELF AUC/MIC ratio)]
    gamma = 1.66,
    exposure_per_s = 1);   // 1 mg · h/liter (total-drug ELF AUC/MIC ratio) per second
  // imax_as_negative_emax: Imax (Q323) enters SigmoidEmaxSweep as −Emax
  // exposure_unit_unresolved: 'mg · h/liter (total-drug ELF AUC/MIC ratio)' — the x axis is in the paper's unit, not SI
  annotation(experiment(StartTime = 0, StopTime = 93, Interval = 0.186),
    Documentation(info = "<html><body><!-- drug-about --><h4>About omadacycline</h4><p>Omadacycline is a tetracycline-class antibacterial used to treat bacterial infections. It is an approved medicine, but it is not authorised in the European Union.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q15426992\">Wikidata Q15426992</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h4>Omadacycline_VanScoy2020_PD_change_in_the_log10_cfu_ml_from</h4><p>The steady-state exposure-response curve of VanScoy BD et al., <i>Antimicrobial agents and chemotherapy 64(6)</i> 2020 (<a href=\"https://doi.org/10.1128/AAC.02265-19\">doi:10.1128/AAC.02265-19</a>) — change in the log10 CFU/ml from baseline at 24 h against omadacycline mg · h/liter (total-drug ELF AUC/MIC ratio) — obtained by sweeping the driver instead of simulating a dose. Model family: sigmoid_emax.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    =        2.8          drug-free response (baseline) (E0, Q324)
  Emax  =       8.81          maximal effect term (Emax, Q323)
  EC50  =       9.29 mg · h/liter (total-drug ELF AUC/MIC ratio) exposure at half of the maximal effect term (EC50, Q321)
  gamma =       1.66          Hill coefficient (Hill coefficient, Q325)</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep\">SigmoidEmaxSweep</a>; this model only supplies the numbers. The x axis is one mg · h/liter (total-drug ELF AUC/MIC ratio) of omadacycline per second of simulated time: there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 2.8   (drug-free)
  exposure = EC50 (9.29 mg · h/liter (total-drug ELF AUC/MIC ratio))  response -1.605
  exposure -> infinity  response -6.01</pre></body></html>"));
end Omadacycline_VanScoy2020_PD_change_in_the_log10_cfu_ml_from;
