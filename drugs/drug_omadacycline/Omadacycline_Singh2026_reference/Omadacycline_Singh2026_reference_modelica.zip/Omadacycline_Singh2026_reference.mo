model Omadacycline_Singh2026_reference
  parameter Real Cl_ref = 8.333333333333334e-09 "Cl [m3/s]";
  parameter Real Vd_ref = 0.00058 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.5566599999999999,
    adminMass = 0.0001,
    k12 = 3.448275862068965e-06
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About omadacycline</h4><p>Omadacycline is a tetracycline-class antibacterial used to treat bacterial infections. It is an approved medicine, but it is not authorised in the European Union.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q15426992\">Wikidata Q15426992</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>omadacycline</td></tr><tr><td>population:</td><td>review reference</td></tr><tr><td>source_paper:</td><td>Singh_2026</td></tr><tr><td>measured_compound:</td><td>omadacycline</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_2C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>omadacycline 556.66 g/mol (drugbank)</td></tr></table><p><b>Defaulted (base-class default used):</b> k21.</p><h4>Interpretation flags</h4><ul><li>built from REVIEW reference values (Singh_2026) — secondary source</li><li>volume reported by review</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 259200, Tolerance = 1e-9, Interval = 1));
end Omadacycline_Singh2026_reference;
