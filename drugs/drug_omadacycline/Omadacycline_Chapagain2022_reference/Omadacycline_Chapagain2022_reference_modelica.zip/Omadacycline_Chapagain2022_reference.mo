model Omadacycline_Chapagain2022_reference
  parameter Real Cl_ref = 2.861111111111111e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.0211 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.5566599999999999,
    adminMass = 0.0003,
    k12 = 9.478672985781988e-08,
    k21 = 2.503128911138923e-08
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About omadacycline</h4><p>Omadacycline is a tetracycline-class antibacterial used to treat bacterial infections. It is an approved medicine, but it is not authorised in the European Union.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q15426992\">Wikidata Q15426992</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>omadacycline</td></tr><tr><td>population:</td><td>simulated healthy adults</td></tr><tr><td>source_paper:</td><td>Chapagain_2022</td></tr><tr><td>measured_compound:</td><td>omadacycline</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>dkac068-T4</td></tr><tr><td>input:</td><td>PK_2C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>omadacycline 556.66 g/mol (drugbank)</td></tr></table><h4>Interpretation flags</h4><ul><li>dropped duplicate Q22 ('Distributional clearance P1 (L/h)', value '101.0') — already have one for this compound</li><li>dropped duplicate Q22 ('Distributional clearance P2 (L/h)', value '21.3') — already have one for this compound</li><li>dropped duplicate Q64 ('Peripheral Volume 2 (L)', value '129.0') — already have one for this compound</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=omadacycline</li><li>gap-filled Q30 (Q) from Singh_2026's review values (primary lacked it)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Omadacycline_Chapagain2022_reference;
