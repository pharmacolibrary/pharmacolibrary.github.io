model Caspofungin_BorsukDe2020_reference
  parameter Real Cl_ref = 1.5638888888888887e-07 "Cl [m3/s]";
  parameter Real Vd_ref = 0.00604 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 1.0933309999999998,
    adminMass = 3.5e-05,
    k12 = 6.0246504782928624e-05,
    k21 = 7.093350660602123e-05
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About caspofungin</h4><p>Caspofungin is an antifungal used to treat candidiasis and aspergillosis. It is an approved, systemically used antifungal and is authorised in the European Union.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q420875\">Wikidata Q420875</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>caspofungin</td></tr><tr><td>population:</td><td>intensive care unit patients</td></tr><tr><td>source_paper:</td><td>Borsuk-De_2020</td></tr><tr><td>measured_compound:</td><td>caspofungin</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>T2</td></tr><tr><td>input:</td><td>PK_2C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>caspofungin 1093.33 g/mol (drugbank)</td></tr></table><h4>Interpretation flags</h4><ul><li>table section iiv: 'ω2CL (%CV)' routed out of structural estimates ('Interindividual variability')</li><li>table section iiv: 'ω2CL (%CV)' routed out of structural estimates ('Interindividual variability')</li><li>table section iiv: 'ω2V1 (%CV)' routed out of structural estimates ('Interindividual variability')</li><li>table section iiv: 'ω2V1 (%CV)' routed out of structural estimates ('Interindividual variability')</li><li>table section iiv: 'ω2Q (%CV)' routed out of structural estimates ('Interindividual variability')</li><li>table section iiv: 'ω2V2 (%CV)' routed out of structural estimates ('Interindividual variability')</li><li>table section iiv: 'ω2V2 (%CV)' routed out of structural estimates ('Interindividual variability')</li><li>table section iiv: 'corCL-V1' routed out of structural estimates ('Interindividual variability')</li><li>table section residual_error: 'σ2prop (%CV)' routed out of structural estimates ('Residual error model')</li><li>dropped duplicate Q22 ('θCL day 2 (liter/h)', value '0.737') — already have one for this compound</li><li>dropped duplicate Q22 ('θCL day 3 (liter/h)', value '1.01') — already have one for this compound</li><li>dropped duplicate Q63 ('θV1 day 2 (liter)', value '7.32') — already have one for this compound</li><li>dropped duplicate Q63 ('θV1 day 3 (liter)', value '7.70') — already have one for this compound</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=caspofungin</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 136800, Tolerance = 1e-9, Interval = 1));
end Caspofungin_BorsukDe2020_reference;
