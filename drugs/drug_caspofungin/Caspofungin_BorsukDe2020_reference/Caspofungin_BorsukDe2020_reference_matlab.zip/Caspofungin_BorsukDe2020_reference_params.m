function p = Caspofungin_BorsukDe2020_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: caspofungin   source: Borsuk-De_2020 / reference   route: iv_bolus
  % estimated (absent from source): F
  p.name  = 'Caspofungin_BorsukDe2020_reference_params';
  p.drug  = 'caspofungin';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'iv_bolus';        % 'oral' | 'iv_bolus'
  p.depot = false;             % oral -> first-order absorption depot
  p.Vc = 6.04;                % central volume [L]
  p.CL = 0.563;                % clearance [L/h]
  p.Vp = [5.13];             % peripheral volumes [L]
  p.Q  = [1.31];             % inter-compartmental clearances [L/h]
  p.ka = 0.0;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 35.0;             % dose [mg]
end
