model Caspofungin_AbdulAziz2025_reference
  parameter Real Cl_ref = 1.527777777777778e-07 "Cl [m3/s]";
  parameter Real Vd_ref = 0.008130000000000002 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 1.0933309999999998,
    adminMass = 5e-05
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About caspofungin</h4><p>Caspofungin is an antifungal used to treat candidiasis and aspergillosis. It is an approved, systemically used antifungal and is authorised in the European Union.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q420875\">Wikidata Q420875</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>caspofungin</td></tr><tr><td>population:</td><td>critically ill patients receiving ECMO</td></tr><tr><td>source_paper:</td><td>Abdul-Aziz_2025</td></tr><tr><td>measured_compound:</td><td>caspofungin</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>T2</td></tr><tr><td>input:</td><td>PK_1C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>caspofungin 1093.33 g/mol (drugbank)</td></tr></table><h4>Interpretation flags</h4><ul><li>table section iiv: 'CL (%)' routed out of structural estimates ('Between-subject variability')</li><li>table section iiv: 'V (%)' routed out of structural estimates ('Between-subject variability')</li><li>table section residual_error: 'Additive (mg/L)' routed out of structural estimates ('Residual error')</li><li>dropped duplicate Q61 ('LBW effect on V', value '1.24') — already have one for this compound</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=caspofungin</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 259200, Tolerance = 1e-9, Interval = 1));
end Caspofungin_AbdulAziz2025_reference;
