model Thalidomide_Kamikawa2006_reference
  parameter Real Cl_ref = 1.5388888888888888e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.0422 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.2582295,
    adminMass = 0.0001,
    ka = 0.00011111111111111112,
    Tlag = 2628.0
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About thalidomide</h4><p>Thalidomide is an immunomodulatory drug used for conditions such as multiple myeloma and leprosy, among several other immune and blood disorders. It remains authorised in the European Union for multiple myeloma, but its use is tightly controlled because it causes severe birth defects, and it was famously withdrawn from use as a sedative for this reason.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q203174\">Wikidata Q203174</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>thalidomide</td></tr><tr><td>population:</td><td>review reference</td></tr><tr><td>source_paper:</td><td>Kamikawa_2006</td></tr><tr><td>measured_compound:</td><td>thalidomide</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>thalidomide 258.229 g/mol (drugbank)</td></tr></table><h4>Interpretation flags</h4><ul><li>built from REVIEW reference values (Kamikawa_2006) — secondary source</li><li>volume reported by review</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 122400, Tolerance = 1e-9, Interval = 1));
end Thalidomide_Kamikawa2006_reference;
