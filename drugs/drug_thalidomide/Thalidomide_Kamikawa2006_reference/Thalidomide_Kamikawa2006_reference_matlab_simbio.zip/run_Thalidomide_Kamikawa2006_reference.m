% Run (SimBiology): build model + dose, simulate 0..34.0 h, plot.
p = Thalidomide_Kamikawa2006_reference_params();
[model, dose, variant] = build_sb_pk(p);
sd = simulate_sb(model, variant, dose, 34.0);
