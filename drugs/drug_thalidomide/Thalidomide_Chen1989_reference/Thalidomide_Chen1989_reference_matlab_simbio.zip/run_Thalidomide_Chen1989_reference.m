% Run (SimBiology): build model + dose, simulate 0..48.0 h, plot.
p = Thalidomide_Chen1989_reference_params();
[model, dose, variant] = build_sb_pk(p);
sd = simulate_sb(model, variant, dose, 48.0);
