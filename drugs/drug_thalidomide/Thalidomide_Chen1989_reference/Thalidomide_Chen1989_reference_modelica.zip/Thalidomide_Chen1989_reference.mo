model Thalidomide_Chen1989_reference
  parameter Real Cl_ref = 2.891666666666667e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.12069 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.2582295,
    adminMass = 0.0001,
    ka = 0.00011111111111111112,
    Tlag = 2628.0
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About thalidomide</h4><p>Thalidomide is an immunomodulatory drug used for conditions such as multiple myeloma and leprosy, among several other immune and blood disorders. It remains authorised in the European Union for multiple myeloma, but its use is tightly controlled because it causes severe birth defects, and it was famously withdrawn from use as a sedative for this reason.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q203174\">Wikidata Q203174</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>thalidomide</td></tr><tr><td>population:</td><td>healthy male volunteers</td></tr><tr><td>source_paper:</td><td>Chen_1989</td></tr><tr><td>measured_compound:</td><td>thalidomide</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>thalidomide 258.229 g/mol (drugbank)</td></tr></table><h4>Interpretation flags</h4><ul><li>unit_dimension_unknown: '% of the total dose administered over 24 hr' (fe)</li><li>apparent-ness (ontology-grounded): parameterization=apparent, measured_compound=thalidomide</li><li>held at status:extracted — NIL link or unit issue (mismatch/unknown/normalisation-failed) present</li><li>status held at route_to_review — not promoted</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li><li>gap-filled Q49 (kabs) from Kamikawa_2006's review values (primary lacked it)</li><li>gap-filled Q83 (tlag) from Kamikawa_2006's review values (primary lacked it)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 172800, Tolerance = 1e-9, Interval = 1));
end Thalidomide_Chen1989_reference;
