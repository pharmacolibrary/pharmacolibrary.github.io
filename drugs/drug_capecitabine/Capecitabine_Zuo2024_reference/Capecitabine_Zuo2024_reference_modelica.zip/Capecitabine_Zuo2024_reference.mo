model Capecitabine_Zuo2024_reference
  parameter Real Cl_ref = 1.5750000000000003e-05 "Cl [m3/s]";
  parameter Real Vd_ref = 0.674 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.3593501,
    adminMass = 0.0001,
    ka = 0.0001388888888888889,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About capecitabine</h4><p>Capecitabine is an antimetabolite cancer medicine used to treat various cancers, including breast, colorectal, gastric, and other gastrointestinal tumours. It is widely used and is included on the WHO essential medicines list, with several products authorised in the European Union for bowel, breast, and stomach cancers.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q420207\">Wikidata Q420207</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>capecitabine</td></tr><tr><td>population:</td><td>review reference</td></tr><tr><td>source_paper:</td><td>Zuo_2024</td></tr><tr><td>measured_compound:</td><td>capecitabine</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C_enteral: apparent (/F) parameterization ⇒ extravascular dosing</td></tr><tr><td>molar_masses:</td><td>capecitabine 359.35 g/mol (drugbank)</td></tr></table><p><b>Defaulted (base-class default used):</b> ka, Tlag.</p><h4>Interpretation flags</h4><ul><li>built from REVIEW reference values (Zuo_2024) — secondary source</li><li>volume reported by review</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 151200, Tolerance = 1e-9, Interval = 1));
end Capecitabine_Zuo2024_reference;
