model Capecitabine_Schmulenson2022_reference
  parameter Real Cl_ref = 2.6000000000000005e-07 "Cl [m3/s]";
  parameter Real Vd_ref = 0.010400000000000001 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.3593501,
    adminMass = 4e-05,
    ka = 0.0001388888888888889,
    Tlag = 0.0,
    k12 = 0.00036057692307692304,
    k21 = 5.868544600938968e-05
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About capecitabine</h4><p>Capecitabine is an antimetabolite cancer medicine used to treat various cancers, including breast, colorectal, gastric, and other gastrointestinal tumours. It is widely used and is included on the WHO essential medicines list, with several products authorised in the European Union for bowel, breast, and stomach cancers.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q420207\">Wikidata Q420207</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>capecitabine</td></tr><tr><td>population:</td><td>locally advanced rectal cancer</td></tr><tr><td>source_paper:</td><td>Schmulenson_2022</td></tr><tr><td>measured_compound:</td><td>capecitabine</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>table 2</td></tr><tr><td>input:</td><td>PK_2C_enteral: apparent (/F) parameterization ⇒ extravascular dosing</td></tr><tr><td>molar_masses:</td><td>capecitabine 359.35 g/mol (drugbank)</td></tr></table><p><b>Defaulted (base-class default used):</b> ka, Tlag.</p><h4>Interpretation flags</h4><ul><li>the dosed compound is capecitabine; the compartment is capecitabine. Input enters at the reported formation rate, so formation is already accounted for in the input step and the simulated concentration is capecitabine, not capecitabine</li><li>apparent parameters (CLm/F, Vm/F) already contain F and the metabolised fraction, so F=1 and no molar correction is applied — adding either would double-count it</li><li>capecitabine's own concentration-time course is not produced by this model</li><li>table section iiv: 'CLRegorafenib/F [%]' routed out of structural estimates ('Interindividual variability')</li><li>table section iiv: 'CLRegorafenib/F [%]' routed out of structural estimates ('Interindividual variability')</li><li>table section iiv: 'Vp/F [%]' routed out of structural estimates ('Interindividual variability')</li><li>table section iiv: 'Vp/F [%]' routed out of structural estimates ('Interindividual variability')</li><li>table section iiv: 'MAT (Regorafenib) [%]' routed out of structural estimates ('Interindividual variability')</li><li>table section iiv: 'MAT (Regorafenib) [%]' routed out of structural estimates ('Interindividual variability')</li><li>table section iiv: 'CLM-2/F [%]' routed out of structural estimates ('Interindividual variability')</li><li>table section iiv: 'CLM-2/F [%]' routed out of structural estimates ('Interindividual variability')</li><li>table section iiv: 'CLM-5/F [%]' routed out of structural estimates ('Interindividual variability')</li><li>table section iiv: 'CLM-5/F [%]' routed out of structural estimates ('Interindividual variability')</li><li>table section residual_error: 'Regorafenib [%]' routed out of structural estimates ('Residual variability')</li><li>table section residual_error: 'Regorafenib [%]' routed out of structural estimates ('Residual variability')</li><li>table section residual_error: 'M-2 [%]' routed out of structural estimates ('Residual variability')</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 140400, Tolerance = 1e-9, Interval = 1));
end Capecitabine_Schmulenson2022_reference;
