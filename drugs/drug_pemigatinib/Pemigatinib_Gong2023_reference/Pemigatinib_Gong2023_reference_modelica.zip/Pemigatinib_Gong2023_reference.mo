model Pemigatinib_Gong2023_reference
  parameter Real Cl_ref = 7.5e-07 "Cl [m3/s]";
  parameter Real cov_sex_0 = 0 "sex covariate";
  parameter Real Vd_ref = 0.0034 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref*(1 + (18.5)*cov_sex_0),
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.487508,
    adminMass = 6e-06,
    ka = 0.0033888888888888888,
    Tlag = 0.0,
    k12 = 0.0006290849673202615,
    k21 = 0.000712962962962963
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About pemigatinib</h4><p>Pemigatinib is a protein kinase inhibitor used to treat cholangiocarcinoma. It is an approved cancer medicine and is authorised in the European Union.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q96398739\">Wikidata Q96398739</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>pemigatinib</td></tr><tr><td>population:</td><td>healthy participants and patients with CCA, other solid tumors, or MLN FGFR1</td></tr><tr><td>source_paper:</td><td>Gong_2023</td></tr><tr><td>measured_compound:</td><td>pemigatinib</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>psp413064-tbl-0002</td></tr><tr><td>input:</td><td>PK_2C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>pemigatinib 487.508 g/mol (drugbank)</td></tr></table><p><b>Defaulted (base-class default used):</b> Tlag.</p><h4>Interpretation flags</h4><ul><li>table section iiv: 'CL/F, L/h' routed out of structural estimates ('Magnitude of interindividual variability (%CV)')</li><li>table section iiv: 'CL/F, L/h' routed out of structural estimates ('Magnitude of interindividual variability (%CV)')</li><li>table section iiv: 'CL/F, L/h' routed out of structural estimates ('Magnitude of interindividual variability (%CV)')</li><li>table section iiv: 'V c/F, L' routed out of structural estimates ('Magnitude of interindividual variability (%CV)')</li><li>table section iiv: 'V c/F, L' routed out of structural estimates ('Magnitude of interindividual variability (%CV)')</li><li>table section iiv: 'V c/F, L' routed out of structural estimates ('Magnitude of interindividual variability (%CV)')</li><li>table section iiv: 'CL/F_V c/F a correlation coefficient, CV' routed out of structural estimates ('Magnitude of interindividual variability (%CV)')</li><li>table section iiv: 'CL/F_V c/F a correlation coefficient, CV' routed out of structural estimates ('Magnitude of interindividual variability (%CV)')</li><li>table section iiv: 'K a, 1/h' routed out of structural estimates ('Magnitude of interindividual variability (%CV)')</li><li>table section iiv: 'K a, 1/h' routed out of structural estimates ('Magnitude of interindividual variability (%CV)')</li><li>table section iiv: 'K a, 1/h' routed out of structural estimates ('Magnitude of interindividual variability (%CV)')</li><li>table section iiv: 'D1, h' routed out of structural estimates ('Magnitude of interindividual variability (%CV)')</li><li>table section iiv: 'D1, h' routed out of structural estimates ('Magnitude of interindividual variability (%CV)')</li><li>table section iiv: 'D1, h' routed out of structural estimates ('Magnitude of interindividual variability (%CV)')</li><li>table section iiv: 'RUV, %' routed out of structural estimates ('Magnitude of interindividual variability (%CV)')</li><li>table section iiv: 'RUV, %' routed out of structural estimates ('Magnitude of interindividual variability (%CV)')</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Pemigatinib_Gong2023_reference;
