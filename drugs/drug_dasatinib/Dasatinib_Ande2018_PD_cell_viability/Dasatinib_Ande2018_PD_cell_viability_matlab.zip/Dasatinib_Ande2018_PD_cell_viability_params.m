function p = Dasatinib_Ande2018_PD_cell_viability_params()
% Dasatinib_Ande2018_PD_cell_viability_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% dasatinib Ande_2018::cell_viability: sigmoid_emax exposure-response sweep (response = E0 + Emax*frac). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one nM per second, in SI inside (kg/m3, s). Response cell viability in % cell viability. Driver: dasatinib (pk_record).
p.E0 = 0.918;
p.Emax = -0.99;
p.EC50 = 58.0;
p.gamma = 0.42;
p.slope = 0.0;
p.exposure_per_s = 1.0;
p.stop_time = 580.0;
p.form = 'E0 + Emax*frac';
end
