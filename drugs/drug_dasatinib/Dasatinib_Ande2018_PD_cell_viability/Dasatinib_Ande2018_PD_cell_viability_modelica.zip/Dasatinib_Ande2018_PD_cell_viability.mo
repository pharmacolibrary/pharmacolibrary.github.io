model Dasatinib_Ande2018_PD_cell_viability
  "sigmoid_emax exposure-response sweep — Ande_2018 :: cell viability (cell viability)"
  extends Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep(
    E0 = 0.918,      // [1; % × 0.01]
    Emax = -0.99,  // [% cell viability]
    EC50 = 58,  // [nM]
    gamma = 0.42,
    exposure_per_s = 1);   // 1 nM per second
  // imax_as_negative_emax: Imax (Q323) enters SigmoidEmaxSweep as −Emax
  // exposure_unit_unresolved: 'nM' — the x axis is in the paper's unit, not SI
  annotation(experiment(StartTime = 0, StopTime = 580, Interval = 1.16),
    Documentation(info = "<html><body><!-- drug-about --><h4>About dasatinib</h4><p>Dasatinib is a tyrosine-kinase inhibitor used to treat certain leukemias, including chronic myelogenous leukemia and precursor lymphoblastic leukemia-lymphoma. It is an approved medicine, authorised in the European Union, and is included on the WHO list of essential medicines.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q419940\">Wikidata Q419940</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h4>Dasatinib_Ande2018_PD_cell_viability</h4><p>The steady-state exposure-response curve of Ande A et al., <i>Frontiers in pharmacology 9:403</i> 2018 (<a href=\"https://doi.org/10.3389/fphar.2018.00403\">doi:10.3389/fphar.2018.00403</a>) — cell viability [% cell viability] against dasatinib nM — obtained by sweeping the driver instead of simulating a dose. Model family: sigmoid_emax.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    =       91.8 %        drug-free response (baseline) (R0, Q324)
  Emax  =       0.99 % cell viability maximal effect term (Imax, Q323)
  EC50  =         58 nM       exposure at half of the maximal effect term (IC50, Q322)
  gamma =       0.42          Hill coefficient (γ, Q325)</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep\">SigmoidEmaxSweep</a>; this model only supplies the numbers. The x axis is one nM of dasatinib per second of simulated time: there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0.918   (drug-free)
  exposure = EC50 (58 nM)  response 0.423
  exposure -> infinity  response -0.072</pre></body></html>"));
end Dasatinib_Ande2018_PD_cell_viability;
