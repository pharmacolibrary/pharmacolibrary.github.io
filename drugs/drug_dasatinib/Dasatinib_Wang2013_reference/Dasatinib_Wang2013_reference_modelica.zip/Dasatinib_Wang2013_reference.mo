model Dasatinib_Wang2013_reference
  parameter Real Cl_ref = 8.222222222222222e-05 "Cl [m3/s]";
  parameter Real Vd_ref = 1.23 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.488006,
    adminMass = 5e-05,
    ka = 0.0005833333333333334,
    Tlag = 0.0,
    k12 = 2.687443541102078e-05,
    k21 = 3.209277238403452e-05
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About dasatinib</h4><p>Dasatinib is a tyrosine-kinase inhibitor used to treat certain leukemias, including chronic myelogenous leukemia and precursor lymphoblastic leukemia-lymphoma. It is an approved medicine, authorised in the European Union, and is included on the WHO list of essential medicines.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q419940\">Wikidata Q419940</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>dasatinib</td></tr><tr><td>population:</td><td>patients with chronic myeloid leukemia in chronic phase across seven clinical studies</td></tr><tr><td>source_paper:</td><td>Wang_2013</td></tr><tr><td>measured_compound:</td><td>dasatinib</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>t1-cpaa-5-085</td></tr><tr><td>input:</td><td>PK_2C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>dasatinib 488.006 g/mol (drugbank)</td></tr></table><p><b>Defaulted (base-class default used):</b> Tlag.</p><h4>Interpretation flags</h4><ul><li>table section residual_error: 'σL' routed out of structural estimates ('Residual error')</li><li>table section residual_error: 'σL' routed out of structural estimates ('Residual error')</li><li>table section residual_error: 'σL' routed out of structural estimates ('Residual error')</li><li>implicit units: 'KATV (1/h)' → 1/h (from the popPK convention: 'The caption defines KATV as the absorption rate constant but states no unit. First-order rate constants are conventional')</li><li>apparent-ness (ontology-grounded): parameterization=apparent, measured_compound=dasatinib</li><li>skipped review gap-fill of TLAG: primary's parameterization (rate-constant / ka-only) does not use it</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Dasatinib_Wang2013_reference;
