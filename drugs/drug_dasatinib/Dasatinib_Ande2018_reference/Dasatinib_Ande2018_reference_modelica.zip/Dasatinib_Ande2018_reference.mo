model Dasatinib_Ande2018_reference
  parameter Real Cl_ref = 1.502777777777778e-07 "Cl [m3/s]";
  parameter Real Vd_ref = 0.025 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.488006,
    adminMass = 1e-05,
    k12 = 1.1088888888888888e-05,
    k21 = 2.8287981859410425e-05
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About dasatinib</h4><p>Dasatinib is a tyrosine-kinase inhibitor used to treat certain leukemias, including chronic myelogenous leukemia and precursor lymphoblastic leukemia-lymphoma. It is an approved medicine, authorised in the European Union, and is included on the WHO list of essential medicines.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q419940\">Wikidata Q419940</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>dasatinib</td></tr><tr><td>population:</td><td>review reference</td></tr><tr><td>source_paper:</td><td>Ande_2018</td></tr><tr><td>measured_compound:</td><td>dasatinib</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_2C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>dasatinib 488.006 g/mol (drugbank)</td></tr></table><h4>Interpretation flags</h4><ul><li>built from REVIEW reference values (Ande_2018) — secondary source</li><li>volume reported by review</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 604800, Tolerance = 1e-9, Interval = 1));
end Dasatinib_Ande2018_reference;
