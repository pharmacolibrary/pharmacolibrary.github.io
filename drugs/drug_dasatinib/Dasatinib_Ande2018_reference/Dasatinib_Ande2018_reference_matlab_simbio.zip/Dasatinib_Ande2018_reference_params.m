function p = Dasatinib_Ande2018_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: dasatinib   source: Ande_2018 / reference   route: iv_bolus
  % estimated (absent from source): F, dose
  p.name  = 'Dasatinib_Ande2018_reference_params';
  p.drug  = 'dasatinib';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'iv_bolus';        % 'oral' | 'iv_bolus'
  p.depot = false;             % oral -> first-order absorption depot
  p.Vc = 25.0;                % central volume [L]
  p.CL = 0.541;                % clearance [L/h]
  p.Vp = [9.8];             % peripheral volumes [L]
  p.Q  = [0.998];             % inter-compartmental clearances [L/h]
  p.ka = 0.0;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 10.0;             % dose [mg]
end
