function p = Dasatinib_Ande2018_PD_active_caspase_3_params()
% Dasatinib_Ande2018_PD_active_caspase_3_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% dasatinib Ande_2018::active_caspase_3: linear exposure-response sweep (response = E0 + slope*exposure). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one nM per second, in SI inside (kg/m3, s). Response active caspase-3 in its own unit. Driver: dasatinib and everolimus (conc_no_pk).
p.E0 = 1.0;
p.Emax = 0.0;
p.EC50 = 1.0;
p.gamma = 1.0;
p.slope = 306000.00000000006;
p.exposure_per_s = 1.0;
p.stop_time = 1000.0;
p.form = 'E0 + slope*exposure';
end
