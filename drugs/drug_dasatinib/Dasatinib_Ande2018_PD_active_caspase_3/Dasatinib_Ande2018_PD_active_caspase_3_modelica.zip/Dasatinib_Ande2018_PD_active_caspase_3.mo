model Dasatinib_Ande2018_PD_active_caspase_3
  "linear exposure-response sweep — Ande_2018 :: active caspase-3 (active caspase-3)"
  extends Pharmacolibrary.Interfaces.PartialExposureResponseSweep(
    E0 = 1,      // [1]
    Emax = 0, EC50 = 1,      // unused by a line
    exposure_per_s = 1);
  parameter Real slope = 306000   "[meter ** 3 / mole; L/nmol × 1e+06]";
equation
  response = E0 + slope*exposure;
  // family_inferred: the record's model family is transduction; read from the parameters: a slope and no Emax — linear
  annotation(experiment(StartTime = 0, StopTime = 1000, Interval = 2),
    Documentation(info = "<html><body><!-- drug-about --><h4>About dasatinib</h4><p>Dasatinib is a tyrosine-kinase inhibitor used to treat certain leukemias, including chronic myelogenous leukemia and precursor lymphoblastic leukemia-lymphoma. It is an approved medicine, authorised in the European Union, and is included on the WHO list of essential medicines.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q419940\">Wikidata Q419940</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h4>Dasatinib_Ande2018_PD_active_caspase_3</h4><p>The steady-state exposure-response curve of Ande A et al., <i>Frontiers in pharmacology 9:403</i> 2018 (<a href=\"https://doi.org/10.3389/fphar.2018.00403\">doi:10.3389/fphar.2018.00403</a>) — active caspase-3 against dasatinib and everolimus nM — obtained by sweeping the driver instead of simulating a dose. Model family: linear.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    =          1          drug-free response (baseline) (baseline active caspase-3, Q324)
  slope =      0.306 L/nmol   change in response per unit of exposure (SDE, Q335)</pre><p>The algebra is <code>response = E0 + slope*exposure</code>; this model only supplies the numbers. The x axis is one nM of dasatinib and everolimus per second of simulated time: there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 1   (drug-free)</pre></body></html>"));
end Dasatinib_Ande2018_PD_active_caspase_3;
