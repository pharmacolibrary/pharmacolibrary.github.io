function p = PolymyxinB_Mahadevan2026_PD_imaxm_pmb_params()
% PolymyxinB_Mahadevan2026_PD_imaxm_pmb_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% polymyxin_b Mahadevan_2026::ImaxM_PMB: sigmoid_emax exposure-response sweep (response = E0 + Emax*frac). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one mg/L per second, in SI inside (kg/m3, s). Response ImaxM,PMB in its own unit. Driver: polymyxin B (conc_no_pk).
p.E0 = 0.0;
p.Emax = 0.84;
p.EC50 = 0.0005099999999999999;
p.gamma = 0.88;
p.slope = 0.0;
p.exposure_per_s = 0.001;
p.stop_time = 5.1;
p.form = 'E0 + Emax*frac';
end
