function p = PolymyxinB_Mahadevan2026_PD_killpmb_params()
% PolymyxinB_Mahadevan2026_PD_killpmb_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% polymyxin_b Mahadevan_2026::KillPMB: sigmoid_emax exposure-response sweep (response = E0 + Emax*frac). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one mg/L per second, in SI inside (kg/m3, s). Response KillPMB in h⁻¹. Driver: polymyxin B (conc_no_pk).
p.E0 = 0.0;
p.Emax = -0.0037222222222222223;
p.EC50 = 0.0008199999999999998;
p.gamma = 0.64;
p.slope = 0.0;
p.exposure_per_s = 0.001;
p.stop_time = 8.2;
p.form = 'E0 + Emax*frac';
end
