function p = PolymyxinB_Hanafin2025_PD_scr_params()
% PolymyxinB_Hanafin2025_PD_scr_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% polymyxin_b Hanafin_2025::SCr: indirect_response_ii exposure-response sweep (response = E0/(1 - Emax*frac)). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one mg/L per second, in SI inside (kg/m3, s). Response SCr in mg/dL. Driver: unbound polymyxin B (conc_no_pk).
p.E0 = 0.012399999999999998;
p.Emax = 1.0;
p.EC50 = 0.0027699999999999995;
p.gamma = 1.0;
p.slope = 0.0;
p.exposure_per_s = 0.001;
p.stop_time = 28.0;
p.form = 'E0/(1 - Emax*frac)';
end
