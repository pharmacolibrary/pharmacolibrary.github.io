model PolymyxinB_Akrong2022_PD_viable_bacterial_burden
  "sigmoid_emax exposure-response sweep — Akrong_2022 :: viable bacterial burden (name)"
  extends Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep(
    E0 = 0,      // [1]
    Emax = -8.96,  // [CFU/mL]
    EC50 = 0.00146,  // [kg/m3; mg/L × 0.001]
    gamma = 0.656,
    exposure_per_s = 0.001);   // 1 mg/L per second
  // inhibition_sign: effect_direction=inhibition with a positive Emax (Q320) — sign flipped
  // defaulted: E0
  annotation(experiment(StartTime = 0, StopTime = 15, Interval = 0.03),
    Documentation(info = "<html><body><h4>PolymyxinB_Akrong2022_PD_viable_bacterial_burden</h4><p>The steady-state exposure-response curve of Akrong G et al., <i>Antimicrobial agents and chemotherapy 66(1):e0178921</i> 2022 (<a href=\"https://doi.org/10.1128/AAC.01789-21\">doi:10.1128/AAC.01789-21</a>) — name [CFU/mL] against Polymyxin B mg/L — obtained by sweeping the driver instead of simulating a dose. Model family: sigmoid_emax.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = (library default) drug-free response (baseline)
  Emax  =       8.96 CFU/mL   maximal effect term (E max(0), Q320)
  EC50  =       1.46 mg/L     exposure at half of the maximal effect term (EC 50, Q321)
  gamma =      0.656          Hill coefficient (g, Q325)</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep\">SigmoidEmaxSweep</a>; this model only supplies the numbers. The x axis is one mg/L of Polymyxin B per second of simulated time (exposure is in kg/m3): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0   (drug-free)
  exposure = EC50 (1.46 mg/L)  response -4.48
  exposure -> infinity  response -8.96</pre></body></html>"));
end PolymyxinB_Akrong2022_PD_viable_bacterial_burden;
