model PolymyxinB_Soeorg2026_PD_cfu
  "sigmoid_emax exposure-response sweep — Soeorg_2026 :: cfu (colony-forming count)"
  extends Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep(
    E0 = 0,      // [1]
    Emax = -3.62,  // [log10 cfu/mL]
    EC50 = 0.00033,  // [kg/m3; mg/L × 0.001]
    gamma = 1,
    exposure_per_s = 0.001);   // 1 mg/L per second
  // imax_as_negative_emax: Imax (Q323) enters SigmoidEmaxSweep as −Emax
  // defaulted: E0
  // defaulted: gamma
  annotation(experiment(StartTime = 0, StopTime = 3.3, Interval = 0.0066),
    Documentation(info = "<html><body><h4>PolymyxinB_Soeorg2026_PD_cfu</h4><p>The steady-state exposure-response curve of Soeorg H et al., <i>Antimicrobial agents and chemotherapy:e0027426</i> 2026 (<a href=\"https://doi.org/10.1128/aac.00274-26\">doi:10.1128/aac.00274-26</a>) — colony-forming count [log10 cfu/mL] against polymyxin B mg/L — obtained by sweeping the driver instead of simulating a dose. Model family: sigmoid_emax.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = (library default) drug-free response (baseline)
  Emax  =       3.62 log10 cfu/mL maximal effect term (EmaxCOLPMB, Q323)
  EC50  =       0.33 mg/L     exposure at half of the maximal effect term (EC50COLPMB, Q322)
  gamma = (library default) Hill coefficient</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep\">SigmoidEmaxSweep</a>; this model only supplies the numbers. The x axis is one mg/L of polymyxin B per second of simulated time (exposure is in kg/m3): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0   (drug-free)
  exposure = EC50 (0.33 mg/L)  response -1.81
  exposure -> infinity  response -3.62</pre></body></html>"));
end PolymyxinB_Soeorg2026_PD_cfu;
