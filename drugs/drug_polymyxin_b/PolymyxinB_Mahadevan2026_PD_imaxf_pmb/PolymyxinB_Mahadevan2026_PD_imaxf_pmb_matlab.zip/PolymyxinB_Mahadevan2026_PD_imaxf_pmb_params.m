function p = PolymyxinB_Mahadevan2026_PD_imaxf_pmb_params()
% PolymyxinB_Mahadevan2026_PD_imaxf_pmb_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% polymyxin_b Mahadevan_2026::ImaxF_PMB: sigmoid_emax exposure-response sweep (response = E0 + Emax*frac). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one mg/L per second, in SI inside (kg/m3, s). Response ImaxF,PMB in its own unit. Driver: polymyxin B (conc_no_pk).
p.E0 = 0.0;
p.Emax = 0.99;
p.EC50 = 0.0006399999999999998;
p.gamma = 0.72;
p.slope = 0.0;
p.exposure_per_s = 0.001;
p.stop_time = 6.4;
p.form = 'E0 + Emax*frac';
end
