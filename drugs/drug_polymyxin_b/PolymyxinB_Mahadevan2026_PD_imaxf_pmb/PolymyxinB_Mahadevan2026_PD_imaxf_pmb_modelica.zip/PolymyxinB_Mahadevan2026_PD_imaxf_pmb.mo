model PolymyxinB_Mahadevan2026_PD_imaxf_pmb
  "sigmoid_emax exposure-response sweep — Mahadevan_2026 :: ImaxF,PMB (mechanistic synergy on fosfomycin potency)"
  extends Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep(
    E0 = 0,      // [1]
    Emax = 0.99,  // [1]
    EC50 = 0.00064,  // [kg/m3; mg/L × 0.001]
    gamma = 0.72,
    exposure_per_s = 0.001);   // 1 mg/L per second
  // defaulted: E0
  annotation(experiment(StartTime = 0, StopTime = 6.4, Interval = 0.0128),
    Documentation(info = "<html><body><h4>PolymyxinB_Mahadevan2026_PD_imaxf_pmb</h4><p>The steady-state exposure-response curve of Mahadevan R et al., <i>Antimicrobial agents and chemotherapy 70(2):e0078225</i> 2026 (<a href=\"https://doi.org/10.1128/aac.00782-25\">doi:10.1128/aac.00782-25</a>) — mechanistic synergy on fosfomycin potency against polymyxin B mg/L — obtained by sweeping the driver instead of simulating a dose. Model family: sigmoid_emax.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = (library default) drug-free response (baseline)
  Emax  =       0.99          maximal effect term (Maximum fractional decrease of KC50,FOF,I and/or KC50,FOF,R by polymyxin B via outer membrane disruption (ImaxF,PMB), Q320)
  EC50  =       0.64 mg/L     exposure at half of the maximal effect term (Polymyxin B concentration causing 50% of ImaxF,PMB (IC50F,PMB), Q322)
  gamma =       0.72          Hill coefficient (Hill coefficient for the mechanistic synergy, Q325)</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep\">SigmoidEmaxSweep</a>; this model only supplies the numbers. The x axis is one mg/L of polymyxin B per second of simulated time (exposure is in kg/m3): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0   (drug-free)
  exposure = EC50 (0.64 mg/L)  response 0.495
  exposure -> infinity  response 0.99</pre></body></html>"));
end PolymyxinB_Mahadevan2026_PD_imaxf_pmb;
