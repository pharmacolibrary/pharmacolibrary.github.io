model Erythromycin_Wen2026_reference
  parameter Real Cl_ref = 9.11111111111111e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.211 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 0.9,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.7339268,
    adminMass = 0.001,
    ka = 0.0005583333333333333,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About erythromycin</h4><p>Erythromycin is a macrolide antibiotic used to treat a range of bacterial infections, including acne, chlamydia, pertussis, legionnaires' disease, and campylobacteriosis. It is widely used in human medicine and is also approved for veterinary use; it appears on the WHO list of essential medicines.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q213511\">Wikidata Q213511</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>erythromycin</td></tr><tr><td>population:</td><td>review reference</td></tr><tr><td>source_paper:</td><td>Wen_2026</td></tr><tr><td>measured_compound:</td><td>erythromycin</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>erythromycin 733.927 g/mol (drugbank)</td></tr></table><p><b>Defaulted (base-class default used):</b> F, Tlag.</p><h4>Interpretation flags</h4><ul><li>built from REVIEW reference values (Wen_2026) — secondary source</li><li>volume reported by review</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Erythromycin_Wen2026_reference;
