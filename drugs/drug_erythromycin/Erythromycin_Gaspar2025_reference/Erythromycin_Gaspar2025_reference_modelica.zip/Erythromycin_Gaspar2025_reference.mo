model Erythromycin_Gaspar2025_reference
  parameter Real Cl_ref = 3.1844444444444445e-05 "Cl [m3/s]";
  parameter Real Vd_ref = 0.0149 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.7339268,
    adminMass = 0.001,
    ka = 7.833333333333333e-05,
    Tlag = 0.0,
    k12 = 0.0009697986577181209,
    k21 = 9.91763898421414e-05
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About erythromycin</h4><p>Erythromycin is a macrolide antibiotic used to treat a range of bacterial infections, including acne, chlamydia, pertussis, legionnaires' disease, and campylobacteriosis. It is widely used in human medicine and is also approved for veterinary use; it appears on the WHO list of essential medicines.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q213511\">Wikidata Q213511</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>erythromycin</td></tr><tr><td>population:</td><td>review reference</td></tr><tr><td>source_paper:</td><td>Gaspar_2025</td></tr><tr><td>measured_compound:</td><td>erythromycin</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_2C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>erythromycin 733.927 g/mol (drugbank)</td></tr></table><p><b>Defaulted (base-class default used):</b> Tlag.</p><h4>Interpretation flags</h4><ul><li>built from REVIEW reference values (Gaspar_2025) — secondary source</li><li>volume reported by review</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Erythromycin_Gaspar2025_reference;
