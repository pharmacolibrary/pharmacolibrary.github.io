function p = Erythromycin_Tamaoki1992_PD_cbf_params()
% Erythromycin_Tamaoki1992_PD_cbf_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% erythromycin Tamaoki_1992::CBF: sigmoid_emax exposure-response sweep (response = E0 + Emax*frac). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one mg/L per second, in SI inside (kg/m3, s). Response CBF in its own unit. Driver: erythromycin (cited_pk).
p.E0 = 0.0;
p.Emax = 0.233;
p.EC50 = 0.006799999999999999;
p.gamma = 1.0;
p.slope = 0.0;
p.exposure_per_s = 0.001;
p.stop_time = 68.0;
p.form = 'E0 + Emax*frac';
end
