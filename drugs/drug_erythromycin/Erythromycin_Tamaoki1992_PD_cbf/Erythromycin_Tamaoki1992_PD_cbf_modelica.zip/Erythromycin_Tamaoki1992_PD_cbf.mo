model Erythromycin_Tamaoki1992_PD_cbf
  "sigmoid_emax exposure-response sweep — Tamaoki_1992 :: CBF (ciliary beat frequency)"
  extends Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep(
    E0 = 0,      // [1]
    Emax = 0.233,  // [1; % × 0.01]
    EC50 = 0.0068,  // [kg/m3; mg/L × 0.001]
    gamma = 1,
    exposure_per_s = 0.001);   // 1 mg/L per second
  // defaulted: E0
  // defaulted: gamma
  annotation(experiment(StartTime = 0, StopTime = 68, Interval = 0.136),
    Documentation(info = "<html><body><!-- drug-about --><h4>About erythromycin</h4><p>Erythromycin is a macrolide antibiotic used to treat a range of bacterial infections, including acne, chlamydia, pertussis, legionnaires' disease, and campylobacteriosis. It is widely used in human medicine and is also approved for veterinary use; it appears on the WHO list of essential medicines.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q213511\">Wikidata Q213511</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h4>Erythromycin_Tamaoki1992_PD_cbf</h4><p>The steady-state exposure-response curve of Tamaoki J et al., <i>The Journal of antimicrobial chemotherapy 29(2):173–178</i> 1992 (<a href=\"https://doi.org/10.1093/jac/29.2.173\">doi:10.1093/jac/29.2.173</a>) — ciliary beat frequency against erythromycin mg/L — obtained by sweeping the driver instead of simulating a dose. Model family: sigmoid_emax.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = (library default) drug-free response (baseline)
  Emax  =       23.3 %        maximal effect term (maximal increase from the baseline value, Q320)
  EC50  =        6.8 mg/L     exposure at half of the maximal effect term (EC50, Q321)
  gamma = (library default) Hill coefficient</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep\">SigmoidEmaxSweep</a>; this model only supplies the numbers. The x axis is one mg/L of erythromycin per second of simulated time (exposure is in kg/m3): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0   (drug-free)
  exposure = EC50 (6.8 mg/L)  response 0.1165
  exposure -> infinity  response 0.233</pre></body></html>"));
end Erythromycin_Tamaoki1992_PD_cbf;
