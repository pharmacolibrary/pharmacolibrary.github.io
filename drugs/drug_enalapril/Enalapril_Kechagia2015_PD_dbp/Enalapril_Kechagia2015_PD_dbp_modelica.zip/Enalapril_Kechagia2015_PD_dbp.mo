model Enalapril_Kechagia2015_PD_dbp
  "emax exposure-response sweep — Kechagia_2015 :: DBP (diastolic blood pressure)"
  extends Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep(
    E0 = 0,      // [1]
    Emax = -18,  // [mmHg]
    EC50 = 4e-06,  // [kg/m3; ng/ml × 1e-06]
    gamma = 1,
    exposure_per_s = 1e-06);   // 1 ng/ml per second
  // family_inferred: the record's model family is effect_compartment; read from the parameters: Emax/Imax and EC50/IC50 without a Hill coefficient — Emax
  // defaulted: E0
  // defaulted: gamma
  annotation(experiment(StartTime = 0, StopTime = 40, Interval = 0.08),
    Documentation(info = "<html><body><!-- drug-about --><h4>About enalapril</h4><p>Enalapril is an ACE inhibitor used to treat high blood pressure, heart failure, and related cardiovascular conditions. It is widely used worldwide, appears on the WHO essential medicines list, and is authorised in the European Union; it is also approved for veterinary use.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q422185\">Wikidata Q422185</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h4>Enalapril_Kechagia2015_PD_dbp</h4><p>The steady-state exposure-response curve of Kechagia IA et al., <i>The Journal of pharmacy and pharmacology 67(11):1537–1545</i> 2015 (<a href=\"https://doi.org/10.1111/jphp.12471\">doi:10.1111/jphp.12471</a>) — diastolic blood pressure [mmHg] against enalaprilat ng/ml — obtained by sweeping the driver instead of simulating a dose. Model family: emax.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = (library default) drug-free response (baseline)
  Emax  =        -18 mmHg     maximal effect term (Emax (mmHg) — Estimate, Q320)
  EC50  =          4 ng/ml    exposure at half of the maximal effect term (Ki (ng/ml) — Estimate, Q322)
  gamma = (library default) Hill coefficient</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep\">SigmoidEmaxSweep</a>; this model only supplies the numbers. The x axis is one ng/ml of enalaprilat per second of simulated time (exposure is in kg/m3): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0   (drug-free)
  exposure = EC50 (4 ng/ml)  response -9
  exposure -> infinity  response -18</pre></body></html>"));
end Enalapril_Kechagia2015_PD_dbp;
