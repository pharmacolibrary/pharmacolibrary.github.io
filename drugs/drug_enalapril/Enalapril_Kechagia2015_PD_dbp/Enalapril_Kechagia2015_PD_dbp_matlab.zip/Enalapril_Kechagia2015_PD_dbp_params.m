function p = Enalapril_Kechagia2015_PD_dbp_params()
% Enalapril_Kechagia2015_PD_dbp_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% enalapril Kechagia_2015::DBP: emax exposure-response sweep (response = E0 + Emax*frac). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one ng/ml per second, in SI inside (kg/m3, s). Response DBP in mmHg. Driver: enalaprilat (cited_pk).
p.E0 = 0.0;
p.Emax = -18.0;
p.EC50 = 4e-06;
p.gamma = 1.0;
p.slope = 0.0;
p.exposure_per_s = 1e-06;
p.stop_time = 40.0;
p.form = 'E0 + Emax*frac';
end
