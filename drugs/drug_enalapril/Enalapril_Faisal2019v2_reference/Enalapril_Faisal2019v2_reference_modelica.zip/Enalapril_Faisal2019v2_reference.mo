model Enalapril_Faisal2019v2_reference
  parameter Real Cl_ref = 2.0833333333333333e-07 "Cl [m3/s]";
  parameter Real Vd_ref = 0.001 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 0.9,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.3764467,
    adminMass = 1e-05,
    ka = 0.001388888888888889,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About enalapril</h4><p>Enalapril is an ACE inhibitor used to treat high blood pressure, heart failure, and related cardiovascular conditions. It is widely used worldwide, appears on the WHO essential medicines list, and is authorised in the European Union; it is also approved for veterinary use.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q422185\">Wikidata Q422185</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>enalapril</td></tr><tr><td>population:</td><td>healthy adults</td></tr><tr><td>source_paper:</td><td>Faisal_2019_2</td></tr><tr><td>measured_compound:</td><td>enalapril</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>T1</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>enalapril 376.447 g/mol (drugbank); enalaprilat 348.399 g/mol (pubchem)</td></tr></table><p><b>Defaulted (base-class default used):</b> F, Tlag.</p><h4>Interpretation flags</h4><ul><li>table section iiv: 'IIV_KA' routed out of structural estimates ('INTERINDIVIDUAL VARIABILITY (IIV)')</li><li>table section iiv: 'IIV_KA' routed out of structural estimates ('INTERINDIVIDUAL VARIABILITY (IIV)')</li><li>table section iiv: 'IIV_VC' routed out of structural estimates ('INTERINDIVIDUAL VARIABILITY (IIV)')</li><li>table section iiv: 'IIV_VC' routed out of structural estimates ('INTERINDIVIDUAL VARIABILITY (IIV)')</li><li>table section iiv: 'IIV_F1' routed out of structural estimates ('INTERINDIVIDUAL VARIABILITY (IIV)')</li><li>table section iiv: 'IIV_F1' routed out of structural estimates ('INTERINDIVIDUAL VARIABILITY (IIV)')</li><li>table section iiv: 'IIV_MTT1' routed out of structural estimates ('INTERINDIVIDUAL VARIABILITY (IIV)')</li><li>table section iiv: 'IIV_MTT1' routed out of structural estimates ('INTERINDIVIDUAL VARIABILITY (IIV)')</li><li>table section iiv: 'IIV_KREN' routed out of structural estimates ('INTERINDIVIDUAL VARIABILITY (IIV)')</li><li>table section iiv: 'IIV_KREN' routed out of structural estimates ('INTERINDIVIDUAL VARIABILITY (IIV)')</li><li>table section iiv: 'IIV_KM' routed out of structural estimates ('INTERINDIVIDUAL VARIABILITY (IIV)')</li><li>table section iiv: 'IIV_KM' routed out of structural estimates ('INTERINDIVIDUAL VARIABILITY (IIV)')</li><li>table section iiv: 'IIV_VM' routed out of structural estimates ('INTERINDIVIDUAL VARIABILITY (IIV)')</li><li>table section iiv: 'IIV_VM' routed out of structural estimates ('INTERINDIVIDUAL VARIABILITY (IIV)')</li><li>table section iiv: 'IIV_KME' routed out of structural estimates ('INTERINDIVIDUAL VARIABILITY (IIV)')</li><li>table section iiv: 'IIV_KME' routed out of structural estimates ('INTERINDIVIDUAL VARIABILITY (IIV)')</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Enalapril_Faisal2019v2_reference;
