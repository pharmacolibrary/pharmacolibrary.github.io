% run_Enalapril_Hockings1986_PD_ace_inhibition  Evaluate the exposure-response curve and plot response against exposure.
% A sweep is a static map: no ODE solver is needed. exposure runs 0..stop_time*exposure_per_s.
p = Enalapril_Hockings1986_PD_ace_inhibition_params();
exposure = linspace(0, p.stop_time * p.exposure_per_s, 501);
frac = exposure.^p.gamma ./ (p.EC50^p.gamma + exposure.^p.gamma);
E0 = p.E0; Emax = p.Emax; slope = p.slope;
response = E0 + Emax.*frac;
figure; plot(exposure, response, 'LineWidth', 1.5); grid on;
xlabel('exposure [ng mt']'); ylabel('response [%]'); title('Enalapril_Hockings1986_PD_ace_inhibition', 'Interpreter', 'none');
writematrix([exposure(:) response(:)], 'Enalapril_Hockings1986_PD_ace_inhibition.csv');
