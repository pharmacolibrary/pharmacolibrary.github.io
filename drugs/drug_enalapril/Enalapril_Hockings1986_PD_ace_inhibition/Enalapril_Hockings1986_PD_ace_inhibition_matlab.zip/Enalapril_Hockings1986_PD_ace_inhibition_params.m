function p = Enalapril_Hockings1986_PD_ace_inhibition_params()
% Enalapril_Hockings1986_PD_ace_inhibition_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% enalapril Hockings_1986::ACE_inhibition: sigmoid_emax exposure-response sweep (response = E0 + Emax*frac). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one ng mt' per second, in SI inside (kg/m3, s). Response ACE inhibition in %. Driver: enalaprilat (pk_record).
p.E0 = 0.0;
p.Emax = -0.898;
p.EC50 = 1.83;
p.gamma = 1.0;
p.slope = 0.0;
p.exposure_per_s = 1.0;
p.stop_time = 19.0;
p.form = 'E0 + Emax*frac';
end
