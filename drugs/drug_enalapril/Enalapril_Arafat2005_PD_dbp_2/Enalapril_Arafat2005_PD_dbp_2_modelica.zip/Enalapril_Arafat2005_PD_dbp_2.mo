model Enalapril_Arafat2005_PD_dbp_2
  "linear exposure-response sweep — Arafat_2005 :: % DBP (percent decrease in diastolic blood pressure)"
  extends Pharmacolibrary.Interfaces.PartialExposureResponseSweep(
    E0 = 0,      // [1; % × 0.01]
    Emax = 0, EC50 = 1,      // unused by a line
    exposure_per_s = 1e-06);
  parameter Real slope = -0.32   "[1]";
equation
  response = E0 + slope*exposure;
  annotation(experiment(StartTime = 0, StopTime = 1000, Interval = 2),
    Documentation(info = "<html><body><!-- drug-about --><h4>About enalapril</h4><p>Enalapril is an ACE inhibitor used to treat high blood pressure, heart failure, and related cardiovascular conditions. It is widely used worldwide, appears on the WHO essential medicines list, and is authorised in the European Union; it is also approved for veterinary use.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q422185\">Wikidata Q422185</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h4>Enalapril_Arafat2005_PD_dbp_2</h4><p>The steady-state exposure-response curve of Arafat T et al., <i>Journal of clinical pharmacy and therapeutics 30(4):319–328</i> 2005 (<a href=\"https://doi.org/10.1111/j.1365-2710.2005.00646.x\">doi:10.1111/j.1365-2710.2005.00646.x</a>) — percent decrease in diastolic blood pressure [%] against enalaprilat ng/mL — obtained by sweeping the driver instead of simulating a dose. Model family: linear.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    =          0 %        drug-free response (baseline) (% DBP predose, Q324)
  slope =      -0.32          change in response per unit of exposure (S, Q335)</pre><p>The algebra is <code>response = E0 + slope*exposure</code>; this model only supplies the numbers. The x axis is one ng/mL of enalaprilat per second of simulated time (exposure is in kg/m3): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0   (drug-free)</pre></body></html>"));
end Enalapril_Arafat2005_PD_dbp_2;
