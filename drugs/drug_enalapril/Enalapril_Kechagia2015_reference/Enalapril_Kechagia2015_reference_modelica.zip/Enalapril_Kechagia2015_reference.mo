model Enalapril_Kechagia2015_reference
  parameter Real Cl_ref = 2.308333333333334e-06 "Cl [m3/s]";
  parameter Boolean cov_category_0 = false "category level 0";
  parameter Boolean cov_category_1 = false "category level 1";
  parameter Real Vd_ref = 0.09 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref + (1.7888888888888891e-06)*(if cov_category_0 then 1 else 0) + (8.250000000000001e-07)*(if cov_category_1 then 1 else 0),
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.3764467,
    adminMass = 2.5e-06,
    ka = 0.00025833333333333334,
    Tlag = 2808.0,
    k12 = 8.179012345679013e-06,
    k21 = 1.8086268086268082e-05
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About enalapril</h4><p>Enalapril is an ACE inhibitor used to treat high blood pressure, heart failure, and related cardiovascular conditions. It is widely used worldwide, appears on the WHO essential medicines list, and is authorised in the European Union; it is also approved for veterinary use.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q422185\">Wikidata Q422185</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>enalapril</td></tr><tr><td>population:</td><td>paediatric patients (0-16 years)</td></tr><tr><td>source_paper:</td><td>Kechagia_2015</td></tr><tr><td>measured_compound:</td><td>enalapril</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>tab_3</td></tr><tr><td>input:</td><td>PK_2C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>enalapril 376.447 g/mol (drugbank)</td></tr></table><h4>Interpretation flags</h4><ul><li>covariate level 'Inter group variability for CL, %CV' → Q900:inter_group_variability_for_cl_cv = 6.44 (additive_shift on Q27)</li><li>covariate level 'Inter group variability for V1, %CV' → Q900:inter_group_variability_for_v1_cv = 2.97 (additive_shift on Q27)</li><li>covariate effect for Q319 has no base parameter row (kept as unattached equation-variable)</li><li>covariate effect for Q319 has no base parameter row (kept as unattached equation-variable)</li><li>apparent-ness (ontology-grounded): parameterization=apparent, measured_compound=enalapril</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 147600, Tolerance = 1e-9, Interval = 1));
end Enalapril_Kechagia2015_reference;
