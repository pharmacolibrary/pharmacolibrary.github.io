function p = Enalapril_Kechagia2015_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: enalapril   source: Kechagia_2015 / reference   route: oral
  p.name  = 'Enalapril_Kechagia2015_reference_params';
  p.drug  = 'enalapril';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 90.0;                % central volume [L]
  p.CL = 8.31;                % clearance [L/h]
  p.Vp = [40.7];             % peripheral volumes [L]
  p.Q  = [2.65];             % inter-compartmental clearances [L/h]
  p.ka = 0.93;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.78;             % absorption lag [h]
  p.dose = 2.5;             % dose [mg]
end
