// parent + metabolites (enalaprilat): PK_3M_9C — formed from central; parent 1, metabolites [1]
model Enalapril_Steichert2025_reference
  parameter Real Q27_enalaprilat_ref = 3.777777777777778e-07 "CL_ENAAT/F [SI]";
  parameter Real cov_age_0 = 0 "age covariate";
  parameter Real cov_creatinine_1 = 0 "creatinine covariate";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_3M_9C(
    Vd1 = 0.00283,
    q1_m11 = 9.527777777777779e-07,
    CL1 = 0.0,
    Vd1m1 = 0.02445,
    CLm1 = Q27_enalaprilat_ref*(1 + (0.092)*cov_age_0)*(1 + (33.3)*cov_creatinine_1),
    MW = 0.3764467,
    MW_m1 = 0.348399,
    F = 1,
    ka = 0.00016666666666666666,
    Tlag = 702.0,
    adminDuration = 600,
    adminCount = 1,
    adminMass = 2.1000000000000002e-06
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About enalapril</h4><p>Enalapril is an ACE inhibitor used to treat high blood pressure, heart failure, and related cardiovascular conditions. It is widely used worldwide, appears on the WHO essential medicines list, and is authorised in the European Union; it is also approved for veterinary use.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q422185\">Wikidata Q422185</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>enalapril</td></tr><tr><td>population:</td><td>children with heart failure</td></tr><tr><td>source_paper:</td><td>Steichert_2025</td></tr><tr><td>measured_compound:</td><td>enalapril</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>parent_metabolite</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>Tab2</td></tr><tr><td>input:</td><td>PK_3M_9C: absorption rate constant reported; formation of enalaprilat: fm not identifiable (CLm/F, Vm/F reported) — all of CL forms it; dose 2.1 mg (paper); covariate effects applied (2): age_on_cl_enaat_f, serum_creatinine_on_cl_enaat_f — typical subject by default</td></tr><tr><td>molar_masses:</td><td>enalapril 376.447 g/mol (drugbank); enalaprilat 348.399 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>table section iiv: 'IIV CL_ENA/F' routed out of structural estimates ('Interindividual variabilitya')</li><li>table section iiv: 'IIV CL_ENA/F' routed out of structural estimates ('Interindividual variabilitya')</li><li>table section iiv: 'IIV CL_ENA/F' routed out of structural estimates ('Interindividual variabilitya')</li><li>table section iiv: 'IIV CL_ENA/F' routed out of structural estimates ('Interindividual variabilitya')</li><li>table section iiv: 'IIV CL_ENA/F' routed out of structural estimates ('Interindividual variabilitya')</li><li>table section iiv: 'IIV CL_ENAAT/F' routed out of structural estimates ('Interindividual variabilitya')</li><li>table section iiv: 'IIV CL_ENAAT/F' routed out of structural estimates ('Interindividual variabilitya')</li><li>table section iiv: 'IIV CL_ENAAT/F' routed out of structural estimates ('Interindividual variabilitya')</li><li>table section iiv: 'IIV CL_ENAAT/F' routed out of structural estimates ('Interindividual variabilitya')</li><li>table section iiv: 'IIV CL_ENAAT/F' routed out of structural estimates ('Interindividual variabilitya')</li><li>table section iiv: 'IIV Vd_ENA/F' routed out of structural estimates ('Interindividual variabilitya')</li><li>table section iiv: 'IIV Vd_ENA/F' routed out of structural estimates ('Interindividual variabilitya')</li><li>table section iiv: 'IIV Vd_ENA/F' routed out of structural estimates ('Interindividual variabilitya')</li><li>table section iiv: 'IIV Vd_ENA/F' routed out of structural estimates ('Interindividual variabilitya')</li><li>table section iiv: 'IIV Vd_ENA/F' routed out of structural estimates ('Interindividual variabilitya')</li><li>table section iiv: 'IIV Vd_ENAAT/F' routed out of structural estimates ('Interindividual variabilitya')</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Enalapril_Steichert2025_reference;
