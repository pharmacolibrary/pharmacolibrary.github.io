function p = Enalapril_Steichert2025_reference_params()
% Auto-generated parent-metabolite PK model (clinical units: mg, L, h).
%   drug: enalapril   source: Steichert_2025 / reference   PK_3M_9C parent + 1 metabolite(s), 2 compartments, oral
%   dA/dt = K*A; C = A./V. K(i,j) is the rate [1/h] at which compartment j feeds i:
%   a metabolic conversion carries MW_dst/MW_src, so one molecule forms one molecule.
%   molar masses: C_central=376.447 g/mol C_M1=348.399 g/mol
  p.name  = 'Enalapril_Steichert2025_reference_params';
  p.drug  = 'enalapril';
  p.kind  = 'network';
  p.template = 'PK_3M_9C';
  p.states = {'central', 'central_M1'};
  p.V = [2.83, 24.45];          % compartment volumes [L]
  p.K = [-1.2120141342756185, 0.0;
         1.1217112870626604, -0.0556237218813906];
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;
  p.dose_into = 1;   % central
  p.ka = 0.6;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.195;             % absorption lag [h] (in dose_start)
  p.dose = 2.1;             % dose [mg]
  p.dose_start = 0.21166666666666667;   % dose enters from [h] ...
  p.dose_duration = 0.16666666666666666;   % ... at a constant rate for [h]
  p.out_idx = [1.0, 2.0];
  p.out_names = {'C_central', 'C_M1'};
  p.out_labels = {'enalapril', 'enalaprilat'};
end
