function p = Enalapril_Arafat2005_PD_dbp_params()
% Enalapril_Arafat2005_PD_dbp_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% enalapril Arafat_2005::DBP: linear exposure-response sweep (response = E0 + slope*exposure). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one ng/mL per second, in SI inside (kg/m3, s). Response % DBP in %. Driver: enalaprilat (cited_pk).
p.E0 = 0.0;
p.Emax = 0.0;
p.EC50 = 1.0;
p.gamma = 1.0;
p.slope = -0.22;
p.exposure_per_s = 1e-06;
p.stop_time = 1000.0;
p.form = 'E0 + slope*exposure';
end
