model Enalapril_Steichert2025v2_reference
  parameter Real Cl_ref = 1.0108333333333333e-05 "Cl [m3/s]";
  parameter Real Vd_ref = 0.22371000000000002 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.348399,
    adminMass = 4.2000000000000004e-06,
    ka = 0.00033055555555555556,
    Tlag = 0.0,
    k12 = 7.921962461321452e-06,
    k21 = 1.637005562739906e-05
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About enalapril</h4><p>Enalapril is an ACE inhibitor used to treat high blood pressure, heart failure, and related cardiovascular conditions. It is widely used worldwide, appears on the WHO essential medicines list, and is authorised in the European Union; it is also approved for veterinary use.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q422185\">Wikidata Q422185</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>enalapril</td></tr><tr><td>population:</td><td>healthy adults and children with heart failure</td></tr><tr><td>source_paper:</td><td>Steichert_2025_2</td></tr><tr><td>measured_compound:</td><td>enalaprilat</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>pharmaceutics-17-01345-t002</td></tr><tr><td>input:</td><td>PK_2C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>enalapril 376.447 g/mol (drugbank); enalaprilat 348.399 g/mol (pubchem)</td></tr></table><p><b>Defaulted (base-class default used):</b> Tlag.</p><h4>Interpretation flags</h4><ul><li>table section iiv: 'IIV ktr' routed out of structural estimates ('Interindividual variability')</li><li>table section iiv: 'IIV ktr' routed out of structural estimates ('Interindividual variability')</li><li>table section iiv: 'IIV Mtt' routed out of structural estimates ('Interindividual variability')</li><li>table section iiv: 'IIV Mtt' routed out of structural estimates ('Interindividual variability')</li><li>table section iiv: 'IIV CL/F' routed out of structural estimates ('Interindividual variability')</li><li>table section iiv: 'IIV CL/F' routed out of structural estimates ('Interindividual variability')</li><li>table section iiv: 'IIV V1/F' routed out of structural estimates ('Interindividual variability')</li><li>table section iiv: 'IIV V1/F' routed out of structural estimates ('Interindividual variability')</li><li>table section iiv: 'IIV E0' routed out of structural estimates ('Interindividual variability')</li><li>table section iiv: 'IIV E0' routed out of structural estimates ('Interindividual variability')</li><li>table section iiv: 'IIV IC50' routed out of structural estimates ('Interindividual variability')</li><li>table section iiv: 'IIV IC50' routed out of structural estimates ('Interindividual variability')</li><li>table section residual_error: 'Proportional error' routed out of structural estimates ('Residual variability pharmacokinetic model')</li><li>table section residual_error: 'Proportional error' routed out of structural estimates ('Residual variability pharmacokinetic model')</li><li>table section residual_error: 'Additive error' routed out of structural estimates ('Residual variability pharmacokinetic model')</li><li>table section residual_error: 'Additive error' routed out of structural estimates ('Residual variability pharmacokinetic model')</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Enalapril_Steichert2025v2_reference;
