model PyridoxineVitB6_Bello2023_PD_inhibition_of_sars_cov_2_main_p
  "emax exposure-response sweep — Bello_2023 :: inhibition of SARS-CoV-2 main protease (MPRO) (name)"
  extends Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep(
    E0 = 0,      // [1]
    Emax = -0.76,  // [1; % × 0.01]
    EC50 = 10,  // [µM]
    gamma = 1,
    exposure_per_s = 1);   // 1 µM per second
  // imax_as_negative_emax: Imax (Q323) enters SigmoidEmaxSweep as −Emax
  // exposure_unit_unresolved: 'µM' — the x axis is in the paper's unit, not SI
  // defaulted: E0
  // defaulted: gamma
  annotation(experiment(StartTime = 0, StopTime = 100, Interval = 0.2),
    Documentation(info = "<html><body><h4>PyridoxineVitB6_Bello2023_PD_inhibition_of_sars_cov_2_main_p</h4><p>The steady-state exposure-response curve of Bello SO et al., <i>Frontiers in cellular and infection microbiology 13:1273982</i> 2023 (<a href=\"https://doi.org/10.3389/fcimb.2023.1273982\">doi:10.3389/fcimb.2023.1273982</a>) — name [%] against erythromycin, retapamulin, pyridoxine, folic acid, ivermectin µM — obtained by sweeping the driver instead of simulating a dose. Model family: emax.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = (library default) drug-free response (baseline)
  Emax  =         76 %        maximal effect term (Maximal inhibition of CPE (%) — Erythromycin, Q323)
  EC50  =         10 µM       exposure at half of the maximal effect term (Dose at maximal observed* inhibition of CPE (µM) — Erythromycin, Q322)
  gamma = (library default) Hill coefficient</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep\">SigmoidEmaxSweep</a>; this model only supplies the numbers. The x axis is one µM of erythromycin, retapamulin, pyridoxine, folic acid, ivermectin per second of simulated time: there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0   (drug-free)
  exposure = EC50 (10 µM)  response -0.38
  exposure -> infinity  response -0.76</pre></body></html>"));
end PyridoxineVitB6_Bello2023_PD_inhibition_of_sars_cov_2_main_p;
