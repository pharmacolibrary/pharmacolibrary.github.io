function p = PyridoxineVitB6_Bello2023_PD_inhibition_of_sars_cov_2_main_p_params()
% PyridoxineVitB6_Bello2023_PD_inhibition_of_sars_cov_2_main_p_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% pyridoxine_vit_b6 Bello_2023::inhibition_of_SARS_CoV_2_main_protease_MPRO: emax exposure-response sweep (response = E0 + Emax*frac). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one µM per second, in SI inside (kg/m3, s). Response inhibition of SARS-CoV-2 main protease (MPRO) in %. Driver: erythromycin, retapamulin, pyridoxine, folic acid, ivermectin (conc_no_pk).
p.E0 = 0.0;
p.Emax = -0.76;
p.EC50 = 10.0;
p.gamma = 1.0;
p.slope = 0.0;
p.exposure_per_s = 1.0;
p.stop_time = 100.0;
p.form = 'E0 + Emax*frac';
end
