function p = Sulfadiazine_Tajima2023v2_sdz_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: sulfadiazine   source: Tajima_2023_2 / sdz   route: oral
  % Vc is the record's Vss — no central volume was reported; 1-compartment reading
  p.name  = 'Sulfadiazine_Tajima2023v2_sdz_params';
  p.drug  = 'sulfadiazine';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 24.99;                % central volume [L]
  p.CL = 6.811;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.158;                % absorption rate [1/h]
  p.F  = 0.857;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 350.0;             % dose [mg]
end
