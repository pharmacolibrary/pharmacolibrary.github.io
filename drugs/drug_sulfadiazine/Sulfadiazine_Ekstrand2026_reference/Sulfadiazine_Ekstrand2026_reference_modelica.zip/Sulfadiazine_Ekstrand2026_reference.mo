model Sulfadiazine_Ekstrand2026_reference
  parameter Real Cl_ref = 8.361111111111111e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.0259 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_3C_enteral(
    weight = 70.0,
    F = 0.94,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.25027699999999997,
    adminMass = 0.00014,
    ka = 0.001025,
    Tlag = 0.0,
    k21 = 0.00043209876543209884
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About sulfadiazine</h4><p>Sulfadiazine is a sulfonamide antibiotic used to treat infections such as toxoplasmosis, urinary tract infections, nocardiosis, malaria, and gram-negative bacterial infections. It remains in use, is listed among WHO essential medicines, and is also approved for veterinary use.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q2555060\">Wikidata Q2555060</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>sulfadiazine</td></tr><tr><td>population:</td><td>Beagle dogs</td></tr><tr><td>source_paper:</td><td>Ekstrand_2026</td></tr><tr><td>measured_compound:</td><td>sulfadiazine</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>3C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>Tab2</td></tr><tr><td>input:</td><td>PK_3C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>sulfadiazine 250.277 g/mol (drugbank)</td></tr></table><p><b>Defaulted (base-class default used):</b> Tlag, k12, k13, k31.</p><h4>Interpretation flags</h4><ul><li>table section iiv: 'Cl' routed out of structural estimates ('IIV (%)')</li><li>table section iiv: 'Vc' routed out of structural estimates ('IIV (%)')</li><li>table section iiv: 'Vp' routed out of structural estimates ('IIV (%)')</li><li>table section iiv: 'ka' routed out of structural estimates ('IIV (%)')</li><li>table section iiv: 'F' routed out of structural estimates ('IIV (%)')</li><li>table section iiv: 'Cl' routed out of structural estimates ('IIV (%)')</li><li>table section iiv: 'ka' routed out of structural estimates ('IIV (%)')</li><li>table section iiv: 'Cl' routed out of structural estimates ('IIV (%)')</li><li>table section iiv: 'V' routed out of structural estimates ('IIV (%)')</li><li>table section iiv: 'ka' routed out of structural estimates ('IIV (%)')</li><li>table section iiv: 'F' routed out of structural estimates ('IIV (%)')</li><li>column 'bootstrap' classified 'other' by the LLM but kept: the deterministic diagnostic-column test disagrees (a stratum column is a value column, not a statistic)</li><li>column 'bootstrap' classified 'other' by the LLM but kept: the deterministic diagnostic-column test disagrees (a stratum column is a value column, not a statistic)</li><li>column 'bootstrap' classified 'other' by the LLM but kept: the deterministic diagnostic-column test disagrees (a stratum column is a value column, not a statistic)</li><li>column 'bootstrap' classified 'other' by the LLM but kept: the deterministic diagnostic-column test disagrees (a stratum column is a value column, not a statistic)</li><li>column 'bootstrap' classified 'other' by the LLM but kept: the deterministic diagnostic-column test disagrees (a stratum column is a value column, not a statistic)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Sulfadiazine_Ekstrand2026_reference;
