model Sulfadiazine_Boulanger2024_reference
  parameter Real Cl_ref = 2.9166666666666666e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.2198 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.25027699999999997,
    adminMass = 1e-05
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About sulfadiazine</h4><p>Sulfadiazine is a sulfonamide antibiotic used to treat infections such as toxoplasmosis, urinary tract infections, nocardiosis, malaria, and gram-negative bacterial infections. It remains in use, is listed among WHO essential medicines, and is also approved for veterinary use.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q2555060\">Wikidata Q2555060</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>sulfadiazine</td></tr><tr><td>population:</td><td>review reference</td></tr><tr><td>source_paper:</td><td>Boulanger_2024</td></tr><tr><td>measured_compound:</td><td>sulfadiazine</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>sulfadiazine 250.277 g/mol (drugbank)</td></tr></table><h4>Interpretation flags</h4><ul><li>built from REVIEW reference values (Boulanger_2024) — secondary source</li><li>volume reported by review</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 345600, Tolerance = 1e-9, Interval = 1));
end Sulfadiazine_Boulanger2024_reference;
