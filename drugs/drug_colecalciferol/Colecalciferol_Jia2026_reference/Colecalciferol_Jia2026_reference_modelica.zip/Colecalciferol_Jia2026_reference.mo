model Colecalciferol_Jia2026_reference
  parameter Real Cl_ref = 2.077777777777778e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.00475 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.38463769999999997,
    adminMass = 2e-08,
    ka = 3.888888888888889e-05,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About colecalciferol</h4><p>Colecalciferol (vitamin D3) is a vitamin used to treat or prevent vitamin D deficiency and support bone health, including in osteoporosis. It is widely used worldwide, appears on the WHO essential medicines list, and is also available as a supplement.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q139347\">Wikidata Q139347</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>colecalciferol</td></tr><tr><td>population:</td><td>review reference</td></tr><tr><td>source_paper:</td><td>Jia_2026</td></tr><tr><td>measured_compound:</td><td>colecalciferol</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>colecalciferol 384.638 g/mol (drugbank)</td></tr></table><p><b>Defaulted (base-class default used):</b> Tlag.</p><h4>Interpretation flags</h4><ul><li>built from REVIEW reference values (Jia_2026) — secondary source</li><li>volume reported by review</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Colecalciferol_Jia2026_reference;
