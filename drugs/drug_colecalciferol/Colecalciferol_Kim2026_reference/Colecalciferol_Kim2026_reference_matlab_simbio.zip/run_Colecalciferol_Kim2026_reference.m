% Run (SimBiology): build model + dose, simulate 0..1176.0 h, plot.
p = Colecalciferol_Kim2026_reference_params();
[model, dose, variant] = build_sb_pk(p);
sd = simulate_sb(model, variant, dose, 1176.0);
