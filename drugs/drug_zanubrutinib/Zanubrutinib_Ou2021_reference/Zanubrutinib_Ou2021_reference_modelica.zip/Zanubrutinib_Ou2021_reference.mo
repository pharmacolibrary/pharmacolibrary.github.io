model Zanubrutinib_Ou2021_reference
  parameter Real Cl_ref = 4.722222222222223e-05 "Cl [m3/s]";
  parameter Real Vd_ref = 0.112 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.47156099999999995,
    adminMass = 2e-05,
    ka = 0.00014611111111111113,
    Tlag = 0.0,
    k12 = 6.572420634920635e-05,
    k21 = 2.1336553945249595e-05
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About zanubrutinib</h4><p>Zanubrutinib is a Bruton's tyrosine kinase inhibitor used to treat blood cancers, including mantle cell lymphoma and Waldenstrom macroglobulinemia. It is an approved medicine and is authorised in the European Union.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q75192022\">Wikidata Q75192022</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>zanubrutinib</td></tr><tr><td>population:</td><td>healthy volunteers and patients with B-cell malignancies</td></tr><tr><td>source_paper:</td><td>Ou_2021</td></tr><tr><td>measured_compound:</td><td>zanubrutinib</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>tab_1</td></tr><tr><td>input:</td><td>PK_2C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>zanubrutinib 471.561 g/mol (drugbank)</td></tr></table><p><b>Defaulted (base-class default used):</b> Tlag.</p><h4>Interpretation flags</h4><ul><li>salvaged Q27 ('CL/F'=170) from results prose — parameter table was unreadable</li><li>salvaged Q290 ('V c /F'=112) from results prose — parameter table was unreadable</li><li>salvaged Q69 ('Q/F'=26.5) from results prose — parameter table was unreadable</li><li>salvaged Q82 ('V p /F'=345) from results prose — parameter table was unreadable</li><li>salvaged Q49 ('absorption rate constant'=0.526) from results prose — parameter table was unreadable</li><li>apparent-ness (ontology-grounded): parameterization=apparent, measured_compound=zanubrutinib</li><li>held at status:extracted — NIL link or unit issue (mismatch/unknown/normalisation-failed) present</li><li>status held at route_to_review — not promoted</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Zanubrutinib_Ou2021_reference;
