function p = Enzalutamide_Hadigol2026_reference_params()
% Auto-generated parent-metabolite PK model (clinical units: mg, L, h).
%   drug: enzalutamide   source: Hadigol_2026 / reference   PK_3M_9C parent + 1 metabolite(s), 3 compartments, oral
%   dA/dt = K*A; C = A./V. K(i,j) is the rate [1/h] at which compartment j feeds i:
%   a metabolic conversion carries MW_dst/MW_src, so one molecule forms one molecule.
%   molar masses: C_central=464.436 g/mol C_M1=450.41 g/mol
  p.name  = 'Enzalutamide_Hadigol2026_reference_params';
  p.drug  = 'enzalutamide';
  p.kind  = 'network';
  p.template = 'PK_3M_9C';
  p.states = {'central', 'central_M1', 'peripheral_M1'};
  p.V = [25.293, 44.944, 52.373];          % compartment volumes [L]
  p.K = [-0.016803068042541416, 0.0, 0.0;
         0.01033141940341413, -0.21646938412246347, 0.18030282779294673;
         0.0, 0.21010590957636166, -0.18030282779294673];
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;
  p.dose_into = 1;   % central
  p.ka = 3.431;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h] (in dose_start)
  p.dose = 0.5;             % dose [mg]
  p.dose_start = 0.016666666666666666;   % dose enters from [h] ...
  p.dose_duration = 0.16666666666666666;   % ... at a constant rate for [h]
  p.out_idx = [1.0, 2.0];
  p.out_names = {'C_central', 'C_M1'};
  p.out_labels = {'enzalutamide', 'N-desmethyl enzalutamide'};
end
