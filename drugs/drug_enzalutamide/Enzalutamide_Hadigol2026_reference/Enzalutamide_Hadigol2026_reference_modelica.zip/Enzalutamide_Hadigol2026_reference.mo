// parent + metabolites (N-desmethyl enzalutamide): PK_3M_9C — formed from central; parent 1, metabolites [2]
model Enzalutamide_Hadigol2026_reference
  parameter Real Q27_ref = 1.1805555555555555e-07 "θ CLe/Fe (L/h) [SI]";
  parameter Real cov_body_weight_0 = 0 "body weight covariate";
  parameter Real cov_body_weight_1 = 0 "body weight covariate";
  parameter Real cov_age_2 = 0 "age covariate";
  parameter Real Q76_ref = 0.025293 "θ Vce/Fe (L) [SI]";
  parameter Real cov_age_0 = 0 "age covariate";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_3M_9C(
    Vd1 = Q76_ref*(1 + (1.223)*cov_age_0),
    q12 = 5.7344444444444445e-06,
    q21 = 5.7344444444444445e-06,
    q13 = 4.3244444444444445e-06,
    q31 = 4.3244444444444445e-06,
    q1_m11 = 0.634*(Q27_ref*(1 + (0.549)*cov_body_weight_0)*(1 + (3.495)*cov_body_weight_1)*(1 + (-0.003)*cov_age_2)),
    CL1 = max((Q27_ref*(1 + (0.549)*cov_body_weight_0)*(1 + (3.495)*cov_body_weight_1)*(1 + (-0.003)*cov_age_2)) - (0.634*(Q27_ref*(1 + (0.549)*cov_body_weight_0)*(1 + (3.495)*cov_body_weight_1)*(1 + (-0.003)*cov_age_2))), 0),
    Vd1m1 = 0.044944000000000005,
    CLm1 = 7.944444444444444e-08,
    Vd2m1 = 0.052372999999999996,
    qm11_m12 = 2.6230555555555555e-06,
    qm12_m11 = 2.6230555555555555e-06,
    MW = 0.46443599999999996,
    MW_m1 = 0.45041000000000003,
    F = 1,
    ka = 0.0009530555555555556,
    Tlag = 0.0,
    adminDuration = 600,
    adminCount = 1,
    adminMass = 5e-07
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About enzalutamide</h4><p>Enzalutamide is an anti-androgen medicine used to treat prostate cancer. It is an approved drug and is authorised in the European Union for prostate tumours.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q1996756\">Wikidata Q1996756</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>enzalutamide</td></tr><tr><td>population:</td><td>patients with metastatic castration-resistant prostate cancer</td></tr><tr><td>source_paper:</td><td>Hadigol_2026</td></tr><tr><td>measured_compound:</td><td>enzalutamide</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>parent_metabolite</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>jcph70125-tbl-0001</td></tr><tr><td>input:</td><td>PK_3M_9C: absorption rate constant reported; formation of N-desmethyl enzalutamide: fm=0.634 × CL; dose 0.5 mg (paper); covariate effects applied (4): body_weight_effect_on_cle_fe, body_weight_effect_on_vce_fe, theta_cl_f_age, theta_v_f_age — typical subject by default</td></tr><tr><td>molar_masses:</td><td>N-desmethyl enzalutamide 450.41 g/mol (pubchem); enzalutamide 464.436 g/mol (drugbank)</td></tr></table><p><b>Defaulted (base-class default used):</b> Tlag.</p><h4>Interpretation flags</h4><ul><li>dropped duplicate Q76 ('θ Vpe/Fe (L)', value '45.928') — already have one for this compound</li><li>unit_dimension_unknown: 'Fixed' (fe)</li><li>routed 'Thetarized sigma' → Q315 (sigma) to residual_error — variability estimate, not a structural parameter</li><li>covariate level 'Body weight effect on θ CLe/Fe' → Q900:body_weight_effect_on_cle_fe = 0.549 (linear_fractional on Q27)</li><li>covariate level 'Body weight effect on θ Vce/Fe' → Q900:body_weight_effect_on_vce_fe = 3.495 (linear_fractional on Q27)</li><li>dropped unlinked row (NIL): 'OFV' — extend the ontology if this is a real PK parameter (source ['jcph70125-tbl-0001:row15:col1', 'Hadigol_2026_table_2:row11:col1', 'Hadigol_2026_table_3:row11:col1'])</li><li>unit_dimension_unknown: 'Fixed' (fm)</li><li>covariate level 'Effect of body weight on θ Vcn' → Q900:effect_of_body_weight_on_vcn = 0.027 (linear_fractional on Q27)</li><li>routed 'Thetarized σ' → Q315 (sigma) to residual_error — variability estimate, not a structural parameter</li><li>linked '(L/h)' as 'CL' → Q22 (CL) for talazoparib — compound marker removed</li><li>dropped duplicate Q290 ('θ Vpt/Ft (L)', value '382.135') — already have one for this compound</li><li>unit_dimension_unknown: 'Fixed' (equation variable)</li><li>dropped value-less row: 'θ slope (mL/ng)' (captured trailing unit 'mL/ng' for child rows)</li><li>dropped unlinked row (NIL): 'BCCL effect on' — extend the ontology if this is a real PK parameter (source ['Hadigol_2026_table_3:row8:col1', 'Hadigol_2026_table_3:row8:col2', 'Hadigol_2026_table_3:row8:col3'])</li><li>unit inherited for body_weight_effect_on_cle_fe (Q900): 'Fixed' from a same-Q-code sibling (this row's label had no unit)</li><li>unit inherited for body_weight_effect_on_vce_fe (Q900): 'Fixed' from a same-Q-code sibling (this row's label had no unit)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 777600, Tolerance = 1e-9, Interval = 1));
end Enzalutamide_Hadigol2026_reference;
