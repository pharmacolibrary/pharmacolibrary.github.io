function p = Betacarotene_Franken2026_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: betacarotene   source: Franken_2026 / reference   route: oral
  % estimated (absent from source): F
  p.name  = 'Betacarotene_Franken2026_reference_params';
  p.drug  = 'betacarotene';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 618.1;                % central volume [L]
  p.CL = 536.9;                % clearance [L/h]
  p.Vp = [616.0];             % peripheral volumes [L]
  p.Q  = [737.1];             % inter-compartmental clearances [L/h]
  p.ka = 1.3;                % absorption rate [1/h]
  p.F  = 0.9;                 % bioavailability [0-1]
  p.Tlag = 0.39;             % absorption lag [h]
  p.dose = 100.0;             % dose [mg]
end
