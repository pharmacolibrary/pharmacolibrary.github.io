model Betacarotene_Franken2026_reference
  parameter Real Cl_ref = 0.0001491388888888889 "Cl [m3/s]";
  parameter Real Vd_ref = 0.6181000000000001 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C_enteral(
    weight = 70.0,
    F = 0.9,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.536888,
    adminMass = 0.0001,
    ka = 0.00036111111111111115,
    Tlag = 1404.0,
    k12 = 0.0003312570781426953,
    k21 = 0.00033238636363636364
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About betacarotene</h4><p>Betacarotene is a provitamin A carotenoid used as a vitamin A supplement and as a systemic protective against UV radiation. It is widely available as an approved supplement and nutraceutical, sold over the counter in many countries.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q306135\">Wikidata Q306135</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>betacarotene</td></tr><tr><td>population:</td><td>review reference</td></tr><tr><td>source_paper:</td><td>Franken_2026</td></tr><tr><td>measured_compound:</td><td>betacarotene</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_2C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>betacarotene 536.888 g/mol (drugbank)</td></tr></table><p><b>Defaulted (base-class default used):</b> F.</p><h4>Interpretation flags</h4><ul><li>built from REVIEW reference values (Franken_2026) — secondary source</li><li>volume reported by review</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Betacarotene_Franken2026_reference;
