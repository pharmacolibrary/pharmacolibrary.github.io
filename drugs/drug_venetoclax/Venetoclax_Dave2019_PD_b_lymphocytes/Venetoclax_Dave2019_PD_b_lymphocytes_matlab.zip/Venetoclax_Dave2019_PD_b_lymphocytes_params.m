function p = Venetoclax_Dave2019_PD_b_lymphocytes_params()
% Venetoclax_Dave2019_PD_b_lymphocytes_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% venetoclax Dave_2019::B_lymphocytes: linear exposure-response sweep (response = E0 + slope*exposure). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one SI per second, in SI inside (kg/m3, s). Response B-lymphocytes in its own unit. Driver: venetoclax (pk_record).
p.E0 = 0.0;
p.Emax = 0.0;
p.EC50 = 1.0;
p.gamma = 1.0;
p.slope = 20.9;
p.exposure_per_s = 1.0;
p.stop_time = 1000.0;
p.form = 'E0 + slope*exposure';
end
