function p = Venetoclax_Zhao2024_minocha_201817_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: venetoclax   source: Zhao_2024 / minocha_201817   route: oral
  p.name  = 'Venetoclax_Zhao2024_minocha_201817_params';
  p.drug  = 'venetoclax';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 181.0;                % central volume [L]
  p.CL = 16.3;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.16;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 10.0;             % dose [mg]
end
