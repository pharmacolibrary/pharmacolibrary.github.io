model Venetoclax_Zhao2024_samineni_2022b19
  parameter Real Cl_ref = 5.173611111111111e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.181 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.86845,
    adminMass = 1e-05,
    ka = 4.4444444444444447e-05,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About venetoclax</h4><p>Venetoclax is an anticancer medicine used to treat blood cancers such as chronic lymphocytic leukemia, acute myeloid leukemia, and certain B-cell lymphomas. It is an approved medicine and is authorised in the European Union for chronic lymphocytic leukemia.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q23671272\">Wikidata Q23671272</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>venetoclax</td></tr><tr><td>population:</td><td>adults with hematologic malignancies</td></tr><tr><td>source_paper:</td><td>Zhao_2024</td></tr><tr><td>measured_compound:</td><td>venetoclax</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>t0003</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>venetoclax 868.45 g/mol (drugbank)</td></tr></table><p><b>Defaulted (base-class default used):</b> Tlag.</p><h4>Interpretation flags</h4><ul><li>column 'samineni 2022b19' classified 'other' by the LLM but kept: the deterministic diagnostic-column test disagrees (a stratum column is a value column, not a statistic)</li><li>column 'samineni 2022b19' classified 'other' by the LLM but kept: the deterministic diagnostic-column test disagrees (a stratum column is a value column, not a statistic)</li><li>column 'samineni 2022b19' classified 'other' by the LLM but kept: the deterministic diagnostic-column test disagrees (a stratum column is a value column, not a statistic)</li><li>column 'samineni 2022b19' classified 'other' by the LLM but kept: the deterministic diagnostic-column test disagrees (a stratum column is a value column, not a statistic)</li><li>column 'samineni 2022b19' classified 'other' by the LLM but kept: the deterministic diagnostic-column test disagrees (a stratum column is a value column, not a statistic)</li><li>column 'samineni 2022b19' classified 'other' by the LLM but kept: the deterministic diagnostic-column test disagrees (a stratum column is a value column, not a statistic)</li><li>apparent-ness (ontology-grounded): parameterization=apparent, measured_compound=venetoclax</li><li>structure disagreement: deterministic 1C vs LLM 3C — review compartment count</li><li>population split: 'samineni 2022b19' subgroup of Zhao_2024 (paper reports 6 populations: deng 201915, gong 202316, jones 201611, minocha 201817, samineni 2022a18, samineni 2022b19)</li><li>gap-filled Q76 (V/F) from Liu_2026's review values (primary lacked it)</li><li>gap-filled Q49 (kabs) from Liu_2026's review values (primary lacked it)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 259200, Tolerance = 1e-9, Interval = 1));
end Venetoclax_Zhao2024_samineni_2022b19;
