function p = Venetoclax_Zhao2024_deng_201915_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: venetoclax   source: Zhao_2024 / deng_201915   route: oral
  p.name  = 'Venetoclax_Zhao2024_deng_201915_params';
  p.drug  = 'venetoclax';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 181.0;                % central volume [L]
  p.CL = 19.541667;                % clearance [L/h]
  p.Vp = [118.0];             % peripheral volumes [L]
  p.Q  = [4.166667];             % inter-compartmental clearances [L/h]
  p.ka = 0.16;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 10.0;             % dose [mg]
end
