model Venetoclax_Liu2026_reference
  parameter Real Cl_ref = 2.0361111111111113e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.181 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.86845,
    adminMass = 0.0001,
    ka = 4.4444444444444447e-05,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About venetoclax</h4><p>Venetoclax is an anticancer medicine used to treat blood cancers such as chronic lymphocytic leukemia, acute myeloid leukemia, and certain B-cell lymphomas. It is an approved medicine and is authorised in the European Union for chronic lymphocytic leukemia.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q23671272\">Wikidata Q23671272</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>venetoclax</td></tr><tr><td>population:</td><td>Chinese patients with hematological malignancies</td></tr><tr><td>source_paper:</td><td>Liu_2026</td></tr><tr><td>measured_compound:</td><td>venetoclax</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>t0003</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>venetoclax 868.45 g/mol (drugbank)</td></tr></table><p><b>Defaulted (base-class default used):</b> Tlag.</p><h4>Interpretation flags</h4><ul><li>apparent-ness (ontology-grounded): parameterization=apparent, measured_compound=venetoclax</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of TLAG: primary's parameterization (rate-constant / ka-only) does not use it</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 432000, Tolerance = 1e-9, Interval = 1));
end Venetoclax_Liu2026_reference;
