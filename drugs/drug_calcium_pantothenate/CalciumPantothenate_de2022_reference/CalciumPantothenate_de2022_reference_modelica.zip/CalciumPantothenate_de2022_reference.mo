model CalciumPantothenate_de2022_reference
  parameter Real Cl_ref = 1.5633333333333335e-05 "Cl [m3/s]";
  parameter Real Vd_ref = 0.09743385228147705 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.476536,
    adminMass = 1e-05
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About calcium_pantothenate</h4><p>Calcium pantothenate, a form of pantothenic acid, is used as a vitamin preparation and as a cicatrizant for wounds and ulcers. It is approved as a supplement and veterinary medicine, and is also studied investigationally.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q27261387\">Wikidata Q27261387</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>calcium_pantothenate</td></tr><tr><td>population:</td><td>review reference</td></tr><tr><td>source_paper:</td><td>de_2022</td></tr><tr><td>measured_compound:</td><td>calcium_pantothenate</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>calcium_pantothenate 476.536 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>built from REVIEW reference values (de_2022) — secondary source</li><li>central volume derived from CL·t½/ln2</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end CalciumPantothenate_de2022_reference;
