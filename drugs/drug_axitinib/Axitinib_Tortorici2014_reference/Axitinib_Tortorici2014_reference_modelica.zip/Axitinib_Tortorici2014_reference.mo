model Axitinib_Tortorici2014_reference
  parameter Real Cl_ref = 5.583333333333335e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.05620000000000001 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 0.663,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.38647000000000004,
    adminMass = 1e-05,
    ka = 0.00035,
    Tlag = 1612.8
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About axitinib</h4><p>Axitinib is a protein kinase inhibitor used to treat kidney cancer, especially renal cell carcinoma. It is an approved medicine and is authorised in the European Union for renal cell carcinoma.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q4830631\">Wikidata Q4830631</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>axitinib</td></tr><tr><td>population:</td><td>patients with NSCLC, thyroid cancer, or melanoma and healthy volunteers</td></tr><tr><td>source_paper:</td><td>Tortorici_2014</td></tr><tr><td>measured_compound:</td><td>axitinib</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>axitinib 386.47 g/mol (drugbank)</td></tr></table><h4>Interpretation flags</h4><ul><li>unit_dimension_unknown: '/h(-1)' (kabs)</li><li>implicit units: 'absorption rate constant' → 1/h (from the popPK convention: 'No unit is stated in the provided text. Absorption rate constants are first-order rate constants, conventionally reporte')</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=axitinib</li><li>1C volume normalization: Q63→Q61 (single-compartment model has no central/peripheral split; 'central volume of distribution' is the general volume)</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Axitinib_Tortorici2014_reference;
