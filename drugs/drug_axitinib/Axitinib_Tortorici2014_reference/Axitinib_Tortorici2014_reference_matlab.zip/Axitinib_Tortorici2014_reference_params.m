function p = Axitinib_Tortorici2014_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: axitinib   source: Tortorici_2014 / reference   route: oral
  p.name  = 'Axitinib_Tortorici2014_reference_params';
  p.drug  = 'axitinib';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 56.2;                % central volume [L]
  p.CL = 20.1;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 1.26;                % absorption rate [1/h]
  p.F  = 0.663;                 % bioavailability [0-1]
  p.Tlag = 0.448;             % absorption lag [h]
  p.dose = 10.0;             % dose [mg]
end
