function p = Axitinib_Ma2019_PD_tv_params()
% Axitinib_Ma2019_PD_tv_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% axitinib Ma_2019::TV: emax exposure-response sweep (response = E0 + Emax*frac). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one mg/L per second, in SI inside (kg/m3, s). Response TV in mm3. Driver: AX (conc_no_pk).
p.E0 = 50.4;
p.Emax = -1.8518518518518518e-05;
p.EC50 = 0.0021;
p.gamma = 1.0;
p.slope = 0.0;
p.exposure_per_s = 0.001;
p.stop_time = 21.0;
p.form = 'E0 + Emax*frac';
end
