model Axitinib_Ma2019_PD_tv
  "emax exposure-response sweep — Ma_2019 :: TV (tumor volume)"
  extends Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep(
    E0 = 50.4,      // [mm3]
    Emax = -1.85185185185e-05,  // [1/s; per day × 1.15741e-05]
    EC50 = 0.0021,  // [kg/m3; mg/L × 0.001]
    gamma = 1,
    exposure_per_s = 0.001);   // 1 mg/L per second
  // imax_as_negative_emax: Imax (Q323) enters SigmoidEmaxSweep as −Emax
  // defaulted: gamma
  annotation(experiment(StartTime = 0, StopTime = 21, Interval = 0.042),
    Documentation(info = "<html><body><!-- drug-about --><h4>About axitinib</h4><p>Axitinib is a protein kinase inhibitor used to treat kidney cancer, especially renal cell carcinoma. It is an approved medicine and is authorised in the European Union for renal cell carcinoma.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q4830631\">Wikidata Q4830631</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h4>Axitinib_Ma2019_PD_tv</h4><p>The steady-state exposure-response curve of Ma YH et al., <i>Acta pharmacologica Sinica 40(2):243–256</i> 2019 (<a href=\"https://doi.org/10.1038/s41401-018-0006-x\">doi:10.1038/s41401-018-0006-x</a>) — tumor volume [mm3] against AX mg/L — obtained by sweeping the driver instead of simulating a dose. Model family: emax.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    =       50.4 mm3      drug-free response (baseline) (N 0, Q324)
  Emax  =        1.6 per day  maximal effect term (k max, Q323)
  EC50  =        2.1 mg/L     exposure at half of the maximal effect term (kC 50, Q322)
  gamma = (library default) Hill coefficient</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep\">SigmoidEmaxSweep</a>; this model only supplies the numbers. The x axis is one mg/L of AX per second of simulated time (exposure is in kg/m3): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 50.4   (drug-free)
  exposure = EC50 (2.1 mg/L)  response 50.4
  exposure -> infinity  response 50.4</pre></body></html>"));
end Axitinib_Ma2019_PD_tv;
