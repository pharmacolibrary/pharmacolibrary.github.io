model Axitinib_Chen2015v2_PD_dbp
  "indirect_response_iii exposure-response sweep — Chen_2015_2 :: dBP (24-h mean dBP)"
  extends Pharmacolibrary.Interfaces.PartialExposureResponseSweep(
    E0 = 0,      // [1]
    Emax = 20.8,  // type III effect term
    EC50 = 1.24e-05,  // [kg/m3; ng/mL × 1e-06]
    gamma = 1,
    exposure_per_s = 1e-06);   // 1 ng/mL per second
equation
  response = E0*(1 + Emax*frac);   // steady state, indirect response type III
  // defaulted: E0
  // defaulted: gamma
  annotation(experiment(StartTime = 0, StopTime = 130, Interval = 0.26),
    Documentation(info = "<html><body><!-- drug-about --><h4>About axitinib</h4><p>Axitinib is a protein kinase inhibitor used to treat kidney cancer, especially renal cell carcinoma. It is an approved medicine and is authorised in the European Union for renal cell carcinoma.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q4830631\">Wikidata Q4830631</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h4>Axitinib_Chen2015v2_PD_dbp</h4><p>The steady-state exposure-response curve of Chen Y et al., <i>Clinical pharmacokinetics 54(4):397–407</i> 2015 (<a href=\"https://doi.org/10.1007/s40262-014-0207-5\">doi:10.1007/s40262-014-0207-5</a>) — 24-h mean dBP against axitinib ng/mL — obtained by sweeping the driver instead of simulating a dose. Model family: indirect_response_iii.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = (library default) drug-free response (baseline)
  Emax  =       20.8          maximal effect term (maximum increase in dBP, Q320)
  EC50  =       12.4 ng/mL    exposure at half of the maximal effect term (axitinib concentration at which 50 % of the maximal increase in dBP was reached, Q321)
  gamma = (library default) Hill coefficient</pre><p>The algebra is <code>response = E0*(1 + Emax*frac)</code>; this model only supplies the numbers. The x axis is one ng/mL of axitinib per second of simulated time (exposure is in kg/m3): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0   (drug-free)
  exposure = EC50 (12.4 ng/mL)  response 0
  exposure -> infinity  response 0</pre></body></html>"));
end Axitinib_Chen2015v2_PD_dbp;
