function p = Axitinib_Chen2015v2_PD_dbp_params()
% Axitinib_Chen2015v2_PD_dbp_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% axitinib Chen_2015_2::dBP: indirect_response_iii exposure-response sweep (response = E0*(1 + Emax*frac)). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one ng/mL per second, in SI inside (kg/m3, s). Response dBP in its own unit. Driver: axitinib (cited_pk).
p.E0 = 0.0;
p.Emax = 20.8;
p.EC50 = 1.24e-05;
p.gamma = 1.0;
p.slope = 0.0;
p.exposure_per_s = 1e-06;
p.stop_time = 130.0;
p.form = 'E0*(1 + Emax*frac)';
end
