function p = Axitinib_Garrett2014_base_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: axitinib   source: Garrett_2014 / base   route: oral
  p.name  = 'Axitinib_Garrett2014_base_params';
  p.drug  = 'axitinib';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 46.6;                % central volume [L]
  p.CL = 17.1;                % clearance [L/h]
  p.Vp = [44.7];             % peripheral volumes [L]
  p.Q  = [1.73];             % inter-compartmental clearances [L/h]
  p.ka = 3.279167;                % absorption rate [1/h]
  p.F  = 0.469;                 % bioavailability [0-1]
  p.Tlag = 0.457;             % absorption lag [h]
  p.dose = 1.0;             % dose [mg]
end
