model Axitinib_Garrett2014_final
  parameter Real Cl_ref = 2.2777777777777776e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.0076 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C_enteral(
    weight = 70.0,
    F = 7.8,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.38647000000000004,
    adminMass = 1e-06,
    ka = 0.0009108796296296296,
    Tlag = 1152.0,
    k12 = 0.00029970760233918127,
    k21 = 0.00011388888888888888
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About axitinib</h4><p>Axitinib is a protein kinase inhibitor used to treat kidney cancer, especially renal cell carcinoma. It is an approved medicine and is authorised in the European Union for renal cell carcinoma.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q4830631\">Wikidata Q4830631</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>axitinib</td></tr><tr><td>population:</td><td>healthy volunteers</td></tr><tr><td>source_paper:</td><td>Garrett_2014</td></tr><tr><td>measured_compound:</td><td>axitinib</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>tab_0</td></tr><tr><td>input:</td><td>PK_2C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>axitinib 386.47 g/mol (drugbank)</td></tr></table><h4>Interpretation flags</h4><ul><li>table section iiv: 'ω 2 CL' routed out of structural estimates ('Interindividual variability model parameters §')</li><li>table section iiv: 'ω 2 CL' routed out of structural estimates ('Interindividual variability model parameters §')</li><li>table section iiv: 'ω 2 CL' routed out of structural estimates ('Interindividual variability model parameters §')</li><li>table section iiv: 'ω 2 Vc' routed out of structural estimates ('Interindividual variability model parameters §')</li><li>table section iiv: 'ω 2 Vc' routed out of structural estimates ('Interindividual variability model parameters §')</li><li>table section iiv: 'ω 2 Vc' routed out of structural estimates ('Interindividual variability model parameters §')</li><li>table section iiv: 'ω 2 Q' routed out of structural estimates ('Interindividual variability model parameters §')</li><li>table section iiv: 'ω 2 Q' routed out of structural estimates ('Interindividual variability model parameters §')</li><li>table section iiv: 'ω 2 Q' routed out of structural estimates ('Interindividual variability model parameters §')</li><li>table section iiv: 'ω 2 Vp' routed out of structural estimates ('Interindividual variability model parameters §')</li><li>table section iiv: 'ω 2 Vp' routed out of structural estimates ('Interindividual variability model parameters §')</li><li>table section iiv: 'ω 2 Vp' routed out of structural estimates ('Interindividual variability model parameters §')</li><li>table section iiv: 'ω 2 ka' routed out of structural estimates ('Interindividual variability model parameters §')</li><li>table section iiv: 'ω 2 ka' routed out of structural estimates ('Interindividual variability model parameters §')</li><li>table section iiv: 'ω 2 ka' routed out of structural estimates ('Interindividual variability model parameters §')</li><li>table section iiv: 'ω CL ω Vc' routed out of structural estimates ('Interindividual variability model parameters §')</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Axitinib_Garrett2014_final;
