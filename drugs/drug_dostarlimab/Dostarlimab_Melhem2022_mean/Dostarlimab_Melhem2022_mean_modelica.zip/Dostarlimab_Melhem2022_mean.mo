model Dostarlimab_Melhem2022_mean
  parameter Real Cl_ref = 2.0717592592592592e-09 "Cl [m3/s]";
  parameter Real Vd_ref = 0.0053 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    adminMass = 1e-05
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About dostarlimab</h4><p>Dostarlimab is a monoclonal antibody drug used to treat endometrial cancer. It is an approved PD-1 inhibitor and is authorised in the European Union.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q85757472\">Wikidata Q85757472</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>dostarlimab</td></tr><tr><td>population:</td><td>patients with advanced solid tumours</td></tr><tr><td>source_paper:</td><td>Melhem_2022</td></tr><tr><td>measured_compound:</td><td>dostarlimab</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>bcp15339-tbl-0003</td></tr><tr><td>input:</td><td>PK_1C: IV (no input phase)</td></tr></table><h4>Interpretation flags</h4><ul><li>salvaged Q22 ('CL'=0.179) from results prose — parameter table was unreadable</li><li>salvaged Q61 ('volume of distribution (Vss)'=5.3) from results prose — parameter table was unreadable</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=dostarlimab</li><li>held at status:extracted — NIL link or unit issue (mismatch/unknown/normalisation-failed) present</li><li>status held at route_to_review — not promoted</li><li>population split: 'mean' subgroup of Melhem_2022 (paper reports 2 populations: estimate b, mean)</li><li>molar mass: none found for 'dostarlimab' — its concentrations stay mass-only</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 9072000, Tolerance = 1e-9, Interval = 1));
end Dostarlimab_Melhem2022_mean;
