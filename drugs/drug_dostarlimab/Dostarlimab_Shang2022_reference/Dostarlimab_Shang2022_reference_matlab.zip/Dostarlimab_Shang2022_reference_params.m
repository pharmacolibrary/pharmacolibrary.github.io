function p = Dostarlimab_Shang2022_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: dostarlimab   source: Shang_2022 / reference   route: iv_bolus
  % estimated (absent from source): F, dose
  p.name  = 'Dostarlimab_Shang2022_reference_params';
  p.drug  = 'dostarlimab';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'iv_bolus';        % 'oral' | 'iv_bolus'
  p.depot = false;             % oral -> first-order absorption depot
  p.Vc = 3.48;                % central volume [L]
  p.CL = 0.010375;                % clearance [L/h]
  p.Vp = [2.78];             % peripheral volumes [L]
  p.Q  = [0.029292];             % inter-compartmental clearances [L/h]
  p.ka = 0.0;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 10.0;             % dose [mg]
end
