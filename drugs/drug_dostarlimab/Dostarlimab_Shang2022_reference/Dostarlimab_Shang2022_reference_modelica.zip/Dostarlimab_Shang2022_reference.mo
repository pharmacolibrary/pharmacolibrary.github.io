model Dostarlimab_Shang2022_reference
  parameter Real Cl_ref = 2.8819444444444443e-09 "Cl [m3/s]";
  parameter Real Vd_ref = 0.00348 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    adminMass = 1e-05,
    k12 = 2.3380959982971474e-06,
    k21 = 2.9268252065014654e-06
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About dostarlimab</h4><p>Dostarlimab is a monoclonal antibody drug used to treat endometrial cancer. It is an approved PD-1 inhibitor and is authorised in the European Union.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q85757472\">Wikidata Q85757472</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>dostarlimab</td></tr><tr><td>population:</td><td>review reference</td></tr><tr><td>source_paper:</td><td>Shang_2022</td></tr><tr><td>measured_compound:</td><td>dostarlimab</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_2C: IV (no input phase)</td></tr></table><h4>Interpretation flags</h4><ul><li>built from REVIEW reference values (Shang_2022) — secondary source</li><li>volume reported by review</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 4233600, Tolerance = 1e-9, Interval = 1));
end Dostarlimab_Shang2022_reference;
