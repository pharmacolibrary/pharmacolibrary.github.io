model Dostarlimab_Kuchimanchi2025_reference
  parameter Real Cl_ref = 2.0333333333333333e-09 "Cl [m3/s]";
  parameter Real cov_age_0 = 0 "age covariate";
  parameter Real Vd_ref = 0.00309 "Vd [m3]";
  parameter Real cov_wt_0 = 0 "wt covariate";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref*(1 + (-0.238)*cov_age_0),
    Vd = Vd_ref*(1 + (0.48)*cov_wt_0),
    adminDuration = 600,
    adminCount = 1,
    adminMass = 0.0005,
    k12 = 1.7170082704063287e-06,
    k21 = 2.1393369175627238e-06
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About dostarlimab</h4><p>Dostarlimab is a monoclonal antibody drug used to treat endometrial cancer. It is an approved PD-1 inhibitor and is authorised in the European Union.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q85757472\">Wikidata Q85757472</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>dostarlimab</td></tr><tr><td>population:</td><td>patients with primary advanced or recurrent endometrial cancer</td></tr><tr><td>source_paper:</td><td>Kuchimanchi_2025</td></tr><tr><td>measured_compound:</td><td>dostarlimab</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>bcp16325-tbl-0002</td></tr><tr><td>input:</td><td>PK_2C: IV (no input phase)</td></tr></table><h4>Interpretation flags</h4><ul><li>unit_dimension_unknown: 'CL [L·h−1]' (CL)</li><li>unit_dimension_unknown: 'Q [L·h−1]' (Q)</li><li>dropped PD-category row 'Imax' → Q323 (Imax, category G11) — pharmacodynamic parameters belong to scholarpd, not the PK model (source ['bcp16325-tbl-0002:row7:col1', 'bcp16325-tbl-0002:row7:col2'])</li><li>dropped PD-category row 'Hill' → Q325 (Hill, category G11) — pharmacodynamic parameters belong to scholarpd, not the PK model (source ['bcp16325-tbl-0002:row9:col1', 'bcp16325-tbl-0002:row9:col2', 'bcp16325-tbl-0002:row9:col3'])</li><li>dropped unlinked row (NIL): 'Effect of ALB on CL' — extend the ontology if this is a real PK parameter (source ['bcp16325-tbl-0002:row14:col1', 'bcp16325-tbl-0002:row14:col2'])</li><li>dropped duplicate Q22 ('Effect of combination therapy on CL', value '-0.0779') — already have one for this compound</li><li>dropped duplicate Q22 ('Effect of male on CL', value '0.15') — already have one for this compound</li><li>dropped duplicate Q63 ('Effect of ALB on Vc', value '-0.132') — already have one for this compound</li><li>dropped duplicate Q63 ('Effect of male on Vc', value '0.137') — already have one for this compound</li><li>covariate effect for Q319 has no base parameter row (kept as unattached equation-variable)</li><li>implicit units: 'Clearance (CL [L·h−1])' → L/h (from the paper text: 'The parameter is listed as “Clearance (CL [L·h−1])”. This explicitly states L/h.')</li><li>implicit units: 'Central volume of distribution (Vc (L))' → L (from the paper text: 'The parameter is listed as “Central volume of distribution (Vc (L))”. This explicitly states L.')</li><li>implicit units: 'Intercompartmental clearance (Q [L·h−1])' → L/h (from the paper text: 'The parameter is listed as “Intercompartmental clearance (Q [L·h−1])”. This explicitly states L/h.')</li><li>implicit units: 'Peripheral volume of distribution (Vp (L))' → L (from the paper text: 'The parameter is listed as “Peripheral volume of distribution (Vp (L))”. This explicitly states L.')</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=dostarlimab</li><li>molar mass: none found for 'dostarlimab' — its concentrations stay mass-only</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 15552000, Tolerance = 1e-9, Interval = 1));
end Dostarlimab_Kuchimanchi2025_reference;
