function p = TolfenamicAcid_Sidhu2005_PD_txb2_params()
% TolfenamicAcid_Sidhu2005_PD_txb2_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% tolfenamic_acid Sidhu_2005::TxB2: sigmoid_emax exposure-response sweep (response = E0 + Emax*frac). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one microg/mL per second, in SI inside (kg/m3, s). Response TxB2 in its own unit. Driver: tolfenamic acid (cited_pk).
p.E0 = 0.0;
p.Emax = -0.7809999999999999;
p.EC50 = 0.00025599999999999993;
p.gamma = 1.96;
p.slope = 0.0;
p.exposure_per_s = 0.001;
p.stop_time = 2.6;
p.form = 'E0 + Emax*frac';
end
