function p = TolfenamicAcid_Sidhu2005_PD_pge2_params()
% TolfenamicAcid_Sidhu2005_PD_pge2_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% tolfenamic_acid Sidhu_2005::PGE2: sigmoid_emax exposure-response sweep (response = E0 + Emax*frac). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one microg/mL per second, in SI inside (kg/m3, s). Response PGE2 in its own unit. Driver: tolfenamic acid (cited_pk).
p.E0 = 0.0;
p.Emax = -0.975;
p.EC50 = 0.00026499999999999994;
p.gamma = 2.29;
p.slope = 0.0;
p.exposure_per_s = 0.001;
p.stop_time = 2.7;
p.form = 'E0 + Emax*frac';
end
