model TolfenamicAcid_Sidhu2005_PD_pge2
  "sigmoid_emax exposure-response sweep — Sidhu_2005 :: PGE2 (prostaglandin E2 (PGE2))"
  extends Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep(
    E0 = 0,      // [1]
    Emax = -0.975,  // [1; % × 0.01]
    EC50 = 0.000265,  // [kg/m3; microg/mL × 0.001]
    gamma = 2.29,
    exposure_per_s = 0.001);   // 1 microg/mL per second
  // imax_as_negative_emax: Imax (Q323) enters SigmoidEmaxSweep as −Emax
  // defaulted: E0
  annotation(experiment(StartTime = 0, StopTime = 2.7, Interval = 0.0054),
    Documentation(info = "<html><body><!-- drug-about --><h4>About tolfenamic_acid</h4><p>Tolfenamic acid is a non-steroidal anti-inflammatory drug (a fenamate) used as an analgesic and anti-inflammatory, for example for pain and rheumatic conditions. It is an approved medicine, though not authorised by the European Medicines Agency, and is used only in some countries rather than worldwide.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q59412\">Wikidata Q59412</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h4>TolfenamicAcid_Sidhu2005_PD_pge2</h4><p>The steady-state exposure-response curve of Sidhu PK et al., <i>Journal of veterinary pharmacology and therapeutics 28(1):109–119</i> 2005 (<a href=\"https://doi.org/10.1111/j.1365-2885.2004.00633.x\">doi:10.1111/j.1365-2885.2004.00633.x</a>) — prostaglandin E2 (PGE2) against tolfenamic acid microg/mL — obtained by sweeping the driver instead of simulating a dose. Model family: sigmoid_emax.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = (library default) drug-free response (baseline)
  Emax  =       97.5 %        maximal effect term (Emax, Q323)
  EC50  =      0.265 microg/mL exposure at half of the maximal effect term (IC50, Q322)
  gamma =       2.29          Hill coefficient (N, Q325)</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep\">SigmoidEmaxSweep</a>; this model only supplies the numbers. The x axis is one microg/mL of tolfenamic acid per second of simulated time (exposure is in kg/m3): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0   (drug-free)
  exposure = EC50 (0.265 microg/mL)  response -0.4875
  exposure -> infinity  response -0.975</pre></body></html>"));
end TolfenamicAcid_Sidhu2005_PD_pge2;
