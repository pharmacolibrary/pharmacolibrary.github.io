function p = TolfenamicAcid_Sidhu2006_PD_pge2_params()
% TolfenamicAcid_Sidhu2006_PD_pge2_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% tolfenamic_acid Sidhu_2006::PGE2: sigmoid_emax exposure-response sweep (response = E0 + Emax*frac). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one microg ml(-1) per second, in SI inside (kg/m3, s). Response PGE2 in its own unit. Driver: tolfenamic_acid (cited_pk).
p.E0 = 0.0;
p.Emax = -0.897;
p.EC50 = 7.299999999999999e-05;
p.gamma = 1.18;
p.slope = 0.0;
p.exposure_per_s = 0.001;
p.stop_time = 0.73;
p.form = 'E0 + Emax*frac';
end
