model TolfenamicAcid_Sidhu2006_PD_pge2
  "sigmoid_emax exposure-response sweep — Sidhu_2006 :: PGE2 (exudate PGE2)"
  extends Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep(
    E0 = 0,      // [1]
    Emax = -0.897,  // [1; % × 0.01]
    EC50 = 7.3e-05,  // [kg/m3; microg ml(-1) × 0.001]
    gamma = 1.18,
    exposure_per_s = 0.001);   // 1 microg ml(-1) per second
  // imax_as_negative_emax: Imax (Q323) enters SigmoidEmaxSweep as −Emax
  // defaulted: E0
  annotation(experiment(StartTime = 0, StopTime = 0.73, Interval = 0.00146),
    Documentation(info = "<html><body><!-- drug-about --><h4>About tolfenamic_acid</h4><p>Tolfenamic acid is a non-steroidal anti-inflammatory drug (a fenamate) used as an analgesic and anti-inflammatory, for example for pain and rheumatic conditions. It is an approved medicine, though not authorised by the European Medicines Agency, and is used only in some countries rather than worldwide.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q59412\">Wikidata Q59412</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h4>TolfenamicAcid_Sidhu2006_PD_pge2</h4><p>The steady-state exposure-response curve of Sidhu PK et al., <i>Research in veterinary science 80(1):79–90</i> 2006 (<a href=\"https://doi.org/10.1016/j.rvsc.2005.04.008\">doi:10.1016/j.rvsc.2005.04.008</a>) — exudate PGE2 against tolfenamic_acid microg ml(-1) — obtained by sweeping the driver instead of simulating a dose. Model family: sigmoid_emax.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = (library default) drug-free response (baseline)
  Emax  =       89.7 %        maximal effect term (Emax, Q323)
  EC50  =      0.073 microg ml(-1) exposure at half of the maximal effect term (IC50, Q322)
  gamma =       1.18          Hill coefficient (N, Q325)</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep\">SigmoidEmaxSweep</a>; this model only supplies the numbers. The x axis is one microg ml(-1) of tolfenamic_acid per second of simulated time (exposure is in kg/m3): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0   (drug-free)
  exposure = EC50 (0.073 microg ml(-1))  response -0.4485
  exposure -> infinity  response -0.897</pre></body></html>"));
end TolfenamicAcid_Sidhu2006_PD_pge2;
