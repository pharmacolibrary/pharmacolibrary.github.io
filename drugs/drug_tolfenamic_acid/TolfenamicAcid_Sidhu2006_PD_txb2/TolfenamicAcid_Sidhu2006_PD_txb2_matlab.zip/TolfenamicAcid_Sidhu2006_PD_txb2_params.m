function p = TolfenamicAcid_Sidhu2006_PD_txb2_params()
% TolfenamicAcid_Sidhu2006_PD_txb2_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% tolfenamic_acid Sidhu_2006::TxB2: sigmoid_emax exposure-response sweep (response = E0 + Emax*frac). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one microg ml(-1) per second, in SI inside (kg/m3, s). Response TxB2 in its own unit. Driver: tolfenamic_acid (cited_pk).
p.E0 = 0.0;
p.Emax = -0.6940000000000001;
p.EC50 = 0.0007169999999999999;
p.gamma = 3.413;
p.slope = 0.0;
p.exposure_per_s = 0.001;
p.stop_time = 7.2;
p.form = 'E0 + Emax*frac';
end
