model TolfenamicAcid_Landoni1996_reference
  parameter Real Cl_ref = 5.833333333333333e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.0686 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.261704,
    adminMass = 1e-05
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About tolfenamic_acid</h4><p>Tolfenamic acid is a non-steroidal anti-inflammatory drug (a fenamate) used as an analgesic and anti-inflammatory, for example for pain and rheumatic conditions. It is an approved medicine, though not authorised by the European Medicines Agency, and is used only in some countries rather than worldwide.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q59412\">Wikidata Q59412</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>tolfenamic_acid</td></tr><tr><td>population:</td><td>calves</td></tr><tr><td>source_paper:</td><td>Landoni_1996</td></tr><tr><td>measured_compound:</td><td>tolfenamic acid</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>tolfenamic acid 261.704 g/mol (drugbank); tolfenamic_acid 261.704 g/mol (drugbank)</td></tr></table><h4>Interpretation flags</h4><ul><li>covariate category for EC50 from footnote/prose kept as documentation only (['Landoni_1996:abstract', 'Landoni_1996:abstract', 'Landoni_1996:abstract'])</li><li>dropped unlinked row (NIL): 'serum TxB2 inhibition' — extend the ontology if this is a real PK parameter (source ['Landoni_1996:abstract'])</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=tolfenamic acid</li><li>structure disagreement: deterministic 1C vs LLM 2C — review compartment count</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end TolfenamicAcid_Landoni1996_reference;
