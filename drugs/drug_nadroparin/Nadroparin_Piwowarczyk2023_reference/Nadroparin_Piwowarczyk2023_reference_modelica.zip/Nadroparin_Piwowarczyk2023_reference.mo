model Nadroparin_Piwowarczyk2023_reference
  parameter Real Cl_ref = 3.1666666666666667e-07 "Cl [m3/s]";
  parameter Real Vd_ref = 0.00662 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    adminMass = 0.0001,
    ka = 9.027777777777779e-05,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About nadroparin</h4><p>Nadroparin is an anticoagulant of the heparin group used to prevent and treat blood clots. It is an approved medicine and is used in clinical practice, mainly in Europe.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q20817257\">Wikidata Q20817257</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>nadroparin</td></tr><tr><td>population:</td><td>patients with COVID-19</td></tr><tr><td>source_paper:</td><td>Piwowarczyk_2023</td></tr><tr><td>measured_compound:</td><td>nadroparin</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>Tab2</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr></table><p><b>Defaulted (base-class default used):</b> Tlag.</p><h4>Interpretation flags</h4><ul><li>table section iiv: 'ω2V/F, %CV' routed out of structural estimates ('Inter-individual variability (ω2)')</li><li>table section iiv: 'ω2V/F, %CV' routed out of structural estimates ('Inter-individual variability (ω2)')</li><li>table section iiv: 'ω2V/F, %CV' routed out of structural estimates ('Inter-individual variability (ω2)')</li><li>table section iiv: 'ω2Cl/F, %CV' routed out of structural estimates ('Inter-individual variability (ω2)')</li><li>table section iiv: 'ω2Cl/F, %CV' routed out of structural estimates ('Inter-individual variability (ω2)')</li><li>table section iiv: 'ω2Cl/F, %CV' routed out of structural estimates ('Inter-individual variability (ω2)')</li><li>table section iiv: 'ω2Cl/F, %CV' routed out of structural estimates ('Inter-individual variability (ω2)')</li><li>table section iiv: 'ω2Cl/F, %CV' routed out of structural estimates ('Inter-individual variability (ω2)')</li><li>table section iiv: 'ω2fr, %CV' routed out of structural estimates ('Inter-individual variability (ω2)')</li><li>table section iiv: 'ω2fr, %CV' routed out of structural estimates ('Inter-individual variability (ω2)')</li><li>table section iiv: 'ω2fr, %CV' routed out of structural estimates ('Inter-individual variability (ω2)')</li><li>table section iiv: 'ω2fr, %CV' routed out of structural estimates ('Inter-individual variability (ω2)')</li><li>table section iiv: 'ω2fr, %CV' routed out of structural estimates ('Inter-individual variability (ω2)')</li><li>table section iiv: 'ω2ka, %CV' routed out of structural estimates ('Inter-individual variability (ω2)')</li><li>table section iiv: 'ω2ka, %CV' routed out of structural estimates ('Inter-individual variability (ω2)')</li><li>table section iiv: 'ω2ka, %CV' routed out of structural estimates ('Inter-individual variability (ω2)')</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 108000, Tolerance = 1e-9, Interval = 1));
end Nadroparin_Piwowarczyk2023_reference;
