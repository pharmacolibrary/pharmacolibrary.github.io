function p = Amifampridine_Thakkar2017_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: amifampridine   source: Thakkar_2017 / reference   route: oral
  p.name  = 'Amifampridine_Thakkar2017_reference_params';
  p.drug  = 'amifampridine';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 72.6;                % central volume [L]
  p.CL = 107.7;                % clearance [L/h]
  p.Vp = [902.2];             % peripheral volumes [L]
  p.Q  = [147.7];             % inter-compartmental clearances [L/h]
  p.ka = 1.1;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 40.0;             % dose [mg]
end
