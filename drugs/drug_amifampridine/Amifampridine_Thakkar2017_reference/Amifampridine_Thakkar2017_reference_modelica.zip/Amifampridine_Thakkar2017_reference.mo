model Amifampridine_Thakkar2017_reference
  parameter Real Cl_ref = 2.9916666666666668e-05 "Cl [m3/s]";
  parameter Real Vd_ref = 0.0726 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.109132,
    adminMass = 4e-05,
    ka = 0.0003055555555555556,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About amifampridine</h4><p>Amifampridine is a potassium channel blocker used to treat Lambert-Eaton myasthenic syndrome and myasthenia gravis. It is approved and authorised in the European Union, where two products are on the market.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q411707\">Wikidata Q411707</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>amifampridine</td></tr><tr><td>population:</td><td>patients with Lambert-Eaton myasthenia</td></tr><tr><td>source_paper:</td><td>Thakkar_2017</td></tr><tr><td>measured_compound:</td><td>3,4-diaminopyridine (amifampridine)</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>psp412218-tbl-0002</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>3,4-diaminopyridine (amifampridine) 109.132 g/mol (pubchem); 3-N-acetyl-3,4-diaminopyridine (3-Ac DAP) 151.169 g/mol (pubchem)</td></tr></table><p><b>Defaulted (base-class default used):</b> Tlag.</p><h4>Interpretation flags</h4><ul><li>PK_3M template not built: formation of 3-N-acetyl-3,4-diaminopyridine (3-Ac DAP) is not quantified (no CLfm, fm, kfm)</li><li>PK_3M template not built: formation of 3-N-acetyl-3,4-diaminopyridine (3-Ac DAP) is not quantified (no CLfm, fm, kfm)</li><li>table section iiv: 'KA, %' routed out of structural estimates ('Between subject variability (%CV)')</li><li>table section iiv: 'KA, %' routed out of structural estimates ('Between subject variability (%CV)')</li><li>table section iiv: 'KA, %' routed out of structural estimates ('Between subject variability (%CV)')</li><li>table section iiv: 'KA, %' routed out of structural estimates ('Between subject variability (%CV)')</li><li>table section iiv: 'KA, %' routed out of structural estimates ('Between subject variability (%CV)')</li><li>table section iiv: 'CL/F, %' routed out of structural estimates ('Between subject variability (%CV)')</li><li>table section iiv: 'CL/F, %' routed out of structural estimates ('Between subject variability (%CV)')</li><li>table section iiv: 'CL/F, %' routed out of structural estimates ('Between subject variability (%CV)')</li><li>table section iiv: 'CL/F, %' routed out of structural estimates ('Between subject variability (%CV)')</li><li>table section iiv: 'CL/F, %' routed out of structural estimates ('Between subject variability (%CV)')</li><li>table section iiv: 'Vc/F, %' routed out of structural estimates ('Between subject variability (%CV)')</li><li>table section iiv: 'Vc/F, %' routed out of structural estimates ('Between subject variability (%CV)')</li><li>table section iiv: 'Vc/F, %' routed out of structural estimates ('Between subject variability (%CV)')</li><li>table section iiv: 'Vc/F, %' routed out of structural estimates ('Between subject variability (%CV)')</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Amifampridine_Thakkar2017_reference;
