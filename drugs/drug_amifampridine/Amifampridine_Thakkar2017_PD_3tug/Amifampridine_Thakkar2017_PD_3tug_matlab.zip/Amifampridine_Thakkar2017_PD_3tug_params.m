function p = Amifampridine_Thakkar2017_PD_3tug_params()
% Amifampridine_Thakkar2017_PD_3tug_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% amifampridine Thakkar_2017::3TUG: emax exposure-response sweep (response = E0 + Emax*frac). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one ng/mL per second, in SI inside (kg/m3, s). Response 3TUG in sec. Driver: 3,4-DAP (conc_no_pk).
p.E0 = 18.2;
p.Emax = -0.816;
p.EC50 = 2.98e-05;
p.gamma = 1.0;
p.slope = 0.0;
p.exposure_per_s = 1e-06;
p.stop_time = 300.0;
p.form = 'E0 + Emax*frac';
end
