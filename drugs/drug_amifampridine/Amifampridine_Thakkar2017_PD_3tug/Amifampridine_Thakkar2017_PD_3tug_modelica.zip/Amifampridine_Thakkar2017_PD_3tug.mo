model Amifampridine_Thakkar2017_PD_3tug
  "emax exposure-response sweep — Thakkar_2017 :: 3TUG (Triple Timed Up & Go)"
  extends Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep(
    E0 = 18.2,      // [s; sec × 1]
    Emax = -0.816,  // [s; sec × 1]
    EC50 = 2.98e-05,  // [kg/m3; ng/mL × 1e-06]
    gamma = 1,
    exposure_per_s = 1e-06);   // 1 ng/mL per second
  // imax_as_negative_emax: Imax (Q323) enters SigmoidEmaxSweep as −Emax
  // defaulted: gamma
  annotation(experiment(StartTime = 0, StopTime = 300, Interval = 0.6),
    Documentation(info = "<html><body><!-- drug-about --><h4>About amifampridine</h4><p>Amifampridine is a potassium channel blocker used to treat Lambert-Eaton myasthenic syndrome and myasthenia gravis. It is approved and authorised in the European Union, where two products are on the market.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q411707\">Wikidata Q411707</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h4>Amifampridine_Thakkar2017_PD_3tug</h4><p>The steady-state exposure-response curve of Thakkar N et al., <i>CPT: pharmacometrics &amp; systems pharmacology 6(9):625–634</i> 2017 (<a href=\"https://doi.org/10.1002/psp4.12218\">doi:10.1002/psp4.12218</a>) — Triple Timed Up &amp; Go [sec] against 3,4-DAP ng/mL — obtained by sweeping the driver instead of simulating a dose. Model family: emax.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    =       18.2 sec      drug-free response (baseline) (E0, Q324)
  Emax  =      0.816 sec      maximal effect term (Fractional Emax, Q323)
  EC50  =       29.8 ng/mL    exposure at half of the maximal effect term (EC50, Q321)
  gamma = (library default) Hill coefficient</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep\">SigmoidEmaxSweep</a>; this model only supplies the numbers. The x axis is one ng/mL of 3,4-DAP per second of simulated time (exposure is in kg/m3): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 18.2   (drug-free)
  exposure = EC50 (29.8 ng/mL)  response 17.79
  exposure -> infinity  response 17.38</pre></body></html>"));
end Amifampridine_Thakkar2017_PD_3tug;
