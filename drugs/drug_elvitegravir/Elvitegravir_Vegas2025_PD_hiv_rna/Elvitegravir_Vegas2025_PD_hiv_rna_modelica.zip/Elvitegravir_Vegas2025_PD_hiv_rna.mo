model Elvitegravir_Vegas2025_PD_hiv_rna
  "sigmoid_emax exposure-response sweep — Vegas_2025 :: HIV-RNA (HIV-1 RNA)"
  extends Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep(
    E0 = 0,      // [1]
    Emax = -0.99,  // [copies/mL]
    EC50 = 0.00024165,  // [kg/m3; ng/mL × 1e-06]
    gamma = 1,
    exposure_per_s = 1e-06);   // 1 ng/mL per second
  // family_inferred: the record's model family is disease_progression; read from the parameters: Emax/Imax, EC50/IC50 and a Hill coefficient — sigmoid Emax
  // imax_as_negative_emax: Imax (Q323) enters SigmoidEmaxSweep as −Emax
  // defaulted: E0
  annotation(experiment(StartTime = 0, StopTime = 2500, Interval = 5),
    Documentation(info = "<html><body><!-- drug-about --><h4>About elvitegravir</h4><p>Elvitegravir is an antiviral drug used to treat HIV infections, acting as an integrase inhibitor. It is an approved medicine used in fixed-dose combination antiviral products for HIV treatment, including in the European Union, although one EU product has been withdrawn.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q2740966\">Wikidata Q2740966</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h4>Elvitegravir_Vegas2025_PD_hiv_rna</h4><p>The steady-state exposure-response curve of Vegas Rodriguez A et al., <i>The AAPS journal 27(6):161</i> 2025 (<a href=\"https://doi.org/10.1208/s12248-025-01136-4\">doi:10.1208/s12248-025-01136-4</a>) — HIV-1 RNA [copies/mL] against elvitegravir ng/mL — obtained by sweeping the driver instead of simulating a dose. Model family: sigmoid_emax.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = (library default) drug-free response (baseline)
  Emax  =       0.99 copies/mL maximal effect term (EMAX, Q323)
  EC50  =     241.65 ng/mL    exposure at half of the maximal effect term (EC50, Q321)
  gamma =          1          Hill coefficient (Gamma, Q325)</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep\">SigmoidEmaxSweep</a>; this model only supplies the numbers. The x axis is one ng/mL of elvitegravir per second of simulated time (exposure is in kg/m3): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0   (drug-free)
  exposure = EC50 (241.65 ng/mL)  response -0.495
  exposure -> infinity  response -0.99</pre></body></html>"));
end Elvitegravir_Vegas2025_PD_hiv_rna;
