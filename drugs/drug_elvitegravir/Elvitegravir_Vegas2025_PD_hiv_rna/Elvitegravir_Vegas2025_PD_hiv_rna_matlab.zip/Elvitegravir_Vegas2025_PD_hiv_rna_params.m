function p = Elvitegravir_Vegas2025_PD_hiv_rna_params()
% Elvitegravir_Vegas2025_PD_hiv_rna_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% elvitegravir Vegas_2025::HIV_RNA: sigmoid_emax exposure-response sweep (response = E0 + Emax*frac). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one ng/mL per second, in SI inside (kg/m3, s). Response HIV-RNA in copies/mL. Driver: elvitegravir (cited_pk).
p.E0 = 0.0;
p.Emax = -0.99;
p.EC50 = 0.00024165;
p.gamma = 1.0;
p.slope = 0.0;
p.exposure_per_s = 1e-06;
p.stop_time = 2500.0;
p.form = 'E0 + Emax*frac';
end
