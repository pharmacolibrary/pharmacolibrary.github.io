model Elvitegravir_Barcel2016_reference
  parameter Real Cl_ref = 2.111111111111111e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.061 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.447884,
    adminMass = 1e-05
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About elvitegravir</h4><p>Elvitegravir is an antiviral drug used to treat HIV infections, acting as an integrase inhibitor. It is an approved medicine used in fixed-dose combination antiviral products for HIV treatment, including in the European Union, although one EU product has been withdrawn.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q2740966\">Wikidata Q2740966</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>elvitegravir</td></tr><tr><td>population:</td><td>HIV-1-infected individuals</td></tr><tr><td>source_paper:</td><td>Barceló_2016</td></tr><tr><td>measured_compound:</td><td>elvitegravir</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>elvitegravir 447.884 g/mol (drugbank)</td></tr></table><h4>Interpretation flags</h4><ul><li>dropped unlinked row (NIL): 'el' — extend the ontology if this is a real PK parameter (source ['Barceló_2016:abstract'])</li><li>unit_dimension_mismatch: 'clearance' → Q22 (unit 'dimensionless' vs ontology '[length] ** 3 / [time]') — route to review</li><li>dropped duplicate Q22 ('clearance', value 47) — already have one for this compound</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=elvitegravir</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 100800, Tolerance = 1e-9, Interval = 1));
end Elvitegravir_Barcel2016_reference;
