function p = Amodiaquine_Bocci2020_PD_cpe_params()
% Amodiaquine_Bocci2020_PD_cpe_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% amodiaquine Bocci_2020::CPE: sigmoid_emax exposure-response sweep (response = E0 + Emax*frac). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one μM per second, in SI inside (kg/m3, s). Response CPE in %. Driver: amodiaquine (conc_no_pk).
p.E0 = 0.0;
p.Emax = -100.0;
p.EC50 = 0.13;
p.gamma = 1.0;
p.slope = 0.0;
p.exposure_per_s = 1.0;
p.stop_time = 1.3;
p.form = 'E0 + Emax*frac';
end
