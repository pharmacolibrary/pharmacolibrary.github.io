model Amodiaquine_Bocci2020_PD_cpe
  "sigmoid_emax exposure-response sweep — Bocci_2020 :: CPE (SARS-CoV-2 cytopathic effect (Vero E6 cell viability, dose–response))"
  extends Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep(
    E0 = 0,      // [1]
    Emax = -100,  // [% at 10 μM]
    EC50 = 0.13,  // [μM]
    gamma = 1,
    exposure_per_s = 1);   // 1 μM per second
  // inhibition_sign: effect_direction=inhibition with a positive Emax (Q320) — sign flipped
  // exposure_unit_unresolved: 'μM' — the x axis is in the paper's unit, not SI
  // defaulted: E0
  // defaulted: gamma
  annotation(experiment(StartTime = 0, StopTime = 1.3, Interval = 0.0026),
    Documentation(info = "<html><body><!-- drug-about --><h4>About amodiaquine</h4><p>Amodiaquine is an antimalarial medicine used to treat malaria. It is on the WHO list of essential medicines and is also available in combination with artemisinin derivatives; it is not authorised in the European Union.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q239569\">Wikidata Q239569</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h4>Amodiaquine_Bocci2020_PD_cpe</h4><p>The steady-state exposure-response curve of Bocci G et al., <i>ACS pharmacology &amp; translational science 3(6):1278–1292</i> 2020 (<a href=\"https://doi.org/10.1021/acsptsci.0c00131\">doi:10.1021/acsptsci.0c00131</a>) — SARS-CoV-2 cytopathic effect (Vero E6 cell viability, dose–response) [%] against amodiaquine μM — obtained by sweeping the driver instead of simulating a dose. Model family: sigmoid_emax.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = (library default) drug-free response (baseline)
  Emax  =        100 % at 10 μM maximal effect term (peak of activity (ZPX, UNM), Q320)
  EC50  =       0.13 μM       exposure at half of the maximal effect term (EC50, Q321)
  gamma = (library default) Hill coefficient</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep\">SigmoidEmaxSweep</a>; this model only supplies the numbers. The x axis is one μM of amodiaquine per second of simulated time: there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0   (drug-free)
  exposure = EC50 (0.13 μM)  response -50
  exposure -> infinity  response -100</pre></body></html>"));
end Amodiaquine_Bocci2020_PD_cpe;
