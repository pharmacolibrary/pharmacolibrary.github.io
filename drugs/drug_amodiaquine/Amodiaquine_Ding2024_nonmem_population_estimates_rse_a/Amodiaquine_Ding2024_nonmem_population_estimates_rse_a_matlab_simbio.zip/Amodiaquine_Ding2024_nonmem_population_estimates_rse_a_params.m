function p = Amodiaquine_Ding2024_nonmem_population_estimates_rse_a_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: amodiaquine   source: Ding_2024 / nonmem_population_estimates_rse_a   route: oral
  % estimated (absent from source): ka
  p.name  = 'Amodiaquine_Ding2024_nonmem_population_estimates_rse_a_params';
  p.drug  = 'amodiaquine';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 4240.0;                % central volume [L]
  p.CL = 69.9;                % clearance [L/h]
  p.Vp = [3880.0];             % peripheral volumes [L]
  p.Q  = [265.0];             % inter-compartmental clearances [L/h]
  p.ka = 0.5;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 513.0;             % dose [mg]
end
