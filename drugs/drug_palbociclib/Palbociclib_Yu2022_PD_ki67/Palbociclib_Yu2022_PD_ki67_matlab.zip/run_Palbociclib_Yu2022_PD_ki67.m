% run_Palbociclib_Yu2022_PD_ki67  Evaluate the exposure-response curve and plot response against exposure.
% A sweep is a static map: no ODE solver is needed. exposure runs 0..stop_time*exposure_per_s.
p = Palbociclib_Yu2022_PD_ki67_params();
exposure = linspace(0, p.stop_time * p.exposure_per_s, 501);
frac = exposure.^p.gamma ./ (p.EC50^p.gamma + exposure.^p.gamma);
E0 = p.E0; Emax = p.Emax; slope = p.slope;
response = E0.*(1 - Emax.*frac);
figure; plot(exposure, response, 'LineWidth', 1.5); grid on;
xlabel('exposure [ng/mL]'); ylabel('response []'); title('Palbociclib_Yu2022_PD_ki67', 'Interpreter', 'none');
writematrix([exposure(:) response(:)], 'Palbociclib_Yu2022_PD_ki67.csv');
