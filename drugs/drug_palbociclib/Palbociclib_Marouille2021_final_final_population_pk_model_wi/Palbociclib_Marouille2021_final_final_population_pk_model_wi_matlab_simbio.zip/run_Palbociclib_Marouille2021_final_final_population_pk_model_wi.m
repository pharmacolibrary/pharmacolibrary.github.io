% Run (SimBiology): build model + dose, simulate 0..24.0 h, plot.
p = Palbociclib_Marouille2021_final_final_population_pk_model_wi_params();
[model, dose, variant] = build_sb_pk(p);
sd = simulate_sb(model, variant, dose, 24.0);
