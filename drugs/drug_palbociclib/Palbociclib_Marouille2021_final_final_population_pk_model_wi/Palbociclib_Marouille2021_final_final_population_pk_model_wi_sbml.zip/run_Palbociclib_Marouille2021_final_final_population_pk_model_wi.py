#!/usr/bin/env python3
"""Simulate Palbociclib_Marouille2021_final_final_population_pk_model_wi.sbml (0..24.0 h) with Tellurium/libRoadRunner and write results.

Headless-friendly: writes Palbociclib_Marouille2021_final_final_population_pk_model_wi.csv, Palbociclib_Marouille2021_final_final_population_pk_model_wi.json and Palbociclib_Marouille2021_final_final_population_pk_model_wi.png next to this script
(no interactive window). Requires `tellurium` (bundles libRoadRunner + matplotlib).
"""
import json
import os

import matplotlib
matplotlib.use("Agg")                 # non-interactive backend: render straight to PNG
import matplotlib.pyplot as plt
import tellurium as te

BASE = os.path.join(os.path.dirname(os.path.abspath(__file__)), "Palbociclib_Marouille2021_final_final_population_pk_model_wi")

r = te.loadSBMLModel(BASE + ".sbml")
res = r.simulate(0, 24.0, 500, ["time", "Cc"])   # Cc = central concentration [mg/L]
t = [float(x) for x in res[:, 0]]
Cc = [float(x) for x in res[:, 1]]

# machine-readable outputs
with open(BASE + ".csv", "w") as f:
    f.write("time_h,Cc_mg_per_L\n")
    for ti, ci in zip(t, Cc):
        f.write("%r,%r\n" % (ti, ci))
with open(BASE + ".json", "w") as f:
    json.dump({"model": "Palbociclib_Marouille2021_final_final_population_pk_model_wi", "stop_time_h": 24.0,
               "time_h": t, "Cc_mg_per_L": Cc}, f, indent=2)

# plot to PNG (named after the model)
plt.figure()
plt.plot(t, Cc, linewidth=1.5)
plt.xlabel("time [h]"); plt.ylabel("central concentration [mg/L]")
plt.title("Palbociclib_Marouille2021_final_final_population_pk_model_wi"); plt.grid(True, alpha=0.3); plt.tight_layout()
plt.savefig(BASE + ".png", dpi=150)

print("wrote %s.csv, %s.json, %s.png" % (BASE, BASE, BASE))
