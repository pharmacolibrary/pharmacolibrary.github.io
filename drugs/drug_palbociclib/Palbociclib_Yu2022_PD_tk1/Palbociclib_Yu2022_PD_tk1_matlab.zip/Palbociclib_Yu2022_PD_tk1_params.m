function p = Palbociclib_Yu2022_PD_tk1_params()
% Palbociclib_Yu2022_PD_tk1_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% palbociclib Yu_2022::TK1: indirect_response_i exposure-response sweep (response = E0*(1 - Emax*frac)). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one ng/mL per second, in SI inside (kg/m3, s). Response TK1 in its own unit. Driver: palbociclib (cited_pk).
p.E0 = 0.0;
p.Emax = 1.0;
p.EC50 = 5.02e-05;
p.gamma = 1.0;
p.slope = 0.0;
p.exposure_per_s = 1e-06;
p.stop_time = 510.0;
p.form = 'E0*(1 - Emax*frac)';
end
