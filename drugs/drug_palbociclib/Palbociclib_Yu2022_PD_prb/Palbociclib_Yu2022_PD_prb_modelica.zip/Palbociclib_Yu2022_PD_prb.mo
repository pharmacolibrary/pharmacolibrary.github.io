model Palbociclib_Yu2022_PD_prb
  "indirect_response_i exposure-response sweep — Yu_2022 :: pRb (phosphor-retinoblastoma protein in skin tissues)"
  extends Pharmacolibrary.Interfaces.PartialExposureResponseSweep(
    E0 = 0,      // [1]
    Emax = 1,  // type I effect term
    EC50 = 4.52e-05,  // [kg/m3; ng/mL × 1e-06]
    gamma = 1,
    exposure_per_s = 1e-06);   // 1 ng/mL per second
equation
  response = E0*(1 - Emax*frac);   // steady state, indirect response type I
  // defaulted: E0
  // defaulted: Emax
  // defaulted: gamma
  annotation(experiment(StartTime = 0, StopTime = 460, Interval = 0.92),
    Documentation(info = "<html><body><!-- drug-about --><h4>About palbociclib</h4><p>Palbociclib is an anticancer drug used to treat breast cancer, particularly hormone receptor-positive, HER2-negative disease. It is an approved protein kinase inhibitor and is authorised in the European Union for breast cancer treatment.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q15269707\">Wikidata Q15269707</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h4>Palbociclib_Yu2022_PD_prb</h4><p>The steady-state exposure-response curve of Yu Y et al., <i>Journal of clinical pharmacology 62(3):376–384</i> 2022 (<a href=\"https://doi.org/10.1002/jcph.1971\">doi:10.1002/jcph.1971</a>) — phosphor-retinoblastoma protein in skin tissues against palbociclib ng/mL — obtained by sweeping the driver instead of simulating a dose. Model family: indirect_response_i.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = (library default) drug-free response (baseline)
  Emax  = (library default) maximal effect term
  EC50  =       45.2 ng/mL    exposure at half of the maximal effect term (concentration to achieve 50% inhibition of the synthesis rate, Q322)
  gamma = (library default) Hill coefficient</pre><p>The algebra is <code>response = E0*(1 - Emax*frac)</code>; this model only supplies the numbers. The x axis is one ng/mL of palbociclib per second of simulated time (exposure is in kg/m3): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0   (drug-free)
  exposure = EC50 (45.2 ng/mL)  response 0
  exposure -> infinity  response 0</pre></body></html>"));
end Palbociclib_Yu2022_PD_prb;
