model Ticagrelor_Kathman2022_PD_pru
  "sigmoid_emax exposure-response sweep — Kathman_2022 :: PRU (P2Y12 reactivity units)"
  extends Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep(
    E0 = 0,      // [1]
    Emax = -0.0181,  // [1]
    EC50 = 1.06e-05,  // [mol/m3; nmol/L × 1e-06]
    gamma = 1,
    exposure_per_s = 1e-06);   // 1 nmol/L per second
  // imax_as_negative_emax: Imax (Q323) enters SigmoidEmaxSweep as −Emax
  // defaulted: E0
  // defaulted: gamma
  annotation(experiment(StartTime = 0, StopTime = 110, Interval = 0.22),
    Documentation(info = "<html><body><!-- drug-about --><h4>About ticagrelor</h4><p>Ticagrelor is an antiplatelet medicine used to prevent blood clots in people with acute coronary syndrome, including heart attack and unstable angina. It is an approved drug authorised in the European Union and widely used for these heart conditions.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q420542\">Wikidata Q420542</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h4>Ticagrelor_Kathman2022_PD_pru</h4><p>The steady-state exposure-response curve of Kathman SJ et al., <i>CPT: pharmacometrics &amp; systems pharmacology 11(1):68–81</i> 2022 (<a href=\"https://doi.org/10.1002/psp4.12734\">doi:10.1002/psp4.12734</a>) — P2Y12 reactivity units against ticagrelor nmol/L — obtained by sweeping the driver instead of simulating a dose. Model family: sigmoid_emax.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = (library default) drug-free response (baseline)
  Emax  =     0.0181          maximal effect term (Emax for relating TAM to PRU, Q323)
  EC50  =       10.6 nmol/L   exposure at half of the maximal effect term (EC50 for relating TICA to PRU, Q321)
  gamma = (library default) Hill coefficient</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep\">SigmoidEmaxSweep</a>; this model only supplies the numbers. The x axis is one nmol/L of ticagrelor per second of simulated time (exposure is in mol/m3): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0   (drug-free)
  exposure = EC50 (10.6 nmol/L)  response -0.00905
  exposure -> infinity  response -0.0181</pre></body></html>"));
end Ticagrelor_Kathman2022_PD_pru;
