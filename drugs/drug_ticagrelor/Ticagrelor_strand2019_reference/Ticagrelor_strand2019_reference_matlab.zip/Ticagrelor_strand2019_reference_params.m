function p = Ticagrelor_strand2019_reference_params()
% Auto-generated parent-metabolite PK model (clinical units: mg, L, h).
%   drug: ticagrelor   source: Åstrand_2019 / reference   PK_3M_9C parent + 1 metabolite(s), 4 compartments, oral
%   dA/dt = K*A; C = A./V. K(i,j) is the rate [1/h] at which compartment j feeds i:
%   a metabolic conversion carries MW_dst/MW_src, so one molecule forms one molecule.
%   molar masses: C_central=522.568 g/mol C_M1=478.518 g/mol
  p.name  = 'Ticagrelor_strand2019_reference_params';
  p.drug  = 'ticagrelor';
  p.kind  = 'network';
  p.template = 'PK_3M_9C';
  p.states = {'central', 'peripheral', 'central_M1', 'peripheral_M1'};
  p.V = [156.0, 55.8, 7.04, 42.3];          % compartment volumes [L]
  p.K = [-0.17307692307692307, 0.18637992831541222, 0.0, 0.0;
         0.06666666666666668, -0.18637992831541222, 0.0, 0.0;
         0.021436883002639035, 0.0, -2.075284090909091, 0.10425531914893618;
         0.0, 0.0, 0.6264204545454546, -0.10425531914893618];
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;
  p.dose_into = 1;   % central
  p.ka = 10.1;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.48;             % absorption lag [h] (in dose_start)
  p.dose = 60.0;             % dose [mg]
  p.dose_start = 0.49666666666666665;   % dose enters from [h] ...
  p.dose_duration = 0.16666666666666666;   % ... at a constant rate for [h]
  p.out_idx = [1.0, 3.0];
  p.out_names = {'C_central', 'C_M1'};
  p.out_labels = {'ticagrelor', 'AR-C124910XX'};
end
