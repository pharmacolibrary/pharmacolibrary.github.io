#!/usr/bin/env python3
"""Simulate Ticagrelor_strand2019_reference.sbml (0..33.0 h) — a parent and its metabolites — with Tellurium/
libRoadRunner; writes Ticagrelor_strand2019_reference.csv, Ticagrelor_strand2019_reference.json and Ticagrelor_strand2019_reference.png next to this script."""
import json
import os

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import tellurium as te

BASE = os.path.join(os.path.dirname(os.path.abspath(__file__)), "Ticagrelor_strand2019_reference")
OUT = {'C_central': 'ticagrelor', 'C_M1': 'AR-C124910XX'}                        # output -> molecule
r = te.loadSBMLModel(BASE + ".sbml")
r.integrator.relative_tolerance = 1e-8
r.integrator.absolute_tolerance = 1e-12
res = r.simulate(0, 33.0, 2001, ["time"] + list(OUT))
t = [float(x) for x in res[:, 0]]
cols = {o: [float(x) for x in res[:, i + 1]] for i, o in enumerate(OUT)}

with open(BASE + ".csv", "w") as f:
    f.write("time_h," + ",".join(o + "_mg_per_L" for o in OUT) + "\n")
    for k, ti in enumerate(t):
        f.write("%r," % ti + ",".join("%r" % cols[o][k] for o in OUT) + "\n")
with open(BASE + ".json", "w") as f:
    json.dump({"model": "Ticagrelor_strand2019_reference", "stop_time_h": 33.0, "labels": OUT, "time_h": t,
               **{o + "_mg_per_L": cols[o] for o in OUT}}, f, indent=2)

plt.figure()
for o in OUT:
    plt.semilogy(t, [max(c, 1e-12) for c in cols[o]], linewidth=1.5, label=f"{OUT[o]} ({o})")
plt.xlabel("time [h]"); plt.ylabel("concentration [mg/L]"); plt.legend()
plt.title("Ticagrelor_strand2019_reference"); plt.grid(True, alpha=0.3); plt.tight_layout()
plt.savefig(BASE + ".png", dpi=150)
print("wrote %s.csv, %s.json, %s.png" % (BASE, BASE, BASE))
