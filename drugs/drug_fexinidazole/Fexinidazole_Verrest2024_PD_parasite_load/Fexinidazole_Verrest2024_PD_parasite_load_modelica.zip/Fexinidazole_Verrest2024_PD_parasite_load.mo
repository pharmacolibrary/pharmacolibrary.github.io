model Fexinidazole_Verrest2024_PD_parasite_load
  "linear exposure-response sweep — Verrest_2024 :: parasite load (blood Leishmania parasite load (kDNA qPCR))"
  extends Pharmacolibrary.Interfaces.PartialExposureResponseSweep(
    E0 = 0,      // [1]
    Emax = 0, EC50 = 1,      // unused by a line
    exposure_per_s = 1e-06);
  parameter Real slope = 0.0011   "[μg-1*L*h-1]";
equation
  response = E0 + slope*exposure;
  // defaulted: E0
  annotation(experiment(StartTime = 0, StopTime = 1000, Interval = 2),
    Documentation(info = "<html><body><!-- drug-about --><h4>About fexinidazole</h4><p>Fexinidazole is an antiprotozoal medicine used to treat trypanosomiasis (sleeping sickness). It is an approved medicine and is used mainly in regions where the disease occurs.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q5446115\">Wikidata Q5446115</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h4>Fexinidazole_Verrest2024_PD_parasite_load</h4><p>The steady-state exposure-response curve of Verrest L et al., <i>PLoS neglected tropical diseases 18(4):e0012078</i> 2024 (<a href=\"https://doi.org/10.1371/journal.pntd.0012078\">doi:10.1371/journal.pntd.0012078</a>) — blood Leishmania parasite load (kDNA qPCR) [parasites/mL] against fexinidazole (sum of M1 and M2 metabolites) μg/L — obtained by sweeping the driver instead of simulating a dose. Model family: linear.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = (library default) drug-free response (baseline)
  slope =     0.0011 μg-1*L*h-1 change in response per unit of exposure (λfexi, Q335)</pre><p>The algebra is <code>response = E0 + slope*exposure</code>; this model only supplies the numbers. The x axis is one μg/L of fexinidazole (sum of M1 and M2 metabolites) per second of simulated time (exposure is in kg/m3): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0   (drug-free)</pre></body></html>"));
end Fexinidazole_Verrest2024_PD_parasite_load;
