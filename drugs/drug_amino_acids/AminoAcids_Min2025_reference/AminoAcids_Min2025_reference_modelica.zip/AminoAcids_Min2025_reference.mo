model AminoAcids_Min2025_reference
  parameter Real Cl_ref = 2.5277777777777778e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.028300000000000002 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    adminMass = 0.0001,
    ka = 0.0001388888888888889,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About amino_acids</h4><p>Amino acid solutions are used to provide parenteral nutrition, and an amino acid product is authorised in the European Union for treating maple syrup urine disease. DrugBank classifies amino acids as investigational, so their use as a drug is not established.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q8066\">Wikidata Q8066</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>amino_acids</td></tr><tr><td>population:</td><td>review reference</td></tr><tr><td>source_paper:</td><td>Min_2025</td></tr><tr><td>measured_compound:</td><td>amino_acids</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C_enteral: apparent (/F) parameterization ⇒ extravascular dosing</td></tr></table><p><b>Defaulted (base-class default used):</b> ka, Tlag.</p><h4>Interpretation flags</h4><ul><li>built from REVIEW reference values (Min_2025) — secondary source</li><li>volume reported by review</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end AminoAcids_Min2025_reference;
