model Flumequine_Mevius1990_reference
  parameter Real Cl_ref = 2.0766666666666665e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.1323 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.2612484,
    adminMass = 1e-05
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About flumequine</h4><p>Flumequine is a quinolone antibacterial that was used to treat bacterial infections, particularly urinary tract infections. It has been withdrawn and is no longer in use.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q3074500\">Wikidata Q3074500</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>flumequine</td></tr><tr><td>population:</td><td>1-, 5- and 18-week-old veal calves</td></tr><tr><td>source_paper:</td><td>Mevius_1990</td></tr><tr><td>measured_compound:</td><td>flumequine</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_2C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>flumequine 261.248 g/mol (drugbank)</td></tr></table><p><b>Defaulted (base-class default used):</b> k12, k21.</p><h4>Interpretation flags</h4><ul><li>dropped value-less row: 'The elimination half-life (t1/2 beta)' (captured trailing unit 't1/2 beta' for child rows)</li><li>dropped duplicate Q23 ('ClB ... of ... 5-week-old ... calves', value 3.23) — already have one for this compound</li><li>dropped duplicate Q23 ('ClB ... of ... 18-week-old calves', value 3.1) — already have one for this compound</li><li>dropped duplicate Q32 ('Cmax ... in 18-week-old calves', value 4.47) — already have one for this compound</li><li>dropped value-less row: 'Tmax'</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=flumequine</li><li>structure disagreement: deterministic 2C vs LLM 1C — review compartment count</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 259200, Tolerance = 1e-9, Interval = 1));
end Flumequine_Mevius1990_reference;
