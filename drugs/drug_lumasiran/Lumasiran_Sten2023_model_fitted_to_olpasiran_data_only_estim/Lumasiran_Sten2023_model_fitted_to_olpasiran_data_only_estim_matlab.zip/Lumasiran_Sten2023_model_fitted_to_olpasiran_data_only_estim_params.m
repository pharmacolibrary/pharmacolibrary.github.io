function p = Lumasiran_Sten2023_model_fitted_to_olpasiran_data_only_estim_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: lumasiran   source: Sten_2023 / model_fitted_to_olpasiran_data_only_estimate_se   route: oral
  p.name  = 'Lumasiran_Sten2023_model_fitted_to_olpasiran_data_only_estim_params';
  p.drug  = 'lumasiran';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 27.9;                % central volume [L]
  p.CL = 27.7;                % clearance [L/h]
  p.Vp = [1470.0];             % peripheral volumes [L]
  p.Q  = [2.62];             % inter-compartmental clearances [L/h]
  p.ka = 0.635;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 25.0;             % dose [mg]
end
