% Run (SimBiology): build model + dose, simulate 0..24.0 h, plot.
p = Lumasiran_Sten2023_model_simultaneously_fitted_to_all_data_e_params();
[model, dose, variant] = build_sb_pk(p);
sd = simulate_sb(model, variant, dose, 24.0);
