model Lumasiran_Sten2023_model_simultaneously_fitted_to_all_data_e
  parameter Real Cl_ref = 6.6111111111111115e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.0181 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    adminMass = 2.5e-05,
    ka = 4.361111111111111e-05,
    Tlag = 0.0,
    k21 = 6.260364842454395e-07
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About lumasiran</h4><p>Lumasiran, a small interfering RNA medicine, is used to treat primary hyperoxaluria. It is authorised in the European Union.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q100692768\">Wikidata Q100692768</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>lumasiran</td></tr><tr><td>population:</td><td>healthy adults and patients with primary hyperoxaluria type 1</td></tr><tr><td>source_paper:</td><td>Sten_2023</td></tr><tr><td>measured_compound:</td><td>lumasiran</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>Tab3</td></tr><tr><td>input:</td><td>PK_2C_enteral: absorption rate constant reported</td></tr></table><p><b>Defaulted (base-class default used):</b> Tlag, k12.</p><h4>Interpretation flags</h4><ul><li>dropped duplicate Q27 ('CL3/F (L/h)', value '45.4') — already have one for this compound</li><li>implicit units: 'Ka (1/h)' → 1/h (from the popPK convention: &quot;The paper text describes the parameter as 'absorption rate (Ka)' and 'first-order absorption'. In population pharmacokin&quot;)</li><li>apparent-ness (ontology-grounded): parameterization=apparent, measured_compound=lumasiran</li><li>structure disagreement: deterministic 2C vs LLM 3C — review compartment count</li><li>population split: 'model simultaneously fitted to all data [estimate (se)]' subgroup of Sten_2023 (paper reports 2 populations: model fitted to olpasiran data only [estimate (se)], model simultaneously fitted to all data [estimate (se)])</li><li>molar mass: none found for 'lumasiran' — its concentrations stay mass-only</li><li>skipped review gap-fill of TLAG: primary's parameterization (rate-constant / ka-only) does not use it</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Lumasiran_Sten2023_model_simultaneously_fitted_to_all_data_e;
