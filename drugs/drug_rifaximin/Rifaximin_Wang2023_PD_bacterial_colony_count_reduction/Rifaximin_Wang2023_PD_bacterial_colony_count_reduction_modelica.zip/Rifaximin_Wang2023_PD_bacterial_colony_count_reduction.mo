model Rifaximin_Wang2023_PD_bacterial_colony_count_reduction
  "sigmoid_emax exposure-response sweep — Wang_2023 :: bacterial colony count reduction (name)"
  extends Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep(
    E0 = 0,      // [1]
    Emax = -2.36,  // [log10 CFU/gland]
    EC50 = 2.36,  // [log10 CFU/gland]
    gamma = 1,
    exposure_per_s = 1);   // 1 log10 CFU/gland per second
  // inhibition_sign: effect_direction=inhibition with a positive Emax (Q320) — sign flipped
  // exposure_unit_unresolved: 'log10 CFU/gland' — the x axis is in the paper's unit, not SI
  // defaulted: E0
  // defaulted: gamma
  annotation(experiment(StartTime = 0, StopTime = 24, Interval = 0.048),
    Documentation(info = "<html><body><h4>Rifaximin_Wang2023_PD_bacterial_colony_count_reduction</h4><p>The steady-state exposure-response curve of Wang H et al., <i>BMC veterinary research 19(1):19</i> 2023 (<a href=\"https://doi.org/10.1186/s12917-022-03564-2\">doi:10.1186/s12917-022-03564-2</a>) — name [log10CFU/gland] against rifaximin log10 CFU/gland — obtained by sweeping the driver instead of simulating a dose. Model family: sigmoid_emax.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = (library default) drug-free response (baseline)
  Emax  =       2.36 log10 CFU/gland maximal effect term (Emax, Q320)
  EC50  =       2.36 log10 CFU/gland exposure at half of the maximal effect term (EC50, Q321)
  gamma = (library default) Hill coefficient</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep\">SigmoidEmaxSweep</a>; this model only supplies the numbers. The x axis is one log10 CFU/gland of rifaximin per second of simulated time: there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0   (drug-free)
  exposure = EC50 (2.36 log10 CFU/gland)  response -1.18
  exposure -> infinity  response -2.36</pre></body></html>"));
end Rifaximin_Wang2023_PD_bacterial_colony_count_reduction;
