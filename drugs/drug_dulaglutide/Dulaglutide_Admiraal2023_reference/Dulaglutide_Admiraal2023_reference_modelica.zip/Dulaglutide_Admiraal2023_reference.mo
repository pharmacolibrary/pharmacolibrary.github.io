model Dulaglutide_Admiraal2023_reference
  parameter Real Cl_ref = 3.416666666666667e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.01 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    adminMass = 1.6e-07
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About dulaglutide</h4><p>Dulaglutide is a GLP-1 analogue anti-diabetic medicine used to lower blood glucose, mainly in type 2 diabetes. It is authorised in the European Union and is used widely as an approved diabetes treatment.</p><p><small>Summary written by glm-5.3-flash from <a href=&quot;https://www.wikidata.org/wiki/Q21011228&quot;>Wikidata Q21011228</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>dulaglutide</td></tr><tr><td>population:</td><td>review reference</td></tr><tr><td>source_paper:</td><td>Admiraal_2023</td></tr><tr><td>measured_compound:</td><td>dulaglutide</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C: IV (no input phase)</td></tr></table><h4>Interpretation flags</h4><ul><li>built from REVIEW reference values (Admiraal_2023) — secondary source</li><li>volume reported by review</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Dulaglutide_Admiraal2023_reference;
