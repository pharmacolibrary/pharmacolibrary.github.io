model Dulaglutide_Zheng2023_PD_ei
  "linear exposure-response sweep — Zheng_2023 :: EI (energy intake)"
  extends Pharmacolibrary.Interfaces.PartialExposureResponseSweep(
    E0 = 0,      // [1]
    Emax = 0, EC50 = 1,      // unused by a line
    exposure_per_s = 1e-06);
  parameter Real slope = -2700   "[meter ** 3 / kilogram; %/1 ng/mL × 10000]";
equation
  response = E0 + slope*exposure;
  // defaulted: E0
  annotation(experiment(StartTime = 0, StopTime = 1000, Interval = 2),
    Documentation(info = "<html><body><!-- drug-about --><h4>About dulaglutide</h4><p>Dulaglutide is a GLP-1 analogue anti-diabetic medicine used to lower blood glucose, mainly in type 2 diabetes. It is authorised in the European Union and is used widely as an approved diabetes treatment.</p><p><small>Summary written by glm-5.3-flash from <a href=&quot;https://www.wikidata.org/wiki/Q21011228&quot;>Wikidata Q21011228</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h4>Dulaglutide_Zheng2023_PD_ei</h4><p>The steady-state exposure-response curve of Zheng S et al., <i>Clinical and translational science 16(8):1431-1444</i> 2023 (<a href=\"https://doi.org/10.1111/cts.13543\">doi:10.1111/cts.13543</a>) — energy intake [%] against dulaglutide ng/mL — obtained by sweeping the driver instead of simulating a dose. Model family: linear.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = (library default) drug-free response (baseline)
  slope =      -0.27 %/1 ng/mL change in response per unit of exposure (E dula, Q335)</pre><p>The algebra is <code>response = E0 + slope*exposure</code>; this model only supplies the numbers. The x axis is one ng/mL of dulaglutide per second of simulated time (exposure is in kg/m3): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0   (drug-free)</pre></body></html>"));
end Dulaglutide_Zheng2023_PD_ei;
