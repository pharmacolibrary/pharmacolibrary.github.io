function p = Dulaglutide_Zheng2023_PD_ei_params()
% Dulaglutide_Zheng2023_PD_ei_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% dulaglutide Zheng_2023::EI: linear exposure-response sweep (response = E0 + slope*exposure). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one ng/mL per second, in SI inside (kg/m3, s). Response EI in %. Driver: dulaglutide (pk_record).
p.E0 = 0.0;
p.Emax = 0.0;
p.EC50 = 1.0;
p.gamma = 1.0;
p.slope = -2700.0000000000014;
p.exposure_per_s = 1e-06;
p.stop_time = 1000.0;
p.form = 'E0 + slope*exposure';
end
