function p = Hydroquinine_van2000_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: hydroquinine   source: van_2000 / reference   route: iv_bolus
  % estimated (absent from source): F, dose
  p.name  = 'Hydroquinine_van2000_reference_params';
  p.drug  = 'hydroquinine';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'iv_bolus';        % 'oral' | 'iv_bolus'
  p.depot = false;             % oral -> first-order absorption depot
  p.Vc = 86.8;                % central volume [L]
  p.CL = 6.7;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.0;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 10.0;             % dose [mg]
end
