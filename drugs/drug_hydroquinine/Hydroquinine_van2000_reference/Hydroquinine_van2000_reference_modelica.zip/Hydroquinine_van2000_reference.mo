model Hydroquinine_van2000_reference
  parameter Real Cl_ref = 1.8611111111111113e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.0868 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.32644,
    adminMass = 1e-05
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About hydroquinine</h4><p>Hydroquinine, a quinine derivative, is classified among drugs for disorders of the musculo-skeletal system. It is not an established marketed medicine; it is listed only as an experimental compound, so its current clinical use is unclear.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q5276450\">Wikidata Q5276450</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>hydroquinine</td></tr><tr><td>population:</td><td>adult patients with muscle cramps</td></tr><tr><td>source_paper:</td><td>van_2000</td></tr><tr><td>measured_compound:</td><td>hydroquinine</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>hydroquinine 326.44 g/mol (drugbank)</td></tr></table><h4>Interpretation flags</h4><ul><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=hydroquinine</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 259200, Tolerance = 1e-9, Interval = 1));
end Hydroquinine_van2000_reference;
