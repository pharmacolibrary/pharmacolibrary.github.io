function p = Liraglutide_Guo2025_PD_weight_params()
% Liraglutide_Guo2025_PD_weight_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% liraglutide Guo_2025::Weight: emax exposure-response sweep (response = E0 + Emax*frac). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one mg per second, in SI inside (kg/m3, s). Response ΔΔWeight in kg. Driver: Liraglutide (dose_only).
p.E0 = 0.0;
p.Emax = 4.25;
p.EC50 = 2.19e-07;
p.gamma = 1.0;
p.slope = 0.0;
p.exposure_per_s = 1e-06;
p.stop_time = 2.2;
p.form = 'E0 + Emax*frac';
end
