model Liraglutide_Guo2025_PD_weight
  "emax exposure-response sweep — Guo_2025 :: ΔΔWeight (weight reduction)"
  extends Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep(
    E0 = 0,      // [1]
    Emax = 4.25,  // [kg; kg × 1]
    EC50 = 2.19e-07,  // [kg; mg × 1e-06]
    gamma = 1,
    exposure_per_s = 1e-06);   // 1 mg per second
  // defaulted: E0
  // defaulted: gamma
  annotation(experiment(StartTime = 0, StopTime = 2.2, Interval = 0.0044),
    Documentation(info = "<html><body><!-- drug-about --><h4>About liraglutide</h4><p>Liraglutide is a GLP-1 analogue used as an anti-diabetic medicine to treat type 2 diabetes and glucose intolerance, and is also authorised for obesity and overweight. It is approved and authorised in the European Union, and is widely used for diabetes care.</p><p><small>Summary written by glm-5.3-flash from <a href=&quot;https://www.wikidata.org/wiki/Q2526479&quot;>Wikidata Q2526479</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h4>Liraglutide_Guo2025_PD_weight</h4><p>The steady-state exposure-response curve of Guo H et al., <i>Obesity pillars 13:100162</i> 2025 (<a href=\"https://doi.org/10.1016/j.obpill.2025.100162\">doi:10.1016/j.obpill.2025.100162</a>) — weight reduction [kg] against Liraglutide mg — obtained by sweeping the driver instead of simulating a dose. Model family: emax.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = (library default) drug-free response (baseline)
  Emax  =       4.25 kg       maximal effect term (Emax, Q320)
  EC50  =      0.219 mg       exposure at half of the maximal effect term (effective doses (doses achieving 50 % of the Emax value) of Cotadutide, Q321)
  gamma = (library default) Hill coefficient</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep\">SigmoidEmaxSweep</a>; this model only supplies the numbers. The x axis is one mg of Liraglutide per second of simulated time (exposure is in kg): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0   (drug-free)
  exposure = EC50 (0.219 mg)  response 2.125
  exposure -> infinity  response 4.25</pre></body></html>"));
end Liraglutide_Guo2025_PD_weight;
