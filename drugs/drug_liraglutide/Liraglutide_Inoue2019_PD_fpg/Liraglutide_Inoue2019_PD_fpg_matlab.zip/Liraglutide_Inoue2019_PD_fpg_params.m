function p = Liraglutide_Inoue2019_PD_fpg_params()
% Liraglutide_Inoue2019_PD_fpg_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% liraglutide Inoue_2019::FPG: indirect_response_i exposure-response sweep (response = E0*(1 - Emax*frac)). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one mg day À1 per second, in SI inside (kg/m3, s). Response FPG in mg dl À1. Driver: liraglutide (dose_only).
p.E0 = 1.6499999999999997;
p.Emax = 0.266;
p.EC50 = 4.3634259259259255e-12;
p.gamma = 1.0;
p.slope = 0.0;
p.exposure_per_s = 1.15740740741e-11;
p.stop_time = 3.8;
p.form = 'E0*(1 - Emax*frac)';
end
