model Liraglutide_Carlsson2021_reference
  parameter Real Cl_ref = 2.9722222222222224e-07 "Cl [m3/s]";
  parameter Real cov_sex_0 = 0 "sex covariate";
  parameter Real cov_age_1 = 0 "age covariate";
  parameter Real cov_age_2 = 0 "age covariate";
  parameter Real Vd_ref = 0.0131 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref*(1 + (1.12)*cov_sex_0)*(1 + (1.11)*cov_age_1)*(1 + (1.06)*cov_age_2),
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 3.751262,
    adminMass = 3e-06,
    ka = 2.2333333333333332e-05,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About liraglutide</h4><p>Liraglutide is a GLP-1 analogue used as an anti-diabetic medicine to treat type 2 diabetes and glucose intolerance, and is also authorised for obesity and overweight. It is approved and authorised in the European Union, and is widely used for diabetes care.</p><p><small>Summary written by glm-5.3-flash from <a href=&quot;https://www.wikidata.org/wiki/Q2526479&quot;>Wikidata Q2526479</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>liraglutide</td></tr><tr><td>population:</td><td>children, adolescents and adults with obesity</td></tr><tr><td>source_paper:</td><td>Carlsson_2021</td></tr><tr><td>measured_compound:</td><td>liraglutide</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>ijpo12799-tbl-0003</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>liraglutide 3751.26 g/mol (pubchem)</td></tr></table><p><b>Defaulted (base-class default used):</b> Tlag.</p><h4>Interpretation flags</h4><ul><li>table section iiv: 'Apparent clearance' routed out of structural estimates ('IIV (%CV)')</li><li>table section iiv: 'Apparent volume of distribution' routed out of structural estimates ('IIV (%CV)')</li><li>table section iiv: 'Apparent clearance' routed out of structural estimates ('IIV (%CV)')</li><li>table section iiv: 'Apparent volume of distribution' routed out of structural estimates ('IIV (%CV)')</li><li>column 'parameter symbol (unit)' classified 'other' by the LLM but kept: the deterministic diagnostic-column test disagrees (a stratum column is a value column, not a statistic)</li><li>column 'parameter symbol (unit)' classified 'other' by the LLM but kept: the deterministic diagnostic-column test disagrees (a stratum column is a value column, not a statistic)</li><li>covariate level 'Sex contrast (male/female) on CL/F' → Q900:sex_contrast_male_female_on_cl_f = 1.12 (linear_fractional on Q27)</li><li>covariate level 'Age contrast (child/adult) on CL/F' → Q900:age_contrast_child_adult_on_cl_f = 1.11 (linear_fractional on Q27)</li><li>covariate level 'Age contrast (adolescent/adult) on CL/F' → Q900:age_contrast_adolescent_adult_on_cl_f = 1.06 (linear_fractional on Q27)</li><li>dropped unlinked row (NIL): 'NA' — extend the ontology if this is a real PK parameter (source ['ijpo12799-tbl-0003:row9:col2', 'Carlsson_2021_table_S1:row3:col2'])</li><li>covariate effect for Q319 has no base parameter row (kept as unattached equation-variable)</li><li>covariate effect for Q319 has no base parameter row (kept as unattached equation-variable)</li><li>implicit units: 'Absorption rate constant' → 1/h (from the popPK convention: 'The paper does not explicitly state the unit for the absorption rate constant (kabs). In population pharmacokinetic mode')</li><li>implicit units: 'Apparent clearance' → L/h (from the popPK convention: 'The paper does not explicitly state the unit for apparent clearance (CL/F). In population PK, clearance parameters are c')</li><li>implicit units: 'Apparent volume of distribution' → L (from the popPK convention: 'The paper does not explicitly state the unit for apparent volume of distribution (V/F). In population PK, volume paramet')</li><li>apparent-ness (ontology-grounded): parameterization=apparent, measured_compound=liraglutide</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 345600, Tolerance = 1e-9, Interval = 1));
end Liraglutide_Carlsson2021_reference;
