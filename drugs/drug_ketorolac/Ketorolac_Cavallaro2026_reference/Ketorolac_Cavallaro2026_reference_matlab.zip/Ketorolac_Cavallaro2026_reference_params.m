function p = Ketorolac_Cavallaro2026_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: ketorolac   source: Cavallaro_2026 / reference   route: iv_bolus
  % estimated (absent from source): F
  p.name  = 'Ketorolac_Cavallaro2026_reference_params';
  p.drug  = 'ketorolac';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'iv_bolus';        % 'oral' | 'iv_bolus'
  p.depot = false;             % oral -> first-order absorption depot
  p.Vc = 329.0;                % central volume [L]
  p.CL = 45.57;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.0;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 30.0;             % dose [mg]
end
