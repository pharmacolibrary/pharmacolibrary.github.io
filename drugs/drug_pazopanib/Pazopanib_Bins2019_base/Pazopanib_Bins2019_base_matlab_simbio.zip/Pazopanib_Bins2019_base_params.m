function p = Pazopanib_Bins2019_base_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: pazopanib   source: Bins_2019 / base   route: oral
  % estimated (absent from source): F
  p.name  = 'Pazopanib_Bins2019_base_params';
  p.drug  = 'pazopanib';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 2.39;                % central volume [L]
  p.CL = 0.27;                % clearance [L/h]
  p.Vp = [25.3];             % peripheral volumes [L]
  p.Q  = [0.99];             % inter-compartmental clearances [L/h]
  p.ka = 0.38;                % absorption rate [1/h]
  p.F  = 0.9;                 % bioavailability [0-1]
  p.Tlag = 0.98;             % absorption lag [h]
  p.dose = 200.0;             % dose [mg]
end
