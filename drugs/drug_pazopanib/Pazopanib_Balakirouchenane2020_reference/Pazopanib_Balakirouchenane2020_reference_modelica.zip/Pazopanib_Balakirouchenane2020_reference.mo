model Pazopanib_Balakirouchenane2020_reference
  parameter Real Cl_ref = 4.9166666666666665e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.0257 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.43751799999999996,
    adminMass = 0.0008,
    ka = 0.0005,
    Tlag = 1800.0,
    k12 = 4.16126242974492e-05,
    k21 = 2.707454289732771e-05
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About pazopanib</h4><p>Pazopanib is a protein kinase inhibitor used to treat kidney cancer, especially renal cell carcinoma, and other tumours such as gastrointestinal stromal tumours and soft-tissue sarcomas. It is an approved anticancer medicine authorised in the European Union for renal cell carcinoma.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q7157043\">Wikidata Q7157043</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>pazopanib</td></tr><tr><td>population:</td><td>review reference</td></tr><tr><td>source_paper:</td><td>Balakirouchenane_2020</td></tr><tr><td>measured_compound:</td><td>pazopanib</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_2C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>pazopanib 437.518 g/mol (drugbank)</td></tr></table><h4>Interpretation flags</h4><ul><li>built from REVIEW reference values (Balakirouchenane_2020) — secondary source</li><li>volume reported by review</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Pazopanib_Balakirouchenane2020_reference;
