function p = Pazopanib_Balakirouchenane2020_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: pazopanib   source: Balakirouchenane_2020 / reference   route: oral
  p.name  = 'Pazopanib_Balakirouchenane2020_reference_params';
  p.drug  = 'pazopanib';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 25.7;                % central volume [L]
  p.CL = 17.7;                % clearance [L/h]
  p.Vp = [39.5];             % peripheral volumes [L]
  p.Q  = [3.85];             % inter-compartmental clearances [L/h]
  p.ka = 1.8;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.5;             % absorption lag [h]
  p.dose = 800.0;             % dose [mg]
end
