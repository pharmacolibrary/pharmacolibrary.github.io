function p = Pazopanib_Bins2019_final_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: pazopanib   source: Bins_2019 / final   route: oral
  % estimated (absent from source): F
  p.name  = 'Pazopanib_Bins2019_final_params';
  p.drug  = 'pazopanib';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 2.4;                % central volume [L]
  p.CL = 0.28;                % clearance [L/h]
  p.Vp = [24.3];             % peripheral volumes [L]
  p.Q  = [0.97];             % inter-compartmental clearances [L/h]
  p.ka = 0.39;                % absorption rate [1/h]
  p.F  = 0.9;                 % bioavailability [0-1]
  p.Tlag = 0.97;             % absorption lag [h]
  p.dose = 200.0;             % dose [mg]
end
