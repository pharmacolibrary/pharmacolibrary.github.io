model Pazopanib_Bins2019_final
  parameter Real Cl_ref = 7.777777777777778e-08 "Cl [m3/s]";
  parameter Real cov_cyp3a4_0 = 0 "cyp3a4 covariate";
  parameter Real Vd_ref = 0.0024 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C_enteral(
    weight = 70.0,
    F = 466.0,
    Cl = Cl_ref*(1 + (0.18)*cov_cyp3a4_0),
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.43751799999999996,
    adminMass = 0.0002,
    ka = 0.00010833333333333334,
    Tlag = 3492.0,
    k12 = 0.00011226851851851852,
    k21 = 1.1088248742569729e-05
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About pazopanib</h4><p>Pazopanib is a protein kinase inhibitor used to treat kidney cancer, especially renal cell carcinoma, and other tumours such as gastrointestinal stromal tumours and soft-tissue sarcomas. It is an approved anticancer medicine authorised in the European Union for renal cell carcinoma.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q7157043\">Wikidata Q7157043</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>pazopanib</td></tr><tr><td>population:</td><td>cancer patients</td></tr><tr><td>source_paper:</td><td>Bins_2019</td></tr><tr><td>measured_compound:</td><td>pazopanib</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>Tab4</td></tr><tr><td>input:</td><td>PK_2C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>pazopanib 437.518 g/mol (drugbank)</td></tr></table><h4>Interpretation flags</h4><ul><li>table section iiv: 'Fast absorption rate constant' routed out of structural estimates ('Between-subject variability')</li><li>table section iiv: 'Clearance' routed out of structural estimates ('Between-subject variability')</li><li>table section iiv: 'Volume of distribution of peripheral compartment' routed out of structural estimates ('Between-subject variability')</li><li>table section iiv: 'Relative bioavailability' routed out of structural estimates ('Between-subject variability')</li><li>column 'final model estimates [rse (%)]' classified 'rse' by the LLM but kept as the estimate: the header names the point value</li><li>column 'final model estimates [rse (%)]' classified 'rse' by the LLM but kept as the estimate: the header names the point value</li><li>column 'final model estimates [rse (%)]' classified 'rse' by the LLM but kept as the estimate: the header names the point value</li><li>column 'final model estimates [rse (%)]' classified 'rse' by the LLM but kept as the estimate: the header names the point value</li><li>column 'final model estimates [rse (%)]' classified 'rse' by the LLM but kept as the estimate: the header names the point value</li><li>column 'final model estimates [rse (%)]' classified 'rse' by the LLM but kept as the estimate: the header names the point value</li><li>column 'final model estimates [rse (%)]' classified 'rse' by the LLM but kept as the estimate: the header names the point value</li><li>column 'final model estimates [rse (%)]' classified 'rse' by the LLM but kept as the estimate: the header names the point value</li><li>column 'final model estimates [rse (%)]' classified 'rse' by the LLM but kept as the estimate: the header names the point value</li><li>column 'final model estimates [rse (%)]' classified 'rse' by the LLM but kept as the estimate: the header names the point value</li><li>column 'final model estimates [rse (%)]' classified 'rse' by the LLM but kept as the estimate: the header names the point value</li><li>column 'final model estimates [rse (%)]' classified 'rse' by the LLM but kept as the estimate: the header names the point value</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 136800, Tolerance = 1e-9, Interval = 1));
end Pazopanib_Bins2019_final;
