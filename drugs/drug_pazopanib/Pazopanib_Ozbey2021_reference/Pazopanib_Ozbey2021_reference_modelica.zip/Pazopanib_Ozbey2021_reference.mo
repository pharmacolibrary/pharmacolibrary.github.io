model Pazopanib_Ozbey2021_reference
  parameter Real Cl_ref = 1.2722222222222223e-07 "Cl [m3/s]";
  parameter Real Vd_ref = 0.0223 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.43751799999999996,
    adminMass = 0.0008,
    ka = 0.00027111111111111113,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About pazopanib</h4><p>Pazopanib is a protein kinase inhibitor used to treat kidney cancer, especially renal cell carcinoma, and other tumours such as gastrointestinal stromal tumours and soft-tissue sarcomas. It is an approved anticancer medicine authorised in the European Union for renal cell carcinoma.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q7157043\">Wikidata Q7157043</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>pazopanib</td></tr><tr><td>population:</td><td>patients with cancer</td></tr><tr><td>source_paper:</td><td>Ozbey_2021</td></tr><tr><td>measured_compound:</td><td>pazopanib</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>pharmaceuticals-14-00927-t001</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>pazopanib 437.518 g/mol (drugbank)</td></tr></table><p><b>Defaulted (base-class default used):</b> Tlag.</p><h4>Interpretation flags</h4><ul><li>table section iiv: 'ka (h−1)' routed out of structural estimates ('IIV(RSE%)')</li><li>table section iiv: 'V/F (L)' routed out of structural estimates ('IIV(RSE%)')</li><li>table section iov: 'V/F (L)' routed out of structural estimates ('IOV(RSE%)')</li><li>table section iiv: 'Cl/F (L·h−1)' routed out of structural estimates ('IIV(RSE%)')</li><li>table section iov: 'Cl/F (L·h−1)' routed out of structural estimates ('IOV(RSE%)')</li><li>column 'value(rse%)' classified 'rse' by the LLM but kept as the estimate: the header names the point value</li><li>column 'value(rse%)' classified 'rse' by the LLM but kept as the estimate: the header names the point value</li><li>column 'value(rse%)' classified 'rse' by the LLM but kept as the estimate: the header names the point value</li><li>column 'value(rse%)' classified 'rse' by the LLM but kept as the estimate: the header names the point value</li><li>column 'value(rse%)' classified 'rse' by the LLM but kept as the estimate: the header names the point value</li><li>apparent-ness (ontology-grounded): parameterization=apparent, measured_compound=pazopanib</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of TLAG: primary's parameterization (rate-constant / ka-only) does not use it</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 691200, Tolerance = 1e-9, Interval = 1));
end Pazopanib_Ozbey2021_reference;
