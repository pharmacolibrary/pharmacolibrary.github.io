model Pazopanib_Wan2025_PD_mmp
  "indirect_response_i exposure-response sweep — Wan_2025 :: MMP (mitochondrial membrane potential)"
  extends Pharmacolibrary.Interfaces.PartialExposureResponseSweep(
    E0 = 0,      // [1]
    Emax = 1,  // type I effect term
    EC50 = 21.49,  // [μM]
    gamma = 1,
    exposure_per_s = 1);   // 1 μM per second
equation
  response = E0*(1 - Emax*frac);   // steady state, indirect response type I
  // exposure_unit_unresolved: 'μM' — the x axis is in the paper's unit, not SI
  // defaulted: E0
  // defaulted: Emax
  // defaulted: gamma
  annotation(experiment(StartTime = 0, StopTime = 220, Interval = 0.44),
    Documentation(info = "<html><body><!-- drug-about --><h4>About pazopanib</h4><p>Pazopanib is a protein kinase inhibitor used to treat kidney cancer, especially renal cell carcinoma, and other tumours such as gastrointestinal stromal tumours and soft-tissue sarcomas. It is an approved anticancer medicine authorised in the European Union for renal cell carcinoma.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q7157043\">Wikidata Q7157043</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h4>Pazopanib_Wan2025_PD_mmp</h4><p>The steady-state exposure-response curve of Wan Z et al., <i>Pharmaceuticals (Basel, Switzerland) 18(4):450</i> 2025 (<a href=\"https://doi.org/10.3390/ph18040450\">doi:10.3390/ph18040450</a>) — mitochondrial membrane potential against pazopanib μM — obtained by sweeping the driver instead of simulating a dose. Model family: indirect_response_i.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = (library default) drug-free response (baseline)
  Emax  = (library default) maximal effect term
  EC50  =      21.49 μM       exposure at half of the maximal effect term (EC50MMP, Q321)
  gamma = (library default) Hill coefficient</pre><p>The algebra is <code>response = E0*(1 - Emax*frac)</code>; this model only supplies the numbers. The x axis is one μM of pazopanib per second of simulated time: there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0   (drug-free)
  exposure = EC50 (21.49 μM)  response 0
  exposure -> infinity  response 0</pre></body></html>"));
end Pazopanib_Wan2025_PD_mmp;
