model Daclatasvir_Osawa2018_reference
  parameter Real Cl_ref = 1.4694444444444445e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.06420000000000001 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.7388899999999999,
    adminMass = 1e-05,
    ka = 0.0002402777777777778,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About daclatasvir</h4><p>Daclatasvir is an antiviral drug used to treat chronic hepatitis C, including in patients with liver cirrhosis. It was authorised in the European Union but that authorisation has expired, so it is no longer marketed there, though it has been included in the WHO essential medicines list.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q5207712\">Wikidata Q5207712</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>daclatasvir</td></tr><tr><td>population:</td><td>Japanese adults with chronic HCV genotype 1 infection</td></tr><tr><td>source_paper:</td><td>Osawa_2018</td></tr><tr><td>measured_compound:</td><td>daclatasvir</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>jcph1274-tbl-0002</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>daclatasvir 738.89 g/mol (drugbank)</td></tr></table><p><b>Defaulted (base-class default used):</b> Tlag.</p><h4>Interpretation flags</h4><ul><li>table section residual_error: 'σ' routed out of structural estimates ('Residual error')</li><li>table section residual_error: 'σ' routed out of structural estimates ('Residual error')</li><li>unit_dimension_unknown: 'h‐1' (kabs)</li><li>dropped duplicate Q27 ('CL/F ∼SEX', value '0.0274') — already have one for this compound</li><li>dropped duplicate Q27 ('CL/F ∼TX', value '0.0336') — already have one for this compound</li><li>dropped duplicate Q27 ('CL/F ∼BCRCL', value '0.235') — already have one for this compound</li><li>dropped duplicate Q76 ('V/F ∼BBWT', value '0.605') — already have one for this compound</li><li>dropped duplicate Q27 ('CL/F', value '0.155') — already have one for this compound</li><li>dropped duplicate Q76 ('V/F', value '0.145') — already have one for this compound</li><li>dropped duplicate Q49 ('Ka', value '0.756') — already have one for this compound</li><li>dropped duplicate Q27 ('CL/F: V/F', value '0.141') — already have one for this compound</li><li>dropped value-less row: 'AST'</li><li>dropped value-less row: 'BAST'</li><li>dropped value-less row: 'BBWT'</li><li>dropped value-less row: 'BCRCL'</li><li>dropped value-less row: 'CI'</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 165600, Tolerance = 1e-9, Interval = 1));
end Daclatasvir_Osawa2018_reference;
