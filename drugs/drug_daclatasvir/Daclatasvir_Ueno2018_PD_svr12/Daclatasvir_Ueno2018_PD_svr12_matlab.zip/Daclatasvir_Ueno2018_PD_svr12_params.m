function p = Daclatasvir_Ueno2018_PD_svr12_params()
% Daclatasvir_Ueno2018_PD_svr12_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% daclatasvir Ueno_2018::SVR12: linear exposure-response sweep (response = E0 + slope*exposure). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one ng/mL per second, in SI inside (kg/m3, s). Response SVR12 in its own unit. Driver: daclatasvir (with asunaprevir interaction) (conc_no_pk).
p.E0 = 0.0;
p.Emax = 0.0;
p.EC50 = 1.0;
p.gamma = 1.0;
p.slope = 0.00368;
p.exposure_per_s = 1e-06;
p.stop_time = 1000.0;
p.form = 'E0 + slope*exposure';
end
