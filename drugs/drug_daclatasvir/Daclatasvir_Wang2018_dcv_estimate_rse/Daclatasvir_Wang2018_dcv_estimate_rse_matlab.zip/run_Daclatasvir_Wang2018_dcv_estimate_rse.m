% Run: build params, simulate 0..29.0 h, plot + save Daclatasvir_Wang2018_dcv_estimate_rse.png/.csv/.json.
% Interactive display (keep the window open):  octave --persist run_Daclatasvir_Wang2018_dcv_estimate_rse.m
here = fileparts(mfilename('fullpath'));
p = Daclatasvir_Wang2018_dcv_estimate_rse_params();
out = simulate_pk(p, 0:0.05:29.0);

% figure (shown on screen if interactive) and PNG (works in MATLAB and Octave)
fig = figure; plot(out.t, out.C, 'LineWidth', 1.5); grid on;
xlabel('time [h]'); ylabel('central concentration [mg/L]');
title('daclatasvir — Wang_2018 (oral)');
print(fig, fullfile(here, 'Daclatasvir_Wang2018_dcv_estimate_rse.png'), '-dpng', '-r150');

% CSV (time_h, Cc_mg_per_L)
fid = fopen(fullfile(here, 'Daclatasvir_Wang2018_dcv_estimate_rse.csv'), 'w');
fprintf(fid, 'time_h,Cc_mg_per_L\n');
fprintf(fid, '%.10g,%.10g\n', [out.t(:), out.C(:)].');
fclose(fid);

% JSON (summary + arrays; jsonencode with a manual fallback for older versions)
fid = fopen(fullfile(here, 'Daclatasvir_Wang2018_dcv_estimate_rse.json'), 'w');
try
  s.model = 'Daclatasvir_Wang2018_dcv_estimate_rse'; s.Cmax = out.Cmax; s.Tmax = out.Tmax; s.AUC = out.AUC;
  s.time_h = out.t(:).'; s.Cc_mg_per_L = out.C(:).';
  fprintf(fid, '%s', jsonencode(s));
catch
  fprintf(fid, '{"model":"Daclatasvir_Wang2018_dcv_estimate_rse","Cmax":%g,"Tmax":%g,"AUC":%g}', out.Cmax, out.Tmax, out.AUC);
end
fclose(fid);

fprintf('Cmax=%.3g mg/L  Tmax=%.3g h  AUC=%.3g mg*h/L\n', out.Cmax, out.Tmax, out.AUC);
fprintf('wrote Daclatasvir_Wang2018_dcv_estimate_rse.png, Daclatasvir_Wang2018_dcv_estimate_rse.csv, Daclatasvir_Wang2018_dcv_estimate_rse.json\n');
