function p = Daclatasvir_Wang2018_dcv_estimate_rse_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: daclatasvir   source: Wang_2018 / dcv_estimate_rse   route: oral
  % estimated (absent from source): F
  p.name  = 'Daclatasvir_Wang2018_dcv_estimate_rse_params';
  p.drug  = 'daclatasvir';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 42.9;                % central volume [L]
  p.CL = 5.24;                % clearance [L/h]
  p.Vp = [25.0];             % peripheral volumes [L]
  p.Q  = [2.62];             % inter-compartmental clearances [L/h]
  p.ka = 1.17;                % absorption rate [1/h]
  p.F  = 0.9;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 60.0;             % dose [mg]
end
