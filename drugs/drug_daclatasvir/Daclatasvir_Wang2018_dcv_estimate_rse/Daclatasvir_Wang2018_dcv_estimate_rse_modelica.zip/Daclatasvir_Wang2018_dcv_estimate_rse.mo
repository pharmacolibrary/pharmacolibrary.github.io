model Daclatasvir_Wang2018_dcv_estimate_rse
  parameter Real Cl_ref = 1.4555555555555557e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.0429 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C_enteral(
    weight = 70.0,
    F = 0.9,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.7388899999999999,
    adminMass = 6e-05,
    ka = 0.000325,
    Tlag = 0.0,
    k21 = 2.9111111111111112e-05
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About daclatasvir</h4><p>Daclatasvir is an antiviral drug used to treat chronic hepatitis C, including in patients with liver cirrhosis. It was authorised in the European Union but that authorisation has expired, so it is no longer marketed there, though it has been included in the WHO essential medicines list.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q5207712\">Wikidata Q5207712</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>daclatasvir</td></tr><tr><td>population:</td><td>healthy subjects and adults with genotype 1 chronic hepatitis C</td></tr><tr><td>source_paper:</td><td>Wang_2018</td></tr><tr><td>measured_compound:</td><td>daclatasvir</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>tab_2</td></tr><tr><td>input:</td><td>PK_2C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>daclatasvir 738.89 g/mol (drugbank)</td></tr></table><p><b>Defaulted (base-class default used):</b> F, Tlag, k12.</p><h4>Interpretation flags</h4><ul><li>dropped duplicate Q22 ('c', value '22.1') — already have one for this compound</li><li>apparent-by-design (ADVISORY, codes unchanged): extravascular dosing with no identifiable F, so these reported disposition parameters are likely apparent unless the model puts first-pass in its structure — Q22 (CL (L/h)); Q63 (Vc (L)); Q30 (Q (L/h)); Q64 (Vp (L))</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=daclatasvir</li><li>population split: 'dcv estimate (%rse)' subgroup of Wang_2018 (paper reports 3 populations: asv estimate (%rse), dcv estimate (%rse), estimate (%rse))</li><li>skipped review gap-fill of TLAG: primary's parameterization (rate-constant / ka-only) does not use it</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 104400, Tolerance = 1e-9, Interval = 1));
end Daclatasvir_Wang2018_dcv_estimate_rse;
