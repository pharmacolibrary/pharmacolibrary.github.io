% Run (SimBiology): build model + dose, simulate 0..144.0 h, plot.
p = Siponimod_Chaoyang2022v2_weighted_geometric_mean_weighted_ge_params();
[model, dose, variant] = build_sb_pk(p);
sd = simulate_sb(model, variant, dose, 144.0);
