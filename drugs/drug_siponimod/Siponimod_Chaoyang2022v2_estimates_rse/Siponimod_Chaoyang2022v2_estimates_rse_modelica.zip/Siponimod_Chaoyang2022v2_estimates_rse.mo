model Siponimod_Chaoyang2022v2_estimates_rse
  parameter Real Cl_ref = 8.805555555555556e-07 "Cl [m3/s]";
  parameter Real Vd_ref = 0.11270000000000001 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.516605,
    adminMass = 2.5e-07,
    ka = 0.00010555555555555555,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About siponimod</h4><p>Siponimod is an immunosuppressant used to treat relapsing-remitting multiple sclerosis. It is an approved medicine authorised in the European Union.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q25100876\">Wikidata Q25100876</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>siponimod</td></tr><tr><td>population:</td><td>healthy volunteers and patients with multiple sclerosis</td></tr><tr><td>source_paper:</td><td>Chaoyang_2022_2</td></tr><tr><td>measured_compound:</td><td>siponimod</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>T3</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>siponimod 516.605 g/mol (drugbank)</td></tr></table><p><b>Defaulted (base-class default used):</b> Tlag.</p><h4>Interpretation flags</h4><ul><li>column 'estimates (rse%)' classified 'rse' by the LLM but kept as the estimate: the header names the point value</li><li>column 'estimates (rse%)' classified 'rse' by the LLM but kept as the estimate: the header names the point value</li><li>column 'estimates (rse%)' classified 'rse' by the LLM but kept as the estimate: the header names the point value</li><li>column 'estimates (rse%)' classified 'rse' by the LLM but kept as the estimate: the header names the point value</li><li>column 'estimates (rse%)' classified 'rse' by the LLM but kept as the estimate: the header names the point value</li><li>column 'estimates (rse%)' classified 'rse' by the LLM but kept as the estimate: the header names the point value</li><li>column 'estimates (rse%)' classified 'rse' by the LLM but kept as the estimate: the header names the point value</li><li>column 'estimates (rse%)' classified 'rse' by the LLM but kept as the estimate: the header names the point value</li><li>dropped duplicate Q27 ('CL/F (%)', value '28.93') — already have one for this compound</li><li>dropped duplicate Q76 ('V/F (%)', value '23.29') — already have one for this compound</li><li>dropped duplicate Q49 ('Ka (%)', value '22.48') — already have one for this compound</li><li>apparent-ness (ontology-grounded): parameterization=apparent, measured_compound=siponimod</li><li>population split: 'estimates (rse%)' subgroup of Chaoyang_2022_2 (paper reports 2 populations: estimates (rse%), weighted geometric mean (weighted geometric coefficient of variation, %))</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of TLAG: primary's parameterization (rate-constant / ka-only) does not use it</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 518400, Tolerance = 1e-9, Interval = 1));
end Siponimod_Chaoyang2022v2_estimates_rse;
