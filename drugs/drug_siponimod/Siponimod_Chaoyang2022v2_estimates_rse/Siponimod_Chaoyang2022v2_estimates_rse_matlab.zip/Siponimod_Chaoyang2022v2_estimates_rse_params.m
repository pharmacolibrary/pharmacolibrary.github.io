function p = Siponimod_Chaoyang2022v2_estimates_rse_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: siponimod   source: Chaoyang_2022_2 / estimates_rse   route: oral
  p.name  = 'Siponimod_Chaoyang2022v2_estimates_rse_params';
  p.drug  = 'siponimod';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 112.7;                % central volume [L]
  p.CL = 3.17;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.38;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 0.25;             % dose [mg]
end
