% Run (SimBiology): build model + dose, simulate 0..144.0 h, plot.
p = Siponimod_Chaoyang2022v2_estimates_rse_params();
[model, dose, variant] = build_sb_pk(p);
sd = simulate_sb(model, variant, dose, 144.0);
