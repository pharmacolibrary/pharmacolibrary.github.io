model Nebacumab_Romano1993_reference
  parameter Real Cl_ref = 1.6944444444444442e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.0077 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    adminMass = 0.0001
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About nebacumab</h4><p>Nebacumab is an antibacterial monoclonal antibody, an immune globulin-type medicine intended to fight bacterial infections. It remains experimental and has not reached routine clinical use.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q6984546\">Wikidata Q6984546</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>nebacumab</td></tr><tr><td>population:</td><td>pediatric patients with sepsis syndrome or septic shock</td></tr><tr><td>source_paper:</td><td>Romano_1993</td></tr><tr><td>measured_compound:</td><td>nebacumab</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C: IV (no input phase)</td></tr></table><h4>Interpretation flags</h4><ul><li>unit_dimension_unknown: 'ml/kg per hour' (CL)</li><li>unit_dimension_unknown: 'ml/hr per kilogram' (CL)</li><li>dropped duplicate Q22 ('clearance', value 1.5) — already have one for this compound</li><li>implicit units: 'Clearance' → L/h (from the popPK convention: 'No unit provided in text or footnotes. L/h is the standard unit for total clearance in population PK studies.')</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=nebacumab</li><li>molar mass: none found for 'nebacumab' — its concentrations stay mass-only</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 345600, Tolerance = 1e-9, Interval = 1));
end Nebacumab_Romano1993_reference;
