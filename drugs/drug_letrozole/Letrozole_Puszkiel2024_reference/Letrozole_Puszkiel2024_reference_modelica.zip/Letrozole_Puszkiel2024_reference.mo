model Letrozole_Puszkiel2024_reference
  parameter Real Cl_ref = 3.638888888888889e-07 "Cl [m3/s]";
  parameter Real cov_cyp2a6_0 = 0 "cyp2a6 covariate";
  parameter Real cov_cyp2a6_1 = 0 "cyp2a6 covariate";
  parameter Real Vd_ref = 0.20700000000000002 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref*(1 + (0.54)*cov_cyp2a6_0)*(1 + (0.85)*cov_cyp2a6_1),
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.2853027,
    adminMass = 2.5e-06,
    ka = 0.0005888888888888889,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About letrozole</h4><p>Letrozole is an aromatase inhibitor used to treat breast cancer, including invasive ductal carcinoma and low-grade serous carcinoma. It is an approved medicine and is widely used as endocrine therapy for cancer.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q194974\">Wikidata Q194974</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>letrozole</td></tr><tr><td>population:</td><td>adults with hormone receptor-positive breast cancer</td></tr><tr><td>source_paper:</td><td>Puszkiel_2024</td></tr><tr><td>measured_compound:</td><td>letrozole</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>tab_2</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>letrozole 285.303 g/mol (drugbank)</td></tr></table><p><b>Defaulted (base-class default used):</b> Tlag.</p><h4>Interpretation flags</h4><ul><li>covariate level 'Effect of CYP2A6 SM on' → Q900:effect_of_cyp2a6_sm_on = 0.54 (linear_fractional on Q27)</li><li>covariate level 'Effect of missing CYP2A6' → Q900:effect_of_missing_cyp2a6 = 0.85 (linear_fractional on Q27)</li><li>covariate effect for Q22 has no base parameter row (kept as unattached equation-variable)</li><li>apparent-ness (ontology-grounded): parameterization=apparent, measured_compound=letrozole</li><li>structure disagreement: deterministic 1C vs LLM 2C — review compartment count</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of TLAG: primary's parameterization (rate-constant / ka-only) does not use it</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 2419200, Tolerance = 1e-9, Interval = 1));
end Letrozole_Puszkiel2024_reference;
