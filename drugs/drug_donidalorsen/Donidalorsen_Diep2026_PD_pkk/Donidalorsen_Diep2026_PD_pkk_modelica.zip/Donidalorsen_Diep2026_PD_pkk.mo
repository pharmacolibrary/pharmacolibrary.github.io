model Donidalorsen_Diep2026_PD_pkk
  "indirect_response_i exposure-response sweep — Diep_2026 :: PKK (prekallikrein)"
  extends Pharmacolibrary.Interfaces.PartialExposureResponseSweep(
    E0 = 0.0,      // [1]
    Emax = 0.992,  // type I effect term
    EC50 = 0.158,  // [unknown]
    gamma = 1.0,
    exposure_per_s = 1.0);   // 1 unit per second
equation
  response = E0*(1 - Emax*frac);   // steady state, indirect response type I
  // exposure_unit_unresolved: 'unknown' — the x axis is in the paper's unit, not SI
  // defaulted: E0
  // defaulted: gamma
  annotation(experiment(StartTime = 0, StopTime = 1.58, Interval = 0.00316));
end Donidalorsen_Diep2026_PD_pkk;
