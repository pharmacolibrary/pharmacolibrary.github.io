model Gabapentin_Siao2010_reference
  parameter Real Cl_ref = 3.5000000000000004e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.006328 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.1712368,
    adminMass = 0.0018,
    ka = 0.0014555555555555556,
    Tlag = 1620.0
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>gabapentin</td></tr><tr><td>population:</td><td>healthy adult cats</td></tr><tr><td>source_paper:</td><td>Siao_2010</td></tr><tr><td>measured_compound:</td><td>gabapentin</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>gabapentin 171.237 g/mol (drugbank)</td></tr></table><h4>Interpretation flags</h4><ul><li>apparent-ness (ontology-grounded): parameterization=apparent, measured_compound=gabapentin</li><li>held at status:extracted — NIL link or unit issue (mismatch/unknown/normalisation-failed) present</li><li>1C volume normalization: Q290→Q76 (single-compartment model has no central/peripheral split; 'apparent volume of the central compartment' is the general volume)</li><li>status held at route_to_review — not promoted</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li><li>gap-filled Q49 (kabs) from Adrian_2018's review values (primary lacked it)</li><li>gap-filled Q83 (tlag) from Adrian_2018's review values (primary lacked it)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Gabapentin_Siao2010_reference;
