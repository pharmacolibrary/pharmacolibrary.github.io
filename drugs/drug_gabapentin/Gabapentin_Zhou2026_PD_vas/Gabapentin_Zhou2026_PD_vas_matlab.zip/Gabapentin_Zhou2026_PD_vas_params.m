function p = Gabapentin_Zhou2026_PD_vas_params()
% Gabapentin_Zhou2026_PD_vas_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% gabapentin Zhou_2026::VAS: emax exposure-response sweep (response = E0 + Emax*frac). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one ng/mL per second, in SI inside (kg/m3, s). Response VAS in its own unit. Driver: gabapentin (pk_record).
p.E0 = 7.31;
p.Emax = -1.0;
p.EC50 = 0.00026311;
p.gamma = 1.0;
p.slope = 0.0;
p.exposure_per_s = 1e-06;
p.stop_time = 2700.0;
p.form = 'E0 + Emax*frac';
end
