model Gabapentin_Zhou2026_PD_vas
  "emax exposure-response sweep — Zhou_2026 :: VAS (pain intensity)"
  extends Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep(
    E0 = 7.31,      // [1]
    Emax = -1,  // [1]
    EC50 = 0.00026311,  // [kg/m3; ng/mL × 1e-06]
    gamma = 1,
    exposure_per_s = 1e-06);   // 1 ng/mL per second
  // imax_as_negative_emax: Imax (Q323) enters SigmoidEmaxSweep as −Emax
  // defaulted: gamma
  annotation(experiment(StartTime = 0, StopTime = 2700, Interval = 5.4),
    Documentation(info = "<html><body><!-- drug-about --><h4>About gabapentin</h4><p>Gabapentin is an anticonvulsant and pain-relieving medicine used for epilepsy and various types of pain and neurological conditions, such as neuropathy, restless legs syndrome, and fibromyalgia. It is an approved medicine in widespread clinical use, and has also been studied for other conditions.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q410352\">Wikidata Q410352</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h4>Gabapentin_Zhou2026_PD_vas</h4><p>The steady-state exposure-response curve of Zhou L et al., <i>Frontiers in pharmacology 17:1760901</i> 2026 (<a href=\"https://doi.org/10.3389/fphar.2026.1760901\">doi:10.3389/fphar.2026.1760901</a>) — pain intensity against gabapentin ng/mL — obtained by sweeping the driver instead of simulating a dose. Model family: emax.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    =       7.31          drug-free response (baseline) (E0, Q324)
  Emax  =          1          maximal effect term (Imax, Q323)
  EC50  =     263.11 ng/mL    exposure at half of the maximal effect term (IC50, Q322)
  gamma = (library default) Hill coefficient</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep\">SigmoidEmaxSweep</a>; this model only supplies the numbers. The x axis is one ng/mL of gabapentin per second of simulated time (exposure is in kg/m3): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 7.31   (drug-free)
  exposure = EC50 (263.11 ng/mL)  response 6.81
  exposure -> infinity  response 6.31</pre></body></html>"));
end Gabapentin_Zhou2026_PD_vas;
