model Gabapentin_AlZubaydi2024_reference
  parameter Real Cl_ref = 1.591666666666667e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.044610000000000004 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 0.9,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.1712368,
    adminMass = 0.0001,
    ka = 0.00021611111111111112,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>gabapentin</td></tr><tr><td>population:</td><td>hospitalized adults</td></tr><tr><td>source_paper:</td><td>Al-Zubaydi_2024</td></tr><tr><td>measured_compound:</td><td>gabapentin</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>pharmaceutics-16-01514-t002</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>gabapentin 171.237 g/mol (drugbank)</td></tr></table><p><b>Defaulted (base-class default used):</b> F, Tlag.</p><h4>Interpretation flags</h4><ul><li>column 'population estimates (rses (%))' classified 'rse' by the LLM but kept as the estimate: the header names the point value</li><li>column 'population estimates (rses (%))' classified 'rse' by the LLM but kept as the estimate: the header names the point value</li><li>column 'population estimates (rses (%))' classified 'rse' by the LLM but kept as the estimate: the header names the point value</li><li>column 'population estimates (rses (%))' classified 'rse' by the LLM but kept as the estimate: the header names the point value</li><li>column 'population estimates (rses (%))' classified 'rse' by the LLM but kept as the estimate: the header names the point value</li><li>column 'population estimates (rses (%))' classified 'rse' by the LLM but kept as the estimate: the header names the point value</li><li>column 'population estimates (rses (%))' classified 'rse' by the LLM but kept as the estimate: the header names the point value</li><li>dropped unlinked row (NIL): 'β Cl_SCR' — extend the ontology if this is a real PK parameter (source ['pharmaceutics-16-01514-t002:row5:col1'])</li><li>dropped unlinked row (NIL): 'a' — extend the ontology if this is a real PK parameter (source ['pharmaceutics-16-01514-t002:row10:col1'])</li><li>apparent-by-design (ADVISORY, codes unchanged): extravascular dosing with no identifiable F, so these reported disposition parameters are likely apparent unless the model puts first-pass in its structure — Q61 (Vd (L)); Q22 (Cl (L/h))</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=gabapentin</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of TLAG: primary's parameterization (rate-constant / ka-only) does not use it</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 111600, Tolerance = 1e-9, Interval = 1));
end Gabapentin_AlZubaydi2024_reference;
