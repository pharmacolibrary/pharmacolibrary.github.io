model Sulbactam_Abouelhassan2024v2_200_mg_kg
  parameter Real Cl_ref = 2.66e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.0399 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.23324199999999998,
    adminMass = 0.0001,
    ka = 0.02178888888888889,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About sulbactam</h4><p>Sulbactam is an antibiotic that works as a beta-lactamase inhibitor, used in combination with other antibacterials to treat bacterial infections. It is an approved medicine and is used in clinical practice, though it is not an authorised EU medicine via the EMA.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q423393\">Wikidata Q423393</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>sulbactam</td></tr><tr><td>population:</td><td>healthy volunteers</td></tr><tr><td>source_paper:</td><td>Abouelhassan_2024_2</td></tr><tr><td>measured_compound:</td><td>sulbactam</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>dlae203-T2</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>sulbactam 233.242 g/mol (drugbank)</td></tr></table><p><b>Defaulted (base-class default used):</b> Tlag.</p><h4>Interpretation flags</h4><ul><li>dropped unlinked row (NIL): 'Parameter' — extend the ontology if this is a real PK parameter (source ['dlae203-T2:row0:col5'])</li><li>implicit units: 'K a (1/h)' → 1/h (from the paper text: &quot;The paper text explicitly lists the intercompartmental transfer rate constants with units of 'h−1' (e.g., 'K12, 10.65 h−&quot;)</li><li>implicit units: 'K el (1/h)' → 1/h (from the popPK convention: 'No specific unit is stated for Kel in the provided text excerpts, but elimination rate constants are first-order rate co')</li><li>implicit units: 'AUC0-8 (h.mg/L)a' → h.mg/L (from the paper text: &quot;The table caption for Table 2 explicitly defines the unit for fAUC0-8 as 'h.mg/L' in the footnote: 'a fAUC0-8 calculated&quot;)</li><li>apparent-ness (ontology-grounded): parameterization=apparent, measured_compound=sulbactam</li><li>1C volume normalization: Q290→Q76 (single-compartment model has no central/peripheral split; 'V c/F (L/kg)' is the general volume)</li><li>population split: '200 mg/kg' subgroup of Abouelhassan_2024_2 (paper reports 5 populations: 1 mg/kg, 10 mg/kg, 100 mg/kg, 200 mg/kg, 25 mg/kg)</li><li>skipped review gap-fill of CL: primary's parameterization (rate-constant / ka-only) does not use it</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary's parameterization (rate-constant / ka-only) does not use it</li><li>skipped review gap-fill of TLAG: primary's parameterization (rate-constant / ka-only) does not use it</li><li>derived CL/F=9.576 L/h from Ke × V/F = CL/F (Q47 × Q76); not separately reported</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Sulbactam_Abouelhassan2024v2_200_mg_kg;
