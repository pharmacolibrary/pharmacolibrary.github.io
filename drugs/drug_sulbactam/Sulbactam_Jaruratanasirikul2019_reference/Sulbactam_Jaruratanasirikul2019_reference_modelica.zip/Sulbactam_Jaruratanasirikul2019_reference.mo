model Sulbactam_Jaruratanasirikul2019_reference
  parameter Real Cl_ref = 1.8777777777777776e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.022170000000000002 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 0.9,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.23324199999999998,
    adminMass = 0.0001,
    ka = 0.0023,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About sulbactam</h4><p>Sulbactam is an antibiotic that works as a beta-lactamase inhibitor, used in combination with other antibacterials to treat bacterial infections. It is an approved medicine and is used in clinical practice, though it is not an authorised EU medicine via the EMA.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q423393\">Wikidata Q423393</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>sulbactam</td></tr><tr><td>population:</td><td>patients with ventilator-associated pneumonia</td></tr><tr><td>source_paper:</td><td>Jaruratanasirikul_2019</td></tr><tr><td>measured_compound:</td><td>sulbactam</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>sulbactam 233.242 g/mol (drugbank)</td></tr></table><p><b>Defaulted (base-class default used):</b> F, Tlag.</p><h4>Interpretation flags</h4><ul><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=sulbactam</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li><li>gap-filled Q49 (kabs) from Abouelhassan_2024_2's review values (primary lacked it)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Sulbactam_Jaruratanasirikul2019_reference;
