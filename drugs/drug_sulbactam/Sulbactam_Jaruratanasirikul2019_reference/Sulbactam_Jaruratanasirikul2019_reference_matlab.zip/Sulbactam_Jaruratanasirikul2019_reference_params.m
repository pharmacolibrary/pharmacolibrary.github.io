function p = Sulbactam_Jaruratanasirikul2019_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: sulbactam   source: Jaruratanasirikul_2019 / reference   route: oral
  % estimated (absent from source): F, dose
  p.name  = 'Sulbactam_Jaruratanasirikul2019_reference_params';
  p.drug  = 'sulbactam';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 22.17;                % central volume [L]
  p.CL = 6.76;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 8.28;                % absorption rate [1/h]
  p.F  = 0.9;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 100.0;             % dose [mg]
end
