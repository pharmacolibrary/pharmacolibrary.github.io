model Sulbactam_Onita2025_reference
  parameter Real Cl_ref = 6.027777777777777e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.0238 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.23324199999999998,
    adminMass = 0.001
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About sulbactam</h4><p>Sulbactam is an antibiotic that works as a beta-lactamase inhibitor, used in combination with other antibacterials to treat bacterial infections. It is an approved medicine and is used in clinical practice, though it is not an authorised EU medicine via the EMA.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q423393\">Wikidata Q423393</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>sulbactam</td></tr><tr><td>population:</td><td>review reference</td></tr><tr><td>source_paper:</td><td>Onita_2025</td></tr><tr><td>measured_compound:</td><td>sulbactam</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>sulbactam 233.242 g/mol (drugbank)</td></tr></table><h4>Interpretation flags</h4><ul><li>built from REVIEW reference values (Onita_2025) — secondary source</li><li>volume reported by review</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Sulbactam_Onita2025_reference;
