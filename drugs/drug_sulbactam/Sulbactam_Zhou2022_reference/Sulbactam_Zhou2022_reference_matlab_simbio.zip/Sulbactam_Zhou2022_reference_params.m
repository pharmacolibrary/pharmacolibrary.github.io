function p = Sulbactam_Zhou2022_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: sulbactam   source: Zhou_2022 / reference   route: oral
  % estimated (absent from source): F, dose
  p.name  = 'Sulbactam_Zhou2022_reference_params';
  p.drug  = 'sulbactam';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 18.0;                % central volume [L]
  p.CL = 15.8;                % clearance [L/h]
  p.Vp = [5.39];             % peripheral volumes [L]
  p.Q  = [2.91];             % inter-compartmental clearances [L/h]
  p.ka = 8.28;                % absorption rate [1/h]
  p.F  = 0.9;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 100.0;             % dose [mg]
end
