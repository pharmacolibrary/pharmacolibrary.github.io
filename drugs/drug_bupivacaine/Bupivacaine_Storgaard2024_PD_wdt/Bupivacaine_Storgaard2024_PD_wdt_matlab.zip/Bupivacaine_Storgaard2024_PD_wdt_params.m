function p = Bupivacaine_Storgaard2024_PD_wdt_params()
% Bupivacaine_Storgaard2024_PD_wdt_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% bupivacaine Storgaard_2024::WDT: linear exposure-response sweep (response = E0 + slope*exposure). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one μg/L per second, in SI inside (kg/m3, s). Response WDT in C. Driver: bupivacaine (pk_record).
p.E0 = 36.7;
p.Emax = 0.0;
p.EC50 = 1.0;
p.gamma = 1.0;
p.slope = 12531324744400.002;
p.exposure_per_s = 1e-06;
p.stop_time = 1000.0;
p.form = 'E0 + slope*exposure';
end
