model Bupivacaine_Venkatachalam2022_reference
  parameter Real Cl_ref = 3.3333333333333334e-08 "Cl [m3/s]";
  parameter Real Vd_ref = 0.005676716446889894 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.2884277,
    adminMass = 1e-05
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About bupivacaine</h4><p>Bupivacaine is a local anesthetic used to relieve pain, especially acute pain. It is widely used, is on the WHO list of essential medicines, and has an authorised product in the European Union.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q422806\">Wikidata Q422806</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>bupivacaine</td></tr><tr><td>population:</td><td>review reference</td></tr><tr><td>source_paper:</td><td>Venkatachalam_2022</td></tr><tr><td>measured_compound:</td><td>bupivacaine</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>bupivacaine 288.428 g/mol (drugbank)</td></tr></table><h4>Interpretation flags</h4><ul><li>built from REVIEW reference values (Venkatachalam_2022) — secondary source</li><li>central volume derived from CL·t½/ln2</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 604800, Tolerance = 1e-9, Interval = 1));
end Bupivacaine_Venkatachalam2022_reference;
