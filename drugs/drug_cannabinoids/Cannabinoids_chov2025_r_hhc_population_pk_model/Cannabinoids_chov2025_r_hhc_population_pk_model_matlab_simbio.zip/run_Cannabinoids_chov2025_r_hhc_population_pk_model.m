% Run (SimBiology): build model + dose, simulate 0..24.0 h, plot.
p = Cannabinoids_chov2025_r_hhc_population_pk_model_params();
[model, dose, variant] = build_sb_pk(p);
sd = simulate_sb(model, variant, dose, 24.0);
