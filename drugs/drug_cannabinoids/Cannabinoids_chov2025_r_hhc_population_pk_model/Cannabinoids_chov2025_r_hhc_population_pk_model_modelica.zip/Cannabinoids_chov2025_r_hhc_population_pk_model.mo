model Cannabinoids_chov2025_r_hhc_population_pk_model
  parameter Real Cl_ref = 6.82611111111111e-07 "Cl [m3/s]";
  parameter Real Vd_ref = 0.0015149 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    adminMass = 0.0007,
    ka = 0.00013055555555555555,
    Tlag = 1764.0
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About cannabinoids</h4><p>JWH-018 is a synthetic cannabinoid that was used recreationally as an ingredient in herbal smoking mixtures sold as legal alternatives to cannabis. It is no longer used because it was found to be harmful and was made a controlled substance in many countries.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q419020\">Wikidata Q419020</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>cannabinoids</td></tr><tr><td>population:</td><td>male Wistar rats</td></tr><tr><td>source_paper:</td><td>Šíchová_2025</td></tr><tr><td>measured_compound:</td><td>hexahydrocannabinol</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>TB1</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>cannabinoids 628.938 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>apparent-ness (ontology-grounded): parameterization=apparent, measured_compound=hexahydrocannabinol</li><li>population split: 'r-hhc population pk model' subgroup of Šíchová_2025 (paper reports 2 populations: r-hhc population pk model, s-hhc population pk model)</li><li>review gap-fill skipped: this record measures 'hexahydrocannabinol', not cannabinoids — the review values are the parent's</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Cannabinoids_chov2025_r_hhc_population_pk_model;
