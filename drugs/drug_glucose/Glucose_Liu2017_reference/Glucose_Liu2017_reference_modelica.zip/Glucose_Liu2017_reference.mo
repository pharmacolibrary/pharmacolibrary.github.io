model Glucose_Liu2017_reference
  parameter Real Cl_ref = 2.1666666666666665e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.023960000000000002 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.180156,
    adminMass = 0.0001,
    ka = 0.0026583333333333333,
    Tlag = 324.0,
    k12 = 0.00011419495455388609,
    k21 = 2.613536260493945e-05
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About glucose</h4><p>Glucose, a simple sugar also known as dextrose, is used as an irrigating solution, a diagnostic agent in tests for diabetes, and a general nutrient. It is listed as a WHO essential medicine and remains widely used in medical care.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q37525\">Wikidata Q37525</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>glucose</td></tr><tr><td>population:</td><td>review reference</td></tr><tr><td>source_paper:</td><td>Liu_2017</td></tr><tr><td>measured_compound:</td><td>glucose</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_2C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>glucose 180.156 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>built from REVIEW reference values (Liu_2017) — secondary source</li><li>volume reported by review</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Glucose_Liu2017_reference;
