function p = Glucose_Xiang2025_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: glucose   source: Xiang_2025 / reference   route: oral
  % estimated (absent from source): dose
  p.name  = 'Glucose_Xiang2025_reference_params';
  p.drug  = 'glucose';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 2248.0;                % central volume [L]
  p.CL = 33.7;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 3.09;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 100.0;             % dose [mg]
end
