function p = Clofarabine_Bonate2011_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: clofarabine   source: Bonate_2011 / reference   route: iv_bolus
  % estimated (absent from source): dose
  % Vc is the record's Vss — no central volume was reported; 1-compartment reading
  p.name  = 'Clofarabine_Bonate2011_reference_params';
  p.drug  = 'clofarabine';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'iv_bolus';        % 'oral' | 'iv_bolus'
  p.depot = false;             % oral -> first-order absorption depot
  p.Vc = 92.9;                % central volume [L]
  p.CL = 18.3;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.0;                % absorption rate [1/h]
  p.F  = 0.575;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 10.0;             % dose [mg]
end
