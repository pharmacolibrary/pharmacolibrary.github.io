model Clofarabine_Bonate2011_reference
  parameter Real Cl_ref = 5.0833333333333335e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.09290000000000001 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.30367700000000003,
    adminMass = 1e-05
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About clofarabine</h4><p>Clofarabine is a purine analogue anticancer drug used to treat acute lymphoblastic leukemia and acute myeloid leukemia. It is approved and used in a limited, specialist setting, mainly for relapsed or refractory childhood leukemia, with one authorised product in the European Union.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q5134875\">Wikidata Q5134875</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>clofarabine</td></tr><tr><td>population:</td><td>adult and pediatric patients with cancer</td></tr><tr><td>source_paper:</td><td>Bonate_2011</td></tr><tr><td>measured_compound:</td><td>clofarabine</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>clofarabine 303.677 g/mol (drugbank)</td></tr></table><h4>Interpretation flags</h4><ul><li>dropped duplicate Q22 ('CL', value 21.5) — already have one for this compound</li><li>dropped duplicate Q65 ('Vdss', value 257.4) — already have one for this compound</li><li>dropped duplicate Q57 ('average apparent half-life', value 4.9) — already have one for this compound</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=clofarabine</li><li>held at status:extracted — NIL link or unit issue (mismatch/unknown/normalisation-failed) present</li><li>structure disagreement: deterministic 1C vs LLM 2C — review compartment count</li><li>status held at route_to_review — not promoted</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Clofarabine_Bonate2011_reference;
