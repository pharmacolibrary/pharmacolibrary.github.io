model Cannabidiol_Shaik2026_reference
  parameter Real Cl_ref = 9.186333333333334e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.035926442606147746 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.314469,
    adminMass = 1e-05
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About cannabidiol</h4><p>Cannabidiol is an antiepileptic medicine used to treat certain epilepsy syndromes, including Lennox–Gastaut syndrome and myoclonic epilepsies. It is an approved medicine with an authorised product in the European Union, and is also being studied for other investigational uses.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q422917\">Wikidata Q422917</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>cannabidiol</td></tr><tr><td>population:</td><td>review reference</td></tr><tr><td>source_paper:</td><td>Shaik_2026</td></tr><tr><td>measured_compound:</td><td>cannabidiol</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>cannabidiol 314.469 g/mol (drugbank)</td></tr></table><h4>Interpretation flags</h4><ul><li>built from REVIEW reference values (Shaik_2026) — secondary source</li><li>central volume derived from CL·t½/ln2</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Cannabidiol_Shaik2026_reference;
