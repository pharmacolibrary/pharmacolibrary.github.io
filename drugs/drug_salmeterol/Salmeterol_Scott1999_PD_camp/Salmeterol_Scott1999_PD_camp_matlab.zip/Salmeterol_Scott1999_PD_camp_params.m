function p = Salmeterol_Scott1999_PD_camp_params()
% Salmeterol_Scott1999_PD_camp_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% salmeterol Scott_1999::cAMP: emax exposure-response sweep (response = E0 + Emax*frac). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one microM per second, in SI inside (kg/m3, s). Response cAMP in %. Driver: salmeterol (cited_pk).
p.E0 = 0.0;
p.Emax = 0.18;
p.EC50 = 0.0012;
p.gamma = 1.0;
p.slope = 0.0;
p.exposure_per_s = 1.0;
p.stop_time = 0.012;
p.form = 'E0 + Emax*frac';
end
