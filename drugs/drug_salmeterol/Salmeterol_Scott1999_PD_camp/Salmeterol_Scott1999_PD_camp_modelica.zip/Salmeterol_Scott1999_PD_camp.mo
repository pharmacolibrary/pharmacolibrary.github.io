model Salmeterol_Scott1999_PD_camp
  "emax exposure-response sweep — Scott_1999 :: cAMP ([3H]-cyclic AMP formation)"
  extends Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep(
    E0 = 0,      // [1]
    Emax = 0.18,  // [1; % × 0.01]
    EC50 = 0.0012,  // [microM]
    gamma = 1,
    exposure_per_s = 1);   // 1 microM per second
  // exposure_unit_unresolved: 'microM' — the x axis is in the paper's unit, not SI
  // defaulted: E0
  // defaulted: gamma
  annotation(experiment(StartTime = 0, StopTime = 0.012, Interval = 2.4e-05),
    Documentation(info = "<html><body><!-- drug-about --><h4>About salmeterol</h4><p>Salmeterol is a long-acting inhaled beta-2 agonist used to manage asthma and chronic obstructive pulmonary disease, often combined with fluticasone. It is an approved medicine, widely used in inhaled combination products for obstructive airway diseases.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q581334\">Wikidata Q581334</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h4>Salmeterol_Scott1999_PD_camp</h4><p>The steady-state exposure-response curve of Scott MG et al., <i>British journal of pharmacology 128(3):721–729</i> 1999 (<a href=\"https://doi.org/10.1038/sj.bjp.0702829\">doi:10.1038/sj.bjp.0702829</a>) — [3H]-cyclic AMP formation [%] against salmeterol microM — obtained by sweeping the driver instead of simulating a dose. Model family: emax.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = (library default) drug-free response (baseline)
  Emax  =         18 %        maximal effect term (maximum response, Q320)
  EC50  =     0.0012 microM   exposure at half of the maximal effect term (EC50, Q321)
  gamma = (library default) Hill coefficient</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep\">SigmoidEmaxSweep</a>; this model only supplies the numbers. The x axis is one microM of salmeterol per second of simulated time: there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0   (drug-free)
  exposure = EC50 (0.0012 microM)  response 0.09
  exposure -> infinity  response 0.18</pre></body></html>"));
end Salmeterol_Scott1999_PD_camp;
