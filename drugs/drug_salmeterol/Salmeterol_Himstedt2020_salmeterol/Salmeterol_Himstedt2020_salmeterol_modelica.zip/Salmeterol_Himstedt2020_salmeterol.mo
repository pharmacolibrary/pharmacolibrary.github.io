model Salmeterol_Himstedt2020_salmeterol
  parameter Real Cl_ref = 7.505555555555556e-05 "Cl [m3/s]";
  parameter Real Vd_ref = 0.008610000000000001 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C_enteral(
    weight = 70.0,
    F = 0.9,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.415574,
    adminMass = 0.0001,
    ka = -0.00024722222222222224,
    Tlag = 5400.0,
    k12 = 0.007317073170731706,
    k21 = 0.0002387267904509284
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About salmeterol</h4><p>Salmeterol is a long-acting inhaled beta-2 agonist used to manage asthma and chronic obstructive pulmonary disease, often combined with fluticasone. It is an approved medicine, widely used in inhaled combination products for obstructive airway diseases.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q581334\">Wikidata Q581334</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>salmeterol</td></tr><tr><td>population:</td><td>rats after intravenous administration</td></tr><tr><td>source_paper:</td><td>Himstedt_2020</td></tr><tr><td>measured_compound:</td><td>salmeterol</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>pharmaceutics-12-00408-t001</td></tr><tr><td>input:</td><td>PK_2C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>salmeterol 415.574 g/mol (pubchem)</td></tr></table><p><b>Defaulted (base-class default used):</b> F.</p><h4>Interpretation flags</h4><ul><li>dropped duplicate Q410 ('Kp,B', value '18.6') — already have one for this compound</li><li>dropped duplicate Q410 ('Kp,A', value '39.3') — already have one for this compound</li><li>dropped unlinked row (NIL): 'QT 1' — extend the ontology if this is a real PK parameter (source ['pharmaceutics-12-00408-t001:row8:col2'])</li><li>dropped duplicate Q30 ('QA 1', value '10.6') — already have one for this compound</li><li>implicit units: 'CL' → L/h/kg (from the popPK convention: 'Paper reports blood flows in L/h/kg (e.g., 0.777 L/h/kg bronchial, 11.6 L/h/kg) and infusion in mL/h/kg, indicating body')</li><li>implicit units: 'VC' → L/kg (from the popPK convention: 'No unit stated for volumes; consistent with weight-normalized PBPK-style parameters (flows in L/h/kg), central volume co')</li><li>implicit units: 'Q' → L/h/kg (from the popPK convention: &quot;No unit stated; intercompartmental clearance conventionally L/h, and paper's parameters are weight-normalized (blood flo&quot;)</li><li>implicit units: 'VP' → L/kg (from the popPK convention: 'No unit stated; peripheral volume conventionally L, weight-normalized to L/kg consistent with other parameters.')</li><li>implicit units: 'QB 1' → L/h/kg (from the paper text: &quot;Text states 'The bronchial blood flow amounted to 0.777 L/h/kg (21.5% CV)', matching QB = 0.777.&quot;)</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=salmeterol</li><li>population split: 'salmeterol' subgroup of Himstedt_2020 (paper reports 4 populations: fluticasone propionate, salmeterol, t½ (human) 2, t½ (rat))</li><li>gap-filled Q49 (kabs) from Ambery_2015's review values (primary lacked it)</li><li>gap-filled Q83 (tlag) from Heuberger_2018's review values (primary lacked it)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Salmeterol_Himstedt2020_salmeterol;
