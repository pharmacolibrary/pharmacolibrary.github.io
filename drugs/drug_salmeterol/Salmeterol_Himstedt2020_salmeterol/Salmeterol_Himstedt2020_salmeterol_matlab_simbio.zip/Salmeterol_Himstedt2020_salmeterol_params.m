function p = Salmeterol_Himstedt2020_salmeterol_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: salmeterol   source: Himstedt_2020 / salmeterol   route: oral
  % estimated (absent from source): F, dose
  p.name  = 'Salmeterol_Himstedt2020_salmeterol_params';
  p.drug  = 'salmeterol';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 8.61;                % central volume [L]
  p.CL = 270.2;                % clearance [L/h]
  p.Vp = [263.9];             % peripheral volumes [L]
  p.Q  = [226.8];             % inter-compartmental clearances [L/h]
  p.ka = -0.89;                % absorption rate [1/h]
  p.F  = 0.9;                 % bioavailability [0-1]
  p.Tlag = 1.5;             % absorption lag [h]
  p.dose = 100.0;             % dose [mg]
end
