model Salmeterol_Himstedt2020_PD_inhibition_of_methacholine_induce
  "emax exposure-response sweep — Himstedt_2020 :: inhibition of methacholine-induced bronchoconstriction (inhibition of methacholine-induced bronchoconstriction)"
  extends Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep(
    E0 = 0,      // [1]
    Emax = -1,  // [1; % × 0.01]
    EC50 = 0.0271,  // [nM]
    gamma = 1,
    exposure_per_s = 1);   // 1 nM per second
  // imax_as_negative_emax: Imax (Q323) enters SigmoidEmaxSweep as −Emax
  // exposure_unit_unresolved: 'nM' — the x axis is in the paper's unit, not SI
  // defaulted: E0
  // defaulted: gamma
  annotation(experiment(StartTime = 0, StopTime = 0.28, Interval = 0.00056),
    Documentation(info = "<html><body><!-- drug-about --><h4>About salmeterol</h4><p>Salmeterol is a long-acting inhaled beta-2 agonist used to manage asthma and chronic obstructive pulmonary disease, often combined with fluticasone. It is an approved medicine, widely used in inhaled combination products for obstructive airway diseases.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q581334\">Wikidata Q581334</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h4>Salmeterol_Himstedt2020_PD_inhibition_of_methacholine_induce</h4><p>The steady-state exposure-response curve of Himstedt A et al., <i>Pharmaceutics 12(5):E408</i> 2020 (<a href=\"https://doi.org/10.3390/pharmaceutics12050408\">doi:10.3390/pharmaceutics12050408</a>) — inhibition of methacholine-induced bronchoconstriction [%] against salmeterol nM — obtained by sweeping the driver instead of simulating a dose. Model family: emax.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = (library default) drug-free response (baseline)
  Emax  =        100 %        maximal effect term (Emax, Q323)
  EC50  =     0.0271 nM       exposure at half of the maximal effect term (EC50,free, Q321)
  gamma = (library default) Hill coefficient</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep\">SigmoidEmaxSweep</a>; this model only supplies the numbers. The x axis is one nM of salmeterol per second of simulated time: there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0   (drug-free)
  exposure = EC50 (0.0271 nM)  response -0.5
  exposure -> infinity  response -1</pre></body></html>"));
end Salmeterol_Himstedt2020_PD_inhibition_of_methacholine_induce;
