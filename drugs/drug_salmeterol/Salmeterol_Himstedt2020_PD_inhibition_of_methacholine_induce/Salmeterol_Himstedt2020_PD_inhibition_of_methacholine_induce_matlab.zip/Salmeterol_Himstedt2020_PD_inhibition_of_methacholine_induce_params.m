function p = Salmeterol_Himstedt2020_PD_inhibition_of_methacholine_induce_params()
% Salmeterol_Himstedt2020_PD_inhibition_of_methacholine_induce_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% salmeterol Himstedt_2020::inhibition_of_methacholine_induced_bronchoconstriction: emax exposure-response sweep (response = E0 + Emax*frac). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one nM per second, in SI inside (kg/m3, s). Response inhibition of methacholine-induced bronchoconstriction in %. Driver: salmeterol (pk_record).
p.E0 = 0.0;
p.Emax = -1.0;
p.EC50 = 0.0271;
p.gamma = 1.0;
p.slope = 0.0;
p.exposure_per_s = 1.0;
p.stop_time = 0.28;
p.form = 'E0 + Emax*frac';
end
