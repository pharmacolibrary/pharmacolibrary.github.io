model Salmeterol_McCrea1993_PD_camp
  "emax exposure-response sweep — McCrea_1993 :: cAMP (total [3H]-cyclic AMP accumulation)"
  extends Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep(
    E0 = 0,      // [1]
    Emax = 46,  // [% of isoprenaline maximum]
    EC50 = 37,  // [nM]
    gamma = 1,
    exposure_per_s = 1);   // 1 nM per second
  // exposure_unit_unresolved: 'nM' — the x axis is in the paper's unit, not SI
  // defaulted: E0
  // defaulted: gamma
  annotation(experiment(StartTime = 0, StopTime = 370, Interval = 0.74),
    Documentation(info = "<html><body><!-- drug-about --><h4>About salmeterol</h4><p>Salmeterol is a long-acting inhaled beta-2 agonist used to manage asthma and chronic obstructive pulmonary disease, often combined with fluticasone. It is an approved medicine, widely used in inhaled combination products for obstructive airway diseases.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q581334\">Wikidata Q581334</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h4>Salmeterol_McCrea1993_PD_camp</h4><p>The steady-state exposure-response curve of McCrea KE et al., <i>British journal of pharmacology 110(2):619–626</i> 1993 (<a href=\"https://doi.org/10.1111/j.1476-5381.1993.tb13856.x\">doi:10.1111/j.1476-5381.1993.tb13856.x</a>) — total [3H]-cyclic AMP accumulation against salmeterol nM — obtained by sweeping the driver instead of simulating a dose. Model family: emax.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = (library default) drug-free response (baseline)
  Emax  =         46 % of isoprenaline maximum maximal effect term (Emax (relative to isoprenaline), Q320)
  EC50  =         37 nM       exposure at half of the maximal effect term (EC50, Q321)
  gamma = (library default) Hill coefficient</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep\">SigmoidEmaxSweep</a>; this model only supplies the numbers. The x axis is one nM of salmeterol per second of simulated time: there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0   (drug-free)
  exposure = EC50 (37 nM)  response 23
  exposure -> infinity  response 46</pre></body></html>"));
end Salmeterol_McCrea1993_PD_camp;
