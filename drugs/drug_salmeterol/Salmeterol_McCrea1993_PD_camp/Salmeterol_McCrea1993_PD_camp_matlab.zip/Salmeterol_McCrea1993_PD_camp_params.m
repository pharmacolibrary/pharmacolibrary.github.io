function p = Salmeterol_McCrea1993_PD_camp_params()
% Salmeterol_McCrea1993_PD_camp_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% salmeterol McCrea_1993::cAMP: emax exposure-response sweep (response = E0 + Emax*frac). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one nM per second, in SI inside (kg/m3, s). Response cAMP in its own unit. Driver: salmeterol (cited_pk).
p.E0 = 0.0;
p.Emax = 46.0;
p.EC50 = 37.0;
p.gamma = 1.0;
p.slope = 0.0;
p.exposure_per_s = 1.0;
p.stop_time = 370.0;
p.form = 'E0 + Emax*frac';
end
