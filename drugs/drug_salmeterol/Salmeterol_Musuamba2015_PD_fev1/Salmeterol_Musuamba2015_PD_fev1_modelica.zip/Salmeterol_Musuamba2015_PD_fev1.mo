model Salmeterol_Musuamba2015_PD_fev1
  "indirect_response_iii exposure-response sweep — Musuamba_2015 :: FEV1 (trough FEV1)"
  extends Pharmacolibrary.Interfaces.PartialExposureResponseSweep(
    E0 = 0.00116,      // [m3; L × 0.001]
    Emax = 0.36,  // type III effect term
    EC50 = 8.66e-09,  // [kg; μg × 1e-09]
    gamma = 1,
    exposure_per_s = 1e-09);   // 1 μg per second
equation
  response = E0*(1 + Emax*frac);   // steady state, indirect response type III
  // defaulted: gamma
  annotation(experiment(StartTime = 0, StopTime = 87, Interval = 0.174),
    Documentation(info = "<html><body><!-- drug-about --><h4>About salmeterol</h4><p>Salmeterol is a long-acting inhaled beta-2 agonist used to manage asthma and chronic obstructive pulmonary disease, often combined with fluticasone. It is an approved medicine, widely used in inhaled combination products for obstructive airway diseases.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q581334\">Wikidata Q581334</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h4>Salmeterol_Musuamba2015_PD_fev1</h4><p>The steady-state exposure-response curve of Musuamba FT et al., <i>Pharmaceutical research 32(2):617–627</i> 2015 (<a href=\"https://doi.org/10.1007/s11095-014-1490-4\">doi:10.1007/s11095-014-1490-4</a>) — trough FEV1 [L] against salmeterol μg — obtained by sweeping the driver instead of simulating a dose. Model family: indirect_response_iii.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    =       1.16 L        drug-free response (baseline) (ΘInt_Dis, Q324)
  Emax  =       0.36          maximal effect term (ΘTVEmax, Q320)
  EC50  =       8.66 μg       exposure at half of the maximal effect term (ΘEDK50/Emax, Q321)
  gamma = (library default) Hill coefficient</pre><p>The algebra is <code>response = E0*(1 + Emax*frac)</code>; this model only supplies the numbers. The x axis is one μg of salmeterol per second of simulated time (exposure is in kg): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0.00116   (drug-free)
  exposure = EC50 (8.66 μg)  response 0.001369
  exposure -> infinity  response 0.001578</pre></body></html>"));
end Salmeterol_Musuamba2015_PD_fev1;
