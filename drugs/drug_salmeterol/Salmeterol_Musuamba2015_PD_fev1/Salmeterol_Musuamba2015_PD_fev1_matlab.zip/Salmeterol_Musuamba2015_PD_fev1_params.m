function p = Salmeterol_Musuamba2015_PD_fev1_params()
% Salmeterol_Musuamba2015_PD_fev1_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% salmeterol Musuamba_2015::FEV1: indirect_response_iii exposure-response sweep (response = E0*(1 + Emax*frac)). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one μg per second, in SI inside (kg/m3, s). Response FEV1 in L. Driver: salmeterol (cited_pk).
p.E0 = 0.0011600000000000002;
p.Emax = 0.36;
p.EC50 = 8.660000000000001e-09;
p.gamma = 1.0;
p.slope = 0.0;
p.exposure_per_s = 1e-09;
p.stop_time = 87.0;
p.form = 'E0*(1 + Emax*frac)';
end
