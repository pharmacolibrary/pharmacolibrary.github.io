function p = Salmeterol_Himstedt2020_fluticasone_propionate_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: salmeterol   source: Himstedt_2020 / fluticasone_propionate   route: oral
  % estimated (absent from source): F, dose
  p.name  = 'Salmeterol_Himstedt2020_fluticasone_propionate_params';
  p.drug  = 'salmeterol';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 15.61;                % central volume [L]
  p.CL = 235.9;                % clearance [L/h]
  p.Vp = [168.7];             % peripheral volumes [L]
  p.Q  = [330.4];             % inter-compartmental clearances [L/h]
  p.ka = -0.89;                % absorption rate [1/h]
  p.F  = 0.9;                 % bioavailability [0-1]
  p.Tlag = 1.5;             % absorption lag [h]
  p.dose = 100.0;             % dose [mg]
end
