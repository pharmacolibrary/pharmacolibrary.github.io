model Salmeterol_Thoueille2026_reference
  parameter Real Cl_ref = 5.3611111111111115e-05 "Cl [m3/s]";
  parameter Real Vd_ref = 0.446 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.415574,
    adminMass = 1.0000000000000001e-07,
    ka = -0.00024722222222222224,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About salmeterol</h4><p>Salmeterol is a long-acting inhaled beta-2 agonist used to manage asthma and chronic obstructive pulmonary disease, often combined with fluticasone. It is an approved medicine, widely used in inhaled combination products for obstructive airway diseases.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q581334\">Wikidata Q581334</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>salmeterol</td></tr><tr><td>population:</td><td>healthy participants, chronic asthmatics, and athletes</td></tr><tr><td>source_paper:</td><td>Thoueille_2026</td></tr><tr><td>measured_compound:</td><td>salmeterol</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>psp470187-tbl-0002</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>salmeterol 415.574 g/mol (pubchem); α-hydroxysalmeterol 431.573 g/mol (pubchem)</td></tr></table><p><b>Defaulted (base-class default used):</b> Tlag.</p><h4>Interpretation flags</h4><ul><li>dropped value-less row: 'Parameters'</li><li>kept covariate coefficient θAthletes=2.91 (covariate Athletes) — not an ontology parameter</li><li>dropped unlinked row (NIL): 'UR_PROD (L/h)' — extend the ontology if this is a real PK parameter (source ['psp470187-tbl-0002:row18:col1'])</li><li>apparent-ness (ontology-grounded): parameterization=apparent, measured_compound=salmeterol</li><li>template fit: PK_3M_9C — formed from central; parent 2, metabolites [0]</li><li>row roles: 3 per-group rows of salmeterol residual_error but 0 reference group(s) — kept as printed</li><li>row roles: 2 per-group rows of α-hydroxysalmeterol residual_error but 0 reference group(s) — kept as printed</li><li>row roles (LLM): model_class=compartmental; 27/27 row label(s) assigned, 8 linked by role; re-tagged parent→α-hydroxysalmeterol ×7</li><li>gap-filled Q49 (kabs) from Ambery_2015's review values (primary lacked it)</li><li>skipped review gap-fill of TLAG: primary's parameterization (rate-constant / ka-only) does not use it</li><li>engineer: parent → metabolite not buildable on PK_3M_9C (None) — the measured compound's 1-compartment model instead</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Salmeterol_Thoueille2026_reference;
