model Salmeterol_Berkhout2025_reference
  parameter Real Cl_ref = 2.0717592592592592e-09 "Cl [m3/s]";
  parameter Real Vd_ref = 0.00327 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C_enteral(
    weight = 70.0,
    F = 0.9,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.415574,
    adminMass = 0.0001,
    ka = 2.7430555555555552e-06,
    Tlag = 0.0,
    k12 = 1.6989466530750936e-06,
    k21 = 3.0358227079538558e-06
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About salmeterol</h4><p>Salmeterol is a long-acting inhaled beta-2 agonist used to manage asthma and chronic obstructive pulmonary disease, often combined with fluticasone. It is an approved medicine, widely used in inhaled combination products for obstructive airway diseases.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q581334\">Wikidata Q581334</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>salmeterol</td></tr><tr><td>population:</td><td>review reference</td></tr><tr><td>source_paper:</td><td>Berkhout_2025</td></tr><tr><td>measured_compound:</td><td>salmeterol</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_2C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>salmeterol 415.574 g/mol (pubchem)</td></tr></table><p><b>Defaulted (base-class default used):</b> F, Tlag.</p><h4>Interpretation flags</h4><ul><li>built from REVIEW reference values (Berkhout_2025) — secondary source</li><li>volume reported by review</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 6652800, Tolerance = 1e-9, Interval = 1));
end Salmeterol_Berkhout2025_reference;
