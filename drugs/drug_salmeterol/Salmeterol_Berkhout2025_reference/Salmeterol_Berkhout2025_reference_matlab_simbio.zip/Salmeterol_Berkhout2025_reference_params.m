function p = Salmeterol_Berkhout2025_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: salmeterol   source: Berkhout_2025 / reference   route: oral
  % estimated (absent from source): F, dose
  p.name  = 'Salmeterol_Berkhout2025_reference_params';
  p.drug  = 'salmeterol';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 3.27;                % central volume [L]
  p.CL = 0.007458;                % clearance [L/h]
  p.Vp = [1.83];             % peripheral volumes [L]
  p.Q  = [0.02];             % inter-compartmental clearances [L/h]
  p.ka = 0.009875;                % absorption rate [1/h]
  p.F  = 0.9;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 100.0;             % dose [mg]
end
