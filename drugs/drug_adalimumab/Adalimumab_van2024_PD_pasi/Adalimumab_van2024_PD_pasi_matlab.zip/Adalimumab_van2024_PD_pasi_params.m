function p = Adalimumab_van2024_PD_pasi_params()
% Adalimumab_van2024_PD_pasi_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% adalimumab van_2024::PASI: indirect_response_i exposure-response sweep (response = E0*(1 - Emax*frac)). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one mg/l per second, in SI inside (kg/m3, s). Response PASI in its own unit. Driver: adalimumab (pk_record).
p.E0 = 0.0;
p.Emax = 1.0;
p.EC50 = 0.0011899999999999997;
p.gamma = 1.0;
p.slope = 0.0;
p.exposure_per_s = 0.001;
p.stop_time = 12.0;
p.form = 'E0*(1 - Emax*frac)';
end
