model Adalimumab_van2024_PD_pasi
  "indirect_response_i exposure-response sweep — van_2024 :: PASI (PASI)"
  extends Pharmacolibrary.Interfaces.PartialExposureResponseSweep(
    E0 = 0,      // [1]
    Emax = 1,  // type I effect term
    EC50 = 0.00119,  // [kg/m3; mg/l × 0.001]
    gamma = 1,
    exposure_per_s = 0.001);   // 1 mg/l per second
equation
  response = E0*(1 - Emax*frac);   // steady state, indirect response type I
  // defaulted: E0
  // defaulted: Emax
  // defaulted: gamma
  annotation(experiment(StartTime = 0, StopTime = 12, Interval = 0.024),
    Documentation(info = "<html><body><!-- drug-about --><h4>About adalimumab</h4><p>Adalimumab is a monoclonal antibody that blocks tumour necrosis factor alpha and is used to treat inflammatory conditions such as rheumatoid and other arthritis, psoriasis, ankylosing spondylitis, uveitis, ulcerative colitis, Crohn's disease, and hidradenitis suppurativa. It is widely used and authorised in the European Union, where several products are approved, though some have been withdrawn.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q348260\">Wikidata Q348260</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h4>Adalimumab_van2024_PD_pasi</h4><p>The steady-state exposure-response curve of van Huizen A et al., <i>The Journal of investigative dermatology 144(4):794–801.e6</i> 2024 (<a href=\"https://doi.org/10.1016/j.jid.2023.10.022\">doi:10.1016/j.jid.2023.10.022</a>) — PASI against adalimumab mg/l — obtained by sweeping the driver instead of simulating a dose. Model family: indirect_response_i.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = (library default) drug-free response (baseline)
  Emax  = (library default) maximal effect term
  EC50  =       1.19 mg/l     exposure at half of the maximal effect term (IC 50, Q322)
  gamma = (library default) Hill coefficient</pre><p>The algebra is <code>response = E0*(1 - Emax*frac)</code>; this model only supplies the numbers. The x axis is one mg/l of adalimumab per second of simulated time (exposure is in kg/m3): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0   (drug-free)
  exposure = EC50 (1.19 mg/l)  response 0
  exposure -> infinity  response 0</pre></body></html>"));
end Adalimumab_van2024_PD_pasi;
