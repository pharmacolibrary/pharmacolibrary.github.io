% run_Adalimumab_Ternant2015_PD_crp  Evaluate the exposure-response curve and plot response against exposure.
% A sweep is a static map: no ODE solver is needed. exposure runs 0..stop_time*exposure_per_s.
p = Adalimumab_Ternant2015_PD_crp_params();
exposure = linspace(0, p.stop_time * p.exposure_per_s, 501);
frac = exposure.^p.gamma ./ (p.EC50^p.gamma + exposure.^p.gamma);
E0 = p.E0; Emax = p.Emax; slope = p.slope;
response = E0.*(1 - Emax.*frac);
figure; plot(exposure, response, 'LineWidth', 1.5); grid on;
xlabel('exposure [mg l(-1)]'); ylabel('response []'); title('Adalimumab_Ternant2015_PD_crp', 'Interpreter', 'none');
writematrix([exposure(:) response(:)], 'Adalimumab_Ternant2015_PD_crp.csv');
