function p = Adalimumab_Ternant2015_PD_crp_params()
% Adalimumab_Ternant2015_PD_crp_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% adalimumab Ternant_2015::CRP: indirect_response_i exposure-response sweep (response = E0*(1 - Emax*frac)). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one mg l(-1) per second, in SI inside (kg/m3, s). Response CRP in its own unit. Driver: adalimumab (cited_pk).
p.E0 = 0.0;
p.Emax = 1.0;
p.EC50 = 0.0035999999999999995;
p.gamma = 1.0;
p.slope = 0.0;
p.exposure_per_s = 0.001;
p.stop_time = 36.0;
p.form = 'E0*(1 - Emax*frac)';
end
