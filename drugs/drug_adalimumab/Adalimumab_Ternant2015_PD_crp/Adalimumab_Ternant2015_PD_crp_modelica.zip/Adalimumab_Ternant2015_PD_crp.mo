model Adalimumab_Ternant2015_PD_crp
  "indirect_response_i exposure-response sweep — Ternant_2015 :: CRP (C-reactive protein)"
  extends Pharmacolibrary.Interfaces.PartialExposureResponseSweep(
    E0 = 0,      // [1]
    Emax = 1,  // type I effect term
    EC50 = 0.0036,  // [kg/m3; mg l(-1) × 0.001]
    gamma = 1,
    exposure_per_s = 0.001);   // 1 mg l(-1) per second
equation
  response = E0*(1 - Emax*frac);   // steady state, indirect response type I
  // defaulted: E0
  // defaulted: Emax
  // defaulted: gamma
  annotation(experiment(StartTime = 0, StopTime = 36, Interval = 0.072),
    Documentation(info = "<html><body><!-- drug-about --><h4>About adalimumab</h4><p>Adalimumab is a monoclonal antibody that blocks tumour necrosis factor alpha and is used to treat inflammatory conditions such as rheumatoid and other arthritis, psoriasis, ankylosing spondylitis, uveitis, ulcerative colitis, Crohn's disease, and hidradenitis suppurativa. It is widely used and authorised in the European Union, where several products are approved, though some have been withdrawn.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q348260\">Wikidata Q348260</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h4>Adalimumab_Ternant2015_PD_crp</h4><p>The steady-state exposure-response curve of Ternant D et al., <i>British journal of clinical pharmacology 79(2):286–297</i> 2015 (<a href=\"https://doi.org/10.1111/bcp.12509\">doi:10.1111/bcp.12509</a>) — C-reactive protein against adalimumab mg l(-1) — obtained by sweeping the driver instead of simulating a dose. Model family: indirect_response_i.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = (library default) drug-free response (baseline)
  Emax  = (library default) maximal effect term
  EC50  =        3.6 mg l(-1) exposure at half of the maximal effect term (adalimumab concentration leading to a 50% decrease in kin, Q322)
  gamma = (library default) Hill coefficient</pre><p>The algebra is <code>response = E0*(1 - Emax*frac)</code>; this model only supplies the numbers. The x axis is one mg l(-1) of adalimumab per second of simulated time (exposure is in kg/m3): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0   (drug-free)
  exposure = EC50 (3.6 mg l(-1))  response 0
  exposure -> infinity  response 0</pre></body></html>"));
end Adalimumab_Ternant2015_PD_crp;
