model Adalimumab_Chan2020_reference
  parameter Real Cl_ref = 5.416666666666667e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.381 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    adminMass = 0.0001,
    ka = 0.0001388888888888889,
    Tlag = 0.0,
    k12 = 3.849518810148731e-05,
    k21 = 5.1643192488262905e-05
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About adalimumab</h4><p>Adalimumab is a monoclonal antibody that blocks tumour necrosis factor alpha and is used to treat inflammatory conditions such as rheumatoid and other arthritis, psoriasis, ankylosing spondylitis, uveitis, ulcerative colitis, Crohn's disease, and hidradenitis suppurativa. It is widely used and authorised in the European Union, where several products are approved, though some have been withdrawn.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q348260\">Wikidata Q348260</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>adalimumab</td></tr><tr><td>population:</td><td>review reference</td></tr><tr><td>source_paper:</td><td>Chan_2020</td></tr><tr><td>measured_compound:</td><td>adalimumab</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_2C_enteral: apparent (/F) parameterization ⇒ extravascular dosing</td></tr></table><p><b>Defaulted (base-class default used):</b> ka, Tlag.</p><h4>Interpretation flags</h4><ul><li>built from REVIEW reference values (Chan_2020) — secondary source</li><li>volume reported by review</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 259200, Tolerance = 1e-9, Interval = 1));
end Adalimumab_Chan2020_reference;
