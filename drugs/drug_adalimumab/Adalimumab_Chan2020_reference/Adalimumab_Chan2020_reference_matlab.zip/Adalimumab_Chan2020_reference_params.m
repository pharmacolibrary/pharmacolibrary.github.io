function p = Adalimumab_Chan2020_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: adalimumab   source: Chan_2020 / reference   route: oral
  % estimated (absent from source): ka, dose
  p.name  = 'Adalimumab_Chan2020_reference_params';
  p.drug  = 'adalimumab';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 381.0;                % central volume [L]
  p.CL = 19.5;                % clearance [L/h]
  p.Vp = [284.0];             % peripheral volumes [L]
  p.Q  = [52.8];             % inter-compartmental clearances [L/h]
  p.ka = 0.5;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 100.0;             % dose [mg]
end
