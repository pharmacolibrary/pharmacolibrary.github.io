model Propafenone_Connolly1984_reference
  parameter Real Cl_ref = 1.3066666666666666e-05 "Cl [m3/s]";
  parameter Real Vd_ref = 0.252 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.341444,
    adminMass = 0.0003
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About propafenone</h4><p>Propafenone is an antiarrhythmic medicine used to treat heart rhythm problems such as atrial fibrillation and supraventricular tachycardia. It is an approved medication and remains in use for these cardiac arrhythmias.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q662511\">Wikidata Q662511</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>propafenone</td></tr><tr><td>population:</td><td>patients with ventricular arrhythmias</td></tr><tr><td>source_paper:</td><td>Connolly_1984</td></tr><tr><td>measured_compound:</td><td>propafenone</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>propafenone 341.444 g/mol (drugbank)</td></tr></table><h4>Interpretation flags</h4><ul><li>dropped duplicate Q57 ('elimination t1/2', value 6.2) — already have one for this compound</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=propafenone</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 90000, Tolerance = 1e-9, Interval = 1));
end Propafenone_Connolly1984_reference;
