model Artenimol_Ding2024_reference
  parameter Real Cl_ref = 1.538888888888889e-05 "Cl [m3/s]";
  parameter Real Vd_ref = 2.165975772688236 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.284352,
    adminMass = 1e-05
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About artenimol</h4><p>Artenimol (dihydroartemisinin) is an antimalarial medicine used to treat malaria. It is used both alone and in combination with other antimalarials, and is approved in some regions while still being studied for other uses.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q5276420\">Wikidata Q5276420</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>artenimol</td></tr><tr><td>population:</td><td>review reference</td></tr><tr><td>source_paper:</td><td>Ding_2024</td></tr><tr><td>measured_compound:</td><td>artenimol</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>artenimol 284.352 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>built from REVIEW reference values (Ding_2024) — secondary source</li><li>central volume derived from CL·t½/ln2</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 518400, Tolerance = 1e-9, Interval = 1));
end Artenimol_Ding2024_reference;
