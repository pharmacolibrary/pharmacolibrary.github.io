function p = Eravacycline_Singh2026_PD_mab_burden_7_params()
% Eravacycline_Singh2026_PD_mab_burden_7_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% eravacycline Singh_2026::MAB_burden::7: sigmoid_emax exposure-response sweep (response = E0 + Emax*frac). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one mg/L per second, in SI inside (kg/m3, s). Response MAB burden in log10 CFU/mL. Driver: eravacycline (pk_record).
p.E0 = 9.054;
p.Emax = -4.494;
p.EC50 = 0.06595999999999998;
p.gamma = 0.4493;
p.slope = 0.0;
p.exposure_per_s = 0.001;
p.stop_time = 660.0;
p.form = 'E0 + Emax*frac';
end
