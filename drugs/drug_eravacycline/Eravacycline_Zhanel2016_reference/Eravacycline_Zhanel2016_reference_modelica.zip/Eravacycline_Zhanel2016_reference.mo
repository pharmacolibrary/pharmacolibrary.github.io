model Eravacycline_Zhanel2016_reference
  parameter Real Cl_ref = 3.75e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.00058 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.558563,
    adminMass = 0.00014
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About eravacycline</h4><p>Eravacycline is a tetracycline antibacterial used to treat bacterial infections. It is an approved medicine, with one product authorised in the European Union.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q15410941\">Wikidata Q15410941</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>eravacycline</td></tr><tr><td>population:</td><td>adults</td></tr><tr><td>source_paper:</td><td>Zhanel_2016</td></tr><tr><td>measured_compound:</td><td>eravacycline</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>eravacycline 558.563 g/mol (drugbank)</td></tr></table><h4>Interpretation flags</h4><ul><li>dropped unlinked row (NIL): 'area under the plasma concentration-time curve from 0 to infinity (AUC0-∞)' — extend the ontology if this is a real PK parameter (source ['Zhanel_2016:abstract'])</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=eravacycline</li><li>held at status:extracted — NIL link or unit issue (mismatch/unknown/normalisation-failed) present</li><li>status held at route_to_review — not promoted</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li><li>gap-filled Q61 (V) from Singh_2026's review values (primary lacked it)</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 864000, Tolerance = 1e-9, Interval = 1));
end Eravacycline_Zhanel2016_reference;
