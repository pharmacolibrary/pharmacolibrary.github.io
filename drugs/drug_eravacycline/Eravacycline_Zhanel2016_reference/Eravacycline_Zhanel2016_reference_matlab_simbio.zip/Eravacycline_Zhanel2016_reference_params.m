function p = Eravacycline_Zhanel2016_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: eravacycline   source: Zhanel_2016 / reference   route: iv_bolus
  p.name  = 'Eravacycline_Zhanel2016_reference_params';
  p.drug  = 'eravacycline';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'iv_bolus';        % 'oral' | 'iv_bolus'
  p.depot = false;             % oral -> first-order absorption depot
  p.Vc = 0.58;                % central volume [L]
  p.CL = 13.5;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.0;                % absorption rate [1/h]
  p.F  = 0.28;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 140.0;             % dose [mg]
end
