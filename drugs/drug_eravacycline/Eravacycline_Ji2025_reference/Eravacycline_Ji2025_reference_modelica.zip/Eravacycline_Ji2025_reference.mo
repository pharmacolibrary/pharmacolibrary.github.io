model Eravacycline_Ji2025_reference
  parameter Real Cl_ref = 4.527777777777778e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.0038799999999999998 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.558563,
    adminMass = 7e-05,
    k12 = 0.002426975945017182,
    k21 = 0.00024145299145299142
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About eravacycline</h4><p>Eravacycline is a tetracycline antibacterial used to treat bacterial infections. It is an approved medicine, with one product authorised in the European Union.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q15410941\">Wikidata Q15410941</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>eravacycline</td></tr><tr><td>population:</td><td>healthy adults</td></tr><tr><td>source_paper:</td><td>Ji_2025</td></tr><tr><td>measured_compound:</td><td>eravacycline</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>T1</td></tr><tr><td>input:</td><td>PK_2C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>eravacycline 558.563 g/mol (drugbank)</td></tr></table><h4>Interpretation flags</h4><ul><li>dropped duplicate Q30 ('Q2 (L/h)', value '23.5') — already have one for this compound</li><li>dropped unlinked row (NIL): 'Ratio' — extend the ontology if this is a real PK parameter (source ['T1:row8:col1'])</li><li>NIL: refused to back-fill base 'CL' from footnote/prose loose number 16.3 (source ['T1:footnote']); the table cell was unparseable — needs review</li><li>NIL: refused to back-fill base 'V1' from footnote/prose loose number 3.88 (source ['T1:footnote']); the table cell was unparseable — needs review</li><li>NIL: refused to back-fill base 'Q' from footnote/prose loose number 33.9 (source ['T1:footnote']); the table cell was unparseable — needs review</li><li>NIL: refused to back-fill base 'V2' from footnote/prose loose number 39 (source ['T1:footnote']); the table cell was unparseable — needs review</li><li>NIL: refused to back-fill base 'Q' from footnote/prose loose number 23.5 (source ['T1:footnote']); the table cell was unparseable — needs review</li><li>NIL: refused to back-fill base 'V3' from footnote/prose loose number 122 (source ['T1:footnote']); the table cell was unparseable — needs review</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=eravacycline</li><li>structure disagreement: deterministic 2C vs LLM 3C — review compartment count</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Eravacycline_Ji2025_reference;
