model Eravacycline_Singh2026_PD_mab_burden_3
  "sigmoid_emax exposure-response sweep — Singh_2026 :: MAB burden (MAB burden)"
  extends Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep(
    E0 = 7.05,      // [log10 CFU/mL]
    Emax = -6.76,  // [log10 CFU/mL]
    EC50 = 31.157,  // [kg/m3; mg/L × 0.001]
    gamma = 0.25,
    exposure_per_s = 0.001);   // 1 mg/L per second
  // imax_as_negative_emax: Imax (Q323) enters SigmoidEmaxSweep as −Emax
  annotation(experiment(StartTime = 0, StopTime = 320000, Interval = 640),
    Documentation(info = "<html><body><!-- drug-about --><h4>About eravacycline</h4><p>Eravacycline is a tetracycline antibacterial used to treat bacterial infections. It is an approved medicine, with one product authorised in the European Union.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q15410941\">Wikidata Q15410941</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h4>Eravacycline_Singh2026_PD_mab_burden_3</h4><p>The steady-state exposure-response curve of Singh S et al., <i>Microbiology spectrum 14(1):e0343225</i> 2026 (<a href=\"https://doi.org/10.1128/spectrum.03432-25\">doi:10.1128/spectrum.03432-25</a>) — MAB burden [log10 CFU/mL] against eravacycline mg/L — obtained by sweeping the driver instead of simulating a dose. Model family: sigmoid_emax.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    =       7.05 log10 CFU/mL drug-free response (baseline) (Econ, Q324)
  Emax  =       6.76 log10 CFU/mL maximal effect term (Emax, Q323)
  EC50  =      31157 mg/L     exposure at half of the maximal effect term (EC50, Q321)
  gamma =       0.25          Hill coefficient (H, Q325)</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep\">SigmoidEmaxSweep</a>; this model only supplies the numbers. The x axis is one mg/L of eravacycline per second of simulated time (exposure is in kg/m3): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 7.05   (drug-free)
  exposure = EC50 (31157 mg/L)  response 3.67
  exposure -> infinity  response 0.29</pre></body></html>"));
end Eravacycline_Singh2026_PD_mab_burden_3;
