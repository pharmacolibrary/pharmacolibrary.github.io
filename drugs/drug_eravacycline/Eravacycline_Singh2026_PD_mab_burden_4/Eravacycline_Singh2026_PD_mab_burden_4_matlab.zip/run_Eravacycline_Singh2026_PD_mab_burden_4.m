% run_Eravacycline_Singh2026_PD_mab_burden_4  Evaluate the exposure-response curve and plot response against exposure.
% A sweep is a static map: no ODE solver is needed. exposure runs 0..stop_time*exposure_per_s.
p = Eravacycline_Singh2026_PD_mab_burden_4_params();
exposure = linspace(0, p.stop_time * p.exposure_per_s, 501);
frac = exposure.^p.gamma ./ (p.EC50^p.gamma + exposure.^p.gamma);
E0 = p.E0; Emax = p.Emax; slope = p.slope;
response = E0 + Emax.*frac;
figure; plot(exposure, response, 'LineWidth', 1.5); grid on;
xlabel('exposure [mg/L]'); ylabel('response [log10 CFU/mL]'); title('Eravacycline_Singh2026_PD_mab_burden_4', 'Interpreter', 'none');
writematrix([exposure(:) response(:)], 'Eravacycline_Singh2026_PD_mab_burden_4.csv');
