function p = Eravacycline_Singh2026_PD_mab_burden_2_params()
% Eravacycline_Singh2026_PD_mab_burden_2_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% eravacycline Singh_2026::MAB_burden::2: sigmoid_emax exposure-response sweep (response = E0 + Emax*frac). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one mg/L per second, in SI inside (kg/m3, s). Response MAB burden in log10 CFU/mL. Driver: eravacycline (pk_record).
p.E0 = 6.0;
p.Emax = -1.66;
p.EC50 = 0.08626999999999999;
p.gamma = 1.43;
p.slope = 0.0;
p.exposure_per_s = 0.001;
p.stop_time = 870.0;
p.form = 'E0 + Emax*frac';
end
