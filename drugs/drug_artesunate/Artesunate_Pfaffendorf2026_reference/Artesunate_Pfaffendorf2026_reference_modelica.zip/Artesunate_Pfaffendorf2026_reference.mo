model Artesunate_Pfaffendorf2026_reference
  parameter Real Cl_ref = 1.6194444444444444e-05 "Cl [m3/s]";
  parameter Real Vd_ref = 0.248 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.384425,
    adminMass = 0.00028,
    ka = 0.00019388888888888887,
    Tlag = 378.0
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About artesunate</h4><p>Artesunate is an antimalarial medicine used to treat malaria, available alone or in combination with other antimalarials. It is widely used worldwide, is included on the WHO essential medicines list, and one product is authorised in the European Union.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q707939\">Wikidata Q707939</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>artesunate</td></tr><tr><td>population:</td><td>review reference</td></tr><tr><td>source_paper:</td><td>Pfaffendorf_2026</td></tr><tr><td>measured_compound:</td><td>artesunate</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>artesunate 384.425 g/mol (drugbank)</td></tr></table><h4>Interpretation flags</h4><ul><li>built from REVIEW reference values (Pfaffendorf_2026) — secondary source</li><li>volume reported by review</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Artesunate_Pfaffendorf2026_reference;
