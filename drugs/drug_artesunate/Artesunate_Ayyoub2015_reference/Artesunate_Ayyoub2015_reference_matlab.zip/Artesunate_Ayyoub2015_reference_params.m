function p = Artesunate_Ayyoub2015_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: artesunate   source: Ayyoub_2015 / reference   route: oral
  p.name  = 'Artesunate_Ayyoub2015_reference_params';
  p.drug  = 'artesunate';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 7179.427601;                % central volume [L]
  p.CL = 15.708333;                % clearance [L/h]
  p.Vp = [2230.0];             % peripheral volumes [L]
  p.Q  = [33.5];             % inter-compartmental clearances [L/h]
  p.ka = 0.745833;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 280.0;             % dose [mg]
end
