model Artesunate_Mim2026_PD_parasitemia_parasite_count
  "indirect_response_i exposure-response sweep — Mim_2026 :: parasitemia (parasite count) (parasitemia (parasite count))"
  extends Pharmacolibrary.Interfaces.PartialExposureResponseSweep(
    E0 = 0,      // [1]
    Emax = 1,  // type I effect term
    EC50 = 4.4e-06,  // [kg/m3; ug/mL × 0.001]
    gamma = 1,
    exposure_per_s = 0.001);   // 1 ug/mL per second
equation
  response = E0*(1 - Emax*frac);   // steady state, indirect response type I
  // defaulted: E0
  // defaulted: Emax
  // defaulted: gamma
  annotation(experiment(StartTime = 0, StopTime = 0.044, Interval = 8.8e-05),
    Documentation(info = "<html><body><!-- drug-about --><h4>About artesunate</h4><p>Artesunate is an antimalarial medicine used to treat malaria, available alone or in combination with other antimalarials. It is widely used worldwide, is included on the WHO essential medicines list, and one product is authorised in the European Union.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q707939\">Wikidata Q707939</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h4>Artesunate_Mim2026_PD_parasitemia_parasite_count</h4><p>The steady-state exposure-response curve of Mim SR et al., <i>Antimicrobial agents and chemotherapy 70(3):e0171725</i> 2026 (<a href=\"https://doi.org/10.1128/aac.01717-25\">doi:10.1128/aac.01717-25</a>) — parasitemia (parasite count) [%] against artesunate ug/mL — obtained by sweeping the driver instead of simulating a dose. Model family: indirect_response_i.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = (library default) drug-free response (baseline)
  Emax  = (library default) maximal effect term
  EC50  =     0.0044 ug/mL    exposure at half of the maximal effect term (Half-maximal inhibitory concentration, IC50 (AS), Q322)
  gamma = (library default) Hill coefficient</pre><p>The algebra is <code>response = E0*(1 - Emax*frac)</code>; this model only supplies the numbers. The x axis is one ug/mL of artesunate per second of simulated time (exposure is in kg/m3): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0   (drug-free)
  exposure = EC50 (0.0044 ug/mL)  response 0
  exposure -> infinity  response 0</pre></body></html>"));
end Artesunate_Mim2026_PD_parasitemia_parasite_count;
