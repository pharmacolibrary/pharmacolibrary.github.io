model Ambrisentan_Hill2020_reference
  parameter Real Cl_ref = 2.7777777777777776e-07 "Cl [m3/s]";
  parameter Real Vd_ref = 0.0137 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.378428,
    adminMass = 1e-05
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>ambrisentan</td></tr><tr><td>population:</td><td>children after Fontan surgery</td></tr><tr><td>source_paper:</td><td>Hill_2020</td></tr><tr><td>measured_compound:</td><td>ambrisentan</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>ambrisentan 378.428 g/mol (drugbank)</td></tr></table><h4>Interpretation flags</h4><ul><li>dropped unlinked row (NIL): 'plasma brain natriuretic peptide concentrations' — extend the ontology if this is a real PK parameter (source ['Hill_2020:abstract'])</li><li>dropped unlinked row (NIL): 'Fontan pressures' — extend the ontology if this is a real PK parameter (source ['Hill_2020:abstract'])</li><li>dropped unlinked row (NIL): 'indexed pulmonary vascular resistance' — extend the ontology if this is a real PK parameter (source ['Hill_2020:abstract'])</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=ambrisentan</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 172800, Tolerance = 1e-9, Interval = 1));
end Ambrisentan_Hill2020_reference;
