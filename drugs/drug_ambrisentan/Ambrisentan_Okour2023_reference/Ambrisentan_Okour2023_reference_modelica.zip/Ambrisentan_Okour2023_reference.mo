model Ambrisentan_Okour2023_reference
  parameter Real Cl_ref = 3.25e-07 "Cl [m3/s]";
  parameter Real Vd_ref = 0.0123 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.378428,
    adminMass = 2.5e-06,
    ka = 0.0006833333333333333,
    Tlag = 1890.0,
    k12 = 1.0320686540198736e-05,
    k21 = 1.5614322809894768e-06
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About ambrisentan</h4><p>Ambrisentan is an antihypertensive drug used to treat pulmonary arterial hypertension. It is authorised in the European Union and is also used for related conditions such as portal and chronic pulmonary hypertension.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q410789\">Wikidata Q410789</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>ambrisentan</td></tr><tr><td>population:</td><td>pediatric patients with pulmonary arterial hypertension</td></tr><tr><td>source_paper:</td><td>Okour_2023</td></tr><tr><td>measured_compound:</td><td>ambrisentan</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>tab_1</td></tr><tr><td>input:</td><td>PK_2C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>ambrisentan 378.428 g/mol (drugbank)</td></tr></table><h4>Interpretation flags</h4><ul><li>routed 'Covar η CL , η Vc' → Q314 (omega_cov) to covariance — variability estimate, not a structural parameter</li><li>routed 'Covar η CL , η Q' → Q314 (omega_cov) to covariance — variability estimate, not a structural parameter</li><li>routed 'Covar η Vc , η Q' → Q314 (omega_cov) to covariance — variability estimate, not a structural parameter</li><li>routed 'Covar η CL , η Vp' → Q314 (omega_cov) to covariance — variability estimate, not a structural parameter</li><li>routed 'Covar η Vc , η Vp' → Q314 (omega_cov) to covariance — variability estimate, not a structural parameter</li><li>routed 'Covar η Q , η Vp' → Q314 (omega_cov) to covariance — variability estimate, not a structural parameter</li><li>routed 'Covar η CL , η Ka' → Q314 (omega_cov) to covariance — variability estimate, not a structural parameter</li><li>routed 'Covar η Vc , η Ka' → Q314 (omega_cov) to covariance — variability estimate, not a structural parameter</li><li>routed 'Covar η Q , η Ka' → Q314 (omega_cov) to covariance — variability estimate, not a structural parameter</li><li>routed 'Covar η Vp , η Ka' → Q314 (omega_cov) to covariance — variability estimate, not a structural parameter</li><li>routed 'Covar η CL , η tlag' → Q314 (omega_cov) to covariance — variability estimate, not a structural parameter</li><li>routed 'Covar η Vc , η tlag' → Q314 (omega_cov) to covariance — variability estimate, not a structural parameter</li><li>routed 'Covar η Q , η tlag' → Q314 (omega_cov) to covariance — variability estimate, not a structural parameter</li><li>routed 'Covar η Vp , η tlag' → Q314 (omega_cov) to covariance — variability estimate, not a structural parameter</li><li>routed 'Covar η Ka , η tlag' → Q314 (omega_cov) to covariance — variability estimate, not a structural parameter</li><li>covariate effect for Q319 has no base parameter row (kept as unattached equation-variable)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 136800, Tolerance = 1e-9, Interval = 1));
end Ambrisentan_Okour2023_reference;
