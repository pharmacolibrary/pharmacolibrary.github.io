function p = Ambrisentan_Okour2023_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: ambrisentan   source: Okour_2023 / reference   route: oral
  p.name  = 'Ambrisentan_Okour2023_reference_params';
  p.drug  = 'ambrisentan';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 12.3;                % central volume [L]
  p.CL = 1.17;                % clearance [L/h]
  p.Vp = [81.3];             % peripheral volumes [L]
  p.Q  = [0.457];             % inter-compartmental clearances [L/h]
  p.ka = 2.46;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.525;             % absorption lag [h]
  p.dose = 2.5;             % dose [mg]
end
