model Oxazepam_Dingemanse1988_PD_ptz_threshold
  "sigmoid_emax exposure-response sweep — Dingemanse_1988 :: PTZ threshold (elevation of the serum or brain threshold concentration of PTZ (anticonvulsant response))"
  extends Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep(
    E0 = 0,      // [1]
    Emax = 120,  // [mg/L PTZ]
    EC50 = 0.0005,  // [kg/m3; mg/L × 0.001]
    gamma = 1,
    exposure_per_s = 0.001);   // 1 mg/L per second
  // defaulted: E0
  // defaulted: gamma
  annotation(experiment(StartTime = 0, StopTime = 5, Interval = 0.01),
    Documentation(info = "<html><body><!-- drug-about --><h4>About oxazepam</h4><p>Oxazepam is a benzodiazepine used to treat anxiety disorders and focal epilepsy, and also acts as a sedative and hypnotic. It is an approved medicine and remains in use, though it carries a boxed warning.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q412299\">Wikidata Q412299</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h4>Oxazepam_Dingemanse1988_PD_ptz_threshold</h4><p>The steady-state exposure-response curve of Dingemanse J et al., <i>Journal of pharmacokinetics and biopharmaceutics 16(2):203–228</i> 1988 (<a href=\"https://doi.org/10.1007/BF01062261\">doi:10.1007/BF01062261</a>) — elevation of the serum or brain threshold concentration of PTZ (anticonvulsant response) [mg/L PTZ] against oxazepam mg/L — obtained by sweeping the driver instead of simulating a dose. Model family: sigmoid_emax.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = (library default) drug-free response (baseline)
  Emax  =        120 mg/L PTZ maximal effect term (Emax, Q320)
  EC50  =        0.5 mg/L     exposure at half of the maximal effect term (EC50, Q321)
  gamma = (library default) Hill coefficient</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep\">SigmoidEmaxSweep</a>; this model only supplies the numbers. The x axis is one mg/L of oxazepam per second of simulated time (exposure is in kg/m3): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0   (drug-free)
  exposure = EC50 (0.5 mg/L)  response 60
  exposure -> infinity  response 120</pre></body></html>"));
end Oxazepam_Dingemanse1988_PD_ptz_threshold;
