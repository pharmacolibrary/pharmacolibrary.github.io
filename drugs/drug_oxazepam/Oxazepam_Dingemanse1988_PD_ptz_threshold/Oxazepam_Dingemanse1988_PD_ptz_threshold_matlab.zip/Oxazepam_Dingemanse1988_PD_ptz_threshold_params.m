function p = Oxazepam_Dingemanse1988_PD_ptz_threshold_params()
% Oxazepam_Dingemanse1988_PD_ptz_threshold_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% oxazepam Dingemanse_1988::PTZ_threshold: sigmoid_emax exposure-response sweep (response = E0 + Emax*frac). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one mg/L per second, in SI inside (kg/m3, s). Response PTZ threshold in mg/L PTZ. Driver: oxazepam (pk_record).
p.E0 = 0.0;
p.Emax = 120.0;
p.EC50 = 0.0004999999999999999;
p.gamma = 1.0;
p.slope = 0.0;
p.exposure_per_s = 0.001;
p.stop_time = 5.0;
p.form = 'E0 + Emax*frac';
end
