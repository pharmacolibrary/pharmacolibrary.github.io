model Oxazepam_Imbert2016_reference
  parameter Real Cl_ref = 1.8888888888888888e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.159 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.286713,
    adminMass = 5e-05,
    ka = 0.0001388888888888889,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About oxazepam</h4><p>Oxazepam is a benzodiazepine used to treat anxiety disorders and focal epilepsy, and also acts as a sedative and hypnotic. It is an approved medicine and remains in use, though it carries a boxed warning.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q412299\">Wikidata Q412299</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>oxazepam</td></tr><tr><td>population:</td><td>alcohol-dependent outpatients treated for alcohol withdrawal syndrome</td></tr><tr><td>source_paper:</td><td>Imbert_2016</td></tr><tr><td>measured_compound:</td><td>oxazepam</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C_enteral: apparent (/F) parameterization ⇒ extravascular dosing</td></tr><tr><td>molar_masses:</td><td>oxazepam 286.713 g/mol (drugbank)</td></tr></table><p><b>Defaulted (base-class default used):</b> ka, Tlag.</p><h4>Interpretation flags</h4><ul><li>routed 'interindividual variability of clearance' → Q312 (IIV) to iiv — variability estimate, not a structural parameter</li><li>routed 'interindividual variability of V' → Q312 (IIV) to iiv — variability estimate, not a structural parameter</li><li>apparent-ness (ontology-grounded): parameterization=apparent, measured_compound=oxazepam</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 345600, Tolerance = 1e-9, Interval = 1));
end Oxazepam_Imbert2016_reference;
