model AntithrombinIii_Kim2020_reference
  parameter Real Cl_ref = 3.5833333333333337e-08 "Cl [m3/s]";
  parameter Real Vd_ref = 0.00386 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    adminMass = 1e-05
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About antithrombin_iii</h4><p>Antithrombin III is a blood protein used to treat or prevent excessive clotting, especially in people with antithrombin deficiency, and it works together with heparin. It is an approved medicine, given by infusion, mainly in hospital settings for clotting problems.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q24775482\">Wikidata Q24775482</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>antithrombin_iii</td></tr><tr><td>population:</td><td>liver transplant recipients</td></tr><tr><td>source_paper:</td><td>Kim_2020</td></tr><tr><td>measured_compound:</td><td>antithrombin_iii</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C: IV (no input phase)</td></tr></table><h4>Interpretation flags</h4><ul><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=antithrombin_iii</li><li>molar mass: none found for 'antithrombin_iii' — its concentrations stay mass-only</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 432000, Tolerance = 1e-9, Interval = 1));
end AntithrombinIii_Kim2020_reference;
