function p = Zalcitabine_Ibrahim1991_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: zalcitabine   source: Ibrahim_1991 / reference   route: oral
  % estimated (absent from source): F
  p.name  = 'Zalcitabine_Ibrahim1991_reference_params';
  p.drug  = 'zalcitabine';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 42.0;                % central volume [L]
  p.CL = 103.6;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 50.0;                % absorption rate [1/h]
  p.F  = 0.9;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 2.25;             % dose [mg]
end
