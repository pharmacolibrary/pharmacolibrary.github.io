model Zalcitabine_Ibrahim1991_reference
  parameter Real Cl_ref = 2.877777777777778e-05 "Cl [m3/s]";
  parameter Real Vd_ref = 0.041999999999999996 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 0.9,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.211221,
    adminMass = 2.25e-06,
    ka = 0.013888888888888888,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About zalcitabine</h4><p>Zalcitabine is a nucleoside reverse transcriptase inhibitor that was used to treat HIV infection and AIDS. It has been withdrawn and is no longer used.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q2344582\">Wikidata Q2344582</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>zalcitabine</td></tr><tr><td>population:</td><td>rats administered high-dose DDC</td></tr><tr><td>source_paper:</td><td>Ibrahim_1991</td></tr><tr><td>measured_compound:</td><td>2',3'-dideoxycytidine (DDC; zalcitabine)</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>2',3'-dideoxycytidine (DDC; zalcitabine) 211.221 g/mol (pubchem); zalcitabine 211.218 g/mol (drugbank)</td></tr></table><p><b>Defaulted (base-class default used):</b> F, Tlag.</p><h4>Interpretation flags</h4><ul><li>covariate renal for CLint from footnote/prose kept as documentation only (['Ibrahim_1991:abstract', 'Ibrahim_1991:abstract'])</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=2',3'-dideoxycytidine (DDC; zalcitabine)</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li><li>gap-filled Q61 (V) from Gründer_2003's review values (primary lacked it)</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li><li>gap-filled Q49 (kabs) from Senek_2020's review values (primary lacked it)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Zalcitabine_Ibrahim1991_reference;
