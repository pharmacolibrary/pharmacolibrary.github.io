model Zalcitabine_Adams1998_reference
  parameter Real Cl_ref = 4.111111111111111e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.0876 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.2112178,
    adminMass = 2.25e-06,
    ka = 0.013888888888888888,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About zalcitabine</h4><p>Zalcitabine is a nucleoside reverse transcriptase inhibitor that was used to treat HIV infection and AIDS. It has been withdrawn and is no longer used.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q2344582\">Wikidata Q2344582</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>zalcitabine</td></tr><tr><td>population:</td><td>HIV-infected patients</td></tr><tr><td>source_paper:</td><td>Adams_1998</td></tr><tr><td>measured_compound:</td><td>zalcitabine</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>zalcitabine 211.218 g/mol (drugbank)</td></tr></table><p><b>Defaulted (base-class default used):</b> Tlag.</p><h4>Interpretation flags</h4><ul><li>dropped unlinked row (NIL): 'age' — extend the ontology if this is a real PK parameter (source ['Adams_1998:abstract'])</li><li>dropped unlinked row (NIL): 'weight' — extend the ontology if this is a real PK parameter (source ['Adams_1998:abstract'])</li><li>dropped value-less row: 'individual estimates of oral clearance (range'</li><li>dropped value-less row: 'individual estimates of oral clearance'</li><li>dropped value-less row: 'volume of distribution (range'</li><li>apparent-ness (ontology-grounded): parameterization=apparent, measured_compound=zalcitabine</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li><li>gap-filled Q49 (kabs) from Senek_2020's review values (primary lacked it)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Zalcitabine_Adams1998_reference;
