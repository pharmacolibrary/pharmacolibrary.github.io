model Empagliflozin_Sato2024_PD_hba1c
  "sigmoid_emax exposure-response sweep — Sato_2024 :: HbA1c (HbA1c change)"
  extends Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep(
    E0 = -0.00124,      // [1; % × 0.01]
    Emax = -0.00796,  // [1; % × 0.01]
    EC50 = 0.251,  // [normalized dose]
    gamma = 0.662,
    exposure_per_s = 1);   // 1 normalized dose per second
  // imax_as_negative_emax: Imax (Q323) enters SigmoidEmaxSweep as −Emax
  // exposure_unit_unresolved: 'normalized dose' — the x axis is in the paper's unit, not SI
  annotation(experiment(StartTime = 0, StopTime = 2.6, Interval = 0.0052),
    Documentation(info = "<html><body><!-- drug-about --><h4>About empagliflozin</h4><p>Empagliflozin is an anti-diabetic medicine (an SGLT2 inhibitor) used to lower blood sugar in type 2 diabetes, and also used for heart failure and chronic kidney disease. It is authorised in the European Union and widely used.</p><p><small>Summary written by glm-5.3-flash from <a href=&quot;https://www.wikidata.org/wiki/Q5373824&quot;>Wikidata Q5373824</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h4>Empagliflozin_Sato2024_PD_hba1c</h4><p>The steady-state exposure-response curve of Sato H et al., <i>Scientific reports 14(1):24695</i> 2024 (<a href=\"https://doi.org/10.1038/s41598-024-76256-6\">doi:10.1038/s41598-024-76256-6</a>) — HbA1c change [%] against empagliflozin normalized dose — obtained by sweeping the driver instead of simulating a dose. Model family: sigmoid_emax.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    =     -0.124 %        drug-free response (baseline) (Base, Q324)
  Emax  =     -0.796 %        maximal effect term (Emax, Q323)
  EC50  =      0.251 normalized dose exposure at half of the maximal effect term (ED50, Q321)
  gamma =      0.662          Hill coefficient (n, Q325)</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep\">SigmoidEmaxSweep</a>; this model only supplies the numbers. The x axis is one normalized dose of empagliflozin per second of simulated time: there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response -0.00124   (drug-free)
  exposure = EC50 (0.251 normalized dose)  response -0.00522
  exposure -> infinity  response -0.0092</pre></body></html>"));
end Empagliflozin_Sato2024_PD_hba1c;
