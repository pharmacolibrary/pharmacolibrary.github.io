function p = Empagliflozin_Sato2024_PD_hba1c_params()
% Empagliflozin_Sato2024_PD_hba1c_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% empagliflozin Sato_2024::HbA1c: sigmoid_emax exposure-response sweep (response = E0 + Emax*frac). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one normalized dose per second, in SI inside (kg/m3, s). Response HbA1c in %. Driver: empagliflozin (dose_only).
p.E0 = -0.00124;
p.Emax = -0.00796;
p.EC50 = 0.251;
p.gamma = 0.662;
p.slope = 0.0;
p.exposure_per_s = 1.0;
p.stop_time = 2.6;
p.form = 'E0 + Emax*frac';
end
