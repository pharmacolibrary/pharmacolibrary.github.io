model Empagliflozin_Rascher2025_PD_hba1c
  "indirect_response_i exposure-response sweep — Rascher_2025 :: HbA1c (glycosylated haemoglobin)"
  extends Pharmacolibrary.Pharmacodynamic.IndirectTurnoverSweep(
    E0 = 0.0735,      // [1; % × 0.01]
    Emax = 10.1,  // type IV effect term
    EC50 = 703,  // [nmol*hr/L]
    gamma = 1,
    exposure_per_s = 1);   // 1 nmol*hr/L per second
  // emax_not_a_fraction: type I needs Imax ≤ 1 but the record has 10.1; bound as the reciprocal stimulation form (IV) the paper fitted
  // exposure_unit_unresolved: 'nmol*hr/L' — the x axis is in the paper's unit, not SI
  // defaulted: gamma
  annotation(experiment(StartTime = 0, StopTime = 1100, Interval = 2.2),
    Documentation(info = "<html><body><!-- drug-about --><h4>About empagliflozin</h4><p>Empagliflozin is an anti-diabetic medicine (an SGLT2 inhibitor) used to lower blood sugar in type 2 diabetes, and also used for heart failure and chronic kidney disease. It is authorised in the European Union and widely used.</p><p><small>Summary written by glm-5.3-flash from <a href=&quot;https://www.wikidata.org/wiki/Q5373824&quot;>Wikidata Q5373824</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h4>Empagliflozin_Rascher2025_PD_hba1c</h4><p>The steady-state exposure-response curve of Rascher J et al., <i>British journal of clinical pharmacology 91(8):2390–2400</i> 2025 (<a href=\"https://doi.org/10.1002/bcp.70096\">doi:10.1002/bcp.70096</a>) — glycosylated haemoglobin [%] against empagliflozin nmol*hr/L — obtained by sweeping the driver instead of simulating a dose. Model family: indirect_response_i.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    =       7.35 %        drug-free response (baseline) (Baseline HbA1c, Q324)
  Emax  =       10.1          maximal effect term (Maximum inhibition, Q323)
  EC50  =        703 nmol*hr/L exposure at half of the maximal effect term (AUC at 50% IMAX, Q322)
  gamma = (library default) Hill coefficient</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.IndirectTurnoverSweep\">IndirectTurnoverSweep</a>; this model only supplies the numbers. The x axis is one nmol*hr/L of empagliflozin per second of simulated time: there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><p>The effect term enters as a reciprocal (steady state of <code>der(R) = Kin - Kout*(1 + Emax*frac)*R</code>), so EC50 is the exposure at half the maximal STIMULATION of turnover, not at half the response.</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0.0735   (drug-free)
  exposure = EC50 (703 nmol*hr/L)  response 0.01215
  exposure -> infinity  response 0.006622</pre></body></html>"));
end Empagliflozin_Rascher2025_PD_hba1c;
