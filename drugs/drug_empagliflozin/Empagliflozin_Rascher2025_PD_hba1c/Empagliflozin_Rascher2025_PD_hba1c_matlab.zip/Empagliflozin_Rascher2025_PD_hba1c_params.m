function p = Empagliflozin_Rascher2025_PD_hba1c_params()
% Empagliflozin_Rascher2025_PD_hba1c_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% empagliflozin Rascher_2025::HbA1c: indirect_response_i exposure-response sweep (response = E0/(1 + Emax*frac)). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one nmol*hr/L per second, in SI inside (kg/m3, s). Response HbA1c in %. Driver: empagliflozin (pk_record).
p.E0 = 0.0735;
p.Emax = 10.1;
p.EC50 = 703.0;
p.gamma = 1.0;
p.slope = 0.0;
p.exposure_per_s = 1.0;
p.stop_time = 1100.0;
p.form = 'E0/(1 + Emax*frac)';
end
