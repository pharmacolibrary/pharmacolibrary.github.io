model Empagliflozin_van2023_PD_uge
  "linear exposure-response sweep — van_2023 :: UGE (Urinary glucose excretion)"
  extends Pharmacolibrary.Interfaces.PartialExposureResponseSweep(
    E0 = 0,      // [1]
    Emax = 0, EC50 = 1,      // unused by a line
    exposure_per_s = 1);
  parameter Real slope = 0.4805   "[dimensionless; % × 0.01]";
equation
  response = E0 + slope*exposure;
  // defaulted: E0
  annotation(experiment(StartTime = 0, StopTime = 1000, Interval = 2),
    Documentation(info = "<html><body><!-- drug-about --><h4>About empagliflozin</h4><p>Empagliflozin is an anti-diabetic medicine (an SGLT2 inhibitor) used to lower blood sugar in type 2 diabetes, and also used for heart failure and chronic kidney disease. It is authorised in the European Union and widely used.</p><p><small>Summary written by glm-5.3-flash from <a href=&quot;https://www.wikidata.org/wiki/Q5373824&quot;>Wikidata Q5373824</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h4>Empagliflozin_van2023_PD_uge</h4><p>The steady-state exposure-response curve of van der Hoek S et al., <i>Journal of personalized medicine 13(5)</i> 2023 (<a href=\"https://doi.org/10.3390/jpm13050747\">doi:10.3390/jpm13050747</a>) — Urinary glucose excretion [mmol/24 h] against empagliflozin nmol/L*h — obtained by sweeping the driver instead of simulating a dose. Model family: linear.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = (library default) drug-free response (baseline)
  slope =      48.05 %        change in response per unit of exposure (β per Doubling AUC, Q335)</pre><p>The algebra is <code>response = E0 + slope*exposure</code>; this model only supplies the numbers. The x axis is one nmol/L*h of empagliflozin per second of simulated time: there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0   (drug-free)</pre></body></html>"));
end Empagliflozin_van2023_PD_uge;
