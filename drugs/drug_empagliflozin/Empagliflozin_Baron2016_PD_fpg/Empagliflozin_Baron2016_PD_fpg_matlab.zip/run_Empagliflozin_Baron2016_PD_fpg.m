% run_Empagliflozin_Baron2016_PD_fpg  Evaluate the exposure-response curve and plot response against exposure.
% A sweep is a static map: no ODE solver is needed. exposure runs 0..stop_time*exposure_per_s.
p = Empagliflozin_Baron2016_PD_fpg_params();
exposure = linspace(0, p.stop_time * p.exposure_per_s, 501);
frac = exposure.^p.gamma ./ (p.EC50^p.gamma + exposure.^p.gamma);
E0 = p.E0; Emax = p.Emax; slope = p.slope;
response = E0./(1 + Emax.*frac);
figure; plot(exposure, response, 'LineWidth', 1.5); grid on;
xlabel('exposure [nM*h]'); ylabel('response [mM]'); title('Empagliflozin_Baron2016_PD_fpg', 'Interpreter', 'none');
writematrix([exposure(:) response(:)], 'Empagliflozin_Baron2016_PD_fpg.csv');
