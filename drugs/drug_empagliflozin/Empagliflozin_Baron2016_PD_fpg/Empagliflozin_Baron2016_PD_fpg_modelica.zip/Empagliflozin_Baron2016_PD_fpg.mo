model Empagliflozin_Baron2016_PD_fpg
  "indirect_response_ii exposure-response sweep — Baron_2016 :: FPG (Fasting plasma glucose)"
  extends Pharmacolibrary.Pharmacodynamic.IndirectTurnoverSweep(
    E0 = 0,      // [1]
    Emax = 22,  // type IV effect term
    EC50 = 704,  // [nM*h]
    gamma = 1,
    exposure_per_s = 1);   // 1 nM*h per second
  // emax_not_a_fraction: type II needs Imax ≤ 1 but the record has 22; bound as the reciprocal stimulation form (IV) the paper fitted
  // exposure_unit_unresolved: 'nM*h' — the x axis is in the paper's unit, not SI
  // defaulted: E0
  // defaulted: gamma
  annotation(experiment(StartTime = 0, StopTime = 7100, Interval = 14.2),
    Documentation(info = "<html><body><!-- drug-about --><h4>About empagliflozin</h4><p>Empagliflozin is an anti-diabetic medicine (an SGLT2 inhibitor) used to lower blood sugar in type 2 diabetes, and also used for heart failure and chronic kidney disease. It is authorised in the European Union and widely used.</p><p><small>Summary written by glm-5.3-flash from <a href=&quot;https://www.wikidata.org/wiki/Q5373824&quot;>Wikidata Q5373824</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h4>Empagliflozin_Baron2016_PD_fpg</h4><p>The steady-state exposure-response curve of Baron KT et al., <i>Diabetes therapy : research, treatment and education of diabetes and related disorders 7(3):455–471</i> 2016 (<a href=\"https://doi.org/10.1007/s13300-016-0174-y\">doi:10.1007/s13300-016-0174-y</a>) — Fasting plasma glucose [mM] against empagliflozin nM*h — obtained by sweeping the driver instead of simulating a dose. Model family: indirect_response_ii.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = (library default) drug-free response (baseline)
  Emax  =         22          maximal effect term (G max, Q320)
  EC50  =        704 nM*h     exposure at half of the maximal effect term (AUC50, Q321)
  gamma = (library default) Hill coefficient</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.IndirectTurnoverSweep\">IndirectTurnoverSweep</a>; this model only supplies the numbers. The x axis is one nM*h of empagliflozin per second of simulated time: there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><p>The effect term enters as a reciprocal (steady state of <code>der(R) = Kin - Kout*(1 + Emax*frac)*R</code>), so EC50 is the exposure at half the maximal STIMULATION of turnover, not at half the response.</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0   (drug-free)
  exposure = EC50 (704 nM*h)  response 0
  exposure -> infinity  response 0</pre></body></html>"));
end Empagliflozin_Baron2016_PD_fpg;
