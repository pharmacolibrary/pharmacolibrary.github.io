model Caffeine_Guo2020_reference
  parameter Real Cl_ref = 7.444444444444444e-08 "Cl [m3/s]";
  parameter Real Vd_ref = 0.109 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.1941906,
    adminMass = 0.0004
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About caffeine</h4><p>Caffeine is a stimulant used to treat breathing problems such as apnea in newborns, and is also used in dermatological and diagnostic preparations. It is widely used and authorised in the European Union, mainly for apnea of prematurity.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q60235\">Wikidata Q60235</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>caffeine</td></tr><tr><td>population:</td><td>Chinese premature infants with apnea</td></tr><tr><td>source_paper:</td><td>Guo_2020</td></tr><tr><td>measured_compound:</td><td>caffeine</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>caffeine 194.191 g/mol (drugbank)</td></tr></table><h4>Interpretation flags</h4><ul><li>unit_dimension_unknown: 'L per 70 kg' (V)</li><li>implicit units: 'volume of distribution (V)' → L (from the popPK convention: 'No unit is stated in the provided text or table captions. The value 109 is a typical magnitude for a volume of distribut')</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=caffeine</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 5443200, Tolerance = 1e-9, Interval = 1));
end Caffeine_Guo2020_reference;
