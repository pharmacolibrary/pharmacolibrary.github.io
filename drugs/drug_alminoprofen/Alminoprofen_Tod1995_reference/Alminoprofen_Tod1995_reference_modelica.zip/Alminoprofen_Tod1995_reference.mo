model Alminoprofen_Tod1995_reference
  parameter Real Cl_ref = 4.833333333333333e-09 "Cl [m3/s]";
  parameter Real Vd_ref = 0.011 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 0.9,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.21928399999999998,
    adminMass = 0.0001,
    ka = 0.0007777777777777777,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About alminoprofen</h4><p>Alminoprofen is a propionic acid derivative that acts as a non-steroidal anti-inflammatory drug, a class used for pain and inflammatory conditions. It is not an approved medicine in major markets and appears only as an experimental compound, so its current availability is unclear.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q3612806\">Wikidata Q3612806</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>alminoprofen</td></tr><tr><td>population:</td><td>patients with knee effusion</td></tr><tr><td>source_paper:</td><td>Tod_1995</td></tr><tr><td>measured_compound:</td><td>alminoprofen</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>alminoprofen 219.284 g/mol (drugbank)</td></tr></table><p><b>Defaulted (base-class default used):</b> F, Tlag.</p><h4>Interpretation flags</h4><ul><li>routed 'interindividual variability' → Q312 (IIV) to iiv — variability estimate, not a structural parameter</li><li>dropped duplicate Q22 ('clearance of efflux into plasma', value 0.56) — already have one for this compound</li><li>apparent-by-design (ADVISORY, codes unchanged): extravascular dosing with no identifiable F, so these reported disposition parameters are likely apparent unless the model puts first-pass in its structure — Q61 (volume of distribution); Q22 (clearance of influx into SF)</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=alminoprofen</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary's parameterization (rate-constant / ka-only) does not use it</li><li>skipped review gap-fill of TLAG: primary's parameterization (rate-constant / ka-only) does not use it</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 8467200, Tolerance = 1e-9, Interval = 1));
end Alminoprofen_Tod1995_reference;
