model Octreotide_Choe2017_reference
  parameter Real Cl_ref = 1.388888888888889e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.1 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 1.019247,
    adminMass = 0.0001,
    ka = 0.0002777777777777778,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About octreotide</h4><p>Octreotide, a somatostatin analogue, is used to treat acromegaly and various neuroendocrine conditions such as carcinoid syndrome and pancreatic cancer. It is an approved medicine, authorised in the European Union for acromegaly, and is also being investigated for other uses.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q419935\">Wikidata Q419935</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>octreotide</td></tr><tr><td>population:</td><td>review reference</td></tr><tr><td>source_paper:</td><td>Choe_2017</td></tr><tr><td>measured_compound:</td><td>octreotide</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>octreotide 1019.25 g/mol (pubchem)</td></tr></table><p><b>Defaulted (base-class default used):</b> Tlag.</p><h4>Interpretation flags</h4><ul><li>built from REVIEW reference values (Choe_2017) — secondary source</li><li>volume reported by review</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 345600, Tolerance = 1e-9, Interval = 1));
end Octreotide_Choe2017_reference;
