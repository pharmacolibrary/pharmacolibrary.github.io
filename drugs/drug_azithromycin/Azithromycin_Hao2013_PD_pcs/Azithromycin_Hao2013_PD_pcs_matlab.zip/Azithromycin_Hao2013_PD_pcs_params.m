function p = Azithromycin_Hao2013_PD_pcs_params()
% Azithromycin_Hao2013_PD_pcs_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% azithromycin Hao_2013::PCs: indirect_response_i exposure-response sweep (response = E0*(1 - Emax*frac)). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one ug/ml per second, in SI inside (kg/m3, s). Response PCs in pg·ml−1. Driver: azithromycin (cited_pk).
p.E0 = 4.98e-08;
p.Emax = 0.83;
p.EC50 = 0.006299999999999998;
p.gamma = 1.0;
p.slope = 0.0;
p.exposure_per_s = 0.001;
p.stop_time = 63.0;
p.form = 'E0*(1 - Emax*frac)';
end
