model Azithromycin_Hao2013_PD_pcs
  "indirect_response_i exposure-response sweep — Hao_2013 :: PCs (plasma proinflammatory cytokines)"
  extends Pharmacolibrary.Interfaces.PartialExposureResponseSweep(
    E0 = 4.98e-08,      // [kg/m3; pg·ml−1 × 1e-09]
    Emax = 0.83,  // type I effect term
    EC50 = 0.0063,  // [kg/m3; ug/ml × 0.001]
    gamma = 1,
    exposure_per_s = 0.001);   // 1 ug/ml per second
equation
  response = E0*(1 - Emax*frac);   // steady state, indirect response type I
  // defaulted: gamma
  annotation(experiment(StartTime = 0, StopTime = 63, Interval = 0.126),
    Documentation(info = "<html><body><!-- drug-about --><h4>About azithromycin</h4><p>Azithromycin is a macrolide antibiotic used to treat many bacterial infections, including pneumonia, bronchitis, sinusitis, otitis media, chlamydia infection, and skin infections. It is widely used around the world and appears on the WHO list of essential medicines; it is also available as an eye drop for eye infections.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q165399\">Wikidata Q165399</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h4>Azithromycin_Hao2013_PD_pcs</h4><p>The steady-state exposure-response curve of Hao K et al., <i>PloS one 8(1):e54981</i> 2013 (<a href=\"https://doi.org/10.1371/journal.pone.0054981\">doi:10.1371/journal.pone.0054981</a>) — plasma proinflammatory cytokines [pg·ml−1] against azithromycin ug/ml — obtained by sweeping the driver instead of simulating a dose. Model family: indirect_response_i.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    =       49.8 pg·ml−1  drug-free response (baseline) (PCs,0, Q324)
  Emax  =       0.83          maximal effect term (Imax, Q323)
  EC50  =        6.3 ug/ml    exposure at half of the maximal effect term (IC50, Q322)
  gamma = (library default) Hill coefficient</pre><p>The algebra is <code>response = E0*(1 - Emax*frac)</code>; this model only supplies the numbers. The x axis is one ug/ml of azithromycin per second of simulated time (exposure is in kg/m3): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 4.98e-08   (drug-free)
  exposure = EC50 (6.3 ug/ml)  response 2.913e-08
  exposure -> infinity  response 8.466e-09</pre></body></html>"));
end Azithromycin_Hao2013_PD_pcs;
