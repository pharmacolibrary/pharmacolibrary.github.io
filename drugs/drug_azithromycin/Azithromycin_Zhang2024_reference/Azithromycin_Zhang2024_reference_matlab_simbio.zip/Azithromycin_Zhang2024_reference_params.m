function p = Azithromycin_Zhang2024_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: azithromycin   source: Zhang_2024 / reference   route: oral
  % estimated (absent from source): F
  p.name  = 'Azithromycin_Zhang2024_reference_params';
  p.drug  = 'azithromycin';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 3192.0;                % central volume [L]
  p.CL = 88.9;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.71;                % absorption rate [1/h]
  p.F  = 0.9;                 % bioavailability [0-1]
  p.Tlag = 0.75;             % absorption lag [h]
  p.dose = 300.0;             % dose [mg]
end
