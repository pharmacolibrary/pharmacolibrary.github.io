model Azithromycin_Benn2017_reference
  parameter Real Cl_ref = 5.027777777777778e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.305 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C_enteral(
    weight = 70.0,
    F = 0.9,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.7489845,
    adminMass = 8.5e-05,
    ka = 0.00019722222222222222,
    Tlag = 2700.0,
    k12 = 4.207650273224044e-05,
    k21 = 2.845528455284553e-05
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About azithromycin</h4><p>Azithromycin is a macrolide antibiotic used to treat many bacterial infections, including pneumonia, bronchitis, sinusitis, otitis media, chlamydia infection, and skin infections. It is widely used around the world and appears on the WHO list of essential medicines; it is also available as an eye drop for eye infections.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q165399\">Wikidata Q165399</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>azithromycin</td></tr><tr><td>population:</td><td>paediatric oncology patient</td></tr><tr><td>source_paper:</td><td>Benn_2017</td></tr><tr><td>measured_compound:</td><td>azithromycin</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>t1-amjcaserep-18-883</td></tr><tr><td>input:</td><td>PK_2C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>azithromycin 748.985 g/mol (drugbank)</td></tr></table><p><b>Defaulted (base-class default used):</b> F.</p><h4>Interpretation flags</h4><ul><li>dropped unlinked row (NIL): 'First dose' — extend the ontology if this is a real PK parameter (source ['t1-amjcaserep-18-883:row12:col1'])</li><li>dropped unlinked row (NIL): 'Second dose' — extend the ontology if this is a real PK parameter (source ['t1-amjcaserep-18-883:row13:col1'])</li><li>dropped unlinked row (NIL): 'Third dose' — extend the ontology if this is a real PK parameter (source ['t1-amjcaserep-18-883:row14:col1'])</li><li>dropped unlinked row (NIL): 'Baseline heart rate (beats/min)' — extend the ontology if this is a real PK parameter (source ['t1-amjcaserep-18-883:row17:col1'])</li><li>dropped PD-category row 'Half maximal effective concentration (EC50) (μg/L)' → Q321 (EC50, category G11) — pharmacodynamic parameters belong to scholarpd, not the PK model (source ['t1-amjcaserep-18-883:row18:col1'])</li><li>dropped PD-category row 'Maximal effect (Emax) (beats/min)' → Q320 (Emax, category G11) — pharmacodynamic parameters belong to scholarpd, not the PK model (source ['t1-amjcaserep-18-883:row19:col1'])</li><li>dropped PD-category row 'Hill coefficient' → Q325 (Hill, category G11) — pharmacodynamic parameters belong to scholarpd, not the PK model (source ['t1-amjcaserep-18-883:row20:col1'])</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=azithromycin</li><li>gap-filled Q49 (kabs) from Alshehri_2023's review values (primary lacked it)</li><li>gap-filled Q83 (tlag) from Alshehri_2023's review values (primary lacked it)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 691200, Tolerance = 1e-9, Interval = 1));
end Azithromycin_Benn2017_reference;
