function p = Azithromycin_Benn2017_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: azithromycin   source: Benn_2017 / reference   route: oral
  % estimated (absent from source): F
  p.name  = 'Azithromycin_Benn2017_reference_params';
  p.drug  = 'azithromycin';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 305.0;                % central volume [L]
  p.CL = 18.1;                % clearance [L/h]
  p.Vp = [451.0];             % peripheral volumes [L]
  p.Q  = [46.2];             % inter-compartmental clearances [L/h]
  p.ka = 0.71;                % absorption rate [1/h]
  p.F  = 0.9;                 % bioavailability [0-1]
  p.Tlag = 0.75;             % absorption lag [h]
  p.dose = 85.0;             % dose [mg]
end
