function p = Tobramycin_Malehorn2026_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: tobramycin   source: Malehorn_2026 / reference   route: iv_bolus
  % estimated (absent from source): F
  p.name  = 'Tobramycin_Malehorn2026_reference_params';
  p.drug  = 'tobramycin';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'iv_bolus';        % 'oral' | 'iv_bolus'
  p.depot = false;             % oral -> first-order absorption depot
  p.Vc = 18.9;                % central volume [L]
  p.CL = 7.0;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.0;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 240.0;             % dose [mg]
end
