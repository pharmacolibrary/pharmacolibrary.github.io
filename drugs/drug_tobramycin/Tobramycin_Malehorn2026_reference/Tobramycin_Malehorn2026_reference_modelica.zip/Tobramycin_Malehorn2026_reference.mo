model Tobramycin_Malehorn2026_reference
  parameter Real Cl_ref = 1.944444444444445e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.0189 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.4675145,
    adminMass = 0.00024
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About tobramycin</h4><p>Tobramycin is an aminoglycoside antibiotic used to treat bacterial infections, including Pseudomonas infections, pneumonia, urinary tract infections, and lung problems in cystic fibrosis. It is approved and authorised in the European Union, mainly for cystic fibrosis and respiratory tract infections, and is also used in eye preparations.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q1758380\">Wikidata Q1758380</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>tobramycin</td></tr><tr><td>population:</td><td>review reference</td></tr><tr><td>source_paper:</td><td>Malehorn_2026</td></tr><tr><td>measured_compound:</td><td>tobramycin</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>tobramycin 467.514 g/mol (drugbank)</td></tr></table><h4>Interpretation flags</h4><ul><li>built from REVIEW reference values (Malehorn_2026) — secondary source</li><li>volume reported by review</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Tobramycin_Malehorn2026_reference;
