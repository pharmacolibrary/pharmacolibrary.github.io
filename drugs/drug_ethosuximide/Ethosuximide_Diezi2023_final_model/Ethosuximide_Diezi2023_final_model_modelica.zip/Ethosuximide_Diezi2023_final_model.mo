model Ethosuximide_Diezi2023_final_model
  parameter Real Cl_ref = 1.5805555555555554e-07 "Cl [m3/s]";
  parameter Real Vd_ref = 0.0313 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C_enteral(
    weight = 70.0,
    F = 0.9,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.1411677,
    adminMass = 0.0007,
    ka = 0.0015527777777777777,
    Tlag = 0.0,
    k12 = 9.052183173588922e-05,
    k21 = 0.00020383693045563546
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About ethosuximide</h4><p>Ethosuximide is an anticonvulsant used to treat epilepsy, especially childhood absence epilepsy. It is an approved medicine and appears on the WHO essential medicines list, so it remains widely used.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q421567\">Wikidata Q421567</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>ethosuximide</td></tr><tr><td>population:</td><td>healthy adults</td></tr><tr><td>source_paper:</td><td>Diezi_2023</td></tr><tr><td>measured_compound:</td><td>ethosuximide</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>prp21032-tbl-0002</td></tr><tr><td>input:</td><td>PK_2C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>ethosuximide 141.168 g/mol (drugbank)</td></tr></table><p><b>Defaulted (base-class default used):</b> F, Tlag.</p><h4>Interpretation flags</h4><ul><li>routed 'kagranulesA&B (h−1)' → Q315 (sigma) to residual_error — variability estimate, not a structural parameter</li><li>apparent-by-design (ADVISORY, codes unchanged): extravascular dosing with no identifiable F, so these reported disposition parameters are likely apparent unless the model puts first-pass in its structure — Q22 (CL (L/h)); Q63 (V c (L)); Q30 (Q (L/h)); Q64 (V p (L))</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=ethosuximide</li><li>population split: 'final model' subgroup of Diezi_2023 (paper reports 4 populations: final model, granules (a), granules (b), syrup (zarontin®) (b))</li><li>skipped review gap-fill of TLAG: primary's parameterization (rate-constant / ka-only) does not use it</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 691200, Tolerance = 1e-9, Interval = 1));
end Ethosuximide_Diezi2023_final_model;
