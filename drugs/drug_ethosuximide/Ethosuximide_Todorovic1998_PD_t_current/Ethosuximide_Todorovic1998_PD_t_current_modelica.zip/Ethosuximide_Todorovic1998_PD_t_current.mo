model Ethosuximide_Todorovic1998_PD_t_current
  "sigmoid_emax exposure-response sweep — Todorovic_1998 :: T current (low-voltage-activated (LVA) Ca2+ current)"
  extends Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep(
    E0 = 0,      // [1]
    Emax = -1,  // [1; % × 0.01]
    EC50 = 23.7,  // [mM]
    gamma = 1.4,
    exposure_per_s = 1);   // 1 mM per second
  // imax_as_negative_emax: Imax (Q323) enters SigmoidEmaxSweep as −Emax
  // exposure_unit_unresolved: 'mM' — the x axis is in the paper's unit, not SI
  // defaulted: E0
  annotation(experiment(StartTime = 0, StopTime = 240, Interval = 0.48),
    Documentation(info = "<html><body><!-- drug-about --><h4>About ethosuximide</h4><p>Ethosuximide is an anticonvulsant used to treat epilepsy, especially childhood absence epilepsy. It is an approved medicine and appears on the WHO essential medicines list, so it remains widely used.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q421567\">Wikidata Q421567</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h4>Ethosuximide_Todorovic1998_PD_t_current</h4><p>The steady-state exposure-response curve of Todorovic SM et al., <i>Journal of neurophysiology 79(1):240–252</i> 1998 (<a href=\"https://doi.org/10.1152/jn.1998.79.1.240\">doi:10.1152/jn.1998.79.1.240</a>) — low-voltage-activated (LVA) Ca2+ current against ethosuximide mM — obtained by sweeping the driver instead of simulating a dose. Model family: sigmoid_emax.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = (library default) drug-free response (baseline)
  Emax  =        100 %        maximal effect term (maximum block, Q323)
  EC50  =       23.7 mM       exposure at half of the maximal effect term (EC50, Q321)
  gamma =        1.4          Hill coefficient (Hill coefficient, Q325)</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep\">SigmoidEmaxSweep</a>; this model only supplies the numbers. The x axis is one mM of ethosuximide per second of simulated time: there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0   (drug-free)
  exposure = EC50 (23.7 mM)  response -0.5
  exposure -> infinity  response -1</pre></body></html>"));
end Ethosuximide_Todorovic1998_PD_t_current;
