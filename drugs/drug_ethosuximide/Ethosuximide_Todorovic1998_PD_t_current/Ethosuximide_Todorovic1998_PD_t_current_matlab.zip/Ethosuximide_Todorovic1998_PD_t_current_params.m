function p = Ethosuximide_Todorovic1998_PD_t_current_params()
% Ethosuximide_Todorovic1998_PD_t_current_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% ethosuximide Todorovic_1998::T_current: sigmoid_emax exposure-response sweep (response = E0 + Emax*frac). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one mM per second, in SI inside (kg/m3, s). Response T current in its own unit. Driver: ethosuximide (cited_pk).
p.E0 = 0.0;
p.Emax = -1.0;
p.EC50 = 23.7;
p.gamma = 1.4;
p.slope = 0.0;
p.exposure_per_s = 1.0;
p.stop_time = 240.0;
p.form = 'E0 + Emax*frac';
end
