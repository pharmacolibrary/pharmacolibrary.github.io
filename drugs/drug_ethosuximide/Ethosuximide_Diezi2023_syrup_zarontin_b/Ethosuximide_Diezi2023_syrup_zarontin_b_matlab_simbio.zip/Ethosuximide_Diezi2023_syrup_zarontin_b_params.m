function p = Ethosuximide_Diezi2023_syrup_zarontin_b_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: ethosuximide   source: Diezi_2023 / syrup_zarontin_b   route: oral
  p.name  = 'Ethosuximide_Diezi2023_syrup_zarontin_b_params';
  p.drug  = 'ethosuximide';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 31.3;                % central volume [L]
  p.CL = 0.57;                % clearance [L/h]
  p.Vp = [13.9];             % peripheral volumes [L]
  p.Q  = [10.2];             % inter-compartmental clearances [L/h]
  p.ka = 5.59;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 700.0;             % dose [mg]
end
