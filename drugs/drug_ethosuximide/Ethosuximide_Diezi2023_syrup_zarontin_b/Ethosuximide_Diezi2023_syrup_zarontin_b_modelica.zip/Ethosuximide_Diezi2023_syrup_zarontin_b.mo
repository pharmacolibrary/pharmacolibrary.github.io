model Ethosuximide_Diezi2023_syrup_zarontin_b
  parameter Real Cl_ref = 1.5833333333333333e-07 "Cl [m3/s]";
  parameter Real Vd_ref = 0.0313 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.1411677,
    adminMass = 0.0007,
    ka = 0.0015527777777777777,
    Tlag = 0.0,
    k12 = 9.052183173588922e-05,
    k21 = 0.00020383693045563546
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About ethosuximide</h4><p>Ethosuximide is an anticonvulsant used to treat epilepsy, especially childhood absence epilepsy. It is an approved medicine and appears on the WHO essential medicines list, so it remains widely used.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q421567\">Wikidata Q421567</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>ethosuximide</td></tr><tr><td>population:</td><td>healthy adults</td></tr><tr><td>source_paper:</td><td>Diezi_2023</td></tr><tr><td>measured_compound:</td><td>ethosuximide</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>prp21032-tbl-0002</td></tr><tr><td>input:</td><td>PK_2C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>ethosuximide 141.168 g/mol (drugbank)</td></tr></table><p><b>Defaulted (base-class default used):</b> Tlag.</p><h4>Interpretation flags</h4><ul><li>salvaged Q22 ('CL'=0.57) from results prose — parameter table was unreadable</li><li>salvaged Q30 ('Q'=10.2) from results prose — parameter table was unreadable</li><li>salvaged Q63 ('V C'=31.3) from results prose — parameter table was unreadable</li><li>salvaged Q64 ('V P'=13.9) from results prose — parameter table was unreadable</li><li>apparent-ness (ontology-grounded): parameterization=apparent, measured_compound=ethosuximide</li><li>held at status:extracted — NIL link or unit issue (mismatch/unknown/normalisation-failed) present</li><li>status held at route_to_review — not promoted</li><li>population split: 'syrup (zarontin®) (b)' subgroup of Diezi_2023 (paper reports 4 populations: final model, granules (a), granules (b), syrup (zarontin®) (b))</li><li>gap-filled Q49 (kabs) from Diezi_2023's review values (primary lacked it)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 1036800, Tolerance = 1e-9, Interval = 1));
end Ethosuximide_Diezi2023_syrup_zarontin_b;
