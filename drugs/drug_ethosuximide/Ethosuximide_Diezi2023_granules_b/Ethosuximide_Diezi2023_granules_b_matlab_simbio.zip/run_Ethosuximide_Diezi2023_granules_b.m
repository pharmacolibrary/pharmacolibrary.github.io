% Run (SimBiology): build model + dose, simulate 0..288.0 h, plot.
p = Ethosuximide_Diezi2023_granules_b_params();
[model, dose, variant] = build_sb_pk(p);
sd = simulate_sb(model, variant, dose, 288.0);
