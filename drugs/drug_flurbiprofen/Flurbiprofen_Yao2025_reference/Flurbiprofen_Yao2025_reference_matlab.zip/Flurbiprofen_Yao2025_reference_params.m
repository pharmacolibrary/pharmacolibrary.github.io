function p = Flurbiprofen_Yao2025_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: flurbiprofen   source: Yao_2025 / reference   route: iv_bolus
  % estimated (absent from source): F
  p.name  = 'Flurbiprofen_Yao2025_reference_params';
  p.drug  = 'flurbiprofen';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'iv_bolus';        % 'oral' | 'iv_bolus'
  p.depot = false;             % oral -> first-order absorption depot
  p.Vc = 17.0;                % central volume [L]
  p.CL = 11.8;                % clearance [L/h]
  p.Vp = [79.1];             % peripheral volumes [L]
  p.Q  = [0.45];             % inter-compartmental clearances [L/h]
  p.ka = 0.0;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 100.0;             % dose [mg]
end
