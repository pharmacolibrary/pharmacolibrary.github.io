model Ustekinumab_Adedokun2022_reference
  parameter Real Cl_ref = 2.222222222222222e-09 "Cl [m3/s]";
  parameter Real Vd_ref = 0.00462 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 78.3,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    adminMass = 0.0001,
    ka = 1.0509259259259259e-05,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About ustekinumab</h4><p>Ustekinumab, a monoclonal antibody that blocks interleukins, is used to treat plaque psoriasis, psoriatic arthritis, Crohn's disease, and ulcerative colitis. It is an approved medicine with several authorised products in the European Union, where it is used for these inflammatory conditions.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q420305\">Wikidata Q420305</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>ustekinumab</td></tr><tr><td>population:</td><td>adults with moderately to severely active Crohn's disease</td></tr><tr><td>source_paper:</td><td>Adedokun_2022</td></tr><tr><td>measured_compound:</td><td>ustekinumab</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr></table><p><b>Defaulted (base-class default used):</b> Tlag.</p><h4>Interpretation flags</h4><ul><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=ustekinumab</li><li>held at status:extracted — NIL link or unit issue (mismatch/unknown/normalisation-failed) present</li><li>structure disagreement: deterministic 1C vs LLM 2C — review compartment count</li><li>status held at route_to_review — not promoted</li><li>molar mass: none found for 'ustekinumab' — its concentrations stay mass-only</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>gap-filled Q49 (kabs) from Rodríguez-Fernández_2022's review values (primary lacked it)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 9072000, Tolerance = 1e-9, Interval = 1));
end Ustekinumab_Adedokun2022_reference;
