function p = Ustekinumab_Adedokun2022_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: ustekinumab   source: Adedokun_2022 / reference   route: oral
  % estimated (absent from source): dose
  % Vc is the record's Vss — no central volume was reported; 1-compartment reading
  p.name  = 'Ustekinumab_Adedokun2022_reference_params';
  p.drug  = 'ustekinumab';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 4.62;                % central volume [L]
  p.CL = 0.008;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.037833;                % absorption rate [1/h]
  p.F  = 0.783;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 100.0;             % dose [mg]
end
