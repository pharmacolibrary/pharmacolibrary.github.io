model Ustekinumab_RodrguezFernndez2024_PD_pasi
  "indirect_response_i exposure-response sweep — Rodríguez-Fernández_2024 :: PASI (Psoriasis Area and Severity Index)"
  extends Pharmacolibrary.Interfaces.PartialExposureResponseSweep(
    E0 = 0,      // [1]
    Emax = 0.97,  // type I effect term
    EC50 = 7e-05,  // [kg/m3; mg/L × 0.001]
    gamma = 1,
    exposure_per_s = 0.001);   // 1 mg/L per second
equation
  response = E0*(1 - Emax*frac);   // steady state, indirect response type I
  // defaulted: E0
  // defaulted: gamma
  annotation(experiment(StartTime = 0, StopTime = 0.7, Interval = 0.0014),
    Documentation(info = "<html><body><!-- drug-about --><h4>About ustekinumab</h4><p>Ustekinumab, a monoclonal antibody that blocks interleukins, is used to treat plaque psoriasis, psoriatic arthritis, Crohn's disease, and ulcerative colitis. It is an approved medicine with several authorised products in the European Union, where it is used for these inflammatory conditions.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q420305\">Wikidata Q420305</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h4>Ustekinumab_RodrguezFernndez2024_PD_pasi</h4><p>The steady-state exposure-response curve of Rodríguez-Fernández K et al., <i>Pharmaceutics 16(10)</i> 2024 (<a href=\"https://doi.org/10.3390/pharmaceutics16101295\">doi:10.3390/pharmaceutics16101295</a>) — Psoriasis Area and Severity Index against ustekinumab mg/L — obtained by sweeping the driver instead of simulating a dose. Model family: indirect_response_i.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = (library default) drug-free response (baseline)
  Emax  =       0.97          maximal effect term (Imax, Q323)
  EC50  =       0.07 mg/L     exposure at half of the maximal effect term (IC50, Q322)
  gamma = (library default) Hill coefficient</pre><p>The algebra is <code>response = E0*(1 - Emax*frac)</code>; this model only supplies the numbers. The x axis is one mg/L of ustekinumab per second of simulated time (exposure is in kg/m3): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0   (drug-free)
  exposure = EC50 (0.07 mg/L)  response 0
  exposure -> infinity  response 0</pre></body></html>"));
end Ustekinumab_RodrguezFernndez2024_PD_pasi;
