function p = Ustekinumab_RodrguezFernndez2024_PD_pasi_params()
% Ustekinumab_RodrguezFernndez2024_PD_pasi_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% ustekinumab Rodríguez-Fernández_2024::PASI: indirect_response_i exposure-response sweep (response = E0*(1 - Emax*frac)). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one mg/L per second, in SI inside (kg/m3, s). Response PASI in its own unit. Driver: ustekinumab (cited_pk).
p.E0 = 0.0;
p.Emax = 0.97;
p.EC50 = 7e-05;
p.gamma = 1.0;
p.slope = 0.0;
p.exposure_per_s = 0.001;
p.stop_time = 0.7;
p.form = 'E0*(1 - Emax*frac)';
end
