function p = Pirfenidone_Braim2008_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: pirfenidone   source: Braim_2008 / reference   route: iv_bolus
  % estimated (absent from source): F, dose
  % Vc is the record's Vss — no central volume was reported; 1-compartment reading
  p.name  = 'Pirfenidone_Braim2008_reference_params';
  p.drug  = 'pirfenidone';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'iv_bolus';        % 'oral' | 'iv_bolus'
  p.depot = false;             % oral -> first-order absorption depot
  p.Vc = 55.37;                % central volume [L]
  p.CL = 27.468;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.0;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 10.0;             % dose [mg]
end
