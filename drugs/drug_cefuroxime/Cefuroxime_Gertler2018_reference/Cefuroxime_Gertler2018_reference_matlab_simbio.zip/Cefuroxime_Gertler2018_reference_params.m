function p = Cefuroxime_Gertler2018_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: cefuroxime   source: Gertler_2018 / reference   route: oral
  % estimated (absent from source): F
  p.name  = 'Cefuroxime_Gertler2018_reference_params';
  p.drug  = 'cefuroxime';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 11.25;                % central volume [L]
  p.CL = 5.15;                % clearance [L/h]
  p.Vp = [17.07];             % peripheral volumes [L]
  p.Q  = [18.19];             % inter-compartmental clearances [L/h]
  p.ka = 9.78;                % absorption rate [1/h]
  p.F  = 0.9;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 500.0;             % dose [mg]
end
