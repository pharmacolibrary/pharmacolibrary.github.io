model Cefuroxime_Hartman2020_reference
  parameter Real Cl_ref = 4.7055555555555555e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.02576 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.424385,
    adminMass = 0.003
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About cefuroxime</h4><p>Cefuroxime is a second-generation cephalosporin antibiotic used to treat a range of bacterial infections, including pneumonia, sinusitis, pharyngitis, urinary tract infections, gonorrhea, Lyme disease, and skin infections. It is an approved antibiotic that is widely used in human medicine, available both alone and in combination with other antibacterials.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q413728\">Wikidata Q413728</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>cefuroxime</td></tr><tr><td>population:</td><td>review reference</td></tr><tr><td>source_paper:</td><td>Hartman_2020</td></tr><tr><td>measured_compound:</td><td>cefuroxime</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>cefuroxime 424.385 g/mol (drugbank)</td></tr></table><h4>Interpretation flags</h4><ul><li>built from REVIEW reference values (Hartman_2020) — secondary source</li><li>volume reported by review</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Cefuroxime_Hartman2020_reference;
