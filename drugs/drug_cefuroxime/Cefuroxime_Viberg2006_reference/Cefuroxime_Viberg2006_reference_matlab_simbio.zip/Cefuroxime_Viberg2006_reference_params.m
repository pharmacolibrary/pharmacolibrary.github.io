function p = Cefuroxime_Viberg2006_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: cefuroxime   source: Viberg_2006 / reference   route: oral
  % estimated (absent from source): F
  p.name  = 'Cefuroxime_Viberg2006_reference_params';
  p.drug  = 'cefuroxime';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 11.4;                % central volume [L]
  p.CL = 6.0;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 9.78;                % absorption rate [1/h]
  p.F  = 0.9;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 500.0;             % dose [mg]
end
