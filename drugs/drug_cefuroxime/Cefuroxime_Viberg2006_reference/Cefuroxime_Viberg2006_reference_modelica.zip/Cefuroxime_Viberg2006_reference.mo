model Cefuroxime_Viberg2006_reference
  parameter Real Cl_ref = 1.6666666666666667e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.0114 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 0.9,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.424385,
    adminMass = 0.0005,
    ka = 0.0027166666666666663,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About cefuroxime</h4><p>Cefuroxime is a second-generation cephalosporin antibiotic used to treat a range of bacterial infections, including pneumonia, sinusitis, pharyngitis, urinary tract infections, gonorrhea, Lyme disease, and skin infections. It is an approved antibiotic that is widely used in human medicine, available both alone and in combination with other antibacterials.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q413728\">Wikidata Q413728</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>cefuroxime</td></tr><tr><td>population:</td><td>adult patients with renal impairment</td></tr><tr><td>source_paper:</td><td>Viberg_2006</td></tr><tr><td>measured_compound:</td><td>cefuroxime</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>cefuroxime 424.385 g/mol (drugbank)</td></tr></table><p><b>Defaulted (base-class default used):</b> F, Tlag.</p><h4>Interpretation flags</h4><ul><li>dropped duplicate Q61 ('V(2)', value 5.11) — already have one for this compound</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=cefuroxime</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li><li>gap-filled Q49 (kabs) from Roelofsen_2022's review values (primary lacked it)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Cefuroxime_Viberg2006_reference;
