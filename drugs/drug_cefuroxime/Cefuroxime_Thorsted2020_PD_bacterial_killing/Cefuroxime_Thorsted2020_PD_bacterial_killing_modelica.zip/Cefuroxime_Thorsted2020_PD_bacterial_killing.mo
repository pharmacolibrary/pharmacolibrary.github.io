model Cefuroxime_Thorsted2020_PD_bacterial_killing
  "sigmoid_emax exposure-response sweep — Thorsted_2020 :: bacterial killing (bacterial killing)"
  extends Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep(
    E0 = 0,      // [1]
    Emax = 0.000905555555556,  // [1/s; h−1 × 0.000277778]
    EC50 = 0.00293,  // [kg/m3; mg/liter × 0.001]
    gamma = 3.37,
    exposure_per_s = 0.001);   // 1 mg/liter per second
  // defaulted: E0
  annotation(experiment(StartTime = 0, StopTime = 30, Interval = 0.06),
    Documentation(info = "<html><body><!-- drug-about --><h4>About cefuroxime</h4><p>Cefuroxime is a second-generation cephalosporin antibiotic used to treat a range of bacterial infections, including pneumonia, sinusitis, pharyngitis, urinary tract infections, gonorrhea, Lyme disease, and skin infections. It is an approved antibiotic that is widely used in human medicine, available both alone and in combination with other antibacterials.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q413728\">Wikidata Q413728</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h4>Cefuroxime_Thorsted2020_PD_bacterial_killing</h4><p>The steady-state exposure-response curve of Thorsted A et al., <i>Antimicrobial agents and chemotherapy 64(4)</i> 2020 (<a href=\"https://doi.org/10.1128/AAC.02070-19\">doi:10.1128/AAC.02070-19</a>) — bacterial killing against cefuroxime mg/liter — obtained by sweeping the driver instead of simulating a dose. Model family: sigmoid_emax.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = (library default) drug-free response (baseline)
  Emax  =       3.26 h−1      maximal effect term (Emax, Q320)
  EC50  =       2.93 mg/liter exposure at half of the maximal effect term (EC50, Q321)
  gamma =       3.37          Hill coefficient (gamma, Q325)</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep\">SigmoidEmaxSweep</a>; this model only supplies the numbers. The x axis is one mg/liter of cefuroxime per second of simulated time (exposure is in kg/m3): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0   (drug-free)
  exposure = EC50 (2.93 mg/liter)  response 0.0004528
  exposure -> infinity  response 0.0009056</pre></body></html>"));
end Cefuroxime_Thorsted2020_PD_bacterial_killing;
