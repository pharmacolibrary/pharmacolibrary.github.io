function p = Cefuroxime_Thorsted2020_PD_bacterial_killing_params()
% Cefuroxime_Thorsted2020_PD_bacterial_killing_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% cefuroxime Thorsted_2020::bacterial_killing: sigmoid_emax exposure-response sweep (response = E0 + Emax*frac). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one mg/liter per second, in SI inside (kg/m3, s). Response bacterial killing in its own unit. Driver: cefuroxime (cited_pk).
p.E0 = 0.0;
p.Emax = 0.0009055555555555555;
p.EC50 = 0.0029299999999999994;
p.gamma = 3.37;
p.slope = 0.0;
p.exposure_per_s = 0.001;
p.stop_time = 30.0;
p.form = 'E0 + Emax*frac';
end
