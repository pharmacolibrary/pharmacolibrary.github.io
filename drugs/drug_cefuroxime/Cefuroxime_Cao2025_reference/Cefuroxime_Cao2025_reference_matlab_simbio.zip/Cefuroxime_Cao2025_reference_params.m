function p = Cefuroxime_Cao2025_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: cefuroxime   source: Cao_2025 / reference   route: iv_bolus
  % estimated (absent from source): F
  p.name  = 'Cefuroxime_Cao2025_reference_params';
  p.drug  = 'cefuroxime';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'iv_bolus';        % 'oral' | 'iv_bolus'
  p.depot = false;             % oral -> first-order absorption depot
  p.Vc = 4.55;                % central volume [L]
  p.CL = 0.77;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.0;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 3000.0;             % dose [mg]
end
