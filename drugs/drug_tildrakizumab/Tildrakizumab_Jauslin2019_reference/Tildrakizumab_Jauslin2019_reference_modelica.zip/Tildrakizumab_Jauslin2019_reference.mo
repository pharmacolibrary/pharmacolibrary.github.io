model Tildrakizumab_Jauslin2019_reference
  parameter Real Cl_ref = 3.703703703703704e-09 "Cl [m3/s]";
  parameter Real Vd_ref = 0.0108 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 0.9,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    adminMass = 0.0001,
    ka = 1.0509259259259259e-05,
    Tlag = 4320.0
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About tildrakizumab</h4><p>Tildrakizumab, a monoclonal antibody that blocks an interleukin signal, is used to treat psoriasis. It is an approved medicine and is authorised in the European Union for this condition.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q15708331\">Wikidata Q15708331</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>tildrakizumab</td></tr><tr><td>population:</td><td>healthy volunteers and subjects with psoriasis</td></tr><tr><td>source_paper:</td><td>Jauslin_2019</td></tr><tr><td>measured_compound:</td><td>tildrakizumab</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr></table><p><b>Defaulted (base-class default used):</b> F.</p><h4>Interpretation flags</h4><ul><li>apparent-by-design (ADVISORY, codes unchanged): extravascular dosing with no identifiable F, so these reported disposition parameters are likely apparent unless the model puts first-pass in its structure — Q22 (geometric mean clearance); Q61 (volume of distribution)</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=tildrakizumab</li><li>molar mass: none found for 'tildrakizumab' — its concentrations stay mass-only</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li><li>gap-filled Q49 (kabs) from Rodríguez-Fernández_2022's review values (primary lacked it)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 10886400, Tolerance = 1e-9, Interval = 1));
end Tildrakizumab_Jauslin2019_reference;
