model SodiumStibogluconate_Verrest2024_PD_parasite_load
  "linear exposure-response sweep — Verrest_2024 :: parasite load (blood parasite load (Leishmania kDNA by qPCR))"
  extends Pharmacolibrary.Interfaces.PartialExposureResponseSweep(
    E0 = 5324,      // [parasites/mL]
    Emax = 0, EC50 = 1,      // unused by a line
    exposure_per_s = 1e-06);
  parameter Real slope = 0.0112   "[mg-1*kg*h-1]";
equation
  response = E0 + slope*exposure;
  annotation(experiment(StartTime = 0, StopTime = 1000, Interval = 2),
    Documentation(info = "<html><body><!-- drug-about --><h4>About sodium_stibogluconate</h4><p>Sodium stibogluconate is an antiprotozoal medicine used to treat leishmaniasis. It is on the WHO list of essential medicines and remains an approved treatment, though it is not authorised in the European Union.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q2757844\">Wikidata Q2757844</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h4>SodiumStibogluconate_Verrest2024_PD_parasite_load</h4><p>The steady-state exposure-response curve of Verrest L et al., <i>PLoS neglected tropical diseases 18(4):e0012078</i> 2024 (<a href=\"https://doi.org/10.1371/journal.pntd.0012078\">doi:10.1371/journal.pntd.0012078</a>) — blood parasite load (Leishmania kDNA by qPCR) [parasites/mL] against sodium stibogluconate mg/kg — obtained by sweeping the driver instead of simulating a dose. Model family: linear.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    =       5324 parasites/mL drug-free response (baseline) (EBASE, Q324)
  slope =     0.0112 mg-1*kg*h-1 change in response per unit of exposure (λSSG, Q335)</pre><p>The algebra is <code>response = E0 + slope*exposure</code>; this model only supplies the numbers. The x axis is one mg/kg of sodium stibogluconate per second of simulated time: there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 5324   (drug-free)</pre></body></html>"));
end SodiumStibogluconate_Verrest2024_PD_parasite_load;
