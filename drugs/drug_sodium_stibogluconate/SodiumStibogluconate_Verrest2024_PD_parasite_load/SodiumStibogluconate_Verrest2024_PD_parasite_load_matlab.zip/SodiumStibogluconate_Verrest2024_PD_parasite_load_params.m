function p = SodiumStibogluconate_Verrest2024_PD_parasite_load_params()
% SodiumStibogluconate_Verrest2024_PD_parasite_load_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% sodium_stibogluconate Verrest_2024::parasite_load: linear exposure-response sweep (response = E0 + slope*exposure). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one mg/kg per second, in SI inside (kg/m3, s). Response parasite load in parasites/mL. Driver: sodium stibogluconate (dose_only).
p.E0 = 5324.0;
p.Emax = 0.0;
p.EC50 = 1.0;
p.gamma = 1.0;
p.slope = 0.0112;
p.exposure_per_s = 1e-06;
p.stop_time = 1000.0;
p.form = 'E0 + slope*exposure';
end
