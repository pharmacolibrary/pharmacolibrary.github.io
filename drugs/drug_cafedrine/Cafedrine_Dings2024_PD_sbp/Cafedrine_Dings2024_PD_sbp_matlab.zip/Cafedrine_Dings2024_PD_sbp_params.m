function p = Cafedrine_Dings2024_PD_sbp_params()
% Cafedrine_Dings2024_PD_sbp_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% cafedrine Dings_2024::SBP: emax exposure-response sweep (response = E0 + Emax*frac). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one mg per second, in SI inside (kg/m3, s). Response SBP in mmHg. Driver: cafedrine (dose_only).
p.E0 = 0.0;
p.Emax = 195.0;
p.EC50 = 2.09e-06;
p.gamma = 1.0;
p.slope = 0.0;
p.exposure_per_s = 1e-06;
p.stop_time = 21.0;
p.form = 'E0 + Emax*frac';
end
