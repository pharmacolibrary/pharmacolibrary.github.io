function p = Cafedrine_Dings2024_PD_hr_params()
% Cafedrine_Dings2024_PD_hr_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% cafedrine Dings_2024::HR: emax exposure-response sweep (response = E0 + Emax*frac). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one mg per second, in SI inside (kg/m3, s). Response HR in bpm. Driver: cafedrine (dose_only).
p.E0 = 0.0;
p.Emax = 62.9;
p.EC50 = 1.3899999999999998e-06;
p.gamma = 1.0;
p.slope = 0.0;
p.exposure_per_s = 1e-06;
p.stop_time = 14.0;
p.form = 'E0 + Emax*frac';
end
