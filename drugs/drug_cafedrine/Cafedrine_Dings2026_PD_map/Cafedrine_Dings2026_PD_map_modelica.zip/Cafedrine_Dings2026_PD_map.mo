model Cafedrine_Dings2026_PD_map
  "emax exposure-response sweep — Dings_2026 :: MAP (Mean arterial pressure)"
  extends Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep(
    E0 = 0,      // [1]
    Emax = 119,  // [mmHg]
    EC50 = 0.0617,  // [kg/m3; mg/L × 0.001]
    gamma = 1,
    exposure_per_s = 0.001);   // 1 mg/L per second
  // defaulted: E0
  // defaulted: gamma
  annotation(experiment(StartTime = 0, StopTime = 620, Interval = 1.24),
    Documentation(info = "<html><body><!-- drug-about --><h4>About cafedrine</h4><p>Cafedrine is a chemical compound described as an antihypertensive drug and vasodilator, classified as a cardiac stimulant acting on the cardiovascular system. It is considered investigational and is not an approved medicine in the European Union.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q5017121\">Wikidata Q5017121</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h4>Cafedrine_Dings2026_PD_map</h4><p>The steady-state exposure-response curve of Dings C et al., <i>Pharmaceutics 18(3)</i> 2026 (<a href=\"https://doi.org/10.3390/pharmaceutics18030296\">doi:10.3390/pharmaceutics18030296</a>) — Mean arterial pressure [mmHg] against cafedrine/theodrenaline mg/L — obtained by sweeping the driver instead of simulating a dose. Model family: emax.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = (library default) drug-free response (baseline)
  Emax  =        119 mmHg     maximal effect term (Maximum MAP, Q320)
  EC50  =       61.7 mg/L     exposure at half of the maximal effect term (Half-effective concentration MAP, Q321)
  gamma = (library default) Hill coefficient</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep\">SigmoidEmaxSweep</a>; this model only supplies the numbers. The x axis is one mg/L of cafedrine/theodrenaline per second of simulated time (exposure is in kg/m3): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0   (drug-free)
  exposure = EC50 (61.7 mg/L)  response 59.5
  exposure -> infinity  response 119</pre></body></html>"));
end Cafedrine_Dings2026_PD_map;
