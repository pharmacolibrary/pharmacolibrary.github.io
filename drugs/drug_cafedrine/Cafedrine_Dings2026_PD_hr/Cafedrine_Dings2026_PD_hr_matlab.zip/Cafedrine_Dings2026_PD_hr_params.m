function p = Cafedrine_Dings2026_PD_hr_params()
% Cafedrine_Dings2026_PD_hr_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% cafedrine Dings_2026::HR: emax exposure-response sweep (response = E0 + Emax*frac). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one mg/L per second, in SI inside (kg/m3, s). Response HR in bpm. Driver: cafedrine/theodrenaline (conc_no_pk).
p.E0 = 0.0;
p.Emax = 77.8;
p.EC50 = 0.005629999999999999;
p.gamma = 1.0;
p.slope = 0.0;
p.exposure_per_s = 0.001;
p.stop_time = 57.0;
p.form = 'E0 + Emax*frac';
end
