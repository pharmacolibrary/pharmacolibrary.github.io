model Cafedrine_Dings2024_PD_dbp
  "emax exposure-response sweep — Dings_2024 :: DBP (diastolic blood pressure)"
  extends Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep(
    E0 = 0,      // [1]
    Emax = 113,  // [mmHg]
    EC50 = 2.4e-06,  // [kg; mg × 1e-06]
    gamma = 1,
    exposure_per_s = 1e-06);   // 1 mg per second
  // defaulted: E0
  // defaulted: gamma
  annotation(experiment(StartTime = 0, StopTime = 24, Interval = 0.048),
    Documentation(info = "<html><body><!-- drug-about --><h4>About cafedrine</h4><p>Cafedrine is a chemical compound described as an antihypertensive drug and vasodilator, classified as a cardiac stimulant acting on the cardiovascular system. It is considered investigational and is not an approved medicine in the European Union.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q5017121\">Wikidata Q5017121</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h4>Cafedrine_Dings2024_PD_dbp</h4><p>The steady-state exposure-response curve of Dings C et al., <i>British journal of clinical pharmacology 90(8):1964–1974</i> 2024 (<a href=\"https://doi.org/10.1111/bcp.16083\">doi:10.1111/bcp.16083</a>) — diastolic blood pressure [mmHg] against cafedrine mg — obtained by sweeping the driver instead of simulating a dose. Model family: emax.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = (library default) drug-free response (baseline)
  Emax  =        113 mmHg     maximal effect term (MAX_DBP, Q320)
  EC50  =        2.4 mg       exposure at half of the maximal effect term (ED50_DBP, Q321)
  gamma = (library default) Hill coefficient</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep\">SigmoidEmaxSweep</a>; this model only supplies the numbers. The x axis is one mg of cafedrine per second of simulated time (exposure is in kg): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0   (drug-free)
  exposure = EC50 (2.4 mg)  response 56.5
  exposure -> infinity  response 113</pre></body></html>"));
end Cafedrine_Dings2024_PD_dbp;
