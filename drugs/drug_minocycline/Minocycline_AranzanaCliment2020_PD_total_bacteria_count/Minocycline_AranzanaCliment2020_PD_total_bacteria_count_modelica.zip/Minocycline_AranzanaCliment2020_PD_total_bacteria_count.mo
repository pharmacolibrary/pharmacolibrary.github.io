model Minocycline_AranzanaCliment2020_PD_total_bacteria_count
  "sigmoid_emax exposure-response sweep — Aranzana-Climent_2020 :: total bacteria count (total bacteria count)"
  extends Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep(
    E0 = 0,      // [1]
    Emax = -0.000391666666667,  // [1/s; h -1 × 0.000277778]
    EC50 = 0.00102,  // [kg/m3; mg/L × 0.001]
    gamma = 1.59,
    exposure_per_s = 0.001);   // 1 mg/L per second
  // family_inferred: the record's model family is unknown; read from the parameters: Emax/Imax, EC50/IC50 and a Hill coefficient — sigmoid Emax
  // imax_as_negative_emax: Imax (Q323) enters SigmoidEmaxSweep as −Emax
  // defaulted: E0
  annotation(experiment(StartTime = 0, StopTime = 11, Interval = 0.022),
    Documentation(info = "<html><body><h4>Minocycline_AranzanaCliment2020_PD_total_bacteria_count</h4><p>The steady-state exposure-response curve of Aranzana-Climent V et al., <i>Clinical microbiology and infection : the official publication of the European Society of Clinical Microbiology and Infectious Diseases 26(9):1254.e9–1254.e15</i> 2020 (<a href=\"https://doi.org/10.1016/j.cmi.2020.01.017\">doi:10.1016/j.cmi.2020.01.017</a>) — total bacteria count [log10CFU/mL] against minocycline mg/L — obtained by sweeping the driver instead of simulating a dose. Model family: sigmoid_emax.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = (library default) drug-free response (baseline)
  Emax  =       1.41 h -1     maximal effect term (Emax,MIN, Q323)
  EC50  =       1.02 mg/L     exposure at half of the maximal effect term (EC50,MIN-R, Q321)
  gamma =       1.59          Hill coefficient (γMIN, Q325)</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep\">SigmoidEmaxSweep</a>; this model only supplies the numbers. The x axis is one mg/L of minocycline per second of simulated time (exposure is in kg/m3): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0   (drug-free)
  exposure = EC50 (1.02 mg/L)  response -0.0001958
  exposure -> infinity  response -0.0003917</pre></body></html>"));
end Minocycline_AranzanaCliment2020_PD_total_bacteria_count;
