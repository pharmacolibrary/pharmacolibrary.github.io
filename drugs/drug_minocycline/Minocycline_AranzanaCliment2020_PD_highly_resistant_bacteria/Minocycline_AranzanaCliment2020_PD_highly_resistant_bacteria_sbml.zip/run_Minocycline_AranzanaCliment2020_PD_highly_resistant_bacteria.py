#!/usr/bin/env python3
"""Sweep Minocycline_AranzanaCliment2020_PD_highly_resistant_bacteria.sbml with Tellurium/libRoadRunner: response against exposure.

Simulated time is the swept exposure (exposure = exposure_per_s * time), so the x axis of the
plot is `exposure`, not time. Writes Minocycline_AranzanaCliment2020_PD_highly_resistant_bacteria.csv/.json/.png next to this script.
"""
import json, os
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import tellurium as te

BASE = os.path.join(os.path.dirname(os.path.abspath(__file__)), "Minocycline_AranzanaCliment2020_PD_highly_resistant_bacteria")
r = te.loadSBMLModel(BASE + ".sbml")
res = r.simulate(0, 17.0, 500, ["time", "exposure", "response"])
x = [float(v) for v in res[:, 1]]; y = [float(v) for v in res[:, 2]]
with open(BASE + ".csv", "w") as f:
    f.write("exposure_si,response\n")
    for xi, yi in zip(x, y):
        f.write("%r,%r\n" % (xi, yi))
with open(BASE + ".json", "w") as f:
    json.dump({"model": "Minocycline_AranzanaCliment2020_PD_highly_resistant_bacteria", "exposure_si": x, "response": y}, f, indent=2)
plt.figure(); plt.plot(x, y, linewidth=1.5)
plt.xlabel("exposure [mg/L]"); plt.ylabel("response [log10CFU/mL]")
plt.title("Minocycline_AranzanaCliment2020_PD_highly_resistant_bacteria"); plt.grid(True, alpha=0.3); plt.tight_layout(); plt.savefig(BASE + ".png", dpi=150)
print("wrote %s.csv, %s.json, %s.png" % (BASE, BASE, BASE))
