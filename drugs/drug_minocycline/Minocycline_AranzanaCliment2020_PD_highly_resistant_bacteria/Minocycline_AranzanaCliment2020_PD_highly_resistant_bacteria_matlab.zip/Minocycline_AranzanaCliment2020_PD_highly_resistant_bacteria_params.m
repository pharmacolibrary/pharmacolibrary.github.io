function p = Minocycline_AranzanaCliment2020_PD_highly_resistant_bacteria_params()
% Minocycline_AranzanaCliment2020_PD_highly_resistant_bacteria_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% minocycline Aranzana-Climent_2020::highly_resistant_bacteria_count: sigmoid_emax exposure-response sweep (response = E0 + Emax*frac). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one mg/L per second, in SI inside (kg/m3, s). Response highly resistant bacteria count in log10CFU/mL. Driver: minocycline (cited_pk).
p.E0 = 0.0;
p.Emax = -0.00039166666666666663;
p.EC50 = 0.0016699999999999996;
p.gamma = 1.59;
p.slope = 0.0;
p.exposure_per_s = 0.001;
p.stop_time = 17.0;
p.form = 'E0 + Emax*frac';
end
