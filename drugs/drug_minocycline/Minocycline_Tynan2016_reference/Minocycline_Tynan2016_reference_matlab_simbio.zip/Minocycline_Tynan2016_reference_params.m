function p = Minocycline_Tynan2016_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: minocycline   source: Tynan_2016 / reference   route: iv_bolus
  p.name  = 'Minocycline_Tynan2016_reference_params';
  p.drug  = 'minocycline';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'iv_bolus';        % 'oral' | 'iv_bolus'
  p.depot = false;             % oral -> first-order absorption depot
  p.Vc = 27.2;                % central volume [L]
  p.CL = 12.18;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.0;                % absorption rate [1/h]
  p.F  = 0.62;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 200.0;             % dose [mg]
end
