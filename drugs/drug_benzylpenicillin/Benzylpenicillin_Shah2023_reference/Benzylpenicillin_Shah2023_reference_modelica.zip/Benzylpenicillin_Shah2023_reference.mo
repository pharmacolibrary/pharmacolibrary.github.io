model Benzylpenicillin_Shah2023_reference
  parameter Real Cl_ref = 6.666666666666667e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.0151 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.33438999999999997,
    adminMass = 0.0036,
    k12 = 0.00020419426048565121,
    k21 = 0.00031462585034013605
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About benzylpenicillin</h4><p>Benzylpenicillin is a penicillin antibiotic used to treat bacterial infections such as gonorrhea, diphtheria, botulism, actinomycosis, and septicemia caused by anthrax or staphylococci. It remains an approved medicine, is on the WHO essential medicines list, and is also approved for veterinary use.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q258450\">Wikidata Q258450</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>benzylpenicillin</td></tr><tr><td>population:</td><td>review reference</td></tr><tr><td>source_paper:</td><td>Shah_2023</td></tr><tr><td>measured_compound:</td><td>benzylpenicillin</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_2C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>benzylpenicillin 334.39 g/mol (drugbank)</td></tr></table><h4>Interpretation flags</h4><ul><li>built from REVIEW reference values (Shah_2023) — secondary source</li><li>volume reported by review</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Benzylpenicillin_Shah2023_reference;
