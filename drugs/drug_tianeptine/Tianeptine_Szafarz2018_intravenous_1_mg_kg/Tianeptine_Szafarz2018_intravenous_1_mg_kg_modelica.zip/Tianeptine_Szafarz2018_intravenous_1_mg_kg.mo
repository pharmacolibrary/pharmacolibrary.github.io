model Tianeptine_Szafarz2018_intravenous_1_mg_kg
  parameter Real Cl_ref = 0.0004159166666666667 "Cl [m3/s]";
  parameter Real Vd_ref = 2.8175 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.436952,
    adminMass = 7e-05,
    ka = 0.0001388888888888889,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About tianeptine</h4><p>Tianeptine is a tricyclic antidepressant used to treat depression. It is not approved in the United States, where it remains investigational, though it has been used as an antidepressant in some other countries.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q424260\">Wikidata Q424260</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>tianeptine</td></tr><tr><td>population:</td><td>rats</td></tr><tr><td>source_paper:</td><td>Szafarz_2018</td></tr><tr><td>measured_compound:</td><td>tianeptine</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>Tab3</td></tr><tr><td>input:</td><td>PK_1C_enteral: apparent (/F) parameterization ⇒ extravascular dosing</td></tr><tr><td>molar_masses:</td><td>tianeptine 436.952 g/mol (drugbank)</td></tr></table><p><b>Defaulted (base-class default used):</b> ka, Tlag.</p><h4>Interpretation flags</h4><ul><li>dropped unlinked row (NIL): 'Parameter' — extend the ontology if this is a real PK parameter (source ['Tab3:row0:col1', 'Tab3:row0:col2', 'Tab3:row0:col3', 'Tab3:row0:col4'])</li><li>dropped unlinked row (NIL): 'C o/C max (mg/L)' — extend the ontology if this is a real PK parameter (source ['Tab3:row3:col2', 'Tab3:row3:col4'])</li><li>apparent-ness (ontology-grounded): parameterization=apparent, measured_compound=tianeptine</li><li>population split: 'intravenous 1 mg/kg' subgroup of Szafarz_2018 (paper reports 3 populations: estimate, intraperitoneal 10 mg/kg, intravenous 1 mg/kg)</li><li>engineer: parent → metabolite not buildable on PK_3M_9C (None) — the measured compound's 1-compartment model instead</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 1209600, Tolerance = 1e-9, Interval = 1));
end Tianeptine_Szafarz2018_intravenous_1_mg_kg;
