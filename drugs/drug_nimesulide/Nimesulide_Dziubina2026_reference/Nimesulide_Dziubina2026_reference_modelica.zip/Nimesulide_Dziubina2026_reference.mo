model Nimesulide_Dziubina2026_reference
  parameter Real Cl_ref = 0.0007097222222222222 "Cl [m3/s]";
  parameter Real Vd_ref = 13.141099999999998 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.30831000000000003,
    adminMass = 0.0002,
    ka = 0.0001388888888888889,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About nimesulide</h4><p>Nimesulide is a non-steroidal anti-inflammatory drug used to treat pain and inflammation. It has been approved in some countries but withdrawn in others, reportedly over safety concerns including liver damage, so its availability varies by country.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q20994\">Wikidata Q20994</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>nimesulide</td></tr><tr><td>population:</td><td>review reference</td></tr><tr><td>source_paper:</td><td>Dziubina_2026</td></tr><tr><td>measured_compound:</td><td>nimesulide</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C_enteral: apparent (/F) parameterization ⇒ extravascular dosing</td></tr><tr><td>molar_masses:</td><td>nimesulide 308.31 g/mol (drugbank)</td></tr></table><p><b>Defaulted (base-class default used):</b> ka, Tlag.</p><h4>Interpretation flags</h4><ul><li>built from REVIEW reference values (Dziubina_2026) — secondary source</li><li>volume reported by review</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Nimesulide_Dziubina2026_reference;
