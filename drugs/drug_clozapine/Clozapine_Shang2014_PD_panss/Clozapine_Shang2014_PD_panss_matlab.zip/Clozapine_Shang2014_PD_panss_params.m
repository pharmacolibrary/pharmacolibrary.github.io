function p = Clozapine_Shang2014_PD_panss_params()
% Clozapine_Shang2014_PD_panss_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% clozapine Shang_2014::PANSS: emax exposure-response sweep (response = E0 + Emax*frac). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one mg·L(-1)·h(-1)·d(-1) per second, in SI inside (kg/m3, s). Response PANSS in its own unit. Driver: clozapine (cited_pk).
p.E0 = 0.0;
p.Emax = -0.554;
p.EC50 = 296.0;
p.gamma = 1.0;
p.slope = 0.0;
p.exposure_per_s = 1.0;
p.stop_time = 3000.0;
p.form = 'E0 + Emax*frac';
end
