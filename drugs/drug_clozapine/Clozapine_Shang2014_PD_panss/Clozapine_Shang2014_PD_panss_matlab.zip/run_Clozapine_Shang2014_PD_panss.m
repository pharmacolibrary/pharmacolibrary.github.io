% run_Clozapine_Shang2014_PD_panss  Evaluate the exposure-response curve and plot response against exposure.
% A sweep is a static map: no ODE solver is needed. exposure runs 0..stop_time*exposure_per_s.
p = Clozapine_Shang2014_PD_panss_params();
exposure = linspace(0, p.stop_time * p.exposure_per_s, 501);
frac = exposure.^p.gamma ./ (p.EC50^p.gamma + exposure.^p.gamma);
E0 = p.E0; Emax = p.Emax; slope = p.slope;
response = E0 + Emax.*frac;
figure; plot(exposure, response, 'LineWidth', 1.5); grid on;
xlabel('exposure [mg·L(-1)·h(-1)·d(-1)]'); ylabel('response []'); title('Clozapine_Shang2014_PD_panss', 'Interpreter', 'none');
writematrix([exposure(:) response(:)], 'Clozapine_Shang2014_PD_panss.csv');
