model Clozapine_Shang2014_PD_panss
  "emax exposure-response sweep — Shang_2014 :: PANSS (total PANSS score)"
  extends Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep(
    E0 = 0,      // [1]
    Emax = -0.554,  // [1; % × 0.01]
    EC50 = 296,  // [mg·L(-1)·h(-1)·d(-1)]
    gamma = 1,
    exposure_per_s = 1);   // 1 mg·L(-1)·h(-1)·d(-1) per second
  // imax_as_negative_emax: Imax (Q323) enters SigmoidEmaxSweep as −Emax
  // exposure_unit_unresolved: 'mg·L(-1)·h(-1)·d(-1)' — the x axis is in the paper's unit, not SI
  // defaulted: E0
  // defaulted: gamma
  annotation(experiment(StartTime = 0, StopTime = 3000, Interval = 6),
    Documentation(info = "<html><body><!-- drug-about --><h4>About clozapine</h4><p>Clozapine is an atypical antipsychotic used mainly for schizophrenia, and also for other psychotic and mood disorders such as bipolar disorder and psychosis in Parkinson's disease. It is an approved medicine on the WHO essential medicines list, but carries a boxed warning, so its use is restricted and requires careful monitoring.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q221361\">Wikidata Q221361</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h4>Clozapine_Shang2014_PD_panss</h4><p>The steady-state exposure-response curve of Shang DW et al., <i>Therapeutic drug monitoring 36(3):378–386</i> 2014 (<a href=\"https://doi.org/10.1097/FTD.0000000000000014\">doi:10.1097/FTD.0000000000000014</a>) — total PANSS score against clozapine mg·L(-1)·h(-1)·d(-1) — obtained by sweeping the driver instead of simulating a dose. Model family: emax.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = (library default) drug-free response (baseline)
  Emax  =       55.4 %        maximal effect term (Emax, Q323)
  EC50  =        296 mg·L(-1)·h(-1)·d(-1) exposure at half of the maximal effect term (cAUC50, Q321)
  gamma = (library default) Hill coefficient</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep\">SigmoidEmaxSweep</a>; this model only supplies the numbers. The x axis is one mg·L(-1)·h(-1)·d(-1) of clozapine per second of simulated time: there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0   (drug-free)
  exposure = EC50 (296 mg·L(-1)·h(-1)·d(-1))  response -0.277
  exposure -> infinity  response -0.554</pre></body></html>"));
end Clozapine_Shang2014_PD_panss;
