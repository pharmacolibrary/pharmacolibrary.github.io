function p = Clozapine_Zeng1997_PD_camp_params()
% Clozapine_Zeng1997_PD_camp_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% clozapine Zeng_1997::cAMP: emax exposure-response sweep (response = E0 + Emax*frac). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one nM per second, in SI inside (kg/m3, s). Response cAMP in % of carbachol maximum. Driver: clozapine (cited_pk).
p.E0 = 0.0;
p.Emax = -74.0;
p.EC50 = 60.0;
p.gamma = 1.0;
p.slope = 0.0;
p.exposure_per_s = 1.0;
p.stop_time = 600.0;
p.form = 'E0 + Emax*frac';
end
