model Clozapine_Zeng1997_PD_camp
  "emax exposure-response sweep — Zeng_1997 :: cAMP (forskolin-stimulated cAMP accumulation (inhibition of cAMP formation))"
  extends Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep(
    E0 = 0,      // [1]
    Emax = -74,  // [% of carbachol maximum]
    EC50 = 60,  // [nM]
    gamma = 1,
    exposure_per_s = 1);   // 1 nM per second
  // imax_as_negative_emax: Imax (Q323) enters SigmoidEmaxSweep as −Emax
  // exposure_unit_unresolved: 'nM' — the x axis is in the paper's unit, not SI
  // defaulted: E0
  // defaulted: gamma
  annotation(experiment(StartTime = 0, StopTime = 600, Interval = 1.2),
    Documentation(info = "<html><body><!-- drug-about --><h4>About clozapine</h4><p>Clozapine is an atypical antipsychotic used mainly for schizophrenia, and also for other psychotic and mood disorders such as bipolar disorder and psychosis in Parkinson's disease. It is an approved medicine on the WHO essential medicines list, but carries a boxed warning, so its use is restricted and requires careful monitoring.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q221361\">Wikidata Q221361</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h4>Clozapine_Zeng1997_PD_camp</h4><p>The steady-state exposure-response curve of Zeng XP et al., <i>European journal of pharmacology 321(3):349–354</i> 1997 (<a href=\"https://doi.org/10.1016/s0014-2999(96)00956-9\">doi:10.1016/s0014-2999(96)00956-9</a>) — forskolin-stimulated cAMP accumulation (inhibition of cAMP formation) [% of carbachol maximum] against clozapine nM — obtained by sweeping the driver instead of simulating a dose. Model family: emax.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = (library default) drug-free response (baseline)
  Emax  =         74 % of carbachol maximum maximal effect term (Emax, Q323)
  EC50  =         60 nM       exposure at half of the maximal effect term (EC50, Q321)
  gamma = (library default) Hill coefficient</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep\">SigmoidEmaxSweep</a>; this model only supplies the numbers. The x axis is one nM of clozapine per second of simulated time: there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0   (drug-free)
  exposure = EC50 (60 nM)  response -37
  exposure -> infinity  response -74</pre></body></html>"));
end Clozapine_Zeng1997_PD_camp;
