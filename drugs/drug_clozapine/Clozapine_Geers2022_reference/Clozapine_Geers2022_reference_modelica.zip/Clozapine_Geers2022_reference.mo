model Clozapine_Geers2022_reference
  parameter Real Cl_ref = 1.7733333333333332e-05 "Cl [m3/s]";
  parameter Real Vd_ref = 0.6719999999999999 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.326823,
    adminMass = 0.0004,
    ka = 0.0003805555555555556,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About clozapine</h4><p>Clozapine is an atypical antipsychotic used mainly for schizophrenia, and also for other psychotic and mood disorders such as bipolar disorder and psychosis in Parkinson's disease. It is an approved medicine on the WHO essential medicines list, but carries a boxed warning, so its use is restricted and requires careful monitoring.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q221361\">Wikidata Q221361</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>clozapine</td></tr><tr><td>population:</td><td>schizophrenia patients on clozapine</td></tr><tr><td>source_paper:</td><td>Geers_2022</td></tr><tr><td>measured_compound:</td><td>clozapine</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>table3-20451253211065857</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>clozapine 326.823 g/mol (drugbank)</td></tr></table><h4>Interpretation flags</h4><ul><li>unit_dimension_unknown: 'L/kgLBMc' (V/F)</li><li>dropped unlinked row (NIL): 'AIC' — extend the ontology if this is a real PK parameter (source ['table3-20451253211065857:row6:col1', 'table3-20451253211065857:row6:col2'])</li><li>implicit units: 'Vd/F (L/kgLBMc)' → L/kg (from the paper text: '&quot;for simplicity clozapine volume of distribution is expressed in L/kg bodyweight&quot;; also &quot;distribution volume per kg body')</li><li>apparent-ness (ontology-grounded): parameterization=apparent, measured_compound=clozapine</li><li>skipped review gap-fill of CL: primary's parameterization (rate-constant / ka-only) does not use it</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary's parameterization (rate-constant / ka-only) does not use it</li><li>derived CL/F=63.84 L/h from Ke × V/F = CL/F (Q47 × Q76); not separately reported</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 140400, Tolerance = 1e-9, Interval = 1));
end Clozapine_Geers2022_reference;
