function p = Clozapine_Parker2001_PD_theta_amplitude_params()
% Clozapine_Parker2001_PD_theta_amplitude_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% clozapine Parker_2001::theta_amplitude: sigmoid_emax exposure-response sweep (response = E0 + Emax*frac). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one ng ml−1 per second, in SI inside (kg/m3, s). Response theta amplitude in µV s−1. Driver: clozapine (pk_record).
p.E0 = 80.0;
p.Emax = 18.0;
p.EC50 = 0.0012599999999999998;
p.gamma = 5.9;
p.slope = 0.0;
p.exposure_per_s = 1e-06;
p.stop_time = 13000.0;
p.form = 'E0 + Emax*frac';
end
