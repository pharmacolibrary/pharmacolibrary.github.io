model Clozapine_Parker2001_PD_theta_amplitude
  "sigmoid_emax exposure-response sweep — Parker_2001 :: theta amplitude (Increase in amplitude in the theta EEG frequency band)"
  extends Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep(
    E0 = 80,      // [µV s−1]
    Emax = 18,  // [µV s−1]
    EC50 = 0.00126,  // [kg/m3; ng ml−1 × 1e-06]
    gamma = 5.9,
    exposure_per_s = 1e-06);   // 1 ng ml−1 per second
  annotation(experiment(StartTime = 0, StopTime = 13000, Interval = 26),
    Documentation(info = "<html><body><!-- drug-about --><h4>About clozapine</h4><p>Clozapine is an atypical antipsychotic used mainly for schizophrenia, and also for other psychotic and mood disorders such as bipolar disorder and psychosis in Parkinson's disease. It is an approved medicine on the WHO essential medicines list, but carries a boxed warning, so its use is restricted and requires careful monitoring.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q221361\">Wikidata Q221361</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h4>Clozapine_Parker2001_PD_theta_amplitude</h4><p>The steady-state exposure-response curve of Parker TJ et al., <i>British journal of pharmacology 132(1):151–158</i> 2001 (<a href=\"https://doi.org/10.1038/sj.bjp.0703791\">doi:10.1038/sj.bjp.0703791</a>) — Increase in amplitude in the theta EEG frequency band [µV s−1] against clozapine ng ml−1 — obtained by sweeping the driver instead of simulating a dose. Model family: sigmoid_emax.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    =         80 µV s−1   drug-free response (baseline) (E0, Q324)
  Emax  =         18 µV s−1   maximal effect term (Emax, Q320)
  EC50  =       1260 ng ml−1  exposure at half of the maximal effect term (EC50, Q321)
  gamma =        5.9          Hill coefficient (N, Q325)</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep\">SigmoidEmaxSweep</a>; this model only supplies the numbers. The x axis is one ng ml−1 of clozapine per second of simulated time (exposure is in kg/m3): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 80   (drug-free)
  exposure = EC50 (1260 ng ml−1)  response 89
  exposure -> infinity  response 98</pre></body></html>"));
end Clozapine_Parker2001_PD_theta_amplitude;
