model Riluzole_Feng2025_PD_madrs
  "log_linear exposure-response sweep — Feng_2025 :: MADRS (Change in MADRS score from baseline)"
  extends Pharmacolibrary.Interfaces.PartialExposureResponseSweep(
    E0 = 0,      // [1]
    Emax = 0, EC50 = 1,      // unused by a line
    exposure_per_s = 1);
  parameter Real slope = 6.12268518519e-07   "[1 / second; 1/day × 1.15741e-05]";
equation
  response = E0 + slope*log(exposure);
  // imax_as_negative_emax: Imax (Q323) enters SigmoidEmaxSweep as −Emax
  // defaulted: E0
  annotation(experiment(StartTime = 0, StopTime = 1000, Interval = 2),
    Documentation(info = "<html><body><!-- drug-about --><h4>About riluzole</h4><p>Riluzole is a medication used to treat amyotrophic lateral sclerosis. It is an approved drug, authorised in the European Union for this condition.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q415744\">Wikidata Q415744</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h4>Riluzole_Feng2025_PD_madrs</h4><p>The steady-state exposure-response curve of Feng Y et al., <i>The international journal of neuropsychopharmacology 28(2):pyaf007</i> 2025 (<a href=\"https://doi.org/10.1093/ijnp/pyaf007\">doi:10.1093/ijnp/pyaf007</a>) — Change in MADRS score from baseline [points] against riluzole + SSRIs/SNRIs (oral regimen) — obtained by sweeping the driver instead of simulating a dose. Model family: log_linear.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = (library default) drug-free response (baseline)
  Emax  =         11 points   maximal effect term (θ Emax, Q323)
  slope =     0.0529 1/day    change in response per unit of exposure (θk, Q335)</pre><p>The algebra is <code>response = E0 + slope*log(exposure)</code>; this model only supplies the numbers. The x axis is one  of riluzole + SSRIs/SNRIs (oral regimen) per second of simulated time: there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p></body></html>"));
end Riluzole_Feng2025_PD_madrs;
