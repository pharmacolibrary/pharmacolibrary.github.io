function p = Riluzole_Feng2025_PD_madrs_params()
% Riluzole_Feng2025_PD_madrs_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% riluzole Feng_2025::MADRS: log_linear exposure-response sweep (response = E0 + slope*log(exposure)). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one SI per second, in SI inside (kg/m3, s). Response MADRS in points. Driver: riluzole + SSRIs/SNRIs (oral regimen) (not_resolved).
p.E0 = 0.0;
p.Emax = -11.0;
p.EC50 = 1.0;
p.gamma = 1.0;
p.slope = 6.122685185185185e-07;
p.exposure_per_s = 1.0;
p.stop_time = 1000.0;
p.form = 'E0 + slope*log(exposure)';
end
