% run_Riluzole_Feng2025_PD_madrs  Evaluate the exposure-response curve and plot response against exposure.
% A sweep is a static map: no ODE solver is needed. exposure runs 0..stop_time*exposure_per_s.
p = Riluzole_Feng2025_PD_madrs_params();
exposure = linspace(0, p.stop_time * p.exposure_per_s, 501);
frac = exposure.^p.gamma ./ (p.EC50^p.gamma + exposure.^p.gamma);
E0 = p.E0; Emax = p.Emax; slope = p.slope;
response = E0 + slope.*log(exposure);
figure; plot(exposure, response, 'LineWidth', 1.5); grid on;
xlabel('exposure [SI]'); ylabel('response [points]'); title('Riluzole_Feng2025_PD_madrs', 'Interpreter', 'none');
writematrix([exposure(:) response(:)], 'Riluzole_Feng2025_PD_madrs.csv');
