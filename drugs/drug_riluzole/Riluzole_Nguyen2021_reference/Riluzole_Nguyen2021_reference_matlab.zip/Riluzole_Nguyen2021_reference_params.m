function p = Riluzole_Nguyen2021_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: riluzole   source: Nguyen_2021 / reference   route: oral
  p.name  = 'Riluzole_Nguyen2021_reference_params';
  p.drug  = 'riluzole';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 557.1;                % central volume [L]
  p.CL = 49.5;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 5.0;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 50.0;             % dose [mg]
end
