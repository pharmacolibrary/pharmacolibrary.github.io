model Riluzole_Nguyen2021_reference
  parameter Real Cl_ref = 1.375e-05 "Cl [m3/s]";
  parameter Real Vd_ref = 0.5571 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.23419800000000002,
    adminMass = 5e-05,
    ka = 0.001388888888888889,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About riluzole</h4><p>Riluzole is a medication used to treat amyotrophic lateral sclerosis. It is an approved drug, authorised in the European Union for this condition.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q415744\">Wikidata Q415744</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>riluzole</td></tr><tr><td>population:</td><td>adults with acute spinal cord injury</td></tr><tr><td>source_paper:</td><td>Nguyen_2021</td></tr><tr><td>measured_compound:</td><td>riluzole</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>jcph1876-tbl-0002</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>riluzole 234.198 g/mol (drugbank)</td></tr></table><p><b>Defaulted (base-class default used):</b> Tlag.</p><h4>Interpretation flags</h4><ul><li>table section covariance: 'Multiplicative residual error' routed out of structural estimates ('Covariance (CL,V)')</li><li>table section covariance: 'CL equation' routed out of structural estimates ('Covariance (CL,V)')</li><li>table section covariance: 'CL equation' routed out of structural estimates ('Covariance (CL,V)')</li><li>table section covariance: 'CL equation' routed out of structural estimates ('Covariance (CL,V)')</li><li>table section covariance: 'CL equation' routed out of structural estimates ('Covariance (CL,V)')</li><li>table section covariance: 'V equation' routed out of structural estimates ('Covariance (CL,V)')</li><li>table section covariance: 'V equation' routed out of structural estimates ('Covariance (CL,V)')</li><li>table section covariance: 'V equation' routed out of structural estimates ('Covariance (CL,V)')</li><li>table section covariance: 'V equation' routed out of structural estimates ('Covariance (CL,V)')</li><li>salvaged Q27 ('CL/F'=49.5) from results prose — parameter table was unreadable</li><li>salvaged Q76 ('Vd/F'=557.1) from results prose — parameter table was unreadable</li><li>salvaged Q49 ('absorption constant'=5) from results prose — parameter table was unreadable</li><li>apparent-ness (ontology-grounded): parameterization=apparent, measured_compound=riluzole</li><li>held at status:extracted — NIL link or unit issue (mismatch/unknown/normalisation-failed) present</li><li>status held at route_to_review — not promoted</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 144000, Tolerance = 1e-9, Interval = 1));
end Riluzole_Nguyen2021_reference;
