function p = Riluzole_Zhao2016_PD_fmp_blue_fluorescence_params()
% Riluzole_Zhao2016_PD_fmp_blue_fluorescence_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% riluzole Zhao_2016::FMP_blue_fluorescence: sigmoid_emax exposure-response sweep (response = E0 + Emax*frac). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one μM per second, in SI inside (kg/m3, s). Response FMP blue fluorescence in %. Driver: riluzole (cited_pk).
p.E0 = 0.0;
p.Emax = -11.7;
p.EC50 = 3.58;
p.gamma = 1.0;
p.slope = 0.0;
p.exposure_per_s = 1.0;
p.stop_time = 36.0;
p.form = 'E0 + Emax*frac';
end
