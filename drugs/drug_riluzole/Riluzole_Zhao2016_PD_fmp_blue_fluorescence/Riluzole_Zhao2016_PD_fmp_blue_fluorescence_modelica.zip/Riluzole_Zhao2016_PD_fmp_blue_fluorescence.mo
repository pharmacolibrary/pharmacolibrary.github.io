model Riluzole_Zhao2016_PD_fmp_blue_fluorescence
  "sigmoid_emax exposure-response sweep — Zhao_2016 :: FMP blue fluorescence (ATX (10 nM)-induced membrane depolarization (fluorescence, % of ATX response))"
  extends Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep(
    E0 = 0,      // [1]
    Emax = -11.7,  // [fold of vehicle control]
    EC50 = 3.58,  // [μM]
    gamma = 1,
    exposure_per_s = 1);   // 1 μM per second
  // inhibition_sign: effect_direction=inhibition with a positive Emax (Q320) — sign flipped
  // exposure_unit_unresolved: 'μM' — the x axis is in the paper's unit, not SI
  // defaulted: E0
  // defaulted: gamma
  annotation(experiment(StartTime = 0, StopTime = 36, Interval = 0.072),
    Documentation(info = "<html><body><!-- drug-about --><h4>About riluzole</h4><p>Riluzole is a medication used to treat amyotrophic lateral sclerosis. It is an approved drug, authorised in the European Union for this condition.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q415744\">Wikidata Q415744</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h4>Riluzole_Zhao2016_PD_fmp_blue_fluorescence</h4><p>The steady-state exposure-response curve of Zhao F et al., <i>Marine drugs 14(2)</i> 2016 (<a href=\"https://doi.org/10.3390/md14020036\">doi:10.3390/md14020036</a>) — ATX (10 nM)-induced membrane depolarization (fluorescence, % of ATX response) [%] against riluzole μM — obtained by sweeping the driver instead of simulating a dose. Model family: sigmoid_emax.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = (library default) drug-free response (baseline)
  Emax  =       11.7 fold of vehicle control maximal effect term (maximal response, Q320)
  EC50  =       3.58 μM       exposure at half of the maximal effect term (IC50, Q322)
  gamma = (library default) Hill coefficient</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep\">SigmoidEmaxSweep</a>; this model only supplies the numbers. The x axis is one μM of riluzole per second of simulated time: there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0   (drug-free)
  exposure = EC50 (3.58 μM)  response -5.85
  exposure -> infinity  response -11.7</pre></body></html>"));
end Riluzole_Zhao2016_PD_fmp_blue_fluorescence;
