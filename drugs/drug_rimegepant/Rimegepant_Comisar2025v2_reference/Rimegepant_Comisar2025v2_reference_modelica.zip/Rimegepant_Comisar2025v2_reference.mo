model Rimegepant_Comisar2025v2_reference
  parameter Real Cl_ref = 6.6944444444444455e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.114 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.5345679999999999,
    adminMass = 3.75e-05,
    ka = 0.0010722222222222222,
    Tlag = 0.0,
    k12 = 9.600389863547757e-06,
    k21 = 2.3792270531400967e-05
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>rimegepant</td></tr><tr><td>population:</td><td>adults</td></tr><tr><td>source_paper:</td><td>Comisar_2025_2</td></tr><tr><td>measured_compound:</td><td>rimegepant</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_2C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>rimegepant 534.568 g/mol (drugbank)</td></tr></table><p><b>Defaulted (base-class default used):</b> Tlag.</p><h4>Interpretation flags</h4><ul><li>apparent-ness (ontology-grounded): parameterization=apparent, measured_compound=rimegepant</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Rimegepant_Comisar2025v2_reference;
