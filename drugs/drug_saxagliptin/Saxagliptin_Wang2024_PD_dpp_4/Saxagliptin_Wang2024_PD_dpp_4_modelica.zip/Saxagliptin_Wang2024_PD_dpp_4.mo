model Saxagliptin_Wang2024_PD_dpp_4
  "sigmoid_emax exposure-response sweep — Wang_2024 :: DPP-4 (DPP-4 inhibition ratio)"
  extends Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep(
    E0 = 7.03,      // [ratio]
    Emax = -60.88,  // [ratio]
    EC50 = 0.00025174,  // [kg/m3; ng/mL × 1e-06]
    gamma = 1,
    exposure_per_s = 1e-06);   // 1 ng/mL per second
  // inhibition_sign: effect_direction=inhibition with a positive Emax (Q320) — sign flipped
  // defaulted: gamma
  annotation(experiment(StartTime = 0, StopTime = 2600, Interval = 5.2),
    Documentation(info = "<html><body><h4>Saxagliptin_Wang2024_PD_dpp_4</h4><p>The steady-state exposure-response curve of Wang T et al., <i>BMC pharmacology &amp; toxicology 25(1):35</i> 2024 (<a href=\"https://doi.org/10.1186/s40360-024-00757-3\">doi:10.1186/s40360-024-00757-3</a>) — DPP-4 inhibition ratio [ratio] against 5-hydroxy Saxagliptin ng/mL — obtained by sweeping the driver instead of simulating a dose. Model family: sigmoid_emax.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    =       7.03 ratio    drug-free response (baseline) (E0 — Mean, Q324)
  Emax  =      60.88 ratio    maximal effect term (Emax — Mean, Q320)
  EC50  =     251.74 ng/mL    exposure at half of the maximal effect term (EC50 — Mean, Q321)
  gamma = (library default) Hill coefficient</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep\">SigmoidEmaxSweep</a>; this model only supplies the numbers. The x axis is one ng/mL of 5-hydroxy Saxagliptin per second of simulated time (exposure is in kg/m3): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 7.03   (drug-free)
  exposure = EC50 (251.74 ng/mL)  response -23.41
  exposure -> infinity  response -53.85</pre></body></html>"));
end Saxagliptin_Wang2024_PD_dpp_4;
