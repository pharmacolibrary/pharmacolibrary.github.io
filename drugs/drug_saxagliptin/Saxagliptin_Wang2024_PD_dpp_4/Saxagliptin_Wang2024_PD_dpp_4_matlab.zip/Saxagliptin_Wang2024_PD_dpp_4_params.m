function p = Saxagliptin_Wang2024_PD_dpp_4_params()
% Saxagliptin_Wang2024_PD_dpp_4_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% saxagliptin Wang_2024::DPP_4: sigmoid_emax exposure-response sweep (response = E0 + Emax*frac). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one ng/mL per second, in SI inside (kg/m3, s). Response DPP-4 in ratio. Driver: 5-hydroxy Saxagliptin (pk_record).
p.E0 = 7.03;
p.Emax = -60.88;
p.EC50 = 0.00025173999999999997;
p.gamma = 1.0;
p.slope = 0.0;
p.exposure_per_s = 1e-06;
p.stop_time = 2600.0;
p.form = 'E0 + Emax*frac';
end
