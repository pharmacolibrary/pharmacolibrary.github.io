model Brivaracetam_Pressler2024_all_patients
  parameter Real Cl_ref = 6.38888888888889e-08 "Cl [m3/s]";
  parameter Real Vd_ref = 0.00257 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 0.9,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.2122887,
    adminMass = 3.5e-05,
    ka = 0.0014916666666666667,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About brivaracetam</h4><p>Brivaracetam is an anticonvulsant medicine used to treat epilepsy. It is authorised in the European Union for epilepsy and is an approved drug.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q408099\">Wikidata Q408099</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>brivaracetam</td></tr><tr><td>population:</td><td>neonates with repeated electroencephalographic seizures</td></tr><tr><td>source_paper:</td><td>Pressler_2024</td></tr><tr><td>measured_compound:</td><td>brivaracetam</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>epi412875-tbl-0002</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>brivaracetam 212.289 g/mol (drugbank)</td></tr></table><p><b>Defaulted (base-class default used):</b> F, Tlag.</p><h4>Interpretation flags</h4><ul><li>dropped duplicate Q88 ('AUC(0–infinity) (h*mg/L)', value '6.75') — already have one for this compound</li><li>dropped duplicate Q22 ('CL (mL/min)', value '3.88') — already have one for this compound</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=brivaracetam</li><li>structure disagreement: deterministic 1C vs LLM 2C — review compartment count</li><li>population split: 'all patients (n = 6)' subgroup of Pressler_2024 (paper reports 2 populations: all patients (n = 6), individual patient data)</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li><li>gap-filled Q49 (kabs) from Klein_2026's review values (primary lacked it)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 140400, Tolerance = 1e-9, Interval = 1));
end Brivaracetam_Pressler2024_all_patients;
