model Brivaracetam_Schoemaker2018_reference
  parameter Real Cl_ref = 9.388888888888888e-07 "Cl [m3/s]";
  parameter Real Vd_ref = 0.04870000000000001 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.2122887,
    adminMass = 0.0001,
    ka = 0.0008277777777777778,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About brivaracetam</h4><p>Brivaracetam is an anticonvulsant medicine used to treat epilepsy. It is authorised in the European Union for epilepsy and is an approved drug.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q408099\">Wikidata Q408099</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>brivaracetam</td></tr><tr><td>population:</td><td>review reference</td></tr><tr><td>source_paper:</td><td>Schoemaker_2018</td></tr><tr><td>measured_compound:</td><td>brivaracetam</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>brivaracetam 212.289 g/mol (drugbank)</td></tr></table><p><b>Defaulted (base-class default used):</b> Tlag.</p><h4>Interpretation flags</h4><ul><li>built from REVIEW reference values (Schoemaker_2018) — secondary source</li><li>volume reported by review</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 259200, Tolerance = 1e-9, Interval = 1));
end Brivaracetam_Schoemaker2018_reference;
