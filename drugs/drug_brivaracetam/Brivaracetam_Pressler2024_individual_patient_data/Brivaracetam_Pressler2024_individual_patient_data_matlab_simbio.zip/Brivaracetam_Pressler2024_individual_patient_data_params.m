function p = Brivaracetam_Pressler2024_individual_patient_data_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: brivaracetam   source: Pressler_2024 / individual_patient_data   route: oral
  % estimated (absent from source): F
  p.name  = 'Brivaracetam_Pressler2024_individual_patient_data_params';
  p.drug  = 'brivaracetam';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 2.18;                % central volume [L]
  p.CL = 0.22;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 5.37;                % absorption rate [1/h]
  p.F  = 0.9;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 35.0;             % dose [mg]
end
