model Amlodipine_Snelder2014_reference
  parameter Real Cl_ref = 1.15e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.05214217270681709 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 0.9,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.40887599999999996,
    adminMass = 5e-06,
    ka = 0.000325,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About amlodipine</h4><p>Amlodipine is a calcium channel blocker used to treat high blood pressure and angina. It is widely used worldwide and is included on the WHO list of essential medicines, available alone and in many fixed-dose combination products.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q411347\">Wikidata Q411347</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>amlodipine</td></tr><tr><td>population:</td><td>review reference</td></tr><tr><td>source_paper:</td><td>Snelder_2014</td></tr><tr><td>measured_compound:</td><td>amlodipine</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>amlodipine 408.876 g/mol (drugbank)</td></tr></table><p><b>Defaulted (base-class default used):</b> F, Tlag.</p><h4>Interpretation flags</h4><ul><li>built from REVIEW reference values (Snelder_2014) — secondary source</li><li>central volume derived from CL·t½/ln2</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 169200, Tolerance = 1e-9, Interval = 1));
end Amlodipine_Snelder2014_reference;
