function p = Amlodipine_Snelder2013_PD_tpr_params()
% Amlodipine_Snelder2013_PD_tpr_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% amlodipine Snelder_2013::TPR: indirect_response_i exposure-response sweep (response = E0*(1 - Emax*frac)). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one ng•mL -1 per second, in SI inside (kg/m3, s). Response TPR in mmHg•(mL•min -1 ) -1. Driver: amlodipine (cited_pk).
p.E0 = 0.0;
p.Emax = 1.0;
p.EC50 = 185.0;
p.gamma = 1.0;
p.slope = 0.0;
p.exposure_per_s = 1.0;
p.stop_time = 1900.0;
p.form = 'E0*(1 - Emax*frac)';
end
