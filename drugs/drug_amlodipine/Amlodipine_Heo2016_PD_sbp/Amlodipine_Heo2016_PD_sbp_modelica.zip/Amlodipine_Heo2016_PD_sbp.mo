model Amlodipine_Heo2016_PD_sbp
  "sigmoid_emax exposure-response sweep — Heo_2016 :: SBP (Systolic blood pressure)"
  extends Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep(
    E0 = 119,      // [mmHg]
    Emax = -0.164,  // [mmHg]
    EC50 = 8.27e-06,  // [kg/m3; ng ml-1 × 1e-06]
    gamma = 1,
    exposure_per_s = 1e-06);   // 1 ng ml-1 per second
  // imax_as_negative_emax: Imax (Q323) enters SigmoidEmaxSweep as −Emax
  // defaulted: gamma
  annotation(experiment(StartTime = 0, StopTime = 83, Interval = 0.166),
    Documentation(info = "<html><body><h4>Amlodipine_Heo2016_PD_sbp</h4><p>The steady-state exposure-response curve of Heo YA et al., <i>British journal of clinical pharmacology 82(6):1557–1567</i> 2016 (<a href=\"https://doi.org/10.1111/bcp.13082\">doi:10.1111/bcp.13082</a>) — Systolic blood pressure [mmHg] against amlodipine ng ml-1 — obtained by sweeping the driver instead of simulating a dose. Model family: sigmoid_emax.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    =        119 mmHg     drug-free response (baseline) (SBP BSL, Q324)
  Emax  =      0.164 mmHg     maximal effect term (I max, Q323)
  EC50  =       8.27 ng ml-1  exposure at half of the maximal effect term (SBP IC 50, Q322)
  gamma = (library default) Hill coefficient</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep\">SigmoidEmaxSweep</a>; this model only supplies the numbers. The x axis is one ng ml-1 of amlodipine per second of simulated time (exposure is in kg/m3): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 119   (drug-free)
  exposure = EC50 (8.27 ng ml-1)  response 118.9
  exposure -> infinity  response 118.8</pre></body></html>"));
end Amlodipine_Heo2016_PD_sbp;
