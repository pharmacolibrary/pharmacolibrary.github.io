model Amlodipine_Canbolat2018_PD_relaxation
  "emax exposure-response sweep — Canbolat_2018 :: relaxation (relaxation)"
  extends Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep(
    E0 = 0,      // [1]
    Emax = -1,  // [1; % × 0.01]
    EC50 = 4.77,  // [M]
    gamma = 1,
    exposure_per_s = 1);   // 1 M per second
  // imax_as_negative_emax: Imax (Q323) enters SigmoidEmaxSweep as −Emax
  // exposure_unit_unresolved: 'M' — the x axis is in the paper's unit, not SI
  // defaulted: E0
  // defaulted: gamma
  annotation(experiment(StartTime = 0, StopTime = 48, Interval = 0.096),
    Documentation(info = "<html><body><!-- drug-about --><h4>About amlodipine</h4><p>Amlodipine is a calcium channel blocker used to treat high blood pressure and angina. It is widely used worldwide and is included on the WHO list of essential medicines, available alone and in many fixed-dose combination products.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q411347\">Wikidata Q411347</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h4>Amlodipine_Canbolat2018_PD_relaxation</h4><p>The steady-state exposure-response curve of Canbolat S et al., <i>Physiology international 105(1):53–60</i> 2018 (<a href=\"https://doi.org/10.1556/2060.105.2018.1.2\">doi:10.1556/2060.105.2018.1.2</a>) — relaxation [%] against amlodipine M — obtained by sweeping the driver instead of simulating a dose. Model family: emax.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = (library default) drug-free response (baseline)
  Emax  =        100 %        maximal effect term (E max, Q323)
  EC50  =       4.77 M        exposure at half of the maximal effect term (pIC 50, Q322)
  gamma = (library default) Hill coefficient</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep\">SigmoidEmaxSweep</a>; this model only supplies the numbers. The x axis is one M of amlodipine per second of simulated time: there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0   (drug-free)
  exposure = EC50 (4.77 M)  response -0.5
  exposure -> infinity  response -1</pre></body></html>"));
end Amlodipine_Canbolat2018_PD_relaxation;
