function p = Amlodipine_Canbolat2018_PD_relaxation_params()
% Amlodipine_Canbolat2018_PD_relaxation_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% amlodipine Canbolat_2018::relaxation: emax exposure-response sweep (response = E0 + Emax*frac). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one M per second, in SI inside (kg/m3, s). Response relaxation in %. Driver: amlodipine (cited_pk).
p.E0 = 0.0;
p.Emax = -1.0;
p.EC50 = 4.77;
p.gamma = 1.0;
p.slope = 0.0;
p.exposure_per_s = 1.0;
p.stop_time = 48.0;
p.form = 'E0 + Emax*frac';
end
