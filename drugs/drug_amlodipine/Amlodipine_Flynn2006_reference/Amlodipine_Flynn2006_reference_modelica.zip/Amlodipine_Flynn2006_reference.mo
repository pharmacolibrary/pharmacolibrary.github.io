model Amlodipine_Flynn2006_reference
  parameter Real Cl_ref = 6.583333333333333e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 1.7570000000000001 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.40887599999999996,
    adminMass = 5e-06,
    ka = 0.00040555555555555554,
    Tlag = 3096.0
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>amlodipine</td></tr><tr><td>population:</td><td>hypertensive children and adolescents</td></tr><tr><td>source_paper:</td><td>Flynn_2006</td></tr><tr><td>measured_compound:</td><td>amlodipine</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>amlodipine 408.876 g/mol (drugbank)</td></tr></table><h4>Interpretation flags</h4><ul><li>dropped unlinked row (NIL): 'weight' — extend the ontology if this is a real PK parameter (source ['Flynn_2006:abstract'])</li><li>apparent-ness (ontology-grounded): parameterization=apparent, measured_compound=amlodipine</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li><li>gap-filled Q49 (kabs) from Chen_2024's review values (primary lacked it)</li><li>gap-filled Q83 (tlag) from Courlet_2021's review values (primary lacked it)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 950400, Tolerance = 1e-9, Interval = 1));
end Amlodipine_Flynn2006_reference;
