function p = Amlodipine_Jeppesen1998_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: amlodipine   source: Jeppesen_1998 / reference   route: oral
  % estimated (absent from source): F
  p.name  = 'Amlodipine_Jeppesen1998_reference_params';
  p.drug  = 'amlodipine';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 980.0;                % central volume [L]
  p.CL = 0.138;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 1.46;                % absorption rate [1/h]
  p.F  = 0.9;                 % bioavailability [0-1]
  p.Tlag = 0.86;             % absorption lag [h]
  p.dose = 5.0;             % dose [mg]
end
