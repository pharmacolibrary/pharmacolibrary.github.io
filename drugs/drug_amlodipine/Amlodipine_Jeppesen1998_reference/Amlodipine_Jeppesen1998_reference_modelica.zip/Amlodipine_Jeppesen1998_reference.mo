model Amlodipine_Jeppesen1998_reference
  parameter Real Cl_ref = 3.8333333333333326e-08 "Cl [m3/s]";
  parameter Real Vd_ref = 0.98 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 0.9,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.40887599999999996,
    adminMass = 5e-06,
    ka = 0.00040555555555555554,
    Tlag = 3096.0
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>amlodipine</td></tr><tr><td>population:</td><td>isolated guinea-pig hearts</td></tr><tr><td>source_paper:</td><td>Jeppesen_1998</td></tr><tr><td>measured_compound:</td><td>amlodipine</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>amlodipine 408.876 g/mol (drugbank)</td></tr></table><p><b>Defaulted (base-class default used):</b> F.</p><h4>Interpretation flags</h4><ul><li>dropped PD-category row 'Emax' → Q320 (Emax, category G11) — pharmacodynamic parameters belong to scholarpd, not the PK model (source ['Jeppesen_1998:abstract'])</li><li>dropped PD-category row 'EC50' → Q321 (EC50, category G11) — pharmacodynamic parameters belong to scholarpd, not the PK model (source ['Jeppesen_1998:abstract'])</li><li>dropped PD-category row 'Observed Emax-values' → Q320 (Emax, category G11) — pharmacodynamic parameters belong to scholarpd, not the PK model (source ['Jeppesen_1998:abstract', 'Jeppesen_1998:abstract', 'Jeppesen_1998:abstract'])</li><li>dropped PD-category row 'curve-fitted EC50-values' → Q321 (EC50, category G11) — pharmacodynamic parameters belong to scholarpd, not the PK model (source ['Jeppesen_1998:abstract', 'Jeppesen_1998:abstract', 'Jeppesen_1998:abstract'])</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=amlodipine</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li><li>gap-filled Q22 (CL) from Angeloni_2016's review values (primary lacked it)</li><li>gap-filled Q61 (V) from Courlet_2021's review values (primary lacked it)</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li><li>gap-filled Q49 (kabs) from Chen_2024's review values (primary lacked it)</li><li>gap-filled Q83 (tlag) from Courlet_2021's review values (primary lacked it)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Amlodipine_Jeppesen1998_reference;
