model Amlodipine_Snelder2014_PD_tpr
  "indirect_response_i exposure-response sweep — Snelder_2014 :: TPR (total peripheral resistance)"
  extends Pharmacolibrary.Interfaces.PartialExposureResponseSweep(
    E0 = 0,      // [1]
    Emax = 1,  // type I effect term
    EC50 = 8.28e-05,  // [kg/m3; ng mL -1 × 1e-06]
    gamma = 1,
    exposure_per_s = 1e-06);   // 1 ng mL -1 per second
equation
  response = E0*(1 - Emax*frac);   // steady state, indirect response type I
  // defaulted: E0
  // defaulted: gamma
  annotation(experiment(StartTime = 0, StopTime = 830, Interval = 1.66),
    Documentation(info = "<html><body><h4>Amlodipine_Snelder2014_PD_tpr</h4><p>The steady-state exposure-response curve of Snelder N et al., <i>British journal of pharmacology 171(22):5076–5092</i> 2014 (<a href=\"https://doi.org/10.1111/bph.12824\">doi:10.1111/bph.12824</a>) — total peripheral resistance [mmHg mL -1 min -1 beats per min mL min -1] against amlodipine ng mL -1 — obtained by sweeping the driver instead of simulating a dose. Model family: indirect_response_i.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = (library default) drug-free response (baseline)
  Emax  =          1          maximal effect term (Emax, Q323)
  EC50  =       82.8 ng mL -1 exposure at half of the maximal effect term (EC50, Q322)
  gamma = (library default) Hill coefficient</pre><p>The algebra is <code>response = E0*(1 - Emax*frac)</code>; this model only supplies the numbers. The x axis is one ng mL -1 of amlodipine per second of simulated time (exposure is in kg/m3): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0   (drug-free)
  exposure = EC50 (82.8 ng mL -1)  response 0
  exposure -> infinity  response 0</pre></body></html>"));
end Amlodipine_Snelder2014_PD_tpr;
