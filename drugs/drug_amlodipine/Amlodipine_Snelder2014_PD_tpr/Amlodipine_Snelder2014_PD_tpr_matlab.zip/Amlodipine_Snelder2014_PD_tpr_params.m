function p = Amlodipine_Snelder2014_PD_tpr_params()
% Amlodipine_Snelder2014_PD_tpr_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% amlodipine Snelder_2014::TPR: indirect_response_i exposure-response sweep (response = E0*(1 - Emax*frac)). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one ng mL -1 per second, in SI inside (kg/m3, s). Response TPR in mmHg mL -1 min -1 beats per min mL min -1. Driver: amlodipine (pk_record).
p.E0 = 0.0;
p.Emax = 1.0;
p.EC50 = 8.28e-05;
p.gamma = 1.0;
p.slope = 0.0;
p.exposure_per_s = 1e-06;
p.stop_time = 830.0;
p.form = 'E0*(1 - Emax*frac)';
end
