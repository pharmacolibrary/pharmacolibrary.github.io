model Amlodipine_Donnelly1993_PD_sbp
  "linear exposure-response sweep — Donnelly_1993 :: SBP (erect systolic blood pressure)"
  extends Pharmacolibrary.Interfaces.PartialExposureResponseSweep(
    E0 = 0,      // [1]
    Emax = 0, EC50 = 1,      // unused by a line
    exposure_per_s = 1e-06);
  parameter Real slope = -3.1   "[mm Hg/ng/ml]";
equation
  response = E0 + slope*exposure;
  // defaulted: E0
  annotation(experiment(StartTime = 0, StopTime = 1000, Interval = 2),
    Documentation(info = "<html><body><!-- drug-about --><h4>About amlodipine</h4><p>Amlodipine is a calcium channel blocker used to treat high blood pressure and angina. It is widely used worldwide and is included on the WHO list of essential medicines, available alone and in many fixed-dose combination products.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q411347\">Wikidata Q411347</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h4>Amlodipine_Donnelly1993_PD_sbp</h4><p>The steady-state exposure-response curve of Donnelly R et al., <i>Clinical pharmacology and therapeutics 54(3):303–310</i> 1993 (<a href=\"https://doi.org/10.1038/clpt.1993.151\">doi:10.1038/clpt.1993.151</a>) — erect systolic blood pressure [mm Hg] against amlodipine ng/ml — obtained by sweeping the driver instead of simulating a dose. Model family: linear.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = (library default) drug-free response (baseline)
  slope =       -3.1 mm Hg/ng/ml change in response per unit of exposure (responsiveness, Q335)</pre><p>The algebra is <code>response = E0 + slope*exposure</code>; this model only supplies the numbers. The x axis is one ng/ml of amlodipine per second of simulated time (exposure is in kg/m3): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0   (drug-free)</pre></body></html>"));
end Amlodipine_Donnelly1993_PD_sbp;
