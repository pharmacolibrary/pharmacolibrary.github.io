function p = Amlodipine_Donnelly1993_PD_sbp_params()
% Amlodipine_Donnelly1993_PD_sbp_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% amlodipine Donnelly_1993::SBP: linear exposure-response sweep (response = E0 + slope*exposure). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one ng/ml per second, in SI inside (kg/m3, s). Response SBP in mm Hg. Driver: amlodipine (cited_pk).
p.E0 = 0.0;
p.Emax = 0.0;
p.EC50 = 1.0;
p.gamma = 1.0;
p.slope = -3.1;
p.exposure_per_s = 1e-06;
p.stop_time = 1000.0;
p.form = 'E0 + slope*exposure';
end
