function p = Amlodipine_Heo2016_PD_dbp_params()
% Amlodipine_Heo2016_PD_dbp_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% amlodipine Heo_2016::DBP: sigmoid_emax exposure-response sweep (response = E0 + Emax*frac). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one ng ml-1 per second, in SI inside (kg/m3, s). Response DBP in mmHg. Driver: amlodipine (pk_record).
p.E0 = 71.3;
p.Emax = -0.164;
p.EC50 = 2.97e-06;
p.gamma = 1.0;
p.slope = 0.0;
p.exposure_per_s = 1e-06;
p.stop_time = 30.0;
p.form = 'E0 + Emax*frac';
end
