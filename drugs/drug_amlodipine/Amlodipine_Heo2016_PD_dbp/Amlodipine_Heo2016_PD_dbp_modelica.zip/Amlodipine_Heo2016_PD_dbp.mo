model Amlodipine_Heo2016_PD_dbp
  "sigmoid_emax exposure-response sweep — Heo_2016 :: DBP (Diastolic blood pressure)"
  extends Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep(
    E0 = 71.3,      // [mmHg]
    Emax = -0.164,  // [mmHg]
    EC50 = 2.97e-06,  // [kg/m3; ng ml-1 × 1e-06]
    gamma = 1,
    exposure_per_s = 1e-06);   // 1 ng ml-1 per second
  // imax_as_negative_emax: Imax (Q323) enters SigmoidEmaxSweep as −Emax
  // defaulted: gamma
  annotation(experiment(StartTime = 0, StopTime = 30, Interval = 0.06),
    Documentation(info = "<html><body><h4>Amlodipine_Heo2016_PD_dbp</h4><p>The steady-state exposure-response curve of Heo YA et al., <i>British journal of clinical pharmacology 82(6):1557–1567</i> 2016 (<a href=\"https://doi.org/10.1111/bcp.13082\">doi:10.1111/bcp.13082</a>) — Diastolic blood pressure [mmHg] against amlodipine ng ml-1 — obtained by sweeping the driver instead of simulating a dose. Model family: sigmoid_emax.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    =       71.3 mmHg     drug-free response (baseline) (DBP BSL, Q324)
  Emax  =      0.164 mmHg     maximal effect term (I max, Q323)
  EC50  =       2.97 ng ml-1  exposure at half of the maximal effect term (DBP IC 50, Q322)
  gamma = (library default) Hill coefficient</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep\">SigmoidEmaxSweep</a>; this model only supplies the numbers. The x axis is one ng ml-1 of amlodipine per second of simulated time (exposure is in kg/m3): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 71.3   (drug-free)
  exposure = EC50 (2.97 ng ml-1)  response 71.22
  exposure -> infinity  response 71.14</pre></body></html>"));
end Amlodipine_Heo2016_PD_dbp;
