function p = Amlodipine_Mukherjee2018_PD_sbp_params()
% Amlodipine_Mukherjee2018_PD_sbp_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% amlodipine Mukherjee_2018::SBP: linear exposure-response sweep (response = E0 + slope*exposure). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one ng/mL per second, in SI inside (kg/m3, s). Response SBP in mmHg. Driver: amlodipine (pk_record).
p.E0 = 148.8;
p.Emax = 0.0;
p.EC50 = 1.0;
p.gamma = 1.0;
p.slope = -3.145;
p.exposure_per_s = 1e-06;
p.stop_time = 1000.0;
p.form = 'E0 + slope*exposure';
end
