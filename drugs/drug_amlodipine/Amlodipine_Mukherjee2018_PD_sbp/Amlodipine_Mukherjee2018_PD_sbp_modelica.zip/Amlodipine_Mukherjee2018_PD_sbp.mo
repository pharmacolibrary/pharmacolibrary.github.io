model Amlodipine_Mukherjee2018_PD_sbp
  "linear exposure-response sweep — Mukherjee_2018 :: SBP (systolic blood pressure)"
  extends Pharmacolibrary.Interfaces.PartialExposureResponseSweep(
    E0 = 148.8,      // [mmHg]
    Emax = 0, EC50 = 1,      // unused by a line
    exposure_per_s = 1e-06);
  parameter Real slope = -3.145   "[mmHg·mL/ng]";
equation
  response = E0 + slope*exposure;
  // family_inferred: the record's model family is effect_compartment; read from the parameters: a slope and no Emax — linear
  annotation(experiment(StartTime = 0, StopTime = 1000, Interval = 2),
    Documentation(info = "<html><body><!-- drug-about --><h4>About amlodipine</h4><p>Amlodipine is a calcium channel blocker used to treat high blood pressure and angina. It is widely used worldwide and is included on the WHO list of essential medicines, available alone and in many fixed-dose combination products.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q411347\">Wikidata Q411347</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h4>Amlodipine_Mukherjee2018_PD_sbp</h4><p>The steady-state exposure-response curve of Mukherjee D et al., <i>Journal of pharmacokinetics and pharmacodynamics 45(3):443–456</i> 2018 (<a href=\"https://doi.org/10.1007/s10928-018-9574-0\">doi:10.1007/s10928-018-9574-0</a>) — systolic blood pressure [mmHg] against amlodipine ng/mL — obtained by sweeping the driver instead of simulating a dose. Model family: linear.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    =      148.8 mmHg     drug-free response (baseline) (Initial pressure, Q324)
  slope =     -3.145 mmHg·mL/ng change in response per unit of exposure (Direct effect rate, Q335)</pre><p>The algebra is <code>response = E0 + slope*exposure</code>; this model only supplies the numbers. The x axis is one ng/mL of amlodipine per second of simulated time (exposure is in kg/m3): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 148.8   (drug-free)</pre></body></html>"));
end Amlodipine_Mukherjee2018_PD_sbp;
