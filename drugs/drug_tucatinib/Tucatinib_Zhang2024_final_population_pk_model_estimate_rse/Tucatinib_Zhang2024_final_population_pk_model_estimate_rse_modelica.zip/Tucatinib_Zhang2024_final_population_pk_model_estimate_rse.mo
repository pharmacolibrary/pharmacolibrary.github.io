model Tucatinib_Zhang2024_final_population_pk_model_estimate_rse
  parameter Real Cl_ref = 3.111111111111111e-05 "Cl [m3/s]";
  parameter Real Vd_ref = 0.125 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.48053199999999996,
    adminMass = 0.0003,
    ka = 0.00011777777777777778,
    Tlag = 1411.2,
    k12 = 0.0001997777777777778,
    k21 = 3.932633420822398e-05
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About tucatinib</h4><p>Tucatinib is a HER2-blocking kinase inhibitor used to treat breast cancer, including metastatic disease. It is an approved medicine and is authorised in the European Union.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q25100690\">Wikidata Q25100690</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>tucatinib</td></tr><tr><td>population:</td><td>healthy participants and patients with HER2+ metastatic breast or colorectal cancer</td></tr><tr><td>source_paper:</td><td>Zhang_2024</td></tr><tr><td>measured_compound:</td><td>tucatinib</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>Tab1</td></tr><tr><td>input:</td><td>PK_2C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>tucatinib 480.532 g/mol (drugbank)</td></tr></table><h4>Interpretation flags</h4><ul><li>table section iiv: 'Cov (CL/F, Vc/F)' routed out of structural estimates ('BSV correlations')</li><li>table section residual_error: 'Additive residual error SD (ng/mL)' routed out of structural estimates ('Residual variability')</li><li>table section residual_error: 'Proportional residual error CV' routed out of structural estimates ('Residual variability')</li><li>implicit units: 'CL/F (L/h), healthy participants' → L/h (from the paper text: 'The paper reports CL/F as a “geometric mean of 89.0 L/h,” establishing the unit for apparent clearance.')</li><li>implicit units: 'Ka (1/h)' → 1/h (from the paper text: 'The paper states “Ka = 0.4 h−1” for the popPK model.')</li><li>apparent-ness (ontology-grounded): parameterization=apparent, measured_compound=tucatinib</li><li>population split: 'final population pk model estimate (%rse)' subgroup of Zhang_2024 (paper reports 4 populations: final population pk model estimate (%rse), healthy participants (300 mg bid)n = 128, her2+ mbcn = 52, her2+ mcrcn = 68)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Tucatinib_Zhang2024_final_population_pk_model_estimate_rse;
