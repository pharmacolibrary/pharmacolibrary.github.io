function p = Tucatinib_Zhang2024_final_population_pk_model_estimate_rse_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: tucatinib   source: Zhang_2024 / final_population_pk_model_estimate_rse   route: oral
  p.name  = 'Tucatinib_Zhang2024_final_population_pk_model_estimate_rse_params';
  p.drug  = 'tucatinib';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 125.0;                % central volume [L]
  p.CL = 112.0;                % clearance [L/h]
  p.Vp = [635.0];             % peripheral volumes [L]
  p.Q  = [89.9];             % inter-compartmental clearances [L/h]
  p.ka = 0.424;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.392;             % absorption lag [h]
  p.dose = 300.0;             % dose [mg]
end
