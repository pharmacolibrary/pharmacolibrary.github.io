% Run (SimBiology): build model + dose, simulate 0..46.0 h, plot.
p = Tucatinib_Zhang2024_healthy_participants_300_mg_bid_params();
[model, dose, variant] = build_sb_pk(p);
sd = simulate_sb(model, variant, dose, 46.0);
