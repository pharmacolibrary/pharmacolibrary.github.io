model Tucatinib_Zhang2024_healthy_participants_300_mg_bid
  parameter Real Cl_ref = 3.2500000000000004e-05 "Cl [m3/s]";
  parameter Real Vd_ref = 0.793 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.48053199999999996,
    adminMass = 0.0003,
    ka = 0.0001388888888888889,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About tucatinib</h4><p>Tucatinib is a HER2-blocking kinase inhibitor used to treat breast cancer, including metastatic disease. It is an approved medicine and is authorised in the European Union.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q25100690\">Wikidata Q25100690</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>tucatinib</td></tr><tr><td>population:</td><td>healthy participants and patients with HER2+ metastatic breast or colorectal cancer</td></tr><tr><td>source_paper:</td><td>Zhang_2024</td></tr><tr><td>measured_compound:</td><td>tucatinib</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>Tab1</td></tr><tr><td>input:</td><td>PK_1C_enteral: apparent (/F) parameterization ⇒ extravascular dosing</td></tr><tr><td>molar_masses:</td><td>tucatinib 480.532 g/mol (drugbank)</td></tr></table><p><b>Defaulted (base-class default used):</b> ka, Tlag.</p><h4>Interpretation flags</h4><ul><li>dropped duplicate Q32 ('Rac, Cmax', value '1.21') — already have one for this compound</li><li>dropped duplicate Q37 ('Rac, Ctrough', value '1.63') — already have one for this compound</li><li>apparent-ness (ontology-grounded): parameterization=apparent, measured_compound=tucatinib</li><li>structure disagreement: deterministic 1C vs LLM 2C — review compartment count</li><li>population split: 'healthy participants (300 mg bid)n = 128' subgroup of Zhang_2024 (paper reports 4 populations: final population pk model estimate (%rse), healthy participants (300 mg bid)n = 128, her2+ mbcn = 52, her2+ mcrcn = 68)</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 165600, Tolerance = 1e-9, Interval = 1));
end Tucatinib_Zhang2024_healthy_participants_300_mg_bid;
