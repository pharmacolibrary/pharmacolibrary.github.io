function p = GlycopyrroniumBromide_Bartels2013_noncompartmental_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: glycopyrronium_bromide   source: Bartels_2013 / noncompartmental   route: iv_bolus
  % estimated (absent from source): F
  % Vc is the record's Vss — no central volume was reported; 1-compartment reading
  p.name  = 'GlycopyrroniumBromide_Bartels2013_noncompartmental_params';
  p.drug  = 'glycopyrronium_bromide';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'iv_bolus';        % 'oral' | 'iv_bolus'
  p.depot = false;             % oral -> first-order absorption depot
  p.Vc = 102.0;                % central volume [L]
  p.CL = 42.5;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.0;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 120.0;             % dose [mg]
end
