model GlycopyrroniumBromide_Bartels2013_noncompartmental
  parameter Real Cl_ref = 1.1805555555555557e-05 "Cl [m3/s]";
  parameter Real Vd_ref = 0.10200000000000001 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.318437,
    adminMass = 0.00012
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>glycopyrronium_bromide</td></tr><tr><td>population:</td><td>healthy volunteers</td></tr><tr><td>source_paper:</td><td>Bartels_2013</td></tr><tr><td>measured_compound:</td><td>glycopyrronium</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>tab_0</td></tr><tr><td>input:</td><td>PK_1C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>glycopyrronium_bromide 398.341 g/mol (pubchem); glycopyrronium 318.437 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>column 'noncompartmental' classified 'other' by the LLM but kept: the deterministic diagnostic-column test disagrees (a stratum column is a value column, not a statistic)</li><li>column 'noncompartmental' classified 'other' by the LLM but kept: the deterministic diagnostic-column test disagrees (a stratum column is a value column, not a statistic)</li><li>dropped duplicate Q57 ('Slow lung absorption half-life', value None) — already have one for this compound</li><li>dropped unlinked row (NIL): '0' — extend the ontology if this is a real PK parameter (source ['Bartels_2013_table_2:row21:col1'])</li><li>implicit units: 'Systemic clearance' → L/h (from the popPK convention: 'The paper does not explicitly state the unit for clearance in the provided text or table footnotes. However, for a drug ')</li><li>implicit units: 'Volume of distribution at steady state ‡' → L (from the popPK convention: 'The paper does not explicitly state the unit for volume of distribution in the provided text or table footnotes. A Vss o')</li><li>implicit units: 'Intermediate lung absorption half-life' → h (from the paper text: &quot;The footnote for Table 5 states: 'rate constants, K, expressed as half-lives, t1/2 = ln(2)/K'. While it doesn't explicit&quot;)</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=glycopyrronium</li><li>structure disagreement: deterministic 1C vs LLM 2C — review compartment count</li><li>population split: 'noncompartmental' subgroup of Bartels_2013 (paper reports 3 populations: model-based, noncompartmental, population mean (%cv))</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end GlycopyrroniumBromide_Bartels2013_noncompartmental;
