model GlycopyrroniumBromide_Bartels2013_population_mean_cv
  parameter Real Cl_ref = 1.2472222222222223e-05 "Cl [m3/s]";
  parameter Real Vd_ref = 0.011300000000000001 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C_enteral(
    weight = 70.0,
    F = 1.11,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.318437,
    adminMass = 0.00012,
    ka = 2.4999999999999998e-06,
    Tlag = 0.0,
    k12 = 0.00020231071779744348,
    k21 = 3.1973581973581977e-05
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>glycopyrronium_bromide</td></tr><tr><td>population:</td><td>healthy volunteers</td></tr><tr><td>source_paper:</td><td>Bartels_2013</td></tr><tr><td>measured_compound:</td><td>glycopyrronium</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>tab_0</td></tr><tr><td>input:</td><td>PK_2C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>glycopyrronium_bromide 398.341 g/mol (pubchem); glycopyrronium 318.437 g/mol (pubchem)</td></tr></table><p><b>Defaulted (base-class default used):</b> Tlag.</p><h4>Interpretation flags</h4><ul><li>dropped unlinked row (NIL): 'Parameter related to fraction of dose with slow absorption' — extend the ontology if this is a real PK parameter (source ['Bartels_2013_table_p6_1:row7:col3', 'Bartels_2013_table_p6_1:row7:col4'])</li><li>dropped unlinked row (NIL): 'Parameter related to fraction of dose with intermediate absorption' — extend the ontology if this is a real PK parameter (source ['Bartels_2013_table_p6_1:row8:col3', 'Bartels_2013_table_p6_1:row8:col4'])</li><li>dropped duplicate Q49 ('Intermediate lung absorption rate', value '1.54') — already have one for this compound</li><li>dropped duplicate Q49 ('GI tract absorption rate', value '0.34') — already have one for this compound</li><li>dropped duplicate Q57 ('Slow lung absorption half-life', value None) — already have one for this compound</li><li>dropped unlinked row (NIL): '0' — extend the ontology if this is a real PK parameter (source ['Bartels_2013_table_2:row21:col1'])</li><li>implicit units: 'Systemic clearance' → L/h (from the popPK convention: 'Systemic clearance (CL) is conventionally expressed in L/h in population PK studies. The value 44.9 is consistent with t')</li><li>implicit units: 'Volume of central plasma compartment' → L (from the popPK convention: 'Volume of distribution (V1) is conventionally expressed in L. The value 11.3 is consistent with a central plasma volume.')</li><li>implicit units: 'Intercompartmental clearance' → L/h (from the popPK convention: 'Intercompartmental clearance (Q) is conventionally expressed in L/h. The value 8.23 is consistent with this unit.')</li><li>implicit units: 'Volume of peripheral PK compartment' → L (from the popPK convention: 'Volume of distribution (V2) is conventionally expressed in L. The value 71.5 is consistent with a peripheral volume.')</li><li>implicit units: 'Slow lung absorption rate' → 1/h (from the popPK convention: 'Absorption rate constant (kabs) is a first-order rate constant, conventionally expressed in 1/h. The value 0.009 is cons')</li><li>implicit units: 'Volume of distribution at steady state ‡' → L (from the popPK convention: 'Volume of distribution at steady state (Vss) is conventionally expressed in L. The value 102 is consistent with this uni')</li><li>implicit units: 'Intermediate lung absorption half-life' → h (from the paper text: &quot;The table caption for Table 5 states: 'with rate constants, K, expressed as half-lives, t1/2 = ln(2)/K'. Half-lives are &quot;)</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=glycopyrronium</li><li>population split: 'population mean (%cv)' subgroup of Bartels_2013 (paper reports 3 populations: model-based, noncompartmental, population mean (%cv))</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 1209600, Tolerance = 1e-9, Interval = 1));
end GlycopyrroniumBromide_Bartels2013_population_mean_cv;
