model Artemether_Lohy2018_PD_eff
  "emax exposure-response sweep — Lohy_2018 :: EFF (Autoinduction effect (EFF) of artemether concentration on enzyme (CYP3A4) production rate, modulating ARM clearance)"
  extends Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep(
    E0 = 0,      // [1]
    Emax = 0.000273888888889,  // [1/s; h−1 × 0.000277778]
    EC50 = 9.37,  // [nM]
    gamma = 1,
    exposure_per_s = 1);   // 1 nM per second
  // exposure_unit_unresolved: 'nM' — the x axis is in the paper's unit, not SI
  // defaulted: E0
  // defaulted: gamma
  annotation(experiment(StartTime = 0, StopTime = 94, Interval = 0.188),
    Documentation(info = "<html><body><!-- drug-about --><h4>About artemether</h4><p>Artemether is an antimalarial medicine of the artemisinin group, used to treat malaria, and is also reported to have activity against other protozoa and schistosomiasis. It is an approved medicine, appears on the WHO essential medicines list, and is used both alone and in combination antimalarial products worldwide.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q416199\">Wikidata Q416199</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h4>Artemether_Lohy2018_PD_eff</h4><p>The steady-state exposure-response curve of Lohy Das J et al., <i>Antimicrobial agents and chemotherapy 62(10)</i> 2018 (<a href=\"https://doi.org/10.1128/AAC.00518-18\">doi:10.1128/AAC.00518-18</a>) — Autoinduction effect (EFF) of artemether concentration on enzyme (CYP3A4) production rate, modulating ARM clearance against artemether nM — obtained by sweeping the driver instead of simulating a dose. Model family: emax.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = (library default) drug-free response (baseline)
  Emax  =      0.986 h−1      maximal effect term (Emax, Q320)
  EC50  =       9.37 nM       exposure at half of the maximal effect term (EC50, Q321)
  gamma = (library default) Hill coefficient</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep\">SigmoidEmaxSweep</a>; this model only supplies the numbers. The x axis is one nM of artemether per second of simulated time: there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0   (drug-free)
  exposure = EC50 (9.37 nM)  response 0.0001369
  exposure -> infinity  response 0.0002739</pre></body></html>"));
end Artemether_Lohy2018_PD_eff;
