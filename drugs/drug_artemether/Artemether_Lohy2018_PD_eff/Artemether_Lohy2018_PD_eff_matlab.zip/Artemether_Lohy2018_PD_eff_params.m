function p = Artemether_Lohy2018_PD_eff_params()
% Artemether_Lohy2018_PD_eff_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% artemether Lohy_2018::EFF: emax exposure-response sweep (response = E0 + Emax*frac). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one nM per second, in SI inside (kg/m3, s). Response EFF in its own unit. Driver: artemether (pk_record).
p.E0 = 0.0;
p.Emax = 0.0002738888888888889;
p.EC50 = 9.37;
p.gamma = 1.0;
p.slope = 0.0;
p.exposure_per_s = 1.0;
p.stop_time = 94.0;
p.form = 'E0 + Emax*frac';
end
