model Artemether_Lohy2018_reference
  parameter Real Cl_ref = 0.00012972222222222223 "Cl [m3/s]";
  parameter Real Vd_ref = 3.0 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.2983746,
    adminMass = 8e-05,
    ka = 1.6027777777777778e-05,
    Tlag = 4716.0
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About artemether</h4><p>Artemether is an antimalarial medicine of the artemisinin group, used to treat malaria, and is also reported to have activity against other protozoa and schistosomiasis. It is an approved medicine, appears on the WHO essential medicines list, and is used both alone and in combination antimalarial products worldwide.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q416199\">Wikidata Q416199</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>artemether</td></tr><tr><td>population:</td><td>pregnant women with uncomplicated Plasmodium falciparum malaria (Rwanda)</td></tr><tr><td>source_paper:</td><td>Lohy_2018</td></tr><tr><td>measured_compound:</td><td>artemether</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>T2</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>artemether 298.375 g/mol (drugbank); dihydroartemisinin 284.352 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>table section iiv: 'MTT (h)' routed out of structural estimates ('BSV/BOV, % CV (% RSE)')</li><li>table section iiv: 'Vc/F (liters)' routed out of structural estimates ('BSV/BOV, % CV (% RSE)')</li><li>table section iiv: 'F' routed out of structural estimates ('BSV/BOV, % CV (% RSE)')</li><li>table section iiv: 'MTT (h)' routed out of structural estimates ('BSV/BOV, % CV (% RSE)')</li><li>table section iiv: 'CLARM/F (liters/h)' routed out of structural estimates ('BSV/BOV, % CV (% RSE)')</li><li>table section iiv: 'VARM/F (liters)' routed out of structural estimates ('BSV/BOV, % CV (% RSE)')</li><li>table section iiv: 'CLDHA/F (liters/h)' routed out of structural estimates ('BSV/BOV, % CV (% RSE)')</li><li>table section iiv: 'VDHA/F (liters)' routed out of structural estimates ('BSV/BOV, % CV (% RSE)')</li><li>dropped PD-category row 'Emax (h−1)' → Q320 (Emax, category G11) — pharmacodynamic parameters belong to scholarpd, not the PK model (source ['T2:row19:col1'])</li><li>dropped PD-category row 'EC50 (nM)' → Q321 (EC50, category G11) — pharmacodynamic parameters belong to scholarpd, not the PK model (source ['T2:row20:col1'])</li><li>dropped unlinked row (NIL): 'TIMEENZ (h)' — extend the ontology if this is a real PK parameter (source ['T2:row21:col1'])</li><li>dropped value-less row: 'Emax'</li><li>dropped value-less row: 'EC50'</li><li>dropped value-less row: 'TIMEENZ'</li><li>apparent-ness (ontology-grounded): parameterization=apparent, measured_compound=artemether</li><li>topology: transfer parameter unlinked (Q100) — add Kfm/formation-rate/rate-constant to the ontology; routing to review</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 345600, Tolerance = 1e-9, Interval = 1));
end Artemether_Lohy2018_reference;
