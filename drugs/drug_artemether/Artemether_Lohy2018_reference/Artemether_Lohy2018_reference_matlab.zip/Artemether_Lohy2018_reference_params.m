function p = Artemether_Lohy2018_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: artemether   source: Lohy_2018 / reference   route: oral
  p.name  = 'Artemether_Lohy2018_reference_params';
  p.drug  = 'artemether';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 3000.0;                % central volume [L]
  p.CL = 467.0;                % clearance [L/h]
  p.Vp = [111.0];             % peripheral volumes [L]
  p.Q  = [0.924];             % inter-compartmental clearances [L/h]
  p.ka = 0.0577;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 1.31;             % absorption lag [h]
  p.dose = 80.0;             % dose [mg]
end
