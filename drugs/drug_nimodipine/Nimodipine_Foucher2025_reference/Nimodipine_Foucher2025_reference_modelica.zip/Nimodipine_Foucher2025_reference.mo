model Nimodipine_Foucher2025_reference
  parameter Real Cl_ref = 1.5222222222222223e-05 "Cl [m3/s]";
  parameter Real Vd_ref = 0.314 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.4184403,
    adminMass = 5e-05
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>nimodipine</td></tr><tr><td>population:</td><td>adults with subarachnoid hemorrhage</td></tr><tr><td>source_paper:</td><td>Foucher_2025</td></tr><tr><td>measured_compound:</td><td>nimodipine</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>tab_1</td></tr><tr><td>input:</td><td>PK_1C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>nimodipine 418.44 g/mol (drugbank)</td></tr></table><h4>Interpretation flags</h4><ul><li>dropped duplicate Q22 ('Effect of BSA on clearance', value '1.1') — already have one for this compound</li><li>dropped duplicate Q22 ('Effect of MAP on clearance', value '0.4') — already have one for this compound</li><li>routed 'Interindividual variability of the' → Q312 (IIV) to iiv — variability estimate, not a structural parameter</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=nimodipine</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Nimodipine_Foucher2025_reference;
