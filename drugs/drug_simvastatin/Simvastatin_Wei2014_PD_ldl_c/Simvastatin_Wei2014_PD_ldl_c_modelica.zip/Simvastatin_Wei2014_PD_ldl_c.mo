model Simvastatin_Wei2014_PD_ldl_c
  "emax exposure-response sweep — Wei_2014 :: LDL-C (LDL-C)"
  extends Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep(
    E0 = 1.38,      // [kg/m3; mg/dl × 0.01]
    Emax = -0.61,  // [kg/m3; mg/dl × 0.01]
    EC50 = 8.56481481481e-11,  // [kg/s; mg/day × 1.15741e-11]
    gamma = 1,
    exposure_per_s = 1.15740740741e-11);   // 1 mg/day per second
  // imax_as_negative_emax: Imax (Q323) enters SigmoidEmaxSweep as −Emax
  // defaulted: gamma
  annotation(experiment(StartTime = 0, StopTime = 74, Interval = 0.148),
    Documentation(info = "<html><body><!-- drug-about --><h4>About simvastatin</h4><p>Simvastatin is a statin used to lower blood lipids in conditions such as hyperlipidemia, hypertriglyceridemia, arteriosclerosis and coronary artery disease. It is widely used and is included on the WHO list of essential medicines.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q670131\">Wikidata Q670131</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h4>Simvastatin_Wei2014_PD_ldl_c</h4><p>The steady-state exposure-response curve of Wei WQ et al., <i>Clinical pharmacology and therapeutics 95(3):331–338</i> 2014 (<a href=\"https://doi.org/10.1038/clpt.2013.202\">doi:10.1038/clpt.2013.202</a>) — LDL-C [mg/dl] against simvastatin mg/day — obtained by sweeping the driver instead of simulating a dose. Model family: emax.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    =        138 mg/dl    drug-free response (baseline) (E 0, Q324)
  Emax  =         61 mg/dl    maximal effect term (E max, Q323)
  EC50  =        7.4 mg/day   exposure at half of the maximal effect term (ED 50, Q321)
  gamma = (library default) Hill coefficient</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep\">SigmoidEmaxSweep</a>; this model only supplies the numbers. The x axis is one mg/day of simvastatin per second of simulated time (exposure is in kg/s): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 1.38   (drug-free)
  exposure = EC50 (7.4 mg/day)  response 1.075
  exposure -> infinity  response 0.77</pre></body></html>"));
end Simvastatin_Wei2014_PD_ldl_c;
