function p = Simvastatin_Wei2014_PD_ldl_c_params()
% Simvastatin_Wei2014_PD_ldl_c_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% simvastatin Wei_2014::LDL_C: emax exposure-response sweep (response = E0 + Emax*frac). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one mg/day per second, in SI inside (kg/m3, s). Response LDL-C in mg/dl. Driver: simvastatin (dose_only).
p.E0 = 1.38;
p.Emax = -0.6099999999999999;
p.EC50 = 8.564814814814815e-11;
p.gamma = 1.0;
p.slope = 0.0;
p.exposure_per_s = 1.15740740741e-11;
p.stop_time = 74.0;
p.form = 'E0 + Emax*frac';
end
