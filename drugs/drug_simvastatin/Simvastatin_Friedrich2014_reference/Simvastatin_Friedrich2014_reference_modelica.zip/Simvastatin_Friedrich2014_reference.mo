model Simvastatin_Friedrich2014_reference
  parameter Real Cl_ref = 4.25e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.228 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.4185662,
    adminMass = 3e-05,
    ka = 8.333333333333333e-05,
    Tlag = 0.0,
    k12 = 1.1927387914230019e-05,
    k21 = 3.2883246002955796e-06
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About simvastatin</h4><p>Simvastatin is a statin used to lower blood lipids in conditions such as hyperlipidemia, hypertriglyceridemia, arteriosclerosis and coronary artery disease. It is widely used and is included on the WHO list of essential medicines.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q670131\">Wikidata Q670131</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>simvastatin</td></tr><tr><td>population:</td><td>review reference</td></tr><tr><td>source_paper:</td><td>Friedrich_2014</td></tr><tr><td>measured_compound:</td><td>simvastatin</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_2C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>simvastatin 418.566 g/mol (drugbank)</td></tr></table><p><b>Defaulted (base-class default used):</b> Tlag.</p><h4>Interpretation flags</h4><ul><li>built from REVIEW reference values (Friedrich_2014) — secondary source</li><li>volume reported by review</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 259200, Tolerance = 1e-9, Interval = 1));
end Simvastatin_Friedrich2014_reference;
