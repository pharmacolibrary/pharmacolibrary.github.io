% run_Simvastatin_Kim2011_PD_ldl_c  Evaluate the exposure-response curve and plot response against exposure.
% A sweep is a static map: no ODE solver is needed. exposure runs 0..stop_time*exposure_per_s.
p = Simvastatin_Kim2011_PD_ldl_c_params();
exposure = linspace(0, p.stop_time * p.exposure_per_s, 501);
frac = exposure.^p.gamma ./ (p.EC50^p.gamma + exposure.^p.gamma);
E0 = p.E0; Emax = p.Emax; slope = p.slope;
response = E0.*(1 - Emax.*frac);
figure; plot(exposure, response, 'LineWidth', 1.5); grid on;
xlabel('exposure [ng/mL]'); ylabel('response [mg/dL]'); title('Simvastatin_Kim2011_PD_ldl_c', 'Interpreter', 'none');
writematrix([exposure(:) response(:)], 'Simvastatin_Kim2011_PD_ldl_c.csv');
