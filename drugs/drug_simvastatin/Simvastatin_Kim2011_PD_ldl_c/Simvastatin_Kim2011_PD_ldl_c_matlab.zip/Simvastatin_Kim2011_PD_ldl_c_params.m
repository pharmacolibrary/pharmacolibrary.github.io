function p = Simvastatin_Kim2011_PD_ldl_c_params()
% Simvastatin_Kim2011_PD_ldl_c_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% simvastatin Kim_2011::LDL_C: indirect_response_i exposure-response sweep (response = E0*(1 - Emax*frac)). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one ng/mL per second, in SI inside (kg/m3, s). Response LDL-C in mg/dL. Driver: simvastatin acid (conc_no_pk).
p.E0 = 0.9199999999999998;
p.Emax = 0.489;
p.EC50 = 8.68e-08;
p.gamma = 1.0;
p.slope = 0.0;
p.exposure_per_s = 1e-06;
p.stop_time = 0.87;
p.form = 'E0*(1 - Emax*frac)';
end
