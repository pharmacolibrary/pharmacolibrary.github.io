model Simvastatin_Kim2011_PD_ldl_c
  "indirect_response_i exposure-response sweep — Kim_2011 :: LDL-C (low-density lipoprotein-cholesterol)"
  extends Pharmacolibrary.Interfaces.PartialExposureResponseSweep(
    E0 = 0.92,      // [kg/m3; mg/dL × 0.01]
    Emax = 0.489,  // type I effect term
    EC50 = 8.68e-08,  // [kg/m3; ng/mL × 1e-06]
    gamma = 1,
    exposure_per_s = 1e-06);   // 1 ng/mL per second
equation
  response = E0*(1 - Emax*frac);   // steady state, indirect response type I
  // defaulted: gamma
  annotation(experiment(StartTime = 0, StopTime = 0.87, Interval = 0.00174),
    Documentation(info = "<html><body><!-- drug-about --><h4>About simvastatin</h4><p>Simvastatin is a statin used to lower blood lipids in conditions such as hyperlipidemia, hypertriglyceridemia, arteriosclerosis and coronary artery disease. It is widely used and is included on the WHO list of essential medicines.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q670131\">Wikidata Q670131</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h4>Simvastatin_Kim2011_PD_ldl_c</h4><p>The steady-state exposure-response curve of Kim J et al., <i>Basic &amp; clinical pharmacology &amp; toxicology 109(3):156–163</i> 2011 (<a href=\"https://doi.org/10.1111/j.1742-7843.2011.00700.x\">doi:10.1111/j.1742-7843.2011.00700.x</a>) — low-density lipoprotein-cholesterol [mg/dL] against simvastatin acid ng/mL — obtained by sweeping the driver instead of simulating a dose. Model family: indirect_response_i.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    =         92 mg/dL    drug-free response (baseline) (Baseline, Q324)
  Emax  =      0.489          maximal effect term (E max, Q323)
  EC50  =     0.0868 ng/mL    exposure at half of the maximal effect term (EC 50, Q322)
  gamma = (library default) Hill coefficient</pre><p>The algebra is <code>response = E0*(1 - Emax*frac)</code>; this model only supplies the numbers. The x axis is one ng/mL of simvastatin acid per second of simulated time (exposure is in kg/m3): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0.92   (drug-free)
  exposure = EC50 (0.0868 ng/mL)  response 0.6951
  exposure -> infinity  response 0.4701</pre></body></html>"));
end Simvastatin_Kim2011_PD_ldl_c;
