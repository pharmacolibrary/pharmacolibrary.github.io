model Sulfadoxine_de2018_reference
  parameter Real Cl_ref = 7.333333333333334e-09 "Cl [m3/s]";
  parameter Real Vd_ref = 0.00529 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.310329,
    adminMass = 8.75e-05,
    ka = 0.00014472222222222222,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About sulfadoxine</h4><p>Sulfadoxine is a sulfonamide antibiotic used as an antimalarial against Plasmodium falciparum malaria and also to treat pneumocystosis. It is used in combination with artemisinin derivatives for malaria, though some products have been withdrawn in certain markets.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q411557\">Wikidata Q411557</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>sulfadoxine</td></tr><tr><td>population:</td><td>African children and adults with uncomplicated falciparum malaria</td></tr><tr><td>source_paper:</td><td>de_2018</td></tr><tr><td>measured_compound:</td><td>sulfadoxine</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>T2</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>sulfadoxine 310.329 g/mol (drugbank)</td></tr></table><p><b>Defaulted (base-class default used):</b> Tlag.</p><h4>Interpretation flags</h4><ul><li>table section iiv: 'F' routed out of structural estimates ('BSV (%)c in:')</li><li>table section iiv: 'F' routed out of structural estimates ('BSV (%)c in:')</li><li>table section iiv: 'ka' routed out of structural estimates ('BSV (%)c in:')</li><li>table section iiv: 'ka' routed out of structural estimates ('BSV (%)c in:')</li><li>table section iiv: 'V' routed out of structural estimates ('BSV (%)c in:')</li><li>table section iiv: 'V' routed out of structural estimates ('BSV (%)c in:')</li><li>table section iiv: 'CL' routed out of structural estimates ('BSV (%)c in:')</li><li>table section iiv: 'CL' routed out of structural estimates ('BSV (%)c in:')</li><li>table section iiv: 'Correlation in CL of the two drugs (%)' routed out of structural estimates ('BSV (%)c in:')</li><li>table section iiv: 'Correlation in CL of the two drugs (%)' routed out of structural estimates ('BSV (%)c in:')</li><li>table section iiv: 'Additive error (μg/ml for sulfadoxine; ng/ml for pyrimethamine)' routed out of structural estimates ('BSV (%)c in:')</li><li>table section iiv: 'Additive error (μg/ml for sulfadoxine; ng/ml for pyrimethamine)' routed out of structural estimates ('BSV (%)c in:')</li><li>table section iiv: 'Proportional error (%)' routed out of structural estimates ('BSV (%)c in:')</li><li>table section iiv: 'Proportional error (%)' routed out of structural estimates ('BSV (%)c in:')</li><li>dropped unlinked row (NIL): 'PGA50 (mo after conception)' — extend the ontology if this is a real PK parameter (source ['T2:row7:col1', 'T2:row7:col2'])</li><li>dropped unlinked row (NIL): 'Mpumalanga, Boane, Namaachad' — extend the ontology if this is a real PK parameter (source ['T2:row13:col1', 'T2:row13:col2'])</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 3024000, Tolerance = 1e-9, Interval = 1));
end Sulfadoxine_de2018_reference;
