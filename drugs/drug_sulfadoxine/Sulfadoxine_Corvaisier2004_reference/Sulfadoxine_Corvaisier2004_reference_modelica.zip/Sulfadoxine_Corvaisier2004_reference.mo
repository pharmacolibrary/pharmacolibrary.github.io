model Sulfadoxine_Corvaisier2004_reference
  parameter Real Cl_ref = 7.143851944444444e-07 "Cl [m3/s]";
  parameter Real Vd_ref = 0.30653 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 0.9,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.310329,
    adminMass = 0.0001,
    ka = 0.0002541666666666667,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About sulfadoxine</h4><p>Sulfadoxine is a sulfonamide antibiotic used as an antimalarial against Plasmodium falciparum malaria and also to treat pneumocystosis. It is used in combination with artemisinin derivatives for malaria, though some products have been withdrawn in certain markets.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q411557\">Wikidata Q411557</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>sulfadoxine</td></tr><tr><td>population:</td><td>children with congenital toxoplasmosis</td></tr><tr><td>source_paper:</td><td>Corvaisier_2004</td></tr><tr><td>measured_compound:</td><td>sulfadoxine</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>sulfadoxine 310.329 g/mol (drugbank)</td></tr></table><p><b>Defaulted (base-class default used):</b> F, Tlag.</p><h4>Interpretation flags</h4><ul><li>dropped duplicate Q49 ('Mean absorption rate constant (SDX)', value 1.659) — already have one for this compound</li><li>dropped duplicate Q61 ('volume of distribution (SDX)', value 0.392) — already have one for this compound</li><li>dropped duplicate Q47 ('elimination rate constant (SDX)', value 0.00526) — already have one for this compound</li><li>dropped duplicate Q57 ('half-life (SDX)', value 6.6) — already have one for this compound</li><li>apparent-by-design (ADVISORY, codes unchanged): extravascular dosing with no identifiable F, so these reported disposition parameters are likely apparent unless the model puts first-pass in its structure — Q61 (volume of distribution (PYR))</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=sulfadoxine</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li><li>skipped review gap-fill of CL: primary's parameterization (rate-constant / ka-only) does not use it</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary's parameterization (rate-constant / ka-only) does not use it</li><li>skipped review gap-fill of TLAG: primary's parameterization (rate-constant / ka-only) does not use it</li><li>derived CL=2.57179 L/h from Ke × V = CL (Q47 × Q61); not separately reported</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 2419200, Tolerance = 1e-9, Interval = 1));
end Sulfadoxine_Corvaisier2004_reference;
