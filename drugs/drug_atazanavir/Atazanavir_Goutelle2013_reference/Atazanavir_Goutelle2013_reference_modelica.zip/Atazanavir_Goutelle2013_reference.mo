model Atazanavir_Goutelle2013_reference
  parameter Real Cl_ref = 3.7222222222222225e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.0711 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 0.9,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.7048555,
    adminMass = 0.0002,
    ka = 0.0002777777777777778,
    Tlag = 3240.0
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About atazanavir</h4><p>Atazanavir is an antiviral protease inhibitor used to treat HIV infections. It is an approved medicine, authorised in the European Union, and appears on the WHO essential medicines list, so it is used widely.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q423467\">Wikidata Q423467</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>atazanavir</td></tr><tr><td>population:</td><td>HIV-infected adults on unboosted atazanavir</td></tr><tr><td>source_paper:</td><td>Goutelle_2013</td></tr><tr><td>measured_compound:</td><td>atazanavir</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>tab_1</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>atazanavir 704.856 g/mol (drugbank)</td></tr></table><p><b>Defaulted (base-class default used):</b> F.</p><h4>Interpretation flags</h4><ul><li>table section iiv: 'CL (liters/h)' routed out of structural estimates ('Interindividual')</li><li>table section iiv: 'V (liters)' routed out of structural estimates ('Interindividual')</li><li>table section iiv: 'k a reg (h Ϫ1 )' routed out of structural estimates ('Interindividual')</li><li>table section iiv: 'k a low (h Ϫ1 )' routed out of structural estimates ('Interindividual')</li><li>dropped duplicate Q49 ('k a low (h Ϫ1 )', value '0.4') — already have one for this compound</li><li>dropped unlinked row (NIL): 'Proportion of regular absorbers' — extend the ontology if this is a real PK parameter (source ['tab_1:row11:col1'])</li><li>implicit units: 'BW (liters • h Ϫ1 • kg Ϫ1 ) b' → L/h/kg (from the paper text: 'Abstract states clearance was 13.4 liters/h; BW is the regression coefficient for the influence of body weight on ATV cl')</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=atazanavir</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Atazanavir_Goutelle2013_reference;
