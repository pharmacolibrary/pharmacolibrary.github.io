model Etomidate_Van1978_reference
  parameter Real Cl_ref = 1.4333333333333332e-05 "Cl [m3/s]";
  parameter Real Vd_ref = 0.0232 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.24428899999999998,
    adminMass = 0.0001,
    ka = 0.0001388888888888889,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About etomidate</h4><p>Etomidate is an intravenous general anesthetic and sedative-hypnotic, used to induce anesthesia and studied for conditions such as status epilepticus and brain ischemia. It is an approved medicine, used mainly in hospital settings for anesthesia induction.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q418445\">Wikidata Q418445</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>etomidate</td></tr><tr><td>population:</td><td>patients</td></tr><tr><td>source_paper:</td><td>Van_1978</td></tr><tr><td>measured_compound:</td><td>etomidate</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_2C_enteral: apparent (/F) parameterization ⇒ extravascular dosing</td></tr><tr><td>molar_masses:</td><td>etomidate 244.289 g/mol (drugbank)</td></tr></table><p><b>Defaulted (base-class default used):</b> ka, Tlag, k12, k21.</p><h4>Interpretation flags</h4><ul><li>dropped unlinked row (NIL): 'fraction of drug in the central compartment' — extend the ontology if this is a real PK parameter (source ['Van_1978:abstract'])</li><li>apparent-ness (ontology-grounded): parameterization=apparent, measured_compound=etomidate</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Etomidate_Van1978_reference;
