function p = Etomidate_Shen2016_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: etomidate   source: Shen_2016 / reference   route: iv_bolus
  % estimated (absent from source): F, dose
  p.name  = 'Etomidate_Shen2016_reference_params';
  p.drug  = 'etomidate';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'iv_bolus';        % 'oral' | 'iv_bolus'
  p.depot = false;             % oral -> first-order absorption depot
  p.Vc = 8.05;                % central volume [L]
  p.CL = 100.2;                % clearance [L/h]
  p.Vp = [13.7];             % peripheral volumes [L]
  p.Q  = [201.0];             % inter-compartmental clearances [L/h]
  p.ka = 0.0;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 10.0;             % dose [mg]
end
