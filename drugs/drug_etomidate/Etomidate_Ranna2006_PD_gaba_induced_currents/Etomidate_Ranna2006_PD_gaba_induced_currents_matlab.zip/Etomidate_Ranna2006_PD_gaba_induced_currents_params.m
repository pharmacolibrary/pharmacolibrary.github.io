function p = Etomidate_Ranna2006_PD_gaba_induced_currents_params()
% Etomidate_Ranna2006_PD_gaba_induced_currents_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% etomidate Ranna_2006::GABA_induced_currents: sigmoid_emax exposure-response sweep (response = E0 + Emax*frac). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one μM per second, in SI inside (kg/m3, s). Response GABA-induced currents in % of control GABA response. Driver: etomidate (cited_pk).
p.E0 = 0.0;
p.Emax = 222.0;
p.EC50 = 50.0;
p.gamma = 1.0;
p.slope = 0.0;
p.exposure_per_s = 1.0;
p.stop_time = 500.0;
p.form = 'E0 + Emax*frac';
end
