model Etomidate_Ranna2006_PD_gaba_induced_currents
  "sigmoid_emax exposure-response sweep — Ranna_2006 :: GABA-induced currents (GABA-induced currents)"
  extends Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep(
    E0 = 0,      // [1]
    Emax = 222,  // [% of the control GABA response]
    EC50 = 50,  // [μM]
    gamma = 1,
    exposure_per_s = 1);   // 1 μM per second
  // exposure_unit_unresolved: 'μM' — the x axis is in the paper's unit, not SI
  // defaulted: E0
  // defaulted: gamma
  annotation(experiment(StartTime = 0, StopTime = 500, Interval = 1),
    Documentation(info = "<html><body><!-- drug-about --><h4>About etomidate</h4><p>Etomidate is an intravenous general anesthetic and sedative-hypnotic, used to induce anesthesia and studied for conditions such as status epilepticus and brain ischemia. It is an approved medicine, used mainly in hospital settings for anesthesia induction.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q418445\">Wikidata Q418445</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h4>Etomidate_Ranna2006_PD_gaba_induced_currents</h4><p>The steady-state exposure-response curve of Ranna M et al., <i>BMC pharmacology 6:1</i> 2006 (<a href=\"https://doi.org/10.1186/1471-2210-6-1\">doi:10.1186/1471-2210-6-1</a>) — GABA-induced currents [% of control GABA response] against etomidate μM — obtained by sweeping the driver instead of simulating a dose. Model family: sigmoid_emax.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = (library default) drug-free response (baseline)
  Emax  =        222 % of the control GABA response maximal effect term (maximal potentiation, Q320)
  EC50  =         50 μM       exposure at half of the maximal effect term (EC50, Q321)
  gamma = (library default) Hill coefficient</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep\">SigmoidEmaxSweep</a>; this model only supplies the numbers. The x axis is one μM of etomidate per second of simulated time: there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0   (drug-free)
  exposure = EC50 (50 μM)  response 111
  exposure -> infinity  response 222</pre></body></html>"));
end Etomidate_Ranna2006_PD_gaba_induced_currents;
