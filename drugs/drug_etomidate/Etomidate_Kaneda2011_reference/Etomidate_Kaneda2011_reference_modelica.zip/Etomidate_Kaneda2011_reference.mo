model Etomidate_Kaneda2011_reference
  parameter Real Cl_ref = 1.0500000000000001e-05 "Cl [m3/s]";
  parameter Real Vd_ref = 0.00445 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.24428899999999998,
    adminMass = 1e-05,
    k12 = 0.011835205992509364,
    k21 = 0.0007031597685803292
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About etomidate</h4><p>Etomidate is an intravenous general anesthetic and sedative-hypnotic, used to induce anesthesia and studied for conditions such as status epilepticus and brain ischemia. It is an approved medicine, used mainly in hospital settings for anesthesia induction.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q418445\">Wikidata Q418445</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>etomidate</td></tr><tr><td>population:</td><td>healthy volunteers</td></tr><tr><td>source_paper:</td><td>Kaneda_2011</td></tr><tr><td>measured_compound:</td><td>etomidate</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_2C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>etomidate 244.289 g/mol (drugbank)</td></tr></table><h4>Interpretation flags</h4><ul><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=etomidate</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Etomidate_Kaneda2011_reference;
