model IsosorbideDinitrate_Jaruratanasirikul2020_reference
  parameter Real Cl_ref = 3.6666666666666666e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.0303 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.2361363,
    adminMass = 1e-05
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About isosorbide_dinitrate</h4><p>Isosorbide dinitrate is a nitrate vasodilator used for cardiac conditions such as angina, and also topically for haemorrhoids and anal fissures. It is an approved medicine and appears on the WHO list of essential medicines, so it remains in widespread clinical use.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q179748\">Wikidata Q179748</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>isosorbide_dinitrate</td></tr><tr><td>population:</td><td>review reference</td></tr><tr><td>source_paper:</td><td>Jaruratanasirikul_2020</td></tr><tr><td>measured_compound:</td><td>isosorbide_dinitrate</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>isosorbide_dinitrate 236.136 g/mol (drugbank)</td></tr></table><h4>Interpretation flags</h4><ul><li>built from REVIEW reference values (Jaruratanasirikul_2020) — secondary source</li><li>volume reported by review</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end IsosorbideDinitrate_Jaruratanasirikul2020_reference;
