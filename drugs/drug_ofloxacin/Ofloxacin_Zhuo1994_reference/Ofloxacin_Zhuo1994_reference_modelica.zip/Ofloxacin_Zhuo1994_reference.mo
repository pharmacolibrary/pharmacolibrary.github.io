model Ofloxacin_Zhuo1994_reference
  parameter Real Cl_ref = 3.6111111111111115e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.058 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 0.9,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.3613675,
    adminMass = 0.0004,
    ka = 0.0008194444444444445,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About ofloxacin</h4><p>Ofloxacin is a fluoroquinolone antibiotic used to treat bacterial infections such as urinary tract infections, gonorrhea, chlamydia, prostatitis, otitis, and eye infections. It is an approved medicine, appears on the WHO essential medicines list, and is used widely, both by mouth and as eye or ear drops.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q411447\">Wikidata Q411447</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>ofloxacin</td></tr><tr><td>population:</td><td>patients with respiratory tract infections</td></tr><tr><td>source_paper:</td><td>Zhuo_1994</td></tr><tr><td>measured_compound:</td><td>ofloxacin</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>ofloxacin 361.368 g/mol (drugbank)</td></tr></table><p><b>Defaulted (base-class default used):</b> F, Tlag.</p><h4>Interpretation flags</h4><ul><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=ofloxacin</li><li>structure disagreement: deterministic 1C vs LLM 2C — review compartment count</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li><li>gap-filled Q49 (kabs) from Al-Shaer_2019's review values (primary lacked it)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 115200, Tolerance = 1e-9, Interval = 1));
end Ofloxacin_Zhuo1994_reference;
