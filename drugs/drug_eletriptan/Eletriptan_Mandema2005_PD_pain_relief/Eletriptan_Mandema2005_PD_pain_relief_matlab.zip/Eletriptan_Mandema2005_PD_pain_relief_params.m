function p = Eletriptan_Mandema2005_PD_pain_relief_params()
% Eletriptan_Mandema2005_PD_pain_relief_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% eletriptan Mandema_2005::pain_relief: emax exposure-response sweep (response = E0 + Emax*frac). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one mg per second, in SI inside (kg/m3, s). Response pain relief in its own unit. Driver: eletriptan (dose_only).
p.E0 = -5.03;
p.Emax = 3.23;
p.EC50 = 1.55e-05;
p.gamma = 1.0;
p.slope = 0.0;
p.exposure_per_s = 1e-06;
p.stop_time = 160.0;
p.form = 'E0 + Emax*frac';
end
