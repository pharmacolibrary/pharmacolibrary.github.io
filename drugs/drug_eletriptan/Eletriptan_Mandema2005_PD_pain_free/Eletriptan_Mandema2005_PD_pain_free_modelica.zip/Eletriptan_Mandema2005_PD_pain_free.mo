model Eletriptan_Mandema2005_PD_pain_free
  "emax exposure-response sweep — Mandema_2005 :: pain free (pain free)"
  extends Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep(
    E0 = -9.22,      // [1]
    Emax = 3.09,  // [1]
    EC50 = 2.09e-05,  // [kg; mg × 1e-06]
    gamma = 1,
    exposure_per_s = 1e-06);   // 1 mg per second
  // defaulted: gamma
  annotation(experiment(StartTime = 0, StopTime = 210, Interval = 0.42),
    Documentation(info = "<html><body><h4>Eletriptan_Mandema2005_PD_pain_free</h4><p>The steady-state exposure-response curve of Mandema JW et al., <i>Cephalalgia : an international journal of headache 25(9):715–725</i> 2005 (<a href=\"https://doi.org/10.1111/j.1468-2982.2004.00939.x\">doi:10.1111/j.1468-2982.2004.00939.x</a>) — pain free against eletriptan mg — obtained by sweeping the driver instead of simulating a dose. Model family: emax.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    =      -9.22          drug-free response (baseline) (PL 0, Q324)
  Emax  =       3.09          maximal effect term (E max,eletriptan, Q320)
  EC50  =       20.9 mg       exposure at half of the maximal effect term (ED 50,eletriptan, Q321)
  gamma = (library default) Hill coefficient</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep\">SigmoidEmaxSweep</a>; this model only supplies the numbers. The x axis is one mg of eletriptan per second of simulated time (exposure is in kg): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response -9.22   (drug-free)
  exposure = EC50 (20.9 mg)  response -7.675
  exposure -> infinity  response -6.13</pre></body></html>"));
end Eletriptan_Mandema2005_PD_pain_free;
