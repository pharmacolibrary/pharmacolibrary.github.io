function p = Eletriptan_Mandema2005_PD_pain_free_params()
% Eletriptan_Mandema2005_PD_pain_free_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% eletriptan Mandema_2005::pain_free: emax exposure-response sweep (response = E0 + Emax*frac). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one mg per second, in SI inside (kg/m3, s). Response pain free in its own unit. Driver: eletriptan (dose_only).
p.E0 = -9.22;
p.Emax = 3.09;
p.EC50 = 2.0899999999999996e-05;
p.gamma = 1.0;
p.slope = 0.0;
p.exposure_per_s = 1e-06;
p.stop_time = 210.0;
p.form = 'E0 + Emax*frac';
end
