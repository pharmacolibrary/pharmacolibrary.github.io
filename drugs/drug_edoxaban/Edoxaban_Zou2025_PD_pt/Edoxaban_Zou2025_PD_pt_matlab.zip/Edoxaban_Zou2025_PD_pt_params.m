function p = Edoxaban_Zou2025_PD_pt_params()
% Edoxaban_Zou2025_PD_pt_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% edoxaban Zou_2025::PT: linear exposure-response sweep (response = E0 + slope*exposure). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one ng/mL per second, in SI inside (kg/m3, s). Response PT in s. Driver: edoxaban (pk_record).
p.E0 = 0.0;
p.Emax = 0.0;
p.EC50 = 1.0;
p.gamma = 1.0;
p.slope = 0.0415;
p.exposure_per_s = 1e-06;
p.stop_time = 1000.0;
p.form = 'E0 + slope*exposure';
end
