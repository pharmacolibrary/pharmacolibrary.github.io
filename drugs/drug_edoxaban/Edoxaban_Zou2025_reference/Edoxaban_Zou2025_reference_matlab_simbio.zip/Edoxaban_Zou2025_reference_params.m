function p = Edoxaban_Zou2025_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: edoxaban   source: Zou_2025 / reference   route: oral
  p.name  = 'Edoxaban_Zou2025_reference_params';
  p.drug  = 'edoxaban';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 261.0;                % central volume [L]
  p.CL = 42.87;                % clearance [L/h]
  p.Vp = [343.5];             % peripheral volumes [L]
  p.Q  = [8.59];             % inter-compartmental clearances [L/h]
  p.ka = 3.71;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 30.0;             % dose [mg]
end
