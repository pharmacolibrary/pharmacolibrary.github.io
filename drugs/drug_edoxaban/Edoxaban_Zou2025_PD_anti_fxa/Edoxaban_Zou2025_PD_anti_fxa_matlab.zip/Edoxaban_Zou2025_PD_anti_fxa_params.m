function p = Edoxaban_Zou2025_PD_anti_fxa_params()
% Edoxaban_Zou2025_PD_anti_fxa_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% edoxaban Zou_2025::anti_FXa: emax exposure-response sweep (response = E0 + Emax*frac). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one ng/mL per second, in SI inside (kg/m3, s). Response anti-FXa in IU/mL. Driver: edoxaban (pk_record).
p.E0 = 0.1;
p.Emax = 8.65;
p.EC50 = 0.0006309999999999999;
p.gamma = 1.0;
p.slope = 0.0;
p.exposure_per_s = 1e-06;
p.stop_time = 6400.0;
p.form = 'E0 + Emax*frac';
end
