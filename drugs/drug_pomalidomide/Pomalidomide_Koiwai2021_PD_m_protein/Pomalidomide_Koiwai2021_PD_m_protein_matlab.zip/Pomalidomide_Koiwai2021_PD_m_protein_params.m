function p = Pomalidomide_Koiwai2021_PD_m_protein_params()
% Pomalidomide_Koiwai2021_PD_m_protein_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% pomalidomide Koiwai_2021::M_protein: linear exposure-response sweep (response = E0 + slope*exposure). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one mol per second, in SI inside (kg/m3, s). Response M-protein in g/L. Driver: pomalidomide (cited_pk).
p.E0 = 21.399999999999995;
p.Emax = 0.0;
p.EC50 = 1.0;
p.gamma = 1.0;
p.slope = 34.6;
p.exposure_per_s = 1.0;
p.stop_time = 1000.0;
p.form = 'E0 + slope*exposure';
end
