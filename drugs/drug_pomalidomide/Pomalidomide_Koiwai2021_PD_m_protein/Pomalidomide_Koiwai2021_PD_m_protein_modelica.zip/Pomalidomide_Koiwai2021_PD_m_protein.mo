model Pomalidomide_Koiwai2021_PD_m_protein
  "linear exposure-response sweep — Koiwai_2021 :: M-protein (serum M-protein)"
  extends Pharmacolibrary.Interfaces.PartialExposureResponseSweep(
    E0 = 21.4,      // [kg/m3; g/L × 1]
    Emax = 0, EC50 = 1,      // unused by a line
    exposure_per_s = 1);
  parameter Real slope = 34.6   "[1]";
equation
  response = E0 + slope*exposure;
  // family_inferred: the record's model family is disease_progression; read from the parameters: a slope and no Emax — linear
  annotation(experiment(StartTime = 0, StopTime = 1000, Interval = 2),
    Documentation(info = "<html><body><!-- drug-about --><h4>About pomalidomide</h4><p>Pomalidomide is an immunomodulating and anti-angiogenic medicine used to treat multiple myeloma, and has also been studied for conditions such as amyloidosis, myelofibrosis, and plasma cell leukemia. It is approved and authorised in the European Union, where several pomalidomide products are on the market.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q7227206\">Wikidata Q7227206</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h4>Pomalidomide_Koiwai2021_PD_m_protein</h4><p>The steady-state exposure-response curve of Koiwai K et al., <i>CPT: pharmacometrics &amp; systems pharmacology 10(8):928–940</i> 2021 (<a href=\"https://doi.org/10.1002/psp4.12666\">doi:10.1002/psp4.12666</a>) — serum M-protein [g/L] against pomalidomide mol — obtained by sweeping the driver instead of simulating a dose. Model family: linear.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    =       21.4 g/L      drug-free response (baseline) (M0, Q324)
  slope =       34.6          change in response per unit of exposure (K, Q335)</pre><p>The algebra is <code>response = E0 + slope*exposure</code>; this model only supplies the numbers. The x axis is one mol of pomalidomide per second of simulated time: there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 21.4   (drug-free)</pre></body></html>"));
end Pomalidomide_Koiwai2021_PD_m_protein;
