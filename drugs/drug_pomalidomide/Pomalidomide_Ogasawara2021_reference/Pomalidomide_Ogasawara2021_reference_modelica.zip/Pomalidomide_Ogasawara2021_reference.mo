model Pomalidomide_Ogasawara2021_reference
  parameter Real Cl_ref = 1.0888888888888889e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.0427 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.2732441,
    adminMass = 3e-06,
    ka = 0.00021083333333333333,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About pomalidomide</h4><p>Pomalidomide is an immunomodulating and anti-angiogenic medicine used to treat multiple myeloma, and has also been studied for conditions such as amyloidosis, myelofibrosis, and plasma cell leukemia. It is approved and authorised in the European Union, where several pomalidomide products are on the market.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q7227206\">Wikidata Q7227206</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>pomalidomide</td></tr><tr><td>population:</td><td>pediatric patients with recurrent or progressive primary brain tumors</td></tr><tr><td>source_paper:</td><td>Ogasawara_2021</td></tr><tr><td>measured_compound:</td><td>pomalidomide</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>tab_1</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>pomalidomide 273.244 g/mol (drugbank)</td></tr></table><p><b>Defaulted (base-class default used):</b> Tlag.</p><h4>Interpretation flags</h4><ul><li>table section iiv: 'Std. dev. of η' routed out of structural estimates ('Interindividual variability d')</li><li>table section iiv: 'Std. dev. of η' routed out of structural estimates ('Interindividual variability d')</li><li>table section residual_error: 'Ln additive' routed out of structural estimates ('Residual variability')</li><li>table section residual_error: 'Ln additive' routed out of structural estimates ('Residual variability')</li><li>dropped value-less row: 'BSA on CL/F b 1.04'</li><li>dropped duplicate Q76 ('BSA on V/F c 1.54', value '1.16') — already have one for this compound</li><li>dropped unlinked row (NIL): 'Std. dev. of' — extend the ontology if this is a real PK parameter (source ['tab_1:row14:col1', 'tab_1:row14:col3', 'tab_1:row14:col4'])</li><li>NIL: refused to back-fill base 'CL/F' from footnote/prose loose number 3.94 (source ['tab_1:footnote']); the table cell was unparseable — needs review</li><li>NIL: refused to back-fill base 'V/F' from footnote/prose loose number 43.0 (source ['tab_1:footnote']); the table cell was unparseable — needs review</li><li>apparent-ness (ontology-grounded): parameterization=apparent, measured_compound=pomalidomide</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of TLAG: primary's parameterization (rate-constant / ka-only) does not use it</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 151200, Tolerance = 1e-9, Interval = 1));
end Pomalidomide_Ogasawara2021_reference;
