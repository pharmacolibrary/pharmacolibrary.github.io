model Pomalidomide_Papathanasiou2025_reference
  parameter Real Cl_ref = 1.0717592592592594e-08 "Cl [m3/s]";
  parameter Real Vd_ref = 0.0123 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.2732441,
    adminMass = 1e-05
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About pomalidomide</h4><p>Pomalidomide is an immunomodulating and anti-angiogenic medicine used to treat multiple myeloma, and has also been studied for conditions such as amyloidosis, myelofibrosis, and plasma cell leukemia. It is approved and authorised in the European Union, where several pomalidomide products are on the market.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q7227206\">Wikidata Q7227206</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>pomalidomide</td></tr><tr><td>population:</td><td>review reference</td></tr><tr><td>source_paper:</td><td>Papathanasiou_2025</td></tr><tr><td>measured_compound:</td><td>pomalidomide</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>pomalidomide 273.244 g/mol (drugbank)</td></tr></table><h4>Interpretation flags</h4><ul><li>built from REVIEW reference values (Papathanasiou_2025) — secondary source</li><li>volume reported by review</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 4233600, Tolerance = 1e-9, Interval = 1));
end Pomalidomide_Papathanasiou2025_reference;
