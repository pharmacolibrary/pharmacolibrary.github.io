model Furosemide_Tilstone1978_reference
  parameter Real Cl_ref = 1.785e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.00261 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C_enteral(
    weight = 70.0,
    F = 43.4,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.33074400000000004,
    adminMass = 4e-05,
    ka = 0.0012527777777777778,
    Tlag = 0.0,
    k12 = 6.704980842911879e-05,
    k21 = 7.056451612903226e-05
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About furosemide</h4><p>Furosemide is a loop diuretic used to treat fluid build-up caused by heart failure, liver cirrhosis, or kidney disease, and is also used for high blood pressure. It is widely used in human medicine, appears on the WHO essential medicines list, and is also approved for veterinary use.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q388801\">Wikidata Q388801</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>furosemide</td></tr><tr><td>population:</td><td>normal volunteers and patients with renal failure</td></tr><tr><td>source_paper:</td><td>Tilstone_1978</td></tr><tr><td>measured_compound:</td><td>furosemide</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_2C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>furosemide 330.744 g/mol (drugbank)</td></tr></table><p><b>Defaulted (base-class default used):</b> Tlag.</p><h4>Interpretation flags</h4><ul><li>dropped unlinked row (NIL): 'absorbed' — extend the ontology if this is a real PK parameter (source ['Tilstone_1978:abstract'])</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=furosemide</li><li>held at status:extracted — NIL link or unit issue (mismatch/unknown/normalisation-failed) present</li><li>status held at route_to_review — not promoted</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li><li>gap-filled Q30 (Q) from Ravix_2025's review values (primary lacked it)</li><li>gap-filled Q49 (kabs) from Miura_2026's review values (primary lacked it)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Furosemide_Tilstone1978_reference;
