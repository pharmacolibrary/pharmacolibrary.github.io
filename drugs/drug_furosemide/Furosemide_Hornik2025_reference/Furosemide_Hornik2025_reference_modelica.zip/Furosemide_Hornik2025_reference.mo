model Furosemide_Hornik2025_reference
  parameter Real Cl_ref = 1.8083333333333333e-06 "Cl [m3/s]";
  parameter Real cov_egfr_0 = 0 "egfr covariate";
  parameter Real Vd_ref = 0.005370000000000001 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C_enteral(
    weight = 70.0,
    F = 0.9,
    Cl = Cl_ref*(1 + (0.74)*cov_egfr_0),
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.33074400000000004,
    adminMass = 4e-05,
    ka = 0.00036111111111111115,
    Tlag = 0.0,
    k12 = 0.0001934616180426236,
    k21 = 0.0001746031746031746
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About furosemide</h4><p>Furosemide is a loop diuretic used to treat fluid build-up caused by heart failure, liver cirrhosis, or kidney disease, and is also used for high blood pressure. It is widely used in human medicine, appears on the WHO essential medicines list, and is also approved for veterinary use.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q388801\">Wikidata Q388801</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>furosemide</td></tr><tr><td>population:</td><td>adults with heart failure</td></tr><tr><td>source_paper:</td><td>Hornik_2025</td></tr><tr><td>measured_compound:</td><td>furosemide</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>Tab1</td></tr><tr><td>input:</td><td>PK_2C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>furosemide 330.744 g/mol (drugbank)</td></tr></table><p><b>Defaulted (base-class default used):</b> F, Tlag.</p><h4>Interpretation flags</h4><ul><li>table section iiv: 'Ka' routed out of structural estimates ('Inter-individual variability, CV% (shrinkage)')</li><li>table section iiv: 'Ka' routed out of structural estimates ('Inter-individual variability, CV% (shrinkage)')</li><li>table section iiv: 'CL' routed out of structural estimates ('Inter-individual variability, CV% (shrinkage)')</li><li>table section iiv: 'CL' routed out of structural estimates ('Inter-individual variability, CV% (shrinkage)')</li><li>table section iiv: 'Vc' routed out of structural estimates ('Inter-individual variability, CV% (shrinkage)')</li><li>table section iiv: 'Vc' routed out of structural estimates ('Inter-individual variability, CV% (shrinkage)')</li><li>table section iiv: 'Q' routed out of structural estimates ('Inter-individual variability, CV% (shrinkage)')</li><li>table section iiv: 'Q' routed out of structural estimates ('Inter-individual variability, CV% (shrinkage)')</li><li>table section iiv: 'Vp' routed out of structural estimates ('Inter-individual variability, CV% (shrinkage)')</li><li>table section iiv: 'Vp' routed out of structural estimates ('Inter-individual variability, CV% (shrinkage)')</li><li>table section residual_error: 'Proportional error, %' routed out of structural estimates ('Residual error')</li><li>table section residual_error: 'Proportional error, %' routed out of structural estimates ('Residual error')</li><li>table section residual_error: 'Additive error, ng/mL' routed out of structural estimates ('Residual error')</li><li>table section residual_error: 'Additive error, ng/mL' routed out of structural estimates ('Residual error')</li><li>covariate level 'eGFR on CL' → Q900:egfr_on_cl = 0.74 (linear_fractional on Q22)</li><li>apparent-by-design (ADVISORY, codes unchanged): extravascular dosing with no identifiable F, so these reported disposition parameters are likely apparent unless the model puts first-pass in its structure — Q22 (CL, L/h); Q63 (Vc, L); Q30 (Q, L/h); Q64 (Vp, L)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Furosemide_Hornik2025_reference;
