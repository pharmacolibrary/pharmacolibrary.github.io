function p = Furosemide_Hornik2025_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: furosemide   source: Hornik_2025 / reference   route: oral
  % estimated (absent from source): F
  p.name  = 'Furosemide_Hornik2025_reference_params';
  p.drug  = 'furosemide';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 5.37;                % central volume [L]
  p.CL = 6.51;                % clearance [L/h]
  p.Vp = [5.95];             % peripheral volumes [L]
  p.Q  = [3.74];             % inter-compartmental clearances [L/h]
  p.ka = 1.3;                % absorption rate [1/h]
  p.F  = 0.9;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 40.0;             % dose [mg]
end
