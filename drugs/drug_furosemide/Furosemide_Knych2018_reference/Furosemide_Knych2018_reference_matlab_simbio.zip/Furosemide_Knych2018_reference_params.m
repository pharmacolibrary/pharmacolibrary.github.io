function p = Furosemide_Knych2018_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: furosemide   source: Knych_2018 / reference   route: oral
  % estimated (absent from source): F
  p.name  = 'Furosemide_Knych2018_reference_params';
  p.drug  = 'furosemide';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 350.0;                % central volume [L]
  p.CL = 37.87;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 4.51;                % absorption rate [1/h]
  p.F  = 0.9;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 40.0;             % dose [mg]
end
