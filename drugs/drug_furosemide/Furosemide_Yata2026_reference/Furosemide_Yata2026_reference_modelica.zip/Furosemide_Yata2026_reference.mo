model Furosemide_Yata2026_reference
  parameter Real Cl_ref = 1.886111111111111e-05 "Cl [m3/s]";
  parameter Real Vd_ref = 0.2821 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.33074400000000004,
    adminMass = 4e-05,
    ka = 0.0001722222222222222,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About furosemide</h4><p>Furosemide is a loop diuretic used to treat fluid build-up caused by heart failure, liver cirrhosis, or kidney disease, and is also used for high blood pressure. It is widely used in human medicine, appears on the WHO essential medicines list, and is also approved for veterinary use.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q388801\">Wikidata Q388801</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>furosemide</td></tr><tr><td>population:</td><td>review reference</td></tr><tr><td>source_paper:</td><td>Yata_2026</td></tr><tr><td>measured_compound:</td><td>furosemide</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>furosemide 330.744 g/mol (drugbank)</td></tr></table><p><b>Defaulted (base-class default used):</b> Tlag.</p><h4>Interpretation flags</h4><ul><li>built from REVIEW reference values (Yata_2026) — secondary source</li><li>volume reported by review</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Furosemide_Yata2026_reference;
