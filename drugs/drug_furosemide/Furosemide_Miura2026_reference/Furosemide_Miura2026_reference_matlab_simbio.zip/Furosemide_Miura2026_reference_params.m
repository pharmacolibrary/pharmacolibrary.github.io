function p = Furosemide_Miura2026_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: furosemide   source: Miura_2026 / reference   route: oral
  p.name  = 'Furosemide_Miura2026_reference_params';
  p.drug  = 'furosemide';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 322.0;                % central volume [L]
  p.CL = 60.6;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 4.51;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 40.0;             % dose [mg]
end
