function p = Furosemide_Ravix2025_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: furosemide   source: Ravix_2025 / reference   route: iv_bolus
  % estimated (absent from source): F
  p.name  = 'Furosemide_Ravix2025_reference_params';
  p.drug  = 'furosemide';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'iv_bolus';        % 'oral' | 'iv_bolus'
  p.depot = false;             % oral -> first-order absorption depot
  p.Vc = 8.4;                % central volume [L]
  p.CL = 9.3;                % clearance [L/h]
  p.Vp = [2.0];             % peripheral volumes [L]
  p.Q  = [0.63];             % inter-compartmental clearances [L/h]
  p.ka = 0.0;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 40.0;             % dose [mg]
end
