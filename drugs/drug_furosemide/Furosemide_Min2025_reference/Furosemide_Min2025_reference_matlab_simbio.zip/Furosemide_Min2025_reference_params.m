function p = Furosemide_Min2025_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: furosemide   source: Min_2025 / reference   route: oral
  % estimated (absent from source): ka
  p.name  = 'Furosemide_Min2025_reference_params';
  p.drug  = 'furosemide';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 28.3;                % central volume [L]
  p.CL = 9.1;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.5;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 40.0;             % dose [mg]
end
