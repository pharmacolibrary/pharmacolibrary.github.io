model Escitalopram_Friberg2006_PD_qtci
  "emax exposure-response sweep — Friberg_2006 :: QTci (Heart-rate corrected QT interval)"
  extends Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep(
    E0 = 0.429,      // [s; ms × 0.001]
    Emax = 0.02,  // [s; ms × 0.001]
    EC50 = 0.2,  // [mg/l -1]
    gamma = 1,
    exposure_per_s = 1);   // 1 mg/l -1 per second
  // family_inferred: the record's model family is effect_compartment; read from the parameters: Emax/Imax and EC50/IC50 without a Hill coefficient — Emax
  // exposure_unit_unresolved: 'mg/l -1' — the x axis is in the paper's unit, not SI
  // defaulted: gamma
  annotation(experiment(StartTime = 0, StopTime = 2, Interval = 0.004),
    Documentation(info = "<html><body><!-- drug-about --><h4>About escitalopram</h4><p>Escitalopram is an antidepressant of the SSRI class used for depression and anxiety-related conditions such as generalized anxiety disorder, obsessive-compulsive disorder, and post-traumatic stress disorder. It is an approved medicine, widely used in clinical practice, and carries a boxed warning.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q423757\">Wikidata Q423757</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h4>Escitalopram_Friberg2006_PD_qtci</h4><p>The steady-state exposure-response curve of Friberg LE et al., <i>British journal of clinical pharmacology 61(2):177–190</i> 2006 (<a href=\"https://doi.org/10.1111/j.1365-2125.2005.02546.x\">doi:10.1111/j.1365-2125.2005.02546.x</a>) — Heart-rate corrected QT interval [ms] against citalopram mg/l -1 — obtained by sweeping the driver instead of simulating a dose. Model family: emax.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    =        429 ms       drug-free response (baseline) (QTci0, women, Q324)
  Emax  =         20 ms       maximal effect term (E max (ms), Q320)
  EC50  =        0.2 mg/l -1  exposure at half of the maximal effect term (Ec 50 (mg/l -1 ), Q321)
  gamma = (library default) Hill coefficient</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep\">SigmoidEmaxSweep</a>; this model only supplies the numbers. The x axis is one mg/l -1 of citalopram per second of simulated time: there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0.429   (drug-free)
  exposure = EC50 (0.2 mg/l -1)  response 0.439
  exposure -> infinity  response 0.449</pre></body></html>"));
end Escitalopram_Friberg2006_PD_qtci;
