function p = Escitalopram_Friberg2006_PD_qtci_params()
% Escitalopram_Friberg2006_PD_qtci_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% escitalopram Friberg_2006::QTci: emax exposure-response sweep (response = E0 + Emax*frac). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one mg/l -1 per second, in SI inside (kg/m3, s). Response QTci in ms. Driver: citalopram (pk_record).
p.E0 = 0.429;
p.Emax = 0.02;
p.EC50 = 0.2;
p.gamma = 1.0;
p.slope = 0.0;
p.exposure_per_s = 1.0;
p.stop_time = 2.0;
p.form = 'E0 + Emax*frac';
end
