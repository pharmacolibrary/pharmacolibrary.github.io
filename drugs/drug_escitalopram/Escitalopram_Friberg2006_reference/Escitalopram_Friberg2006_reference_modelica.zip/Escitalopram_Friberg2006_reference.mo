model Escitalopram_Friberg2006_reference
  parameter Real Cl_ref = 6.138888888888889e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 1.28 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    adminMass = 8e-05,
    ka = 0.0004111111111111111,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About escitalopram</h4><p>Escitalopram is an antidepressant of the SSRI class used for depression and anxiety-related conditions such as generalized anxiety disorder, obsessive-compulsive disorder, and post-traumatic stress disorder. It is an approved medicine, widely used in clinical practice, and carries a boxed warning.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q423757\">Wikidata Q423757</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>escitalopram</td></tr><tr><td>population:</td><td>patients with citalopram overdose</td></tr><tr><td>source_paper:</td><td>Friberg_2006</td></tr><tr><td>measured_compound:</td><td>citalopram</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>Table 3</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>escitalopram 324.392 g/mol (drugbank)</td></tr></table><p><b>Defaulted (base-class default used):</b> Tlag.</p><h4>Interpretation flags</h4><ul><li>salvaged Q22 ('apparent (oral) clearance'=22.1) from results prose — parameter table was unreadable</li><li>salvaged Q76 ('apparent volume of distribution'=1280) from results prose — parameter table was unreadable</li><li>salvaged Q49 ('absorption rate constant'=1.48) from results prose — parameter table was unreadable</li><li>apparent-ness (ontology-grounded): parameterization=apparent, measured_compound=citalopram</li><li>held at status:extracted — NIL link or unit issue (mismatch/unknown/normalisation-failed) present</li><li>status held at route_to_review — not promoted</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 777600, Tolerance = 1e-9, Interval = 1));
end Escitalopram_Friberg2006_reference;
