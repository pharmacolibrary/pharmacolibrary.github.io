model Escitalopram_Poweleit2023_reference
  parameter Real Cl_ref = 3.944444444444444e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.428 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.3243919,
    adminMass = 1e-05,
    ka = 0.0004111111111111111,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About escitalopram</h4><p>Escitalopram is an antidepressant of the SSRI class used for depression and anxiety-related conditions such as generalized anxiety disorder, obsessive-compulsive disorder, and post-traumatic stress disorder. It is an approved medicine, widely used in clinical practice, and carries a boxed warning.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q423757\">Wikidata Q423757</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>escitalopram</td></tr><tr><td>population:</td><td>psychiatrically hospitalized pediatric patients aged 5-18 years</td></tr><tr><td>source_paper:</td><td>Poweleit_2023</td></tr><tr><td>measured_compound:</td><td>escitalopram</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>escitalopram 324.392 g/mol (drugbank)</td></tr></table><p><b>Defaulted (base-class default used):</b> Tlag.</p><h4>Interpretation flags</h4><ul><li>unit_dimension_unknown: 'L/h/1.73 m2' (CL/F)</li><li>unit_dimension_unknown: 'L/1.73 m2' (V/F)</li><li>dropped duplicate Q27 ('CL/F (sertraline)', value 124) — already have one for this compound</li><li>dropped duplicate Q76 ('V/F (sertraline)', value 4320) — already have one for this compound</li><li>covariate cyp2c19 for Ctrough from footnote/prose kept as documentation only (['Poweleit_2023:abstract'])</li><li>covariate normal metabolizer for Ctrough from footnote/prose kept as documentation only (['Poweleit_2023:abstract'])</li><li>covariate normal metabolizer for AUC ratio from footnote/prose kept as documentation only (['Poweleit_2023:abstract'])</li><li>dropped value-less row: 'p (escitalopram)' (captured trailing unit 'escitalopram' for child rows)</li><li>covariate cyp2c19 for Ctrough from footnote/prose kept as documentation only (['Poweleit_2023:abstract'])</li><li>covariate ultrarapid metabolizer for Ctrough from footnote/prose kept as documentation only (['Poweleit_2023:abstract'])</li><li>covariate ultrarapid metabolizer for AUC ratio from footnote/prose kept as documentation only (['Poweleit_2023:abstract'])</li><li>dropped value-less row: 'p (sertraline)' (captured trailing unit 'sertraline' for child rows)</li><li>dropped unlinked row (NIL): 'escitalopram cohort samples' — extend the ontology if this is a real PK parameter (source ['Poweleit_2023:abstract'])</li><li>dropped unlinked row (NIL): 'escitalopram cohort patients' — extend the ontology if this is a real PK parameter (source ['Poweleit_2023:abstract'])</li><li>dropped unlinked row (NIL): 'sertraline cohort samples' — extend the ontology if this is a real PK parameter (source ['Poweleit_2023:abstract'])</li><li>dropped unlinked row (NIL): 'sertraline cohort patients' — extend the ontology if this is a real PK parameter (source ['Poweleit_2023:abstract'])</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 432000, Tolerance = 1e-9, Interval = 1));
end Escitalopram_Poweleit2023_reference;
