function p = Buprenorphine_Juul2014_PD_meanamp_params()
% Buprenorphine_Juul2014_PD_meanamp_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% buprenorphine Juul_2014::MeanAmp: log_linear exposure-response sweep (response = E0 + slope*log(exposure)). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one SI per second, in SI inside (kg/m3, s). Response MeanAmp in its own unit. Driver: buprenorphine (cited_pk).
p.E0 = 18.2;
p.Emax = 0.0;
p.EC50 = 1.0;
p.gamma = 1.0;
p.slope = 98.1;
p.exposure_per_s = 1.0;
p.stop_time = 1000.0;
p.form = 'E0 + slope*log(exposure)';
end
