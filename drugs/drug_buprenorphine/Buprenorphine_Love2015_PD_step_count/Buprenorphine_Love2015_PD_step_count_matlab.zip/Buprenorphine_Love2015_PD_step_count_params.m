function p = Buprenorphine_Love2015_PD_step_count_params()
% Buprenorphine_Love2015_PD_step_count_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% buprenorphine Love_2015::Step_count: indirect_response_ii exposure-response sweep (response = E0/(1 - Emax*frac)). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one ng mL À1 per second, in SI inside (kg/m3, s). Response Step count in step hour À1. Driver: buprenorphine (cited_pk).
p.E0 = 56.3;
p.Emax = 1.0;
p.EC50 = 9e-07;
p.gamma = 1.3;
p.slope = 0.0;
p.exposure_per_s = 1e-06;
p.stop_time = 9.0;
p.form = 'E0/(1 - Emax*frac)';
end
