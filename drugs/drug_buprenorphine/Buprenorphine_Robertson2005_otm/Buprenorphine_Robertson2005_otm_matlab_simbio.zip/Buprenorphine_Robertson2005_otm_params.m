function p = Buprenorphine_Robertson2005_otm_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: buprenorphine   source: Robertson_2005 / otm   route: iv_bolus
  % estimated (absent from source): F
  p.name  = 'Buprenorphine_Robertson2005_otm_params';
  p.drug  = 'buprenorphine';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'iv_bolus';        % 'oral' | 'iv_bolus'
  p.depot = false;             % oral -> first-order absorption depot
  p.Vc = 336.7;                % central volume [L]
  p.CL = 39.06;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.0;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 1.2;             % dose [mg]
end
