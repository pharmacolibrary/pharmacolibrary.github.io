function p = Buprenorphine_Walsh2024_PD_desire_to_use_vas_params()
% Buprenorphine_Walsh2024_PD_desire_to_use_vas_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% buprenorphine Walsh_2024::desire_to_use_VAS: sigmoid_emax exposure-response sweep (response = E0 + Emax*frac). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one ng/mL per second, in SI inside (kg/m3, s). Response desire to use VAS in score. Driver: buprenorphine (cited_pk).
p.E0 = 45.3;
p.Emax = -1.0;
p.EC50 = 7.5e-08;
p.gamma = 1.0;
p.slope = 0.0;
p.exposure_per_s = 1e-06;
p.stop_time = 0.75;
p.form = 'E0 + Emax*frac';
end
