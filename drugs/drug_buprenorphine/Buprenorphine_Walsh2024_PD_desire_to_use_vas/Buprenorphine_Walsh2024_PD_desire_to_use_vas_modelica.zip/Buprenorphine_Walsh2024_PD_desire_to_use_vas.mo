model Buprenorphine_Walsh2024_PD_desire_to_use_vas
  "sigmoid_emax exposure-response sweep — Walsh_2024 :: desire to use VAS (desire to use VAS)"
  extends Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep(
    E0 = 45.3,      // [score]
    Emax = -1,  // [score]
    EC50 = 7.5e-08,  // [kg/m3; ng/mL × 1e-06]
    gamma = 1,
    exposure_per_s = 1e-06);   // 1 ng/mL per second
  // imax_as_negative_emax: Imax (Q323) enters SigmoidEmaxSweep as −Emax
  // defaulted: gamma
  annotation(experiment(StartTime = 0, StopTime = 0.75, Interval = 0.0015),
    Documentation(info = "<html><body><h4>Buprenorphine_Walsh2024_PD_desire_to_use_vas</h4><p>The steady-state exposure-response curve of Walsh SL et al., <i>Neuropsychopharmacology : official publication of the American College of Neuropsychopharmacology 49(6):1050–1057</i> 2024 (<a href=\"https://doi.org/10.1038/s41386-023-01793-z\">doi:10.1038/s41386-023-01793-z</a>) — desire to use VAS [score] against buprenorphine ng/mL — obtained by sweeping the driver instead of simulating a dose. Model family: sigmoid_emax.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    =       45.3 score    drug-free response (baseline) (Baseline — Value, Q324)
  Emax  =          1 score    maximal effect term (I max — Value, Q323)
  EC50  =      0.075 ng/mL    exposure at half of the maximal effect term (IC 50 — Value, Q322)
  gamma = (library default) Hill coefficient</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep\">SigmoidEmaxSweep</a>; this model only supplies the numbers. The x axis is one ng/mL of buprenorphine per second of simulated time (exposure is in kg/m3): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 45.3   (drug-free)
  exposure = EC50 (0.075 ng/mL)  response 44.8
  exposure -> infinity  response 44.3</pre></body></html>"));
end Buprenorphine_Walsh2024_PD_desire_to_use_vas;
