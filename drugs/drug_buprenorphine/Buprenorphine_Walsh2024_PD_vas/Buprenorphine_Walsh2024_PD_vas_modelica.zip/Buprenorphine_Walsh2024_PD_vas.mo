model Buprenorphine_Walsh2024_PD_vas
  "sigmoid_emax exposure-response sweep — Walsh_2024 :: VAS (drug liking E max VAS score)"
  extends Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep(
    E0 = 45.3,      // [VAS units]
    Emax = -1,  // [VAS units]
    EC50 = 7.5e-08,  // [kg/m3; ng/mL × 1e-06]
    gamma = 1,
    exposure_per_s = 1e-06);   // 1 ng/mL per second
  // imax_as_negative_emax: Imax (Q323) enters SigmoidEmaxSweep as −Emax
  // defaulted: gamma
  annotation(experiment(StartTime = 0, StopTime = 0.75, Interval = 0.0015),
    Documentation(info = "<html><body><!-- drug-about --><h4>About buprenorphine</h4><p>Buprenorphine is an opioid used to treat pain and opioid dependence, including heroin dependence. It is widely used and authorised in the European Union, mainly for opioid-related disorders, and is also approved for veterinary use.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q407721\">Wikidata Q407721</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h4>Buprenorphine_Walsh2024_PD_vas</h4><p>The steady-state exposure-response curve of Walsh SL et al., <i>Neuropsychopharmacology : official publication of the American College of Neuropsychopharmacology 49(6):1050–1057</i> 2024 (<a href=\"https://doi.org/10.1038/s41386-023-01793-z\">doi:10.1038/s41386-023-01793-z</a>) — drug liking E max VAS score [VAS units] against buprenorphine ng/mL — obtained by sweeping the driver instead of simulating a dose. Model family: sigmoid_emax.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    =       45.3 VAS units drug-free response (baseline) (Baseline, Q324)
  Emax  =          1 VAS units maximal effect term (I max, Q323)
  EC50  =      0.075 ng/mL    exposure at half of the maximal effect term (IC 50, Q322)
  gamma = (library default) Hill coefficient</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep\">SigmoidEmaxSweep</a>; this model only supplies the numbers. The x axis is one ng/mL of buprenorphine per second of simulated time (exposure is in kg/m3): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 45.3   (drug-free)
  exposure = EC50 (0.075 ng/mL)  response 44.8
  exposure -> infinity  response 44.3</pre></body></html>"));
end Buprenorphine_Walsh2024_PD_vas;
