model Buprenorphine_Juul2014_PD_peakamp
  "log_linear exposure-response sweep — Juul_2014 :: PeakAmp (PeakAmp)"
  extends Pharmacolibrary.Interfaces.PartialExposureResponseSweep(
    E0 = 18.2,      // [1]
    Emax = 0, EC50 = 1,      // unused by a line
    exposure_per_s = 1.0);
  parameter Real slope = 98.1   "[1]";
equation
  response = E0 + slope*log(exposure);
  annotation(experiment(StartTime = 0, StopTime = 1000, Interval = 2));
end Buprenorphine_Juul2014_PD_peakamp;
