model Buprenorphine_Walsh2024_PD_cows
  "sigmoid_emax exposure-response sweep — Walsh_2024 :: COWS (Clinical Opiate Withdrawal Scale score)"
  extends Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep(
    E0 = 45.3,      // [score]
    Emax = -1.0,  // [score]
    EC50 = 7.5e-08,  // [kg/m3; ng/mL × 1e-06]
    gamma = 1.0,
    exposure_per_s = 1e-06);   // 1 ng/mL per second
  // imax_as_negative_emax: Imax (Q323) enters SigmoidEmaxSweep as −Emax
  // defaulted: gamma
  annotation(experiment(StartTime = 0, StopTime = 0.75, Interval = 0.0015));
end Buprenorphine_Walsh2024_PD_cows;
