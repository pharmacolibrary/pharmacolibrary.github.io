model Buprenorphine_EudyByrne2021_PD_mother_nas_score
  "indirect_response_ii exposure-response sweep — Eudy-Byrne_2021 :: MOTHER NAS score (MOTHER neonatal abstinence syndrome (NAS) scores)"
  extends Pharmacolibrary.Interfaces.PartialExposureResponseSweep(
    E0 = 0,      // [1]
    Emax = 1,  // type II effect term
    EC50 = 9.42e-07,  // [kg/m3; ng/ml × 1e-06]
    gamma = 1,
    exposure_per_s = 1e-06);   // 1 ng/ml per second
equation
  response = E0/(1 - Emax*frac);   // steady state, indirect response type II
  // defaulted: E0
  // defaulted: Emax
  // defaulted: gamma
  annotation(experiment(StartTime = 0, StopTime = 9.5, Interval = 0.019),
    Documentation(info = "<html><body><!-- drug-about --><h4>About buprenorphine</h4><p>Buprenorphine is an opioid used to treat pain and opioid dependence, including heroin dependence. It is widely used and authorised in the European Union, mainly for opioid-related disorders, and is also approved for veterinary use.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q407721\">Wikidata Q407721</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h4>Buprenorphine_EudyByrne2021_PD_mother_nas_score</h4><p>The steady-state exposure-response curve of Eudy-Byrne R et al., <i>Clinical and translational science 14(6):2171–2183</i> 2021 (<a href=\"https://doi.org/10.1111/cts.13074\">doi:10.1111/cts.13074</a>) — MOTHER neonatal abstinence syndrome (NAS) scores against buprenorphine ng/ml — obtained by sweeping the driver instead of simulating a dose. Model family: indirect_response_ii.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = (library default) drug-free response (baseline)
  Emax  = (library default) maximal effect term
  EC50  =      0.942 ng/ml    exposure at half of the maximal effect term (EC50, Q321)
  gamma = (library default) Hill coefficient</pre><p>The algebra is <code>response = E0/(1 - Emax*frac)</code>; this model only supplies the numbers. The x axis is one ng/ml of buprenorphine per second of simulated time (exposure is in kg/m3): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0   (drug-free)
  exposure = EC50 (0.942 ng/ml)  response 0
  exposure -> infinity  response inf</pre></body></html>"));
end Buprenorphine_EudyByrne2021_PD_mother_nas_score;
