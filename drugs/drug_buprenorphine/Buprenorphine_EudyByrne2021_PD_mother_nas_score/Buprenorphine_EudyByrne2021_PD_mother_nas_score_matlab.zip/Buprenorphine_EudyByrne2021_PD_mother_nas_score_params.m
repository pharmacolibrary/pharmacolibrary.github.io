function p = Buprenorphine_EudyByrne2021_PD_mother_nas_score_params()
% Buprenorphine_EudyByrne2021_PD_mother_nas_score_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% buprenorphine Eudy-Byrne_2021::MOTHER_NAS_score: indirect_response_ii exposure-response sweep (response = E0/(1 - Emax*frac)). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one ng/ml per second, in SI inside (kg/m3, s). Response MOTHER NAS score in its own unit. Driver: buprenorphine (cited_pk).
p.E0 = 0.0;
p.Emax = 1.0;
p.EC50 = 9.419999999999999e-07;
p.gamma = 1.0;
p.slope = 0.0;
p.exposure_per_s = 1e-06;
p.stop_time = 9.5;
p.form = 'E0/(1 - Emax*frac)';
end
