model Buprenorphine_Juul2014_PD_peaklat
  "log_linear exposure-response sweep — Juul_2014 :: PeakLat (PeakLat)"
  extends Pharmacolibrary.Interfaces.PartialExposureResponseSweep(
    E0 = 18.2,      // [1]
    Emax = 0, EC50 = 1,      // unused by a line
    exposure_per_s = 1);
  parameter Real slope = 98.1   "[1]";
equation
  response = E0 + slope*log(exposure);
  annotation(experiment(StartTime = 0, StopTime = 1000, Interval = 2),
    Documentation(info = "<html><body><h4>Buprenorphine_Juul2014_PD_peaklat</h4><p>The steady-state exposure-response curve of Juul RV et al., <i>Basic &amp; clinical pharmacology &amp; toxicology 115(4):343–351</i> 2014 (<a href=\"https://doi.org/10.1111/bcpt.12217\">doi:10.1111/bcpt.12217</a>) — PeakLat against buprenorphine — obtained by sweeping the driver instead of simulating a dose. Model family: log_linear.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    =       18.2          drug-free response (baseline) (Baseline, Q324)
  slope =       98.1          change in response per unit of exposure (e proportional, Q335)</pre><p>The algebra is <code>response = E0 + slope*log(exposure)</code>; this model only supplies the numbers. The x axis is one  of buprenorphine per second of simulated time: there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p></body></html>"));
end Buprenorphine_Juul2014_PD_peaklat;
