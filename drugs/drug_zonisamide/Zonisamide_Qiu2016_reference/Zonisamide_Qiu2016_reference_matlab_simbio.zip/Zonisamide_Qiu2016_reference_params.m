function p = Zonisamide_Qiu2016_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: zonisamide   source: Qiu_2016 / reference   route: oral
  % estimated (absent from source): F
  p.name  = 'Zonisamide_Qiu2016_reference_params';
  p.drug  = 'zonisamide';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 34.5;                % central volume [L]
  p.CL = 23.25;                % clearance [L/h]
  p.Vp = [1429.0];             % peripheral volumes [L]
  p.Q  = [20.22];             % inter-compartmental clearances [L/h]
  p.ka = 0.026;                % absorption rate [1/h]
  p.F  = 0.9;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 200.0;             % dose [mg]
end
