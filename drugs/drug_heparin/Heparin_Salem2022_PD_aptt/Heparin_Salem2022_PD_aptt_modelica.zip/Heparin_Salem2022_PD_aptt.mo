model Heparin_Salem2022_PD_aptt
  "linear exposure-response sweep — Salem_2022 :: aPTT (activated partial thromboplastin time)"
  extends Pharmacolibrary.Interfaces.PartialExposureResponseSweep(
    E0 = 0,      // [1]
    Emax = 0, EC50 = 1,      // unused by a line
    exposure_per_s = 1);
  parameter Real slope = 150   "[seconds/(IU/mL)]";
equation
  response = E0 + slope*exposure;
  // defaulted: E0
  annotation(experiment(StartTime = 0, StopTime = 1000, Interval = 2),
    Documentation(info = "<html><body><!-- drug-about --><h4>About heparin</h4><p>Heparin is an anticoagulant (blood thinner) used to treat and prevent blood clots, including pulmonary embolism, and is also used in antiphospholipid syndrome. It is a widely used medicine and appears on the WHO list of essential medicines.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q190016\">Wikidata Q190016</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h4>Heparin_Salem2022_PD_aptt</h4><p>The steady-state exposure-response curve of Salem AM et al., <i>Journal of clinical pharmacology 62(6):733–746</i> 2022 (<a href=\"https://doi.org/10.1002/jcph.2007\">doi:10.1002/jcph.2007</a>) — activated partial thromboplastin time [seconds] against unfractionated heparin IU/mL — obtained by sweeping the driver instead of simulating a dose. Model family: linear.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = (library default) drug-free response (baseline)
  slope =        150 seconds/(IU/mL) change in response per unit of exposure (slope, Q335)</pre><p>The algebra is <code>response = E0 + slope*exposure</code>; this model only supplies the numbers. The x axis is one IU/mL of unfractionated heparin per second of simulated time: there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0   (drug-free)</pre></body></html>"));
end Heparin_Salem2022_PD_aptt;
