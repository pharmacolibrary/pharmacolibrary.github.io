function p = Heparin_Salem2022_PD_aptt_params()
% Heparin_Salem2022_PD_aptt_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% heparin Salem_2022::aPTT: linear exposure-response sweep (response = E0 + slope*exposure). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one IU/mL per second, in SI inside (kg/m3, s). Response aPTT in seconds. Driver: unfractionated heparin (pk_record).
p.E0 = 0.0;
p.Emax = 0.0;
p.EC50 = 1.0;
p.gamma = 1.0;
p.slope = 150.0;
p.exposure_per_s = 1.0;
p.stop_time = 1000.0;
p.form = 'E0 + slope*exposure';
end
