function p = Cefazolin_Smith2024_PD_kmax_sc_params()
% Cefazolin_Smith2024_PD_kmax_sc_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% cefazolin Smith_2024::Kmax_SC: emax exposure-response sweep (response = E0 + Emax*frac). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one mg/L per second, in SI inside (kg/m3, s). Response Kmax,SC in h-1. Driver: cefazolin (cited_pk).
p.E0 = 0.0;
p.Emax = -0.0004972222222222222;
p.EC50 = 0.0004159999999999999;
p.gamma = 1.0;
p.slope = 0.0;
p.exposure_per_s = 0.001;
p.stop_time = 4.2;
p.form = 'E0 + Emax*frac';
end
