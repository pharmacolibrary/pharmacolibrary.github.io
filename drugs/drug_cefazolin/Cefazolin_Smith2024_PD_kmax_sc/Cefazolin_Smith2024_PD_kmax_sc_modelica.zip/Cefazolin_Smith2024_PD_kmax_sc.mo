model Cefazolin_Smith2024_PD_kmax_sc
  "emax exposure-response sweep — Smith_2024 :: Kmax,SC (S. aureus bacterial killing rate)"
  extends Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep(
    E0 = 0,      // [1]
    Emax = -0.000497222222222,  // [1/s; h-1 × 0.000277778]
    EC50 = 0.000416,  // [kg/m3; mg/L × 0.001]
    gamma = 1,
    exposure_per_s = 0.001);   // 1 mg/L per second
  // imax_as_negative_emax: Imax (Q323) enters SigmoidEmaxSweep as −Emax
  // defaulted: E0
  // defaulted: gamma
  annotation(experiment(StartTime = 0, StopTime = 4.2, Interval = 0.0084),
    Documentation(info = "<html><body><!-- drug-about --><h4>About cefazolin</h4><p>Cefazolin is a first-generation cephalosporin antibiotic used to treat bacterial infections such as staphylococcal and urinary tract infections. It is an approved medicine and appears on the WHO list of essential medicines, so it is widely used around the world.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q415739\">Wikidata Q415739</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h4>Cefazolin_Smith2024_PD_kmax_sc</h4><p>The steady-state exposure-response curve of Smith NM et al., <i>Frontiers in pharmacology 15:1339858</i> 2024 (<a href=\"https://doi.org/10.3389/fphar.2024.1339858\">doi:10.3389/fphar.2024.1339858</a>) — S. aureus bacterial killing rate [h-1] against cefazolin mg/L — obtained by sweeping the driver instead of simulating a dose. Model family: emax.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = (library default) drug-free response (baseline)
  Emax  =       1.79 h-1      maximal effect term (Max cefazolin killing rate, S. aureus susceptible/intermediate subpopulation, Q323)
  EC50  =      0.416 mg/L     exposure at half of the maximal effect term (Cefazolin concentration for 50% S. aureus Kmx,SC, Q322)
  gamma = (library default) Hill coefficient</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep\">SigmoidEmaxSweep</a>; this model only supplies the numbers. The x axis is one mg/L of cefazolin per second of simulated time (exposure is in kg/m3): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0   (drug-free)
  exposure = EC50 (0.416 mg/L)  response -0.0002486
  exposure -> infinity  response -0.0004972</pre></body></html>"));
end Cefazolin_Smith2024_PD_kmax_sc;
