model Cefazolin_Santavy2023_reference
  parameter Real Cl_ref = 2.472222222222222e-08 "Cl [m3/s]";
  parameter Real Vd_ref = 0.01009 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.454507,
    adminMass = 0.002
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About cefazolin</h4><p>Cefazolin is a first-generation cephalosporin antibiotic used to treat bacterial infections such as staphylococcal and urinary tract infections. It is an approved medicine and appears on the WHO list of essential medicines, so it is widely used around the world.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q415739\">Wikidata Q415739</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>cefazolin</td></tr><tr><td>population:</td><td>adults undergoing cardiac surgery</td></tr><tr><td>source_paper:</td><td>Santavy_2023</td></tr><tr><td>measured_compound:</td><td>cefazolin</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>tab_1</td></tr><tr><td>input:</td><td>PK_1C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>cefazolin 454.507 g/mol (drugbank)</td></tr></table><h4>Interpretation flags</h4><ul><li>dropped unlinked row (NIL): 'β_CL_eGFR' — extend the ontology if this is a real PK parameter (source ['tab_1:row5:col1', 'tab_1:row5:col2', 'tab_1:row5:col4', 'tab_1:row5:col5', 'tab_1:row5:col7', 'tab_1:row5:col8'])</li><li>dropped unlinked row (NIL): 'V2_pop (L)' — extend the ontology if this is a real PK parameter (source ['tab_1:row8:col1', 'tab_1:row8:col2', 'tab_1:row8:col4', 'tab_1:row8:col5', 'tab_1:row8:col7', 'tab_1:row8:col8'])</li><li>dropped unlinked row (NIL): 'Ω_CL' — extend the ontology if this is a real PK parameter (source ['tab_1:row10:col1', 'tab_1:row10:col2', 'tab_1:row10:col4', 'tab_1:row10:col5', 'tab_1:row10:col7', 'tab_1:row10:col8'])</li><li>dropped duplicate Q63 ('Ω_V1', value '0.25') — already have one for this compound</li><li>dropped duplicate Q30 ('Ω_Q', value '0.16') — already have one for this compound</li><li>dropped unlinked row (NIL): 'Ω_V2' — extend the ontology if this is a real PK parameter (source ['tab_1:row13:col1', 'tab_1:row13:col2', 'tab_1:row13:col4', 'tab_1:row13:col5', 'tab_1:row13:col7', 'tab_1:row13:col8'])</li><li>routed 'Proportional' → Q316 (prop_error) to residual_error — variability estimate, not a structural parameter</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=cefazolin</li><li>structure disagreement: deterministic 1C vs LLM 2C — review compartment count</li><li>1C volume normalization: Q63→Q61 (single-compartment model has no central/peripheral split; 'V1_pop (L)' is the general volume)</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 1468800, Tolerance = 1e-9, Interval = 1));
end Cefazolin_Santavy2023_reference;
