model Cefazolin_Ryan2022_reference
  parameter Real Cl_ref = 9e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.0182 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.454507,
    adminMass = 0.003
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About cefazolin</h4><p>Cefazolin is a first-generation cephalosporin antibiotic used to treat bacterial infections such as staphylococcal and urinary tract infections. It is an approved medicine and appears on the WHO list of essential medicines, so it is widely used around the world.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q415739\">Wikidata Q415739</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>cefazolin</td></tr><tr><td>population:</td><td>obese bariatric surgery patients</td></tr><tr><td>source_paper:</td><td>Ryan_2022</td></tr><tr><td>measured_compound:</td><td>cefazolin</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>cefazolin 454.507 g/mol (drugbank)</td></tr></table><h4>Interpretation flags</h4><ul><li>dropped unlinked row (NIL): 'penetration into ISF' — extend the ontology if this is a real PK parameter (source ['Ryan_2022:abstract'])</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=cefazolin</li><li>1C volume normalization: Q63→Q61 (single-compartment model has no central/peripheral split; 'mean central volume of distribution' is the general volume)</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Cefazolin_Ryan2022_reference;
