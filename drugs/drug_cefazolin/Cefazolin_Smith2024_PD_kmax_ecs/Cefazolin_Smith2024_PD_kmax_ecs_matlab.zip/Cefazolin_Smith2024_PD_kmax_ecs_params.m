function p = Cefazolin_Smith2024_PD_kmax_ecs_params()
% Cefazolin_Smith2024_PD_kmax_ecs_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% cefazolin Smith_2024::Kmax_ECs: emax exposure-response sweep (response = E0 + Emax*frac). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one mg/L per second, in SI inside (kg/m3, s). Response Kmax,ECs in h-1. Driver: cefazolin (cited_pk).
p.E0 = 0.0;
p.Emax = -0.001425;
p.EC50 = 0.0070199999999999985;
p.gamma = 1.0;
p.slope = 0.0;
p.exposure_per_s = 0.001;
p.stop_time = 71.0;
p.form = 'E0 + Emax*frac';
end
