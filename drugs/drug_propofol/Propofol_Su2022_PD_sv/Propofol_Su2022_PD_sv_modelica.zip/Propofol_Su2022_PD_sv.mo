model Propofol_Su2022_PD_sv
  "emax exposure-response sweep — Su_2022 :: SV (Stroke volume)"
  extends Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep(
    E0 = 8.04e-05,      // [m3; ml × 1e-06]
    Emax = -2.4e-07,  // [m3; ml × 1e-06]
    EC50 = 0.34,  // [kg/m3; mg ml À1 × 1]
    gamma = 1,
    exposure_per_s = 1);   // 1 mg ml À1 per second
  // imax_as_negative_emax: Imax (Q323) enters SigmoidEmaxSweep as −Emax
  // defaulted: gamma
  annotation(experiment(StartTime = 0, StopTime = 3.4, Interval = 0.0068),
    Documentation(info = "<html><body><!-- drug-about --><h4>About propofol</h4><p>Propofol is an intravenous medication used to induce and maintain general anaesthesia, and also for sedation and to treat status epilepticus. It is widely used in human medicine and is also an approved veterinary medicine; it appears on the WHO list of essential medicines.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q422740\">Wikidata Q422740</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h4>Propofol_Su2022_PD_sv</h4><p>The steady-state exposure-response curve of Su H et al., <i>British journal of anaesthesia 128(5):806–816</i> 2022 (<a href=\"https://doi.org/10.1016/j.bja.2022.01.022\">doi:10.1016/j.bja.2022.01.022</a>) — Stroke volume [ml] against propofol mg ml À1 — obtained by sweeping the driver instead of simulating a dose. Model family: emax.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    =       80.4 ml       drug-free response (baseline) (Base SV, Q324)
  Emax  =      -0.24 ml       maximal effect term (E max_SV, Q323)
  EC50  =       0.34 mg ml À1 exposure at half of the maximal effect term (EC 50 SV, Q321)
  gamma = (library default) Hill coefficient</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep\">SigmoidEmaxSweep</a>; this model only supplies the numbers. The x axis is one mg ml À1 of propofol per second of simulated time (exposure is in kg/m3): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 8.04e-05   (drug-free)
  exposure = EC50 (0.34 mg ml À1)  response 8.028e-05
  exposure -> infinity  response 8.016e-05</pre></body></html>"));
end Propofol_Su2022_PD_sv;
