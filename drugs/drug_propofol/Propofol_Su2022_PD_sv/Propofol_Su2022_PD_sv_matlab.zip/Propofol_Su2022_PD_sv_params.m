function p = Propofol_Su2022_PD_sv_params()
% Propofol_Su2022_PD_sv_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% propofol Su_2022::SV: emax exposure-response sweep (response = E0 + Emax*frac). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one mg ml À1 per second, in SI inside (kg/m3, s). Response SV in ml. Driver: propofol (cited_pk).
p.E0 = 8.040000000000002e-05;
p.Emax = -2.4000000000000003e-07;
p.EC50 = 0.33999999999999997;
p.gamma = 1.0;
p.slope = 0.0;
p.exposure_per_s = 1.0;
p.stop_time = 3.4;
p.form = 'E0 + Emax*frac';
end
