model Propofol_de2025_reference
  parameter Real Cl_ref = 1.888888888888889e-05 "Cl [m3/s]";
  parameter Real Vd_ref = 0.09025500175801356 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.1782707,
    adminMass = 1e-05
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About propofol</h4><p>Propofol is an intravenous medication used to induce and maintain general anaesthesia, and also for sedation and to treat status epilepticus. It is widely used in human medicine and is also an approved veterinary medicine; it appears on the WHO list of essential medicines.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q422740\">Wikidata Q422740</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>propofol</td></tr><tr><td>population:</td><td>review reference</td></tr><tr><td>source_paper:</td><td>de_2025</td></tr><tr><td>measured_compound:</td><td>propofol</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>propofol 178.271 g/mol (drugbank)</td></tr></table><h4>Interpretation flags</h4><ul><li>built from REVIEW reference values (de_2025) — secondary source</li><li>central volume derived from CL·t½/ln2</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Propofol_de2025_reference;
