model Propofol_Eleveld2018_reference
  parameter Real Cl_ref = 2.9833333333333335e-05 "Cl [m3/s]";
  parameter Real Vd_ref = 0.00628 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.1782707,
    adminMass = 1e-05,
    k12 = 0.004644373673036093,
    k21 = 0.0011437908496732025
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About propofol</h4><p>Propofol is an intravenous medication used to induce and maintain general anaesthesia, and also for sedation and to treat status epilepticus. It is widely used in human medicine and is also an approved veterinary medicine; it appears on the WHO list of essential medicines.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q422740\">Wikidata Q422740</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>propofol</td></tr><tr><td>population:</td><td>young children, children, adults, elderly, and high-BMI individuals</td></tr><tr><td>source_paper:</td><td>Eleveld_2018</td></tr><tr><td>measured_compound:</td><td>propofol</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_2C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>propofol 178.271 g/mol (drugbank)</td></tr></table><h4>Interpretation flags</h4><ul><li>dropped PD-category row 'ke0' → Q326 (ke0, category G11) — pharmacodynamic parameters belong to scholarpd, not the PK model (source ['Eleveld_2018:abstract'])</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=propofol</li><li>structure disagreement: deterministic 2C vs LLM 3C — review compartment count</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Propofol_Eleveld2018_reference;
