function p = Propofol_Eleveld2018_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: propofol   source: Eleveld_2018 / reference   route: iv_bolus
  % estimated (absent from source): F, dose
  p.name  = 'Propofol_Eleveld2018_reference_params';
  p.drug  = 'propofol';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'iv_bolus';        % 'oral' | 'iv_bolus'
  p.depot = false;             % oral -> first-order absorption depot
  p.Vc = 6.28;                % central volume [L]
  p.CL = 107.4;                % clearance [L/h]
  p.Vp = [25.5];             % peripheral volumes [L]
  p.Q  = [105.0];             % inter-compartmental clearances [L/h]
  p.ka = 0.0;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 10.0;             % dose [mg]
end
