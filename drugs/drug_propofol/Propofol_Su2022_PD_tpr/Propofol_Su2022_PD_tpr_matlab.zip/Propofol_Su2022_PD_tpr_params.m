function p = Propofol_Su2022_PD_tpr_params()
% Propofol_Su2022_PD_tpr_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% propofol Su_2022::TPR: sigmoid_emax exposure-response sweep (response = E0 + Emax*frac). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one mg ml À1 per second, in SI inside (kg/m3, s). Response TPR in mm Hg ml À1 min. Driver: propofol (cited_pk).
p.E0 = 0.018;
p.Emax = -0.85;
p.EC50 = 2.9599999999999995;
p.gamma = 1.76;
p.slope = 0.0;
p.exposure_per_s = 1.0;
p.stop_time = 30.0;
p.form = 'E0 + Emax*frac';
end
