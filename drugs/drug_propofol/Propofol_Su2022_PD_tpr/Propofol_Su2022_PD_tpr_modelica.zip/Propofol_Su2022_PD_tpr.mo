model Propofol_Su2022_PD_tpr
  "sigmoid_emax exposure-response sweep — Su_2022 :: TPR (Total peripheral resistance)"
  extends Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep(
    E0 = 0.018,      // [mm Hg ml À1 min]
    Emax = -0.85,  // [mm Hg ml À1 min]
    EC50 = 2.96,  // [kg/m3; mg ml À1 × 1]
    gamma = 1.76,
    exposure_per_s = 1);   // 1 mg ml À1 per second
  // imax_as_negative_emax: Imax (Q323) enters SigmoidEmaxSweep as −Emax
  annotation(experiment(StartTime = 0, StopTime = 30, Interval = 0.06),
    Documentation(info = "<html><body><!-- drug-about --><h4>About propofol</h4><p>Propofol is an intravenous medication used to induce and maintain general anaesthesia, and also for sedation and to treat status epilepticus. It is widely used in human medicine and is also an approved veterinary medicine; it appears on the WHO list of essential medicines.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q422740\">Wikidata Q422740</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h4>Propofol_Su2022_PD_tpr</h4><p>The steady-state exposure-response curve of Su H et al., <i>British journal of anaesthesia 128(5):806–816</i> 2022 (<a href=\"https://doi.org/10.1016/j.bja.2022.01.022\">doi:10.1016/j.bja.2022.01.022</a>) — Total peripheral resistance [mm Hg ml À1 min] against propofol mg ml À1 — obtained by sweeping the driver instead of simulating a dose. Model family: sigmoid_emax.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    =      0.018 mm Hg ml À1 min drug-free response (baseline) (Base TPR, Q324)
  Emax  =      -0.85 mm Hg ml À1 min maximal effect term (E max_TPR, Q323)
  EC50  =       2.96 mg ml À1 exposure at half of the maximal effect term (EC 50 TPR, Q321)
  gamma =       1.76          Hill coefficient (g, Q325)</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep\">SigmoidEmaxSweep</a>; this model only supplies the numbers. The x axis is one mg ml À1 of propofol per second of simulated time (exposure is in kg/m3): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0.018   (drug-free)
  exposure = EC50 (2.96 mg ml À1)  response -0.407
  exposure -> infinity  response -0.832</pre></body></html>"));
end Propofol_Su2022_PD_tpr;
