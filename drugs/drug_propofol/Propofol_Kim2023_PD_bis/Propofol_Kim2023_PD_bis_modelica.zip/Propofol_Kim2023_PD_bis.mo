model Propofol_Kim2023_PD_bis
  "sigmoid_emax exposure-response sweep — Kim_2023 :: BIS (bispectral index)"
  extends Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep(
    E0 = 92.1,      // [1]
    Emax = -18.7,  // [1]
    EC50 = 0.00221,  // [kg/m3; μg/mL × 0.001]
    gamma = 2.89,
    exposure_per_s = 0.001);   // 1 μg/mL per second
  // imax_as_negative_emax: Imax (Q323) enters SigmoidEmaxSweep as −Emax
  annotation(experiment(StartTime = 0, StopTime = 23, Interval = 0.046),
    Documentation(info = "<html><body><!-- drug-about --><h4>About propofol</h4><p>Propofol is an intravenous medication used to induce and maintain general anaesthesia, and also for sedation and to treat status epilepticus. It is widely used in human medicine and is also an approved veterinary medicine; it appears on the WHO list of essential medicines.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q422740\">Wikidata Q422740</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h4>Propofol_Kim2023_PD_bis</h4><p>The steady-state exposure-response curve of Kim KM et al., <i>Journal of pharmacokinetics and pharmacodynamics 50(2):97–109</i> 2023 (<a href=\"https://doi.org/10.1007/s10928-022-09836-6\">doi:10.1007/s10928-022-09836-6</a>) — bispectral index against propofol μg/mL — obtained by sweeping the driver instead of simulating a dose. Model family: sigmoid_emax.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    =       92.1          drug-free response (baseline) (E0, Q324)
  Emax  =       18.7          maximal effect term (Emax, Q323)
  EC50  =       2.21 μg/mL    exposure at half of the maximal effect term (Ce50, Q321)
  gamma =       2.89          Hill coefficient (γ, Q325)</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep\">SigmoidEmaxSweep</a>; this model only supplies the numbers. The x axis is one μg/mL of propofol per second of simulated time (exposure is in kg/m3): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 92.1   (drug-free)
  exposure = EC50 (2.21 μg/mL)  response 82.75
  exposure -> infinity  response 73.4</pre></body></html>"));
end Propofol_Kim2023_PD_bis;
