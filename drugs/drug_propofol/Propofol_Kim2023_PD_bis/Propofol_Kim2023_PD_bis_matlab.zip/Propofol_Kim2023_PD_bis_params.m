function p = Propofol_Kim2023_PD_bis_params()
% Propofol_Kim2023_PD_bis_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% propofol Kim_2023::BIS: sigmoid_emax exposure-response sweep (response = E0 + Emax*frac). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one μg/mL per second, in SI inside (kg/m3, s). Response BIS in its own unit. Driver: propofol (pk_record).
p.E0 = 92.1;
p.Emax = -18.7;
p.EC50 = 0.0022099999999999997;
p.gamma = 2.89;
p.slope = 0.0;
p.exposure_per_s = 0.001;
p.stop_time = 23.0;
p.form = 'E0 + Emax*frac';
end
