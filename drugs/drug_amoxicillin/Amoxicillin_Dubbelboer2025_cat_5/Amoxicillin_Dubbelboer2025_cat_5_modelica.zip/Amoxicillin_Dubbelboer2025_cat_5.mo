model Amoxicillin_Dubbelboer2025_cat_5
  parameter Real Cl_ref = 4.472222222222223e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.0329 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 0.9,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.365404,
    adminMass = 0.0007,
    ka = 4.722222222222223e-05,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>amoxicillin</td></tr><tr><td>population:</td><td>healthy cats</td></tr><tr><td>source_paper:</td><td>Dubbelboer_2025</td></tr><tr><td>measured_compound:</td><td>amoxicillin</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>jvp70003-tbl-0002</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>amoxicillin 365.404 g/mol (drugbank)</td></tr></table><p><b>Defaulted (base-class default used):</b> F, Tlag.</p><h4>Interpretation flags</h4><ul><li>dropped duplicate Q32 ('C max SC', value '13.1') — already have one for this compound</li><li>dropped duplicate Q56 ('T maxSC', value '1') — already have one for this compound</li><li>dropped duplicate Q17 ('AUC0‐ꚙPO', value '18.8') — already have one for this compound</li><li>dropped duplicate Q17 ('AUC0‐ꚙSC', value '48.8') — already have one for this compound</li><li>dropped duplicate Q47 ('k ePO', value '0.52') — already have one for this compound</li><li>dropped duplicate Q47 ('k eSC', value '0.28') — already have one for this compound</li><li>dropped duplicate Q57 ('t 1/2zPO', value '1.3') — already have one for this compound</li><li>dropped duplicate Q57 ('t 1/2zSC', value '2.6') — already have one for this compound</li><li>implicit units: 'Cl' → L/h/kg (from the paper text: &quot;The abstract states 'The population clearance was 0.18 L/h∙kg' and the discussion compares 'Cl (present: 0.17 L/kg∙h...)&quot;)</li><li>implicit units: 'V d' → L/kg (from the paper text: &quot;The abstract states 'the volume of the central compartment was 0.12 L/kg' and the discussion compares 'V d (present: 0.3&quot;)</li><li>implicit units: 'C maxPO' → mg/L (from the paper text: &quot;The discussion states 'IV AUCIV (57.6 mg∙h/L...)', implying the concentration unit is mg/L, which is consistent with the&quot;)</li><li>implicit units: 'T maxPO' → h (from the paper text: &quot;The table caption defines T max as 'the time for C max' and the text mentions 'from the time 0 h to infinity', indicatin&quot;)</li><li>implicit units: 'AUC0‐ꚙIV' → mg*h/L (from the paper text: &quot;The discussion explicitly cites the AUC value with units: 'IV AUCIV (57.6 mg∙h/L...)'.&quot;)</li><li>implicit units: 'k eIV' → 1/h (from the paper text: &quot;The text states 'the population value for k apo was 0.34 1/h', establishing the unit for first-order rate constants (inc&quot;)</li><li>implicit units: 't 1/2zIV' → h (from the paper text: &quot;The table caption defines t 1/2z as a half-life, and the text references time in hours (e.g., 'time 0 h'), consistent wi&quot;)</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=amoxicillin</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 90000, Tolerance = 1e-9, Interval = 1));
end Amoxicillin_Dubbelboer2025_cat_5;
