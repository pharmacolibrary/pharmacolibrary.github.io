function p = Amoxicillin_Dubbelboer2025_cat_5_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: amoxicillin   source: Dubbelboer_2025 / cat_5   route: oral
  % estimated (absent from source): F
  p.name  = 'Amoxicillin_Dubbelboer2025_cat_5_params';
  p.drug  = 'amoxicillin';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 32.9;                % central volume [L]
  p.CL = 16.1;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.17;                % absorption rate [1/h]
  p.F  = 0.9;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 700.0;             % dose [mg]
end
