function p = Amoxicillin_Li1994_PD_n_params()
% Amoxicillin_Li1994_PD_n_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% amoxicillin Li_1994::N: emax exposure-response sweep (response = E0 + Emax*frac). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one mg/L per second, in SI inside (kg/m3, s). Response N in cfu/mL. Driver: amoxicillin (cited_pk).
p.E0 = 0.0;
p.Emax = -5.49;
p.EC50 = 0.0029499999999999995;
p.gamma = 1.0;
p.slope = 0.0;
p.exposure_per_s = 0.001;
p.stop_time = 30.0;
p.form = 'E0 + Emax*frac';
end
