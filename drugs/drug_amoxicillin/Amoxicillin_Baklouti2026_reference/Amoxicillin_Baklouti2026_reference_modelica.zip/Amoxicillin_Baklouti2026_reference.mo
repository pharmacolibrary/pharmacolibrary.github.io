model Amoxicillin_Baklouti2026_reference
  parameter Real Cl_ref = 7.093833333333332e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.08238 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.365404,
    adminMass = 0.001,
    ka = 4.722222222222223e-05,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>amoxicillin</td></tr><tr><td>population:</td><td>breastfeeding mothers</td></tr><tr><td>source_paper:</td><td>Baklouti_2026</td></tr><tr><td>measured_compound:</td><td>amoxicillin</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>bcp70434-tbl-0003</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>amoxicillin 365.404 g/mol (drugbank)</td></tr></table><p><b>Defaulted (base-class default used):</b> Tlag.</p><h4>Interpretation flags</h4><ul><li>dropped unlinked row (NIL): 'b1 (se)' — extend the ontology if this is a real PK parameter (source ['bcp70434-tbl-0003:row11:col1', 'bcp70434-tbl-0003:row11:col2', 'bcp70434-tbl-0003:row11:col3'])</li><li>dropped unlinked row (NIL): 'b2 (se)' — extend the ontology if this is a real PK parameter (source ['bcp70434-tbl-0003:row12:col1', 'bcp70434-tbl-0003:row12:col2', 'bcp70434-tbl-0003:row12:col3'])</li><li>apparent-ness (ontology-grounded): parameterization=apparent, measured_compound=amoxicillin</li><li>structure disagreement: deterministic 1C vs LLM 2C — review compartment count</li><li>amount-only peripheral compartment: a peripheral output rate (kout_peripheral) is present with no reported volume — model its AMOUNT; concentration is not identifiable without an assumed volume</li><li>skipped review gap-fill of CL: primary's parameterization (rate-constant / ka-only) does not use it</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary's parameterization (rate-constant / ka-only) does not use it</li><li>skipped review gap-fill of TLAG: primary's parameterization (rate-constant / ka-only) does not use it</li><li>derived CL/F=25.5378 L/h from Ke × V/F = CL/F (Q47 × Q76); not separately reported</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 104400, Tolerance = 1e-9, Interval = 1));
end Amoxicillin_Baklouti2026_reference;
