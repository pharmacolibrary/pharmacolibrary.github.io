function p = Amoxicillin_Wu2021_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: amoxicillin   source: Wu_2021 / reference   route: oral
  % estimated (absent from source): F
  p.name  = 'Amoxicillin_Wu2021_reference_params';
  p.drug  = 'amoxicillin';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 2.17;                % central volume [L]
  p.CL = 2.15;                % clearance [L/h]
  p.Vp = [2.03];             % peripheral volumes [L]
  p.Q  = [0.711];             % inter-compartmental clearances [L/h]
  p.ka = 0.17;                % absorption rate [1/h]
  p.F  = 0.9;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 1750.0;             % dose [mg]
end
