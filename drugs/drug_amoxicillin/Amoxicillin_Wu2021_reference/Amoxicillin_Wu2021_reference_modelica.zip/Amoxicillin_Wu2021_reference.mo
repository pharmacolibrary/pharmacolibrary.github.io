model Amoxicillin_Wu2021_reference
  parameter Real Cl_ref = 5.972222222222222e-07 "Cl [m3/s]";
  parameter Real Vd_ref = 0.00217 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C_enteral(
    weight = 70.0,
    F = 0.9,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.365404,
    adminMass = 0.00175,
    ka = 4.722222222222223e-05,
    Tlag = 0.0,
    k12 = 9.101382488479262e-05,
    k21 = 9.729064039408868e-05
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>amoxicillin</td></tr><tr><td>population:</td><td>Chinese infants</td></tr><tr><td>source_paper:</td><td>Wu_2021</td></tr><tr><td>measured_compound:</td><td>amoxicillin</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>tab_1</td></tr><tr><td>input:</td><td>PK_2C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>amoxicillin 365.404 g/mol (drugbank)</td></tr></table><p><b>Defaulted (base-class default used):</b> F, Tlag.</p><h4>Interpretation flags</h4><ul><li>dropped duplicate Q22 ('CL', value '23.5') — already have one for this compound</li><li>dropped duplicate Q64 ('V₂', value '82.4') — already have one for this compound</li><li>implicit units: 'CL(L/h)\nCL = θ1 × Fweight\nθ1' → L/h (from the paper text: &quot;The paper text states: 'The median of estimated weight-normalized CL was 0.31 L/h/kg' and 'The median (range) values of &quot;)</li><li>implicit units: 'V₁ (L)\nV₁ = θ2\nθ2' → L (from the popPK convention: 'The text provides units for weight-normalized V1 (L/kg) but not for the total volume V1. By convention, volume of distri')</li><li>implicit units: 'V₂ (L)\nV₂ = θ3\nθ3' → L (from the popPK convention: 'The text provides units for weight-normalized V2 (L/kg) but not for the total volume V2. By convention, volume of distri')</li><li>implicit units: 'Q (L/h)\nQ = θ4\nθ4' → L/h (from the popPK convention: 'The text does not state a unit for Q. By convention, intercompartmental clearance is expressed in liters per hour (L/h).')</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=amoxicillin</li><li>model equation 'Fweight = (CW/7)^0.5
θ5' not bound — neither LHS nor base term 'CW' linked to an ontology parameter</li><li>gap-filled Q49 (kabs) from Baklouti_2026's review values (primary lacked it)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Amoxicillin_Wu2021_reference;
