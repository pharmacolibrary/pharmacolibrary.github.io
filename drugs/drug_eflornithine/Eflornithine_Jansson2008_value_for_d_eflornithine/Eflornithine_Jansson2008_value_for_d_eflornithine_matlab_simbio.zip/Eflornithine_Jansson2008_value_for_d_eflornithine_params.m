function p = Eflornithine_Jansson2008_value_for_d_eflornithine_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: eflornithine   source: Jansson_2008 / value_for_d_eflornithine   route: oral
  p.name  = 'Eflornithine_Jansson2008_value_for_d_eflornithine_params';
  p.drug  = 'eflornithine';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 28.07;                % central volume [L]
  p.CL = 52.92;                % clearance [L/h]
  p.Vp = [31.22];             % peripheral volumes [L]
  p.Q  = [5.04];             % inter-compartmental clearances [L/h]
  p.ka = 1.16;                % absorption rate [1/h]
  p.F  = 0.623;                 % bioavailability [0-1]
  p.Tlag = 0.447;             % absorption lag [h]
  p.dose = 26250.0;             % dose [mg]
end
