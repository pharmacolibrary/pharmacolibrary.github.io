model Eflornithine_Jansson2008_value_for_d_eflornithine
  parameter Real Cl_ref = 1.47e-05 "Cl [m3/s]";
  parameter Real Vd_ref = 0.028070000000000005 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C_enteral(
    weight = 70.0,
    F = 62.3,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.182171,
    adminMass = 0.02625,
    ka = 0.0003222222222222222,
    Tlag = 1609.2,
    k12 = 4.9875311720698244e-05,
    k21 = 4.484304932735426e-05
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About eflornithine</h4><p>Eflornithine is used to treat excessive facial hair growth in women (hirsutism) and, in combination therapy, the childhood cancer neuroblastoma; it has also been used against sleeping sickness. It remains authorised in the European Union for these uses, with a topical dermatological product for hirsutism and an oncology product for neuroblastoma, though some applications have been withdrawn.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q72470623\">Wikidata Q72470623</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>eflornithine</td></tr><tr><td>population:</td><td>male Sprague-Dawley rats</td></tr><tr><td>source_paper:</td><td>Jansson_2008</td></tr><tr><td>measured_compound:</td><td>eflornithine</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>tab_2</td></tr><tr><td>input:</td><td>PK_2C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>eflornithine 182.171 g/mol (drugbank)</td></tr></table><h4>Interpretation flags</h4><ul><li>unit_dimension_unknown: 'mol/min/kg of body wt' (tmax)</li><li>dropped unlinked row (NIL): 'K t (mol/kg of body wt)' — extend the ontology if this is a real PK parameter (source ['tab_2:row2:col4'])</li><li>unit_dimension_unknown: 'ml/min/kg of body wt' (CL)</li><li>unit_dimension_unknown: 'liters/kg of body wt' (V1)</li><li>unit_dimension_unknown: 'ml/min/kg of body wt' (Q)</li><li>unit_dimension_unknown: 'liters/kg of body wt' (V2)</li><li>implicit units: 'T max (mol/min/kg of body wt)' → h (from the popPK convention: 'The parameter is T_max (time to maximum concentration). Although the provided prompt text contains a likely OCR/labeling')</li><li>implicit units: 'CL (ml/min/kg of body wt)' → ml/min/kg (from the paper text: &quot;The abstract explicitly states: 'mean clearances of 14.5 and 12.6 ml/min/kg for L-and D-eflornithine, respectively'. The&quot;)</li><li>implicit units: 'V central (liters/kg of body wt)' → L/kg (from the paper text: &quot;While the table caption does not explicitly list units for the column, the prompt's parameter description for item 3 exp&quot;)</li><li>implicit units: 'Q (ml/min/kg of body wt)' → ml/min/kg (from the paper text: &quot;The prompt's parameter description for item 4 explicitly includes '(ml/min/kg of body wt)' in the parameter label line '&quot;)</li><li>implicit units: 'V peripheral (liters/kg of body wt)' → L/kg (from the paper text: &quot;The prompt's parameter description for item 5 explicitly includes '(liters/kg of body wt)' in the parameter label line '&quot;)</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=eflornithine</li><li>population split: 'value for d-eflornithine' subgroup of Jansson_2008 (paper reports 5 populations: d-eflornithine estimate (rse), l-eflornithine estimate (rse), value for d-eflornithine, value for l-eflornithine, value for r-eflornithine estimate (rse) iiv (rse))</li><li>gap-filled Q49 (kabs) from Boberg_2025's review values (primary lacked it)</li><li>gap-filled Q83 (tlag) from Boberg_2025's review values (primary lacked it)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Eflornithine_Jansson2008_value_for_d_eflornithine;
