function p = Eflornithine_Jansson2008_value_for_l_eflornithine_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: eflornithine   source: Jansson_2008 / value_for_l_eflornithine   route: oral
  p.name  = 'Eflornithine_Jansson2008_value_for_l_eflornithine_params';
  p.drug  = 'eflornithine';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 28.28;                % central volume [L]
  p.CL = 60.9;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 1.16;                % absorption rate [1/h]
  p.F  = 0.623;                 % bioavailability [0-1]
  p.Tlag = 0.447;             % absorption lag [h]
  p.dose = 26250.0;             % dose [mg]
end
