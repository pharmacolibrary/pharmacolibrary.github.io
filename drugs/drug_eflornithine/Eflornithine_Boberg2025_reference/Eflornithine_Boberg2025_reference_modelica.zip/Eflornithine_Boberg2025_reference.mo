model Eflornithine_Boberg2025_reference
  parameter Real Cl_ref = 4.777777777777777e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.055 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.182171,
    adminMass = 0.0001,
    ka = 0.0003222222222222222,
    Tlag = 1609.2,
    k12 = 4.045454545454545e-05,
    k21 = 3.3559577677224736e-05
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About eflornithine</h4><p>Eflornithine is used to treat excessive facial hair growth in women (hirsutism) and, in combination therapy, the childhood cancer neuroblastoma; it has also been used against sleeping sickness. It remains authorised in the European Union for these uses, with a topical dermatological product for hirsutism and an oncology product for neuroblastoma, though some applications have been withdrawn.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q72470623\">Wikidata Q72470623</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>eflornithine</td></tr><tr><td>population:</td><td>review reference</td></tr><tr><td>source_paper:</td><td>Boberg_2025</td></tr><tr><td>measured_compound:</td><td>eflornithine</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_2C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>eflornithine 182.171 g/mol (drugbank)</td></tr></table><h4>Interpretation flags</h4><ul><li>built from REVIEW reference values (Boberg_2025) — secondary source</li><li>volume reported by review</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Eflornithine_Boberg2025_reference;
