model Dihydroergocristine_Grognet1992_reference
  parameter Real Cl_ref = 7.361111111111111e-07 "Cl [m3/s]";
  parameter Real Vd_ref = 3.64 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.611743,
    adminMass = 1e-05
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>dihydroergocristine</td></tr><tr><td>population:</td><td>rats</td></tr><tr><td>source_paper:</td><td>Grognet_1992</td></tr><tr><td>measured_compound:</td><td>dihydroergocristine</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>dihydroergocristine 611.743 g/mol (drugbank)</td></tr></table><h4>Interpretation flags</h4><ul><li>unit_dimension_unknown: 'l.h-1 x kg-1' (CL)</li><li>implicit units: 'systemic clearance' → L/h (from the popPK convention: 'No unit is stated in the provided text or table captions. Systemic clearance is conventionally expressed in L/h in popul')</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=dihydroergocristine</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 259200, Tolerance = 1e-9, Interval = 1));
end Dihydroergocristine_Grognet1992_reference;
