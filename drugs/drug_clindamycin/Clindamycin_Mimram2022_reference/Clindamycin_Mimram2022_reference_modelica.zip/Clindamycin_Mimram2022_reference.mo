model Clindamycin_Mimram2022_reference
  parameter Real Cl_ref = 6.3888888888888885e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.10300000000000001 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.42498,
    adminMass = 0.00075,
    ka = 0.0009805555555555555,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About clindamycin</h4><p>Clindamycin is a lincosamide antibiotic used to treat bacterial infections such as staphylococcal and skin infections, acne, dental abscesses, bacterial vaginosis, toxoplasmosis, and pneumocystosis. It is widely used in human medicine and is also approved for veterinary use, and it appears on the WHO list of essential medicines.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q422273\">Wikidata Q422273</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>clindamycin</td></tr><tr><td>population:</td><td>adults with prosthetic joint infections</td></tr><tr><td>source_paper:</td><td>Mimram_2022</td></tr><tr><td>measured_compound:</td><td>clindamycin</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>antibiotics-11-01462-t002</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>clindamycin 424.98 g/mol (drugbank)</td></tr></table><p><b>Defaulted (base-class default used):</b> Tlag.</p><h4>Interpretation flags</h4><ul><li>table section iiv: 'ω2 CL/F' routed out of structural estimates ('Interindividual variability')</li><li>table section iiv: 'ω2 CL/F' routed out of structural estimates ('Interindividual variability')</li><li>table section iiv: 'ω2 V/F' routed out of structural estimates ('Interindividual variability')</li><li>table section iiv: 'ω2 V/F' routed out of structural estimates ('Interindividual variability')</li><li>table section iiv: 'ω2 Ka' routed out of structural estimates ('Interindividual variability')</li><li>table section iiv: 'ω2 Ka' routed out of structural estimates ('Interindividual variability')</li><li>table section residual_error: 'Proportional errorAdditive error' routed out of structural estimates ('Residual error')</li><li>table section residual_error: 'Proportional errorAdditive error' routed out of structural estimates ('Residual error')</li><li>apparent-ness (ontology-grounded): parameterization=apparent, measured_compound=clindamycin</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of TLAG: primary's parameterization (rate-constant / ka-only) does not use it</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Clindamycin_Mimram2022_reference;
