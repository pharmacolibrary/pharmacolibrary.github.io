model Cyclophosphamide_Shemesh2020_reference
  parameter Real Cl_ref = 1.028935185185185e-08 "Cl [m3/s]";
  parameter Real Vd_ref = 0.006092140483913869 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.26108600000000004,
    adminMass = 1e-05
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About cyclophosphamide</h4><p>Cyclophosphamide is an alkylating anticancer drug used to treat many cancers, including breast and ovarian cancer, leukemias, and lymphomas, as well as several autoimmune diseases such as lupus and vasculitis. It is an approved medicine and appears on the WHO list of essential medicines, so it is widely used worldwide.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q408524\">Wikidata Q408524</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>cyclophosphamide</td></tr><tr><td>population:</td><td>review reference</td></tr><tr><td>source_paper:</td><td>Shemesh_2020</td></tr><tr><td>measured_compound:</td><td>cyclophosphamide</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>cyclophosphamide 261.086 g/mol (drugbank)</td></tr></table><h4>Interpretation flags</h4><ul><li>built from REVIEW reference values (Shemesh_2020) — secondary source</li><li>central volume derived from CL·t½/ln2</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 2419200, Tolerance = 1e-9, Interval = 1));
end Cyclophosphamide_Shemesh2020_reference;
