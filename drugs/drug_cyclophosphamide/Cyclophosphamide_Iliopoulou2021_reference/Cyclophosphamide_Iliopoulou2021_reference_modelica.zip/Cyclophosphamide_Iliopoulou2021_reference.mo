model Cyclophosphamide_Iliopoulou2021_reference
  parameter Real Cl_ref = 3.6944444444444446e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.0598 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 0.9,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.26108600000000004,
    adminMass = 0.0001,
    ka = 8.946759259259258e-06,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About cyclophosphamide</h4><p>Cyclophosphamide is an alkylating anticancer drug used to treat many cancers, including breast and ovarian cancer, leukemias, and lymphomas, as well as several autoimmune diseases such as lupus and vasculitis. It is an approved medicine and appears on the WHO list of essential medicines, so it is widely used worldwide.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q408524\">Wikidata Q408524</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>cyclophosphamide</td></tr><tr><td>population:</td><td>patients with autoimmune glomerulonephritis</td></tr><tr><td>source_paper:</td><td>Iliopoulou_2021</td></tr><tr><td>measured_compound:</td><td>cyclophosphamide</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>cyclophosphamide 261.086 g/mol (drugbank)</td></tr></table><p><b>Defaulted (base-class default used):</b> F, Tlag.</p><h4>Interpretation flags</h4><ul><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=cyclophosphamide</li><li>1C volume normalization: Q63→Q61 (single-compartment model has no central/peripheral split; 'central volume of distribution' is the general volume)</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li><li>gap-filled Q49 (kabs) from Luo_2022's review values (primary lacked it)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 432000, Tolerance = 1e-9, Interval = 1));
end Cyclophosphamide_Iliopoulou2021_reference;
