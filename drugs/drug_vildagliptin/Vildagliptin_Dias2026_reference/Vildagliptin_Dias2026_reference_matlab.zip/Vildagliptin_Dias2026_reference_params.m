function p = Vildagliptin_Dias2026_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: vildagliptin   source: Dias_2026 / reference   route: oral
  % estimated (absent from source): ka
  p.name  = 'Vildagliptin_Dias2026_reference_params';
  p.drug  = 'vildagliptin';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 77.7;                % central volume [L]
  p.CL = 190.4;                % clearance [L/h]
  p.Vp = [129.5];             % peripheral volumes [L]
  p.Q  = [23.66];             % inter-compartmental clearances [L/h]
  p.ka = 0.5;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 3500.0;             % dose [mg]
end
