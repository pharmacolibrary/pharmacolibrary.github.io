model Vildagliptin_Dias2026_reference
  parameter Real Cl_ref = 5.288888888888889e-05 "Cl [m3/s]";
  parameter Real Vd_ref = 0.0777 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.3033993,
    adminMass = 0.0035,
    ka = 0.0001388888888888889,
    Tlag = 0.0,
    k12 = 8.458458458458459e-05,
    k21 = 5.075075075075076e-05
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About vildagliptin</h4><p>Vildagliptin is a DPP-4 inhibitor used to lower blood glucose in adults with type 2 diabetes. It is authorised in the European Union and widely used as an oral diabetes medicine, often in combination products.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q421042\">Wikidata Q421042</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>vildagliptin</td></tr><tr><td>population:</td><td>healthy and diabetic rats</td></tr><tr><td>source_paper:</td><td>Dias_2026</td></tr><tr><td>measured_compound:</td><td>vildagliptin</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>psp470165-tbl-0001</td></tr><tr><td>input:</td><td>PK_2C_enteral: apparent (/F) parameterization ⇒ extravascular dosing</td></tr><tr><td>molar_masses:</td><td>vildagliptin 303.399 g/mol (drugbank)</td></tr></table><p><b>Defaulted (base-class default used):</b> ka, Tlag.</p><h4>Interpretation flags</h4><ul><li>table section iiv: 'CL (L/h/kg)' routed out of structural estimates ('IIV (% RSE)')</li><li>table section iiv: 'Q 1,healthy (L/h/kg)' routed out of structural estimates ('IIV (% RSE)')</li><li>table section iiv: 'Q 1,diabetic (L/h/kg)' routed out of structural estimates ('IIV (% RSE)')</li><li>table section iiv: 'V 3 (L/kg)' routed out of structural estimates ('IIV (% RSE)')</li><li>table section iiv: 'Q out,liver,healthy (L/h/kg)' routed out of structural estimates ('IIV (% RSE)')</li><li>table section iiv: 'Q out,liver,diabetic (L/h/kg)' routed out of structural estimates ('IIV (% RSE)')</li><li>table section iiv: 'V 4 (L/kg)' routed out of structural estimates ('IIV (% RSE)')</li><li>table section residual_error: 'Plasma' routed out of structural estimates ('Residual error (ng/L)')</li><li>table section residual_error: 'Muscle' routed out of structural estimates ('Residual error (ng/L)')</li><li>table section residual_error: 'Liver' routed out of structural estimates ('Residual error (ng/L)')</li><li>dropped duplicate Q30 ('Q 1,diabetic (L/h/kg)', value '2.61') — already have one for this compound</li><li>dropped duplicate Q30 ('Q in,muscle (L/h/kg)', value '2.09') — already have one for this compound</li><li>dropped duplicate Q30 ('Q out,muscle (L/h/kg)', value '14.3') — already have one for this compound</li><li>dropped duplicate Q30 ('Q in,liver (L/h/kg)', value '2.5') — already have one for this compound</li><li>dropped duplicate Q30 ('Q out,liver,healthy (L/h/kg)', value '218') — already have one for this compound</li><li>dropped duplicate Q30 ('Q out,liver,diabetic (L/h/kg)', value '19.7') — already have one for this compound</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Vildagliptin_Dias2026_reference;
