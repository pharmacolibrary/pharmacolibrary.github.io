function p = Pethidine_HamamotoHardman2020_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: pethidine   source: Hamamoto-Hardman_2020 / reference   route: iv_bolus
  % estimated (absent from source): F
  p.name  = 'Pethidine_HamamotoHardman2020_reference_params';
  p.drug  = 'pethidine';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'iv_bolus';        % 'oral' | 'iv_bolus'
  p.depot = false;             % oral -> first-order absorption depot
  p.Vc = 210.500748;                % central volume [L]
  p.CL = 75.6;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.0;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 17.5;             % dose [mg]
end
