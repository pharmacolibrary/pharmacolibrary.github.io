model Pethidine_Zhang2014_reference
  parameter Real Cl_ref = 4.422222222222223e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 4.1909 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.2473327,
    adminMass = 0.0014,
    ka = 0.0001388888888888889,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>pethidine</td></tr><tr><td>population:</td><td>review reference</td></tr><tr><td>source_paper:</td><td>Zhang_2014</td></tr><tr><td>measured_compound:</td><td>pethidine</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C_enteral: apparent (/F) parameterization ⇒ extravascular dosing</td></tr><tr><td>molar_masses:</td><td>pethidine 247.333 g/mol (drugbank)</td></tr></table><p><b>Defaulted (base-class default used):</b> ka, Tlag.</p><h4>Interpretation flags</h4><ul><li>built from REVIEW reference values (Zhang_2014) — secondary source</li><li>volume reported by review</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 3628800, Tolerance = 1e-9, Interval = 1));
end Pethidine_Zhang2014_reference;
