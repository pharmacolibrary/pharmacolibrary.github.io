model Pethidine_Chmelar1975_reference
  parameter Real Cl_ref = 1.7694444444444443e-07 "Cl [m3/s]";
  parameter Real Vd_ref = 0.35000000000000003 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.2473327,
    adminMass = 0.0004
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>pethidine</td></tr><tr><td>population:</td><td>rats</td></tr><tr><td>source_paper:</td><td>Chmelar_1975</td></tr><tr><td>measured_compound:</td><td>pethidine</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>pethidine 247.333 g/mol (drugbank)</td></tr></table><h4>Interpretation flags</h4><ul><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=pethidine</li><li>gap-filled Q22 (CL) from Groll_2019's review values (primary lacked it)</li><li>gap-filled Q61 (V) from Hernández-Gago_2026's review values (primary lacked it)</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li><li>gap-filled Q83 (tlag) from Morse_2022's review values (primary lacked it)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 7257600, Tolerance = 1e-9, Interval = 1));
end Pethidine_Chmelar1975_reference;
