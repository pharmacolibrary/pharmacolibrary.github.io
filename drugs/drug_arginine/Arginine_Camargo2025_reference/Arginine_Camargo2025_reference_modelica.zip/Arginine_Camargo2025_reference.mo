model Arginine_Camargo2025_reference
  parameter Real Cl_ref = 9.838888888888887e-05 "Cl [m3/s]";
  parameter Real Vd_ref = 0.0224 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 0.9,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.174204,
    adminMass = 0.0035,
    ka = 6.277777777777778e-05,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>arginine</td></tr><tr><td>population:</td><td>review reference</td></tr><tr><td>source_paper:</td><td>Camargo_2025</td></tr><tr><td>measured_compound:</td><td>arginine</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>arginine 174.204 g/mol (pubchem)</td></tr></table><p><b>Defaulted (base-class default used):</b> F, Tlag.</p><h4>Interpretation flags</h4><ul><li>built from REVIEW reference values (Camargo_2025) — secondary source</li><li>volume reported by review</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Arginine_Camargo2025_reference;
