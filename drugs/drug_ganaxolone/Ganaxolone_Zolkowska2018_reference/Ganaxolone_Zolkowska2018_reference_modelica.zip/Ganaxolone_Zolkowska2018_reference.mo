model Ganaxolone_Zolkowska2018_reference
  parameter Real Cl_ref = 0.00025044444444444447 "Cl [m3/s]";
  parameter Real Vd_ref = 0.34650000000000003 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    adminMass = 1e-05
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About ganaxolone</h4><p>Ganaxolone is an antiepileptic medicine used to treat epileptic syndromes, including infantile spasms. It is authorised in the European Union and is also being investigated for other uses.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q3758034\">Wikidata Q3758034</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>ganaxolone</td></tr><tr><td>population:</td><td>mice</td></tr><tr><td>source_paper:</td><td>Zolkowska_2018</td></tr><tr><td>measured_compound:</td><td>ganaxolone and allopregnanolone</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>ganaxolone 332.528 g/mol (drugbank)</td></tr></table><h4>Interpretation flags</h4><ul><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=ganaxolone and allopregnanolone</li><li>held at status:extracted — NIL link or unit issue (mismatch/unknown/normalisation-failed) present</li><li>status held at route_to_review — not promoted</li><li>molar mass: no plausible PubChem entry for 'ganaxolone and allopregnanolone' ('ganaxolone and allopregnanolone') — left in mass units</li><li>molar mass: none found for 'ganaxolone and allopregnanolone' — its concentrations stay mass-only</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Ganaxolone_Zolkowska2018_reference;
