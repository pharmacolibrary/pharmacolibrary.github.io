model Vancomycin_VeraYunca2025_PD_bacterial_load
  "sigmoid_emax exposure-response sweep — Vera-Yunca_2025 :: bacterial load (name)"
  extends Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep(
    E0 = 0,      // [1]
    Emax = -0.000483333333333,  // [1/s; h−1 × 0.000277778]
    EC50 = 0.00056,  // [kg/m3; mg/L × 0.001]
    gamma = 1,
    exposure_per_s = 0.001);   // 1 mg/L per second
  // inhibition_sign: effect_direction=inhibition with a positive Emax (Q320) — sign flipped
  // defaulted: E0
  // defaulted: gamma
  annotation(experiment(StartTime = 0, StopTime = 5.6, Interval = 0.0112),
    Documentation(info = "<html><body><h4>Vancomycin_VeraYunca2025_PD_bacterial_load</h4><p>The steady-state exposure-response curve of Vera-Yunca D et al., <i>The Journal of antimicrobial chemotherapy 80(7):1860–1868</i> 2025 (<a href=\"https://doi.org/10.1093/jac/dkaf140\">doi:10.1093/jac/dkaf140</a>) — name [cfu/total lung] against linezolid, vancomycin mg/L — obtained by sweeping the driver instead of simulating a dose. Model family: sigmoid_emax.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = (library default) drug-free response (baseline)
  Emax  =       1.74 h−1      maximal effect term (E max,VAN (h−1), Q320)
  EC50  =       0.56 mg/L     exposure at half of the maximal effect term (EC50,LZD (mg/L) — Value, Q321)
  gamma = (library default) Hill coefficient</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep\">SigmoidEmaxSweep</a>; this model only supplies the numbers. The x axis is one mg/L of linezolid, vancomycin per second of simulated time (exposure is in kg/m3): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0   (drug-free)
  exposure = EC50 (0.56 mg/L)  response -0.0002417
  exposure -> infinity  response -0.0004833</pre></body></html>"));
end Vancomycin_VeraYunca2025_PD_bacterial_load;
