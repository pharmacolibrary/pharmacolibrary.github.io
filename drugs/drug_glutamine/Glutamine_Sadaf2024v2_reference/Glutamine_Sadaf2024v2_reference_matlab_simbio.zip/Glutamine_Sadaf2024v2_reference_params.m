function p = Glutamine_Sadaf2024v2_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: glutamine   source: Sadaf_2024_2 / reference   route: oral
  % estimated (absent from source): F
  p.name  = 'Glutamine_Sadaf2024v2_reference_params';
  p.drug  = 'glutamine';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 4.452;                % central volume [L]
  p.CL = 78.5;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.91;                % absorption rate [1/h]
  p.F  = 0.9;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 7000.0;             % dose [mg]
end
