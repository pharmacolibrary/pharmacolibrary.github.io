model Atogepant_Schlachter2026v2_PD_mmd
  "emax exposure-response sweep — Schlachter_2026_2 :: MMD (Monthly migraine days)"
  extends Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep(
    E0 = 73612.8,      // [s; days × 86400]
    Emax = -57456,  // [s; days × 86400]
    EC50 = 0.412,  // [nM]
    gamma = 1,
    exposure_per_s = 1);   // 1 nM per second
  // imax_as_negative_emax: Imax (Q323) enters SigmoidEmaxSweep as −Emax
  // exposure_unit_unresolved: 'nM' — the x axis is in the paper's unit, not SI
  // defaulted: gamma
  annotation(experiment(StartTime = 0, StopTime = 4.2, Interval = 0.0084),
    Documentation(info = "<html><body><!-- drug-about --><h4>About atogepant</h4><p>Atogepant is a CGRP antagonist used to treat migraine. It is an approved medicine, authorised in the European Union for migraine disorders.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q76797798\">Wikidata Q76797798</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h4>Atogepant_Schlachter2026v2_PD_mmd</h4><p>The steady-state exposure-response curve of Schlachter L et al., <i>CPT: pharmacometrics &amp; systems pharmacology 15(1):e70154</i> 2026 (<a href=\"https://doi.org/10.1002/psp4.70154\">doi:10.1002/psp4.70154</a>) — Monthly migraine days [days] against atogepant nM — obtained by sweeping the driver instead of simulating a dose. Model family: emax.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    =      0.852 days     drug-free response (baseline) (Placebo effect, Q324)
  Emax  =      0.665 days     maximal effect term (Atogepant C min E max, Q323)
  EC50  =      0.412 nM       exposure at half of the maximal effect term (Atogepant C min EC50, Q321)
  gamma = (library default) Hill coefficient</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep\">SigmoidEmaxSweep</a>; this model only supplies the numbers. The x axis is one nM of atogepant per second of simulated time: there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 7.361e+04   (drug-free)
  exposure = EC50 (0.412 nM)  response 4.488e+04
  exposure -> infinity  response 1.616e+04</pre></body></html>"));
end Atogepant_Schlachter2026v2_PD_mmd;
