model Atogepant_Schlachter2026v2_PD_mmd
  "emax exposure-response sweep — Schlachter_2026_2 :: MMD (monthly migraine days)"
  extends Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep(
    E0 = 0,      // [1]
    Emax = -2.52870940756e-07,  // [1/s; counts/month × 3.80257e-07]
    EC50 = 0.412,  // [nM]
    gamma = 1,
    exposure_per_s = 1);   // 1 nM per second
  // imax_as_negative_emax: Imax (Q323) enters SigmoidEmaxSweep as −Emax
  // exposure_unit_unresolved: 'nM' — the x axis is in the paper's unit, not SI
  // defaulted: E0
  // defaulted: gamma
  annotation(experiment(StartTime = 0, StopTime = 4.2, Interval = 0.0084),
    Documentation(info = "<html><body><h4>Atogepant_Schlachter2026v2_PD_mmd</h4><p>The steady-state exposure-response curve of Schlachter L et al., <i>CPT: pharmacometrics &amp; systems pharmacology 15(1):e70154</i> 2026 (<a href=\"https://doi.org/10.1002/psp4.70154\">doi:10.1002/psp4.70154</a>) — monthly migraine days [counts/month] against atogepant nM — obtained by sweeping the driver instead of simulating a dose. Model family: emax.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = (library default) drug-free response (baseline)
  Emax  =      0.665 counts/month maximal effect term (Atogepant C min E max, Q323)
  EC50  =      0.412 nM       exposure at half of the maximal effect term (Atogepant C min EC50, Q321)
  gamma = (library default) Hill coefficient</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep\">SigmoidEmaxSweep</a>; this model only supplies the numbers. The x axis is one nM of atogepant per second of simulated time: there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0   (drug-free)
  exposure = EC50 (0.412 nM)  response -1.264e-07
  exposure -> infinity  response -2.529e-07</pre></body></html>"));
end Atogepant_Schlachter2026v2_PD_mmd;
