function p = Atogepant_Schlachter2026v2_PD_mmd_params()
% Atogepant_Schlachter2026v2_PD_mmd_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% atogepant Schlachter_2026_2::MMD: emax exposure-response sweep (response = E0 + Emax*frac). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one nM per second, in SI inside (kg/m3, s). Response MMD in days. Driver: atogepant (cited_pk).
p.E0 = 73612.8;
p.Emax = -57456.0;
p.EC50 = 0.412;
p.gamma = 1.0;
p.slope = 0.0;
p.exposure_per_s = 1.0;
p.stop_time = 4.2;
p.form = 'E0 + Emax*frac';
end
