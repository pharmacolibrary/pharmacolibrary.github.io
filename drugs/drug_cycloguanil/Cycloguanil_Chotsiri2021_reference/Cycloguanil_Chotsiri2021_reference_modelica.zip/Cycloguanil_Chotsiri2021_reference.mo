model Cycloguanil_Chotsiri2021_reference
  parameter Real Cl_ref = 1.3611111111111111e-05 "Cl [m3/s]";
  parameter Real Vd_ref = 2.19 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.251718,
    adminMass = 0.0001,
    ka = 0.0001388888888888889,
    Tlag = 0.0,
    k12 = 3.094875697615424e-05
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About cycloguanil</h4><p>Cycloguanil is an antimalarial agent belonging to the biguanide class, used to treat malaria. It is an approved drug, but it is not widely used on its own; it is mainly known as the active metabolite of proguanil.</p><p><small><b>Unverified</b> — written by glm-5.3-flash from general knowledge (no Wikidata entry found) and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>cycloguanil</td></tr><tr><td>population:</td><td>review reference</td></tr><tr><td>source_paper:</td><td>Chotsiri_2021</td></tr><tr><td>measured_compound:</td><td>cycloguanil</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_2C_enteral: apparent (/F) parameterization ⇒ extravascular dosing</td></tr><tr><td>molar_masses:</td><td>cycloguanil 251.718 g/mol (pubchem)</td></tr></table><p><b>Defaulted (base-class default used):</b> ka, Tlag, k21.</p><h4>Interpretation flags</h4><ul><li>built from REVIEW reference values (Chotsiri_2021) — secondary source</li><li>volume reported by review</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 604800, Tolerance = 1e-9, Interval = 1));
end Cycloguanil_Chotsiri2021_reference;
