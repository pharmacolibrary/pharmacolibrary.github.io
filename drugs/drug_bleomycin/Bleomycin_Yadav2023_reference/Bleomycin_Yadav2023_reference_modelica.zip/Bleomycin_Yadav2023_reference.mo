model Bleomycin_Yadav2023_reference
  parameter Real Cl_ref = 3.483796296296296e-09 "Cl [m3/s]";
  parameter Real Vd_ref = 0.0049070386425756314 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 1.415552,
    adminMass = 1e-05
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About bleomycin</h4><p>Bleomycin is a cytotoxic antibiotic used as an anticancer medicine to treat various types of cancer. It is an approved cancer drug, used in oncology treatment, and has also been investigated for other uses.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q105203558\">Wikidata Q105203558</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>bleomycin</td></tr><tr><td>population:</td><td>review reference</td></tr><tr><td>source_paper:</td><td>Yadav_2023</td></tr><tr><td>measured_compound:</td><td>bleomycin</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>bleomycin 1415.55 g/mol (drugbank)</td></tr></table><h4>Interpretation flags</h4><ul><li>built from REVIEW reference values (Yadav_2023) — secondary source</li><li>central volume derived from CL·t½/ln2</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 5443200, Tolerance = 1e-9, Interval = 1));
end Bleomycin_Yadav2023_reference;
