% Run (SimBiology): build model + dose, simulate 0..1512.0 h, plot.
p = Bleomycin_Yadav2023_reference_params();
[model, dose, variant] = build_sb_pk(p);
sd = simulate_sb(model, variant, dose, 1512.0);
