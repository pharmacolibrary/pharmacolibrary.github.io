model Bleomycin_Dresp1978_PD_s_cells_2
  "linear exposure-response sweep — Dresp_1978 :: S cells (S cells)"
  extends Pharmacolibrary.Interfaces.PartialExposureResponseSweep(
    E0 = 0.1974,      // [1; % × 0.01]
    Emax = 0, EC50 = 1,      // unused by a line
    exposure_per_s = 1e-09);
  parameter Real slope = 0.1   "[1]";
equation
  response = E0 + slope*exposure;
  annotation(experiment(StartTime = 0, StopTime = 1000, Interval = 2),
    Documentation(info = "<html><body><!-- drug-about --><h4>About bleomycin</h4><p>Bleomycin is a cytotoxic antibiotic used as an anticancer medicine to treat various types of cancer. It is an approved cancer drug, used in oncology treatment, and has also been investigated for other uses.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q105203558\">Wikidata Q105203558</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h4>Bleomycin_Dresp1978_PD_s_cells_2</h4><p>The steady-state exposure-response curve of Dresp J et al., <i>Mutation research 56(3):341–353</i> 1978 (<a href=\"https://doi.org/10.1016/0027-5107(78)90203-8\">doi:10.1016/0027-5107(78)90203-8</a>) — S cells [%] against bleomycin pg/ml — obtained by sweeping the driver instead of simulating a dose. Model family: linear.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    =      19.74 %        drug-free response (baseline) (intercept, Q324)
  slope =        0.1          change in response per unit of exposure (slope, Q335)</pre><p>The algebra is <code>response = E0 + slope*exposure</code>; this model only supplies the numbers. The x axis is one pg/ml of bleomycin per second of simulated time (exposure is in kg/m3): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0.1974   (drug-free)</pre></body></html>"));
end Bleomycin_Dresp1978_PD_s_cells_2;
