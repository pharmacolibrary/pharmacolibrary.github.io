function p = Bleomycin_Dresp1978_PD_dicentrics_params()
% Bleomycin_Dresp1978_PD_dicentrics_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% bleomycin Dresp_1978::dicentrics: linear exposure-response sweep (response = E0 + slope*exposure). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one pg/ml per second, in SI inside (kg/m3, s). Response dicentrics in per cell. Driver: bleomycin (dose_only).
p.E0 = 10.9;
p.Emax = 0.0;
p.EC50 = 1.0;
p.gamma = 1.0;
p.slope = 1.2;
p.exposure_per_s = 1e-09;
p.stop_time = 1000.0;
p.form = 'E0 + slope*exposure';
end
