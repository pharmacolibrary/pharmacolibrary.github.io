model Levomethadone_Gittel2021v2_reference
  parameter Real Cl_ref = 2.158333333333333e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.0301 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.309453,
    adminMass = 1e-05
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About levomethadone</h4><p>Levomethadone, the active isomer of methadone, is classified as a drug used in opioid dependence. It is currently considered investigational and is not an approved medicine in the European Union.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q6535776\">Wikidata Q6535776</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>levomethadone</td></tr><tr><td>population:</td><td>isoflurane-anaesthetized healthy adult ponies</td></tr><tr><td>source_paper:</td><td>Gittel_2021_2</td></tr><tr><td>measured_compound:</td><td>l-methadone</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>l-methadone 309.453 g/mol (drugbank); levomethadone 309.453 g/mol (drugbank)</td></tr></table><h4>Interpretation flags</h4><ul><li>unit_dimension_unknown: 'mL minute-1 kg-1' (CL)</li><li>implicit units: 'plasma clearance' → L/h (from the popPK convention: 'No unit stated in text or table caption/footnotes. Plasma (total) clearance in population PK is conventionally expressed')</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=l-methadone</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Levomethadone_Gittel2021v2_reference;
