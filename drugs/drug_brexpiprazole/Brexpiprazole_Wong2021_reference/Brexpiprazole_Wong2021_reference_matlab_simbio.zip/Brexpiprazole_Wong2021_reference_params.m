function p = Brexpiprazole_Wong2021_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: brexpiprazole   source: Wong_2021 / reference   route: oral
  % estimated (absent from source): ka
  p.name  = 'Brexpiprazole_Wong2021_reference_params';
  p.drug  = 'brexpiprazole';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 124.320061;                % central volume [L]
  p.CL = 1.799;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.5;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 0.25;             % dose [mg]
end
