// parent + metabolites (DM-3411, DM-3412): PK_3M_9C — formed from central; parent 2, metabolites [1, 2]
model Brexpiprazole_Frederiksen2023v3_reference
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_3M_9C(
    Vd1 = 0.08120000000000001,
    Vd2 = 0.040100000000000004,
    q12 = 1.9833333333333332e-07,
    q21 = 1.9833333333333332e-07,
    q1_m11 = 3.111111111111111e-07,
    q1_m21 = 6.222222222222222e-09,
    CL1 = 0.0,
    Vd1m1 = 0.00244,
    CLm1 = 9.25e-07,
    Vd1m2 = 0.000447,
    CLm2 = 1.1666666666666667e-07,
    Vd2m2 = 0.020399999999999998,
    qm21_m22 = 6e-07,
    qm22_m21 = 6e-07,
    MW = 0.43357,
    MW_m1 = 0.449569,
    MW_m2 = 0.467584,
    F = 0.9,
    ka = 0.00028333333333333335,
    Tlag = 1479.6,
    adminDuration = 600,
    adminCount = 1,
    adminMass = 1.5e-07
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>brexpiprazole</td></tr><tr><td>population:</td><td>healthy subjects and patients</td></tr><tr><td>source_paper:</td><td>Frederiksen_2023_3</td></tr><tr><td>measured_compound:</td><td>brexpiprazole</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>general_linear</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>cpt2791-tbl-0002</td></tr><tr><td>input:</td><td>PK_3M_9C: absorption rate constant reported; parent clearance = Σ formation clearances (no other elimination route); formation of DM-3411: CLfm; formation of DM-3412: CLfm; covariate effects NOT applied (target parameter ambiguous): CYP2D6</td></tr><tr><td>molar_masses:</td><td>brexpiprazole 433.57 g/mol (drugbank); DM-3411 449.569 g/mol (pubchem); DM-3412 467.584 g/mol (pubchem)</td></tr></table><p><b>Defaulted (base-class default used):</b> F.</p><h4>Interpretation flags</h4><ul><li>dropped duplicate Q49 ('Absorption rate constant fed', value '0.535') — already have one for this compound</li><li>unit_dimension_unknown: 'V2' (V1)</li><li>unit_dimension_unknown: 'V3' (V2)</li><li>unit_dimension_unknown: 'Q' (Q)</li><li>unit_dimension_unknown: 'CLM1' (CLfm)</li><li>unit_dimension_unknown: 'CLM2' (CLfm)</li><li>unit_dimension_unknown: 'V4' (V1)</li><li>unit_dimension_unknown: 'V5' (V2)</li><li>unit_dimension_unknown: 'QMET' (Q)</li><li>unit_dimension_unknown: 'CLMET1' (CL)</li><li>unit_dimension_unknown: 'V6' (V1)</li><li>unit_dimension_unknown: 'CLMET2' (CL)</li><li>dropped unlinked row (NIL): 'Body mass index on V6' — extend the ontology if this is a real PK parameter (source ['cpt2791-tbl-0002:row15:col1'])</li><li>implicit units: 'Absorption rate constant fasted' → 1/h (from the popPK convention: 'Absorption rate constants (ka) are first-order rate constants, conventionally expressed in 1/h. The value 1.02 is consis')</li><li>implicit units: 'Lag‐time' → h (from the popPK convention: 'Lag time (ALAG) is a time parameter, conventionally expressed in hours (h). The value 0.411 is consistent with this unit')</li><li>implicit units: 'Volume of distribution, brexpiprazole central compartment (V2)' → L (from the popPK convention: 'Volume of distribution (V2) is a volume parameter, conventionally expressed in liters (L). The value 81.2 is consistent ')</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Brexpiprazole_Frederiksen2023v3_reference;
