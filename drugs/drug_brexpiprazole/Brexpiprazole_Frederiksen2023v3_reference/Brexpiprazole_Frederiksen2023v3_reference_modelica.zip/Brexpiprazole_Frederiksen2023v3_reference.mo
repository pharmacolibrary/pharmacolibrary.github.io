// parent + metabolites (DM-3411, DM-3412): PK_3M_9C — formed from central; parent 2, metabolites [1, 2]
model Brexpiprazole_Frederiksen2023v3_reference
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_3M_9C(
    Vd1 = 0.08120000000000001,
    Vd2 = 0.040100000000000004,
    q12 = 1.9833333333333332e-07,
    q21 = 1.9833333333333332e-07,
    q1_m11 = 3.111111111111111e-07,
    q1_m21 = 6.222222222222222e-09,
    CL1 = 0.0,
    Vd1m1 = 0.00244,
    CLm1 = 9.25e-07,
    Vd1m2 = 0.000447,
    CLm2 = 1.1666666666666667e-07,
    Vd2m2 = 0.020399999999999998,
    qm21_m22 = 6e-07,
    qm22_m21 = 6e-07,
    MW = 0.43357,
    MW_m1 = 0.449569,
    MW_m2 = 0.0,
    F = 0.9,
    ka = 0.00028333333333333335,
    Tlag = 1479.6,
    adminDuration = 600,
    adminCount = 1,
    adminMass = 1.5e-07
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About brexpiprazole</h4><p>Brexpiprazole is an antipsychotic used to treat schizophrenia, and has also been studied for conditions such as anxiety, psychosis and schizoaffective disorder. It is an approved medicine, authorised in the European Union for schizophrenia.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q2924764\">Wikidata Q2924764</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>brexpiprazole</td></tr><tr><td>population:</td><td>healthy subjects and patients</td></tr><tr><td>source_paper:</td><td>Frederiksen_2023_3</td></tr><tr><td>measured_compound:</td><td>brexpiprazole</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>general_linear</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>cpt2791-tbl-0002</td></tr><tr><td>input:</td><td>PK_3M_9C: absorption rate constant reported; parent clearance = Σ formation clearances (no other elimination route); formation of DM-3411: CLfm; formation of DM-3412: CLfm; molar mass not resolved for DM-3412 — set to 0: no molar concentration, formation converts mass 1:1; dose 0.15 mg (paper)</td></tr><tr><td>molar_masses:</td><td>DM-3411 449.569 g/mol (pubchem); brexpiprazole 433.57 g/mol (drugbank)</td></tr></table><p><b>Defaulted (base-class default used):</b> F.</p><h4>Interpretation flags</h4><ul><li>table section iiv: 'Absorption rate constant fasted' routed out of structural estimates ('IIV (%RSE)')</li><li>table section iiv: 'Absorption rate constant fed' routed out of structural estimates ('IIV (%RSE)')</li><li>table section iiv: 'Volume of distribution, brexpiprazole central compartment (V2)' routed out of structural estimates ('IIV (%RSE)')</li><li>table section iiv: 'Volume of distribution, brexpiprazole peripheral compartment (V3)' routed out of structural estimates ('IIV (%RSE)')</li><li>table section iiv: 'Clearance from brexpiprazole to DM‐3412 (CLM1)' routed out of structural estimates ('IIV (%RSE)')</li><li>table section iiv: 'Clearance from brexpiprazole to DM‐3411 (CLM2)' routed out of structural estimates ('IIV (%RSE)')</li><li>table section iiv: 'Volume of distribution, DM‐3412 central compartment (V4)' routed out of structural estimates ('IIV (%RSE)')</li><li>table section iiv: 'Clearance from DM‐3412 central compartment (CLMET1)' routed out of structural estimates ('IIV (%RSE)')</li><li>table section iiv: 'Volume of distribution, DM‐3411 central compartment (V6)' routed out of structural estimates ('IIV (%RSE)')</li><li>table section iiv: 'Clearance from DM‐3411 central compartment (CLMET2)' routed out of structural estimates ('IIV (%RSE)')</li><li>unit_dimension_unknown: 'V2' (V1)</li><li>unit_dimension_unknown: 'V3' (V2)</li><li>unit_dimension_unknown: 'Q' (Q)</li><li>unit_dimension_unknown: 'CLM1' (CLfm)</li><li>unit_dimension_unknown: 'CLM2' (CLfm)</li><li>unit_dimension_unknown: 'V4' (V1)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Brexpiprazole_Frederiksen2023v3_reference;
