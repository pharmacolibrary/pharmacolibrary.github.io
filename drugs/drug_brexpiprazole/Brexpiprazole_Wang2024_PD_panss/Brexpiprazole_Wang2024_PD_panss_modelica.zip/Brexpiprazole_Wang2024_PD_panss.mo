model Brexpiprazole_Wang2024_PD_panss
  "emax exposure-response sweep — Wang_2024 :: PANSS (PANSS total score change from baseline)"
  extends Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep(
    E0 = 94,      // [1]
    Emax = -0.173,  // [1]
    EC50 = 3.87e-06,  // [kg/m3; ng/mL × 1e-06]
    gamma = 1,
    exposure_per_s = 1e-06);   // 1 ng/mL per second
  // family_inferred: the record's model family is disease_progression; read from the parameters: Emax/Imax and EC50/IC50 without a Hill coefficient — Emax
  // imax_as_negative_emax: Imax (Q323) enters SigmoidEmaxSweep as −Emax
  // defaulted: gamma
  annotation(experiment(StartTime = 0, StopTime = 39, Interval = 0.078),
    Documentation(info = "<html><body><!-- drug-about --><h4>About brexpiprazole</h4><p>Brexpiprazole is an antipsychotic used to treat schizophrenia, and has also been studied for conditions such as anxiety, psychosis and schizoaffective disorder. It is an approved medicine, authorised in the European Union for schizophrenia.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q2924764\">Wikidata Q2924764</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h4>Brexpiprazole_Wang2024_PD_panss</h4><p>The steady-state exposure-response curve of Wang X et al., <i>Journal of clinical pharmacology 64(10):1236–1245</i> 2024 (<a href=\"https://doi.org/10.1002/jcph.2464\">doi:10.1002/jcph.2464</a>) — PANSS total score change from baseline against brexpiprazole ng/mL — obtained by sweeping the driver instead of simulating a dose. Model family: emax.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    =         94          drug-free response (baseline) (Baseline PANSS total score, Q324)
  Emax  =      0.173          maximal effect term (Maximum drug effect, Q323)
  EC50  =       3.87 ng/mL    exposure at half of the maximal effect term (EC 50, Q321)
  gamma = (library default) Hill coefficient</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep\">SigmoidEmaxSweep</a>; this model only supplies the numbers. The x axis is one ng/mL of brexpiprazole per second of simulated time (exposure is in kg/m3): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 94   (drug-free)
  exposure = EC50 (3.87 ng/mL)  response 93.91
  exposure -> infinity  response 93.83</pre></body></html>"));
end Brexpiprazole_Wang2024_PD_panss;
