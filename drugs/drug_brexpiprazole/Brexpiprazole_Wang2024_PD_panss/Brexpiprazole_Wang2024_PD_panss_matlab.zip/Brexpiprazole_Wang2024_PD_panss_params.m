function p = Brexpiprazole_Wang2024_PD_panss_params()
% Brexpiprazole_Wang2024_PD_panss_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% brexpiprazole Wang_2024::PANSS: emax exposure-response sweep (response = E0 + Emax*frac). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one ng/mL per second, in SI inside (kg/m3, s). Response PANSS in its own unit. Driver: brexpiprazole (cited_pk).
p.E0 = 94.0;
p.Emax = -0.173;
p.EC50 = 3.87e-06;
p.gamma = 1.0;
p.slope = 0.0;
p.exposure_per_s = 1e-06;
p.stop_time = 39.0;
p.form = 'E0 + Emax*frac';
end
