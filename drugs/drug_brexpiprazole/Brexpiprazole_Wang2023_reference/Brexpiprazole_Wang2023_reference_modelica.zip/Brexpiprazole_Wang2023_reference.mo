model Brexpiprazole_Wang2023_reference
  parameter Real Cl_ref = 3.722222222222222e-07 "Cl [m3/s]";
  parameter Real Vd_ref = 0.078 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C_enteral(
    weight = 70.0,
    F = 0.9,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.43357,
    adminMass = 1e-06,
    ka = 0.0004138888888888889,
    Tlag = 0.0,
    k12 = 3.005698005698006e-06,
    k21 = 8.525252525252525e-06
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>brexpiprazole</td></tr><tr><td>population:</td><td>adults, adolescents, and children with CNS disorders</td></tr><tr><td>source_paper:</td><td>Wang_2023</td></tr><tr><td>measured_compound:</td><td>brexpiprazole</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>tab_1</td></tr><tr><td>input:</td><td>PK_2C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>brexpiprazole 433.57 g/mol (drugbank)</td></tr></table><p><b>Defaulted (base-class default used):</b> F, Tlag.</p><h4>Interpretation flags</h4><ul><li>dropped duplicate Q22 ('CL_weight', value '0.75') — already have one for this compound</li><li>dropped unlinked row (NIL): 'V_weight' — extend the ontology if this is a real PK parameter (source ['tab_1:row12:col1', 'tab_1:row12:col2'])</li><li>dropped unlinked row (NIL): 'Error 1' — extend the ontology if this is a real PK parameter (source ['tab_1:row20:col2', 'tab_1:row20:col3'])</li><li>dropped unlinked row (NIL): 'Error 2' — extend the ontology if this is a real PK parameter (source ['tab_1:row21:col2', 'tab_1:row21:col3'])</li><li>implicit units: 'k a (1/h)' → 1/h (from the popPK convention: 'The parameter is the absorption rate constant (ka). In population pharmacokinetics, first-order rate constants are conve')</li><li>apparent-by-design (ADVISORY, codes unchanged): extravascular dosing with no identifiable F, so these reported disposition parameters are likely apparent unless the model puts first-pass in its structure — Q22 (CL (L/h)); Q63 (V c (L)); Q30 (Q (L/h)); Q64 (V p (L))</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=brexpiprazole</li><li>skipped review gap-fill of TLAG: primary's parameterization (rate-constant / ka-only) does not use it</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 777600, Tolerance = 1e-9, Interval = 1));
end Brexpiprazole_Wang2023_reference;
