function p = Brexpiprazole_Wong2021_PD_occupancy_params()
% Brexpiprazole_Wong2021_PD_occupancy_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% brexpiprazole Wong_2021::occupancy: emax exposure-response sweep (response = E0 + Emax*frac). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one ng/mL per second, in SI inside (kg/m3, s). Response occupancy in %. Driver: brexpiprazole (pk_record).
p.E0 = 0.0;
p.Emax = 0.892;
p.EC50 = 8.13e-06;
p.gamma = 1.0;
p.slope = 0.0;
p.exposure_per_s = 1e-06;
p.stop_time = 82.0;
p.form = 'E0 + Emax*frac';
end
