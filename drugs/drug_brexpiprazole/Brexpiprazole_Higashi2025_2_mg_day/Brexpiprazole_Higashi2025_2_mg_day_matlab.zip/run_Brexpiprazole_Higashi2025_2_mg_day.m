% Run: build params, simulate 0..312.0 h, plot + save Brexpiprazole_Higashi2025_2_mg_day.png/.csv/.json.
% Interactive display (keep the window open):  octave --persist run_Brexpiprazole_Higashi2025_2_mg_day.m
here = fileparts(mfilename('fullpath'));
p = Brexpiprazole_Higashi2025_2_mg_day_params();
out = simulate_pk(p, 0:0.05:312.0);

% figure (shown on screen if interactive) and PNG (works in MATLAB and Octave)
fig = figure; plot(out.t, out.C, 'LineWidth', 1.5); grid on;
xlabel('time [h]'); ylabel('central concentration [mg/L]');
title('brexpiprazole — Higashi_2025 (oral)');
print(fig, fullfile(here, 'Brexpiprazole_Higashi2025_2_mg_day.png'), '-dpng', '-r150');

% CSV (time_h, Cc_mg_per_L)
fid = fopen(fullfile(here, 'Brexpiprazole_Higashi2025_2_mg_day.csv'), 'w');
fprintf(fid, 'time_h,Cc_mg_per_L\n');
fprintf(fid, '%.10g,%.10g\n', [out.t(:), out.C(:)].');
fclose(fid);

% JSON (summary + arrays; jsonencode with a manual fallback for older versions)
fid = fopen(fullfile(here, 'Brexpiprazole_Higashi2025_2_mg_day.json'), 'w');
try
  s.model = 'Brexpiprazole_Higashi2025_2_mg_day'; s.Cmax = out.Cmax; s.Tmax = out.Tmax; s.AUC = out.AUC;
  s.time_h = out.t(:).'; s.Cc_mg_per_L = out.C(:).';
  fprintf(fid, '%s', jsonencode(s));
catch
  fprintf(fid, '{"model":"Brexpiprazole_Higashi2025_2_mg_day","Cmax":%g,"Tmax":%g,"AUC":%g}', out.Cmax, out.Tmax, out.AUC);
end
fclose(fid);

fprintf('Cmax=%.3g mg/L  Tmax=%.3g h  AUC=%.3g mg*h/L\n', out.Cmax, out.Tmax, out.AUC);
fprintf('wrote Brexpiprazole_Higashi2025_2_mg_day.png, Brexpiprazole_Higashi2025_2_mg_day.csv, Brexpiprazole_Higashi2025_2_mg_day.json\n');
