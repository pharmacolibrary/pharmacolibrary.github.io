function p = Brexpiprazole_Higashi2025_2_mg_day_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: brexpiprazole   source: Higashi_2025 / 2_mg_day   route: oral
  % estimated (absent from source): ka
  p.name  = 'Brexpiprazole_Higashi2025_2_mg_day_params';
  p.drug  = 'brexpiprazole';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 63.0;                % central volume [L]
  p.CL = 0.74;                % clearance [L/h]
  p.Vp = [24.6];             % peripheral volumes [L]
  p.Q  = [1.0];             % inter-compartmental clearances [L/h]
  p.ka = 0.5;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 0.2;             % dose [mg]
end
