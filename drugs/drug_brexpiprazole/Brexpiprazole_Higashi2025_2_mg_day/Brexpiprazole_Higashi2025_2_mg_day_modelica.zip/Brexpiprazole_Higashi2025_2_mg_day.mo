model Brexpiprazole_Higashi2025_2_mg_day
  parameter Real Cl_ref = 2.0555555555555556e-07 "Cl [m3/s]";
  parameter Real Vd_ref = 0.063 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.43357,
    adminMass = 2.0000000000000002e-07,
    ka = 0.0001388888888888889,
    Tlag = 0.0,
    k12 = 4.409171075837742e-06,
    k21 = 1.129177958446251e-05
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About brexpiprazole</h4><p>Brexpiprazole is an antipsychotic used to treat schizophrenia, and has also been studied for conditions such as anxiety, psychosis and schizoaffective disorder. It is an approved medicine, authorised in the European Union for schizophrenia.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q2924764\">Wikidata Q2924764</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>brexpiprazole</td></tr><tr><td>population:</td><td>Japanese healthy subjects and patients with schizophrenia</td></tr><tr><td>source_paper:</td><td>Higashi_2025</td></tr><tr><td>measured_compound:</td><td>brexpiprazole</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>tab_2</td></tr><tr><td>input:</td><td>PK_2C_enteral: apparent (/F) parameterization ⇒ extravascular dosing</td></tr><tr><td>molar_masses:</td><td>brexpiprazole 433.57 g/mol (drugbank)</td></tr></table><p><b>Defaulted (base-class default used):</b> ka, Tlag.</p><h4>Interpretation flags</h4><ul><li>table section iiv: 'shrinkage of BSV for CL/F' routed out of structural estimates ('The shrinkage of BSV for CL/F, Vc/F, and KTR were estimated at 2.1%, 18.9%, and 50.0%, respectively (Figure S6).')</li><li>table section iiv: 'shrinkage of BSV for Vc/F' routed out of structural estimates ('The shrinkage of BSV for CL/F, Vc/F, and KTR were estimated at 2.1%, 18.9%, and 50.0%, respectively (Figure S6).')</li><li>table section iiv: 'shrinkage of BSV for KTR' routed out of structural estimates ('The shrinkage of BSV for CL/F, Vc/F, and KTR were estimated at 2.1%, 18.9%, and 50.0%, respectively (Figure S6).')</li><li>salvaged Q27 ('CL/F (intermediate metabolisers)'=0.74) from results prose — parameter table was unreadable</li><li>salvaged Q69 ('Q/F'=1.0) from results prose — parameter table was unreadable</li><li>salvaged Q290 ('Vc/F'=63.0) from results prose — parameter table was unreadable</li><li>salvaged Q82 ('Vp/F'=24.6) from results prose — parameter table was unreadable</li><li>implicit units: 'AUC 0-24,ss' → ng·h/mL (from the popPK convention: &quot;Paper reports trough concentrations in ng/mL (e.g., '38.5 (10.5-87.0) and 77.1 (22.4-173) ng/mL'), so AUC at steady stat&quot;)</li><li>implicit units: 'C max,ss' → ng/mL (from the paper text: &quot;Paper states trough plasma concentrations in ng/mL: '38.5 (10.5-87.0) and 77.1 (22.4-173) ng/mL at doses of 1 and 2 mg/d&quot;)</li><li>implicit units: 'C trough,ss' → ng/mL (from the paper text: &quot;Paper states trough plasma concentrations in ng/mL: '38.5 (10.5-87.0) and 77.1 (22.4-173) ng/mL at doses of 1 and 2 mg/d&quot;)</li><li>apparent-ness (ontology-grounded): parameterization=apparent, measured_compound=brexpiprazole</li><li>held at status:extracted — NIL link or unit issue (mismatch/unknown/normalisation-failed) present</li><li>model equation 'eGFR = 194 * (Scr/0.7)^-1.209 * (Age/0.993)^-1.094' not bound — neither LHS nor base term 'Scr' linked to an ontology parameter</li><li>status held at route_to_review — not promoted</li><li>population split: '2 mg/day' subgroup of Higashi_2025 (paper reports 2 populations: 1 mg/day, 2 mg/day)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 1123200, Tolerance = 1e-9, Interval = 1));
end Brexpiprazole_Higashi2025_2_mg_day;
