model Brexpiprazole_Wong2021_PD_occupancy_2
  "emax exposure-response sweep — Wong_2021 :: occupancy (Striatal D2/D3 receptor occupancy (caudate nucleus))"
  extends Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep(
    E0 = 0,      // [1]
    Emax = -0.954,  // [1; % × 0.01]
    EC50 = 7.75e-06,  // [kg/m3; ng/mL × 1e-06]
    gamma = 1,
    exposure_per_s = 1e-06);   // 1 ng/mL per second
  // imax_as_negative_emax: Imax (Q323) enters SigmoidEmaxSweep as −Emax
  // defaulted: E0
  // defaulted: gamma
  annotation(experiment(StartTime = 0, StopTime = 78, Interval = 0.156),
    Documentation(info = "<html><body><!-- drug-about --><h4>About brexpiprazole</h4><p>Brexpiprazole is an antipsychotic used to treat schizophrenia, and has also been studied for conditions such as anxiety, psychosis and schizoaffective disorder. It is an approved medicine, authorised in the European Union for schizophrenia.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q2924764\">Wikidata Q2924764</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h4>Brexpiprazole_Wong2021_PD_occupancy_2</h4><p>The steady-state exposure-response curve of Wong DF et al., <i>European journal of clinical pharmacology 77(5):717–725</i> 2021 (<a href=\"https://doi.org/10.1007/s00228-020-03021-9\">doi:10.1007/s00228-020-03021-9</a>) — Striatal D2/D3 receptor occupancy (caudate nucleus) [%] against brexpiprazole ng/mL — obtained by sweeping the driver instead of simulating a dose. Model family: emax.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = (library default) drug-free response (baseline)
  Emax  =       95.4 %        maximal effect term (Omax, Q323)
  EC50  =       7.75 ng/mL    exposure at half of the maximal effect term (EC50, Q321)
  gamma = (library default) Hill coefficient</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep\">SigmoidEmaxSweep</a>; this model only supplies the numbers. The x axis is one ng/mL of brexpiprazole per second of simulated time (exposure is in kg/m3): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0   (drug-free)
  exposure = EC50 (7.75 ng/mL)  response -0.477
  exposure -> infinity  response -0.954</pre></body></html>"));
end Brexpiprazole_Wong2021_PD_occupancy_2;
