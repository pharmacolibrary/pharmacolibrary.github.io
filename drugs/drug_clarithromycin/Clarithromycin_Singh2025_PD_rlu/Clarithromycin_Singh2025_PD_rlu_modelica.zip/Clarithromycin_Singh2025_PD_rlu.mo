model Clarithromycin_Singh2025_PD_rlu
  "sigmoid_emax exposure-response sweep — Singh_2025 :: RLU (relative light units)"
  extends Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep(
    E0 = 6.07,      // [log10 RLU]
    Emax = -2.66,  // [log10 RLU]
    EC50 = 0.0002,  // [kg/m3; mg/L × 0.001]
    gamma = 1.46,
    exposure_per_s = 0.001);   // 1 mg/L per second
  // imax_as_negative_emax: Imax (Q323) enters SigmoidEmaxSweep as −Emax
  annotation(experiment(StartTime = 0, StopTime = 2, Interval = 0.004),
    Documentation(info = "<html><body><h4>Clarithromycin_Singh2025_PD_rlu</h4><p>The steady-state exposure-response curve of Singh S et al., <i>Antimicrobial agents and chemotherapy 69(5):e0002925</i> 2025 (<a href=\"https://doi.org/10.1128/aac.00029-25\">doi:10.1128/aac.00029-25</a>) — relative light units [log10 RLU] against clarithromycin mg/L — obtained by sweeping the driver instead of simulating a dose. Model family: sigmoid_emax.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    =       6.07 log10 RLU drug-free response (baseline) (Econ, Q324)
  Emax  =       2.66 log10 RLU maximal effect term (Emax, Q323)
  EC50  =        0.2 mg/L     exposure at half of the maximal effect term (EC50, Q322)
  gamma =       1.46          Hill coefficient (H, Q325)</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep\">SigmoidEmaxSweep</a>; this model only supplies the numbers. The x axis is one mg/L of clarithromycin per second of simulated time (exposure is in kg/m3): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 6.07   (drug-free)
  exposure = EC50 (0.2 mg/L)  response 4.74
  exposure -> infinity  response 3.41</pre></body></html>"));
end Clarithromycin_Singh2025_PD_rlu;
