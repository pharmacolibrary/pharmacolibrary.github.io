function p = Clarithromycin_Singh2025_PD_rlu_params()
% Clarithromycin_Singh2025_PD_rlu_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% clarithromycin Singh_2025::RLU: sigmoid_emax exposure-response sweep (response = E0 + Emax*frac). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one mg/L per second, in SI inside (kg/m3, s). Response RLU in log10 RLU. Driver: clarithromycin (cited_pk).
p.E0 = 6.07;
p.Emax = -2.66;
p.EC50 = 0.00019999999999999998;
p.gamma = 1.46;
p.slope = 0.0;
p.exposure_per_s = 0.001;
p.stop_time = 2.0;
p.form = 'E0 + Emax*frac';
end
