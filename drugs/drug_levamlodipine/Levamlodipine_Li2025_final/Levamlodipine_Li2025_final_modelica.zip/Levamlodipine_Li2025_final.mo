model Levamlodipine_Li2025_final
  parameter Real Cl_ref = 1.6558333333333334e-05 "Cl [m3/s]";
  parameter Real Vd_ref = 3.572 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 0.9,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.5670499999999999,
    adminMass = 2.5e-06,
    ka = 0.00021944444444444444,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>levamlodipine</td></tr><tr><td>population:</td><td>smoking patients</td></tr><tr><td>source_paper:</td><td>Li_2025</td></tr><tr><td>measured_compound:</td><td>levamlodipine besylate</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>t0006</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>levamlodipine 408.88 g/mol (drugbank); levamlodipine besylate 567.05 g/mol (pubchem)</td></tr></table><p><b>Defaulted (base-class default used):</b> F, Tlag.</p><h4>Interpretation flags</h4><ul><li>dropped PD-category row 'tvIC50' → Q322 (IC50, category G11) — pharmacodynamic parameters belong to scholarpd, not the PK model (source ['t0006:row5:col1', 't0006:row5:col2', 't0006:row5:col3'])</li><li>dropped PD-category row 'tvE0' → Q324 (E0, category G11) — pharmacodynamic parameters belong to scholarpd, not the PK model (source ['t0006:row6:col1', 't0006:row6:col2', 't0006:row6:col3'])</li><li>dropped PD-category row 'tvImax' → Q323 (Imax, category G11) — pharmacodynamic parameters belong to scholarpd, not the PK model (source ['t0006:row7:col1', 't0006:row7:col2', 't0006:row7:col3'])</li><li>dropped unlinked row (NIL): 'dCldUA' — extend the ontology if this is a real PK parameter (source ['t0006:row8:col1', 't0006:row8:col2', 't0006:row8:col3'])</li><li>dropped unlinked row (NIL): 'dCldeGFR' — extend the ontology if this is a real PK parameter (source ['t0006:row9:col1', 't0006:row9:col2', 't0006:row9:col3'])</li><li>routed 'stdev0' → Q315 (sigma) to residual_error — variability estimate, not a structural parameter</li><li>dropped unlinked row (NIL): 'Covariate model' — extend the ontology if this is a real PK parameter (source ['Li_2025_table_5:row0:col2'])</li><li>implicit units: 'tvKa' → 1/h (from the popPK convention: 'The parameter tvKa is the absorption rate constant. In population pharmacokinetic modeling, first-order rate constants a')</li><li>implicit units: 'tvV' → L (from the paper text: &quot;The paper text states: 'Typical values of the model with the inclusion of covariates were altered compared to the base m&quot;)</li><li>implicit units: 'tvCl' → L/h (from the paper text: &quot;The paper text states: 'Typical values of the model with the inclusion of covariates were altered compared to the base m&quot;)</li><li>apparent-by-design (ADVISORY, codes unchanged): extravascular dosing with no identifiable F, so these reported disposition parameters are likely apparent unless the model puts first-pass in its structure — Q61 (tvV); Q22 (tvCl)</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=levamlodipine besylate</li><li>model-stage split: 'final' is the final model of Li_2025 (paper reports 2 stages: base, final); same population, different model-building step</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 777600, Tolerance = 1e-9, Interval = 1));
end Levamlodipine_Li2025_final;
