function p = Levamlodipine_Li2025_base_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: levamlodipine   source: Li_2025 / base   route: oral
  % estimated (absent from source): F
  p.name  = 'Levamlodipine_Li2025_base_params';
  p.drug  = 'levamlodipine';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 3572.0;                % central volume [L]
  p.CL = 59.61;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.79;                % absorption rate [1/h]
  p.F  = 0.9;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 2.5;             % dose [mg]
end
