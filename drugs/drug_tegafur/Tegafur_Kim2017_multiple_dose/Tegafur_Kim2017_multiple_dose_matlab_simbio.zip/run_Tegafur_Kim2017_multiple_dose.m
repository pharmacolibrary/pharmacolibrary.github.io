% Run (SimBiology): build model + dose, simulate 0..72.0 h, plot.
p = Tegafur_Kim2017_multiple_dose_params();
[model, dose, variant] = build_sb_pk(p);
sd = simulate_sb(model, variant, dose, 72.0);
