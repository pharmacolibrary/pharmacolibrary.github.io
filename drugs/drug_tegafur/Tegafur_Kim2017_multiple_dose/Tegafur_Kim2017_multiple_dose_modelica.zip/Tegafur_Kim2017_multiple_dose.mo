model Tegafur_Kim2017_multiple_dose
  parameter Real Cl_ref = 2.1e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.035 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.200169,
    adminMass = 0.00035,
    ka = 2.2222222222222223e-05,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About tegafur</h4><p>Tegafur is an antineoplastic antimetabolite, a pyrimidine analogue used to treat cancer. It is an approved medicine, though it is not authorised in the European Union.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q413370\">Wikidata Q413370</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>tegafur</td></tr><tr><td>population:</td><td>rats</td></tr><tr><td>source_paper:</td><td>Kim_2017</td></tr><tr><td>measured_compound:</td><td>tegafur</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>molecules-22-01488-t002</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>5-FU 130.078 g/mol (pubchem); tegafur 200.169 g/mol (pubchem)</td></tr></table><p><b>Defaulted (base-class default used):</b> Tlag.</p><h4>Interpretation flags</h4><ul><li>dropped unlinked row (NIL): 'Tegafur' — extend the ontology if this is a real PK parameter (source ['Kim_2017_table_1:row1:col4', 'Kim_2017_table_1:row1:col5'])</li><li>dropped unlinked row (NIL): '5-FU' — extend the ontology if this is a real PK parameter (source ['Kim_2017_table_1:row8:col4', 'Kim_2017_table_1:row8:col5'])</li><li>dropped unlinked row (NIL): 'Gimeracil' — extend the ontology if this is a real PK parameter (source ['Kim_2017_table_1:row14:col4', 'Kim_2017_table_1:row14:col5'])</li><li>apparent-ness (ontology-grounded): parameterization=apparent, measured_compound=tegafur</li><li>template fit: PK_3M_3C — first-pass formation; parent 1 + hepatic, metabolites [0] (site presystemic: 'To determine the effect of SDT multiple dose pretreatment, the oral absorption rate of tegafur (Ka), metabolic conversio')</li><li>population split: 'multiple dose' subgroup of Kim_2017 (paper reports 3 populations: multiple dose, population mean (bsv), single dose)</li><li>row roles: 2 per-group rows of tegafur absorption_rate_constant but 0 reference group(s) — kept as printed</li><li>row roles: 2 per-group rows of 5-FU formation_rate_constant but 0 reference group(s) — kept as printed</li><li>row roles: 2 per-group rows of 5-FU clearance but 0 reference group(s) — kept as printed</li><li>row roles (LLM): model_class=compartmental; 26/26 row label(s) assigned, 24 linked by role; re-tagged parent→5-FU ×22, parent→gimeracil ×5</li><li>skipped review gap-fill of V2: primary is PARENT_METABOLITE (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is PARENT_METABOLITE (peripheral family needs ≥2C)</li><li>gap-filled Q49 (kabs) from Zuo_2024's review values (primary lacked it)</li><li>engineer: parent → metabolite not buildable on PK_3M_9C (None) — the measured compound's 1-compartment model instead</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 259200, Tolerance = 1e-9, Interval = 1));
end Tegafur_Kim2017_multiple_dose;
