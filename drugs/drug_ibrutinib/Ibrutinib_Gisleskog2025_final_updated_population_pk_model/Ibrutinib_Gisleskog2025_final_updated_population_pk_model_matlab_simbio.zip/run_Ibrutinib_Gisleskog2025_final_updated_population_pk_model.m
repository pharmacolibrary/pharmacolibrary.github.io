% Run (SimBiology): build model + dose, simulate 0..27.0 h, plot.
p = Ibrutinib_Gisleskog2025_final_updated_population_pk_model_params();
[model, dose, variant] = build_sb_pk(p);
sd = simulate_sb(model, variant, dose, 27.0);
