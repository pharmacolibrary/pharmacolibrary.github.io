function p = Ibrutinib_Gisleskog2025_previous_population_pk_model_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: ibrutinib   source: Gisleskog_2025 / previous_population_pk_model   route: oral
  p.name  = 'Ibrutinib_Gisleskog2025_previous_population_pk_model_params';
  p.drug  = 'ibrutinib';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 7286.0;                % central volume [L]
  p.CL = 1100.0;                % clearance [L/h]
  p.Vp = [436.0];             % peripheral volumes [L]
  p.Q  = [709.0];             % inter-compartmental clearances [L/h]
  p.ka = 0.451;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.226;             % absorption lag [h]
  p.dose = 560.0;             % dose [mg]
end
