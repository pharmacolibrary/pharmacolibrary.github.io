% Run (SimBiology): build model + dose, simulate 0..30.0 h, plot.
p = Ibrutinib_Gisleskog2025_previous_population_pk_model_params();
[model, dose, variant] = build_sb_pk(p);
sd = simulate_sb(model, variant, dose, 30.0);
