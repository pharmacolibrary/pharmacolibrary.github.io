model Ibrutinib_Ibrahim2023_PD_pbtk
  "indirect_response_i exposure-response sweep — Ibrahim_2023 :: pBtk (phosphorylated Btk)"
  extends Pharmacolibrary.Interfaces.PartialExposureResponseSweep(
    E0 = 1,      // [1; % × 0.01]
    Emax = 1,  // type I effect term
    EC50 = 34.1,  // [h∙ng∙mL−1]
    gamma = 1,
    exposure_per_s = 1);   // 1 h∙ng∙mL−1 per second
equation
  response = E0*(1 - Emax*frac);   // steady state, indirect response type I
  // exposure_unit_unresolved: 'h∙ng∙mL−1' — the x axis is in the paper's unit, not SI
  // defaulted: Emax
  // defaulted: gamma
  annotation(experiment(StartTime = 0, StopTime = 350, Interval = 0.7),
    Documentation(info = "<html><body><!-- drug-about --><h4>About ibrutinib</h4><p>Ibrutinib is a Bruton's tyrosine kinase inhibitor used to treat B-cell blood cancers such as chronic lymphocytic leukemia, mantle cell lymphoma, and other lymphomas. It is an approved medicine, authorised in the European Union, and is widely used in oncology care.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q5984881\">Wikidata Q5984881</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h4>Ibrutinib_Ibrahim2023_PD_pbtk</h4><p>The steady-state exposure-response curve of Ibrahim EIK et al., <i>CPT: pharmacometrics &amp; systems pharmacology 12(9):1305–1318</i> 2023 (<a href=\"https://doi.org/10.1002/psp4.13010\">doi:10.1002/psp4.13010</a>) — phosphorylated Btk [%] against ibrutinib h∙ng∙mL−1 — obtained by sweeping the driver instead of simulating a dose. Model family: indirect_response_i.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    =        100 %        drug-free response (baseline) (pBTKbaseline, Q324)
  Emax  = (library default) maximal effect term
  EC50  =       34.1 h∙ng∙mL−1 exposure at half of the maximal effect term (IAUC50,pBTK, Q322)
  gamma = (library default) Hill coefficient</pre><p>The algebra is <code>response = E0*(1 - Emax*frac)</code>; this model only supplies the numbers. The x axis is one h∙ng∙mL−1 of ibrutinib per second of simulated time: there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 1   (drug-free)
  exposure = EC50 (34.1 h∙ng∙mL−1)  response 0.5
  exposure -> infinity  response 0</pre></body></html>"));
end Ibrutinib_Ibrahim2023_PD_pbtk;
