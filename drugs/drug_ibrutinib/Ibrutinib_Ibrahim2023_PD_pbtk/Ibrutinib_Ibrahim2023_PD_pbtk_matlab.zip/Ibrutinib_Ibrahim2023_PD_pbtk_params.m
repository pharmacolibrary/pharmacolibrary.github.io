function p = Ibrutinib_Ibrahim2023_PD_pbtk_params()
% Ibrutinib_Ibrahim2023_PD_pbtk_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% ibrutinib Ibrahim_2023::pBtk: indirect_response_i exposure-response sweep (response = E0*(1 - Emax*frac)). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one h∙ng∙mL−1 per second, in SI inside (kg/m3, s). Response pBtk in %. Driver: ibrutinib (cited_pk).
p.E0 = 1.0;
p.Emax = 1.0;
p.EC50 = 34.1;
p.gamma = 1.0;
p.slope = 0.0;
p.exposure_per_s = 1.0;
p.stop_time = 350.0;
p.form = 'E0*(1 - Emax*frac)';
end
