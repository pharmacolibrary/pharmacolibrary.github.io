model Tolterodine_Sano2023_PD_mcc
  "emax exposure-response sweep — Sano_2023 :: MCC (maximum cystometric capacity)"
  extends Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep(
    E0 = 0.00019,      // [m3; mL × 1e-06]
    Emax = 0.00039,  // [m3; mL × 1e-06]
    EC50 = 6.22e-06,  // [kg/m3; ng/mL × 1e-06]
    gamma = 1,
    exposure_per_s = 1e-06);   // 1 ng/mL per second
  // defaulted: gamma
  annotation(experiment(StartTime = 0, StopTime = 63, Interval = 0.126),
    Documentation(info = "<html><body><!-- drug-about --><h4>About tolterodine</h4><p>Tolterodine is a muscarinic antagonist used to treat urinary incontinence and bladder disease. It is an approved drug for urinary frequency and incontinence, and is widely used for overactive bladder conditions.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q424312\">Wikidata Q424312</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h4>Tolterodine_Sano2023_PD_mcc</h4><p>The steady-state exposure-response curve of Sano Y et al., <i>European journal of drug metabolism and pharmacokinetics 48(3):257–269</i> 2023 (<a href=\"https://doi.org/10.1007/s13318-023-00818-8\">doi:10.1007/s13318-023-00818-8</a>) — maximum cystometric capacity [mL] against 5-hydroxymethyl tolterodine ng/mL — obtained by sweeping the driver instead of simulating a dose. Model family: emax.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    =        190 mL       drug-free response (baseline) (BASEa (age &gt; 12 years), Q324)
  Emax  =        390 mL       maximal effect term (Emaxb (age &gt; 12 years), Q320)
  EC50  =       6.22 ng/mL    exposure at half of the maximal effect term (EC50, Q321)
  gamma = (library default) Hill coefficient</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep\">SigmoidEmaxSweep</a>; this model only supplies the numbers. The x axis is one ng/mL of 5-hydroxymethyl tolterodine per second of simulated time (exposure is in kg/m3): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0.00019   (drug-free)
  exposure = EC50 (6.22 ng/mL)  response 0.000385
  exposure -> infinity  response 0.00058</pre></body></html>"));
end Tolterodine_Sano2023_PD_mcc;
