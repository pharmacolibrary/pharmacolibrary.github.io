function p = Tolterodine_Sano2023_PD_mcc_params()
% Tolterodine_Sano2023_PD_mcc_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% tolterodine Sano_2023::MCC: emax exposure-response sweep (response = E0 + Emax*frac). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one ng/mL per second, in SI inside (kg/m3, s). Response MCC in mL. Driver: 5-hydroxymethyl tolterodine (pk_record).
p.E0 = 0.00019000000000000004;
p.Emax = 0.00039000000000000005;
p.EC50 = 6.22e-06;
p.gamma = 1.0;
p.slope = 0.0;
p.exposure_per_s = 1e-06;
p.stop_time = 63.0;
p.form = 'E0 + Emax*frac';
end
