function p = Brigatinib_Gupta2021_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: brigatinib   source: Gupta_2021 / reference   route: oral
  % estimated (absent from source): ka
  p.name  = 'Brigatinib_Gupta2021_reference_params';
  p.drug  = 'brigatinib';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 207.0;                % central volume [L]
  p.CL = 10.6;                % clearance [L/h]
  p.Vp = [114.0];             % peripheral volumes [L]
  p.Q  = [12.6];             % inter-compartmental clearances [L/h]
  p.ka = 0.5;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 90.0;             % dose [mg]
end
