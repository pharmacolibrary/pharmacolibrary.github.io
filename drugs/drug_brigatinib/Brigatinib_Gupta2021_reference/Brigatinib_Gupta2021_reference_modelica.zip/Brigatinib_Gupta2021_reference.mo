model Brigatinib_Gupta2021_reference
  parameter Real Cl_ref = 2.9444444444444445e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.20700000000000002 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.5841000000000001,
    adminMass = 9e-05,
    ka = 0.0001388888888888889,
    Tlag = 0.0,
    k12 = 1.6908212560386472e-05,
    k21 = 3.0701754385964913e-05
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About brigatinib</h4><p>Brigatinib is a protein kinase inhibitor used to treat non-small-cell lung carcinoma. It is authorised in the European Union for this cancer indication.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q27456393\">Wikidata Q27456393</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>brigatinib</td></tr><tr><td>population:</td><td>healthy volunteers and patients with cancer</td></tr><tr><td>source_paper:</td><td>Gupta_2021</td></tr><tr><td>measured_compound:</td><td>brigatinib</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>Tab3</td></tr><tr><td>input:</td><td>PK_2C_enteral: apparent (/F) parameterization ⇒ extravascular dosing</td></tr><tr><td>molar_masses:</td><td>brigatinib 584.1 g/mol (drugbank)</td></tr></table><p><b>Defaulted (base-class default used):</b> ka, Tlag.</p><h4>Interpretation flags</h4><ul><li>table section iiv: 'CL/F (L/h)' routed out of structural estimates ('Inter-individual variability,a % (% CV)')</li><li>table section iiv: 'V1/F (L)' routed out of structural estimates ('Inter-individual variability,a % (% CV)')</li><li>table section iiv: 'V2/F (L)' routed out of structural estimates ('Inter-individual variability,a % (% CV)')</li><li>table section iiv: 'No. of transit compartmentsc' routed out of structural estimates ('Inter-individual variability,a % (% CV)')</li><li>table section iiv: 'Mean transit time (h)' routed out of structural estimates ('Inter-individual variability,a % (% CV)')</li><li>dropped duplicate Q69 ('Q2/F (L/h)', value '2.7') — already have one for this compound</li><li>dropped unlinked row (NIL): 'Condition numberd' — extend the ontology if this is a real PK parameter (source ['Tab3:row12:col1'])</li><li>covariate effect for Q900 has no base parameter row (kept as unattached equation-variable)</li><li>apparent-ness (ontology-grounded): parameterization=apparent, measured_compound=brigatinib</li><li>structure disagreement: deterministic 2C vs LLM 3C — review compartment count</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 259200, Tolerance = 1e-9, Interval = 1));
end Brigatinib_Gupta2021_reference;
