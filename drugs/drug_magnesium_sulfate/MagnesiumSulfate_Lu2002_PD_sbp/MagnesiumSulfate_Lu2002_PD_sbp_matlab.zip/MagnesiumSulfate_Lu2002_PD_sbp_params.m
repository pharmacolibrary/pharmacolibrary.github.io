function p = MagnesiumSulfate_Lu2002_PD_sbp_params()
% MagnesiumSulfate_Lu2002_PD_sbp_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% magnesium_sulfate Lu_2002::SBP: emax exposure-response sweep (response = E0 + Emax*frac). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one mmol/L per second, in SI inside (kg/m3, s). Response SBP in mm Hg. Driver: magnesium (pk_record).
p.E0 = 0.0;
p.Emax = -36.8;
p.EC50 = 0.7499999999999999;
p.gamma = 1.0;
p.slope = 0.0;
p.exposure_per_s = 1.0;
p.stop_time = 7.5;
p.form = 'E0 + Emax*frac';
end
