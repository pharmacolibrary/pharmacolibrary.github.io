model MagnesiumSulfate_Lu2002_PD_sbp
  "emax exposure-response sweep — Lu_2002 :: SBP (systolic blood pressure)"
  extends Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep(
    E0 = 0,      // [1]
    Emax = -36.8,  // [mm Hg]
    EC50 = 0.75,  // [mol/m3; mmol/L × 1]
    gamma = 1,
    exposure_per_s = 1);   // 1 mmol/L per second
  // family_inferred: the record's model family is effect_compartment; read from the parameters: Emax/Imax and EC50/IC50 without a Hill coefficient — Emax
  // imax_as_negative_emax: Imax (Q323) enters SigmoidEmaxSweep as −Emax
  // defaulted: E0
  // defaulted: gamma
  annotation(experiment(StartTime = 0, StopTime = 7.5, Interval = 0.015),
    Documentation(info = "<html><body><h4>MagnesiumSulfate_Lu2002_PD_sbp</h4><p>The steady-state exposure-response curve of Lu J et al., <i>Clinical pharmacokinetics 41(13):1105–1113</i> 2002 (<a href=\"https://doi.org/10.2165/00003088-200241130-00007\">doi:10.2165/00003088-200241130-00007</a>) — systolic blood pressure [mm Hg] against magnesium mmol/L — obtained by sweeping the driver instead of simulating a dose. Model family: emax.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = (library default) drug-free response (baseline)
  Emax  =       36.8 mm Hg    maximal effect term (maximum decrease, Q323)
  EC50  =       0.75 mmol/L   exposure at half of the maximal effect term (Mg2+ concentration (above baseline) eliciting half-maximum effect, Q321)
  gamma = (library default) Hill coefficient</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep\">SigmoidEmaxSweep</a>; this model only supplies the numbers. The x axis is one mmol/L of magnesium per second of simulated time (exposure is in mol/m3): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0   (drug-free)
  exposure = EC50 (0.75 mmol/L)  response -18.4
  exposure -> infinity  response -36.8</pre></body></html>"));
end MagnesiumSulfate_Lu2002_PD_sbp;
