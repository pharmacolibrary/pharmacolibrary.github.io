model MagnesiumSulfate_Deng2024_reference
  parameter Real Cl_ref = 8.277777777777777e-07 "Cl [m3/s]";
  parameter Real Vd_ref = 0.025070000000000002 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.12036799999999999,
    adminMass = 0.005
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>magnesium_sulfate</td></tr><tr><td>population:</td><td>Chinese preeclampsia population</td></tr><tr><td>source_paper:</td><td>Deng_2024</td></tr><tr><td>measured_compound:</td><td>magnesium_sulfate</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>Tab2</td></tr><tr><td>input:</td><td>PK_1C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>magnesium_sulfate 120.368 g/mol (drugbank)</td></tr></table><h4>Interpretation flags</h4><ul><li>table section iiv: 'ω2 V (%)' routed out of structural estimates ('Inter-individual variability')</li><li>table section iiv: 'ω2 V (%)' routed out of structural estimates ('Inter-individual variability')</li><li>table section iiv: 'ω2 V (%)' routed out of structural estimates ('Inter-individual variability')</li><li>table section iiv: 'ω2 V (%)' routed out of structural estimates ('Inter-individual variability')</li><li>table section iiv: 'ω2 CL (%)' routed out of structural estimates ('Inter-individual variability')</li><li>table section iiv: 'ω2 CL (%)' routed out of structural estimates ('Inter-individual variability')</li><li>table section iiv: 'ω2 CL (%)' routed out of structural estimates ('Inter-individual variability')</li><li>table section iiv: 'ω2 CL (%)' routed out of structural estimates ('Inter-individual variability')</li><li>table section residual_error: 'stdev0' routed out of structural estimates ('Residual variability')</li><li>table section residual_error: 'stdev0' routed out of structural estimates ('Residual variability')</li><li>table section residual_error: 'stdev0' routed out of structural estimates ('Residual variability')</li><li>table section residual_error: 'stdev0' routed out of structural estimates ('Residual variability')</li><li>table section residual_error: 'stdev0' routed out of structural estimates ('Residual variability')</li><li>table section residual_error: 'stdev0' routed out of structural estimates ('Residual variability')</li><li>table section residual_error: 'stdev0' routed out of structural estimates ('Residual variability')</li><li>table section residual_error: 'stdev0' routed out of structural estimates ('Residual variability')</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 108000, Tolerance = 1e-9, Interval = 1));
end MagnesiumSulfate_Deng2024_reference;
