model MagnesiumSulfate_da2020_reference
  parameter Real Cl_ref = 3.833333333333333e-07 "Cl [m3/s]";
  parameter Real Vd_ref = 0.013300000000000001 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.12036799999999999,
    adminMass = 0.001
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>magnesium_sulfate</td></tr><tr><td>population:</td><td>pregnant women with preeclampsia</td></tr><tr><td>source_paper:</td><td>da_2020</td></tr><tr><td>measured_compound:</td><td>magnesium_sulfate</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>Tab3</td></tr><tr><td>input:</td><td>PK_1C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>magnesium_sulfate 120.368 g/mol (drugbank)</td></tr></table><h4>Interpretation flags</h4><ul><li>column '%' classified 'other' by the LLM but kept: the deterministic diagnostic-column test disagrees (a stratum column is a value column, not a statistic)</li><li>column '%' classified 'other' by the LLM but kept: the deterministic diagnostic-column test disagrees (a stratum column is a value column, not a statistic)</li><li>column '%' classified 'other' by the LLM but kept: the deterministic diagnostic-column test disagrees (a stratum column is a value column, not a statistic)</li><li>column '%' classified 'other' by the LLM but kept: the deterministic diagnostic-column test disagrees (a stratum column is a value column, not a statistic)</li><li>dropped duplicate Q22 ('Beta_CL_creatinine_mg_dL', value '34.2') — already have one for this compound</li><li>dropped duplicate Q61 ('Beta_V_Weith_kg', value '28') — already have one for this compound</li><li>implicit units: 'V_pop' → L (from the paper text: &quot;The paper text states: 'for V, it was 13.3 L'.&quot;)</li><li>implicit units: 'CL_pop' → L/h (from the paper text: &quot;The paper text states: 'The model estimate of the population CL was 1.38 L/h'.&quot;)</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=magnesium_sulfate</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 122400, Tolerance = 1e-9, Interval = 1));
end MagnesiumSulfate_da2020_reference;
