model Moclobemide_Gwka2019_reference
  parameter Real Cl_ref = 1.883333333333333e-05 "Cl [m3/s]";
  parameter Real Vd_ref = 0.1128 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.26873899999999995,
    adminMass = 0.0003,
    ka = 0.0001388888888888889,
    Tlag = 727.2
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About moclobemide</h4><p>Moclobemide is an antidepressant that works as a reversible inhibitor of monoamine oxidase A. It is an approved medicine, used in several countries for depression, though it is not authorised centrally in the European Union.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q421934\">Wikidata Q421934</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>moclobemide</td></tr><tr><td>population:</td><td>review reference</td></tr><tr><td>source_paper:</td><td>Główka_2019</td></tr><tr><td>measured_compound:</td><td>moclobemide</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C_enteral: apparent (/F) parameterization ⇒ extravascular dosing</td></tr><tr><td>molar_masses:</td><td>moclobemide 268.739 g/mol (drugbank)</td></tr></table><p><b>Defaulted (base-class default used):</b> ka.</p><h4>Interpretation flags</h4><ul><li>built from REVIEW reference values (Główka_2019) — secondary source</li><li>volume reported by review</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Moclobemide_Gwka2019_reference;
