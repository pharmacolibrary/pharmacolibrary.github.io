function p = Moclobemide_Birkett1995_PD_u_params()
% Moclobemide_Birkett1995_PD_u_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% moclobemide Birkett_1995::u: sigmoid_emax exposure-response sweep (response = E0 + Emax*frac). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one quarter years per second, in SI inside (kg/m3, s). Response u in DDD/1000 population/day. Driver: moclobemide (dose_only).
p.E0 = 0.0;
p.Emax = 1.8;
p.EC50 = 6.0;
p.gamma = 2.0;
p.slope = 0.0;
p.exposure_per_s = 1.0;
p.stop_time = 60.0;
p.form = 'E0 + Emax*frac';
end
