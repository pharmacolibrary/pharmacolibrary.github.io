model Moclobemide_Birkett1995_PD_u
  "sigmoid_emax exposure-response sweep — Birkett_1995 :: u (Utilisation (market uptake))"
  extends Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep(
    E0 = 0,      // [1]
    Emax = 1.8,  // [DDD/1000/day]
    EC50 = 6,  // [quarter years]
    gamma = 2,
    exposure_per_s = 1);   // 1 quarter years per second
  // exposure_unit_unresolved: 'quarter years' — the x axis is in the paper's unit, not SI
  // defaulted: E0
  annotation(experiment(StartTime = 0, StopTime = 60, Interval = 0.12),
    Documentation(info = "<html><body><!-- drug-about --><h4>About moclobemide</h4><p>Moclobemide is an antidepressant that works as a reversible inhibitor of monoamine oxidase A. It is an approved medicine, used in several countries for depression, though it is not authorised centrally in the European Union.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q421934\">Wikidata Q421934</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h4>Moclobemide_Birkett1995_PD_u</h4><p>The steady-state exposure-response curve of Birkett DJ et al., <i>British journal of clinical pharmacology 40(4):407–410</i> 1995 (<a href=\"https://doi.org/10.1111/j.1365-2125.1995.tb04565.x\">doi:10.1111/j.1365-2125.1995.tb04565.x</a>) — Utilisation (market uptake) [DDD/1000 population/day] against moclobemide quarter years — obtained by sweeping the driver instead of simulating a dose. Model family: sigmoid_emax.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = (library default) drug-free response (baseline)
  Emax  =        1.8 DDD/1000/day maximal effect term (Umax, Q320)
  EC50  =          6 quarter years exposure at half of the maximal effect term (TU50, Q321)
  gamma =          2          Hill coefficient (Slope (n), Q325)</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep\">SigmoidEmaxSweep</a>; this model only supplies the numbers. The x axis is one quarter years of moclobemide per second of simulated time: there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0   (drug-free)
  exposure = EC50 (6 quarter years)  response 0.9
  exposure -> infinity  response 1.8</pre></body></html>"));
end Moclobemide_Birkett1995_PD_u;
