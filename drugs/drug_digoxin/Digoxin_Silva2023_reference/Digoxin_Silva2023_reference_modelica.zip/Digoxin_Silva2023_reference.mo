model Digoxin_Silva2023_reference
  parameter Real Cl_ref = 1.1638888888888888e-07 "Cl [m3/s]";
  parameter Real Vd_ref = 0.0011 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.7809385,
    adminMass = 2.5e-07
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About digoxin</h4><p>Digoxin is a plant-derived cardiac glycoside used for heart conditions such as atrial fibrillation, other arrhythmias, and congestive heart failure. It remains an approved medicine, is listed among WHO essential medicines, and is widely used for these heart conditions.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q422222\">Wikidata Q422222</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>digoxin</td></tr><tr><td>population:</td><td>review reference</td></tr><tr><td>source_paper:</td><td>Silva_2023</td></tr><tr><td>measured_compound:</td><td>digoxin</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>digoxin 780.938 g/mol (drugbank)</td></tr></table><h4>Interpretation flags</h4><ul><li>built from REVIEW reference values (Silva_2023) — secondary source</li><li>volume reported by review</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Digoxin_Silva2023_reference;
