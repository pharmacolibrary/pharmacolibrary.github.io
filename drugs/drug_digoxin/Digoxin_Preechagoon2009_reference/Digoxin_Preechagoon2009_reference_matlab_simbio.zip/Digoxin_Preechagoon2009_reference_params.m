function p = Digoxin_Preechagoon2009_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: digoxin   source: Preechagoon_2009 / reference   route: oral
  % estimated (absent from source): F
  p.name  = 'Digoxin_Preechagoon2009_reference_params';
  p.drug  = 'digoxin';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 29.26;                % central volume [L]
  p.CL = 15.61;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 2.29;                % absorption rate [1/h]
  p.F  = 0.9;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 0.25;             % dose [mg]
end
