function p = Mesalazine_Cuffari2016_nonmem_estimates_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: mesalazine   source: Cuffari_2016 / nonmem_estimates   route: oral
  p.name  = 'Mesalazine_Cuffari2016_nonmem_estimates_params';
  p.drug  = 'mesalazine';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 70.1;                % central volume [L]
  p.CL = 2.27;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.0207;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 4.31;             % absorption lag [h]
  p.dose = 2100.0;             % dose [mg]
end
