model Mesalazine_Cuffari2016_nonmem_estimates
  parameter Real Cl_ref = 2.1083333333333335e-05 "Cl [m3/s]";
  parameter Real cov_wt = 1.0 "wt covariate (reference 1.0)";
  parameter Real Vd_ref = 0.0701 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref*(cov_wt/1.0)^(0.75),
    Vd = Vd_ref*(cov_wt/1.0)^(1.0),
    adminDuration = 600,
    adminCount = 1,
    MM = 0.1531354,
    adminMass = 0.0021,
    ka = 5.75e-06,
    Tlag = 15515.999999999998
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About mesalazine</h4><p>Mesalazine (5-aminosalicylic acid) is an intestinal anti-inflammatory aminosalicylic acid used mainly to treat inflammatory bowel conditions such as ulcerative colitis, proctitis, and microscopic colitis. It is an approved medicine in widespread use, and is also being investigated for other conditions.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q412479\">Wikidata Q412479</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>mesalazine</td></tr><tr><td>population:</td><td>children and adolescents with ulcerative colitis</td></tr><tr><td>source_paper:</td><td>Cuffari_2016</td></tr><tr><td>measured_compound:</td><td>5-ASA</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>ts2-dddt-10-593</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>5-ASA 153.135 g/mol (drugbank); Ac-5-ASA 195.15 g/mol (paper)</td></tr></table><h4>Interpretation flags</h4><ul><li>the dosed compound is mesalazine; the compartment is 5-ASA. Input enters at the reported formation rate, so formation is already accounted for in the input step and the simulated concentration is 5-ASA, not mesalazine</li><li>apparent parameters (CLm/F, Vm/F) already contain F and the metabolised fraction, so F=1 and no molar correction is applied — adding either would double-count it</li><li>mesalazine's own concentration-time course is not produced by this model</li><li>PK_3M template not built: the parent has no clearance</li><li>PK_3M template not built: the parent has no clearance</li><li>table section iiv: 'ω2CLR' routed out of structural estimates ('Inter-individual variability')</li><li>table section iiv: 'ω2CLR' routed out of structural estimates ('Inter-individual variability')</li><li>table section iiv: 'ω2CLR' routed out of structural estimates ('Inter-individual variability')</li><li>table section iiv: 'ω2CLM' routed out of structural estimates ('Inter-individual variability')</li><li>table section iiv: 'ω2CLM' routed out of structural estimates ('Inter-individual variability')</li><li>table section iiv: 'ω2CLM' routed out of structural estimates ('Inter-individual variability')</li><li>table section iiv: 'ω2Vc' routed out of structural estimates ('Inter-individual variability')</li><li>table section iiv: 'ω2Vc' routed out of structural estimates ('Inter-individual variability')</li><li>table section iiv: 'ω2Vc' routed out of structural estimates ('Inter-individual variability')</li><li>table section iiv: 'ω2CLRM' routed out of structural estimates ('Inter-individual variability')</li><li>table section iiv: 'ω2CLRM' routed out of structural estimates ('Inter-individual variability')</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 604800, Tolerance = 1e-9, Interval = 1));
end Mesalazine_Cuffari2016_nonmem_estimates;
