function p = Bosutinib_Garrett2023_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: bosutinib   source: Garrett_2023 / reference   route: oral
  % estimated (absent from source): F
  p.name  = 'Bosutinib_Garrett2023_reference_params';
  p.drug  = 'bosutinib';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 1325.7;                % central volume [L]
  p.CL = 56.3;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.358;                % absorption rate [1/h]
  p.F  = 0.9;                 % bioavailability [0-1]
  p.Tlag = 0.442;             % absorption lag [h]
  p.dose = 400.0;             % dose [mg]
end
