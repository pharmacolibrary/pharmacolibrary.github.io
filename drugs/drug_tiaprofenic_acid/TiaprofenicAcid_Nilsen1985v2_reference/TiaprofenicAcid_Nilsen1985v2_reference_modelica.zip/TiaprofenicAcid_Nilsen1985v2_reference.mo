model TiaprofenicAcid_Nilsen1985v2_reference
  parameter Real Cl_ref = 5e-07 "Cl [m3/s]";
  parameter Real Vd_ref = 0.011800000000000001 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.260308,
    adminMass = 0.0006,
    ka = 0.0012000000000000001,
    Tlag = 828.0
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About tiaprofenic_acid</h4><p>It is an approved medicine, though it is not widely used today and has largely been superseded by other NSAIDs.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q419926\">Wikidata Q419926</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>tiaprofenic_acid</td></tr><tr><td>population:</td><td>elderly patients</td></tr><tr><td>source_paper:</td><td>Nilsen_1985_2</td></tr><tr><td>measured_compound:</td><td>tiaprofenic acid</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>tiaprofenic_acid 260.308 g/mol (drugbank); tiaprofenic acid 260.308 g/mol (drugbank)</td></tr></table><h4>Interpretation flags</h4><ul><li>apparent-ness (ontology-grounded): parameterization=apparent, measured_compound=tiaprofenic acid</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end TiaprofenicAcid_Nilsen1985v2_reference;
