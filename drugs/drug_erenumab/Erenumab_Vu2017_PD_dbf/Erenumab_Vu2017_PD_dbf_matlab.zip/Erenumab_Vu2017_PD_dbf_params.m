function p = Erenumab_Vu2017_PD_dbf_params()
% Erenumab_Vu2017_PD_dbf_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% erenumab Vu_2017::DBF: sigmoid_emax exposure-response sweep (response = E0 + Emax*frac). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one ng/mL per second, in SI inside (kg/m3, s). Response DBF in PU. Driver: erenumab (pk_record).
p.E0 = 6.608945494301599e-37;
p.Emax = -0.893;
p.EC50 = 0.00025499999999999996;
p.gamma = 3.08;
p.slope = 0.0;
p.exposure_per_s = 1e-06;
p.stop_time = 2600.0;
p.form = 'E0 + Emax*frac';
end
