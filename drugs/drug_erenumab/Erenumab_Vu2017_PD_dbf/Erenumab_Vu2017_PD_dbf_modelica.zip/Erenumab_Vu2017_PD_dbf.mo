model Erenumab_Vu2017_PD_dbf
  "sigmoid_emax exposure-response sweep — Vu_2017 :: DBF (dermal blood flow)"
  extends Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep(
    E0 = 6.6089454943e-37,      // [kg; PU × 1.66054e-39]
    Emax = -0.893,  // [1; % × 0.01]
    EC50 = 0.000255,  // [kg/m3; ng/mL × 1e-06]
    gamma = 3.08,
    exposure_per_s = 1e-06);   // 1 ng/mL per second
  // imax_as_negative_emax: Imax (Q323) enters SigmoidEmaxSweep as −Emax
  annotation(experiment(StartTime = 0, StopTime = 2600, Interval = 5.2),
    Documentation(info = "<html><body><!-- drug-about --><h4>About erenumab</h4><p>Erenumab is a monoclonal antibody that blocks the calcitonin gene-related peptide receptor and is used to prevent migraine. It is authorised in the European Union for migraine and is an approved medicine.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q28209017\">Wikidata Q28209017</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h4>Erenumab_Vu2017_PD_dbf</h4><p>The steady-state exposure-response curve of Vu T et al., <i>Pharmaceutical research 34(9):1784–1795</i> 2017 (<a href=\"https://doi.org/10.1007/s11095-017-2183-6\">doi:10.1007/s11095-017-2183-6</a>) — dermal blood flow [PU] against erenumab ng/mL — obtained by sweeping the driver instead of simulating a dose. Model family: sigmoid_emax.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    =        398 PU       drug-free response (baseline) (Baseline dermal blood flow, Q324)
  Emax  =       89.3 %        maximal effect term (Maximum inhibition (Imax), Q323)
  EC50  =        255 ng/mL    exposure at half of the maximal effect term (Potency (IC50), Q322)
  gamma =       3.08          Hill coefficient (Hill coefficient, Q325)</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep\">SigmoidEmaxSweep</a>; this model only supplies the numbers. The x axis is one ng/mL of erenumab per second of simulated time (exposure is in kg/m3): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 6.609e-37   (drug-free)
  exposure = EC50 (255 ng/mL)  response -0.4465
  exposure -> infinity  response -0.893</pre></body></html>"));
end Erenumab_Vu2017_PD_dbf;
