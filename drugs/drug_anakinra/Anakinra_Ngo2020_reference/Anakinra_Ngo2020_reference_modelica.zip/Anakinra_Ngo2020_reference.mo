model Anakinra_Ngo2020_reference
  parameter Real Cl_ref = 5.7777777777777775e-08 "Cl [m3/s]";
  parameter Real Vd_ref = 0.011300000000000001 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    adminMass = 0.0001,
    ka = 0.0003361111111111111,
    Tlag = 1123.2,
    k12 = 7.079646017699113e-07,
    k21 = 1.5810276679841897e-06
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About anakinra</h4><p>Anakinra, an interleukin-1 receptor antagonist, is used to treat rheumatoid arthritis, systemic-onset juvenile idiopathic arthritis, and pericarditis, and has also been used for COVID-19. It is an approved medicine with an authorised product in the European Union, and is also being studied for other uses.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q415411\">Wikidata Q415411</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>anakinra</td></tr><tr><td>population:</td><td>review reference</td></tr><tr><td>source_paper:</td><td>Ngo_2020</td></tr><tr><td>measured_compound:</td><td>anakinra</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_2C_enteral: absorption rate constant reported</td></tr></table><h4>Interpretation flags</h4><ul><li>built from REVIEW reference values (Ngo_2020) — secondary source</li><li>volume reported by review</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 691200, Tolerance = 1e-9, Interval = 1));
end Anakinra_Ngo2020_reference;
