model Tafenoquine_Watson2022_reference
  parameter Real Cl_ref = 8.722222222222222e-07 "Cl [m3/s]";
  parameter Real Vd_ref = 1.33 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.463501,
    adminMass = 5e-05,
    ka = 0.0001388888888888889,
    Tlag = 529.1999999999999,
    k12 = 1.2155388471177944e-06,
    k21 = 5.198285101822079e-06
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About tafenoquine</h4><p>Tafenoquine is an antimalarial drug used to treat or prevent malaria. It is an approved medicine, though its use appears limited rather than widespread.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q2387553\">Wikidata Q2387553</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>tafenoquine</td></tr><tr><td>population:</td><td>patients with P. vivax malaria and healthy volunteers</td></tr><tr><td>source_paper:</td><td>Watson_2022</td></tr><tr><td>measured_compound:</td><td>tafenoquine</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>app6table1</td></tr><tr><td>input:</td><td>PK_2C_enteral: apparent (/F) parameterization ⇒ extravascular dosing</td></tr><tr><td>molar_masses:</td><td>tafenoquine 463.501 g/mol (drugbank)</td></tr></table><p><b>Defaulted (base-class default used):</b> ka.</p><h4>Interpretation flags</h4><ul><li>dropped duplicate Q27 ('Age – CL/F', value '-0.00434') — already have one for this compound</li><li>dropped unlinked row (NIL): 'Vomit – F' — extend the ontology if this is a real PK parameter (source ['app6table1:row10:col1', 'app6table1:footnote'])</li><li>dropped duplicate Q81 ('Patient – MTT', value '0.937') — already have one for this compound</li><li>dropped duplicate Q290 ('Patient – Vc/F', value '-0.276') — already have one for this compound</li><li>dropped duplicate Q82 ('Patient – Vp/F', value '1.40') — already have one for this compound</li><li>apparent-ness (ontology-grounded): parameterization=apparent, measured_compound=tafenoquine</li><li>gap-filled Q83 (tlag) from Cherkaoui-Rbati_2023's review values (primary lacked it)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 5443200, Tolerance = 1e-9, Interval = 1));
end Tafenoquine_Watson2022_reference;
