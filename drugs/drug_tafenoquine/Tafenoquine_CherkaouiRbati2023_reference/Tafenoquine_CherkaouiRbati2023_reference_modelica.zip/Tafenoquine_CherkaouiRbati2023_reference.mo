model Tafenoquine_CherkaouiRbati2023_reference
  parameter Real Cl_ref = 1.322222222222222e-07 "Cl [m3/s]";
  parameter Real Vd_ref = 0.00858 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.463501,
    adminMass = 1e-05,
    k12 = 0.0012011137011137011,
    k21 = 0.00017985262749660658
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About tafenoquine</h4><p>Tafenoquine is an antimalarial drug used to treat or prevent malaria. It is an approved medicine, though its use appears limited rather than widespread.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q2387553\">Wikidata Q2387553</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>tafenoquine</td></tr><tr><td>population:</td><td>review reference</td></tr><tr><td>source_paper:</td><td>Cherkaoui-Rbati_2023</td></tr><tr><td>measured_compound:</td><td>tafenoquine</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_2C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>tafenoquine 463.501 g/mol (drugbank)</td></tr></table><h4>Interpretation flags</h4><ul><li>built from REVIEW reference values (Cherkaoui-Rbati_2023) — secondary source</li><li>volume reported by review</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 259200, Tolerance = 1e-9, Interval = 1));
end Tafenoquine_CherkaouiRbati2023_reference;
