model Ticarcillin_Economou2019_reference
  parameter Real Cl_ref = 1.7805555555555555e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.05646 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 0.9,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.384427,
    adminMass = 0.0001,
    ka = 0.00021694444444444447,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About ticarcillin</h4><p>Ticarcillin is a penicillin antibiotic used to treat bacterial infections such as sepsis, urinary, skin and respiratory tract infections, and Pseudomonas and other gram-negative infections. It has been withdrawn from human use, though it was also approved for veterinary use.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q2601832\">Wikidata Q2601832</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>ticarcillin</td></tr><tr><td>population:</td><td>critically ill patients with acute kidney injury receiving extended daily diafiltration</td></tr><tr><td>source_paper:</td><td>Economou_2019</td></tr><tr><td>measured_compound:</td><td>ticarcillin</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>ticarcillin 384.427 g/mol (drugbank)</td></tr></table><p><b>Defaulted (base-class default used):</b> F, Tlag.</p><h4>Interpretation flags</h4><ul><li>dropped duplicate Q22 ('clearance of EDDf (CLnon-EDDf)', value 4.97) — already have one for this compound</li><li>dropped duplicate Q30 ('intercompartmental clearance from the peripheral to central compartment (kPC)', value 21.93) — already have one for this compound</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=ticarcillin</li><li>structure disagreement: deterministic 1C vs LLM 2C — review compartment count</li><li>1C volume normalization: Q63→Q61 (single-compartment model has no central/peripheral split; 'volume of distribution of the central compartment (Vc)' is the general volume)</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>gap-filled Q49 (kabs) from Schouwenburg_2025's review values (primary lacked it)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 126000, Tolerance = 1e-9, Interval = 1));
end Ticarcillin_Economou2019_reference;
