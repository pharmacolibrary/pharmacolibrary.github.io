% Run (SimBiology): build model + dose, simulate 0..216.0 h, plot.
p = AcetylsalicylicAcid_Bayoumy2025_reference_params();
[model, dose, variant] = build_sb_pk(p);
sd = simulate_sb(model, variant, dose, 216.0);
