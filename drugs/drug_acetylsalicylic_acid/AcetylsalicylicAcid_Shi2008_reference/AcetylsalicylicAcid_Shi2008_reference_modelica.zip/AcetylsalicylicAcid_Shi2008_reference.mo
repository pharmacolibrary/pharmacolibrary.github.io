model AcetylsalicylicAcid_Shi2008_reference
  parameter Real Cl_ref = 7.5e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.4674331932480242 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.1801574,
    adminMass = 0.003,
    ka = 0.0001388888888888889,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About acetylsalicylic_acid</h4><p>Aspirin (acetylsalicylic acid) is used to relieve pain, fever and inflammation, and to lower the risk of heart attacks and other heart and blood-clotting problems. It is very widely used worldwide, appears on the WHO essential medicines list, and in the UK is available for general sale without a prescription.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q18216\">Wikidata Q18216</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>acetylsalicylic_acid</td></tr><tr><td>population:</td><td>review reference</td></tr><tr><td>source_paper:</td><td>Shi_2008</td></tr><tr><td>measured_compound:</td><td>acetylsalicylic_acid</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C_enteral: apparent (/F) parameterization ⇒ extravascular dosing</td></tr><tr><td>molar_masses:</td><td>acetylsalicylic_acid 180.157 g/mol (drugbank)</td></tr></table><p><b>Defaulted (base-class default used):</b> ka, Tlag.</p><h4>Interpretation flags</h4><ul><li>built from REVIEW reference values (Shi_2008) — secondary source</li><li>central volume derived from CL·t½/ln2</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 259200, Tolerance = 1e-9, Interval = 1));
end AcetylsalicylicAcid_Shi2008_reference;
