function p = Atorvastatin_Wen2023_PD_su_params()
% Atorvastatin_Wen2023_PD_su_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% atorvastatin Wen_2023::SU: emax exposure-response sweep (response = E0 + Emax*frac). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one mg/L per second, in SI inside (kg/m3, s). Response SU in mg/dL. Driver: oxypurinol (conc_no_pk).
p.E0 = 0.0;
p.Emax = -0.07599999999999998;
p.EC50 = 0.017599999999999998;
p.gamma = 1.0;
p.slope = 0.0;
p.exposure_per_s = 0.0009999999999999998;
p.stop_time = 176.0;
p.form = 'E0 + Emax*frac';
end
