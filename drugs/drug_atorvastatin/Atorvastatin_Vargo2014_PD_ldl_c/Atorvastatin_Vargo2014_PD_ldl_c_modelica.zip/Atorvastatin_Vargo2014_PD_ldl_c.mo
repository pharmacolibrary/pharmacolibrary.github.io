model Atorvastatin_Vargo2014_PD_ldl_c
  "sigmoid_emax exposure-response sweep — Vargo_2014 :: LDL-C (low-density-lipoprotein cholesterol)"
  extends Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep(
    E0 = 0,      // [1]
    Emax = -0.758,  // [% change from pretreatment]
    EC50 = 1.75925925926e-10,  // [kg/s; mg/day × 1.15741e-11]
    gamma = 0.417,
    exposure_per_s = 1.15740740741e-11);   // 1 mg/day per second
  // imax_as_negative_emax: Imax (Q323) enters SigmoidEmaxSweep as −Emax
  // defaulted: E0
  annotation(experiment(StartTime = 0, StopTime = 160, Interval = 0.32),
    Documentation(info = "<html><body><!-- drug-about --><h4>About atorvastatin</h4><p>Atorvastatin is a statin used to lower blood lipids, treating conditions such as hypercholesterolemia, hypertriglyceridemia, arteriosclerosis, and coronary artery disease. It is an approved prescription medicine, widely used, and also available in combination lipid-modifying products.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q668093\">Wikidata Q668093</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h4>Atorvastatin_Vargo2014_PD_ldl_c</h4><p>The steady-state exposure-response curve of Vargo R et al., <i>Clinical pharmacology and therapeutics 96(1):101–109</i> 2014 (<a href=\"https://doi.org/10.1038/clpt.2014.66\">doi:10.1038/clpt.2014.66</a>) — low-density-lipoprotein cholesterol [% change from pretreatment] against atorvastatin mg/day — obtained by sweeping the driver instead of simulating a dose. Model family: sigmoid_emax.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = (library default) drug-free response (baseline)
  Emax  =     -0.758 % change from pretreatment maximal effect term (E max,1 (statin), Q323)
  EC50  =       15.2 mg/day   exposure at half of the maximal effect term (ED 50,atorvastatin, Q321)
  gamma =      0.417          Hill coefficient (N, Q325)</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep\">SigmoidEmaxSweep</a>; this model only supplies the numbers. The x axis is one mg/day of atorvastatin per second of simulated time (exposure is in kg/s): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0   (drug-free)
  exposure = EC50 (15.2 mg/day)  response -0.379
  exposure -> infinity  response -0.758</pre></body></html>"));
end Atorvastatin_Vargo2014_PD_ldl_c;
