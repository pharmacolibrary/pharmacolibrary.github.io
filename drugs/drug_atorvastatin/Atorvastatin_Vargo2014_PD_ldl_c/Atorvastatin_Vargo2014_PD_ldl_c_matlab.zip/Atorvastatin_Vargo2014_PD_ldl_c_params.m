function p = Atorvastatin_Vargo2014_PD_ldl_c_params()
% Atorvastatin_Vargo2014_PD_ldl_c_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% atorvastatin Vargo_2014::LDL_C: sigmoid_emax exposure-response sweep (response = E0 + Emax*frac). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one mg/day per second, in SI inside (kg/m3, s). Response LDL-C in % change from pretreatment. Driver: atorvastatin (dose_only).
p.E0 = 0.0;
p.Emax = -0.758;
p.EC50 = 1.7592592592592592e-10;
p.gamma = 0.417;
p.slope = 0.0;
p.exposure_per_s = 1.15740740741e-11;
p.stop_time = 160.0;
p.form = 'E0 + Emax*frac';
end
