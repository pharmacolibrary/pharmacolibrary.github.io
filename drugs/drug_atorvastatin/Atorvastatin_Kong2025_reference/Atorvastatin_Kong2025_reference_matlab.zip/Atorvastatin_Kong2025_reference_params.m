function p = Atorvastatin_Kong2025_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: atorvastatin   source: Kong_2025 / reference   route: oral
  p.name  = 'Atorvastatin_Kong2025_reference_params';
  p.drug  = 'atorvastatin';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 835.0;                % central volume [L]
  p.CL = 363.0;                % clearance [L/h]
  p.Vp = [5830.0];             % peripheral volumes [L]
  p.Q  = [3920.0];             % inter-compartmental clearances [L/h]
  p.ka = 7.53;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 0.01;             % dose [mg]
end
