model Atorvastatin_Jadhav2023_reference
  parameter Real Cl_ref = 2.0972222222222223e-07 "Cl [m3/s]";
  parameter Real Vd_ref = 0.019100000000000002 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.5586398,
    adminMass = 2e-05,
    ka = 0.00039166666666666663,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About atorvastatin</h4><p>Atorvastatin is a statin used to lower blood lipids, treating conditions such as hypercholesterolemia, hypertriglyceridemia, arteriosclerosis, and coronary artery disease. It is an approved prescription medicine, widely used, and also available in combination lipid-modifying products.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q668093\">Wikidata Q668093</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>atorvastatin</td></tr><tr><td>population:</td><td>review reference</td></tr><tr><td>source_paper:</td><td>Jadhav_2023</td></tr><tr><td>measured_compound:</td><td>atorvastatin</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>atorvastatin 558.64 g/mol (drugbank)</td></tr></table><p><b>Defaulted (base-class default used):</b> Tlag.</p><h4>Interpretation flags</h4><ul><li>built from REVIEW reference values (Jadhav_2023) — secondary source</li><li>volume reported by review</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 345600, Tolerance = 1e-9, Interval = 1));
end Atorvastatin_Jadhav2023_reference;
