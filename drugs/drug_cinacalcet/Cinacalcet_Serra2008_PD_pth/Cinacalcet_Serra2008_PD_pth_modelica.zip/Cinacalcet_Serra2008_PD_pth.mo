model Cinacalcet_Serra2008_PD_pth
  "emax exposure-response sweep — Serra_2008 :: PTH (parathyroid hormone)"
  extends Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep(
    E0 = 0,      // [1]
    Emax = -0.8,  // [1; % × 0.01]
    EC50 = 1.3e-05,  // [kg/m3; ng/mL × 1e-06]
    gamma = 1,
    exposure_per_s = 1e-06);   // 1 ng/mL per second
  // imax_as_negative_emax: Imax (Q323) enters SigmoidEmaxSweep as −Emax
  // defaulted: E0
  // defaulted: gamma
  annotation(experiment(StartTime = 0, StopTime = 130, Interval = 0.26),
    Documentation(info = "<html><body><!-- drug-about --><h4>About cinacalcet</h4><p>Cinacalcet is a calcimimetic anti-parathyroid medicine used to treat hyperparathyroidism, including secondary hyperparathyroidism, and related calcium disorders such as hypercalcemia. It is an approved medicine with authorised products in the European Union, and is also being studied for further uses.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q193978\">Wikidata Q193978</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h4>Cinacalcet_Serra2008_PD_pth</h4><p>The steady-state exposure-response curve of Serra AL et al., <i>American journal of transplantation : official journal of the American Society of Transplantation and the American Society of Transplant Surgeons 8(4):803–810</i> 2008 (<a href=\"https://doi.org/10.1111/j.1600-6143.2007.02136.x\">doi:10.1111/j.1600-6143.2007.02136.x</a>) — parathyroid hormone against cinacalcet ng/mL — obtained by sweeping the driver instead of simulating a dose. Model family: emax.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = (library default) drug-free response (baseline)
  Emax  =         80 %        maximal effect term (E(max), Q323)
  EC50  =         13 ng/mL    exposure at half of the maximal effect term (EC(50), Q321)
  gamma = (library default) Hill coefficient</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep\">SigmoidEmaxSweep</a>; this model only supplies the numbers. The x axis is one ng/mL of cinacalcet per second of simulated time (exposure is in kg/m3): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0   (drug-free)
  exposure = EC50 (13 ng/mL)  response -0.4
  exposure -> infinity  response -0.8</pre></body></html>"));
end Cinacalcet_Serra2008_PD_pth;
