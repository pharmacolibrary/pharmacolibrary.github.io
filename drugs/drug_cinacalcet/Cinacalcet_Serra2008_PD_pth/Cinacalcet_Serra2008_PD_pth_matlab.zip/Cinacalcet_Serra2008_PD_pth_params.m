function p = Cinacalcet_Serra2008_PD_pth_params()
% Cinacalcet_Serra2008_PD_pth_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% cinacalcet Serra_2008::PTH: emax exposure-response sweep (response = E0 + Emax*frac). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one ng/mL per second, in SI inside (kg/m3, s). Response PTH in its own unit. Driver: cinacalcet (cited_pk).
p.E0 = 0.0;
p.Emax = -0.8;
p.EC50 = 1.3e-05;
p.gamma = 1.0;
p.slope = 0.0;
p.exposure_per_s = 1e-06;
p.stop_time = 130.0;
p.form = 'E0 + Emax*frac';
end
