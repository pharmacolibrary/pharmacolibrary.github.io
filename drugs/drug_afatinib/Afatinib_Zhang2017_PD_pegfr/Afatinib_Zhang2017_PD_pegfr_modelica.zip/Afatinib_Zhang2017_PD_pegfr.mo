model Afatinib_Zhang2017_PD_pegfr
  "emax exposure-response sweep — Zhang_2017 :: pEGFR (expression of pEGFR (Tyr1068))"
  extends Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep(
    E0 = 0,      // [1]
    Emax = -0.865,  // [1; % × 0.01]
    EC50 = 2.6e-07,  // [mol/m3; nmol/L × 1e-06]
    gamma = 1,
    exposure_per_s = 1e-06);   // 1 nmol/L per second
  // imax_as_negative_emax: Imax (Q323) enters SigmoidEmaxSweep as −Emax
  // defaulted: E0
  // defaulted: gamma
  annotation(experiment(StartTime = 0, StopTime = 2.6, Interval = 0.0052),
    Documentation(info = "<html><body><!-- drug-about --><h4>About afatinib</h4><p>Afatinib is a protein kinase inhibitor used to treat non-small-cell lung cancer. It is authorised in the European Union for this indication.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q4688818\">Wikidata Q4688818</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h4>Afatinib_Zhang2017_PD_pegfr</h4><p>The steady-state exposure-response curve of Zhang SR et al., <i>Acta pharmacologica Sinica 38(2):233–240</i> 2017 (<a href=\"https://doi.org/10.1038/aps.2016.107\">doi:10.1038/aps.2016.107</a>) — expression of pEGFR (Tyr1068) against afatinib nmol/L — obtained by sweeping the driver instead of simulating a dose. Model family: emax.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = (library default) drug-free response (baseline)
  Emax  =       86.5 %        maximal effect term (E max, Q323)
  EC50  =       0.26 nmol/L   exposure at half of the maximal effect term (EC 50, Q321)
  gamma = (library default) Hill coefficient</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep\">SigmoidEmaxSweep</a>; this model only supplies the numbers. The x axis is one nmol/L of afatinib per second of simulated time (exposure is in mol/m3): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0   (drug-free)
  exposure = EC50 (0.26 nmol/L)  response -0.4325
  exposure -> infinity  response -0.865</pre></body></html>"));
end Afatinib_Zhang2017_PD_pegfr;
