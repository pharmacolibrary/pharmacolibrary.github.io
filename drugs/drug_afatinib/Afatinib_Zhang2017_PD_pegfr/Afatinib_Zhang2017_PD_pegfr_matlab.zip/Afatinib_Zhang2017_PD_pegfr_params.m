function p = Afatinib_Zhang2017_PD_pegfr_params()
% Afatinib_Zhang2017_PD_pegfr_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% afatinib Zhang_2017::pEGFR: emax exposure-response sweep (response = E0 + Emax*frac). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one nmol/L per second, in SI inside (kg/m3, s). Response pEGFR in its own unit. Driver: afatinib (cited_pk).
p.E0 = 0.0;
p.Emax = -0.865;
p.EC50 = 2.6e-07;
p.gamma = 1.0;
p.slope = 0.0;
p.exposure_per_s = 1e-06;
p.stop_time = 2.6;
p.form = 'E0 + Emax*frac';
end
