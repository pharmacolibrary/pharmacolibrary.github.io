function p = Piperacillin_de2011_PD_n_params()
% Piperacillin_de2011_PD_n_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% piperacillin de_2011::N: emax exposure-response sweep (response = E0 + Emax*frac). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one mg ml À1 per second, in SI inside (kg/m3, s). Response N in CFU ml À1. Driver: piperacillin (cited_pk).
p.E0 = 0.0;
p.Emax = -0.0003833333333333333;
p.EC50 = 1.3099999999999998;
p.gamma = 1.0;
p.slope = 0.0;
p.exposure_per_s = 1.0;
p.stop_time = 14.0;
p.form = 'E0 + Emax*frac';
end
