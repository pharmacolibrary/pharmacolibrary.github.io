model Piperacillin_de2011_PD_n
  "emax exposure-response sweep — de_2011 :: N (number of bacteria)"
  extends Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep(
    E0 = 0,      // [1]
    Emax = -0.000383333333333,  // [1/s; h À1 × 0.000277778]
    EC50 = 1.31,  // [kg/m3; mg ml À1 × 1]
    gamma = 1,
    exposure_per_s = 1);   // 1 mg ml À1 per second
  // imax_as_negative_emax: Imax (Q323) enters SigmoidEmaxSweep as −Emax
  // defaulted: E0
  // defaulted: gamma
  annotation(experiment(StartTime = 0, StopTime = 14, Interval = 0.028),
    Documentation(info = "<html><body><!-- drug-about --><h4>About piperacillin</h4><p>Piperacillin is an extended-spectrum penicillin antibiotic used to treat bacterial infections such as sepsis, urinary tract, skin, and respiratory infections, including Pseudomonas and E. coli infections. It is an approved medicine, typically given by infusion, and is often combined with tazobactam in hospital settings.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q423787\">Wikidata Q423787</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h4>Piperacillin_de2011_PD_n</h4><p>The steady-state exposure-response curve of de Araujo BV et al., <i>The Journal of antibiotics 64(6):439–446</i> 2011 (<a href=\"https://doi.org/10.1038/ja.2011.29\">doi:10.1038/ja.2011.29</a>) — number of bacteria [CFU ml À1] against piperacillin mg ml À1 — obtained by sweeping the driver instead of simulating a dose. Model family: emax.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = (library default) drug-free response (baseline)
  Emax  =       1.38 h À1     maximal effect term (maximum killing effect, Q323)
  EC50  =       1.31 mg ml À1 exposure at half of the maximal effect term (concentration to produce 50% of the maximum effect, Q321)
  gamma = (library default) Hill coefficient</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep\">SigmoidEmaxSweep</a>; this model only supplies the numbers. The x axis is one mg ml À1 of piperacillin per second of simulated time (exposure is in kg/m3): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0   (drug-free)
  exposure = EC50 (1.31 mg ml À1)  response -0.0001917
  exposure -> infinity  response -0.0003833</pre></body></html>"));
end Piperacillin_de2011_PD_n;
