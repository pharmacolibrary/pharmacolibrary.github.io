model Piperacillin_Dohmann2025_reference
  parameter Real Cl_ref = 9.777777777777778e-07 "Cl [m3/s]";
  parameter Real Vd_ref = 0.01542 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.517555,
    adminMass = 0.0045
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About piperacillin</h4><p>Piperacillin is an extended-spectrum penicillin antibiotic used to treat bacterial infections such as sepsis, urinary tract, skin, and respiratory infections, including Pseudomonas and E. coli infections. It is an approved medicine, typically given by infusion, and is often combined with tazobactam in hospital settings.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q423787\">Wikidata Q423787</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>piperacillin</td></tr><tr><td>population:</td><td>patients with impaired renal function</td></tr><tr><td>source_paper:</td><td>Dohmann_2025</td></tr><tr><td>measured_compound:</td><td>piperacillin</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>bcp70153-tbl-0002</td></tr><tr><td>input:</td><td>PK_1C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>piperacillin 517.555 g/mol (drugbank)</td></tr></table><h4>Interpretation flags</h4><ul><li>dropped unlinked row (NIL): 'βeGFR' — extend the ontology if this is a real PK parameter (source ['bcp70153-tbl-0002:row4:col1', 'bcp70153-tbl-0002:row4:col2', 'bcp70153-tbl-0002:row4:col3'])</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=piperacillin</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of KA from de_2011: its label names a different analyte ('rats') — 'k max (3.11±0.02 h À1 for rats and 3.19 ± 1.39 h À1 for humans) for rats'</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Piperacillin_Dohmann2025_reference;
