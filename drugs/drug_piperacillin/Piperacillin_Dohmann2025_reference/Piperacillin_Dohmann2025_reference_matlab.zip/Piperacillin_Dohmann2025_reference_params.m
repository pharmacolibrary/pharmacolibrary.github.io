function p = Piperacillin_Dohmann2025_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: piperacillin   source: Dohmann_2025 / reference   route: iv_bolus
  % estimated (absent from source): F
  p.name  = 'Piperacillin_Dohmann2025_reference_params';
  p.drug  = 'piperacillin';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'iv_bolus';        % 'oral' | 'iv_bolus'
  p.depot = false;             % oral -> first-order absorption depot
  p.Vc = 15.42;                % central volume [L]
  p.CL = 3.52;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.0;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 4500.0;             % dose [mg]
end
