model Dobutamine_ma2015_reference
  parameter Real Cl_ref = 7.777777777777777e-08 "Cl [m3/s]";
  parameter Real Vd_ref = 0.034587 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.30138010000000004,
    adminMass = 0.0005
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About dobutamine</h4><p>Dobutamine is a cardiotonic sympathomimetic drug used to treat heart disease. It is an approved medication given as a cardiac stimulant, typically in hospital settings for acute heart conditions.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q422782\">Wikidata Q422782</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>dobutamine</td></tr><tr><td>population:</td><td>review reference</td></tr><tr><td>source_paper:</td><td>Šíma_2015</td></tr><tr><td>measured_compound:</td><td>dobutamine</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>dobutamine 301.38 g/mol (drugbank)</td></tr></table><h4>Interpretation flags</h4><ul><li>built from REVIEW reference values (Šíma_2015) — secondary source</li><li>volume reported by review</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 1555200, Tolerance = 1e-9, Interval = 1));
end Dobutamine_ma2015_reference;
