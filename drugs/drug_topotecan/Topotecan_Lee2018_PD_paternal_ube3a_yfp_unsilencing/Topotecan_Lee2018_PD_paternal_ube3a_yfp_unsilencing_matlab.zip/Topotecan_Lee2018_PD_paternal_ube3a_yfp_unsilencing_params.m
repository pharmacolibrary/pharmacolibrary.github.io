function p = Topotecan_Lee2018_PD_paternal_ube3a_yfp_unsilencing_params()
% Topotecan_Lee2018_PD_paternal_ube3a_yfp_unsilencing_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% topotecan Lee_2018::paternal_Ube3a_YFP_unsilencing: emax exposure-response sweep (response = E0 + Emax*frac). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one M per second, in SI inside (kg/m3, s). Response paternal Ube3a-YFP unsilencing in its own unit. Driver: topotecan (cited_pk).
p.E0 = 0.0;
p.Emax = 1.51;
p.EC50 = 3.04e-08;
p.gamma = 1.0;
p.slope = 0.0;
p.exposure_per_s = 1.0;
p.stop_time = 3.1e-07;
p.form = 'E0 + Emax*frac';
end
