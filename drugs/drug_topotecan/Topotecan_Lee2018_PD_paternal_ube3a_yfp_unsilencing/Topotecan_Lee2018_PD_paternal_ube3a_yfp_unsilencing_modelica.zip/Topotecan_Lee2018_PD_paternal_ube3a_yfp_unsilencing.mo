model Topotecan_Lee2018_PD_paternal_ube3a_yfp_unsilencing
  "emax exposure-response sweep — Lee_2018 :: paternal Ube3a-YFP unsilencing (paternal Ube3a-YFP unsilencing)"
  extends Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep(
    E0 = 0,      // [1]
    Emax = 1.51,  // [1]
    EC50 = 3.04e-08,  // [M]
    gamma = 1,
    exposure_per_s = 1);   // 1 M per second
  // exposure_unit_unresolved: 'M' — the x axis is in the paper's unit, not SI
  // defaulted: E0
  // defaulted: gamma
  annotation(experiment(StartTime = 0, StopTime = 3.1e-07, Interval = 6.2e-10),
    Documentation(info = "<html><body><!-- drug-about --><h4>About topotecan</h4><p>Topotecan is a topoisomerase I inhibitor used to treat cancers such as ovarian cancer, small cell lung cancer, and cervical cancer. It remains authorised in the European Union for several cancer indications and is used in oncology care, though some EU marketing applications have been withdrawn.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q419953\">Wikidata Q419953</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h4>Topotecan_Lee2018_PD_paternal_ube3a_yfp_unsilencing</h4><p>The steady-state exposure-response curve of Lee HM et al., <i>Molecular autism 9:45</i> 2018 (<a href=\"https://doi.org/10.1186/s13229-018-0228-2\">doi:10.1186/s13229-018-0228-2</a>) — paternal Ube3a-YFP unsilencing against topotecan M — obtained by sweeping the driver instead of simulating a dose. Model family: emax.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = (library default) drug-free response (baseline)
  Emax  =       1.51          maximal effect term (Emax, Q320)
  EC50  =   3.04e-08 M        exposure at half of the maximal effect term (EC50, Q321)
  gamma = (library default) Hill coefficient</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep\">SigmoidEmaxSweep</a>; this model only supplies the numbers. The x axis is one M of topotecan per second of simulated time: there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0   (drug-free)
  exposure = EC50 (3.04e-08 M)  response 0.755
  exposure -> infinity  response 1.51</pre></body></html>"));
end Topotecan_Lee2018_PD_paternal_ube3a_yfp_unsilencing;
