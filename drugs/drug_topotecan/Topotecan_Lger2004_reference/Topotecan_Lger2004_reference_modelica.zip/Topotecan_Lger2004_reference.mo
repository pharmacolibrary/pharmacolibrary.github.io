model Topotecan_Lger2004_reference
  parameter Real Cl_ref = 1.7222222222222224e-05 "Cl [m3/s]";
  parameter Real cov_crcl_0 = 0 "crcl covariate";
  parameter Real Vd_ref = 0.027 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref*(1 + (20.0)*cov_crcl_0),
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.42144580000000004,
    adminMass = 1e-05
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About topotecan</h4><p>Topotecan is a topoisomerase I inhibitor used to treat cancers such as ovarian cancer, small cell lung cancer, and cervical cancer. It remains authorised in the European Union for several cancer indications and is used in oncology care, though some EU marketing applications have been withdrawn.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q419953\">Wikidata Q419953</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>topotecan</td></tr><tr><td>population:</td><td>patients receiving oral or intravenous topotecan</td></tr><tr><td>source_paper:</td><td>Léger_2004</td></tr><tr><td>measured_compound:</td><td>topotecan</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>tbl3</td></tr><tr><td>input:</td><td>PK_1C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>topotecan 421.446 g/mol (drugbank)</td></tr></table><h4>Interpretation flags</h4><ul><li>dropped value-less row: 'CL(l h−1)=(θ1+θ2 × CrCl) × (1−θ3 × PS)' (captured trailing unit '1−θ3 × PS' for child rows)</li><li>dropped value-less row: 'Interday variability of CL'</li><li>dropped value-less row: 'Central volume: V1 (l)=θ4 × body weight'</li><li>dropped value-less row: 'Interday variability of V1'</li><li>dropped value-less row: 'Peripheral volume: V2 (l)=θ5'</li><li>dropped value-less row: 'Intercompartmental clearance: Q(l h−1)=θ6'</li><li>dropped value-less row: 'Interday variability of F'</li><li>dropped value-less row: 'Constant rate of absorption: Ka(h−1)=θ9'</li><li>dropped value-less row: 'Lag time (h)=θ10'</li><li>unit '1−θ3 × PS' inherited from a section-header row for CL (not printed on this row itself) — see the unit_dimension_mismatch check below if this is wrong</li><li>unit_dimension_unknown: '1−θ3 × PS' (CL)</li><li>unit '1−θ3 × PS' inherited from a section-header row for CL (not printed on this row itself) — see the unit_dimension_mismatch check below if this is wrong</li><li>unit_dimension_unknown: '1−θ3 × PS' (CL)</li><li>dropped duplicate Q22 ('CL=θ1 × (1−θ3 × PS)', value '+47') — already have one for this compound</li><li>unit '1−θ3 × PS' inherited from a section-header row for V1 (not printed on this row itself) — see the unit_dimension_mismatch check below if this is wrong</li><li>unit_dimension_unknown: '1−θ3 × PS' (V1)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Topotecan_Lger2004_reference;
