function p = Valdecoxib_Tan2016_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: valdecoxib   source: Tan_2016 / reference   route: oral
  % estimated (absent from source): ka
  p.name  = 'Valdecoxib_Tan2016_reference_params';
  p.drug  = 'valdecoxib';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 294.0;                % central volume [L]
  p.CL = 667.1;                % clearance [L/h]
  p.Vp = [9100.0];             % peripheral volumes [L]
  p.Q  = [440.3];             % inter-compartmental clearances [L/h]
  p.ka = 0.5;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 10.0;             % dose [mg]
end
