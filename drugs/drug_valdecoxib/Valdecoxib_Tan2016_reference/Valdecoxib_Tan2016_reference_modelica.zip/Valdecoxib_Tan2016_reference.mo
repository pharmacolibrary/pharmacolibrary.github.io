model Valdecoxib_Tan2016_reference
  parameter Real Cl_ref = 0.00018530555555555555 "Cl [m3/s]";
  parameter Real Vd_ref = 0.29400000000000004 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_3C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.314359,
    adminMass = 1e-05,
    ka = 0.0001388888888888889,
    Tlag = 0.0,
    k12 = 0.000416005291005291,
    k21 = 1.3440170940170942e-05
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About valdecoxib</h4><p>Valdecoxib, a COX-2 inhibitor painkiller, was used to treat osteoarthritis, rheumatoid arthritis, and pain such as dysmenorrhea. It has been withdrawn from the market, including its authorised products in the European Union, and is no longer in use.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q347613\">Wikidata Q347613</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>valdecoxib</td></tr><tr><td>population:</td><td>children undergoing tonsillectomy +/- adenoidectomy</td></tr><tr><td>source_paper:</td><td>Tan_2016</td></tr><tr><td>measured_compound:</td><td>valdecoxib</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>3C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_3C_enteral: apparent (/F) parameterization ⇒ extravascular dosing</td></tr><tr><td>molar_masses:</td><td>valdecoxib 314.359 g/mol (drugbank)</td></tr></table><p><b>Defaulted (base-class default used):</b> ka, Tlag, k13, k31.</p><h4>Interpretation flags</h4><ul><li>dropped duplicate Q30 ('Q3PARECOXIB', value 6.02) — already have one for this compound</li><li>apparent-ness (ontology-grounded): parameterization=apparent, measured_compound=valdecoxib</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Valdecoxib_Tan2016_reference;
