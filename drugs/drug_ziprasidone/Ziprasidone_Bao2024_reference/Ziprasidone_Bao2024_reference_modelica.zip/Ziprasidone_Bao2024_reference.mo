model Ziprasidone_Bao2024_reference
  parameter Real Cl_ref = 5.205555555555556e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.11023999999999999 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 0.9,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.41293599999999997,
    adminMass = 8e-05,
    ka = 0.0001388888888888889,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About ziprasidone</h4><p>Ziprasidone is an antipsychotic used to treat schizophrenia and related psychotic conditions such as schizoaffective disorder, and has also been used for anxiety and Tourette syndrome. It is an approved medicine used in routine psychiatric care, though it carries a boxed warning.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q205517\">Wikidata Q205517</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>ziprasidone</td></tr><tr><td>population:</td><td>Chinese psychiatric disorder patients</td></tr><tr><td>source_paper:</td><td>Bao_2024</td></tr><tr><td>measured_compound:</td><td>ziprasidone</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>ziprasidone 412.936 g/mol (drugbank)</td></tr></table><p><b>Defaulted (base-class default used):</b> F, Tlag.</p><h4>Interpretation flags</h4><ul><li>apparent-by-design (ADVISORY, codes unchanged): extravascular dosing with no identifiable F, so these reported disposition parameters are likely apparent unless the model puts first-pass in its structure — Q22 (CL); Q61 (V)</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=ziprasidone</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of TLAG: primary's parameterization (rate-constant / ka-only) does not use it</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 97200, Tolerance = 1e-9, Interval = 1));
end Ziprasidone_Bao2024_reference;
