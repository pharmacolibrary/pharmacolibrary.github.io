function p = Ziprasidone_Li2026_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: ziprasidone   source: Li_2026 / reference   route: oral
  % estimated (absent from source): F
  p.name  = 'Ziprasidone_Li2026_reference_params';
  p.drug  = 'ziprasidone';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 950.0;                % central volume [L]
  p.CL = 8.41;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.5;                % absorption rate [1/h]
  p.F  = 0.9;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 80.0;             % dose [mg]
end
