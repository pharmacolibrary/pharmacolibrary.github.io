model Ziprasidone_Li2018_reference
  parameter Real Cl_ref = 7.055555555555555e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 2.15 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.41293599999999997,
    adminMass = 8e-05,
    ka = 0.0007916666666666666,
    Tlag = 0.0,
    k12 = 1.0865633074935401e-06,
    k21 = 1.3905423280423281e-05
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About ziprasidone</h4><p>Ziprasidone is an antipsychotic used to treat schizophrenia and related psychotic conditions such as schizoaffective disorder, and has also been used for anxiety and Tourette syndrome. It is an approved medicine used in routine psychiatric care, though it carries a boxed warning.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q205517\">Wikidata Q205517</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>ziprasidone</td></tr><tr><td>population:</td><td>review reference</td></tr><tr><td>source_paper:</td><td>Li_2018</td></tr><tr><td>measured_compound:</td><td>ziprasidone</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_2C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>ziprasidone 412.936 g/mol (drugbank)</td></tr></table><p><b>Defaulted (base-class default used):</b> Tlag.</p><h4>Interpretation flags</h4><ul><li>built from REVIEW reference values (Li_2018) — secondary source</li><li>volume reported by review</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 1123200, Tolerance = 1e-9, Interval = 1));
end Ziprasidone_Li2018_reference;
