function p = Ziprasidone_Li2018_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: ziprasidone   source: Li_2018 / reference   route: oral
  p.name  = 'Ziprasidone_Li2018_reference_params';
  p.drug  = 'ziprasidone';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 2150.0;                % central volume [L]
  p.CL = 25.4;                % clearance [L/h]
  p.Vp = [168.0];             % peripheral volumes [L]
  p.Q  = [8.41];             % inter-compartmental clearances [L/h]
  p.ka = 2.85;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 80.0;             % dose [mg]
end
