function p = Suramin_Naviaux2017_social_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: suramin   source: Naviaux_2017 / social   route: iv_bolus
  % estimated (absent from source): F
  p.name  = 'Suramin_Naviaux2017_social_params';
  p.drug  = 'suramin';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'iv_bolus';        % 'oral' | 'iv_bolus'
  p.depot = false;             % oral -> first-order absorption depot
  p.Vc = 58.1;                % central volume [L]
  p.CL = 0.1365;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.0;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 1400.0;             % dose [mg]
end
