model Suramin_Naviaux2017_social
  parameter Real Cl_ref = 3.7916666666666665e-08 "Cl [m3/s]";
  parameter Real Vd_ref = 0.0581 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 1.29726,
    adminMass = 0.0014
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About suramin</h4><p>Suramin is an antiprotozoal drug developed against trypanosomiasis and related parasitic infections. It is currently classed as investigational and is not an approved medicine in the European Union.</p><p><small><b>Unverified</b> — written by glm-5.3-flash from general knowledge (no Wikidata entry found) and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>suramin</td></tr><tr><td>population:</td><td>children with autism spectrum disorder</td></tr><tr><td>source_paper:</td><td>Naviaux_2017</td></tr><tr><td>measured_compound:</td><td>suramin</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>acn3424-tbl-0004</td></tr><tr><td>input:</td><td>PK_1C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>suramin 1297.26 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>dropped unlinked row (NIL): 'Outcome' — extend the ontology if this is a real PK parameter (source ['acn3424-tbl-0004:row0:col6', 'acn3424-tbl-0004:row1:col6'])</li><li>dropped unlinked row (NIL): 'Suramin' — extend the ontology if this is a real PK parameter (source ['acn3424-tbl-0004:row3:col6', 'acn3424-tbl-0004:row4:col6', 'acn3424-tbl-0004:row5:col6', 'acn3424-tbl-0004:row6:col6', 'acn3424-tbl-0004:row7:col6'])</li><li>dropped unlinked row (NIL): 'Placebo' — extend the ontology if this is a real PK parameter (source ['acn3424-tbl-0004:row9:col6', 'acn3424-tbl-0004:row10:col6', 'acn3424-tbl-0004:row11:col6', 'acn3424-tbl-0004:row12:col6'])</li><li>salvaged Q61 ('steady‐state volume of distribution'=0.83) from results prose — parameter table was unreadable</li><li>salvaged Q22 ('clearance'=1.95) from results prose — parameter table was unreadable</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=suramin</li><li>held at status:extracted — NIL link or unit issue (mismatch/unknown/normalisation-failed) present</li><li>status held at route_to_review — not promoted</li><li>population split: 'social' subgroup of Naviaux_2017 (paper reports 13 populations: abc, ados‐2, atec, cgi, e. language, eowpvt, language, rbq, restr/rep, sociability, social, social inter., stereotypy)</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 5443200, Tolerance = 1e-9, Interval = 1));
end Suramin_Naviaux2017_social;
