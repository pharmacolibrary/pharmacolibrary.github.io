model InterferonBeta1a_Savic2017_reference
  parameter Real Cl_ref = 1.0916666666666665e-05 "Cl [m3/s]";
  parameter Real Vd_ref = 0.365 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C_enteral(
    weight = 70.0,
    F = 0.9,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    adminMass = 0.0001,
    ka = 0.00030000000000000003,
    Tlag = 1148.4,
    k12 = 4.08675799086758e-05
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About interferon_beta_1a</h4><p>Interferon beta-1a is a drug used to treat multiple sclerosis, including relapsing-remitting, secondary progressive, and primary progressive forms. It is an approved medicine and remains in use, with some investigational applications as well.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q2450337\">Wikidata Q2450337</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>interferon_beta_1a</td></tr><tr><td>population:</td><td>review reference</td></tr><tr><td>source_paper:</td><td>Savic_2017</td></tr><tr><td>measured_compound:</td><td>interferon_beta_1a</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_2C_enteral: absorption rate constant reported</td></tr></table><p><b>Defaulted (base-class default used):</b> F, k21.</p><h4>Interpretation flags</h4><ul><li>built from REVIEW reference values (Savic_2017) — secondary source</li><li>volume reported by review</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 126000, Tolerance = 1e-9, Interval = 1));
end InterferonBeta1a_Savic2017_reference;
