% Run (SimBiology): build model + dose, simulate 0..35.0 h, plot.
p = InterferonBeta1a_Savic2017_reference_params();
[model, dose, variant] = build_sb_pk(p);
sd = simulate_sb(model, variant, dose, 35.0);
