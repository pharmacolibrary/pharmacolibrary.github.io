function p = InterferonBeta1a_Savic2017_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: interferon_beta_1a   source: Savic_2017 / reference   route: oral
  % estimated (absent from source): F, dose
  p.name  = 'InterferonBeta1a_Savic2017_reference_params';
  p.drug  = 'interferon_beta_1a';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 365.0;                % central volume [L]
  p.CL = 39.3;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 1.08;                % absorption rate [1/h]
  p.F  = 0.9;                 % bioavailability [0-1]
  p.Tlag = 0.319;             % absorption lag [h]
  p.dose = 100.0;             % dose [mg]
end
