function p = Ixazomib_Srimani2022_PD_m_protein_params()
% Ixazomib_Srimani2022_PD_m_protein_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% ixazomib Srimani_2022::M_protein: indirect_response_i exposure-response sweep (response = E0/(1 + Emax*frac)). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one ng/ml per second, in SI inside (kg/m3, s). Response M-protein in g/L. Driver: ixazomib (cited_pk).
p.E0 = 0.0;
p.Emax = 75.8;
p.EC50 = 3.29e-06;
p.gamma = 1.0;
p.slope = 0.0;
p.exposure_per_s = 1e-06;
p.stop_time = 33.0;
p.form = 'E0/(1 + Emax*frac)';
end
