model Ixazomib_Srimani2022_PD_m_protein
  "indirect_response_i exposure-response sweep — Srimani_2022 :: M-protein (M-protein)"
  extends Pharmacolibrary.Pharmacodynamic.IndirectTurnoverSweep(
    E0 = 0,      // [1]
    Emax = 75.8,  // type IV effect term
    EC50 = 3.29e-06,  // [kg/m3; ng/ml × 1e-06]
    gamma = 1,
    exposure_per_s = 1e-06);   // 1 ng/ml per second
  // emax_not_a_fraction: type I needs Imax ≤ 1 but the record has 75.8; bound as the reciprocal stimulation form (IV) the paper fitted
  // defaulted: E0
  // defaulted: gamma
  annotation(experiment(StartTime = 0, StopTime = 33, Interval = 0.066),
    Documentation(info = "<html><body><!-- drug-about --><h4>About ixazomib</h4><p>Ixazomib is a proteasome inhibitor used to treat multiple myeloma and amyloidosis. It is an approved anticancer medicine authorised in the European Union for multiple myeloma.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q20948663\">Wikidata Q20948663</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h4>Ixazomib_Srimani2022_PD_m_protein</h4><p>The steady-state exposure-response curve of Srimani JK et al., <i>CPT: pharmacometrics &amp; systems pharmacology 11(8):1085–1099</i> 2022 (<a href=\"https://doi.org/10.1002/psp4.12815\">doi:10.1002/psp4.12815</a>) — M-protein [g/L] against ixazomib ng/ml — obtained by sweeping the driver instead of simulating a dose. Model family: indirect_response_i.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = (library default) drug-free response (baseline)
  Emax  =       75.8          maximal effect term (Imax, Q323)
  EC50  =       3.29 ng/ml    exposure at half of the maximal effect term (IC50, Q322)
  gamma = (library default) Hill coefficient</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.IndirectTurnoverSweep\">IndirectTurnoverSweep</a>; this model only supplies the numbers. The x axis is one ng/ml of ixazomib per second of simulated time (exposure is in kg/m3): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><p>The effect term enters as a reciprocal (steady state of <code>der(R) = Kin - Kout*(1 + Emax*frac)*R</code>), so EC50 is the exposure at half the maximal STIMULATION of turnover, not at half the response.</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0   (drug-free)
  exposure = EC50 (3.29 ng/ml)  response 0
  exposure -> infinity  response 0</pre></body></html>"));
end Ixazomib_Srimani2022_PD_m_protein;
