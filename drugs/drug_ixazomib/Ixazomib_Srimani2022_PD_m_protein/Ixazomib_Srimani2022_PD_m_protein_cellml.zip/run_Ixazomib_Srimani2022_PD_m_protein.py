#!/usr/bin/env python3
"""Sweep Ixazomib_Srimani2022_PD_m_protein.cellml — the curve is evaluated directly (one ODE for the swept exposure and
one algebraic response), so no CellML tooling is needed; OpenCOR opens the file as-is.
Writes Ixazomib_Srimani2022_PD_m_protein.csv/.json/.png next to this script."""
import json, os, math
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

BASE = os.path.join(os.path.dirname(os.path.abspath(__file__)), "Ixazomib_Srimani2022_PD_m_protein")
E0, Emax, EC50, gamma, slope, exposure_per_s = 0.0, 75.8, 3.29e-06, 1.0, 0.0, 1e-06
def response(exposure):
    frac = exposure**gamma / (EC50**gamma + exposure**gamma) if exposure > 0 else 0.0
    log = math.log
    return E0/(1 + Emax*(exposure**gamma / (EC50**gamma + exposure**gamma)))
x = [exposure_per_s * 33.0 * i / 500 for i in range(501)]
y = [response(v) for v in x]
with open(BASE + ".csv", "w") as f:
    f.write("exposure_si,response\n")
    for xi, yi in zip(x, y):
        f.write("%r,%r\n" % (xi, yi))
with open(BASE + ".json", "w") as f:
    json.dump({"model": "Ixazomib_Srimani2022_PD_m_protein", "exposure_si": x, "response": y}, f, indent=2)
plt.figure(); plt.plot(x, y, linewidth=1.5)
plt.xlabel("exposure [ng/ml]"); plt.ylabel("response [g/L]")
plt.title("Ixazomib_Srimani2022_PD_m_protein"); plt.grid(True, alpha=0.3); plt.tight_layout(); plt.savefig(BASE + ".png", dpi=150)
print("wrote %s.csv, %s.json, %s.png" % (BASE, BASE, BASE))
