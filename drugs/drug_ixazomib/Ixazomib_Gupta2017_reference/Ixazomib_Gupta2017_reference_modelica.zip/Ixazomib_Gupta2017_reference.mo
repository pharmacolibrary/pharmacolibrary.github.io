model Ixazomib_Gupta2017_reference
  parameter Real Cl_ref = 1.7222222222222222e-07 "Cl [m3/s]";
  parameter Real Vd_ref = 0.0026200000000000004 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C_enteral(
    weight = 70.0,
    F = -0.55,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.36102999999999996,
    adminMass = 4.3e-07,
    ka = -0.0003027777777777778,
    Tlag = -5472.0,
    k12 = 0.00034563189143341813,
    k21 = 0.00015803761877060304
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About ixazomib</h4><p>Ixazomib is a proteasome inhibitor used to treat multiple myeloma and amyloidosis. It is an approved anticancer medicine authorised in the European Union for multiple myeloma.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q20948663\">Wikidata Q20948663</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>ixazomib</td></tr><tr><td>population:</td><td>adults with multiple myeloma</td></tr><tr><td>source_paper:</td><td>Gupta_2017</td></tr><tr><td>measured_compound:</td><td>ixazomib</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>Tab3</td></tr><tr><td>input:</td><td>PK_2C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>ixazomib 361.03 g/mol (drugbank)</td></tr></table><h4>Interpretation flags</h4><ul><li>unit_dimension_unknown: 'log K a' (kabs)</li><li>unit_dimension_unknown: 'log CL' (CL)</li><li>unit_dimension_unknown: 'log V 2' (V1)</li><li>unit_dimension_unknown: 'log Q3' (Q3)</li><li>unit_dimension_unknown: 'log V 3' (V2)</li><li>unit_dimension_unknown: 'log Q4' (Q)</li><li>unit_dimension_unknown: 'log V 4' (V3)</li><li>unit_dimension_unknown: 'log T LAG' (tlag)</li><li>unit_dimension_unknown: 'V 4[BSA]' (V2)</li><li>dropped duplicate Q64 ('Impact of BSA on V 4 (V 4[BSA])', value '2.06') — already have one for this compound</li><li>implicit units: 'Absorption rate constant (log K a)' → 1/h (from the paper text: &quot;Table 3 explicitly states the untransformed parameter for Absorption rate constant as '1/h ~ t 1/2 = 124 min'.&quot;)</li><li>implicit units: 'Systemic clearance (log CL)' → L/h (from the paper text: &quot;Table 3 explicitly states the untransformed parameter for Systemic clearance as '1.86 L/h'. The text also confirms 'syst&quot;)</li><li>implicit units: 'Central volume of distribution (log V 2)' → L (from the paper text: &quot;Table 3 explicitly states the untransformed parameter for Central volume of distribution as '13.7 L'. The text also conf&quot;)</li><li>implicit units: 'First inter-compartmental clearance (log Q3)' → L/h (from the paper text: &quot;Table 3 explicitly states the untransformed parameter for First inter-compartmental clearance as '5.18 L/h'.&quot;)</li><li>implicit units: 'Volume of the first peripheral compartment (log V 3)' → L (from the paper text: &quot;Table 3 explicitly states the untransformed parameter for Volume of the first peripheral compartment as '309 L'.&quot;)</li><li>implicit units: 'Second inter-compartmental clearance (log Q4)' → L/h (from the paper text: &quot;Table 3 explicitly states the untransformed parameter for Second inter-compartmental clearance as '27.4 L/h' (implied by&quot;)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Ixazomib_Gupta2017_reference;
