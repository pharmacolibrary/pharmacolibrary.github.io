function p = Ixazomib_Gupta2017_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: ixazomib   source: Gupta_2017 / reference   route: oral
  % estimated (absent from source): F
  p.name  = 'Ixazomib_Gupta2017_reference_params';
  p.drug  = 'ixazomib';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 2.62;                % central volume [L]
  p.CL = 0.62;                % clearance [L/h]
  p.Vp = [5.73];             % peripheral volumes [L]
  p.Q  = [3.26];             % inter-compartmental clearances [L/h]
  p.ka = -1.09;                % absorption rate [1/h]
  p.F  = 0.9;                 % bioavailability [0-1]
  p.Tlag = -1.52;             % absorption lag [h]
  p.dose = 0.43;             % dose [mg]
end
