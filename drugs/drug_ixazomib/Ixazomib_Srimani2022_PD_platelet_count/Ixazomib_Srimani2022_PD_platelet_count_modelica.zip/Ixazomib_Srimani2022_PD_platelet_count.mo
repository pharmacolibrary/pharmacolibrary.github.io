model Ixazomib_Srimani2022_PD_platelet_count
  "linear exposure-response sweep — Srimani_2022 :: platelet count (platelet count)"
  extends Pharmacolibrary.Interfaces.PartialExposureResponseSweep(
    E0 = 203,      // [e9/L]
    Emax = 0, EC50 = 1,      // unused by a line
    exposure_per_s = 1e-06);
  parameter Real slope = 0.238095238095   "[meter ** 3 / kilogram / second; /week/(ng/ml) × 1.65344]";
equation
  response = E0 + slope*exposure;
  // family_inferred: the record's model family is disease_progression; read from the parameters: a slope and no Emax — linear
  annotation(experiment(StartTime = 0, StopTime = 1000, Interval = 2),
    Documentation(info = "<html><body><!-- drug-about --><h4>About ixazomib</h4><p>Ixazomib is a proteasome inhibitor used to treat multiple myeloma and amyloidosis. It is an approved anticancer medicine authorised in the European Union for multiple myeloma.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q20948663\">Wikidata Q20948663</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h4>Ixazomib_Srimani2022_PD_platelet_count</h4><p>The steady-state exposure-response curve of Srimani JK et al., <i>CPT: pharmacometrics &amp; systems pharmacology 11(8):1085–1099</i> 2022 (<a href=\"https://doi.org/10.1002/psp4.12815\">doi:10.1002/psp4.12815</a>) — platelet count [e9/L] against ixazomib ng/ml — obtained by sweeping the driver instead of simulating a dose. Model family: linear.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    =        203 e9/L     drug-free response (baseline) (BL, Q324)
  slope =      0.144 /week/(ng/ml) change in response per unit of exposure (slpIXA, Q335)</pre><p>The algebra is <code>response = E0 + slope*exposure</code>; this model only supplies the numbers. The x axis is one ng/ml of ixazomib per second of simulated time (exposure is in kg/m3): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 203   (drug-free)</pre></body></html>"));
end Ixazomib_Srimani2022_PD_platelet_count;
