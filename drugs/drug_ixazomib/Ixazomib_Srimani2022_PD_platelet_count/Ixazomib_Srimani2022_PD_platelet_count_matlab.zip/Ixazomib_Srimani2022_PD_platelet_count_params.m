function p = Ixazomib_Srimani2022_PD_platelet_count_params()
% Ixazomib_Srimani2022_PD_platelet_count_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% ixazomib Srimani_2022::platelet_count: linear exposure-response sweep (response = E0 + slope*exposure). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one ng/ml per second, in SI inside (kg/m3, s). Response platelet count in e9/L. Driver: ixazomib (cited_pk).
p.E0 = 203.0;
p.Emax = 0.0;
p.EC50 = 1.0;
p.gamma = 1.0;
p.slope = 0.23809523809523808;
p.exposure_per_s = 1e-06;
p.stop_time = 1000.0;
p.form = 'E0 + slope*exposure';
end
