function p = Acalabrutinib_Edlund2022_reference_params()
% Auto-generated parent-metabolite PK model (clinical units: mg, L, h).
%   drug: acalabrutinib   source: Edlund_2022 / reference   PK_3M_9C parent + 1 metabolite(s), 4 compartments, oral
%   dA/dt = K*A; C = A./V. K(i,j) is the rate [1/h] at which compartment j feeds i:
%   a metabolic conversion carries MW_dst/MW_src, so one molecule forms one molecule.
%   molar masses: C_central=465.517 g/mol C_M1=481.516 g/mol
  p.name  = 'Acalabrutinib_Edlund2022_reference_params';
  p.drug  = 'acalabrutinib';
  p.kind  = 'network';
  p.template = 'PK_3M_9C';
  p.states = {'central', 'peripheral', 'central_M1', 'peripheral_M1'};
  p.V = [31.0, 110.0, 22.700000000000003, 89.2];          % compartment volumes [L]
  p.K = [-4.9967741935483865, 0.18999999999999997, 0.0, 0.0;
         0.6741935483870968, -0.18999999999999997, 0.0, 0.0;
         4.471140134378516, 0.0, -2.1365638766519823, 0.2993273542600897;
         0.0, 0.0, 1.1762114537444934, -0.2993273542600897];
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;
  p.dose_into = 1;   % central
  p.ka = 1.48;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h] (in dose_start)
  p.dose = 100.0;             % dose [mg]
  p.dose_start = 0.016666666666666666;   % dose enters from [h] ...
  p.dose_duration = 0.16666666666666666;   % ... at a constant rate for [h]
  p.out_idx = [1.0, 3.0];
  p.out_names = {'C_central', 'C_M1'};
  p.out_labels = {'acalabrutinib', 'ACP-5862'};
end
