// parent + metabolites (ACP-5862): PK_3M_9C — formed from central; parent 2, metabolites [2]
model Acalabrutinib_Edlund2022_reference
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_3M_9C(
    Vd1 = 0.031,
    Vd2 = 0.11,
    q12 = 5.805555555555555e-06,
    q21 = 5.805555555555555e-06,
    q1_m11 = 3.722222222222222e-05,
    CL1 = 0.0,
    Vd1m1 = 0.0227,
    CLm1 = 6.055555555555555e-06,
    Vd2m1 = 0.0892,
    qm11_m12 = 7.416666666666667e-06,
    qm12_m11 = 7.416666666666667e-06,
    MW = 0.465517,
    MW_m1 = 0.481516,
    F = 1,
    ka = 0.0004111111111111111,
    Tlag = 0.0,
    adminDuration = 600,
    adminCount = 1,
    adminMass = 0.0001
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About acalabrutinib</h4><p>Acalabrutinib is a Bruton's tyrosine kinase inhibitor used to treat mantle cell lymphoma and chronic lymphocytic leukemia. It is an approved medicine, also still under investigation for other uses.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q23668732\">Wikidata Q23668732</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>acalabrutinib</td></tr><tr><td>population:</td><td>adults with B-cell malignancies and healthy subjects</td></tr><tr><td>source_paper:</td><td>Edlund_2022</td></tr><tr><td>measured_compound:</td><td>acalabrutinib</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>parent_metabolite</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>bcp14988-tbl-0001</td></tr><tr><td>input:</td><td>PK_3M_9C: absorption rate constant reported; formation of ACP-5862: fm not identifiable (CLm/F, Vm/F reported) — all of CL forms it; dose 100 mg (paper)</td></tr><tr><td>molar_masses:</td><td>ACP-5862 481.516 g/mol (pubchem); acalabrutinib 465.517 g/mol (drugbank)</td></tr></table><p><b>Defaulted (base-class default used):</b> Tlag.</p><h4>Interpretation flags</h4><ul><li>dropped duplicate Q27 ('Healthy subject—CL/F', value '0.467') — already have one for this compound</li><li>dropped duplicate Q82 ('Healthy subject—Vp/F', value '-0.556') — already have one for this compound</li><li>dropped duplicate Q27 ('ECOG 2—CL/F', value '-0.171') — already have one for this compound</li><li>apparent-ness (ontology-grounded): parameterization=apparent, measured_compound=acalabrutinib</li><li>template fit: PK_3M_9C — formed from central; parent 2, metabolites [2]</li><li>row roles (LLM): model_class=compartmental; 27/27 row label(s) assigned, 9 linked by role; re-tagged parent→ACP-5862 ×16</li><li>skipped review gap-fill of TLAG: primary's parameterization (rate-constant / ka-only) does not use it</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Acalabrutinib_Edlund2022_reference;
