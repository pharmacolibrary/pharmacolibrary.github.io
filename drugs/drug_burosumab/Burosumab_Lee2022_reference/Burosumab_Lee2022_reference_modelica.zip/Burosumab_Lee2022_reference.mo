model Burosumab_Lee2022_reference
  parameter Real Cl_ref = 3.4375e-09 "Cl [m3/s]";
  parameter Real cov_wt_0 = 0 "wt covariate";
  parameter Real Vd_ref = 0.00902 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref*(1 + (0.912)*cov_wt_0),
    Vd = Vd_ref*(1 + (1.05)*cov_wt_0),
    adminDuration = 600,
    adminCount = 1,
    adminMass = 3.5e-06,
    ka = 0.0001388888888888889,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About burosumab</h4><p>Burosumab, a monoclonal antibody, is used to treat bone-mineralisation disorders such as familial hypophosphataemia, X-linked hypophosphataemic rickets and osteomalacia. It is an approved medicine, authorised in the European Union.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q28209068\">Wikidata Q28209068</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>burosumab</td></tr><tr><td>population:</td><td>adult and pediatric patients with X-linked hypophosphatemia</td></tr><tr><td>source_paper:</td><td>Lee_2022</td></tr><tr><td>measured_compound:</td><td>burosumab</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>jcph1950-tbl-0003</td></tr><tr><td>input:</td><td>PK_1C_enteral: apparent (/F) parameterization ⇒ extravascular dosing</td></tr></table><p><b>Defaulted (base-class default used):</b> ka, Tlag.</p><h4>Interpretation flags</h4><ul><li>column 'pk parameters (unit)' classified 'other' by the LLM but kept: the deterministic diagnostic-column test disagrees (a stratum column is a value column, not a statistic)</li><li>column 'pk parameters (unit)' classified 'other' by the LLM but kept: the deterministic diagnostic-column test disagrees (a stratum column is a value column, not a statistic)</li><li>column 'pk parameters (unit)' classified 'other' by the LLM but kept: the deterministic diagnostic-column test disagrees (a stratum column is a value column, not a statistic)</li><li>column 'pk parameters (unit)' classified 'other' by the LLM but kept: the deterministic diagnostic-column test disagrees (a stratum column is a value column, not a statistic)</li><li>column 'pk parameters (unit)' classified 'other' by the LLM but kept: the deterministic diagnostic-column test disagrees (a stratum column is a value column, not a statistic)</li><li>dropped unlinked row (NIL): 'Population mean parameters' — extend the ontology if this is a real PK parameter (source ['jcph1950-tbl-0003:row1:col1', 'jcph1950-tbl-0003:row1:col2'])</li><li>covariate level 'Covariate effect of WT on CL/F' → Q900:covariate_effect_of_wt_on_cl_f = 0.912 (linear_fractional on Q27)</li><li>apparent-ness (ontology-grounded): parameterization=apparent, measured_compound=burosumab</li><li>molar mass: none found for 'burosumab' — its concentrations stay mass-only</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of KA from Mehta_2025: its label names a different analyte ('typical') — 'absorption rate constant for typical patients'</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 9676800, Tolerance = 1e-9, Interval = 1));
end Burosumab_Lee2022_reference;
