function p = Burosumab_Mehta2025_PD_s1_params()
% Burosumab_Mehta2025_PD_s1_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% burosumab Mehta_2025::S1: emax exposure-response sweep (response = E0 + Emax*frac). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one ng/mL per second, in SI inside (kg/m3, s). Response S1 in mg/dL. Driver: burosumab (pk_record).
p.E0 = 0.0214;
p.Emax = 0.015499999999999998;
p.EC50 = 0.00827;
p.gamma = 1.0;
p.slope = 0.0;
p.exposure_per_s = 1e-06;
p.stop_time = 83000.0;
p.form = 'E0 + Emax*frac';
end
