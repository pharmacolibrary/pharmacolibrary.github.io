model Burosumab_Mehta2025_PD_s1
  "emax exposure-response sweep — Mehta_2025 :: S1 (Serum Phosphate Concentration)"
  extends Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep(
    E0 = 0.0214,      // [kg/m3; mg/dL × 0.01]
    Emax = 0.0155,  // [kg/m3; mg/dL × 0.01]
    EC50 = 0.00827,  // [kg/m3; ng/mL × 1e-06]
    gamma = 1,
    exposure_per_s = 1e-06);   // 1 ng/mL per second
  // defaulted: gamma
  annotation(experiment(StartTime = 0, StopTime = 83000, Interval = 166),
    Documentation(info = "<html><body><!-- drug-about --><h4>About burosumab</h4><p>Burosumab, a monoclonal antibody, is used to treat bone-mineralisation disorders such as familial hypophosphataemia, X-linked hypophosphataemic rickets and osteomalacia. It is an approved medicine, authorised in the European Union.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q28209068\">Wikidata Q28209068</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h4>Burosumab_Mehta2025_PD_s1</h4><p>The steady-state exposure-response curve of Mehta K et al., <i>Journal of clinical pharmacology 65(2):253–260</i> 2025 (<a href=\"https://doi.org/10.1002/jcph.6140\">doi:10.1002/jcph.6140</a>) — Serum Phosphate Concentration [mg/dL] against burosumab ng/mL — obtained by sweeping the driver instead of simulating a dose. Model family: emax.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    =       2.14 mg/dL    drug-free response (baseline) (Baseline phosphate level, Q324)
  Emax  =       1.55 mg/dL    maximal effect term (Maximal change in phosphate from BSL, Q320)
  EC50  =       8270 ng/mL    exposure at half of the maximal effect term (Burosumab concentration at half‐maximal effect, Q321)
  gamma = (library default) Hill coefficient</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep\">SigmoidEmaxSweep</a>; this model only supplies the numbers. The x axis is one ng/mL of burosumab per second of simulated time (exposure is in kg/m3): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0.0214   (drug-free)
  exposure = EC50 (8270 ng/mL)  response 0.02915
  exposure -> infinity  response 0.0369</pre></body></html>"));
end Burosumab_Mehta2025_PD_s1;
