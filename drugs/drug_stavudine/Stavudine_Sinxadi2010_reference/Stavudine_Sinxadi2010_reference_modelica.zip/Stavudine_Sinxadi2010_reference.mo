model Stavudine_Sinxadi2010_reference
  parameter Real Cl_ref = 4.9444444444444444e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 2.345 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.2242133,
    adminMass = 3e-05,
    ka = 0.0030833333333333333,
    Tlag = 1476.0
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About stavudine</h4><p>Stavudine is a nucleoside reverse-transcriptase inhibitor that was used to treat HIV infection and AIDS.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q423984\">Wikidata Q423984</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>stavudine</td></tr><tr><td>population:</td><td>HIV-1 infected African adults on stavudine</td></tr><tr><td>source_paper:</td><td>Sinxadi_2010</td></tr><tr><td>measured_compound:</td><td>stavudine</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>stavudine 224.213 g/mol (drugbank)</td></tr></table><h4>Interpretation flags</h4><ul><li>dropped value-less row: 'Fasting glucose'</li><li>dropped value-less row: '2 hour glucose'</li><li>dropped value-less row: 'Lactate'</li><li>dropped value-less row: 'Triglycerides'</li><li>dropped value-less row: 'Lipoatrophy score'</li><li>dropped value-less row: 'Impaired fasting glucose'</li><li>dropped value-less row: 'Impaired glucose tolerance'</li><li>dropped value-less row: 'Hyperlactataemia'</li><li>dropped value-less row: 'Hypertriglyceridaemia'</li><li>dropped value-less row: 'Lipoatrophy score >0'</li><li>salvaged Q27 ('apparent clearance'=17.8) from results prose — parameter table was unreadable</li><li>salvaged Q76 ('apparent volume of distribution'=33.5) from results prose — parameter table was unreadable</li><li>salvaged Q49 ('first-order absorption rate constant'=11.1) from results prose — parameter table was unreadable</li><li>salvaged Q83 ('absorption lag time'=0.41) from results prose — parameter table was unreadable</li><li>apparent-ness (ontology-grounded): parameterization=apparent, measured_compound=stavudine</li><li>held at status:extracted — NIL link or unit issue (mismatch/unknown/normalisation-failed) present</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 1728000, Tolerance = 1e-9, Interval = 1));
end Stavudine_Sinxadi2010_reference;
