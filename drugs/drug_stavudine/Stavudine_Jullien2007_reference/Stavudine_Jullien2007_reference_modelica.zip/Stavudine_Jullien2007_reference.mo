model Stavudine_Jullien2007_reference
  parameter Real Cl_ref = 4.583333333333333e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.0409 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.2242133,
    adminMass = 8e-05,
    ka = 0.0030833333333333333,
    Tlag = 1476.0
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About stavudine</h4><p>Stavudine is a nucleoside reverse-transcriptase inhibitor that was used to treat HIV infection and AIDS.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q423984\">Wikidata Q423984</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>stavudine</td></tr><tr><td>population:</td><td>children from birth to 16 years</td></tr><tr><td>source_paper:</td><td>Jullien_2007</td></tr><tr><td>measured_compound:</td><td>stavudine</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>stavudine 224.213 g/mol (drugbank)</td></tr></table><h4>Interpretation flags</h4><ul><li>dropped unlinked row (NIL): 'Mean calculated dose (children less than 2 weeks)' — extend the ontology if this is a real PK parameter (source ['Jullien_2007:abstract'])</li><li>dropped unlinked row (NIL): 'Mean calculated dose (children more than 2 weeks with bodyweight less than 30 kg)' — extend the ontology if this is a real PK parameter (source ['Jullien_2007:abstract'])</li><li>dropped unlinked row (NIL): 'Mean calculated dose (children with a bodyweight between 30 and 60 kg)' — extend the ontology if this is a real PK parameter (source ['Jullien_2007:abstract'])</li><li>apparent-ness (ontology-grounded): parameterization=apparent, measured_compound=stavudine</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li><li>gap-filled Q49 (kabs) from Sinxadi_2010's review values (primary lacked it)</li><li>gap-filled Q83 (tlag) from Sinxadi_2010's review values (primary lacked it)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Stavudine_Jullien2007_reference;
