model Risankizumab_Thomas2026_PD_pasi
  "indirect_response_i exposure-response sweep — Thomas_2026 :: PASI (Psoriasis Area and Severity Index (PASI))"
  extends Pharmacolibrary.Interfaces.PartialExposureResponseSweep(
    E0 = 23.4,      // [PASI]
    Emax = 1,  // type I effect term
    EC50 = 0.000106,  // [kg/m3; mg/L × 0.001]
    gamma = 1,
    exposure_per_s = 0.001);   // 1 mg/L per second
equation
  response = E0*(1 - Emax*frac);   // steady state, indirect response type I
  // defaulted: gamma
  annotation(experiment(StartTime = 0, StopTime = 1.1, Interval = 0.0022),
    Documentation(info = "<html><body><!-- drug-about --><h4>About risankizumab</h4><p>Risankizumab is a monoclonal antibody used to treat psoriasis, psoriatic arthritis, ulcerative colitis, and Crohn's disease. It is an approved interleukin inhibitor and is authorised in the European Union.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q25112466\">Wikidata Q25112466</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h4>Risankizumab_Thomas2026_PD_pasi</h4><p>The steady-state exposure-response curve of Thomas CM et al., <i>British journal of clinical pharmacology 92(7):2136–2146</i> 2026 (<a href=\"https://doi.org/10.1002/bcp.70477\">doi:10.1002/bcp.70477</a>) — Psoriasis Area and Severity Index (PASI) against risankizumab mg/L — obtained by sweeping the driver instead of simulating a dose. Model family: indirect_response_i.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    =       23.4 PASI     drug-free response (baseline) (BSL, Q324)
  Emax  =          1          maximal effect term (E max, Q323)
  EC50  =      0.106 mg/L     exposure at half of the maximal effect term (EC 50, Q322)
  gamma = (library default) Hill coefficient</pre><p>The algebra is <code>response = E0*(1 - Emax*frac)</code>; this model only supplies the numbers. The x axis is one mg/L of risankizumab per second of simulated time (exposure is in kg/m3): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 23.4   (drug-free)
  exposure = EC50 (0.106 mg/L)  response 11.7
  exposure -> infinity  response 0</pre></body></html>"));
end Risankizumab_Thomas2026_PD_pasi;
