function p = Risankizumab_Thomas2026_PD_pasi_params()
% Risankizumab_Thomas2026_PD_pasi_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% risankizumab Thomas_2026::PASI: indirect_response_i exposure-response sweep (response = E0*(1 - Emax*frac)). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one mg/L per second, in SI inside (kg/m3, s). Response PASI in its own unit. Driver: risankizumab (pk_record).
p.E0 = 23.4;
p.Emax = 1.0;
p.EC50 = 0.00010599999999999997;
p.gamma = 1.0;
p.slope = 0.0;
p.exposure_per_s = 0.001;
p.stop_time = 1.1;
p.form = 'E0*(1 - Emax*frac)';
end
