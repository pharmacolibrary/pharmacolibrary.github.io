function p = Risankizumab_Khatri2020_PD_pasi90_params()
% Risankizumab_Khatri2020_PD_pasi90_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% risankizumab Khatri_2020::PASI90: emax exposure-response sweep (response = E0 + Emax*frac). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one μg/mL per second, in SI inside (kg/m3, s). Response PASI90 in its own unit. Driver: risankizumab (cited_pk).
p.E0 = 0.616;
p.Emax = 0.812;
p.EC50 = 0.00044099999999999993;
p.gamma = 1.0;
p.slope = 0.0;
p.exposure_per_s = 0.001;
p.stop_time = 4.5;
p.form = 'E0 + Emax*frac';
end
