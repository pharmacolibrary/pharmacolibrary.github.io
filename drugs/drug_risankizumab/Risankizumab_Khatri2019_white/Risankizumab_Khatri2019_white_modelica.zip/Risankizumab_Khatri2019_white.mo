model Risankizumab_Khatri2019_white
  parameter Real Cl_ref = 2.777777777777778e-09 "Cl [m3/s]";
  parameter Real Vd_ref = 0.00912 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 0.9,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    adminMass = 1.8e-05,
    ka = 1.0509259259259259e-05,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About risankizumab</h4><p>Risankizumab is a monoclonal antibody used to treat psoriasis, psoriatic arthritis, ulcerative colitis, and Crohn's disease. It is an approved interleukin inhibitor and is authorised in the European Union.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q25112466\">Wikidata Q25112466</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>risankizumab</td></tr><tr><td>population:</td><td>healthy subjects and patients with psoriasis, GPP, or EP</td></tr><tr><td>source_paper:</td><td>Khatri_2019</td></tr><tr><td>measured_compound:</td><td>risankizumab</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>jcph1473-tbl-0005</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr></table><p><b>Defaulted (base-class default used):</b> F, Tlag.</p><h4>Interpretation flags</h4><ul><li>dropped unlinked row (NIL): '18 mg SC' — extend the ontology if this is a real PK parameter (source ['Khatri_2019_table_2:row0:col5'])</li><li>dropped unlinked row (NIL): '300 mg SC' — extend the ontology if this is a real PK parameter (source ['Khatri_2019_table_2:row8:col5'])</li><li>salvaged Q22 ('risankizumab plasma clearance'=0.24) from results prose — parameter table was unreadable</li><li>salvaged Q61 ('steady‐state volume of distribution'=9.12) from results prose — parameter table was unreadable</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=risankizumab</li><li>held at status:extracted — NIL link or unit issue (mismatch/unknown/normalisation-failed) present</li><li>status held at route_to_review — not promoted</li><li>population split: 'white (n = 6)' subgroup of Khatri_2019 (paper reports 7 populations: chinese (n = 6), japanese (n = 6), population estimate (%rse)a , b, risankizumab 1200 mg iv (n = 6), risankizumab 200 mg iv (n = 6), risankizumab 600 mg iv (n = 6), white (n = 6))</li><li>molar mass: none found for 'risankizumab' — its concentrations stay mass-only</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li><li>gap-filled Q49 (kabs) from Rodríguez-Fernández_2022's review values (primary lacked it)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 12096000, Tolerance = 1e-9, Interval = 1));
end Risankizumab_Khatri2019_white;
