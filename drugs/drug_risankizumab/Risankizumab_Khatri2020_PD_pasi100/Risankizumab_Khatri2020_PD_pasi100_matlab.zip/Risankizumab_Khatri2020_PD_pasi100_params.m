function p = Risankizumab_Khatri2020_PD_pasi100_params()
% Risankizumab_Khatri2020_PD_pasi100_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% risankizumab Khatri_2020::PASI100: emax exposure-response sweep (response = E0 + Emax*frac). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one μg/mL per second, in SI inside (kg/m3, s). Response PASI100 in its own unit. Driver: risankizumab (cited_pk).
p.E0 = 0.296;
p.Emax = 0.642;
p.EC50 = 0.009649999999999999;
p.gamma = 1.0;
p.slope = 0.0;
p.exposure_per_s = 0.001;
p.stop_time = 97.0;
p.form = 'E0 + Emax*frac';
end
