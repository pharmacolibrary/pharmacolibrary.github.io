model Risankizumab_Suleiman2019_reference
  parameter Real Cl_ref = 2.8125e-09 "Cl [m3/s]";
  parameter Real cov_weight = 1.0 "weight covariate (reference 1.0)";
  parameter Boolean cov_ada_1 = false "ada level 1";
  parameter Real Vd_ref = 0.004860000000000001 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C_enteral(
    weight = 70.0,
    F = 0.71,
    Cl = Cl_ref*(cov_weight/1.0)^(0.044) + (4.9537037037037036e-09)*(if cov_ada_1 then 1 else 0),
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    adminMass = 1e-08,
    ka = 2.650462962962963e-06,
    Tlag = 0.0,
    k12 = 1.5622618503276937e-06,
    k21 = 1.7864923747276687e-06
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About risankizumab</h4><p>Risankizumab is a monoclonal antibody used to treat psoriasis, psoriatic arthritis, ulcerative colitis, and Crohn's disease. It is an approved interleukin inhibitor and is authorised in the European Union.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q25112466\">Wikidata Q25112466</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>risankizumab</td></tr><tr><td>population:</td><td>healthy volunteers and subjects with moderate to severe plaque psoriasis</td></tr><tr><td>source_paper:</td><td>Suleiman_2019</td></tr><tr><td>measured_compound:</td><td>risankizumab</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>Tab3</td></tr><tr><td>input:</td><td>PK_2C_enteral: absorption rate constant reported</td></tr></table><p><b>Defaulted (base-class default used):</b> Tlag.</p><h4>Interpretation flags</h4><ul><li>table section iiv: 'IIV for CL (%CV)e' routed out of structural estimates ('Inter-individual correlation and residual variability')</li><li>table section iiv: 'IIV for CL (%CV)e' routed out of structural estimates ('Inter-individual correlation and residual variability')</li><li>table section iiv: 'IIV for Vc (%CV)e' routed out of structural estimates ('Inter-individual correlation and residual variability')</li><li>table section iiv: 'IIV for Vc (%CV)e' routed out of structural estimates ('Inter-individual correlation and residual variability')</li><li>table section iiv: 'IIV for ka (%CV)e' routed out of structural estimates ('Inter-individual correlation and residual variability')</li><li>table section iiv: 'IIV for ka (%CV)e' routed out of structural estimates ('Inter-individual correlation and residual variability')</li><li>table section iiv: 'Variance of IIV for Ff; (additive error model in logit domain)' routed out of structural estimates ('Inter-individual correlation and residual variability')</li><li>table section iiv: 'Variance of IIV for Ff; (additive error model in logit domain)' routed out of structural estimates ('Inter-individual correlation and residual variability')</li><li>table section iiv: 'Covariance between IIV CL and IIV Vc (% correlation)' routed out of structural estimates ('Inter-individual correlation and residual variability')</li><li>table section iiv: 'Covariance between IIV CL and IIV Vc (% correlation)' routed out of structural estimates ('Inter-individual correlation and residual variability')</li><li>table section iiv: 'Proportional residual error (%CV)' routed out of structural estimates ('Inter-individual correlation and residual variability')</li><li>table section iiv: 'Proportional residual error (%CV)' routed out of structural estimates ('Inter-individual correlation and residual variability')</li><li>dropped value-less row: 'Exponent for the effect of serum albumin on risankizumab CL'</li><li>dropped value-less row: 'Exponent for the effect of serum creatinine on risankizumab CL'</li><li>covariate level 'Exponent for the effect of C-reactive protein on risankizumab CL' → Q900:exponent_for_the_effect_of_c_reactive_protein_on_risankizumab_cl = 0.044 (power on Q22)</li><li>covariate effect for Q319 has no base parameter row (kept as unattached equation-variable)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 7257600, Tolerance = 1e-9, Interval = 1));
end Risankizumab_Suleiman2019_reference;
