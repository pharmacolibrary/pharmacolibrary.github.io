function p = Risankizumab_Suleiman2019_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: risankizumab   source: Suleiman_2019 / reference   route: oral
  p.name  = 'Risankizumab_Suleiman2019_reference_params';
  p.drug  = 'risankizumab';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 4.86;                % central volume [L]
  p.CL = 0.010125;                % clearance [L/h]
  p.Vp = [4.25];             % peripheral volumes [L]
  p.Q  = [0.027333];             % inter-compartmental clearances [L/h]
  p.ka = 0.009542;                % absorption rate [1/h]
  p.F  = 0.71;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 0.01;             % dose [mg]
end
