% Run (SimBiology): build model + dose, simulate 0..3192.0 h, plot.
p = Risankizumab_Thomas2026_reference_params();
[model, dose, variant] = build_sb_pk(p);
sd = simulate_sb(model, variant, dose, 3192.0);
