model Risankizumab_Khatri2020_PD_spga0_1
  "emax exposure-response sweep — Khatri_2020 :: sPGA0/1 (sPGA0/1)"
  extends Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep(
    E0 = 0.505,      // [1]
    Emax = 0.916,  // [1]
    EC50 = 0.000431,  // [kg/m3; μg/mL × 0.001]
    gamma = 1,
    exposure_per_s = 0.001);   // 1 μg/mL per second
  // defaulted: gamma
  annotation(experiment(StartTime = 0, StopTime = 4.4, Interval = 0.0088),
    Documentation(info = "<html><body><!-- drug-about --><h4>About risankizumab</h4><p>Risankizumab is a monoclonal antibody used to treat psoriasis, psoriatic arthritis, ulcerative colitis, and Crohn's disease. It is an approved interleukin inhibitor and is authorised in the European Union.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q25112466\">Wikidata Q25112466</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h4>Risankizumab_Khatri2020_PD_spga0_1</h4><p>The steady-state exposure-response curve of Khatri A et al., <i>Clinical pharmacology and therapeutics 107(2):378–387</i> 2020 (<a href=\"https://doi.org/10.1002/cpt.1594\">doi:10.1002/cpt.1594</a>) — sPGA0/1 against risankizumab μg/mL — obtained by sweeping the driver instead of simulating a dose. Model family: emax.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    =      0.505          drug-free response (baseline) (Exponent for effect of baseline hs-CRP on EC50, Q324)
  Emax  =      0.916          maximal effect term (Emax, Q320)
  EC50  =      0.431 μg/mL    exposure at half of the maximal effect term (EC50, Q321)
  gamma = (library default) Hill coefficient</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep\">SigmoidEmaxSweep</a>; this model only supplies the numbers. The x axis is one μg/mL of risankizumab per second of simulated time (exposure is in kg/m3): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0.505   (drug-free)
  exposure = EC50 (0.431 μg/mL)  response 0.963
  exposure -> infinity  response 1.421</pre></body></html>"));
end Risankizumab_Khatri2020_PD_spga0_1;
