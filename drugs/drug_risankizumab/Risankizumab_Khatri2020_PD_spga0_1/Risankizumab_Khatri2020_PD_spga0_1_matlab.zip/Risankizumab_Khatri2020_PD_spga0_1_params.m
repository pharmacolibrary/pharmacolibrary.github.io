function p = Risankizumab_Khatri2020_PD_spga0_1_params()
% Risankizumab_Khatri2020_PD_spga0_1_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% risankizumab Khatri_2020::sPGA0_1: emax exposure-response sweep (response = E0 + Emax*frac). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one μg/mL per second, in SI inside (kg/m3, s). Response sPGA0/1 in its own unit. Driver: risankizumab (cited_pk).
p.E0 = 0.505;
p.Emax = 0.916;
p.EC50 = 0.0004309999999999999;
p.gamma = 1.0;
p.slope = 0.0;
p.exposure_per_s = 0.001;
p.stop_time = 4.4;
p.form = 'E0 + Emax*frac';
end
