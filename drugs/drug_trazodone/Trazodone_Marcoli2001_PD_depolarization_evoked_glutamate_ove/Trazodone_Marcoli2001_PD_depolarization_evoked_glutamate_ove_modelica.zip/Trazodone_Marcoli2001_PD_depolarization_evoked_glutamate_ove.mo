model Trazodone_Marcoli2001_PD_depolarization_evoked_glutamate_ove
  "emax exposure-response sweep — Marcoli_2001 :: depolarization-evoked glutamate overflow (depolarization-evoked glutamate overflow)"
  extends Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep(
    E0 = 0,      // [1]
    Emax = -0.54,  // [1; % × 0.01]
    EC50 = 6.42,  // [1]
    gamma = 1,
    exposure_per_s = 1);   // 1 unit per second
  // imax_as_negative_emax: Imax (Q323) enters SigmoidEmaxSweep as −Emax
  // exposure_unit_unresolved: '' — the x axis is in the paper's unit, not SI
  // defaulted: E0
  // defaulted: gamma
  annotation(experiment(StartTime = 0, StopTime = 65, Interval = 0.13),
    Documentation(info = "<html><body><!-- drug-about --><h4>About trazodone</h4><p>Trazodone is an antidepressant used for depression, and also for conditions such as anxiety, insomnia, sleep-wake disorders, delirium and neurotic disorders. It is an approved medicine in widespread clinical use, though it carries a boxed warning.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q411457\">Wikidata Q411457</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h4>Trazodone_Marcoli2001_PD_depolarization_evoked_glutamate_ove</h4><p>The steady-state exposure-response curve of Marcoli M et al., <i>The Journal of pharmacology and experimental therapeutics 299(3):1106–1111</i> 2001 — depolarization-evoked glutamate overflow against trazodone — obtained by sweeping the driver instead of simulating a dose. Model family: emax.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = (library default) drug-free response (baseline)
  Emax  =         54 %        maximal effect term (maximal inhibition, Q323)
  EC50  =       6.42          exposure at half of the maximal effect term (pD2, Q321)
  gamma = (library default) Hill coefficient</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep\">SigmoidEmaxSweep</a>; this model only supplies the numbers. The x axis is one  of trazodone per second of simulated time: there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0   (drug-free)
  exposure = EC50 (6.42 )  response -0.27
  exposure -> infinity  response -0.54</pre></body></html>"));
end Trazodone_Marcoli2001_PD_depolarization_evoked_glutamate_ove;
