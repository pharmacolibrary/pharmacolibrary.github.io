function p = Trazodone_Marcoli2001_PD_depolarization_evoked_glutamate_ove_params()
% Trazodone_Marcoli2001_PD_depolarization_evoked_glutamate_ove_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% trazodone Marcoli_2001::depolarization_evoked_glutamate_overflow: emax exposure-response sweep (response = E0 + Emax*frac). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one SI per second, in SI inside (kg/m3, s). Response depolarization-evoked glutamate overflow in its own unit. Driver: trazodone (cited_pk).
p.E0 = 0.0;
p.Emax = -0.54;
p.EC50 = 6.42;
p.gamma = 1.0;
p.slope = 0.0;
p.exposure_per_s = 1.0;
p.stop_time = 65.0;
p.form = 'E0 + Emax*frac';
end
