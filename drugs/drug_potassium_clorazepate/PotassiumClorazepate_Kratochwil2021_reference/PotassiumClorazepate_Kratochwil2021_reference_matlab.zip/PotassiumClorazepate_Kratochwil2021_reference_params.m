function p = PotassiumClorazepate_Kratochwil2021_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: potassium_clorazepate   source: Kratochwil_2021 / reference   route: oral
  p.name  = 'PotassiumClorazepate_Kratochwil2021_reference_params';
  p.drug  = 'potassium_clorazepate';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 109.0;                % central volume [L]
  p.CL = 9.38;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 2.95;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 20.0;             % dose [mg]
end
