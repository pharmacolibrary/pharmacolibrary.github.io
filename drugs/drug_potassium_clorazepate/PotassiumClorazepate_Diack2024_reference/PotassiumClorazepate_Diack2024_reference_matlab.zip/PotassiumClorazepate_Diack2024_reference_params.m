function p = PotassiumClorazepate_Diack2024_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: potassium_clorazepate   source: Diack_2024 / reference   route: oral
  % estimated (absent from source): ka
  p.name  = 'PotassiumClorazepate_Diack2024_reference_params';
  p.drug  = 'potassium_clorazepate';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 25.076637;                % central volume [L]
  p.CL = 0.097083;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.5;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 20.0;             % dose [mg]
end
