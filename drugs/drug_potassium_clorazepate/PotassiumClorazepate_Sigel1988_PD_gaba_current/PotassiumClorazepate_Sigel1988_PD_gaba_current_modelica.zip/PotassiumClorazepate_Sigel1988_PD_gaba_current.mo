model PotassiumClorazepate_Sigel1988_PD_gaba_current
  "emax exposure-response sweep — Sigel_1988 :: GABA current (GABA-induced current (enhancement by clorazepate))"
  extends Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep(
    E0 = 0,      // [1]
    Emax = 0.9,  // [1; % × 0.01]
    EC50 = 390,  // [nM]
    gamma = 1,
    exposure_per_s = 1);   // 1 nM per second
  // exposure_unit_unresolved: 'nM' — the x axis is in the paper's unit, not SI
  // defaulted: E0
  // defaulted: gamma
  annotation(experiment(StartTime = 0, StopTime = 3900, Interval = 7.8),
    Documentation(info = "<html><body><!-- drug-about --><h4>About potassium_clorazepate</h4><p>Clorazepate is a benzodiazepine used to treat anxiety disorders and focal epilepsy. It is an approved medicine, though it is also encountered as an illicit drug.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q418850\">Wikidata Q418850</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h4>PotassiumClorazepate_Sigel1988_PD_gaba_current</h4><p>The steady-state exposure-response curve of Sigel E et al., <i>The Journal of neuroscience : the official journal of the Society for Neuroscience 8(1):289–295</i> 1988 (<a href=\"https://doi.org/10.1523/JNEUROSCI.08-01-00289.1988\">doi:10.1523/JNEUROSCI.08-01-00289.1988</a>) — GABA-induced current (enhancement by clorazepate) against clorazepate nM — obtained by sweeping the driver instead of simulating a dose. Model family: emax.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = (library default) drug-free response (baseline)
  Emax  =         90 %        maximal effect term (maximal stimulation, Q320)
  EC50  =        390 nM       exposure at half of the maximal effect term (half-maximal stimulation concentration, Q321)
  gamma = (library default) Hill coefficient</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep\">SigmoidEmaxSweep</a>; this model only supplies the numbers. The x axis is one nM of clorazepate per second of simulated time: there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0   (drug-free)
  exposure = EC50 (390 nM)  response 0.45
  exposure -> infinity  response 0.9</pre></body></html>"));
end PotassiumClorazepate_Sigel1988_PD_gaba_current;
