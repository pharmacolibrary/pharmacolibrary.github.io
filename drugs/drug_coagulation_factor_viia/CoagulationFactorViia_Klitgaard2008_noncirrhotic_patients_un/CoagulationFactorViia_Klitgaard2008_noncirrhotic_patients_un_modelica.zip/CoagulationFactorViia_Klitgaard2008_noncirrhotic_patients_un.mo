model CoagulationFactorViia_Klitgaard2008_noncirrhotic_patients_un
  parameter Real Cl_ref = 1.361111111111111e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.00581 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    adminMass = 1e-05
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>coagulation_factor_viia</td></tr><tr><td>population:</td><td>mixed (healthy volunteers, haemophilia, liver surgery, trauma)</td></tr><tr><td>source_paper:</td><td>Klitgaard_2008</td></tr><tr><td>measured_compound:</td><td>recombinant activated factor VII</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>tbl1</td></tr><tr><td>input:</td><td>PK_1C: IV (no input phase)</td></tr></table><h4>Interpretation flags</h4><ul><li>dropped unlinked row (NIL): 'n' — extend the ontology if this is a real PK parameter (source ['tbl1:row0:col14', 'tbl1:row0:col28', 'tbl1:row0:col33'])</li><li>dropped unlinked row (NIL): 'rFVIIa dose, μg kg−1*' — extend the ontology if this is a real PK parameter (source ['tbl1:row1:col4', 'tbl1:row1:col28'])</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=recombinant activated factor VII</li><li>population split: 'noncirrhotic patients undergoing liver resection [27] (klitgaard, data on file 2005)' subgroup of Klitgaard_2008 (paper reports 12 populations: adults with haemophilia a or b [9] (jansen, data on file 2001), healthy japanese and caucasian volunteers [16], healthy volunteers [11, 12], japanese patients with haemophilia a or b [14], nonbleeding patients with cirrhosis and prolonged pt [10], noncirrhotic patients undergoing liver resection [27] (klitgaard, data on file 2005), paediatric patients with haemophilia a or b [8], patients undergoing olt – multiple dose study [20] (erichsen, klitgaard, data on file 2004)., patients undergoing olt – single dose study [17] (jansen, data on file 2001), patients with cirrhosis and ugib [18], patients with cirrhosis and ugib [19/unpublished data] (klitgaard, data on file 2004), patients with traumatic blunt and/or penetrating injury [2, 23])</li><li>gap-filled Q61 (V) from Klitgaard_2006's review values (primary lacked it)</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end CoagulationFactorViia_Klitgaard2008_noncirrhotic_patients_un;
