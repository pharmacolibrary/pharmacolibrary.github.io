model Miltefosine_Madu2023_PD_pbmc_concentration
  "linear exposure-response sweep — Madu_2023 :: PBMC concentration (Miltefosine intracellular concentration in PBMCs)"
  extends Pharmacolibrary.Interfaces.PartialExposureResponseSweep(
    E0 = 0,      // [kg/m3; µg/mL × 0.001]
    Emax = 0, EC50 = 1,      // unused by a line
    exposure_per_s = 0.001);
  parameter Real slope = 0.8   "[1]";
equation
  response = E0 + slope*exposure;
  annotation(experiment(StartTime = 0, StopTime = 1000, Interval = 2),
    Documentation(info = "<html><body><!-- drug-about --><h4>About miltefosine</h4><p>Miltefosine is a phospholipid drug used as an antiprotozoal agent against leishmaniasis and trypanosomiasis, and it also has antifungal, antibacterial and anticancer activity. It is an approved medicine, included on the WHO essential medicines list, though it carries a boxed warning.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q411787\">Wikidata Q411787</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h4>Miltefosine_Madu2023_PD_pbmc_concentration</h4><p>The steady-state exposure-response curve of Madu SJ et al., <i>Pharmaceutical research 40(12):2983–3000</i> 2023 (<a href=\"https://doi.org/10.1007/s11095-023-03610-0\">doi:10.1007/s11095-023-03610-0</a>) — Miltefosine intracellular concentration in PBMCs [µg/mL] against miltefosine µg/mL — obtained by sweeping the driver instead of simulating a dose. Model family: linear.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    =          0 µg/mL    drug-free response (baseline) (E0 (Baseline effect), Q324)
  slope =        0.8          change in response per unit of exposure (α (activation constant enhancement factor for bound receptor), Q335)</pre><p>The algebra is <code>response = E0 + slope*exposure</code>; this model only supplies the numbers. The x axis is one µg/mL of miltefosine per second of simulated time (exposure is in kg/m3): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0   (drug-free)</pre></body></html>"));
end Miltefosine_Madu2023_PD_pbmc_concentration;
