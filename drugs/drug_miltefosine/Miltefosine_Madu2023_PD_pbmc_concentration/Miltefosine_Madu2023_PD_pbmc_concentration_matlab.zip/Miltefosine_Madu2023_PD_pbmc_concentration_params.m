function p = Miltefosine_Madu2023_PD_pbmc_concentration_params()
% Miltefosine_Madu2023_PD_pbmc_concentration_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% miltefosine Madu_2023::PBMC_concentration: linear exposure-response sweep (response = E0 + slope*exposure). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one µg/mL per second, in SI inside (kg/m3, s). Response PBMC concentration in µg/mL. Driver: miltefosine (pk_record).
p.E0 = 0.0;
p.Emax = 0.0;
p.EC50 = 1.0;
p.gamma = 1.0;
p.slope = 0.8;
p.exposure_per_s = 0.001;
p.stop_time = 1000.0;
p.form = 'E0 + slope*exposure';
end
