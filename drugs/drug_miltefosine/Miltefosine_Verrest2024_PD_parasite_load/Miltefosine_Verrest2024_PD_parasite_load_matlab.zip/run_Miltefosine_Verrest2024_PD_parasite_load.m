% run_Miltefosine_Verrest2024_PD_parasite_load  Evaluate the exposure-response curve and plot response against exposure.
% A sweep is a static map: no ODE solver is needed. exposure runs 0..stop_time*exposure_per_s.
p = Miltefosine_Verrest2024_PD_parasite_load_params();
exposure = linspace(0, p.stop_time * p.exposure_per_s, 501);
frac = exposure.^p.gamma ./ (p.EC50^p.gamma + exposure.^p.gamma);
E0 = p.E0; Emax = p.Emax; slope = p.slope;
response = E0 + slope.*exposure;
figure; plot(exposure, response, 'LineWidth', 1.5); grid on;
xlabel('exposure [μg/L]'); ylabel('response [parasites/mL]'); title('Miltefosine_Verrest2024_PD_parasite_load', 'Interpreter', 'none');
writematrix([exposure(:) response(:)], 'Miltefosine_Verrest2024_PD_parasite_load.csv');
