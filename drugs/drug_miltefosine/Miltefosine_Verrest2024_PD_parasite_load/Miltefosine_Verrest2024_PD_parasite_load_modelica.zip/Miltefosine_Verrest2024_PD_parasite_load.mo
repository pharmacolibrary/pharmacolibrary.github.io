model Miltefosine_Verrest2024_PD_parasite_load
  "linear exposure-response sweep — Verrest_2024 :: parasite load (blood parasite load (Leishmania kDNA qPCR))"
  extends Pharmacolibrary.Interfaces.PartialExposureResponseSweep(
    E0 = 5324,      // [parasites/mL]
    Emax = 0, EC50 = 1,      // unused by a line
    exposure_per_s = 1e-06);
  parameter Real slope = 0.001   "[μg-1*L*h-1]";
equation
  response = E0 + slope*exposure;
  annotation(experiment(StartTime = 0, StopTime = 1000, Interval = 2),
    Documentation(info = "<html><body><!-- drug-about --><h4>About miltefosine</h4><p>Miltefosine is a phospholipid drug used as an antiprotozoal agent against leishmaniasis and trypanosomiasis, and it also has antifungal, antibacterial and anticancer activity. It is an approved medicine, included on the WHO essential medicines list, though it carries a boxed warning.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q411787\">Wikidata Q411787</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h4>Miltefosine_Verrest2024_PD_parasite_load</h4><p>The steady-state exposure-response curve of Verrest L et al., <i>PLoS neglected tropical diseases 18(4):e0012078</i> 2024 (<a href=\"https://doi.org/10.1371/journal.pntd.0012078\">doi:10.1371/journal.pntd.0012078</a>) — blood parasite load (Leishmania kDNA qPCR) [parasites/mL] against miltefosine μg/L — obtained by sweeping the driver instead of simulating a dose. Model family: linear.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    =       5324 parasites/mL drug-free response (baseline) (EBASE, Q324)
  slope =      0.001 μg-1*L*h-1 change in response per unit of exposure (λMF, Q335)</pre><p>The algebra is <code>response = E0 + slope*exposure</code>; this model only supplies the numbers. The x axis is one μg/L of miltefosine per second of simulated time (exposure is in kg/m3): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 5324   (drug-free)</pre></body></html>"));
end Miltefosine_Verrest2024_PD_parasite_load;
