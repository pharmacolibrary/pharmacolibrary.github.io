function p = Miltefosine_Dorlo2017_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: miltefosine   source: Dorlo_2017 / reference   route: oral
  p.name  = 'Miltefosine_Dorlo2017_reference_params';
  p.drug  = 'miltefosine';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 51.7;                % central volume [L]
  p.CL = 0.17875;                % clearance [L/h]
  p.Vp = [2.25];             % peripheral volumes [L]
  p.Q  = [0.001108];             % inter-compartmental clearances [L/h]
  p.ka = 0.062083;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 150.0;             % dose [mg]
end
