model Miltefosine_Dorlo2017_reference
  parameter Real Cl_ref = 4.965277777777778e-08 "Cl [m3/s]";
  parameter Real Vd_ref = 0.0517 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.40757600000000005,
    adminMass = 0.00015,
    ka = 1.724537037037037e-05,
    Tlag = 0.0,
    k12 = 5.954939465577763e-09,
    k21 = 1.368312757201646e-07
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About miltefosine</h4><p>Miltefosine is a phospholipid drug used as an antiprotozoal agent against leishmaniasis and trypanosomiasis, and it also has antifungal, antibacterial and anticancer activity. It is an approved medicine, included on the WHO essential medicines list, though it carries a boxed warning.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q411787\">Wikidata Q411787</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>miltefosine</td></tr><tr><td>population:</td><td>Eastern African patients with visceral leishmaniasis</td></tr><tr><td>source_paper:</td><td>Dorlo_2017</td></tr><tr><td>measured_compound:</td><td>miltefosine</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>dkx283-T2</td></tr><tr><td>input:</td><td>PK_2C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>miltefosine 407.576 g/mol (drugbank)</td></tr></table><p><b>Defaulted (base-class default used):</b> Tlag.</p><h4>Interpretation flags</h4><ul><li>table section iiv: 'Absorption rate, ka (/day)' routed out of structural estimates ('Between-subject variability (% RSEc)')</li><li>table section iiv: 'Clearance, CL/F (L/day)b' routed out of structural estimates ('Between-subject variability (% RSEc)')</li><li>table section iov: 'F (%, at end of treatment)' routed out of structural estimates ('Between-occasion variability (% RSEc)')</li><li>table section iiv: 'Reduction in F at baselined (% change from end of treatment)' routed out of structural estimates ('Between-subject variability (% RSEc)')</li><li>unit_dimension_unknown: '% RSEc' (CL/F)</li><li>unit_dimension_unknown: '% RSEc' (V1)</li><li>unit_dimension_unknown: '% change from end of treatment' (Frel)</li><li>dropped PD-category row 'Baseline hazard of relapse (infections/year)' → Q342 (lambda_hazard, category G14) — pharmacodynamic parameters belong to scholarpd, not the PK model (source ['dkx283-T2:row12:col1'])</li><li>dropped unlinked row (NIL): 'I50 miltefosine Time > EC90 for monotherapy arm (day)' — extend the ontology if this is a real PK parameter (source ['dkx283-T2:row13:col1'])</li><li>dropped unlinked row (NIL): 'I50 miltefosine Time > EC90 for combination therapy arm (day)' — extend the ontology if this is a real PK parameter (source ['dkx283-T2:row14:col1'])</li><li>dropped PD-category row 'Hazard reduction by liposomal amphotericin B (%)' → Q342 (lambda_hazard, category G14) — pharmacodynamic parameters belong to scholarpd, not the PK model (source ['dkx283-T2:row15:col1'])</li><li>dropped value-less row: 'Monotherapy (28 days miltefosine)' (captured trailing unit '28 days miltefosine' for child rows)</li><li>dropped value-less row: 'Initial half-life (days)' (captured trailing unit 'days' for child rows)</li><li>dropped value-less row: 'Terminal half-life (days)' (captured trailing unit 'days' for child rows)</li><li>dropped value-less row: 'AUC0–∞ (μg·day/mL)' (captured trailing unit 'μg·day/mL' for child rows)</li><li>dropped value-less row: 'AUC0–28d (μg·day/mL)' (captured trailing unit 'μg·day/mL' for child rows)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 4233600, Tolerance = 1e-9, Interval = 1));
end Miltefosine_Dorlo2017_reference;
