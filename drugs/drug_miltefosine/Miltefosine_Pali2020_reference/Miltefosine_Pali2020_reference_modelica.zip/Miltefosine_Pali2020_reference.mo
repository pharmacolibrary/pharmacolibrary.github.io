model Miltefosine_Pali2020_reference
  parameter Real Cl_ref = 2.824074074074074e-08 "Cl [m3/s]";
  parameter Real Vd_ref = 0.0229 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.40757600000000005,
    adminMass = 0.00015,
    ka = 1.863425925925926e-05,
    Tlag = 0.0,
    k12 = 1.1776241306808993e-08,
    k21 = 1.1879996736824933e-07
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About miltefosine</h4><p>Miltefosine is a phospholipid drug used as an antiprotozoal agent against leishmaniasis and trypanosomiasis, and it also has antifungal, antibacterial and anticancer activity. It is an approved medicine, included on the WHO essential medicines list, though it carries a boxed warning.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q411787\">Wikidata Q411787</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>miltefosine</td></tr><tr><td>population:</td><td>paediatric visceral leishmaniasis patients from Eastern Africa</td></tr><tr><td>source_paper:</td><td>Palić_2020</td></tr><tr><td>measured_compound:</td><td>miltefosine</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>dkaa314-T2</td></tr><tr><td>input:</td><td>PK_2C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>miltefosine 407.576 g/mol (drugbank)</td></tr></table><p><b>Defaulted (base-class default used):</b> Tlag.</p><h4>Interpretation flags</h4><ul><li>dropped value-less row: 'Vp'</li><li>dropped value-less row: 'Q'</li><li>dropped unlinked row (NIL): 'ΔOFV' — extend the ontology if this is a real PK parameter (source ['dkaa314-F3:caption', 'dkaa314-F3:caption'])</li><li>covariate effect for Q319 has no base parameter row (kept as unattached equation-variable)</li><li>apparent-ness (ontology-grounded): parameterization=apparent, measured_compound=miltefosine</li><li>skipped review gap-fill of TLAG: primary's parameterization (rate-constant / ka-only) does not use it</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 3024000, Tolerance = 1e-9, Interval = 1));
end Miltefosine_Pali2020_reference;
