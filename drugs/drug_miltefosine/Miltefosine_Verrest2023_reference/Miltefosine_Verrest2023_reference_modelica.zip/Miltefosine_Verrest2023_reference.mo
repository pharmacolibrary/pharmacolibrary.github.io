model Miltefosine_Verrest2023_reference
  parameter Real Cl_ref = 2.1412037037037037e-08 "Cl [m3/s]";
  parameter Real Vd_ref = 0.00917 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C_enteral(
    weight = 70.0,
    F = 0.9,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.40757600000000005,
    adminMass = 0.00015,
    ka = 4.282407407407407e-07,
    Tlag = 0.0,
    k12 = 2.145684397592795e-07,
    k21 = 3.0039581566299125e-07
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About miltefosine</h4><p>Miltefosine is a phospholipid drug used as an antiprotozoal agent against leishmaniasis and trypanosomiasis, and it also has antifungal, antibacterial and anticancer activity. It is an approved medicine, included on the WHO essential medicines list, though it carries a boxed warning.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q411787\">Wikidata Q411787</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>miltefosine</td></tr><tr><td>population:</td><td>Eastern African children and adults with visceral leishmaniasis</td></tr><tr><td>source_paper:</td><td>Verrest_2023</td></tr><tr><td>measured_compound:</td><td>miltefosine</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>dkad286-T4</td></tr><tr><td>input:</td><td>PK_2C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>miltefosine 407.576 g/mol (drugbank)</td></tr></table><p><b>Defaulted (base-class default used):</b> F, Tlag.</p><h4>Interpretation flags</h4><ul><li>table section iiv: 'CL (CV%)' routed out of structural estimates ('Between-subject variability')</li><li>table section iiv: 'CL (CV%)' routed out of structural estimates ('Between-subject variability')</li><li>table section iiv: 'CL (CV%)' routed out of structural estimates ('Between-subject variability')</li><li>table section iiv: 'COVF,W1 (CV%)' routed out of structural estimates ('Between-subject variability')</li><li>table section iiv: 'COVF,W1 (CV%)' routed out of structural estimates ('Between-subject variability')</li><li>table section iiv: 'COVF,W1 (CV%)' routed out of structural estimates ('Between-subject variability')</li><li>table section residual_error: 'Proportional error (CV%)' routed out of structural estimates ('Residual variability')</li><li>table section residual_error: 'Proportional error (CV%)' routed out of structural estimates ('Residual variability')</li><li>table section residual_error: 'Proportional error (CV%)' routed out of structural estimates ('Residual variability')</li><li>table section iiv: 'CL (CV%)' routed out of structural estimates ('Between-subject variability')</li><li>table section iiv: 'CL (CV%)' routed out of structural estimates ('Between-subject variability')</li><li>table section iiv: 'CL (CV%)' routed out of structural estimates ('Between-subject variability')</li><li>table section residual_error: 'Proportional error (CV%)' routed out of structural estimates ('Residual variability')</li><li>table section residual_error: 'Proportional error (CV%)' routed out of structural estimates ('Residual variability')</li><li>table section residual_error: 'Proportional error (CV%)' routed out of structural estimates ('Residual variability')</li><li>routed 'COVF,W1b (fractional change)' → Q314 (omega_cov) to covariance — variability estimate, not a structural parameter</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 9072000, Tolerance = 1e-9, Interval = 1));
end Miltefosine_Verrest2023_reference;
