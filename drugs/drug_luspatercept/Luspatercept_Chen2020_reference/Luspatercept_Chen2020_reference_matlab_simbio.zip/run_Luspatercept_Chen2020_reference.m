% Run (SimBiology): build model + dose, simulate 0..1848.0 h, plot.
p = Luspatercept_Chen2020_reference_params();
[model, dose, variant] = build_sb_pk(p);
sd = simulate_sb(model, variant, dose, 1848.0);
