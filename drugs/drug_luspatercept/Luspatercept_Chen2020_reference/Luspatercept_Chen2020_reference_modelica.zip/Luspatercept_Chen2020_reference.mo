model Luspatercept_Chen2020_reference
  parameter Real Cl_ref = 5.42824074074074e-09 "Cl [m3/s]";
  parameter Real cov_weight_0 = 0 "weight covariate";
  parameter Real cov_age_1 = 0 "age covariate";
  parameter Real cov_albumin_2 = 0 "albumin covariate";
  parameter Real cov_weight_3 = 0 "weight covariate";
  parameter Real cov_albumin_4 = 0 "albumin covariate";
  parameter Real Vd_ref = 0.0092 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref*(1 + (0.768)*cov_weight_0)*(1 + (-0.534)*cov_age_1)*(1 + (-1.18)*cov_albumin_2)*(1 + (0.878)*cov_weight_3)*(1 + (-0.609)*cov_albumin_4),
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    adminMass = 8.75e-06,
    ka = 5.277777777777778e-06,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About luspatercept</h4><p>Luspatercept is an antianemic medicine used to treat anemia in people with myelodysplastic syndromes or beta-thalassemia. It is authorised in the European Union and is also being studied for further uses.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q30314143\">Wikidata Q30314143</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>luspatercept</td></tr><tr><td>population:</td><td>anemic patients with myelodysplastic syndromes</td></tr><tr><td>source_paper:</td><td>Chen_2020</td></tr><tr><td>measured_compound:</td><td>luspatercept</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>psp412521-tbl-0002</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr></table><p><b>Defaulted (base-class default used):</b> Tlag.</p><h4>Interpretation flags</h4><ul><li>covariate level 'Weight, kg, on CL/F' → Q900:weight_kg_on_cl_f = 0.768 (linear_fractional on Q27)</li><li>covariate level 'Age, years, on CL/F' → Q900:age_years_on_cl_f = -0.534 (linear_fractional on Q27)</li><li>covariate level 'Albumin, g/L, on CL/F' → Q900:albumin_g_l_on_cl_f = -1.18 (linear_fractional on Q27)</li><li>covariate level 'Weight, kg, on V1/F' → Q900:weight_kg_on_v1_f = 0.878 (linear_fractional on Q27)</li><li>covariate level 'Albumin, g/L, on V1/F' → Q900:albumin_g_l_on_v1_f = -0.609 (linear_fractional on Q27)</li><li>routed 'Interindividual variability of CL/F' → Q312 (IIV) to iiv — variability estimate, not a structural parameter</li><li>routed 'Interindividual variability of V1/F' → Q312 (IIV) to iiv — variability estimate, not a structural parameter</li><li>apparent-ness (ontology-grounded): parameterization=apparent, measured_compound=luspatercept</li><li>1C volume normalization: Q290→Q76 (single-compartment model has no central/peripheral split; 'V1/F, L' is the general volume)</li><li>molar mass: none found for 'luspatercept' — its concentrations stay mass-only</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of TLAG: primary's parameterization (rate-constant / ka-only) does not use it</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 6652800, Tolerance = 1e-9, Interval = 1));
end Luspatercept_Chen2020_reference;
