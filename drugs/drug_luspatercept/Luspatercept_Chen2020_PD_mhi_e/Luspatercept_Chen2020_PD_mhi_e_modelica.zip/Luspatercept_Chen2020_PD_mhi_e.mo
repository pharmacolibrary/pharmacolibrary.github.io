model Luspatercept_Chen2020_PD_mhi_e
  "linear exposure-response sweep — Chen_2020 :: mHI-E (modified hematologic improvement–erythroid (mHI-E) in weeks 1–24)"
  extends Pharmacolibrary.Interfaces.PartialExposureResponseSweep(
    E0 = 0,      // [1]
    Emax = 0, EC50 = 1,      // unused by a line
    exposure_per_s = 1);
  parameter Real slope = 1.101   "[1]";
equation
  response = E0 + slope*exposure;
  // defaulted: E0
  annotation(experiment(StartTime = 0, StopTime = 1000, Interval = 2),
    Documentation(info = "<html><body><!-- drug-about --><h4>About luspatercept</h4><p>Luspatercept is an antianemic medicine used to treat anemia in people with myelodysplastic syndromes or beta-thalassemia. It is authorised in the European Union and is also being studied for further uses.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q30314143\">Wikidata Q30314143</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h4>Luspatercept_Chen2020_PD_mhi_e</h4><p>The steady-state exposure-response curve of Chen N et al., <i>CPT: pharmacometrics &amp; systems pharmacology 9(7):395–404</i> 2020 (<a href=\"https://doi.org/10.1002/psp4.12521\">doi:10.1002/psp4.12521</a>) — modified hematologic improvement–erythroid (mHI-E) in weeks 1–24 against luspatercept day·μg/mL — obtained by sweeping the driver instead of simulating a dose. Model family: linear.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = (library default) drug-free response (baseline)
  slope =      1.101          change in response per unit of exposure (OR, Q335)</pre><p>The algebra is <code>response = E0 + slope*exposure</code>; this model only supplies the numbers. The x axis is one day·μg/mL of luspatercept per second of simulated time: there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0   (drug-free)</pre></body></html>"));
end Luspatercept_Chen2020_PD_mhi_e;
