function p = Luspatercept_Chen2020_PD_rbc_ti_params()
% Luspatercept_Chen2020_PD_rbc_ti_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% luspatercept Chen_2020::RBC_TI: linear exposure-response sweep (response = E0 + slope*exposure). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one day·μg/mL per second, in SI inside (kg/m3, s). Response RBC-TI in its own unit. Driver: luspatercept (pk_record).
p.E0 = 0.0;
p.Emax = 0.0;
p.EC50 = 1.0;
p.gamma = 1.0;
p.slope = 1.936;
p.exposure_per_s = 1.0;
p.stop_time = 1000.0;
p.form = 'E0 + slope*exposure';
end
