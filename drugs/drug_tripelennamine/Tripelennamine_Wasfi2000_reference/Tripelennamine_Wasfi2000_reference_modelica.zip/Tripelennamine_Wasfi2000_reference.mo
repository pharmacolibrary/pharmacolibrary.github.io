model Tripelennamine_Wasfi2000_reference
  parameter Real Cl_ref = 1.886111111111111e-05 "Cl [m3/s]";
  parameter Real Vd_ref = 0.1225 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.25535800000000003,
    adminMass = 1e-05
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About tripelennamine</h4><p>Tripelennamine is an antihistamine used to treat allergic conditions such as urticaria. It is an approved drug, used both systemically for allergies and topically on the skin to relieve itching, and is also approved for veterinary use.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q415203\">Wikidata Q415203</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>tripelennamine</td></tr><tr><td>population:</td><td>horses and camels</td></tr><tr><td>source_paper:</td><td>Wasfi_2000</td></tr><tr><td>measured_compound:</td><td>tripelennamine</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>tripelennamine 255.358 g/mol (drugbank)</td></tr></table><h4>Interpretation flags</h4><ul><li>dropped duplicate Q57 ('terminal elimination half-lives (horses)', value 2.08) — already have one for this compound</li><li>dropped duplicate Q65 ('volumes of distribution at steady state (horses)', value 1.69) — already have one for this compound</li><li>dropped duplicate Q63 ('volumes of the central compartment of the two compartment pharmacokinetic model (horses)', value 1.06) — already have one for this compound</li><li>dropped unlinked row (NIL): 'extent of protein binding (horses)' — extend the ontology if this is a real PK parameter (source ['Wasfi_2000:abstract'])</li><li>dropped unlinked row (NIL): 'extent of protein binding (camels)' — extend the ontology if this is a real PK parameter (source ['Wasfi_2000:abstract'])</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=tripelennamine</li><li>structure disagreement: deterministic 1C vs LLM 2C — review compartment count</li><li>1C volume normalization: Q63→Q61 (single-compartment model has no central/peripheral split; 'volumes of the central compartment of the two compartment pharmacokinetic model (camels)' is the general volume)</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Tripelennamine_Wasfi2000_reference;
