% Run (SimBiology): build model + dose, simulate 0..32.0 h, plot.
p = SodiumSalicylate_Lowenthal1974_six_anephric_patients_params();
[model, dose, variant] = build_sb_pk(p);
sd = simulate_sb(model, variant, dose, 32.0);
