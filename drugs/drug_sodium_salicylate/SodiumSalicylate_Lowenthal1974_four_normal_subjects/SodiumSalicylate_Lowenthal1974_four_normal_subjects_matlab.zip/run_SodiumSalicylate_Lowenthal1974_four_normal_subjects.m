% Run: build params, simulate 0..26.0 h, plot + save SodiumSalicylate_Lowenthal1974_four_normal_subjects.png/.csv/.json.
% Interactive display (keep the window open):  octave --persist run_SodiumSalicylate_Lowenthal1974_four_normal_subjects.m
here = fileparts(mfilename('fullpath'));
p = SodiumSalicylate_Lowenthal1974_four_normal_subjects_params();
out = simulate_pk(p, 0:0.05:26.0);

% figure (shown on screen if interactive) and PNG (works in MATLAB and Octave)
fig = figure; plot(out.t, out.C, 'LineWidth', 1.5); grid on;
xlabel('time [h]'); ylabel('central concentration [mg/L]');
title('sodium_salicylate — Lowenthal_1974 (oral)');
print(fig, fullfile(here, 'SodiumSalicylate_Lowenthal1974_four_normal_subjects.png'), '-dpng', '-r150');

% CSV (time_h, Cc_mg_per_L)
fid = fopen(fullfile(here, 'SodiumSalicylate_Lowenthal1974_four_normal_subjects.csv'), 'w');
fprintf(fid, 'time_h,Cc_mg_per_L\n');
fprintf(fid, '%.10g,%.10g\n', [out.t(:), out.C(:)].');
fclose(fid);

% JSON (summary + arrays; jsonencode with a manual fallback for older versions)
fid = fopen(fullfile(here, 'SodiumSalicylate_Lowenthal1974_four_normal_subjects.json'), 'w');
try
  s.model = 'SodiumSalicylate_Lowenthal1974_four_normal_subjects'; s.Cmax = out.Cmax; s.Tmax = out.Tmax; s.AUC = out.AUC;
  s.time_h = out.t(:).'; s.Cc_mg_per_L = out.C(:).';
  fprintf(fid, '%s', jsonencode(s));
catch
  fprintf(fid, '{"model":"SodiumSalicylate_Lowenthal1974_four_normal_subjects","Cmax":%g,"Tmax":%g,"AUC":%g}', out.Cmax, out.Tmax, out.AUC);
end
fclose(fid);

fprintf('Cmax=%.3g mg/L  Tmax=%.3g h  AUC=%.3g mg*h/L\n', out.Cmax, out.Tmax, out.AUC);
fprintf('wrote SodiumSalicylate_Lowenthal1974_four_normal_subjects.png, SodiumSalicylate_Lowenthal1974_four_normal_subjects.csv, SodiumSalicylate_Lowenthal1974_four_normal_subjects.json\n');
