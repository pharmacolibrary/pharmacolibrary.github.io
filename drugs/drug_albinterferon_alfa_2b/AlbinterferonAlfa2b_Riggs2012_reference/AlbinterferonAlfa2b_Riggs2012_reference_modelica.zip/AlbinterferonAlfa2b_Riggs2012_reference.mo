model AlbinterferonAlfa2b_Riggs2012_reference
  parameter Real Cl_ref = 1.0805555555555554e-08 "Cl [m3/s]";
  parameter Real Vd_ref = 0.0116 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    adminMass = 0.0001,
    ka = 4.111111111111111e-06,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About albinterferon_alfa_2b</h4><p>It was never approved and remains an investigational compound, so it is not in routine clinical use.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q4712444\">Wikidata Q4712444</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>albinterferon_alfa_2b</td></tr><tr><td>population:</td><td>adults with chronic hepatitis C virus</td></tr><tr><td>source_paper:</td><td>Riggs_2012</td></tr><tr><td>measured_compound:</td><td>albinterferon_alfa_2b</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr></table><p><b>Defaulted (base-class default used):</b> Tlag.</p><h4>Interpretation flags</h4><ul><li>apparent-ness (ontology-grounded): parameterization=apparent, measured_compound=albinterferon_alfa_2b</li><li>molar mass: none found for 'albinterferon_alfa_2b' — its concentrations stay mass-only</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 4838400, Tolerance = 1e-9, Interval = 1));
end AlbinterferonAlfa2b_Riggs2012_reference;
