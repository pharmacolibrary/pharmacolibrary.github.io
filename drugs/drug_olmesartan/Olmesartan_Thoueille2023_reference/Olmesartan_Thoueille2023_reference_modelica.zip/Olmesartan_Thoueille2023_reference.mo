model Olmesartan_Thoueille2023_reference
  parameter Real Cl_ref = 1.1083333333333333e-05 "Cl [m3/s]";
  parameter Real Vd_ref = 2.66 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 0.9,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.44651100000000005,
    adminMass = 0.0001,
    ka = 0.0005555555555555556,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About olmesartan</h4><p>Olmesartan is an angiotensin II receptor blocker used to treat high blood pressure (arterial hypertension) and congestive heart failure. It is an approved medicine, available alone and in combination products with diuretics or calcium channel blockers.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q421156\">Wikidata Q421156</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>olmesartan</td></tr><tr><td>population:</td><td>review reference</td></tr><tr><td>source_paper:</td><td>Thoueille_2023</td></tr><tr><td>measured_compound:</td><td>olmesartan</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>olmesartan 446.511 g/mol (pubchem)</td></tr></table><p><b>Defaulted (base-class default used):</b> F, Tlag.</p><h4>Interpretation flags</h4><ul><li>built from REVIEW reference values (Thoueille_2023) — secondary source</li><li>volume reported by review</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 864000, Tolerance = 1e-9, Interval = 1));
end Olmesartan_Thoueille2023_reference;
