function p = Olmesartan_Kodati2017_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: olmesartan   source: Kodati_2017 / reference   route: oral
  % estimated (absent from source): dose
  p.name  = 'Olmesartan_Kodati2017_reference_params';
  p.drug  = 'olmesartan';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 44.5162;                % central volume [L]
  p.CL = 0.31565;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 2.0;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 100.0;             % dose [mg]
end
