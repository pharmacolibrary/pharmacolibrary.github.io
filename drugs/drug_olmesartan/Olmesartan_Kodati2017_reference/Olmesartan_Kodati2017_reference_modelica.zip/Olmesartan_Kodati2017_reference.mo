model Olmesartan_Kodati2017_reference
  parameter Real Cl_ref = 8.768055555555556e-08 "Cl [m3/s]";
  parameter Real Vd_ref = 0.0445162 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.44651100000000005,
    adminMass = 0.0001,
    ka = 0.0005555555555555556,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About olmesartan</h4><p>Olmesartan is an angiotensin II receptor blocker used to treat high blood pressure (arterial hypertension) and congestive heart failure. It is an approved medicine, available alone and in combination products with diuretics or calcium channel blockers.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q421156\">Wikidata Q421156</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>olmesartan</td></tr><tr><td>population:</td><td>Indian patients with hypertension</td></tr><tr><td>source_paper:</td><td>Kodati_2017</td></tr><tr><td>measured_compound:</td><td>olmesartan</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>olmesartan 446.511 g/mol (pubchem); olmesartan medoxomil 558.595 g/mol (pubchem)</td></tr></table><p><b>Defaulted (base-class default used):</b> Tlag.</p><h4>Interpretation flags</h4><ul><li>apparent-ness (ontology-grounded): parameterization=apparent, measured_compound=olmesartan</li><li>template fit: PK_3M_9C — formed from central; parent 0, metabolites [1]</li><li>1C volume normalization: Q290→Q76 (single-compartment model has no central/peripheral split; 'V/F' is the general volume)</li><li>row roles (LLM): model_class=compartmental; 2/2 row label(s) assigned, 2 linked by role</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li><li>gap-filled Q49 (kabs) from Thoueille_2023's review values (primary lacked it)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 1814400, Tolerance = 1e-9, Interval = 1));
end Olmesartan_Kodati2017_reference;
