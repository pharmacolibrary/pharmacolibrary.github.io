model Olmesartan_Zakrocka2019_PD_kyna
  "emax exposure-response sweep — Zakrocka_2019 :: KYNA (KYNA production)"
  extends Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep(
    E0 = 0,      // [1]
    Emax = -0.573,  // [1; % × 0.01]
    EC50 = 108.1,  // [μM]
    gamma = 1,
    exposure_per_s = 1);   // 1 μM per second
  // imax_as_negative_emax: Imax (Q323) enters SigmoidEmaxSweep as −Emax
  // exposure_unit_unresolved: 'μM' — the x axis is in the paper's unit, not SI
  // defaulted: E0
  // defaulted: gamma
  annotation(experiment(StartTime = 0, StopTime = 1100, Interval = 2.2),
    Documentation(info = "<html><body><!-- drug-about --><h4>About olmesartan</h4><p>Olmesartan is an angiotensin II receptor blocker used to treat high blood pressure (arterial hypertension) and congestive heart failure. It is an approved medicine, available alone and in combination products with diuretics or calcium channel blockers.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q421156\">Wikidata Q421156</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h4>Olmesartan_Zakrocka2019_PD_kyna</h4><p>The steady-state exposure-response curve of Zakrocka I et al., <i>Naunyn-Schmiedeberg's archives of pharmacology 392(2):209–217</i> 2019 (<a href=\"https://doi.org/10.1007/s00210-018-1572-7\">doi:10.1007/s00210-018-1572-7</a>) — KYNA production [pmol/mg protein/2 h] against olmesartan μM — obtained by sweeping the driver instead of simulating a dose. Model family: emax.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = (library default) drug-free response (baseline)
  Emax  =       57.3 %        maximal effect term (maximal inhibition, Q323)
  EC50  =      108.1 μM       exposure at half of the maximal effect term (IC 50, Q322)
  gamma = (library default) Hill coefficient</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep\">SigmoidEmaxSweep</a>; this model only supplies the numbers. The x axis is one μM of olmesartan per second of simulated time: there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0   (drug-free)
  exposure = EC50 (108.1 μM)  response -0.2865
  exposure -> infinity  response -0.573</pre></body></html>"));
end Olmesartan_Zakrocka2019_PD_kyna;
