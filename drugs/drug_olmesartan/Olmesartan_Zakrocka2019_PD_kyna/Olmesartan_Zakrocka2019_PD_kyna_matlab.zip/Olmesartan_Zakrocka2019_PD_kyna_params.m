function p = Olmesartan_Zakrocka2019_PD_kyna_params()
% Olmesartan_Zakrocka2019_PD_kyna_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% olmesartan Zakrocka_2019::KYNA: emax exposure-response sweep (response = E0 + Emax*frac). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one μM per second, in SI inside (kg/m3, s). Response KYNA in pmol/mg protein/2 h. Driver: olmesartan (cited_pk).
p.E0 = 0.0;
p.Emax = -0.573;
p.EC50 = 108.1;
p.gamma = 1.0;
p.slope = 0.0;
p.exposure_per_s = 1.0;
p.stop_time = 1100.0;
p.form = 'E0 + Emax*frac';
end
