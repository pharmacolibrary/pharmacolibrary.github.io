model Atomoxetine_Li2012_reference
  parameter Real Cl_ref = 0.00012619444444444443 "Cl [m3/s]";
  parameter Real Vd_ref = 0.903 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.2553547,
    adminMass = 8e-05,
    ka = 0.006722222222222222,
    Tlag = 0.0,
    k12 = 0.00017140396210163654,
    k21 = 0.00038521099496709253
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About atomoxetine</h4><p>Atomoxetine is a non-stimulant medicine used to treat attention deficit hyperactivity disorder, and has also been used for anxiety. It is an approved drug, widely used for ADHD, though it carries a boxed warning.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q417240\">Wikidata Q417240</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>atomoxetine</td></tr><tr><td>population:</td><td>review reference</td></tr><tr><td>source_paper:</td><td>Li_2012</td></tr><tr><td>measured_compound:</td><td>atomoxetine</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_2C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>atomoxetine 255.355 g/mol (drugbank)</td></tr></table><p><b>Defaulted (base-class default used):</b> Tlag.</p><h4>Interpretation flags</h4><ul><li>built from REVIEW reference values (Li_2012) — secondary source</li><li>volume reported by review</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Atomoxetine_Li2012_reference;
