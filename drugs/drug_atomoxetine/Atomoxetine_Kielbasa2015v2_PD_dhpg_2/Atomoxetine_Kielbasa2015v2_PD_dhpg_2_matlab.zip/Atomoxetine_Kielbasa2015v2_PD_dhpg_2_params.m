function p = Atomoxetine_Kielbasa2015v2_PD_dhpg_2_params()
% Atomoxetine_Kielbasa2015v2_PD_dhpg_2_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% atomoxetine Kielbasa_2015_2::DHPG::2: indirect_response_i exposure-response sweep (response = E0*(1 - Emax*frac)). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one ng/mL, nM per second, in SI inside (kg/m3, s). Response DHPG in pg/mL. Driver: atomoxetine (cited_pk).
p.E0 = 2.1800000000000003e-06;
p.Emax = 0.529;
p.EC50 = 53.3209;
p.gamma = 1.0;
p.slope = 0.0;
p.exposure_per_s = 1.0;
p.stop_time = 540.0;
p.form = 'E0*(1 - Emax*frac)';
end
