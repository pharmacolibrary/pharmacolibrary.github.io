model Atomoxetine_Kielbasa2015v2_PD_dhpg_2
  "indirect_response_i exposure-response sweep — Kielbasa_2015_2 :: DHPG (CSF DHPG)"
  extends Pharmacolibrary.Interfaces.PartialExposureResponseSweep(
    E0 = 2.18e-06,      // [kg/m3; pg/mL × 1e-09]
    Emax = 0.529,  // type I effect term
    EC50 = 53.3209,  // [ng/mL, nM]
    gamma = 1,
    exposure_per_s = 1);   // 1 ng/mL, nM per second
equation
  response = E0*(1 - Emax*frac);   // steady state, indirect response type I
  // exposure_unit_unresolved: 'ng/mL, nM' — the x axis is in the paper's unit, not SI
  // defaulted: gamma
  annotation(experiment(StartTime = 0, StopTime = 540, Interval = 1.08),
    Documentation(info = "<html><body><!-- drug-about --><h4>About atomoxetine</h4><p>Atomoxetine is a non-stimulant medicine used to treat attention deficit hyperactivity disorder, and has also been used for anxiety. It is an approved drug, widely used for ADHD, though it carries a boxed warning.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q417240\">Wikidata Q417240</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h4>Atomoxetine_Kielbasa2015v2_PD_dhpg_2</h4><p>The steady-state exposure-response curve of Kielbasa W et al., <i>Journal of clinical pharmacology 55(12):1422–1431</i> 2015 (<a href=\"https://doi.org/10.1002/jcph.551\">doi:10.1002/jcph.551</a>) — CSF DHPG [pg/mL] against atomoxetine ng/mL, nM — obtained by sweeping the driver instead of simulating a dose. Model family: indirect_response_i.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    =       2180 pg/mL    drug-free response (baseline) (Baseline, Q324)
  Emax  =      0.529          maximal effect term (I max, Q323)
  EC50  =    53.3209 ng/mL, nM exposure at half of the maximal effect term (Plasma IC50, Q322)
  gamma = (library default) Hill coefficient</pre><p>The algebra is <code>response = E0*(1 - Emax*frac)</code>; this model only supplies the numbers. The x axis is one ng/mL, nM of atomoxetine per second of simulated time: there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 2.18e-06   (drug-free)
  exposure = EC50 (53.3209 ng/mL, nM)  response 1.603e-06
  exposure -> infinity  response 1.027e-06</pre></body></html>"));
end Atomoxetine_Kielbasa2015v2_PD_dhpg_2;
