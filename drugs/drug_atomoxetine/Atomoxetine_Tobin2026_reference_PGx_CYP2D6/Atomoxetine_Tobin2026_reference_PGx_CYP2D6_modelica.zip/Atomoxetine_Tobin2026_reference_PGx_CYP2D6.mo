model Atomoxetine_Tobin2026_reference_PGx_CYP2D6
  "Atomoxetine_Tobin2026_reference with the CYP2D6 phenotype as a parameter (Tobin_2026)"
  import PGx = Pharmacolibrary.Pharmacogenomics.PGx;
  parameter PGx.MetabolizerStatus metabolizer = PGx.MetabolizerStatus.Normal
    "CYP2D6 phenotype — the reference is the record's own model"
    annotation(Dialog(group = "Pharmacogenomics"), Evaluate = false);
  parameter Real Cl_by_phenotype[6] = {1.08416666667e-05, 4.82300286797e-06, 1.08416666667e-05, 1.08416666667e-05, 1.08416666667e-05, 1.08416666667e-05};
  extends Atomoxetine_Tobin2026_reference(Cl = Cl_by_phenotype[Integer(metabolizer)]);
  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About atomoxetine</h4><p>Atomoxetine is a non-stimulant medicine used to treat attention deficit hyperactivity disorder, and has also been used for anxiety. It is an approved drug, widely used for ADHD, though it carries a boxed warning.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q417240\">Wikidata Q417240</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --></body></html>"));
end Atomoxetine_Tobin2026_reference_PGx_CYP2D6;
