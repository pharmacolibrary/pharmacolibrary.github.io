model Atomoxetine_Tobin2026_reference
  parameter Real Cl_ref = 1.0841666666666666e-05 "Cl [m3/s]";
  parameter Real cov_pm_0 = 0 "pm covariate";
  parameter Real Vd_ref = 0.17594 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref*(1 + (-0.81)*cov_pm_0),
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.2553547,
    adminMass = 3.5e-05,
    ka = 0.007597222222222222,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About atomoxetine</h4><p>Atomoxetine is a non-stimulant medicine used to treat attention deficit hyperactivity disorder, and has also been used for anxiety. It is an approved drug, widely used for ADHD, though it carries a boxed warning.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q417240\">Wikidata Q417240</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>atomoxetine</td></tr><tr><td>population:</td><td>children and adolescents with ADHD</td></tr><tr><td>source_paper:</td><td>Tobin_2026</td></tr><tr><td>measured_compound:</td><td>atomoxetine</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>jcph70168-tbl-0003</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>atomoxetine 255.355 g/mol (drugbank)</td></tr></table><p><b>Defaulted (base-class default used):</b> Tlag.</p><h4>Interpretation flags</h4><ul><li>table section iiv: 'Ω2 dur' routed out of structural estimates ('Between‐Subject Variability (BSV)')</li><li>table section iiv: 'Ω2 dur' routed out of structural estimates ('Between‐Subject Variability (BSV)')</li><li>table section iiv: 'Ω2 dur' routed out of structural estimates ('Between‐Subject Variability (BSV)')</li><li>table section iiv: 'Ω2 ka' routed out of structural estimates ('Between‐Subject Variability (BSV)')</li><li>table section iiv: 'Ω2 ka' routed out of structural estimates ('Between‐Subject Variability (BSV)')</li><li>table section iiv: 'Ω2 ka' routed out of structural estimates ('Between‐Subject Variability (BSV)')</li><li>table section iiv: 'Ω2 Vc/F' routed out of structural estimates ('Between‐Subject Variability (BSV)')</li><li>table section iiv: 'Ω2 Vc/F' routed out of structural estimates ('Between‐Subject Variability (BSV)')</li><li>table section iiv: 'Ω2 Vc/F' routed out of structural estimates ('Between‐Subject Variability (BSV)')</li><li>table section iiv: 'Ω2 CL/F' routed out of structural estimates ('Between‐Subject Variability (BSV)')</li><li>table section iiv: 'Ω2 CL/F' routed out of structural estimates ('Between‐Subject Variability (BSV)')</li><li>table section iiv: 'Ω2 CL/F' routed out of structural estimates ('Between‐Subject Variability (BSV)')</li><li>table section residual_error: 'σ2 add' routed out of structural estimates ('Residual Unexplained Variability (RUV)')</li><li>table section residual_error: 'σ2 add' routed out of structural estimates ('Residual Unexplained Variability (RUV)')</li><li>table section residual_error: 'σ2 prop' routed out of structural estimates ('Residual Unexplained Variability (RUV)')</li><li>table section residual_error: 'σ2 prop' routed out of structural estimates ('Residual Unexplained Variability (RUV)')</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Atomoxetine_Tobin2026_reference;
