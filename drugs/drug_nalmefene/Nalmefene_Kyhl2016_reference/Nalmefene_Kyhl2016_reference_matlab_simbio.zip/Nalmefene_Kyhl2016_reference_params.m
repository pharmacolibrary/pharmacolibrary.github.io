function p = Nalmefene_Kyhl2016_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: nalmefene   source: Kyhl_2016 / reference   route: iv_bolus
  % estimated (absent from source): dose
  p.name  = 'Nalmefene_Kyhl2016_reference_params';
  p.drug  = 'nalmefene';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'iv_bolus';        % 'oral' | 'iv_bolus'
  p.depot = false;             % oral -> first-order absorption depot
  p.Vc = 266.0;                % central volume [L]
  p.CL = 60.4;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.0;                % absorption rate [1/h]
  p.F  = 0.41;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 10.0;             % dose [mg]
end
