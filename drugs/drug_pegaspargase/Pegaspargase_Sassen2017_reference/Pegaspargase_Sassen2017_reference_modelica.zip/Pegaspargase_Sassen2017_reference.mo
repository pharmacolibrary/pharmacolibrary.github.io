model Pegaspargase_Sassen2017_reference
  parameter Real Cl_ref = 1.2222222222222222e-07 "Cl [m3/s]";
  parameter Real Vd_ref = 0.0032 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    adminMass = 1e-05,
    k12 = 1.302083333333333e-05,
    k21 = 1.4367816091954022e-05
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About pegaspargase</h4><p>Pegaspargase is a PEGylated asparaginase enzyme used as an antineoplastic drug to treat lymphoid leukemias and lymphomas, including acute lymphoblastic leukemia/lymphoma. It is an approved medicine, with one product authorised in the European Union for precursor cell lymphoblastic leukemia-lymphoma, and it is also used in the United States.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q7160547\">Wikidata Q7160547</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>pegaspargase</td></tr><tr><td>population:</td><td>review reference</td></tr><tr><td>source_paper:</td><td>Sassen_2017</td></tr><tr><td>measured_compound:</td><td>pegaspargase</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_2C: IV (no input phase)</td></tr></table><h4>Interpretation flags</h4><ul><li>built from REVIEW reference values (Sassen_2017) — secondary source</li><li>volume reported by review</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 93600, Tolerance = 1e-9, Interval = 1));
end Pegaspargase_Sassen2017_reference;
