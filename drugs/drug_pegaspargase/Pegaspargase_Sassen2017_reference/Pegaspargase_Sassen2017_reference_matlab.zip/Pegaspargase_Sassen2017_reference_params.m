function p = Pegaspargase_Sassen2017_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: pegaspargase   source: Sassen_2017 / reference   route: iv_bolus
  % estimated (absent from source): F, dose
  p.name  = 'Pegaspargase_Sassen2017_reference_params';
  p.drug  = 'pegaspargase';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'iv_bolus';        % 'oral' | 'iv_bolus'
  p.depot = false;             % oral -> first-order absorption depot
  p.Vc = 3.2;                % central volume [L]
  p.CL = 0.44;                % clearance [L/h]
  p.Vp = [2.9];             % peripheral volumes [L]
  p.Q  = [0.15];             % inter-compartmental clearances [L/h]
  p.ka = 0.0;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 10.0;             % dose [mg]
end
