model Telmisartan_Jeong2025_reference
  parameter Real Cl_ref = 5.0833333333333335e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.0207 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.5146168999999999,
    adminMass = 1e-05,
    ka = 5.055555555555555e-05,
    Tlag = 820.8000000000001,
    k12 = 0.00017042404723564142,
    k21 = 9.799382716049382e-06
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About telmisartan</h4><p>Telmisartan is an angiotensin II receptor blocker used to treat high blood pressure and congestive heart failure. It is widely used and authorised in the European Union, available alone and in combination products.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q733186\">Wikidata Q733186</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>telmisartan</td></tr><tr><td>population:</td><td>healthy subjects and hypertensive patients</td></tr><tr><td>source_paper:</td><td>Jeong_2025</td></tr><tr><td>measured_compound:</td><td>telmisartan</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>tab_0</td></tr><tr><td>input:</td><td>PK_2C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>telmisartan 514.617 g/mol (drugbank)</td></tr></table><h4>Interpretation flags</h4><ul><li>salvaged Q49 ('k a (h -1 )'=0.182) from results prose — parameter table was unreadable</li><li>salvaged Q290 ('V 1 /F (L)'=20.7) from results prose — parameter table was unreadable</li><li>salvaged Q27 ('CL/F (L/h)'=18.3) from results prose — parameter table was unreadable</li><li>salvaged Q82 ('V 2 /F (L)'=360) from results prose — parameter table was unreadable</li><li>salvaged Q69 ('Q/F (L/h)'=12.7) from results prose — parameter table was unreadable</li><li>salvaged Q83 ('ALAG (h)'=0.228) from results prose — parameter table was unreadable</li><li>apparent-ness (ontology-grounded): parameterization=apparent, measured_compound=telmisartan</li><li>held at status:extracted — NIL link or unit issue (mismatch/unknown/normalisation-failed) present</li><li>status held at route_to_review — not promoted</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Telmisartan_Jeong2025_reference;
