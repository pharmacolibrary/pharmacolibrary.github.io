% Run (SimBiology): build model + dose, simulate 0..24.0 h, plot.
p = Telmisartan_Tatami2003_final_estimates_of_the_model_paramete_params();
[model, dose, variant] = build_sb_pk(p);
sd = simulate_sb(model, variant, dose, 24.0);
