function p = Telmisartan_Tatami2003_estimated_parameters_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: telmisartan   source: Tatami_2003 / estimated_parameters   route: oral
  p.name  = 'Telmisartan_Tatami2003_estimated_parameters_params';
  p.drug  = 'telmisartan';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 105.6;                % central volume [L]
  p.CL = 100.8;                % clearance [L/h]
  p.Vp = [106.4];             % peripheral volumes [L]
  p.Q  = [103.9];             % inter-compartmental clearances [L/h]
  p.ka = 102.2;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 101.2;             % absorption lag [h]
  p.dose = 20.0;             % dose [mg]
end
