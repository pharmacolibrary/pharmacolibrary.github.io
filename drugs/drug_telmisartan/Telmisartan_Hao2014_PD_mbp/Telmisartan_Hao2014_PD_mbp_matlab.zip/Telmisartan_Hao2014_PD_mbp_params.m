function p = Telmisartan_Hao2014_PD_mbp_params()
% Telmisartan_Hao2014_PD_mbp_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% telmisartan Hao_2014::MBP: indirect_response_i exposure-response sweep (response = E0*(1 - Emax*frac)). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one ng/ml per second, in SI inside (kg/m3, s). Response MBP in mmHg. Driver: telmisartan (cited_pk).
p.E0 = 176.05263157894737;
p.Emax = 0.97;
p.EC50 = 0.0003601;
p.gamma = 1.0;
p.slope = 0.0;
p.exposure_per_s = 1e-06;
p.stop_time = 3700.0;
p.form = 'E0*(1 - Emax*frac)';
end
