model Telmisartan_Hao2014_PD_mbp
  "indirect_response_i exposure-response sweep — Hao_2014 :: MBP (mean arterial blood pressure)"
  extends Pharmacolibrary.Interfaces.PartialExposureResponseSweep(
    E0 = 176.052631579,      // [mmHg]
    Emax = 0.97,  // type I effect term
    EC50 = 0.0003601,  // [kg/m3; ng/ml × 1e-06]
    gamma = 1,
    exposure_per_s = 1e-06);   // 1 ng/ml per second
equation
  response = E0*(1 - Emax*frac);   // steady state, indirect response type I
  // e0_from_kin_kout: no baseline row; E0 = kin/kout (66.9/0.38 = 176.1) — the paper's stated baseline may differ
  // defaulted: gamma
  annotation(experiment(StartTime = 0, StopTime = 3700, Interval = 7.4),
    Documentation(info = "<html><body><h4>Telmisartan_Hao2014_PD_mbp</h4><p>The steady-state exposure-response curve of Hao K et al., <i>The Journal of pharmacy and pharmacology 66(8):1112–1121</i> 2014 (<a href=\"https://doi.org/10.1111/jphp.12230\">doi:10.1111/jphp.12230</a>) — mean arterial blood pressure [mmHg] against telmisartan ng/ml — obtained by sweeping the driver instead of simulating a dose. Model family: indirect_response_i.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = 176.052631579 mmHg     drug-free response (baseline) (kin/kout, Q327/Q328)
  Emax  =       0.97          maximal effect term (Imax, Q323)
  EC50  =      360.1 ng/ml    exposure at half of the maximal effect term (IC50, Q322)
  gamma = (library default) Hill coefficient</pre><p>The algebra is <code>response = E0*(1 - Emax*frac)</code>; this model only supplies the numbers. The x axis is one ng/ml of telmisartan per second of simulated time (exposure is in kg/m3): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 176.1   (drug-free)
  exposure = EC50 (360.1 ng/ml)  response 90.67
  exposure -> infinity  response 5.282</pre></body></html>"));
end Telmisartan_Hao2014_PD_mbp;
