model Telmisartan_Huang2019_reference
  parameter Real Cl_ref = 6.972222222222223e-06 "Cl [m3/s]";
  parameter Real cov_ugt1a1_0 = 0 "ugt1a1 covariate";
  parameter Real Vd_ref = 0.5 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 0.9,
    Cl = Cl_ref*(1 + (0.472)*cov_ugt1a1_0),
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.5146168999999999,
    adminMass = 8e-05,
    ka = 0.0001586111111111111,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About telmisartan</h4><p>Telmisartan is an angiotensin II receptor blocker used to treat high blood pressure and congestive heart failure. It is widely used and authorised in the European Union, available alone and in combination products.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q733186\">Wikidata Q733186</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>telmisartan</td></tr><tr><td>population:</td><td>Chinese patients with hypertension</td></tr><tr><td>source_paper:</td><td>Huang_2019</td></tr><tr><td>measured_compound:</td><td>telmisartan</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>tab_2</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>telmisartan 514.617 g/mol (drugbank)</td></tr></table><p><b>Defaulted (base-class default used):</b> F, Tlag.</p><h4>Interpretation flags</h4><ul><li>dropped duplicate Q22 ('GNDA on CL', value '0.67') — already have one for this compound</li><li>covariate level 'UGT1A1 AA on' → Q900:ugt1a1_aa_on = 0.472 (linear_fractional on Q22)</li><li>dropped duplicate Q22 ('CL (%)', value '14.9') — already have one for this compound</li><li>dropped duplicate Q64 ('V 2 (%)', value '88') — already have one for this compound</li><li>dropped unlinked row (NIL): 'CV (%)' — extend the ontology if this is a real PK parameter (source ['tab_2:row16:col1', 'tab_2:row16:col3'])</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=telmisartan</li><li>structure disagreement: deterministic 1C vs LLM 3C — review compartment count</li><li>gap-filled Q61 (V) from Jeong_2025's review values (primary lacked it)</li><li>skipped review gap-fill of TLAG: primary's parameterization (rate-constant / ka-only) does not use it</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 345600, Tolerance = 1e-9, Interval = 1));
end Telmisartan_Huang2019_reference;
