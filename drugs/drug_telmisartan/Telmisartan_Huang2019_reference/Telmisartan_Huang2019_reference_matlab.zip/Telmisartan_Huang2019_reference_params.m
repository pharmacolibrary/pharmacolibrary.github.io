function p = Telmisartan_Huang2019_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: telmisartan   source: Huang_2019 / reference   route: oral
  % estimated (absent from source): F
  p.name  = 'Telmisartan_Huang2019_reference_params';
  p.drug  = 'telmisartan';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 500.0;                % central volume [L]
  p.CL = 25.1;                % clearance [L/h]
  p.Vp = [30.0];             % peripheral volumes [L]
  p.Q  = [14.6];             % inter-compartmental clearances [L/h]
  p.ka = 0.571;                % absorption rate [1/h]
  p.F  = 0.9;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 80.0;             % dose [mg]
end
