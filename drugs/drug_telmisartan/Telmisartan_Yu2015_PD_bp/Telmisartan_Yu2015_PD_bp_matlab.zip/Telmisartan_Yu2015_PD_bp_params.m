function p = Telmisartan_Yu2015_PD_bp_params()
% Telmisartan_Yu2015_PD_bp_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% telmisartan Yu_2015::BP: indirect_response_i exposure-response sweep (response = E0*(1 - Emax*frac)). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one ng/mL per second, in SI inside (kg/m3, s). Response BP in mmHg. Driver: telmisartan (cited_pk).
p.E0 = 127.49999999999999;
p.Emax = 0.48;
p.EC50 = 0.00012209999999999999;
p.gamma = 1.0;
p.slope = 0.0;
p.exposure_per_s = 1e-06;
p.stop_time = 1300.0;
p.form = 'E0*(1 - Emax*frac)';
end
