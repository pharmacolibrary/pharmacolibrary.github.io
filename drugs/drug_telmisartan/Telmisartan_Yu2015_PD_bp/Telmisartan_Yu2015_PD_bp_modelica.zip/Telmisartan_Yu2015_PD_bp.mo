model Telmisartan_Yu2015_PD_bp
  "indirect_response_i exposure-response sweep — Yu_2015 :: BP (blood pressure)"
  extends Pharmacolibrary.Interfaces.PartialExposureResponseSweep(
    E0 = 127.5,      // [mmHg]
    Emax = 0.48,  // type I effect term
    EC50 = 0.0001221,  // [kg/m3; ng/mL × 1e-06]
    gamma = 1,
    exposure_per_s = 1e-06);   // 1 ng/mL per second
equation
  response = E0*(1 - Emax*frac);   // steady state, indirect response type I
  // e0_from_kin_kout: no baseline row; E0 = kin/kout (20.4/0.16 = 127.5) — the paper's stated baseline may differ
  // defaulted: gamma
  annotation(experiment(StartTime = 0, StopTime = 1300, Interval = 2.6),
    Documentation(info = "<html><body><!-- drug-about --><h4>About telmisartan</h4><p>Telmisartan is an angiotensin II receptor blocker used to treat high blood pressure and congestive heart failure. It is widely used and authorised in the European Union, available alone and in combination products.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q733186\">Wikidata Q733186</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h4>Telmisartan_Yu2015_PD_bp</h4><p>The steady-state exposure-response curve of Yu D et al., <i>Fundamental &amp; clinical pharmacology 29(6):543–552</i> 2015 (<a href=\"https://doi.org/10.1111/fcp.12152\">doi:10.1111/fcp.12152</a>) — blood pressure [mmHg] against telmisartan ng/mL — obtained by sweeping the driver instead of simulating a dose. Model family: indirect_response_i.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    =      127.5 mmHg     drug-free response (baseline) (kin/kout, Q327/Q328)
  Emax  =       0.48          maximal effect term (I max, Q323)
  EC50  =      122.1 ng/mL    exposure at half of the maximal effect term (IC 50, Q322)
  gamma = (library default) Hill coefficient</pre><p>The algebra is <code>response = E0*(1 - Emax*frac)</code>; this model only supplies the numbers. The x axis is one ng/mL of telmisartan per second of simulated time (exposure is in kg/m3): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 127.5   (drug-free)
  exposure = EC50 (122.1 ng/mL)  response 96.9
  exposure -> infinity  response 66.3</pre></body></html>"));
end Telmisartan_Yu2015_PD_bp;
