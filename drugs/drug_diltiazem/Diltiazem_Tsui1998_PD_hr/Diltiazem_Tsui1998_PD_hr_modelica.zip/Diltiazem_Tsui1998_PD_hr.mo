model Diltiazem_Tsui1998_PD_hr
  "emax exposure-response sweep — Tsui_1998 :: HR (heart rate)"
  extends Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep(
    E0 = 0,      // [1]
    Emax = -0.77,  // [1; % × 0.01]
    EC50 = 0.01,  // [kg/m3; microg mL(-1) × 0.001]
    gamma = 1,
    exposure_per_s = 0.001);   // 1 microg mL(-1) per second
  // imax_as_negative_emax: Imax (Q323) enters SigmoidEmaxSweep as −Emax
  // defaulted: E0
  // defaulted: gamma
  annotation(experiment(StartTime = 0, StopTime = 100, Interval = 0.2),
    Documentation(info = "<html><body><!-- drug-about --><h4>About diltiazem</h4><p>Diltiazem is a calcium channel blocker used to treat high blood pressure, angina, and certain heart rhythm problems such as atrial fibrillation and supraventricular tachycardia. It is an approved medicine and is widely used for these cardiovascular conditions.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q422229\">Wikidata Q422229</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h4>Diltiazem_Tsui1998_PD_hr</h4><p>The steady-state exposure-response curve of Tsui BC et al., <i>The Journal of pharmacy and pharmacology 50(2):183–188</i> 1998 (<a href=\"https://doi.org/10.1111/j.2042-7158.1998.tb06174.x\">doi:10.1111/j.2042-7158.1998.tb06174.x</a>) — heart rate against diltiazem microg mL(-1) — obtained by sweeping the driver instead of simulating a dose. Model family: emax.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = (library default) drug-free response (baseline)
  Emax  =         77 %        maximal effect term (Emax, Q323)
  EC50  =         10 microg mL(-1) exposure at half of the maximal effect term (EC50, Q321)
  gamma = (library default) Hill coefficient</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep\">SigmoidEmaxSweep</a>; this model only supplies the numbers. The x axis is one microg mL(-1) of diltiazem per second of simulated time (exposure is in kg/m3): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0   (drug-free)
  exposure = EC50 (10 microg mL(-1))  response -0.385
  exposure -> infinity  response -0.77</pre></body></html>"));
end Diltiazem_Tsui1998_PD_hr;
