function p = Diltiazem_Tsui1998_PD_dbp_params()
% Diltiazem_Tsui1998_PD_dbp_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% diltiazem Tsui_1998::DBP: emax exposure-response sweep (response = E0 + Emax*frac). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one microg mL(-1) per second, in SI inside (kg/m3, s). Response DBP in its own unit. Driver: diltiazem (cited_pk).
p.E0 = 0.0;
p.Emax = -0.72;
p.EC50 = 0.004399999999999999;
p.gamma = 1.0;
p.slope = 0.0;
p.exposure_per_s = 0.001;
p.stop_time = 44.0;
p.form = 'E0 + Emax*frac';
end
