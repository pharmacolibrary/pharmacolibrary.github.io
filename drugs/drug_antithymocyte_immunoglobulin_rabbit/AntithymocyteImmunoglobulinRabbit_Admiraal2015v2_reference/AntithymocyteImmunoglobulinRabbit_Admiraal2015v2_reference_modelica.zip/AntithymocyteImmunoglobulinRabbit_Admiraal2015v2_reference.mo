model AntithymocyteImmunoglobulinRabbit_Admiraal2015v2_reference
  parameter Real Cl_ref = 5.88888888888889e-07 "Cl [m3/s]";
  parameter Real Vd_ref = 0.00784 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    adminMass = 0.0001
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About antithymocyte_immunoglobulin_rabbit</h4><p>Rabbit anti-thymocyte globulin is an immunosuppressant antibody medicine used to suppress T cells, for example in transplant settings. It is an approved medicine, though it carries a boxed warning and is also being studied for further uses.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q20801777\">Wikidata Q20801777</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>antithymocyte_immunoglobulin_rabbit</td></tr><tr><td>population:</td><td>children receiving allogeneic hematopoietic cell transplantation</td></tr><tr><td>source_paper:</td><td>Admiraal_2015_2</td></tr><tr><td>measured_compound:</td><td>antithymocyte immunoglobulin</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C: IV (no input phase)</td></tr></table><h4>Interpretation flags</h4><ul><li>salvaged Q22 ('CL'=2.12) from results prose — parameter table was unreadable</li><li>salvaged Q63 ('V1'=7.84) from results prose — parameter table was unreadable</li><li>implicit units: 'CL' → L/h (from the popPK convention: 'The paper defines TIME in days and AMT in mg, but does not explicitly state the unit for CL in the text. Based on popula')</li><li>implicit units: 'V1' → L (from the popPK convention: 'The paper does not explicitly state the unit for V1. Based on population PK conventions, volume of distribution is commo')</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=antithymocyte immunoglobulin</li><li>1C volume normalization: Q63→Q61 (single-compartment model has no central/peripheral split; 'V1' is the general volume)</li><li>molar mass: none found for 'antithymocyte_immunoglobulin_rabbit' — its concentrations stay mass-only</li><li>molar mass: none found for 'antithymocyte immunoglobulin' — its concentrations stay mass-only</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end AntithymocyteImmunoglobulinRabbit_Admiraal2015v2_reference;
