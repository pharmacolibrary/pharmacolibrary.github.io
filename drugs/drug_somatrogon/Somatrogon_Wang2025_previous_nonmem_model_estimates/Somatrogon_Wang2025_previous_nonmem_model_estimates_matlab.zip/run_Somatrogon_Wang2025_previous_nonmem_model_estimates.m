% Run: build params, simulate 0..96.0 h, plot + save Somatrogon_Wang2025_previous_nonmem_model_estimates.png/.csv/.json.
% Interactive display (keep the window open):  octave --persist run_Somatrogon_Wang2025_previous_nonmem_model_estimates.m
here = fileparts(mfilename('fullpath'));
p = Somatrogon_Wang2025_previous_nonmem_model_estimates_params();
out = simulate_pk(p, 0:0.05:96.0);

% figure (shown on screen if interactive) and PNG (works in MATLAB and Octave)
fig = figure; plot(out.t, out.C, 'LineWidth', 1.5); grid on;
xlabel('time [h]'); ylabel('central concentration [mg/L]');
title('somatrogon — Wang_2025 (oral)');
print(fig, fullfile(here, 'Somatrogon_Wang2025_previous_nonmem_model_estimates.png'), '-dpng', '-r150');

% CSV (time_h, Cc_mg_per_L)
fid = fopen(fullfile(here, 'Somatrogon_Wang2025_previous_nonmem_model_estimates.csv'), 'w');
fprintf(fid, 'time_h,Cc_mg_per_L\n');
fprintf(fid, '%.10g,%.10g\n', [out.t(:), out.C(:)].');
fclose(fid);

% JSON (summary + arrays; jsonencode with a manual fallback for older versions)
fid = fopen(fullfile(here, 'Somatrogon_Wang2025_previous_nonmem_model_estimates.json'), 'w');
try
  s.model = 'Somatrogon_Wang2025_previous_nonmem_model_estimates'; s.Cmax = out.Cmax; s.Tmax = out.Tmax; s.AUC = out.AUC;
  s.time_h = out.t(:).'; s.Cc_mg_per_L = out.C(:).';
  fprintf(fid, '%s', jsonencode(s));
catch
  fprintf(fid, '{"model":"Somatrogon_Wang2025_previous_nonmem_model_estimates","Cmax":%g,"Tmax":%g,"AUC":%g}', out.Cmax, out.Tmax, out.AUC);
end
fclose(fid);

fprintf('Cmax=%.3g mg/L  Tmax=%.3g h  AUC=%.3g mg*h/L\n', out.Cmax, out.Tmax, out.AUC);
fprintf('wrote Somatrogon_Wang2025_previous_nonmem_model_estimates.png, Somatrogon_Wang2025_previous_nonmem_model_estimates.csv, Somatrogon_Wang2025_previous_nonmem_model_estimates.json\n');
