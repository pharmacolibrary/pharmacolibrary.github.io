model Somatrogon_Wang2025_previous_nonmem_model_estimates
  parameter Real Cl_ref = 1.311111111111111e-07 "Cl [m3/s]";
  parameter Real cov_weight_0 = 0 "weight covariate";
  parameter Real cov_weight_1 = 0 "weight covariate";
  parameter Boolean cov_ada_2 = false "ada level 2";
  parameter Real Vd_ref = 0.0109 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref*(1 + (1.26)*cov_weight_0)*(1 + (1.74)*cov_weight_1) + (-7.166666666666666e-08)*(if cov_ada_2 then 1 else 0),
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    adminMass = 1.75e-05,
    ka = 8.694444444444445e-05,
    Tlag = 1270.8,
    k12 = 3.567787971457696e-07
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About somatrogon</h4><p>Somatrogon is a long-acting growth hormone analogue used to treat growth disorders in children. It is authorised in the European Union as a newer medicine, and is also still under investigation for further uses.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q110220159\">Wikidata Q110220159</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>somatrogon</td></tr><tr><td>population:</td><td>pediatric participants</td></tr><tr><td>source_paper:</td><td>Wang_2025</td></tr><tr><td>measured_compound:</td><td>somatrogon</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>psp413279-tbl-0005</td></tr><tr><td>input:</td><td>PK_2C_enteral: absorption rate constant reported</td></tr></table><p><b>Defaulted (base-class default used):</b> k21.</p><h4>Interpretation flags</h4><ul><li>covariate level 'Weight effect on CL/F and Q/F' → Q900:weight_effect_on_cl_f_and_q_f = 1.26 (linear_fractional on Q27)</li><li>covariate level 'Weight effect on Vc/F and Vp/F' → Q900:weight_effect_on_vc_f_and_vp_f = 1.74 (linear_fractional on Q27)</li><li>implicit units: 'Ka (1/h)' → 1/h (from the popPK convention: &quot;The text refers to 'first-order absorption rate constant Ka', for which the conventional unit is 1/h, consistent with th&quot;)</li><li>apparent-ness (ontology-grounded): parameterization=apparent, measured_compound=somatrogon</li><li>held at status:extracted — NIL link or unit issue (mismatch/unknown/normalisation-failed) present</li><li>status held at route_to_review — not promoted</li><li>population split: 'previous nonmem model estimates' subgroup of Wang_2025 (paper reports 2 populations: nonmem focei estimates (previous analysis), previous nonmem model estimates)</li><li>molar mass: none found for 'somatrogon' — its concentrations stay mass-only</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 345600, Tolerance = 1e-9, Interval = 1));
end Somatrogon_Wang2025_previous_nonmem_model_estimates;
