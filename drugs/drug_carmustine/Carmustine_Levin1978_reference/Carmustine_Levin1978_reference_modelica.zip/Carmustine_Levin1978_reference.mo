model Carmustine_Levin1978_reference
  parameter Real Cl_ref = 6.533333333333333e-05 "Cl [m3/s]";
  parameter Real Vd_ref = 0.2275 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.21405000000000002,
    adminMass = 1e-05
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About carmustine</h4><p>Carmustine is an alkylating anticancer drug used to treat cancers such as Hodgkin disease and non-Hodgkin lymphoma. It remains an approved medicine, with an authorised product in the European Union, and carries a boxed warning.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q415869\">Wikidata Q415869</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>carmustine</td></tr><tr><td>population:</td><td>patients</td></tr><tr><td>source_paper:</td><td>Levin_1978</td></tr><tr><td>measured_compound:</td><td>BCNU</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>carmustine 214.05 g/mol (drugbank)</td></tr></table><h4>Interpretation flags</h4><ul><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=BCNU</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li><li>unit re-normalised: CL 'ml/minute/kg' now converts (value unchanged)</li><li>unit re-normalised: kel 'MINUTE-1' now converts (value unchanged)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Carmustine_Levin1978_reference;
