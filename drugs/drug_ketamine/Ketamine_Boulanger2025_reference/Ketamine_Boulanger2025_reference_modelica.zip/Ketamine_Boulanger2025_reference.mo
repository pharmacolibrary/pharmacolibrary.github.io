model Ketamine_Boulanger2025_reference
  parameter Real Cl_ref = 2.916666666666667e-07 "Cl [m3/s]";
  parameter Real Vd_ref = 0.0091 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.237725,
    adminMass = 1e-05
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About ketamine</h4><p>Ketamine is a dissociative general anesthetic that is also used as an analgesic for pain and has been studied for treating substance abuse. It is an approved medicine, appears on the WHO essential medicines list, and is also approved for veterinary use.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q243547\">Wikidata Q243547</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>ketamine</td></tr><tr><td>population:</td><td>review reference</td></tr><tr><td>source_paper:</td><td>Boulanger_2025</td></tr><tr><td>measured_compound:</td><td>ketamine</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>ketamine 237.725 g/mol (drugbank)</td></tr></table><h4>Interpretation flags</h4><ul><li>built from REVIEW reference values (Boulanger_2025) — secondary source</li><li>volume reported by review</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 111600, Tolerance = 1e-9, Interval = 1));
end Ketamine_Boulanger2025_reference;
