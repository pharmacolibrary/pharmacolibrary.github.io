function p = Ketamine_Douglas2025_PD_pain_score_params()
% Ketamine_Douglas2025_PD_pain_score_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% ketamine Douglas_2025::PAIN_SCORE: emax exposure-response sweep (response = E0 + Emax*frac). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one mg/kg/h per second, in SI inside (kg/m3, s). Response PAIN SCORE in pain units (0–10). Driver: ketamine (dose_only).
p.E0 = 6.4;
p.Emax = -0.11;
p.EC50 = 4.166666666666667e-10;
p.gamma = 0.26;
p.slope = 0.0;
p.exposure_per_s = 2.77777777778e-10;
p.stop_time = 15.0;
p.form = 'E0 + Emax*frac';
end
