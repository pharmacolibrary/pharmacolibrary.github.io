model Ketamine_Herd2007_reference
  parameter Real Cl_ref = 0.0002625 "Cl [m3/s]";
  parameter Real Vd_ref = 1.5399999999999998 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 0.9,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.22369999999999998,
    adminMass = 0.0001,
    ka = 0.00018333333333333334,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About ketamine</h4><p>Ketamine is a dissociative general anesthetic that is also used as an analgesic for pain and has been studied for treating substance abuse. It is an approved medicine, appears on the WHO essential medicines list, and is also approved for veterinary use.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q243547\">Wikidata Q243547</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>ketamine</td></tr><tr><td>population:</td><td>children and adults</td></tr><tr><td>source_paper:</td><td>Herd_2007</td></tr><tr><td>measured_compound:</td><td>norketamine</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>ketamine 237.725 g/mol (drugbank); norketamine 223.7 g/mol (pubchem)</td></tr></table><p><b>Defaulted (base-class default used):</b> F, Tlag.</p><h4>Interpretation flags</h4><ul><li>the dosed compound is ketamine; the compartment is norketamine. Input enters at the reported formation rate, so formation is already accounted for in the input step and the simulated concentration is norketamine, not ketamine</li><li>apparent parameters (CLm/F, Vm/F) already contain F and the metabolised fraction, so F=1 and no molar correction is applied — adding either would double-count it</li><li>ketamine's own concentration-time course is not produced by this model</li><li>covariate category for equation variable from footnote/prose kept as documentation only (['Herd_2007:abstract'])</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=norketamine</li><li>template fit: PK_3M_9C — formed from central; parent 2, metabolites [0]</li><li>row roles (LLM): model_class=compartmental; 8/8 row label(s) assigned, 6 linked by role; re-tagged norketamine→parent ×4</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li><li>gap-filled Q49 (kabs) from Kir_2025's review values (primary lacked it)</li><li>engineer: parent_metabolite composite downgraded to a 1C model of the measured compound — the paper reports the metabolite's own CL and V but neither the parent's disposition nor a formation rate, so the parent sub-component could not be populated; the parent's concentration-time course is NOT produced by this model</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Ketamine_Herd2007_reference;
