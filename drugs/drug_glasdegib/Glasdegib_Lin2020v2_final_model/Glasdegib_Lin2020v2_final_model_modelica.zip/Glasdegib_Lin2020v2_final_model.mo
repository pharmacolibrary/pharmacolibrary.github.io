model Glasdegib_Lin2020v2_final_model
  parameter Real Cl_ref = 1.7416666666666666e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.00332 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.374448,
    adminMass = 5e-06,
    ka = 1.6666666666666667e-05,
    Tlag = 0.0,
    k12 = 0.00010793172690763053,
    k21 = 1.2833828778816426e-06
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About glasdegib</h4><p>Glasdegib is a hedgehog pathway inhibitor used to treat acute myeloid leukemia. It is an approved medicine, authorised in the European Union, and also remains under investigation for other uses.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q27077810\">Wikidata Q27077810</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>glasdegib</td></tr><tr><td>population:</td><td>patients with advanced hematologic malignancies and solid tumors</td></tr><tr><td>source_paper:</td><td>Lin_2020_2</td></tr><tr><td>measured_compound:</td><td>glasdegib</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>jcph1556-tbl-0003</td></tr><tr><td>input:</td><td>PK_2C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>glasdegib 374.448 g/mol (drugbank)</td></tr></table><p><b>Defaulted (base-class default used):</b> Tlag.</p><h4>Interpretation flags</h4><ul><li>table section residual_error: 'Hematologic' routed out of structural estimates ('Residual error, proportional error')</li><li>table section residual_error: 'Solid tumors' routed out of structural estimates ('Residual error, proportional error')</li><li>dropped unlinked row (NIL): 'OFV' — extend the ontology if this is a real PK parameter (source ['jcph1556-tbl-0003:row2:col1', 'jcph1556-tbl-0003:row2:col2', 'jcph1556-tbl-0003:row2:col3', 'jcph1556-tbl-0003:row2:col6'])</li><li>kept covariate coefficient θCYPmod=-0.17 (covariate CYPmod) — not an ontology parameter</li><li>kept covariate coefficient θCYPstrong=-0.30 (covariate CYPstrong) — not an ontology parameter</li><li>routed 'θWNCL' → Q312 (IIV) to iiv — variability estimate, not a structural parameter</li><li>kept covariate coefficient θBPBL=-0.004 (covariate BPBL) — not an ontology parameter</li><li>routed 'θsolid' → Q312 (IIV) to iiv — variability estimate, not a structural parameter</li><li>dropped duplicate Q27 ('CL/F', value '14.8') — already have one for this compound</li><li>dropped duplicate Q290 ('Vc/F', value '22.8') — already have one for this compound</li><li>dropped duplicate Q82 ('Vp/F', value '118.9') — already have one for this compound</li><li>dropped duplicate Q69 ('Q/F', value '36.3') — already have one for this compound</li><li>dropped duplicate Q49 ('ka', value '97.8') — already have one for this compound</li><li>apparent-ness (ontology-grounded): parameterization=apparent, measured_compound=glasdegib</li><li>population split: 'final model' subgroup of Lin_2020_2 (paper reports 2 populations: estimate, final model)</li><li>skipped review gap-fill of TLAG: primary's parameterization (rate-constant / ka-only) does not use it</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 259200, Tolerance = 1e-9, Interval = 1));
end Glasdegib_Lin2020v2_final_model;
