model Eperisone_Baek2021_reference
  parameter Real Cl_ref = 1.09e-05 "Cl [m3/s]";
  parameter Real Vd_ref = 0.039240000000000004 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.2593865,
    adminMass = 0.00015,
    ka = 0.00041666666666666664,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About eperisone</h4><p>Eperisone is a centrally acting muscle relaxant that has been used to treat muscle spasticity and related musculoskeletal conditions. It is not authorised in the European Union and is considered investigational in major drug databases, though it has been marketed in some Asian countries.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q426401\">Wikidata Q426401</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>eperisone</td></tr><tr><td>population:</td><td>healthy Korean volunteers</td></tr><tr><td>source_paper:</td><td>Baek_2021</td></tr><tr><td>measured_compound:</td><td>eperisone</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_2C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>eperisone 259.387 g/mol (drugbank)</td></tr></table><p><b>Defaulted (base-class default used):</b> Tlag, k12, k21.</p><h4>Interpretation flags</h4><ul><li>unit_dimension_unknown: '× 103  l/h' (CL/F)</li><li>unit_dimension_unknown: '× 103  L' (V/F)</li><li>unit_dimension_unknown: '× 103  l/h' (CL/F)</li><li>dropped duplicate Q27 ('typical population CL/F', value 30.8) — already have one for this compound</li><li>unit_dimension_unknown: '× 103  l' (V1/F)</li><li>routed 'Interindividual variability in CL/F' → Q312 (IIV) to iiv — variability estimate, not a structural parameter</li><li>routed 'Interindividual variability in V c /F' → Q312 (IIV) to iiv — variability estimate, not a structural parameter</li><li>routed 'interoccasion variability in CL/F' → Q313 (IOV) to iov — variability estimate, not a structural parameter</li><li>routed 'interoccasion variability in V c /F' → Q313 (IOV) to iov — variability estimate, not a structural parameter</li><li>implicit units: 'apparent clearance (CL/F)' → L/h (from the popPK convention: 'The paper provides no explicit unit. Apparent clearance (CL/F) in population pharmacokinetics is conventionally expresse')</li><li>implicit units: 'apparent volume of distribution' → L (from the popPK convention: 'The paper provides no explicit unit. Apparent volume of distribution (V/F) in population pharmacokinetics is conventiona')</li><li>implicit units: 'apparent volume of distribution in the central compartment [V c /F]' → L (from the popPK convention: 'The paper provides no explicit unit. Apparent central volume of distribution (V1/F) in population pharmacokinetics is co')</li><li>apparent-ness (ontology-grounded): parameterization=apparent, measured_compound=eperisone</li><li>structure disagreement: deterministic 2C vs LLM 1C — review compartment count</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li><li>skipped review gap-fill of TLAG: primary's parameterization (rate-constant / ka-only) does not use it</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Eperisone_Baek2021_reference;
