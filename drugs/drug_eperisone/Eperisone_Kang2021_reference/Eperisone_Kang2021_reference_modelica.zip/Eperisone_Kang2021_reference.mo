model Eperisone_Kang2021_reference
  parameter Real Cl_ref = 2.777777777777778e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.05 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.2593865,
    adminMass = 1e-05
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About eperisone</h4><p>Eperisone is a centrally acting muscle relaxant that has been used to treat muscle spasticity and related musculoskeletal conditions. It is not authorised in the European Union and is considered investigational in major drug databases, though it has been marketed in some Asian countries.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q426401\">Wikidata Q426401</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>eperisone</td></tr><tr><td>population:</td><td>review reference</td></tr><tr><td>source_paper:</td><td>Kang_2021</td></tr><tr><td>measured_compound:</td><td>eperisone</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>eperisone 259.387 g/mol (drugbank)</td></tr></table><h4>Interpretation flags</h4><ul><li>built from REVIEW reference values (Kang_2021) — secondary source</li><li>volume reported by review</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Eperisone_Kang2021_reference;
