model Natalizumab_Moes2022_reference
  parameter Real Cl_ref = 8.391203703703704e-09 "Cl [m3/s]";
  parameter Real Vd_ref = 0.00434 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    adminMass = 1e-05
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About natalizumab</h4><p>Natalizumab is a monoclonal antibody used to treat multiple sclerosis, including relapsing-remitting forms, and Crohn's disease. It is authorised in the European Union and prescribed under medical supervision, carrying a boxed warning.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q386119\">Wikidata Q386119</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>natalizumab</td></tr><tr><td>population:</td><td>review reference</td></tr><tr><td>source_paper:</td><td>Moes_2022</td></tr><tr><td>measured_compound:</td><td>natalizumab</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C: IV (no input phase)</td></tr></table><h4>Interpretation flags</h4><ul><li>built from REVIEW reference values (Moes_2022) — secondary source</li><li>volume reported by review</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 1814400, Tolerance = 1e-9, Interval = 1));
end Natalizumab_Moes2022_reference;
