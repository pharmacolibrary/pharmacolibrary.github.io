function p = Spironolactone_Lass2024_value_2_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: spironolactone   source: Lass_2024 / value_2   route: iv_bolus
  % estimated (absent from source): F
  p.name  = 'Spironolactone_Lass2024_value_2_params';
  p.drug  = 'spironolactone';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'iv_bolus';        % 'oral' | 'iv_bolus'
  p.depot = false;             % oral -> first-order absorption depot
  p.Vc = 103.0;                % central volume [L]
  p.CL = 78.0;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.0;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 70.0;             % dose [mg]
end
