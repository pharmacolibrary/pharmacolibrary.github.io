model Terbutaline_Pouliquen2015_reference
  parameter Real Cl_ref = 2.4305555555555557e-09 "Cl [m3/s]";
  parameter Real Vd_ref = 0.0036000000000000003 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.2252842,
    adminMass = 1.5e-05
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About terbutaline</h4><p>Terbutaline is a beta-2 agonist bronchodilator used to treat asthma and other obstructive lung diseases. It is an approved medicine, available as inhalation and systemic formulations, and has also been investigated as a uterine relaxant.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q424340\">Wikidata Q424340</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>terbutaline</td></tr><tr><td>population:</td><td>review reference</td></tr><tr><td>source_paper:</td><td>Pouliquen_2015</td></tr><tr><td>measured_compound:</td><td>terbutaline</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>terbutaline 225.284 g/mol (drugbank)</td></tr></table><h4>Interpretation flags</h4><ul><li>built from REVIEW reference values (Pouliquen_2015) — secondary source</li><li>volume reported by review</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 5443200, Tolerance = 1e-9, Interval = 1));
end Terbutaline_Pouliquen2015_reference;
