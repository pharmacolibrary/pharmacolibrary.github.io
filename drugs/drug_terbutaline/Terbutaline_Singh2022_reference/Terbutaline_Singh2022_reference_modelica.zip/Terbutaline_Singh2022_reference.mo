model Terbutaline_Singh2022_reference
  parameter Real Cl_ref = 9.25925925925926e-10 "Cl [m3/s]";
  parameter Real Vd_ref = 0.006110000000000001 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.2252842,
    adminMass = 1.5e-05,
    ka = 0.0001388888888888889,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About terbutaline</h4><p>Terbutaline is a beta-2 agonist bronchodilator used to treat asthma and other obstructive lung diseases. It is an approved medicine, available as inhalation and systemic formulations, and has also been investigated as a uterine relaxant.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q424340\">Wikidata Q424340</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>terbutaline</td></tr><tr><td>population:</td><td>review reference</td></tr><tr><td>source_paper:</td><td>Singh_2022</td></tr><tr><td>measured_compound:</td><td>terbutaline</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C_enteral: apparent (/F) parameterization ⇒ extravascular dosing</td></tr><tr><td>molar_masses:</td><td>terbutaline 225.284 g/mol (drugbank)</td></tr></table><p><b>Defaulted (base-class default used):</b> ka, Tlag.</p><h4>Interpretation flags</h4><ul><li>built from REVIEW reference values (Singh_2022) — secondary source</li><li>volume reported by review</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 15552000, Tolerance = 1e-9, Interval = 1));
end Terbutaline_Singh2022_reference;
