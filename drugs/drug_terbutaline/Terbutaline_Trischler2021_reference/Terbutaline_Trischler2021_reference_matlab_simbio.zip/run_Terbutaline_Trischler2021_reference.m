% Run (SimBiology): build model + dose, simulate 0..2016.0 h, plot.
p = Terbutaline_Trischler2021_reference_params();
[model, dose, variant] = build_sb_pk(p);
sd = simulate_sb(model, variant, dose, 2016.0);
