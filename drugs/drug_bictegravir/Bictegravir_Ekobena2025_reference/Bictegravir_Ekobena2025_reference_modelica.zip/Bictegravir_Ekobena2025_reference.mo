model Bictegravir_Ekobena2025_reference
  parameter Real Cl_ref = 1.277777777777778e-07 "Cl [m3/s]";
  parameter Real Vd_ref = 0.0109 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 0.9,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.449386,
    adminMass = 5e-05,
    ka = 0.00017777777777777779,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About bictegravir</h4><p>Bictegravir is an antiviral medicine used to treat HIV infections. It is an approved drug, given as part of combination antiviral therapy for HIV.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q27270406\">Wikidata Q27270406</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>bictegravir</td></tr><tr><td>population:</td><td>people with HIV</td></tr><tr><td>source_paper:</td><td>Ekobena_2025</td></tr><tr><td>measured_compound:</td><td>bictegravir</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>dkaf297-T2</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>bictegravir 449.386 g/mol (drugbank)</td></tr></table><p><b>Defaulted (base-class default used):</b> F, Tlag.</p><h4>Interpretation flags</h4><ul><li>dropped value-less row: 'Parameters'</li><li>dropped unlinked row (NIL): 'βBodyweight' — extend the ontology if this is a real PK parameter (source ['dkaf297-T2:row6:col1', 'dkaf297-T2:footnote'])</li><li>routed 'βAge' → Q314 (omega_cov) to covariance — variability estimate, not a structural parameter</li><li>NIL: refused to back-fill base 'kabs' from footnote/prose loose number None (source ['dkaf297-T2:footnote']); the table cell was unparseable — needs review</li><li>apparent-by-design (ADVISORY, codes unchanged): extravascular dosing with no identifiable F, so these reported disposition parameters are likely apparent unless the model puts first-pass in its structure — Q61 (V (L)); Q22 (CL (L/h))</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=bictegravir</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of TLAG: primary's parameterization (rate-constant / ka-only) does not use it</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 345600, Tolerance = 1e-9, Interval = 1));
end Bictegravir_Ekobena2025_reference;
