model Bictegravir_Khoei2026_reference
  parameter Real Cl_ref = 2.7777777777777776e-07 "Cl [m3/s]";
  parameter Real Vd_ref = 0.0174 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.449386,
    adminMass = 0.0001,
    ka = 0.0006222222222222223,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About bictegravir</h4><p>Bictegravir is an antiviral medicine used to treat HIV infections. It is an approved drug, given as part of combination antiviral therapy for HIV.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q27270406\">Wikidata Q27270406</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>bictegravir</td></tr><tr><td>population:</td><td>review reference</td></tr><tr><td>source_paper:</td><td>Khoei_2026</td></tr><tr><td>measured_compound:</td><td>bictegravir</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>bictegravir 449.386 g/mol (drugbank)</td></tr></table><p><b>Defaulted (base-class default used):</b> Tlag.</p><h4>Interpretation flags</h4><ul><li>built from REVIEW reference values (Khoei_2026) — secondary source</li><li>volume reported by review</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 259200, Tolerance = 1e-9, Interval = 1));
end Bictegravir_Khoei2026_reference;
