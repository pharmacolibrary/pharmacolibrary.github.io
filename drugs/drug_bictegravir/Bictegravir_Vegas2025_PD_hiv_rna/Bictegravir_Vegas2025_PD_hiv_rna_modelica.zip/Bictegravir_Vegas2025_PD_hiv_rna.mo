model Bictegravir_Vegas2025_PD_hiv_rna
  "sigmoid_emax exposure-response sweep — Vegas_2025 :: HIV-RNA (HIV-RNA (viral load, via inhibition of viral infectivity in the viral dynamics model))"
  extends Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep(
    E0 = 410.37,      // [cell/μL]
    Emax = -0.99,  // [copies/mL]
    EC50 = 0.00014794,  // [kg/m3; ng/mL × 1e-06]
    gamma = 1,
    exposure_per_s = 1e-06);   // 1 ng/mL per second
  // imax_as_negative_emax: Imax (Q323) enters SigmoidEmaxSweep as −Emax
  annotation(experiment(StartTime = 0, StopTime = 1500, Interval = 3),
    Documentation(info = "<html><body><!-- drug-about --><h4>About bictegravir</h4><p>Bictegravir is an antiviral medicine used to treat HIV infections. It is an approved drug, given as part of combination antiviral therapy for HIV.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q27270406\">Wikidata Q27270406</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h4>Bictegravir_Vegas2025_PD_hiv_rna</h4><p>The steady-state exposure-response curve of Vegas Rodriguez A et al., <i>The AAPS journal 27(6):161</i> 2025 (<a href=\"https://doi.org/10.1208/s12248-025-01136-4\">doi:10.1208/s12248-025-01136-4</a>) — HIV-RNA (viral load, via inhibition of viral infectivity in the viral dynamics model) [copies/mL] against bictegravir ng/mL — obtained by sweeping the driver instead of simulating a dose. Model family: sigmoid_emax.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    =     410.37 cell/μL  drug-free response (baseline) (T 0 (cell/μL), Q324)
  Emax  =       0.99 copies/mL maximal effect term (Emax, Q323)
  EC50  =     147.94 ng/mL    exposure at half of the maximal effect term (EC50 BIC, Q321)
  gamma =          1          Hill coefficient (gamma (Hill coefficient), Q325)</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep\">SigmoidEmaxSweep</a>; this model only supplies the numbers. The x axis is one ng/mL of bictegravir per second of simulated time (exposure is in kg/m3): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 410.4   (drug-free)
  exposure = EC50 (147.94 ng/mL)  response 409.9
  exposure -> infinity  response 409.4</pre></body></html>"));
end Bictegravir_Vegas2025_PD_hiv_rna;
