model Ruxolitinib_Polepally2026_reference
  parameter Real Cl_ref = 1.5856481481481483e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.0383 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.306365,
    adminMass = 3e-05,
    ka = 5.4398148148148144e-05,
    Tlag = 4138.5599999999995,
    k12 = 2.3389904264577896e-05,
    k21 = 1.1441038739889317e-05
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About ruxolitinib</h4><p>Ruxolitinib, a JAK inhibitor, is used for myeloproliferative disorders such as myelofibrosis and polycythemia vera, for graft-versus-host disease, and as a skin preparation for vitiligo. It is approved and authorised in the European Union, with additional investigational uses.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q7383611\">Wikidata Q7383611</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>ruxolitinib</td></tr><tr><td>population:</td><td>review reference</td></tr><tr><td>source_paper:</td><td>Polepally_2026</td></tr><tr><td>measured_compound:</td><td>ruxolitinib</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_2C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>ruxolitinib 306.365 g/mol (drugbank)</td></tr></table><h4>Interpretation flags</h4><ul><li>built from REVIEW reference values (Polepally_2026) — secondary source</li><li>volume reported by review</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 140400, Tolerance = 1e-9, Interval = 1));
end Ruxolitinib_Polepally2026_reference;
