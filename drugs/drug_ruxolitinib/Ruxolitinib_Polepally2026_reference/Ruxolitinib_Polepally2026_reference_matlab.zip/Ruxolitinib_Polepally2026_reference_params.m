function p = Ruxolitinib_Polepally2026_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: ruxolitinib   source: Polepally_2026 / reference   route: oral
  p.name  = 'Ruxolitinib_Polepally2026_reference_params';
  p.drug  = 'ruxolitinib';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 38.3;                % central volume [L]
  p.CL = 5.708333;                % clearance [L/h]
  p.Vp = [78.3];             % peripheral volumes [L]
  p.Q  = [3.225];             % inter-compartmental clearances [L/h]
  p.ka = 0.195833;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 1.1496;             % absorption lag [h]
  p.dose = 30.0;             % dose [mg]
end
