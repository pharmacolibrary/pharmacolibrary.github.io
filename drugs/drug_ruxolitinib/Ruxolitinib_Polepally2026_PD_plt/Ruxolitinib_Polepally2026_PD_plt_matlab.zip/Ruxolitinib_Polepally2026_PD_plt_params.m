function p = Ruxolitinib_Polepally2026_PD_plt_params()
% Ruxolitinib_Polepally2026_PD_plt_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% ruxolitinib Polepally_2026::PLT: indirect_response_ii exposure-response sweep (response = E0/(1 - Emax*frac)). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one mg/L per second, in SI inside (kg/m3, s). Response PLT in 109/L. Driver: ruxolitinib (pk_record).
p.E0 = 0.0;
p.Emax = 1.0;
p.EC50 = 6.829999999999998e-05;
p.gamma = 1.0;
p.slope = 0.0;
p.exposure_per_s = 0.001;
p.stop_time = 0.69;
p.form = 'E0/(1 - Emax*frac)';
end
