model Ruxolitinib_Polepally2026_PD_sv
  "indirect_response_i exposure-response sweep — Polepally_2026 :: SV (spleen volume)"
  extends Pharmacolibrary.Interfaces.PartialExposureResponseSweep(
    E0 = 0,      // [1]
    Emax = 1,  // type I effect term
    EC50 = 5.97e-05,  // [kg/m3; mg/L × 0.001]
    gamma = 1,
    exposure_per_s = 0.001);   // 1 mg/L per second
equation
  response = E0*(1 - Emax*frac);   // steady state, indirect response type I
  // defaulted: E0
  // defaulted: Emax
  // defaulted: gamma
  annotation(experiment(StartTime = 0, StopTime = 0.6, Interval = 0.0012),
    Documentation(info = "<html><body><!-- drug-about --><h4>About ruxolitinib</h4><p>Ruxolitinib, a JAK inhibitor, is used for myeloproliferative disorders such as myelofibrosis and polycythemia vera, for graft-versus-host disease, and as a skin preparation for vitiligo. It is approved and authorised in the European Union, with additional investigational uses.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q7383611\">Wikidata Q7383611</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h4>Ruxolitinib_Polepally2026_PD_sv</h4><p>The steady-state exposure-response curve of Polepally AR et al., <i>CPT: pharmacometrics &amp; systems pharmacology 15(5):e70260</i> 2026 (<a href=\"https://doi.org/10.1002/psp4.70260\">doi:10.1002/psp4.70260</a>) — spleen volume against ruxolitinib mg/L — obtained by sweeping the driver instead of simulating a dose. Model family: indirect_response_i.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = (library default) drug-free response (baseline)
  Emax  = (library default) maximal effect term
  EC50  =     0.0597 mg/L     exposure at half of the maximal effect term (Ruxolitinib EC50, Q321)
  gamma = (library default) Hill coefficient</pre><p>The algebra is <code>response = E0*(1 - Emax*frac)</code>; this model only supplies the numbers. The x axis is one mg/L of ruxolitinib per second of simulated time (exposure is in kg/m3): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0   (drug-free)
  exposure = EC50 (0.0597 mg/L)  response 0
  exposure -> infinity  response 0</pre></body></html>"));
end Ruxolitinib_Polepally2026_PD_sv;
