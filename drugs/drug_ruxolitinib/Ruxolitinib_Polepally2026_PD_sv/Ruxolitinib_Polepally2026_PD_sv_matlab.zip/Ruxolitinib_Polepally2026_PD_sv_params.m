function p = Ruxolitinib_Polepally2026_PD_sv_params()
% Ruxolitinib_Polepally2026_PD_sv_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% ruxolitinib Polepally_2026::SV: indirect_response_i exposure-response sweep (response = E0*(1 - Emax*frac)). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one mg/L per second, in SI inside (kg/m3, s). Response SV in its own unit. Driver: ruxolitinib (pk_record).
p.E0 = 0.0;
p.Emax = 1.0;
p.EC50 = 5.9699999999999994e-05;
p.gamma = 1.0;
p.slope = 0.0;
p.exposure_per_s = 0.001;
p.stop_time = 0.6;
p.form = 'E0*(1 - Emax*frac)';
end
