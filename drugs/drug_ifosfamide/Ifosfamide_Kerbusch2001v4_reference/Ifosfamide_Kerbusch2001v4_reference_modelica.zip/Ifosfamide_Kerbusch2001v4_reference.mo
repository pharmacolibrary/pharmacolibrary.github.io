model Ifosfamide_Kerbusch2001v4_reference
  parameter Real Cl_ref = 8.416666666666666e-07 "Cl [m3/s]";
  parameter Real Vd_ref = 0.044 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.26108600000000004,
    adminMass = 1e-05
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About ifosfamide</h4><p>Ifosfamide is an alkylating anticancer drug used to treat various cancers, including sarcomas, lymphomas, and cancers of the breast, ovary, stomach, pancreas, and testis. It is an approved medicine and is included on the WHO list of essential medicines, so it is used widely in cancer care.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q418560\">Wikidata Q418560</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>ifosfamide</td></tr><tr><td>population:</td><td>patients with soft tissue sarcoma</td></tr><tr><td>source_paper:</td><td>Kerbusch_2001_4</td></tr><tr><td>measured_compound:</td><td>ifosfamide</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>ifosfamide 261.086 g/mol (drugbank)</td></tr></table><h4>Interpretation flags</h4><ul><li>dropped PD-category row '50% maximum induction' → Q321 (EC50, category G11) — pharmacodynamic parameters belong to scholarpd, not the PK model (source ['Kerbusch_2001_4:abstract'])</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=ifosfamide</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 259200, Tolerance = 1e-9, Interval = 1));
end Ifosfamide_Kerbusch2001v4_reference;
