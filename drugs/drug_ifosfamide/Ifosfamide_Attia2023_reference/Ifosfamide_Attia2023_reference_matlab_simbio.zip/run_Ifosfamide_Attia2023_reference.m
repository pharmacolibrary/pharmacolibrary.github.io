% Run (SimBiology): build model + dose, simulate 0..1008.0 h, plot.
p = Ifosfamide_Attia2023_reference_params();
[model, dose, variant] = build_sb_pk(p);
sd = simulate_sb(model, variant, dose, 1008.0);
