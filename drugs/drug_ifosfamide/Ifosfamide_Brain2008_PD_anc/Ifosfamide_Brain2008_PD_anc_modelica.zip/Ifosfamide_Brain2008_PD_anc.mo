model Ifosfamide_Brain2008_PD_anc
  "linear exposure-response sweep — Brain_2008 :: ANC (absolute neutrophil count)"
  extends Pharmacolibrary.Interfaces.PartialExposureResponseSweep(
    E0 = 4490,      // [mm-3]
    Emax = 0, EC50 = 1,      // unused by a line
    exposure_per_s = 1);
  parameter Real slope = 0.014   "[meter ** 3 / mole; l mmol-1 × 1]";
equation
  response = E0 + slope*exposure;
  // family_inferred: the record's model family is transduction; read from the parameters: a slope and no Emax — linear
  annotation(experiment(StartTime = 0, StopTime = 1000, Interval = 2),
    Documentation(info = "<html><body><!-- drug-about --><h4>About ifosfamide</h4><p>Ifosfamide is an alkylating anticancer drug used to treat various cancers, including sarcomas, lymphomas, and cancers of the breast, ovary, stomach, pancreas, and testis. It is an approved medicine and is included on the WHO list of essential medicines, so it is used widely in cancer care.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q418560\">Wikidata Q418560</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h4>Ifosfamide_Brain2008_PD_anc</h4><p>The steady-state exposure-response curve of Brain EG et al., <i>British journal of clinical pharmacology 65(4):607–610</i> 2008 (<a href=\"https://doi.org/10.1111/j.1365-2125.2007.03095.x\">doi:10.1111/j.1365-2125.2007.03095.x</a>) — absolute neutrophil count [mm-3] against ifosfamide mmol l-1 — obtained by sweeping the driver instead of simulating a dose. Model family: linear.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    =       4490 mm-3     drug-free response (baseline) (baseline count, Q324)
  slope =      0.014 l mmol-1 change in response per unit of exposure (SLOPEIF, Q335)</pre><p>The algebra is <code>response = E0 + slope*exposure</code>; this model only supplies the numbers. The x axis is one mmol l-1 of ifosfamide per second of simulated time (exposure is in mol/m3): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 4490   (drug-free)</pre></body></html>"));
end Ifosfamide_Brain2008_PD_anc;
