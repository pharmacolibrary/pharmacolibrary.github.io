function p = Ifosfamide_Brain2008_PD_anc_params()
% Ifosfamide_Brain2008_PD_anc_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% ifosfamide Brain_2008::ANC: linear exposure-response sweep (response = E0 + slope*exposure). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one mmol l-1 per second, in SI inside (kg/m3, s). Response ANC in mm-3. Driver: ifosfamide (pk_record).
p.E0 = 4490.0;
p.Emax = 0.0;
p.EC50 = 1.0;
p.gamma = 1.0;
p.slope = 0.014000000000000004;
p.exposure_per_s = 1.0;
p.stop_time = 1000.0;
p.form = 'E0 + slope*exposure';
end
