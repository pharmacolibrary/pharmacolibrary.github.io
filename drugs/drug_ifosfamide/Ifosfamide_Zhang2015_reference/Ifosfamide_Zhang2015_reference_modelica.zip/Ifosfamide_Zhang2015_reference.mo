model Ifosfamide_Zhang2015_reference
  parameter Real Cl_ref = 1.4722222222222223e-08 "Cl [m3/s]";
  parameter Real Vd_ref = 0.01824 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.26108600000000004,
    adminMass = 0.0001,
    ka = 0.0001388888888888889,
    Tlag = 0.0,
    k12 = 2.619395711500975e-07,
    k21 = 9.277238403451995e-06
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About ifosfamide</h4><p>Ifosfamide is an alkylating anticancer drug used to treat various cancers, including sarcomas, lymphomas, and cancers of the breast, ovary, stomach, pancreas, and testis. It is an approved medicine and is included on the WHO list of essential medicines, so it is used widely in cancer care.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q418560\">Wikidata Q418560</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>ifosfamide</td></tr><tr><td>population:</td><td>review reference</td></tr><tr><td>source_paper:</td><td>Zhang_2015</td></tr><tr><td>measured_compound:</td><td>ifosfamide</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_2C_enteral: apparent (/F) parameterization ⇒ extravascular dosing</td></tr><tr><td>molar_masses:</td><td>ifosfamide 261.086 g/mol (drugbank)</td></tr></table><p><b>Defaulted (base-class default used):</b> ka, Tlag.</p><h4>Interpretation flags</h4><ul><li>built from REVIEW reference values (Zhang_2015) — secondary source</li><li>volume reported by review</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 4838400, Tolerance = 1e-9, Interval = 1));
end Ifosfamide_Zhang2015_reference;
