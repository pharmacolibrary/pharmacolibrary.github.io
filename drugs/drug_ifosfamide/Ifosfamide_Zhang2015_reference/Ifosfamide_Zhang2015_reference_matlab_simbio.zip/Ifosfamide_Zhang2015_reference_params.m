function p = Ifosfamide_Zhang2015_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: ifosfamide   source: Zhang_2015 / reference   route: oral
  % estimated (absent from source): ka, dose
  p.name  = 'Ifosfamide_Zhang2015_reference_params';
  p.drug  = 'ifosfamide';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 18.24;                % central volume [L]
  p.CL = 0.053;                % clearance [L/h]
  p.Vp = [0.515];             % peripheral volumes [L]
  p.Q  = [0.0172];             % inter-compartmental clearances [L/h]
  p.ka = 0.5;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 100.0;             % dose [mg]
end
