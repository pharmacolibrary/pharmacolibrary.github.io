function p = Halofantrine_Klein2012_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: halofantrine   source: Klein_2012 / reference   route: oral
  % estimated (absent from source): ka
  p.name  = 'Halofantrine_Klein2012_reference_params';
  p.drug  = 'halofantrine';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 2386.0;                % central volume [L]
  p.CL = 102.208333;                % clearance [L/h]
  p.Vp = [2641.0];             % peripheral volumes [L]
  p.Q  = [29.833333];             % inter-compartmental clearances [L/h]
  p.ka = 0.5;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 1500.0;             % dose [mg]
end
