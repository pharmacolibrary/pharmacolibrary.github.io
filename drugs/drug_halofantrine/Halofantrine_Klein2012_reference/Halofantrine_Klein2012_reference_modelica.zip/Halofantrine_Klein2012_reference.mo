model Halofantrine_Klein2012_reference
  parameter Real Cl_ref = 2.8391203703703702e-05 "Cl [m3/s]";
  parameter Real Vd_ref = 2.386 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.500424,
    adminMass = 0.0015,
    ka = 0.0001388888888888889,
    Tlag = 0.0,
    k12 = 3.473192387693645e-06,
    k21 = 3.1378406047092154e-06
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About halofantrine</h4><p>Halofantrine is an antimalarial drug used to treat malaria caused by Plasmodium falciparum and Plasmodium vivax. It is no longer in general use, having been withdrawn, largely because of safety concerns about heart rhythm disturbances.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q947595\">Wikidata Q947595</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>halofantrine</td></tr><tr><td>population:</td><td>healthy volunteers and patients with symptomatic falciparum malaria</td></tr><tr><td>source_paper:</td><td>Klein_2012</td></tr><tr><td>measured_compound:</td><td>halofantrine</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_2C_enteral: apparent (/F) parameterization ⇒ extravascular dosing</td></tr><tr><td>molar_masses:</td><td>halofantrine 500.424 g/mol (drugbank)</td></tr></table><p><b>Defaulted (base-class default used):</b> ka, Tlag.</p><h4>Interpretation flags</h4><ul><li>apparent-ness (ontology-grounded): parameterization=apparent, measured_compound=halofantrine</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 345600, Tolerance = 1e-9, Interval = 1));
end Halofantrine_Klein2012_reference;
