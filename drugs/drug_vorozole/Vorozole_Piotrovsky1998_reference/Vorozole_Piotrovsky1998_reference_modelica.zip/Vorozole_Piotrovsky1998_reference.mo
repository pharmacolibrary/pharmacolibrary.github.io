model Vorozole_Piotrovsky1998_reference
  parameter Real Cl_ref = 1.3333333333333332e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.0301 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.32477,
    adminMass = 1e-05,
    k12 = 1.5688445921004063e-06,
    k21 = 1.0540674603174602e-06
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About vorozole</h4><p>Vorozole is an aromatase inhibitor studied as an anticancer (antineoplastic) agent. It remains experimental and does not appear to be an approved medicine on the market.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q7941876\">Wikidata Q7941876</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>vorozole</td></tr><tr><td>population:</td><td>healthy volunteers and breast cancer patients</td></tr><tr><td>source_paper:</td><td>Piotrovsky_1998</td></tr><tr><td>measured_compound:</td><td>vorozole</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_2C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>vorozole 324.77 g/mol (drugbank)</td></tr></table><h4>Interpretation flags</h4><ul><li>dropped duplicate Q22 ('CL (healthy volunteers)', value 8.6) — already have one for this compound</li><li>covariate age for CL from footnote/prose kept as documentation only (['Piotrovsky_1998:abstract'])</li><li>unit_dimension_unknown: 'l h(-1) kg(-1)' (Q)</li><li>dropped duplicate Q64 ('Vp (men)', value 0.4) — already have one for this compound</li><li>routed 'unexplained variability in CL' → Q312 (IIV) to iiv — variability estimate, not a structural parameter</li><li>implicit units: 'Q (WT coefficient)' → L/h (from the popPK convention: 'Parameter Q is defined as Apparent intercompartmental clearance. In population pharmacokinetics, intercompartmental clea')</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=vorozole</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Vorozole_Piotrovsky1998_reference;
