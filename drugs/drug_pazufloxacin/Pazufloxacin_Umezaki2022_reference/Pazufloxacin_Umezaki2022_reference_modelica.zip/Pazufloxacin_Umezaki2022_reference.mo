model Pazufloxacin_Umezaki2022_reference
  parameter Real Cl_ref = 5.555555555555555e-07 "Cl [m3/s]";
  parameter Real Vd_ref = 0.058800000000000005 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.318304,
    adminMass = 0.000175
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About pazufloxacin</h4><p>Pazufloxacin is a fluoroquinolone antibacterial that has been investigated as an antituberculous drug. It is not an approved medicine in major markets such as the European Union and remains investigational.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q3898423\">Wikidata Q3898423</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>pazufloxacin</td></tr><tr><td>population:</td><td>infected neutropenic mice</td></tr><tr><td>source_paper:</td><td>Umezaki_2022</td></tr><tr><td>measured_compound:</td><td>pazufloxacin</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>antibiotics-11-00982-t001</td></tr><tr><td>input:</td><td>PK_1C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>pazufloxacin 318.304 g/mol (drugbank)</td></tr></table><h4>Interpretation flags</h4><ul><li>column 'dosing regimen (mg/kg)' classified 'other' by the LLM but kept: the deterministic diagnostic-column test disagrees (a stratum column is a value column, not a statistic)</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=pazufloxacin</li><li>gap-filled Q22 (CL) from Umezaki_2022's review values (primary lacked it)</li><li>gap-filled Q61 (V) from Umezaki_2022's review values (primary lacked it)</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 432000, Tolerance = 1e-9, Interval = 1));
end Pazufloxacin_Umezaki2022_reference;
