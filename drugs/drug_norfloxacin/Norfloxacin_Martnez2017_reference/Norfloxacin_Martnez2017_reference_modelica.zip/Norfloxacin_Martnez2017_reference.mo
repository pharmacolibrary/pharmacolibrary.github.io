model Norfloxacin_Martnez2017_reference
  parameter Real Cl_ref = 3.694444444444445e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.1652 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.3193308,
    adminMass = 1e-05
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About norfloxacin</h4><p>Norfloxacin is a fluoroquinolone antibiotic used to treat bacterial infections, including urinary tract infections, gonorrhea, prostatitis, and eye infections such as conjunctivitis. It is an approved medicine, available as an oral antibacterial and also as an ophthalmic preparation, though it is not authorised in the European Union.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q417897\">Wikidata Q417897</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>norfloxacin</td></tr><tr><td>population:</td><td>review reference</td></tr><tr><td>source_paper:</td><td>Martínez_2017</td></tr><tr><td>measured_compound:</td><td>norfloxacin</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>norfloxacin 319.331 g/mol (drugbank)</td></tr></table><h4>Interpretation flags</h4><ul><li>built from REVIEW reference values (Martínez_2017) — secondary source</li><li>volume reported by review</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 158400, Tolerance = 1e-9, Interval = 1));
end Norfloxacin_Martnez2017_reference;
