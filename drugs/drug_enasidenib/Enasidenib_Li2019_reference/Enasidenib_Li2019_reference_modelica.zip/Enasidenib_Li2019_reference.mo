model Enasidenib_Li2019_reference
  parameter Real Cl_ref = 1.0891203703703704e-07 "Cl [m3/s]";
  parameter Real Vd_ref = 0.09770000000000001 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.473383,
    adminMass = 3e-05,
    ka = 0.00025613425925925923,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About enasidenib</h4><p>Enasidenib is an anticancer medicine, an IDH inhibitor, used to treat acute myeloid leukemia. It is an approved drug, though it has no European Union authorisation recorded, and remains investigational for some uses.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q27077182\">Wikidata Q27077182</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>enasidenib</td></tr><tr><td>population:</td><td>subjects with advanced hematologic malignancies with an IDH2 mutation</td></tr><tr><td>source_paper:</td><td>Li_2019</td></tr><tr><td>measured_compound:</td><td>enasidenib</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>t2-cpaa-11-039</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>enasidenib 473.383 g/mol (drugbank)</td></tr></table><p><b>Defaulted (base-class default used):</b> Tlag.</p><h4>Interpretation flags</h4><ul><li>routed 'δ2' → Q315 (sigma) to residual_error — variability estimate, not a structural parameter</li><li>implicit units: 'Ka (1/day)' → 1/day (from the paper text: 'The paper states: &quot;model predicted absorption rate constant of 22.10/day&quot;')</li><li>apparent-ness (ontology-grounded): parameterization=apparent, measured_compound=enasidenib</li><li>skipped review gap-fill of V2: primary is PARENT_METABOLITE (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is PARENT_METABOLITE (peripheral family needs ≥2C)</li><li>skipped review gap-fill of TLAG: primary's parameterization (rate-constant / ka-only) does not use it</li><li>engineer: parent_metabolite composite downgraded to a 1C model of the measured compound — the paper reports the metabolite's own CL and V but neither the parent's disposition nor a formation rate, so the parent sub-component could not be populated; the parent's concentration-time course is NOT produced by this model</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 3628800, Tolerance = 1e-9, Interval = 1));
end Enasidenib_Li2019_reference;
