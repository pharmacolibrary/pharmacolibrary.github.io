model Enasidenib_Li2019_PD_4_hydroxycholesterol_cholesterol_ratio
  "indirect_response_iii exposure-response sweep — Li_2019 :: 4β-hydroxycholesterol/cholesterol ratio (4β-hydroxycholesterol/cholesterol ratio)"
  extends Pharmacolibrary.Interfaces.PartialExposureResponseSweep(
    E0 = 0,      // [1]
    Emax = 7.36,  // type III effect term
    EC50 = 0.0314,  // [kg/m3; ng/mL × 1e-06]
    gamma = 1,
    exposure_per_s = 1e-06);   // 1 ng/mL per second
equation
  response = E0*(1 + Emax*frac);   // steady state, indirect response type III
  // defaulted: E0
  // defaulted: gamma
  annotation(experiment(StartTime = 0, StopTime = 320000, Interval = 640),
    Documentation(info = "<html><body><!-- drug-about --><h4>About enasidenib</h4><p>Enasidenib is an anticancer medicine, an IDH inhibitor, used to treat acute myeloid leukemia. It is an approved drug, though it has no European Union authorisation recorded, and remains investigational for some uses.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q27077182\">Wikidata Q27077182</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h4>Enasidenib_Li2019_PD_4_hydroxycholesterol_cholesterol_ratio</h4><p>The steady-state exposure-response curve of Li Y et al., <i>Clinical pharmacology : advances and applications 11:39–50</i> 2019 (<a href=\"https://doi.org/10.2147/CPAA.S192687\">doi:10.2147/CPAA.S192687</a>) — 4β-hydroxycholesterol/cholesterol ratio against enasidenib ng/mL — obtained by sweeping the driver instead of simulating a dose. Model family: indirect_response_iii.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = (library default) drug-free response (baseline)
  Emax  =       7.36          maximal effect term (Emax, Q320)
  EC50  =      31400 ng/mL    exposure at half of the maximal effect term (EC50, Q321)
  gamma = (library default) Hill coefficient</pre><p>The algebra is <code>response = E0*(1 + Emax*frac)</code>; this model only supplies the numbers. The x axis is one ng/mL of enasidenib per second of simulated time (exposure is in kg/m3): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0   (drug-free)
  exposure = EC50 (31400 ng/mL)  response 0
  exposure -> infinity  response 0</pre></body></html>"));
end Enasidenib_Li2019_PD_4_hydroxycholesterol_cholesterol_ratio;
