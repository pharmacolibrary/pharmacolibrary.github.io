function p = Enasidenib_Li2019_PD_4_hydroxycholesterol_cholesterol_ratio_params()
% Enasidenib_Li2019_PD_4_hydroxycholesterol_cholesterol_ratio_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% enasidenib Li_2019::4_hydroxycholesterol_cholesterol_ratio: indirect_response_iii exposure-response sweep (response = E0*(1 + Emax*frac)). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one ng/mL per second, in SI inside (kg/m3, s). Response 4β-hydroxycholesterol/cholesterol ratio in its own unit. Driver: enasidenib (pk_record).
p.E0 = 0.0;
p.Emax = 7.36;
p.EC50 = 0.0314;
p.gamma = 1.0;
p.slope = 0.0;
p.exposure_per_s = 1e-06;
p.stop_time = 320000.0;
p.form = 'E0*(1 + Emax*frac)';
end
