model Cefotaxime_Trang1985_dctx
  parameter Real Cl_ref = 5.619444444444444e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.02527 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.45546499999999995,
    adminMass = 0.0035
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About cefotaxime</h4><p>Cefotaxime is a third-generation cephalosporin antibiotic used to treat bacterial infections such as sepsis, meningitis, pneumonia, gonorrhea, and urinary tract infections. It is an approved, widely used antibiotic and is included on the WHO list of essential medicines.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q417968\">Wikidata Q417968</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>cefotaxime</td></tr><tr><td>population:</td><td>infants and children with meningitis</td></tr><tr><td>source_paper:</td><td>Trang_1985</td></tr><tr><td>measured_compound:</td><td>cefotaxime</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>tab_2</td></tr><tr><td>input:</td><td>PK_1C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>cefotaxime 455.465 g/mol (drugbank)</td></tr></table><h4>Interpretation flags</h4><ul><li>dropped unlinked row (NIL): 'Mean ± SDᵃ U (mg)' — extend the ontology if this is a real PK parameter (source ['Trang_1985_table_2:row0:col2'])</li><li>unit_dimension_unknown: 'liter/h per kg' (CLR)</li><li>dropped value-less row: 'K, c'</li><li>NIL: refused to back-fill base 'V' from footnote/prose loose number 0.361 (source ['tab_2:footnote']); the table cell was unparseable — needs review</li><li>salvaged Q61 ('apparent steady-state volume of distribution'=0.361) from results prose — parameter table was unreadable</li><li>salvaged Q22 ('total body clearance'=0.289) from results prose — parameter table was unreadable</li><li>implicit units: 'Mean ± SDᵃ CLᴿ (liter/h per kg)' → L/h/kg (from the paper text: &quot;The paper text explicitly states: 'the estimated renal clearance was 0.174 liter/h per kg'. The Discussion section also &quot;)</li><li>implicit units: 'total body clearance' → L/h/kg (from the paper text: &quot;The paper text explicitly states: 'total body clearance were 0.8 h, 0.361 liter/kg, and 0.289 liter/h per kg, respective&quot;)</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=cefotaxime</li><li>held at status:extracted — NIL link or unit issue (mismatch/unknown/normalisation-failed) present</li><li>status held at route_to_review — not promoted</li><li>population split: 'dctx' subgroup of Trang_1985 (paper reports 3 populations: dctx, model-dependent, noncompartmental)</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Cefotaxime_Trang1985_dctx;
