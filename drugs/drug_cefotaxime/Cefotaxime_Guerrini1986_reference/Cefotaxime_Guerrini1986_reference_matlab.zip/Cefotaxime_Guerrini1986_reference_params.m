function p = Cefotaxime_Guerrini1986_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: cefotaxime   source: Guerrini_1986 / reference   route: iv_bolus
  % Vc is the record's Vss — no central volume was reported; 1-compartment reading
  p.name  = 'Cefotaxime_Guerrini1986_reference_params';
  p.drug  = 'cefotaxime';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'iv_bolus';        % 'oral' | 'iv_bolus'
  p.depot = false;             % oral -> first-order absorption depot
  p.Vc = 33.6;                % central volume [L]
  p.CL = 44.1;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.0;                % absorption rate [1/h]
  p.F  = 0.865;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 4000.0;             % dose [mg]
end
