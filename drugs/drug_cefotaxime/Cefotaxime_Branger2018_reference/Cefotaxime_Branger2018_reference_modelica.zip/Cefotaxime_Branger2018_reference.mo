model Cefotaxime_Branger2018_reference
  parameter Real Cl_ref = 2.694444444444444e-07 "Cl [m3/s]";
  parameter Real Vd_ref = 0.020999999999999998 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.45546499999999995,
    adminMass = 0.004
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About cefotaxime</h4><p>Cefotaxime is a third-generation cephalosporin antibiotic used to treat bacterial infections such as sepsis, meningitis, pneumonia, gonorrhea, and urinary tract infections. It is an approved, widely used antibiotic and is included on the WHO list of essential medicines.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q417968\">Wikidata Q417968</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>cefotaxime</td></tr><tr><td>population:</td><td>critically ill children</td></tr><tr><td>source_paper:</td><td>Béranger_2018</td></tr><tr><td>measured_compound:</td><td>cefotaxime</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>cefotaxime 455.465 g/mol (drugbank); desacetylcefotaxime 413.423 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=cefotaxime</li><li>topology: transfer parameter unlinked (Q100) — add Kfm/formation-rate/rate-constant to the ontology; routing to review</li><li>template fit: none — noncompartmental model — not a compartmental parent–metabolite model</li><li>status held at route_to_review — not promoted</li><li>row roles (LLM): model_class=noncompartmental; 3/3 row label(s) assigned, 0 linked by role; re-tagged cefotaxime→parent ×2, cefotaxime→desacetylcefotaxime ×1</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li><li>skipped review gap-fill of V2: primary is PARENT_METABOLITE (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is PARENT_METABOLITE (peripheral family needs ≥2C)</li><li>engineer: parent → metabolite not buildable on PK_3M_9C (None) — the measured compound's 1-compartment model instead</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 345600, Tolerance = 1e-9, Interval = 1));
end Cefotaxime_Branger2018_reference;
