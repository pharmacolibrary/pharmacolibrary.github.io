function p = Oxcarbazepine_Faison2020_PD_pch_2_params()
% Oxcarbazepine_Faison2020_PD_pch_2_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% oxcarbazepine Faison_2020::PCH::2: log_linear exposure-response sweep (response = E0 + slope*log(exposure)). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one µmol/L per second, in SI inside (kg/m3, s). Response PCH in its own unit. Driver: monohydroxy derivative (pk_record).
p.E0 = 0.0;
p.Emax = 0.0;
p.EC50 = 1.0;
p.gamma = 1.0;
p.slope = -0.007164;
p.exposure_per_s = 0.001;
p.stop_time = 1000.0;
p.form = 'E0 + slope*log(exposure)';
end
