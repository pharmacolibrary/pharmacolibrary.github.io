model Oxcarbazepine_Faison2020_PD_pch_4
  "log_linear exposure-response sweep — Faison_2020 :: PCH (percent change from baseline 28-day seizure frequency)"
  extends Pharmacolibrary.Interfaces.PartialExposureResponseSweep(
    E0 = 0,      // [1]
    Emax = 0, EC50 = 1,      // unused by a line
    exposure_per_s = 0.001);
  parameter Real slope = -0.00427   "[1]";
equation
  response = E0 + slope*log(exposure);
  // defaulted: E0
  annotation(experiment(StartTime = 0, StopTime = 1000, Interval = 2),
    Documentation(info = "<html><body><!-- drug-about --><h4>About oxcarbazepine</h4><p>Oxcarbazepine is an anticonvulsant used to treat epilepsy, especially focal seizures, and has also been used for trigeminal neuralgia and mood disorders. It is an approved medicine in general use, though it has also been studied for other investigational purposes.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q176301\">Wikidata Q176301</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h4>Oxcarbazepine_Faison2020_PD_pch_4</h4><p>The steady-state exposure-response curve of Faison S et al., <i>Clinical pharmacology : advances and applications 12:135–147</i> 2020 (<a href=\"https://doi.org/10.2147/CPAA.S256972\">doi:10.2147/CPAA.S256972</a>) — percent change from baseline 28-day seizure frequency against monohydroxy derivative µmol/L — obtained by sweeping the driver instead of simulating a dose. Model family: log_linear.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = (library default) drug-free response (baseline)
  slope =   -0.00427          change in response per unit of exposure (slope, Q335)</pre><p>The algebra is <code>response = E0 + slope*log(exposure)</code>; this model only supplies the numbers. The x axis is one µmol/L of monohydroxy derivative per second of simulated time (exposure is in mol/m3): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p></body></html>"));
end Oxcarbazepine_Faison2020_PD_pch_4;
