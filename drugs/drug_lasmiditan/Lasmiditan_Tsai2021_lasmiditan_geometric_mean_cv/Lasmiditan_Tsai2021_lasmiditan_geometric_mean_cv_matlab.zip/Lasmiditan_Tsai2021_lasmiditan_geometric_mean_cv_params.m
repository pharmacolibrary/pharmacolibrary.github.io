function p = Lasmiditan_Tsai2021_lasmiditan_geometric_mean_cv_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: lasmiditan   source: Tsai_2021 / lasmiditan_geometric_mean_cv   route: oral
  p.name  = 'Lasmiditan_Tsai2021_lasmiditan_geometric_mean_cv_params';
  p.drug  = 'lasmiditan';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 261.0;                % central volume [L]
  p.CL = 48.9;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.295;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 100.0;             % dose [mg]
end
