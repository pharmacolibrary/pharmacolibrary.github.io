% Run (SimBiology): build model + dose, simulate 0..29.0 h, plot.
p = Lasmiditan_Tsai2021_lasmiditan_geometric_mean_cv_params();
[model, dose, variant] = build_sb_pk(p);
sd = simulate_sb(model, variant, dose, 29.0);
