model Lasmiditan_Tsai2021_lasmiditan_geometric_mean_cv
  parameter Real Cl_ref = 1.3583333333333333e-05 "Cl [m3/s]";
  parameter Real Vd_ref = 0.261 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.377367,
    adminMass = 0.0001,
    ka = 8.194444444444444e-05,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About lasmiditan</h4><p>Lasmiditan is an antimigraine drug used to treat migraine attacks. It is an approved selective serotonin agonist and has been authorised in the European Union.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q6493750\">Wikidata Q6493750</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>lasmiditan</td></tr><tr><td>population:</td><td>pediatric patients with migraine</td></tr><tr><td>source_paper:</td><td>Tsai_2021</td></tr><tr><td>measured_compound:</td><td>lasmiditan</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>Tab3</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>lasmiditan 377.367 g/mol (drugbank)</td></tr></table><p><b>Defaulted (base-class default used):</b> Tlag.</p><h4>Interpretation flags</h4><ul><li>dropped unlinked row (NIL): 'Cohort 1: 100 mg [n = 11][15 to ≤ 40 kg]' — extend the ontology if this is a real PK parameter (source ['Tsai_2021_table_2:row0:col1'])</li><li>dropped unlinked row (NIL): 'Vss/F, L' — extend the ontology if this is a real PK parameter (source ['Tsai_2021_table_2:row8:col1'])</li><li>apparent-ness (ontology-grounded): parameterization=apparent, measured_compound=lasmiditan</li><li>population split: 'lasmiditan geometric mean (cv%)' subgroup of Tsai_2021 (paper reports 2 populations: lasmiditan geometric mean (cv%), population mean (%see))</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li><li>gap-filled Q49 (kabs) from Tsai_2021's review values (primary lacked it)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 104400, Tolerance = 1e-9, Interval = 1));
end Lasmiditan_Tsai2021_lasmiditan_geometric_mean_cv;
