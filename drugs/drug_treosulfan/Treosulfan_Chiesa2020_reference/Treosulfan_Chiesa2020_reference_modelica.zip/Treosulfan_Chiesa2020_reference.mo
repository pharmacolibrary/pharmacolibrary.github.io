model Treosulfan_Chiesa2020_reference
  parameter Real Cl_ref = 4.808333333333333e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.03555 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.27829000000000004,
    adminMass = 1e-05,
    k12 = 7.313642756680732e-05,
    k21 = 0.000262891809908999
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About treosulfan</h4><p>Treosulfan is an alkylating anticancer drug used as conditioning treatment before hematopoietic stem cell transplantation. It is authorised in the European Union and is also being investigated for other uses.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q7838652\">Wikidata Q7838652</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>treosulfan</td></tr><tr><td>population:</td><td>pediatric patients with hematological diseases (allogeneic HSCT)</td></tr><tr><td>source_paper:</td><td>Chiesa_2020</td></tr><tr><td>measured_compound:</td><td>treosulfan</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>cpt1715-tbl-0002</td></tr><tr><td>input:</td><td>PK_2C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>treosulfan 278.29 g/mol (drugbank)</td></tr></table><h4>Interpretation flags</h4><ul><li>table section iiv: 'Covariance of CL + V' routed out of structural estimates ('IIV %CV (%RSE)')</li><li>dropped unlinked row (NIL): 'θa (postmenstrual age in weeks at 50% mature)' — extend the ontology if this is a real PK parameter (source ['cpt1715-tbl-0002:row7:col1'])</li><li>dropped unlinked row (NIL): 'θc (creatinine power)' — extend the ontology if this is a real PK parameter (source ['cpt1715-tbl-0002:row9:col1'])</li><li>covariate effect for Q900 has no base parameter row (kept as unattached equation-variable)</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=treosulfan</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Treosulfan_Chiesa2020_reference;
