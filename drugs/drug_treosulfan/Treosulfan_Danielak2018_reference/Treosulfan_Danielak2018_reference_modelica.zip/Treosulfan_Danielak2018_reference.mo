model Treosulfan_Danielak2018_reference
  parameter Real Cl_ref = 4.083333333333333e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.026000000000000002 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.27829000000000004,
    adminMass = 1e-05,
    k12 = 2.403846153846154e-05,
    k21 = 6.294058408862036e-05
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About treosulfan</h4><p>Treosulfan is an alkylating anticancer drug used as conditioning treatment before hematopoietic stem cell transplantation. It is authorised in the European Union and is also being investigated for other uses.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q7838652\">Wikidata Q7838652</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>treosulfan</td></tr><tr><td>population:</td><td>pediatric patients</td></tr><tr><td>source_paper:</td><td>Danielak_2018</td></tr><tr><td>measured_compound:</td><td>treosulfan</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>Tab2</td></tr><tr><td>input:</td><td>PK_2C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>treosulfan 278.29 g/mol (drugbank)</td></tr></table><h4>Interpretation flags</h4><ul><li>table section iiv: 'ωCl' routed out of structural estimates ('IIV [%]')</li><li>table section iiv: 'ωV1' routed out of structural estimates ('IIV [%]')</li><li>table section iiv: 'ωQ' routed out of structural estimates ('IIV [%]')</li><li>table section iiv: 'ωCl-V1' routed out of structural estimates ('IIV [%]')</li><li>table section iiv: 'Residual proportional error' routed out of structural estimates ('IIV [%]')</li><li>dropped duplicate Q22 ('βCl, weight', value '0.75') — already have one for this compound</li><li>dropped duplicate Q63 ('βV1, weight', value '1') — already have one for this compound</li><li>dropped duplicate Q64 ('βV2, weight', value '1') — already have one for this compound</li><li>dropped value-less row: 'Table 2. Final estimates of pharmacokinetic parameters'</li><li>dropped value-less row: 'RSE'</li><li>dropped value-less row: 'CI'</li><li>dropped value-less row: 'Cl'</li><li>dropped value-less row: 'V 1'</li><li>dropped value-less row: 'Q'</li><li>dropped value-less row: 'V 2'</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=treosulfan</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Treosulfan_Danielak2018_reference;
