model Treosulfan_van2019_base
  parameter Real Cl_ref = 1.6500000000000003e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.0007700000000000001 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.27829000000000004,
    adminMass = 1e-05,
    k12 = 0.008874458874458873,
    k21 = 0.0007827415043909889
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About treosulfan</h4><p>Treosulfan is an alkylating anticancer drug used as conditioning treatment before hematopoietic stem cell transplantation. It is authorised in the European Union and is also being investigated for other uses.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q7838652\">Wikidata Q7838652</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>treosulfan</td></tr><tr><td>population:</td><td>paediatric patients undergoing hematopoietic stem cell transplantation</td></tr><tr><td>source_paper:</td><td>van_2019</td></tr><tr><td>measured_compound:</td><td>treosulfan</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>bcp13995-tbl-0002</td></tr><tr><td>input:</td><td>PK_2C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>treosulfan 278.29 g/mol (drugbank)</td></tr></table><h4>Interpretation flags</h4><ul><li>table section iiv: 'Cl (CV%)' routed out of structural estimates ('Interindividual variability')</li><li>table section iiv: 'Cl (CV%)' routed out of structural estimates ('Interindividual variability')</li><li>table section iiv: 'Cl (CV%)' routed out of structural estimates ('Interindividual variability')</li><li>table section iiv: 'V1 (CV%)' routed out of structural estimates ('Interindividual variability')</li><li>table section iiv: 'V1 (CV%)' routed out of structural estimates ('Interindividual variability')</li><li>table section iiv: 'V1 (CV%)' routed out of structural estimates ('Interindividual variability')</li><li>table section iiv: 'V2 (CV%)' routed out of structural estimates ('Interindividual variability')</li><li>table section iiv: 'V2 (CV%)' routed out of structural estimates ('Interindividual variability')</li><li>table section iiv: 'V2 (CV%)' routed out of structural estimates ('Interindividual variability')</li><li>table section iiv: 'Q (CV%)' routed out of structural estimates ('Interindividual variability')</li><li>table section iiv: 'Q (CV%)' routed out of structural estimates ('Interindividual variability')</li><li>table section iiv: 'Q (CV%)' routed out of structural estimates ('Interindividual variability')</li><li>table section iov: 'Cl (CV%)' routed out of structural estimates ('Interoccasion variability')</li><li>table section iov: 'Cl (CV%)' routed out of structural estimates ('Interoccasion variability')</li><li>table section iov: 'Cl (CV%)' routed out of structural estimates ('Interoccasion variability')</li><li>table section residual_error: 'σ (proportional error)' routed out of structural estimates ('Residual variability')</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Treosulfan_van2019_base;
