model Treosulfan_Ten2014_reference
  parameter Real Cl_ref = 1.9027777777777778e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.0132 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.27829000000000004,
    adminMass = 1e-05
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About treosulfan</h4><p>Treosulfan is an alkylating anticancer drug used as conditioning treatment before hematopoietic stem cell transplantation. It is authorised in the European Union and is also being investigated for other uses.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q7838652\">Wikidata Q7838652</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>treosulfan</td></tr><tr><td>population:</td><td>pediatric patients</td></tr><tr><td>source_paper:</td><td>Ten_2014</td></tr><tr><td>measured_compound:</td><td>treosulfan</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>treosulfan 278.29 g/mol (drugbank)</td></tr></table><h4>Interpretation flags</h4><ul><li>dropped unlinked row (NIL): 'weight' — extend the ontology if this is a real PK parameter (source ['Ten_2014:abstract'])</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=treosulfan</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Treosulfan_Ten2014_reference;
