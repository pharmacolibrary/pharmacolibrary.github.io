model Candesartan_Kassem2021_final_model
  parameter Real Cl_ref = 2.3972222222222225e-06 "Cl [m3/s]";
  parameter Real cov_weight_0 = 0 "weight covariate";
  parameter Real cov_egfr_1 = 0 "egfr covariate";
  parameter Real Vd_ref = 0.0125 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref*(1 + (0.963)*cov_weight_0)*(1 + (0.56)*cov_egfr_1),
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.440454,
    adminMass = 4e-06,
    ka = 3.638888888888889e-05,
    Tlag = 594.0
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About candesartan</h4><p>Candesartan is an angiotensin II receptor antagonist used mainly to treat high blood pressure and congestive heart failure. DrugBank currently lists it as investigational, so its availability as an approved medicine is unclear from the available facts.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q415970\">Wikidata Q415970</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>candesartan</td></tr><tr><td>population:</td><td>patients with chronic heart failure</td></tr><tr><td>source_paper:</td><td>Kassem_2021</td></tr><tr><td>measured_compound:</td><td>candesartan</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>tab_1</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>candesartan 440.454 g/mol (drugbank)</td></tr></table><h4>Interpretation flags</h4><ul><li>table section iiv: 'ω 2' routed out of structural estimates ('Interindividual variability')</li><li>table section residual_error: 'σ 2' routed out of structural estimates ('Residual variability')</li><li>table section residual_error: 'σ 2' routed out of structural estimates ('Residual variability')</li><li>dropped duplicate Q27 ('Diabetes effect on CL/F -θ7', value '0.682') — already have one for this compound</li><li>apparent-ness (ontology-grounded): parameterization=apparent, measured_compound=candesartan</li><li>population split: 'final model' subgroup of Kassem_2021 (paper reports 2 populations: estimates, final model)</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 100800, Tolerance = 1e-9, Interval = 1));
end Candesartan_Kassem2021_final_model;
