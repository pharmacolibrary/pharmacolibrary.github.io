function p = Candesartan_Kassem2021_final_model_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: candesartan   source: Kassem_2021 / final_model   route: oral
  p.name  = 'Candesartan_Kassem2021_final_model_params';
  p.drug  = 'candesartan';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 12.5;                % central volume [L]
  p.CL = 8.63;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.131;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.165;             % absorption lag [h]
  p.dose = 4.0;             % dose [mg]
end
