model Acepromazine_Steagall2026_reference
  parameter Real Cl_ref = 6.066666666666667e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.12865954374647778 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.326456,
    adminMass = 0.0001,
    ka = 0.0001388888888888889,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About acepromazine</h4><p>Acepromazine is a phenothiazine antipsychotic and dopamine antagonist. It is approved for veterinary use and remains investigational in humans, so it is not used in routine human medicine.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q425097\">Wikidata Q425097</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>acepromazine</td></tr><tr><td>population:</td><td>review reference</td></tr><tr><td>source_paper:</td><td>Steagall_2026</td></tr><tr><td>measured_compound:</td><td>acepromazine</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C_enteral: apparent (/F) parameterization ⇒ extravascular dosing</td></tr><tr><td>molar_masses:</td><td>acepromazine 326.456 g/mol (drugbank)</td></tr></table><p><b>Defaulted (base-class default used):</b> ka, Tlag.</p><h4>Interpretation flags</h4><ul><li>built from REVIEW reference values (Steagall_2026) — secondary source</li><li>central volume derived from CL·t½/ln2</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Acepromazine_Steagall2026_reference;
