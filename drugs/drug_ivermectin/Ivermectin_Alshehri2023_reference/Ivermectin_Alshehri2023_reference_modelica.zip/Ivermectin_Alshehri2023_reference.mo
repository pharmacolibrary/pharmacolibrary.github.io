model Ivermectin_Alshehri2023_reference
  parameter Real Cl_ref = 1.95e-06 "Cl [m3/s]";
  parameter Real cov_sex_0 = 0 "sex covariate";
  parameter Real Vd_ref = 0.138 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref*(1 + (-0.74)*cov_sex_0),
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 1.7361849999999999,
    adminMass = 1.4e-05,
    ka = 0.00019722222222222222,
    Tlag = 2700.0,
    k12 = 1.8337359098228662e-05,
    k21 = 5.963649884654763e-06
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About ivermectin</h4><p>Ivermectin is an antiparasitic medicine used against infections such as scabies, lice infestation, onchocerciasis, strongyloidiasis, ascariasis, filariasis and rosacea. It is widely used in humans and also approved for veterinary use, and is included on the WHO list of essential medicines.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q415178\">Wikidata Q415178</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>ivermectin</td></tr><tr><td>population:</td><td>Wuchereria bancrofti-infected and uninfected adults in Côte d’Ivoire</td></tr><tr><td>source_paper:</td><td>Alshehri_2023</td></tr><tr><td>measured_compound:</td><td>ivermectin</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>pntd.0011319.t002</td></tr><tr><td>input:</td><td>PK_2C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>ivermectin 1736.18 g/mol (drugbank)</td></tr></table><h4>Interpretation flags</h4><ul><li>table section residual_error: 'Additive residual error (ng/mL)' routed out of structural estimates ('Residual variability')</li><li>table section residual_error: 'Proportional residual error' routed out of structural estimates ('Residual variability')</li><li>dropped unlinked row (NIL): 'Tk0 (h)' — extend the ontology if this is a real PK parameter (source ['pntd.0011319.t002:row7:col1'])</li><li>covariate level 'Sex (male) on Vp/F' → Q900:sex_male_on_vp_f = -0.74 (linear_fractional on Q27)</li><li>dropped duplicate Q27 ('CL/F', value '0.25') — already have one for this compound</li><li>dropped duplicate Q69 ('Q/F', value '0.19') — already have one for this compound</li><li>dropped duplicate Q290 ('Vc/F', value '0.23') — already have one for this compound</li><li>dropped duplicate Q82 ('Vp /F', value '0.17') — already have one for this compound</li><li>dropped duplicate Q83 ('Tlag', value '0.35') — already have one for this compound</li><li>dropped unlinked row (NIL): 'Tk0' — extend the ontology if this is a real PK parameter (source ['pntd.0011319.t002:row16:col1', 'pntd.0011319.t002:row16:col3'])</li><li>dropped duplicate Q49 ('Ka', value '0.55') — already have one for this compound</li><li>implicit units: 'Ka (1/h)' → 1/h (from the paper text: &quot;The paper text explicitly states: 'Estimates of mean population values for Vc/F, CL/F, Q/F, Ka, TK0, and Tlag were 138 l&quot;)</li><li>apparent-ness (ontology-grounded): parameterization=apparent, measured_compound=ivermectin</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 345600, Tolerance = 1e-9, Interval = 1));
end Ivermectin_Alshehri2023_reference;
