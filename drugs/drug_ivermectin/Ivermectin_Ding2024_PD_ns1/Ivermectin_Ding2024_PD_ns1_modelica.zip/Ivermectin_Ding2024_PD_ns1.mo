model Ivermectin_Ding2024_PD_ns1
  "indirect_response_i exposure-response sweep — Ding_2024 :: NS1 (dengue non-structural protein 1)"
  extends Pharmacolibrary.Interfaces.PartialExposureResponseSweep(
    E0 = 0,      // [1]
    Emax = 0.99,  // type I effect term
    EC50 = 6.75e-05,  // [kg/m3; ng/mL × 1e-06]
    gamma = 1,
    exposure_per_s = 1e-06);   // 1 ng/mL per second
equation
  response = E0*(1 - Emax*frac);   // steady state, indirect response type I
  // defaulted: E0
  // defaulted: gamma
  annotation(experiment(StartTime = 0, StopTime = 680, Interval = 1.36),
    Documentation(info = "<html><body><!-- drug-about --><h4>About ivermectin</h4><p>Ivermectin is an antiparasitic medicine used against infections such as scabies, lice infestation, onchocerciasis, strongyloidiasis, ascariasis, filariasis and rosacea. It is widely used in humans and also approved for veterinary use, and is included on the WHO list of essential medicines.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q415178\">Wikidata Q415178</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h4>Ivermectin_Ding2024_PD_ns1</h4><p>The steady-state exposure-response curve of Ding J et al., <i>CPT: pharmacometrics &amp; systems pharmacology 13(12):2196–2209</i> 2024 (<a href=\"https://doi.org/10.1002/psp4.13233\">doi:10.1002/psp4.13233</a>) — dengue non-structural protein 1 [ng/mL] against ivermectin ng/mL — obtained by sweeping the driver instead of simulating a dose. Model family: indirect_response_i.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = (library default) drug-free response (baseline)
  Emax  =       0.99          maximal effect term (Maximum effect of ivermectin on E max,NS1, Q323)
  EC50  =       67.5 ng/mL    exposure at half of the maximal effect term (EC50 of ivermectin concentration (ng/mL) on E max,NS1, Q322)
  gamma = (library default) Hill coefficient</pre><p>The algebra is <code>response = E0*(1 - Emax*frac)</code>; this model only supplies the numbers. The x axis is one ng/mL of ivermectin per second of simulated time (exposure is in kg/m3): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0   (drug-free)
  exposure = EC50 (67.5 ng/mL)  response 0
  exposure -> infinity  response 0</pre></body></html>"));
end Ivermectin_Ding2024_PD_ns1;
