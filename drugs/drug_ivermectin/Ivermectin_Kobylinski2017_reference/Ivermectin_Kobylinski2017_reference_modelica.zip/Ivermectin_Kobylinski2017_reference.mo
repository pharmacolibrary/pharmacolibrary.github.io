model Ivermectin_Kobylinski2017_reference
  parameter Real Cl_ref = 2.505555555555556e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.115 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 1.7361849999999999,
    adminMass = 1.4e-05,
    ka = 8.805555555555556e-05,
    Tlag = 0.0,
    k12 = 3.913043478260869e-05,
    k21 = 2.8662420382165606e-05
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About ivermectin</h4><p>Ivermectin is an antiparasitic medicine used against infections such as scabies, lice infestation, onchocerciasis, strongyloidiasis, ascariasis, filariasis and rosacea. It is widely used in humans and also approved for veterinary use, and is included on the WHO list of essential medicines.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q415178\">Wikidata Q415178</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>ivermectin</td></tr><tr><td>population:</td><td>healthy Thai volunteers</td></tr><tr><td>source_paper:</td><td>Kobylinski_2017</td></tr><tr><td>measured_compound:</td><td>ivermectin</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>Tab1</td></tr><tr><td>input:</td><td>PK_2C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>ivermectin 1736.18 g/mol (drugbank)</td></tr></table><p><b>Defaulted (base-class default used):</b> Tlag.</p><h4>Interpretation flags</h4><ul><li>table section iiv: 'F' routed out of structural estimates ('IIV [%CV] (%RSE)b')</li><li>table section iiv: 'MTT (h)' routed out of structural estimates ('IIV [%CV] (%RSE)b')</li><li>table section iiv: 'CL/F (l/h)' routed out of structural estimates ('IIV [%CV] (%RSE)b')</li><li>table section iiv: 'VP/F (l)' routed out of structural estimates ('IIV [%CV] (%RSE)b')</li><li>apparent-ness (ontology-grounded): parameterization=apparent, measured_compound=ivermectin</li><li>skipped review gap-fill of TLAG: primary's parameterization (rate-constant / ka-only) does not use it</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 259200, Tolerance = 1e-9, Interval = 1));
end Ivermectin_Kobylinski2017_reference;
