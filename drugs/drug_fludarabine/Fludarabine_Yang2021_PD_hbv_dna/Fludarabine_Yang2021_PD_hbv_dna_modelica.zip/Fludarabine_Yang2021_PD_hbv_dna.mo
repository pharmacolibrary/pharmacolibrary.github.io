model Fludarabine_Yang2021_PD_hbv_dna
  "emax exposure-response sweep — Yang_2021 :: HBV DNA (HBV progeny DNA)"
  extends Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep(
    E0 = 0,      // [1]
    Emax = -0.96,  // [1; % × 0.01]
    EC50 = 0.1,  // [μM]
    gamma = 1,
    exposure_per_s = 1);   // 1 μM per second
  // imax_as_negative_emax: Imax (Q323) enters SigmoidEmaxSweep as −Emax
  // exposure_unit_unresolved: 'μM' — the x axis is in the paper's unit, not SI
  // defaulted: E0
  // defaulted: gamma
  annotation(experiment(StartTime = 0, StopTime = 1, Interval = 0.002),
    Documentation(info = "<html><body><!-- drug-about --><h4>About fludarabine</h4><p>Fludarabine is a purine analogue anticancer drug used to treat certain blood cancers such as chronic lymphocytic leukaemia. It is an approved medicine and is also being studied for other uses.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q72478349\">Wikidata Q72478349</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h4>Fludarabine_Yang2021_PD_hbv_dna</h4><p>The steady-state exposure-response curve of Yang J et al., <i>JHEP reports : innovation in hepatology 3(4):100296</i> 2021 (<a href=\"https://doi.org/10.1016/j.jhepr.2021.100296\">doi:10.1016/j.jhepr.2021.100296</a>) — HBV progeny DNA against fludarabine μM — obtained by sweeping the driver instead of simulating a dose. Model family: emax.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = (library default) drug-free response (baseline)
  Emax  =         96 %        maximal effect term (Imax, Q323)
  EC50  =        0.1 μM       exposure at half of the maximal effect term (EC50, Q322)
  gamma = (library default) Hill coefficient</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep\">SigmoidEmaxSweep</a>; this model only supplies the numbers. The x axis is one μM of fludarabine per second of simulated time: there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0   (drug-free)
  exposure = EC50 (0.1 μM)  response -0.48
  exposure -> infinity  response -0.96</pre></body></html>"));
end Fludarabine_Yang2021_PD_hbv_dna;
