function p = Fludarabine_Yang2021_PD_hbv_dna_params()
% Fludarabine_Yang2021_PD_hbv_dna_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% fludarabine Yang_2021::HBV_DNA: emax exposure-response sweep (response = E0 + Emax*frac). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one μM per second, in SI inside (kg/m3, s). Response HBV DNA in its own unit. Driver: fludarabine (cited_pk).
p.E0 = 0.0;
p.Emax = -0.96;
p.EC50 = 0.1;
p.gamma = 1.0;
p.slope = 0.0;
p.exposure_per_s = 1.0;
p.stop_time = 1.0;
p.form = 'E0 + Emax*frac';
end
