% Run (SimBiology): build model + dose, simulate 0..2352.0 h, plot.
p = Eculizumab_Monteleone2021_median_params();
[model, dose, variant] = build_sb_pk(p);
sd = simulate_sb(model, variant, dose, 2352.0);
