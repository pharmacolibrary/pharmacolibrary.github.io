model Eculizumab_Monteleone2021_mean
  parameter Real Cl_ref = 2.9444444444444445e-09 "Cl [m3/s]";
  parameter Real Vd_ref = 0.00254 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    adminMass = 0.0009,
    k12 = 2.744969378827647e-05,
    k21 = 2.5539275539275543e-05
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About eculizumab</h4><p>Eculizumab, a monoclonal antibody that inhibits complement, is used to treat conditions such as paroxysmal nocturnal hemoglobinuria, myasthenia gravis, and hemolytic-uremic syndrome. It is authorised in the European Union, where it is used for rare blood and immune-related disorders.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q421617\">Wikidata Q421617</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>eculizumab</td></tr><tr><td>population:</td><td>adults with refractory generalized myasthenia gravis</td></tr><tr><td>source_paper:</td><td>Monteleone_2021</td></tr><tr><td>measured_compound:</td><td>eculizumab</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>T1</td></tr><tr><td>input:</td><td>PK_2C: IV (no input phase)</td></tr></table><h4>Interpretation flags</h4><ul><li>dropped duplicate Q32 ('Cmax, ss (μg/ml)', value '845') — already have one for this compound</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=eculizumab</li><li>population split: 'mean' subgroup of Monteleone_2021 (paper reports 2 populations: mean, median)</li><li>molar mass: none found for 'eculizumab' — its concentrations stay mass-only</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 7862400, Tolerance = 1e-9, Interval = 1));
end Eculizumab_Monteleone2021_mean;
