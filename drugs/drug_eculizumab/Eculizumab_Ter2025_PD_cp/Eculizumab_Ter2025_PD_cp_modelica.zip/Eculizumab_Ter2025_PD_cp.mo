model Eculizumab_Ter2025_PD_cp
  "sigmoid_emax exposure-response sweep — Ter_2025 :: CP (classical pathway activity)"
  extends Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep(
    E0 = 1.12,      // [1; % × 0.01]
    Emax = -0.00967,  // [1; % × 0.01]
    EC50 = 0.022,  // [kg/m3; µg/mL × 0.001]
    gamma = 4.34,
    exposure_per_s = 0.001);   // 1 µg/mL per second
  // imax_as_negative_emax: Imax (Q323) enters SigmoidEmaxSweep as −Emax
  annotation(experiment(StartTime = 0, StopTime = 220, Interval = 0.44),
    Documentation(info = "<html><body><!-- drug-about --><h4>About eculizumab</h4><p>Eculizumab, a monoclonal antibody that inhibits complement, is used to treat conditions such as paroxysmal nocturnal hemoglobinuria, myasthenia gravis, and hemolytic-uremic syndrome. It is authorised in the European Union, where it is used for rare blood and immune-related disorders.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q421617\">Wikidata Q421617</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h4>Eculizumab_Ter2025_PD_cp</h4><p>The steady-state exposure-response curve of Ter Avest M et al., <i>Clinical pharmacokinetics 64(8):1139–1147</i> 2025 (<a href=\"https://doi.org/10.1007/s40262-025-01536-x\">doi:10.1007/s40262-025-01536-x</a>) — classical pathway activity [%] against eculizumab µg/mL — obtained by sweeping the driver instead of simulating a dose. Model family: sigmoid_emax.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    =        112 %        drug-free response (baseline) (Baseline classical pathway activity (%), Q324)
  Emax  =      0.967 %        maximal effect term (Maximum inhibition (Imax), Q323)
  EC50  =         22 µg/mL    exposure at half of the maximal effect term (Concentration for 50% inhibition (IC50) (µg/mL), Q322)
  gamma =       4.34          Hill coefficient (Hill coefficient (γ), Q325)</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep\">SigmoidEmaxSweep</a>; this model only supplies the numbers. The x axis is one µg/mL of eculizumab per second of simulated time (exposure is in kg/m3): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 1.12   (drug-free)
  exposure = EC50 (22 µg/mL)  response 1.115
  exposure -> infinity  response 1.11</pre></body></html>"));
end Eculizumab_Ter2025_PD_cp;
