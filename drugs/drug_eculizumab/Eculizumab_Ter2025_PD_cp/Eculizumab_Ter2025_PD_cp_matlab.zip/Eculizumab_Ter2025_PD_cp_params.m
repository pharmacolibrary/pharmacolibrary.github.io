function p = Eculizumab_Ter2025_PD_cp_params()
% Eculizumab_Ter2025_PD_cp_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% eculizumab Ter_2025::CP: sigmoid_emax exposure-response sweep (response = E0 + Emax*frac). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one µg/mL per second, in SI inside (kg/m3, s). Response CP in %. Driver: eculizumab (pk_record).
p.E0 = 1.12;
p.Emax = -0.00967;
p.EC50 = 0.021999999999999995;
p.gamma = 4.34;
p.slope = 0.0;
p.exposure_per_s = 0.001;
p.stop_time = 220.0;
p.form = 'E0 + Emax*frac';
end
