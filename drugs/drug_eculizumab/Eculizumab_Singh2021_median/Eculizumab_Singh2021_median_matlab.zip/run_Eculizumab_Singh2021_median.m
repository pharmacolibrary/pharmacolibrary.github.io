% Run: build params, simulate 0..2352.0 h, plot + save Eculizumab_Singh2021_median.png/.csv/.json.
% Interactive display (keep the window open):  octave --persist run_Eculizumab_Singh2021_median.m
here = fileparts(mfilename('fullpath'));
p = Eculizumab_Singh2021_median_params();
out = simulate_pk(p, 0:0.05:2352.0);

% figure (shown on screen if interactive) and PNG (works in MATLAB and Octave)
fig = figure; plot(out.t, out.C, 'LineWidth', 1.5); grid on;
xlabel('time [h]'); ylabel('central concentration [mg/L]');
title('eculizumab — Singh_2021 (iv_bolus)');
print(fig, fullfile(here, 'Eculizumab_Singh2021_median.png'), '-dpng', '-r150');

% CSV (time_h, Cc_mg_per_L)
fid = fopen(fullfile(here, 'Eculizumab_Singh2021_median.csv'), 'w');
fprintf(fid, 'time_h,Cc_mg_per_L\n');
fprintf(fid, '%.10g,%.10g\n', [out.t(:), out.C(:)].');
fclose(fid);

% JSON (summary + arrays; jsonencode with a manual fallback for older versions)
fid = fopen(fullfile(here, 'Eculizumab_Singh2021_median.json'), 'w');
try
  s.model = 'Eculizumab_Singh2021_median'; s.Cmax = out.Cmax; s.Tmax = out.Tmax; s.AUC = out.AUC;
  s.time_h = out.t(:).'; s.Cc_mg_per_L = out.C(:).';
  fprintf(fid, '%s', jsonencode(s));
catch
  fprintf(fid, '{"model":"Eculizumab_Singh2021_median","Cmax":%g,"Tmax":%g,"AUC":%g}', out.Cmax, out.Tmax, out.AUC);
end
fclose(fid);

fprintf('Cmax=%.3g mg/L  Tmax=%.3g h  AUC=%.3g mg*h/L\n', out.Cmax, out.Tmax, out.AUC);
fprintf('wrote Eculizumab_Singh2021_median.png, Eculizumab_Singh2021_median.csv, Eculizumab_Singh2021_median.json\n');
