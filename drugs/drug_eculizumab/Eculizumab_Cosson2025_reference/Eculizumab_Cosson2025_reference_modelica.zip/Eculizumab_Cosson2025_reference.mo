model Eculizumab_Cosson2025_reference
  parameter Real Cl_ref = 9.155092592592594e-10 "Cl [m3/s]";
  parameter Real Vd_ref = 0.006059622137692235 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    adminMass = 6.4e-05
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About eculizumab</h4><p>Eculizumab, a monoclonal antibody that inhibits complement, is used to treat conditions such as paroxysmal nocturnal hemoglobinuria, myasthenia gravis, and hemolytic-uremic syndrome. It is authorised in the European Union, where it is used for rare blood and immune-related disorders.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q421617\">Wikidata Q421617</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>eculizumab</td></tr><tr><td>population:</td><td>review reference</td></tr><tr><td>source_paper:</td><td>Cosson_2025</td></tr><tr><td>measured_compound:</td><td>eculizumab</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C: IV (no input phase)</td></tr></table><h4>Interpretation flags</h4><ul><li>built from REVIEW reference values (Cosson_2025) — secondary source</li><li>central volume derived from CL·t½/ln2</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 15552000, Tolerance = 1e-9, Interval = 1));
end Eculizumab_Cosson2025_reference;
