model Eculizumab_Singh2021_mean
  parameter Real Cl_ref = 2.108333333333333e-09 "Cl [m3/s]";
  parameter Real Vd_ref = 0.00233 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    adminMass = 0.0009,
    k12 = 2.8373867429661416e-05,
    k21 = 3.1332280147446024e-05
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About eculizumab</h4><p>Eculizumab, a monoclonal antibody that inhibits complement, is used to treat conditions such as paroxysmal nocturnal hemoglobinuria, myasthenia gravis, and hemolytic-uremic syndrome. It is authorised in the European Union, where it is used for rare blood and immune-related disorders.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q421617\">Wikidata Q421617</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>eculizumab</td></tr><tr><td>population:</td><td>adults with neuromyelitis optica spectrum disorder</td></tr><tr><td>source_paper:</td><td>Singh_2021</td></tr><tr><td>measured_compound:</td><td>eculizumab</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>T2</td></tr><tr><td>input:</td><td>PK_2C: IV (no input phase)</td></tr></table><h4>Interpretation flags</h4><ul><li>dropped unlinked row (NIL): 'Accumulation ratio' — extend the ontology if this is a real PK parameter (source ['T2:row9:col1'])</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=eculizumab</li><li>population split: 'mean' subgroup of Singh_2021 (paper reports 2 populations: mean, median)</li><li>molar mass: none found for 'eculizumab' — its concentrations stay mass-only</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 4233600, Tolerance = 1e-9, Interval = 1));
end Eculizumab_Singh2021_mean;
