function p = Eculizumab_Singh2021_mean_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: eculizumab   source: Singh_2021 / mean   route: iv_bolus
  % estimated (absent from source): F
  p.name  = 'Eculizumab_Singh2021_mean_params';
  p.drug  = 'eculizumab';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'iv_bolus';        % 'oral' | 'iv_bolus'
  p.depot = false;             % oral -> first-order absorption depot
  p.Vc = 2.33;                % central volume [L]
  p.CL = 0.00759;                % clearance [L/h]
  p.Vp = [2.11];             % peripheral volumes [L]
  p.Q  = [0.238];             % inter-compartmental clearances [L/h]
  p.ka = 0.0;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 900.0;             % dose [mg]
end
