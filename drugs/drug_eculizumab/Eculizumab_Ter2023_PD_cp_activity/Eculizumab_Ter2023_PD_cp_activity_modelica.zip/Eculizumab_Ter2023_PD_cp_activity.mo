model Eculizumab_Ter2023_PD_cp_activity
  "sigmoid_emax exposure-response sweep — Ter_2023 :: CP activity (classical pathway activity)"
  extends Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep(
    E0 = 1.007,      // [1; % × 0.01]
    Emax = -0.0096,  // [1; % × 0.01]
    EC50 = 0.022,  // [kg/m3; mg/L × 0.001]
    gamma = 5.42,
    exposure_per_s = 0.001);   // 1 mg/L per second
  // imax_as_negative_emax: Imax (Q323) enters SigmoidEmaxSweep as −Emax
  annotation(experiment(StartTime = 0, StopTime = 220, Interval = 0.44),
    Documentation(info = "<html><body><!-- drug-about --><h4>About eculizumab</h4><p>Eculizumab, a monoclonal antibody that inhibits complement, is used to treat conditions such as paroxysmal nocturnal hemoglobinuria, myasthenia gravis, and hemolytic-uremic syndrome. It is authorised in the European Union, where it is used for rare blood and immune-related disorders.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q421617\">Wikidata Q421617</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h4>Eculizumab_Ter2023_PD_cp_activity</h4><p>The steady-state exposure-response curve of Ter Avest M et al., <i>Nephrology, dialysis, transplantation : official publication of the European Dialysis and Transplant Association - European Renal Association 38(2):362–371</i> 2023 (<a href=\"https://doi.org/10.1093/ndt/gfac056\">doi:10.1093/ndt/gfac056</a>) — classical pathway activity [%] against eculizumab mg/L — obtained by sweeping the driver instead of simulating a dose. Model family: sigmoid_emax.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    =      100.7 %        drug-free response (baseline) (Baseline CP activity, Q324)
  Emax  =       0.96 %        maximal effect term (Maximum inhibition, Q323)
  EC50  =         22 mg/L     exposure at half of the maximal effect term (Plasma IC50, Q322)
  gamma =       5.42          Hill coefficient (Hill coefficient, Q325)</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep\">SigmoidEmaxSweep</a>; this model only supplies the numbers. The x axis is one mg/L of eculizumab per second of simulated time (exposure is in kg/m3): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 1.007   (drug-free)
  exposure = EC50 (22 mg/L)  response 1.002
  exposure -> infinity  response 0.9974</pre></body></html>"));
end Eculizumab_Ter2023_PD_cp_activity;
