function p = Eculizumab_Ter2023_PD_cp_activity_params()
% Eculizumab_Ter2023_PD_cp_activity_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% eculizumab Ter_2023::CP_activity: sigmoid_emax exposure-response sweep (response = E0 + Emax*frac). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one mg/L per second, in SI inside (kg/m3, s). Response CP activity in %. Driver: eculizumab (pk_record).
p.E0 = 1.0070000000000001;
p.Emax = -0.0096;
p.EC50 = 0.021999999999999995;
p.gamma = 5.42;
p.slope = 0.0;
p.exposure_per_s = 0.001;
p.stop_time = 220.0;
p.form = 'E0 + Emax*frac';
end
