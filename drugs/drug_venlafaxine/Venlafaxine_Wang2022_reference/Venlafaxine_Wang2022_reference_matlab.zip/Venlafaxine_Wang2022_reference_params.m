function p = Venlafaxine_Wang2022_reference_params()
% Auto-generated parent-metabolite PK model (clinical units: mg, L, h).
%   drug: venlafaxine   source: Wang_2022 / reference   PK_3M_3C parent + 1 metabolite(s), 3 compartments, oral
%   dA/dt = K*A; C = A./V. K(i,j) is the rate [1/h] at which compartment j feeds i:
%   a metabolic conversion carries MW_dst/MW_src, so one molecule forms one molecule.
%   molar masses: C_central=277.402 g/mol C_M1=263.381 g/mol
  p.name  = 'Venlafaxine_Wang2022_reference_params';
  p.drug  = 'venlafaxine';
  p.kind  = 'network';
  p.template = 'PK_3M_3C';
  p.states = {'hepatic', 'central', 'central_M1'};
  p.V = [628.0, 628.0, 238.00000000000003];          % compartment volumes [L]
  p.K = [-0.2721337579617834, 0.143312101910828, 0.0;
         0.143312101910828, -0.143312101910828, 0.0;
         0.005870908106699818, 0.0, -0.09285714285714285];
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;
  p.dose_into = 1;   % hepatic
  p.ka = 0.63;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h] (in dose_start)
  p.dose = 50.0;             % dose [mg]
  p.dose_start = 0.016666666666666666;   % dose enters from [h] ...
  p.dose_duration = 0.16666666666666666;   % ... at a constant rate for [h]
  p.out_idx = [2.0, 3.0];
  p.out_names = {'C_central', 'C_M1'};
  p.out_labels = {'venlafaxine', 'O-desmethyl venlafaxine'};
end
