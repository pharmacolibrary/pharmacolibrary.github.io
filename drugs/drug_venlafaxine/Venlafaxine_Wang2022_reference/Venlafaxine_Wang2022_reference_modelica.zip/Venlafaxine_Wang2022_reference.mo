// parent + metabolites (O-desmethyl venlafaxine): PK_3M_3C — first-pass formation; parent 1 + hepatic, metabolites [1]
model Venlafaxine_Wang2022_reference
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_3M_3C(
    Vd1 = 0.628,
    Vd2 = 0.628,
    q12 = 2.4999999999999998e-05,
    q21 = 2.4999999999999998e-05,
    q1_m11 = 1.078666666666667e-06,
    CL1 = 2.139355555555556e-05,
    Vd1m1 = 0.23800000000000002,
    CLm1 = 6.138888888888889e-06,
    MW = 0.2774018,
    MW_m1 = 0.263381,
    F = 1,
    ka = 0.000175,
    Tlag = 0.0,
    adminDuration = 600,
    adminCount = 1,
    adminMass = 5e-05
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About venlafaxine</h4><p>Venlafaxine is an antidepressant (a serotonin–norepinephrine reuptake inhibitor) used for depression and anxiety-related conditions such as generalized anxiety disorder, social anxiety disorder, and panic-type anxiety disorders. It is an approved prescription medicine that is widely used, though it carries a boxed warning.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q898407\">Wikidata Q898407</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>venlafaxine</td></tr><tr><td>population:</td><td>healthy volunteers and psychiatric patients</td></tr><tr><td>source_paper:</td><td>Wang_2022</td></tr><tr><td>measured_compound:</td><td>venlafaxine</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>parent_metabolite</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>T2</td></tr><tr><td>input:</td><td>PK_3M_3C: absorption rate constant reported; hepatic volume not reported separately — set equal to the central volume (as Jung_2024 fixes Vc = VH); formation of O-desmethyl venlafaxine: fm=0.048 × CL; dose 50 mg (paper)</td></tr><tr><td>molar_masses:</td><td>O-desmethyl venlafaxine 263.381 g/mol (pubchem); venlafaxine 277.402 g/mol (drugbank)</td></tr></table><p><b>Defaulted (base-class default used):</b> q12/q21 (hepatic flow, 90 L/h), Tlag.</p><h4>Interpretation flags</h4><ul><li>table section iiv: 'CL/F' routed out of structural estimates ('Interindividual variability, %CV')</li><li>table section iiv: 'V/F' routed out of structural estimates ('Interindividual variability, %CV')</li><li>table section iiv: 'CLM/F' routed out of structural estimates ('Interindividual variability, %CV')</li><li>table section iiv: 'V M/F' routed out of structural estimates ('Interindividual variability, %CV')</li><li>table section residual_error: 'Proportional error on VEN' routed out of structural estimates ('Residual variability, % CV')</li><li>table section residual_error: 'Proportional error on ODV' routed out of structural estimates ('Residual variability, % CV')</li><li>dropped unlinked row (NIL): 'θmorbid state on CL/F' — extend the ontology if this is a real PK parameter (source ['T2:row7:col1'])</li><li>dropped duplicate Q27 ('θamisulpride on CL/F', value '0.392') — already have one for this compound</li><li>implicit units: 'θamisulpride on CLM/F' → L/h (from the paper text: &quot;The paper states 'The population-predicted clearance in healthy Chinese subjects was 81 L/h for VEN and 22 L/h for ODV' &quot;)</li><li>metabolite o-desmethyl venlafaxine: Q351→Q22 — the model states fm, so its CL/V are not fm-divided</li><li>apparent-ness (ontology-grounded): parameterization=apparent, measured_compound=venlafaxine</li><li>template fit: PK_3M_3C — first-pass formation; parent 1 + hepatic, metabolites [1] (site presystemic: 'Results and conclusion: Concentrations of VEN and ODV were well described with a one-compartment model incorporating fir')</li><li>row roles (LLM): model_class=compartmental; 15/15 row label(s) assigned, 6 linked by role; re-tagged parent→O-desmethyl venlafaxine ×7</li><li>skipped review gap-fill of V2: primary is PARENT_METABOLITE (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is PARENT_METABOLITE (peripheral family needs ≥2C)</li><li>skipped review gap-fill of TLAG: primary's parameterization (rate-constant / ka-only) does not use it</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 97200, Tolerance = 1e-9, Interval = 1));
end Venlafaxine_Wang2022_reference;
