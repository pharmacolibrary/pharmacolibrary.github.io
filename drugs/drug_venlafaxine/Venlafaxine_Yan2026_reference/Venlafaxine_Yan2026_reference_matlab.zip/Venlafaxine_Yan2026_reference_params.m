function p = Venlafaxine_Yan2026_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: venlafaxine   source: Yan_2026 / reference   route: oral
  % estimated (absent from source): ka
  p.name  = 'Venlafaxine_Yan2026_reference_params';
  p.drug  = 'venlafaxine';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 310.0;                % central volume [L]
  p.CL = 28.94;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.5;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 100.0;             % dose [mg]
end
