function p = Venlafaxine_Maringwa2025_PD_hamd_change_from_baseline_params()
% Venlafaxine_Maringwa2025_PD_hamd_change_from_baseline_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% venlafaxine Maringwa_2025::HAMD_change_from_baseline: emax exposure-response sweep (response = E0 + Emax*frac). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one mg/day per second, in SI inside (kg/m3, s). Response HAMD change from baseline in its own unit. Driver: venlafaxine (dose_only).
p.E0 = 0.0;
p.Emax = -1.75;
p.EC50 = 3.3680555555555554e-10;
p.gamma = 1.0;
p.slope = 0.0;
p.exposure_per_s = 1.15740740741e-11;
p.stop_time = 300.0;
p.form = 'E0 + Emax*frac';
end
