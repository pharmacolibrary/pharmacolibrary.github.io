model Venlafaxine_Maringwa2025_PD_hamd_change_from_baseline
  "emax exposure-response sweep — Maringwa_2025 :: HAMD change from baseline (Change from baseline in Hamilton Depression Rating (HAMD) scale at primary timepoint)"
  extends Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep(
    E0 = 0,      // [1]
    Emax = -1.75,  // [1]
    EC50 = 3.36805555556e-10,  // [kg/s; mg/day × 1.15741e-11]
    gamma = 1,
    exposure_per_s = 1.15740740741e-11);   // 1 mg/day per second
  // imax_as_negative_emax: Imax (Q323) enters SigmoidEmaxSweep as −Emax
  // defaulted: E0
  // defaulted: gamma
  annotation(experiment(StartTime = 0, StopTime = 300, Interval = 0.6),
    Documentation(info = "<html><body><!-- drug-about --><h4>About venlafaxine</h4><p>Venlafaxine is an antidepressant (a serotonin–norepinephrine reuptake inhibitor) used for depression and anxiety-related conditions such as generalized anxiety disorder, social anxiety disorder, and panic-type anxiety disorders. It is an approved prescription medicine that is widely used, though it carries a boxed warning.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q898407\">Wikidata Q898407</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h4>Venlafaxine_Maringwa2025_PD_hamd_change_from_baseline</h4><p>The steady-state exposure-response curve of Maringwa J et al., <i>Clinical pharmacology and therapeutics 117(1):153–161</i> 2025 (<a href=\"https://doi.org/10.1002/cpt.3418\">doi:10.1002/cpt.3418</a>) — Change from baseline in Hamilton Depression Rating (HAMD) scale at primary timepoint against venlafaxine mg/day — obtained by sweeping the driver instead of simulating a dose. Model family: emax.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = (library default) drug-free response (baseline)
  Emax  =      -1.75          maximal effect term (E max venlafaxine, Q323)
  EC50  =       29.1 mg/day   exposure at half of the maximal effect term (ED50 venlafaxine, Q321)
  gamma = (library default) Hill coefficient</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep\">SigmoidEmaxSweep</a>; this model only supplies the numbers. The x axis is one mg/day of venlafaxine per second of simulated time (exposure is in kg/s): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0   (drug-free)
  exposure = EC50 (29.1 mg/day)  response -0.875
  exposure -> infinity  response -1.75</pre></body></html>"));
end Venlafaxine_Maringwa2025_PD_hamd_change_from_baseline;
