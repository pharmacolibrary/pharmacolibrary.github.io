model Clonidine_Yocca2025_PD_arrestin
  "emax exposure-response sweep — Yocca_2025 :: β-arrestin (β-arrestin recruitment)"
  extends Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep(
    E0 = 0,      // [1]
    Emax = 0.93,  // [1; % × 0.01]
    EC50 = 13,  // [nM]
    gamma = 1,
    exposure_per_s = 1);   // 1 nM per second
  // exposure_unit_unresolved: 'nM' — the x axis is in the paper's unit, not SI
  // defaulted: E0
  // defaulted: gamma
  annotation(experiment(StartTime = 0, StopTime = 130, Interval = 0.26),
    Documentation(info = "<html><body><!-- drug-about --><h4>About clonidine</h4><p>Clonidine is a centrally acting alpha-2 agonist used to treat high blood pressure, and also for conditions such as glaucoma, ADHD, Tourette syndrome, spasticity, and hypersalivation. It remains an approved medicine in widespread use, though it carries a boxed warning.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q412221\">Wikidata Q412221</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h4>Clonidine_Yocca2025_PD_arrestin</h4><p>The steady-state exposure-response curve of Yocca FD et al., <i>Frontiers in pharmacology 16:1589075</i> 2025 (<a href=\"https://doi.org/10.3389/fphar.2025.1589075\">doi:10.3389/fphar.2025.1589075</a>) — β-arrestin recruitment against clonidine nM — obtained by sweeping the driver instead of simulating a dose. Model family: emax.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = (library default) drug-free response (baseline)
  Emax  =         93 %        maximal effect term (Max activity, Q320)
  EC50  =         13 nM       exposure at half of the maximal effect term (EC50, Q321)
  gamma = (library default) Hill coefficient</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep\">SigmoidEmaxSweep</a>; this model only supplies the numbers. The x axis is one nM of clonidine per second of simulated time: there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0   (drug-free)
  exposure = EC50 (13 nM)  response 0.465
  exposure -> infinity  response 0.93</pre></body></html>"));
end Clonidine_Yocca2025_PD_arrestin;
