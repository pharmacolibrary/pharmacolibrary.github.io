model Clonidine_Tang2021_reference
  parameter Real Cl_ref = 2.0833333333333333e-05 "Cl [m3/s]";
  parameter Real Vd_ref = 0.196 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.230094,
    adminMass = 4.5000000000000003e-07
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About clonidine</h4><p>Clonidine is a centrally acting alpha-2 agonist used to treat high blood pressure, and also for conditions such as glaucoma, ADHD, Tourette syndrome, spasticity, and hypersalivation. It remains an approved medicine in widespread use, though it carries a boxed warning.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q412221\">Wikidata Q412221</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>clonidine</td></tr><tr><td>population:</td><td>review reference</td></tr><tr><td>source_paper:</td><td>Tang_2021</td></tr><tr><td>measured_compound:</td><td>clonidine</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>clonidine 230.094 g/mol (drugbank)</td></tr></table><h4>Interpretation flags</h4><ul><li>built from REVIEW reference values (Tang_2021) — secondary source</li><li>volume reported by review</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Clonidine_Tang2021_reference;
