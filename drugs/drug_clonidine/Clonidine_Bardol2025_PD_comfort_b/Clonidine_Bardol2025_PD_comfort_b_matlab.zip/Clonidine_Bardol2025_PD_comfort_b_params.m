function p = Clonidine_Bardol2025_PD_comfort_b_params()
% Clonidine_Bardol2025_PD_comfort_b_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% clonidine Bardol_2025::COMFORT_B: sigmoid_emax exposure-response sweep (response = E0 + Emax*frac). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one ng/mL per second, in SI inside (kg/m3, s). Response COMFORT-B in its own unit. Driver: clonidine (pk_record).
p.E0 = 15.6;
p.Emax = -6.0;
p.EC50 = 2.7299999999999997e-06;
p.gamma = 1.0;
p.slope = 0.0;
p.exposure_per_s = 1e-06;
p.stop_time = 28.0;
p.form = 'E0 + Emax*frac';
end
