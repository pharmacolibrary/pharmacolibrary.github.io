model Clonidine_Bardol2025_PD_comfort_b
  "sigmoid_emax exposure-response sweep — Bardol_2025 :: COMFORT-B (COMFORT-B score)"
  extends Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep(
    E0 = 15.6,      // [1]
    Emax = -6,  // [fixed]
    EC50 = 2.73e-06,  // [kg/m3; ng/mL × 1e-06]
    gamma = 1,
    exposure_per_s = 1e-06);   // 1 ng/mL per second
  // inhibition_sign: effect_direction=inhibition with a positive Emax (Q320) — sign flipped
  // defaulted: gamma
  annotation(experiment(StartTime = 0, StopTime = 28, Interval = 0.056),
    Documentation(info = "<html><body><!-- drug-about --><h4>About clonidine</h4><p>Clonidine is a centrally acting alpha-2 agonist used to treat high blood pressure, and also for conditions such as glaucoma, ADHD, Tourette syndrome, spasticity, and hypersalivation. It remains an approved medicine in widespread use, though it carries a boxed warning.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q412221\">Wikidata Q412221</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h4>Clonidine_Bardol2025_PD_comfort_b</h4><p>The steady-state exposure-response curve of Bardol M et al., <i>Paediatric anaesthesia 35(12):1053–1062</i> 2025 (<a href=\"https://doi.org/10.1111/pan.70050\">doi:10.1111/pan.70050</a>) — COMFORT-B score against clonidine ng/mL — obtained by sweeping the driver instead of simulating a dose. Model family: sigmoid_emax.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    =       15.6          drug-free response (baseline) (B0, Q324)
  Emax  =          6 fixed    maximal effect term (maximum drug effect (Emax), Q320)
  EC50  =       2.73 ng/mL    exposure at half of the maximal effect term (EC50, Q321)
  gamma = (library default) Hill coefficient</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep\">SigmoidEmaxSweep</a>; this model only supplies the numbers. The x axis is one ng/mL of clonidine per second of simulated time (exposure is in kg/m3): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 15.6   (drug-free)
  exposure = EC50 (2.73 ng/mL)  response 12.6
  exposure -> infinity  response 9.6</pre></body></html>"));
end Clonidine_Bardol2025_PD_comfort_b;
