function p = Clonidine_Larsson2011_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: clonidine   source: Larsson_2011 / reference   route: iv_bolus
  p.name  = 'Clonidine_Larsson2011_reference_params';
  p.drug  = 'clonidine';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'iv_bolus';        % 'oral' | 'iv_bolus'
  p.depot = false;             % oral -> first-order absorption depot
  p.Vc = 5684.0;                % central volume [L]
  p.CL = 17.9;                % clearance [L/h]
  p.Vp = [7910.0];             % peripheral volumes [L]
  p.Q  = [121.0];             % inter-compartmental clearances [L/h]
  p.ka = 0.0;                % absorption rate [1/h]
  p.F  = 0.554;                 % bioavailability [0-1]
  p.Tlag = 0.148;             % absorption lag [h]
  p.dose = 0.45;             % dose [mg]
end
