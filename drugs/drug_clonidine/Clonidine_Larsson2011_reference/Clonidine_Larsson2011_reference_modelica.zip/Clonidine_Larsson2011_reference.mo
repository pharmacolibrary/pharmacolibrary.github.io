model Clonidine_Larsson2011_reference
  parameter Real Cl_ref = 4.9722222222222224e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 5.684 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.230094,
    adminMass = 4.5000000000000003e-07,
    k12 = 5.913284854171553e-06,
    k21 = 4.249192302289647e-06
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>clonidine</td></tr><tr><td>population:</td><td>children undergoing adenotonsillectomy</td></tr><tr><td>source_paper:</td><td>Larsson_2011</td></tr><tr><td>measured_compound:</td><td>clonidine</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_2C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>clonidine 230.094 g/mol (drugbank)</td></tr></table><h4>Interpretation flags</h4><ul><li>unit_dimension_unknown: 'l·h(-1) per 70 kg' (CL)</li><li>unit_dimension_unknown: 'l·h(-1) per 70 kg' (Q)</li><li>implicit units: 'Clearance (CL)' → L/h (from the popPK convention: 'No unit is stated in the provided text or table captions. For a total clearance (CL) with a value of 17.9, the standard ')</li><li>implicit units: 'between compartment clearance (Q)' → L/h (from the popPK convention: 'No unit is stated in the provided text or table captions. For an intercompartmental clearance (Q) with a value of 121, t')</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=clonidine</li><li>held at status:extracted — NIL link or unit issue (mismatch/unknown/normalisation-failed) present</li><li>status held at route_to_review — not promoted</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 4233600, Tolerance = 1e-9, Interval = 1));
end Clonidine_Larsson2011_reference;
