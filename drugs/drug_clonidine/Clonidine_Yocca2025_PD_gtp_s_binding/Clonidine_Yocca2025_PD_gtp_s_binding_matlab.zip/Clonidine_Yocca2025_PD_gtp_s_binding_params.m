function p = Clonidine_Yocca2025_PD_gtp_s_binding_params()
% Clonidine_Yocca2025_PD_gtp_s_binding_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% clonidine Yocca_2025::GTP_S_binding: emax exposure-response sweep (response = E0 + Emax*frac). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one nM per second, in SI inside (kg/m3, s). Response GTPγS binding in its own unit. Driver: clonidine (cited_pk).
p.E0 = 0.0;
p.Emax = 0.76;
p.EC50 = 25.0;
p.gamma = 1.0;
p.slope = 0.0;
p.exposure_per_s = 1.0;
p.stop_time = 250.0;
p.form = 'E0 + Emax*frac';
end
