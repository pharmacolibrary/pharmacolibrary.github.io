model HyaluronicAcid_Jeon2013_reference
  parameter Real Cl_ref = 3.3888888888888884e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.6910000000000001 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.7766486,
    adminMass = 0.0001,
    ka = 1.813888888888889e-06,
    Tlag = 308520.0
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About hyaluronic_acid</h4><p>Hyaluronic acid is a naturally occurring polysaccharide used to help wound healing, as a viscoelastic aid in eye surgery, in nasal preparations, and for joint (viscosupplement) treatment. It is widely used, with approved human and veterinary products, and is also being investigated for further uses.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q337231\">Wikidata Q337231</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>hyaluronic_acid</td></tr><tr><td>population:</td><td>review reference</td></tr><tr><td>source_paper:</td><td>Jeon_2013</td></tr><tr><td>measured_compound:</td><td>hyaluronic_acid</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>hyaluronic_acid 776.649 g/mol (drugbank)</td></tr></table><h4>Interpretation flags</h4><ul><li>built from REVIEW reference values (Jeon_2013) — secondary source</li><li>volume reported by review</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 2419200, Tolerance = 1e-9, Interval = 1));
end HyaluronicAcid_Jeon2013_reference;
