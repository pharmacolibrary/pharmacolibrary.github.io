model Ropivacaine_McCann2001_reference
  parameter Real Cl_ref = 1.1833333333333334e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.1659 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 0.9,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.2744011,
    adminMass = 0.0001,
    ka = 0.008888888888888889,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About ropivacaine</h4><p>Ropivacaine is a local anesthetic of the amide type used to numb an area of the body during procedures. It is an approved medicine and is widely used in clinical practice for regional anesthesia.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q279504\">Wikidata Q279504</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>ropivacaine</td></tr><tr><td>population:</td><td>infants and young children</td></tr><tr><td>source_paper:</td><td>McCann_2001</td></tr><tr><td>measured_compound:</td><td>ropivacaine</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>ropivacaine 274.401 g/mol (drugbank)</td></tr></table><p><b>Defaulted (base-class default used):</b> F, Tlag.</p><h4>Interpretation flags</h4><ul><li>unit_dimension_unknown: 'mL x min(-1) x kg(-1)' (CL)</li><li>unit_dimension_unknown: 'mL x min(-1) x kg(-1)' (CL)</li><li>dropped duplicate Q22 ('CL in young children', value 6.15) — already have one for this compound</li><li>implicit units: 'calculated clearance (CL) in infants' → L/h (from the popPK convention: 'In population pharmacokinetic modeling, total clearance (CL) is conventionally expressed in volume per time units. Given')</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=ropivacaine</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li><li>gap-filled Q49 (kabs) from Ling_2025's review values (primary lacked it)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 518400, Tolerance = 1e-9, Interval = 1));
end Ropivacaine_McCann2001_reference;
