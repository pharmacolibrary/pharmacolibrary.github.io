model Ropivacaine_Matsota2024_arterial
  parameter Real Cl_ref = 3.1746666666666665e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.16098332 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.2744011,
    adminMass = 2.8e-05,
    ka = 0.008888888888888889,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About ropivacaine</h4><p>Ropivacaine is a local anesthetic of the amide type used to numb an area of the body during procedures. It is an approved medicine and is widely used in clinical practice for regional anesthesia.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q279504\">Wikidata Q279504</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>ropivacaine</td></tr><tr><td>population:</td><td>adult patients undergoing open thoracotomy</td></tr><tr><td>source_paper:</td><td>Matsota_2024</td></tr><tr><td>measured_compound:</td><td>ropivacaine</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>joacp_353_22-t002</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>ropivacaine 274.401 g/mol (drugbank)</td></tr></table><p><b>Defaulted (base-class default used):</b> Tlag.</p><h4>Interpretation flags</h4><ul><li>dropped unlinked row (NIL): 'kb (min−1)' — extend the ontology if this is a real PK parameter (source ['joacp_353_22-t002:row4:col1', 'joacp_353_22-t002:row4:col2', 'joacp_353_22-t002:row4:col3', 'joacp_353_22-t002:row19:col1', 'joacp_353_22-t002:row19:col2', 'joacp_353_22-t002:row19:col3'])</li><li>dropped duplicate Q22 ('beta_Cl_Sex', value '-0.17') — already have one for this compound</li><li>routed 'corr_Vap_Cl' → Q314 (omega_cov) to covariance — variability estimate, not a structural parameter</li><li>dropped unlinked row (NIL): 'B' — extend the ontology if this is a real PK parameter (source ['joacp_353_22-t002:row14:col1', 'joacp_353_22-t002:row14:col2', 'joacp_353_22-t002:row14:col3', 'joacp_353_22-t002:row29:col1', 'joacp_353_22-t002:row29:col2', 'joacp_353_22-t002:row29:col3'])</li><li>implicit units: 'Vap (ml)a' → mL (from the paper text: &quot;The paper text explicitly states: 'The volume of distribution of the central compartment (Vap) was 160,983.32 ml...'&quot;)</li><li>implicit units: 'Cl (ml/min)a' → mL/min (from the paper text: &quot;The paper text explicitly states: 'The clearance estimates from the central compartment (Cl) were 190.48 and 183.03 ml/m&quot;)</li><li>apparent-ness (ontology-grounded): parameterization=apparent, measured_compound=ropivacaine</li><li>population split: 'arterial' subgroup of Matsota_2024 (paper reports 3 populations: arterial, from the entire profile, only from the single-bolus part)</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li><li>gap-filled Q49 (kabs) from Ling_2025's review values (primary lacked it)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 259200, Tolerance = 1e-9, Interval = 1));
end Ropivacaine_Matsota2024_arterial;
