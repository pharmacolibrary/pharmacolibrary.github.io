function p = Ropivacaine_Matsota2024_arterial_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: ropivacaine   source: Matsota_2024 / arterial   route: oral
  p.name  = 'Ropivacaine_Matsota2024_arterial_params';
  p.drug  = 'ropivacaine';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 160.98332;                % central volume [L]
  p.CL = 11.4288;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 32.0;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 28.0;             % dose [mg]
end
