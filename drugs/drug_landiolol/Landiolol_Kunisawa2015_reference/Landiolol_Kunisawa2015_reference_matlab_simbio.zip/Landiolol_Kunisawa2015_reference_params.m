function p = Landiolol_Kunisawa2015_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: landiolol   source: Kunisawa_2015 / reference   route: iv_bolus
  % estimated (absent from source): F, dose
  p.name  = 'Landiolol_Kunisawa2015_reference_params';
  p.drug  = 'landiolol';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'iv_bolus';        % 'oral' | 'iv_bolus'
  p.depot = false;             % oral -> first-order absorption depot
  p.Vc = 5.243;                % central volume [L]
  p.CL = 142.8;                % clearance [L/h]
  p.Vp = [2.723];             % peripheral volumes [L]
  p.Q  = [297.78];             % inter-compartmental clearances [L/h]
  p.ka = 0.0;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.010567;             % absorption lag [h]
  p.dose = 10.0;             % dose [mg]
end
