model Landiolol_Kunisawa2015_reference
  parameter Real Cl_ref = 3.966666666666667e-05 "Cl [m3/s]";
  parameter Real Vd_ref = 0.005243 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.5096,
    adminMass = 1e-05,
    k12 = 0.01577659101023587,
    k21 = 0.030377035132819197
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>landiolol</td></tr><tr><td>population:</td><td>gynecologic patients</td></tr><tr><td>source_paper:</td><td>Kunisawa_2015</td></tr><tr><td>measured_compound:</td><td>landiolol</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_2C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>landiolol 509.6 g/mol (drugbank)</td></tr></table><h4>Interpretation flags</h4><ul><li>apparent-by-design (ADVISORY, codes unchanged): extravascular dosing with no identifiable F, so these reported disposition parameters are likely apparent unless the model puts first-pass in its structure — Q22 (total body clearance (CL)); Q63 (distribution volume of the central compartment (V 1)); Q30 (inter-compartmental clearance (Q)); Q64 (distribution volume of the peripheral compartment (V 2))</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=landiolol</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Landiolol_Kunisawa2015_reference;
