model Landiolol_Kunisawa2015v2_reference
  parameter Real Cl_ref = 4.27e-05 "Cl [m3/s]";
  parameter Real Vd_ref = 0.00707 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.5096,
    adminMass = 1e-05,
    k12 = 0.0026567656765676567,
    k21 = 0.004826139088729017
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About landiolol</h4><p>Landiolol is a selective beta blocker with antiarrhythmic activity, used to control fast heart rhythms. It is an approved medicine, given by infusion in hospital settings, and is used mainly in Japan and some Asian countries rather than in the European Union.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q6484656\">Wikidata Q6484656</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>landiolol</td></tr><tr><td>population:</td><td>patients with peripheral arterial disease</td></tr><tr><td>source_paper:</td><td>Kunisawa_2015_2</td></tr><tr><td>measured_compound:</td><td>landiolol</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>tab_1</td></tr><tr><td>input:</td><td>PK_2C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>landiolol 509.6 g/mol (drugbank)</td></tr></table><h4>Interpretation flags</h4><ul><li>apparent-by-design (ADVISORY, codes unchanged): extravascular dosing with no identifiable F, so these reported disposition parameters are likely apparent unless the model puts first-pass in its structure — Q22 (TVCl (ml/min/kg)); Q63 (TVV 1 (ml/kg)); Q30 (TVQ (ml/min/kg)); Q64 (TVV 2 (ml/kg))</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=landiolol</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Landiolol_Kunisawa2015v2_reference;
