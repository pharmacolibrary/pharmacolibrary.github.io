function p = Landiolol_Honda2008_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: landiolol   source: Honda_2008 / reference   route: iv_bolus
  % estimated (absent from source): F, dose
  p.name  = 'Landiolol_Honda2008_reference_params';
  p.drug  = 'landiolol';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'iv_bolus';        % 'oral' | 'iv_bolus'
  p.depot = false;             % oral -> first-order absorption depot
  p.Vc = 7.07;                % central volume [L]
  p.CL = 153.72;                % clearance [L/h]
  p.Vp = [3.892];             % peripheral volumes [L]
  p.Q  = [67.62];             % inter-compartmental clearances [L/h]
  p.ka = 0.0;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.013667;             % absorption lag [h]
  p.dose = 10.0;             % dose [mg]
end
