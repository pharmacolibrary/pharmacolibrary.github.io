function p = Ornithine_Wang2022_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: ornithine   source: Wang_2022 / reference   route: oral
  % estimated (absent from source): ka
  p.name  = 'Ornithine_Wang2022_reference_params';
  p.drug  = 'ornithine';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 33.2;                % central volume [L]
  p.CL = 14.9;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.5;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 15000.0;             % dose [mg]
end
