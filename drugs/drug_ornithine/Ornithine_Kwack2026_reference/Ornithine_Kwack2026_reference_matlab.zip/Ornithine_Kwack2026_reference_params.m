function p = Ornithine_Kwack2026_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: ornithine   source: Kwack_2026 / reference   route: oral
  % estimated (absent from source): F, dose
  p.name  = 'Ornithine_Kwack2026_reference_params';
  p.drug  = 'ornithine';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 4.59;                % central volume [L]
  p.CL = 0.133;                % clearance [L/h]
  p.Vp = [13.2];             % peripheral volumes [L]
  p.Q  = [6.85];             % inter-compartmental clearances [L/h]
  p.ka = 0.545;                % absorption rate [1/h]
  p.F  = 0.9;                 % bioavailability [0-1]
  p.Tlag = 0.825;             % absorption lag [h]
  p.dose = 100.0;             % dose [mg]
end
