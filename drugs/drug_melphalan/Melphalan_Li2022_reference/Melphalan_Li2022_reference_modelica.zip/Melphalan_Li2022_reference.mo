model Melphalan_Li2022_reference
  parameter Real Cl_ref = 1.4855555555555557e-05 "Cl [m3/s]";
  parameter Real Vd_ref = 0.0238 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.30519999999999997,
    adminMass = 1e-05,
    k12 = 0.0004052287581699346,
    k21 = 0.0005938697318007664
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About melphalan</h4><p>Melphalan is an alkylating anticancer drug used mainly to treat multiple myeloma, and also other cancers such as ovarian and breast cancer and childhood tumours like neuroblastoma. It is an approved medicine, authorised in the European Union, and is also used in conditioning before stem cell transplantation.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q2298283\">Wikidata Q2298283</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>melphalan</td></tr><tr><td>population:</td><td>pediatric patients undergoing hematopoietic cell transplantation</td></tr><tr><td>source_paper:</td><td>Li_2022</td></tr><tr><td>measured_compound:</td><td>melphalan</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_2C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>melphalan 305.2 g/mol (drugbank)</td></tr></table><h4>Interpretation flags</h4><ul><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=melphalan</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Melphalan_Li2022_reference;
