function p = Melphalan_Li2022_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: melphalan   source: Li_2022 / reference   route: iv_bolus
  % estimated (absent from source): F, dose
  p.name  = 'Melphalan_Li2022_reference_params';
  p.drug  = 'melphalan';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'iv_bolus';        % 'oral' | 'iv_bolus'
  p.depot = false;             % oral -> first-order absorption depot
  p.Vc = 23.8;                % central volume [L]
  p.CL = 53.48;                % clearance [L/h]
  p.Vp = [16.24];             % peripheral volumes [L]
  p.Q  = [34.72];             % inter-compartmental clearances [L/h]
  p.ka = 0.0;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 10.0;             % dose [mg]
end
