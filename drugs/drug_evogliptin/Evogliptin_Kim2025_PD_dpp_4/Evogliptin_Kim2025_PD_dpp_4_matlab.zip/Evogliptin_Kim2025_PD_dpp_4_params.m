function p = Evogliptin_Kim2025_PD_dpp_4_params()
% Evogliptin_Kim2025_PD_dpp_4_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% evogliptin Kim_2025::DPP_4: sigmoid_emax exposure-response sweep (response = E0 + Emax*frac). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one μg/L per second, in SI inside (kg/m3, s). Response DPP-4 in %inhibition. Driver: evogliptin (pk_record).
p.E0 = 0.0;
p.Emax = -88.9;
p.EC50 = 1.0799999999999998e-06;
p.gamma = 2.14;
p.slope = 0.0;
p.exposure_per_s = 1e-06;
p.stop_time = 11.0;
p.form = 'E0 + Emax*frac';
end
