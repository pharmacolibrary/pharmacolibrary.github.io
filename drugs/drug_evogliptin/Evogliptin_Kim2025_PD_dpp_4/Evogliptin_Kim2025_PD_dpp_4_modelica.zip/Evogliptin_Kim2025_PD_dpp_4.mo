model Evogliptin_Kim2025_PD_dpp_4
  "sigmoid_emax exposure-response sweep — Kim_2025 :: DPP-4 (DPP-4 activity)"
  extends Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep(
    E0 = 0,      // [1]
    Emax = -88.9,  // [%inhibition]
    EC50 = 1.08e-06,  // [kg/m3; μg/L × 1e-06]
    gamma = 2.14,
    exposure_per_s = 1e-06);   // 1 μg/L per second
  // imax_as_negative_emax: Imax (Q323) enters SigmoidEmaxSweep as −Emax
  // defaulted: E0
  annotation(experiment(StartTime = 0, StopTime = 11, Interval = 0.022),
    Documentation(info = "<html><body><!-- drug-about --><h4>About evogliptin</h4><p>Evogliptin is a DPP-4 inhibitor studied for lowering blood glucose in diabetes. It is considered investigational and is not authorised in the European Union.</p><p><small>Summary written by glm-5.3-flash from <a href=&quot;https://www.wikidata.org/wiki/Q25103700&quot;>Wikidata Q25103700</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h4>Evogliptin_Kim2025_PD_dpp_4</h4><p>The steady-state exposure-response curve of Kim B et al., <i>CPT: pharmacometrics &amp; systems pharmacology 14(2):246–256</i> 2025 (<a href=\"https://doi.org/10.1002/psp4.13263\">doi:10.1002/psp4.13263</a>) — DPP-4 activity [%inhibition] against evogliptin μg/L — obtained by sweeping the driver instead of simulating a dose. Model family: sigmoid_emax.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = (library default) drug-free response (baseline)
  Emax  =       88.9 %inhibition maximal effect term (E max, Q323)
  EC50  =       1.08 μg/L     exposure at half of the maximal effect term (EC50, Q321)
  gamma =       2.14          Hill coefficient (γ, Q325)</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep\">SigmoidEmaxSweep</a>; this model only supplies the numbers. The x axis is one μg/L of evogliptin per second of simulated time (exposure is in kg/m3): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0   (drug-free)
  exposure = EC50 (1.08 μg/L)  response -44.45
  exposure -> infinity  response -88.9</pre></body></html>"));
end Evogliptin_Kim2025_PD_dpp_4;
