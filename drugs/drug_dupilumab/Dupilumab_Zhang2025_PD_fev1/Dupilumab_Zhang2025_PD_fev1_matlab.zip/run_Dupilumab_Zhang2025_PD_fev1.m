% run_Dupilumab_Zhang2025_PD_fev1  Evaluate the exposure-response curve and plot response against exposure.
% A sweep is a static map: no ODE solver is needed. exposure runs 0..stop_time*exposure_per_s.
p = Dupilumab_Zhang2025_PD_fev1_params();
exposure = linspace(0, p.stop_time * p.exposure_per_s, 501);
frac = exposure.^p.gamma ./ (p.EC50^p.gamma + exposure.^p.gamma);
E0 = p.E0; Emax = p.Emax; slope = p.slope;
response = E0 + Emax.*frac;
figure; plot(exposure, response, 'LineWidth', 1.5); grid on;
xlabel('exposure [mg/L]'); ylabel('response [L]'); title('Dupilumab_Zhang2025_PD_fev1', 'Interpreter', 'none');
writematrix([exposure(:) response(:)], 'Dupilumab_Zhang2025_PD_fev1.csv');
