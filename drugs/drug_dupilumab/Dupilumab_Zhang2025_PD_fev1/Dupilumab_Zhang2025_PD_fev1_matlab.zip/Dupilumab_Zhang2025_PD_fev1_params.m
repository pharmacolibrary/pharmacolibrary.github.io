function p = Dupilumab_Zhang2025_PD_fev1_params()
% Dupilumab_Zhang2025_PD_fev1_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% dupilumab Zhang_2025::FEV1: emax exposure-response sweep (response = E0 + Emax*frac). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one mg/L per second, in SI inside (kg/m3, s). Response FEV1 in L. Driver: dupilumab (cited_pk).
p.E0 = 0.0019300000000000003;
p.Emax = 0.00010400000000000002;
p.EC50 = 0.0007129999999999999;
p.gamma = 1.0;
p.slope = 0.0;
p.exposure_per_s = 0.001;
p.stop_time = 7.2;
p.form = 'E0 + Emax*frac';
end
