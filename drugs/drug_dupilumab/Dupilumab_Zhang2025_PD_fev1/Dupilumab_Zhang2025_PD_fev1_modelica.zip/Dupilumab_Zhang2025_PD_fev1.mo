model Dupilumab_Zhang2025_PD_fev1
  "emax exposure-response sweep — Zhang_2025 :: FEV1 (FEV1)"
  extends Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep(
    E0 = 0.00193,      // [m3; L × 0.001]
    Emax = 0.000104,  // [m3; L × 0.001]
    EC50 = 0.000713,  // [kg/m3; mg/L × 0.001]
    gamma = 1,
    exposure_per_s = 0.001);   // 1 mg/L per second
  // defaulted: gamma
  annotation(experiment(StartTime = 0, StopTime = 7.2, Interval = 0.0144),
    Documentation(info = "<html><body><!-- drug-about --><h4>About dupilumab</h4><p>Dupilumab, a monoclonal antibody, is used to treat atopic dermatitis, prurigo, esophageal disease, asthma, and sinusitis. It is approved and authorised in the European Union, and is also being investigated for additional uses.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q5315925\">Wikidata Q5315925</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h4>Dupilumab_Zhang2025_PD_fev1</h4><p>The steady-state exposure-response curve of Zhang L et al., <i>CPT: pharmacometrics &amp; systems pharmacology 14(8):1370–1380</i> 2025 (<a href=\"https://doi.org/10.1002/psp4.70057\">doi:10.1002/psp4.70057</a>) — FEV1 [L] against dupilumab mg/L — obtained by sweeping the driver instead of simulating a dose. Model family: emax.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    =       1.93 L        drug-free response (baseline) (Typical value of base for men, Q324)
  Emax  =      0.104 L        maximal effect term (E max, Q320)
  EC50  =      0.713 mg/L     exposure at half of the maximal effect term (EC50, Q321)
  gamma = (library default) Hill coefficient</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep\">SigmoidEmaxSweep</a>; this model only supplies the numbers. The x axis is one mg/L of dupilumab per second of simulated time (exposure is in kg/m3): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0.00193   (drug-free)
  exposure = EC50 (0.713 mg/L)  response 0.001982
  exposure -> infinity  response 0.002034</pre></body></html>"));
end Dupilumab_Zhang2025_PD_fev1;
