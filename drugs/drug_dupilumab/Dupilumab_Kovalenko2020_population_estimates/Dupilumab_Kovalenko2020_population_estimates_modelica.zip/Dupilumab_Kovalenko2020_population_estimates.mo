model Dupilumab_Kovalenko2020_population_estimates
  parameter Real Cl_ref = 1.5046296296296299e-09 "Cl [m3/s]";
  parameter Real cov_bmi = 1.0 "bmi covariate (reference 1.0)";
  parameter Real cov_albumin = 1.0 "albumin covariate (reference 1.0)";
  parameter Real cov_race_2 = 0 "race covariate";
  parameter Real Vd_ref = 0.0027400000000000002 "Vd [m3]";
  parameter Real cov_weight = 1.0 "weight covariate (reference 1.0)";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 0.9,
    Cl = Cl_ref*(cov_bmi/1.0)^(0.372)*(cov_albumin/1.0)^(-0.8)*(1 + (-0.118)*cov_race_2),
    Vd = Vd_ref*(cov_weight/1.0)^(0.817)*(cov_albumin/1.0)^(-0.653),
    adminDuration = 600,
    adminCount = 1,
    adminMass = 0.0003,
    ka = 6.342592592592593e-06,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About dupilumab</h4><p>Dupilumab, a monoclonal antibody, is used to treat atopic dermatitis, prurigo, esophageal disease, asthma, and sinusitis. It is approved and authorised in the European Union, and is also being investigated for additional uses.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q5315925\">Wikidata Q5315925</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>dupilumab</td></tr><tr><td>population:</td><td>healthy volunteers and patients with moderate‐to‐severe atopic dermatitis</td></tr><tr><td>source_paper:</td><td>Kovalenko_2020</td></tr><tr><td>measured_compound:</td><td>dupilumab</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>cpdd780-tbl-0002</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr></table><p><b>Defaulted (base-class default used):</b> F, Tlag.</p><h4>Interpretation flags</h4><ul><li>covariate level 'CL ∼ BMI' → Q900:cl_bmi = 0.372 (power on Q22)</li><li>dropped duplicate Q22 ('CL ∼ EASI', value '0.140') — already have one for this compound</li><li>dropped duplicate Q47 ('ke ∼ EASI', value '0.143') — already have one for this compound</li><li>covariate effect for Q319 has no base parameter row (kept as unattached equation-variable)</li><li>implicit units: 'ke (1/d)' → 1/d (from the popPK convention: &quot;The parameter 'ke' is the elimination rate constant. While the paper states the half-life in days (25.4 days) and implie&quot;)</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=dupilumab</li><li>structure disagreement: deterministic 1C vs LLM 2C — review compartment count</li><li>1C volume normalization: Q63→Q61 (single-compartment model has no central/peripheral split; 'Vc (L)' is the general volume)</li><li>population split: 'population estimates' subgroup of Kovalenko_2020 (paper reports 2 populations: population estimate of covariate coefficient, population estimates)</li><li>molar mass: none found for 'dupilumab' — its concentrations stay mass-only</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary's parameterization (rate-constant / ka-only) does not use it</li><li>gap-filled Q49 (kabs) from Takechi_2025's review values (primary lacked it)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 7257600, Tolerance = 1e-9, Interval = 1));
end Dupilumab_Kovalenko2020_population_estimates;
