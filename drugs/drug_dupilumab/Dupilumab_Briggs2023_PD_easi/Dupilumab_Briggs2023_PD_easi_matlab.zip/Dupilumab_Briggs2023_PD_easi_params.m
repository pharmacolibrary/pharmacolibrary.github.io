function p = Dupilumab_Briggs2023_PD_easi_params()
% Dupilumab_Briggs2023_PD_easi_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% dupilumab Briggs_2023::EASI: indirect_response_i exposure-response sweep (response = E0*(1 - Emax*frac)). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one mg/L per second, in SI inside (kg/m3, s). Response EASI in units. Driver: dupilumab (cited_pk).
p.E0 = 30.4;
p.Emax = 0.266;
p.EC50 = 0.020299999999999995;
p.gamma = 1.0;
p.slope = 0.0;
p.exposure_per_s = 0.001;
p.stop_time = 210.0;
p.form = 'E0*(1 - Emax*frac)';
end
