model Dupilumab_Briggs2023_PD_easi
  "indirect_response_i exposure-response sweep — Briggs_2023 :: EASI (Eczema Area and Severity Index (EASI))"
  extends Pharmacolibrary.Interfaces.PartialExposureResponseSweep(
    E0 = 30.4,      // [units]
    Emax = 0.266,  // type I effect term
    EC50 = 0.0203,  // [kg/m3; mg/L × 0.001]
    gamma = 1,
    exposure_per_s = 0.001);   // 1 mg/L per second
equation
  response = E0*(1 - Emax*frac);   // steady state, indirect response type I
  // defaulted: gamma
  annotation(experiment(StartTime = 0, StopTime = 210, Interval = 0.42),
    Documentation(info = "<html><body><!-- drug-about --><h4>About dupilumab</h4><p>Dupilumab, a monoclonal antibody, is used to treat atopic dermatitis, prurigo, esophageal disease, asthma, and sinusitis. It is approved and authorised in the European Union, and is also being investigated for additional uses.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q5315925\">Wikidata Q5315925</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h4>Dupilumab_Briggs2023_PD_easi</h4><p>The steady-state exposure-response curve of Briggs E et al., <i>Pharmaceutical research 40(11):2653–2666</i> 2023 (<a href=\"https://doi.org/10.1007/s11095-023-03616-8\">doi:10.1007/s11095-023-03616-8</a>) — Eczema Area and Severity Index (EASI) [units] against dupilumab mg/L — obtained by sweeping the driver instead of simulating a dose. Model family: indirect_response_i.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    =       30.4 units    drug-free response (baseline) (Baseline EASI score units, Q324)
  Emax  =      0.266          maximal effect term (Drug effect (Imax), Q323)
  EC50  =       20.3 mg/L     exposure at half of the maximal effect term (IC50 (mg/L), Q322)
  gamma = (library default) Hill coefficient</pre><p>The algebra is <code>response = E0*(1 - Emax*frac)</code>; this model only supplies the numbers. The x axis is one mg/L of dupilumab per second of simulated time (exposure is in kg/m3): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 30.4   (drug-free)
  exposure = EC50 (20.3 mg/L)  response 26.36
  exposure -> infinity  response 22.31</pre></body></html>"));
end Dupilumab_Briggs2023_PD_easi;
