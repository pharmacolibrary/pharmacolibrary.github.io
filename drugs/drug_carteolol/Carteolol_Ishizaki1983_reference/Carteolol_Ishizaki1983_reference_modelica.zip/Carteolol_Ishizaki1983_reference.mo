model Carteolol_Ishizaki1983_reference
  parameter Real Cl_ref = 1.1818333333333333e-05 "Cl [m3/s]";
  parameter Real Vd_ref = 0.0518 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.2923734,
    adminMass = 1e-05
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About carteolol</h4><p>Carteolol is a non-selective beta blocker used to treat arterial hypertension and to lower pressure in the eye in open-angle glaucoma and ocular hypertension. It is an approved medicine, available both as a cardiovascular beta blocker and as an eye drop for glaucoma.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q546434\">Wikidata Q546434</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>carteolol</td></tr><tr><td>population:</td><td>normal volunteers</td></tr><tr><td>source_paper:</td><td>Ishizaki_1983</td></tr><tr><td>measured_compound:</td><td>carteolol</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_2C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>carteolol 292.373 g/mol (drugbank)</td></tr></table><p><b>Defaulted (base-class default used):</b> k12, k21.</p><h4>Interpretation flags</h4><ul><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=carteolol</li><li>held at status:extracted — NIL link or unit issue (mismatch/unknown/normalisation-failed) present</li><li>status held at route_to_review — not promoted</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Carteolol_Ishizaki1983_reference;
