model Carteolol_Floreani2004_PD_inotropic_effect
  "sigmoid_emax exposure-response sweep — Floreani_2004 :: inotropic effect (force of contraction)"
  extends Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep(
    E0 = 0,      // [1]
    Emax = 0.171,  // [1; % × 0.01]
    EC50 = 4.6,  // [mM]
    gamma = 1,
    exposure_per_s = 1);   // 1 mM per second
  // exposure_unit_unresolved: 'mM' — the x axis is in the paper's unit, not SI
  // defaulted: E0
  // defaulted: gamma
  annotation(experiment(StartTime = 0, StopTime = 46, Interval = 0.092),
    Documentation(info = "<html><body><!-- drug-about --><h4>About carteolol</h4><p>Carteolol is a non-selective beta blocker used to treat arterial hypertension and to lower pressure in the eye in open-angle glaucoma and ocular hypertension. It is an approved medicine, available both as a cardiovascular beta blocker and as an eye drop for glaucoma.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q546434\">Wikidata Q546434</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h4>Carteolol_Floreani2004_PD_inotropic_effect</h4><p>The steady-state exposure-response curve of Floreani M et al., <i>Journal of pharmacological sciences 95(1):115–123</i> 2004 (<a href=\"https://doi.org/10.1254/jphs.95.115\">doi:10.1254/jphs.95.115</a>) — force of contraction [% of Emax induced by 0.1 mM isoprenaline] against carteolol mM — obtained by sweeping the driver instead of simulating a dose. Model family: sigmoid_emax.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = (library default) drug-free response (baseline)
  Emax  =       17.1 %        maximal effect term (E max, Q320)
  EC50  =        4.6 mM       exposure at half of the maximal effect term (EC 50, Q321)
  gamma = (library default) Hill coefficient</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep\">SigmoidEmaxSweep</a>; this model only supplies the numbers. The x axis is one mM of carteolol per second of simulated time: there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0   (drug-free)
  exposure = EC50 (4.6 mM)  response 0.0855
  exposure -> infinity  response 0.171</pre></body></html>"));
end Carteolol_Floreani2004_PD_inotropic_effect;
