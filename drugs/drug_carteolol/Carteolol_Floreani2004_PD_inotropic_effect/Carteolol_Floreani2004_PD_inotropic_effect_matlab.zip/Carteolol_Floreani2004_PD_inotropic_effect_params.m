function p = Carteolol_Floreani2004_PD_inotropic_effect_params()
% Carteolol_Floreani2004_PD_inotropic_effect_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% carteolol Floreani_2004::inotropic_effect: sigmoid_emax exposure-response sweep (response = E0 + Emax*frac). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one mM per second, in SI inside (kg/m3, s). Response inotropic effect in % of Emax induced by 0.1 mM isoprenaline. Driver: carteolol (cited_pk).
p.E0 = 0.0;
p.Emax = 0.171;
p.EC50 = 4.6;
p.gamma = 1.0;
p.slope = 0.0;
p.exposure_per_s = 1.0;
p.stop_time = 46.0;
p.form = 'E0 + Emax*frac';
end
