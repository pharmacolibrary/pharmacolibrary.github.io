% run_Carteolol_Floreani2004_PD_inotropic_effect  Evaluate the exposure-response curve and plot response against exposure.
% A sweep is a static map: no ODE solver is needed. exposure runs 0..stop_time*exposure_per_s.
p = Carteolol_Floreani2004_PD_inotropic_effect_params();
exposure = linspace(0, p.stop_time * p.exposure_per_s, 501);
frac = exposure.^p.gamma ./ (p.EC50^p.gamma + exposure.^p.gamma);
E0 = p.E0; Emax = p.Emax; slope = p.slope;
response = E0 + Emax.*frac;
figure; plot(exposure, response, 'LineWidth', 1.5); grid on;
xlabel('exposure [mM]'); ylabel('response [% of Emax induced by 0.1 mM isoprenaline]'); title('Carteolol_Floreani2004_PD_inotropic_effect', 'Interpreter', 'none');
writematrix([exposure(:) response(:)], 'Carteolol_Floreani2004_PD_inotropic_effect.csv');
