function p = Prazosin_Grahnn1981_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: prazosin   source: Grahnén_1981 / reference   route: oral
  % estimated (absent from source): ka
  p.name  = 'Prazosin_Grahnn1981_reference_params';
  p.drug  = 'prazosin';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 42.0;                % central volume [L]
  p.CL = 0.14;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.5;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 5.0;             % dose [mg]
end
