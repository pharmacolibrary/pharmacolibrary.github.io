model Azlocillin_Pacifici2010_reference
  parameter Real Cl_ref = 1.5166666666666668e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.025206767754411972 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.461492,
    adminMass = 0.012
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About azlocillin</h4><p>Azlocillin is an extended-spectrum penicillin antibiotic used to treat bacterial infections. It is an approved antibacterial for systemic use, though it is not widely marketed today and has largely been replaced by other penicillins.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q510154\">Wikidata Q510154</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>azlocillin</td></tr><tr><td>population:</td><td>review reference</td></tr><tr><td>source_paper:</td><td>Pacifici_2010</td></tr><tr><td>measured_compound:</td><td>azlocillin</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>azlocillin 461.492 g/mol (drugbank)</td></tr></table><h4>Interpretation flags</h4><ul><li>built from REVIEW reference values (Pacifici_2010) — secondary source</li><li>central volume derived from CL·t½/ln2</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Azlocillin_Pacifici2010_reference;
