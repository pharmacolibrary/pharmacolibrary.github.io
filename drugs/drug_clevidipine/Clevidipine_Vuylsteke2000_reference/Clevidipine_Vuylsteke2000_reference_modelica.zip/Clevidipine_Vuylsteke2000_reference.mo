model Clevidipine_Vuylsteke2000_reference
  parameter Real Cl_ref = 1.916666666666667e-08 "Cl [m3/s]";
  parameter Real Vd_ref = 0.013300000000000001 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.456316,
    adminMass = 1e-05
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>clevidipine</td></tr><tr><td>population:</td><td>patients undergoing cardiac surgery</td></tr><tr><td>source_paper:</td><td>Vuylsteke_2000</td></tr><tr><td>measured_compound:</td><td>clevidipine</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>clevidipine 456.316 g/mol (drugbank)</td></tr></table><h4>Interpretation flags</h4><ul><li>unit_dimension_unknown: 'litres min-1 kg-1' (CL)</li><li>unit_dimension_unknown: 'litres min-1 kg-1' (CLb)</li><li>unit_dimension_unknown: 'litres min-1 kg-1' (CL)</li><li>dropped duplicate Q22 ('clearance of clevidipine', value 0.03) — already have one for this compound</li><li>implicit units: 'clearance' → L/h (from the popPK convention: 'Clearance is conventionally expressed in L/h in population PK; the value 0.069 is consistent with a low-clearance drug (')</li><li>implicit units: 'total blood clearance of clevidipine' → L/h (from the popPK convention: 'Blood clearance is conventionally expressed in L/h in population PK; the value 0.055 is consistent with a low-clearance ')</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=clevidipine</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 2419200, Tolerance = 1e-9, Interval = 1));
end Clevidipine_Vuylsteke2000_reference;
