model Clevidipine_Ericsson2001_reference
  parameter Real Cl_ref = 0.00012016666666666667 "Cl [m3/s]";
  parameter Real Vd_ref = 0.027300000000000005 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    adminMass = 1e-05
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About clevidipine</h4><p>Clevidipine is a dihydropyridine calcium channel blocker used to treat arterial hypertension. It is an approved drug, though it does not appear to be authorised in the European Union.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q5132338\">Wikidata Q5132338</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>clevidipine</td></tr><tr><td>population:</td><td>essential hypertensive patients</td></tr><tr><td>source_paper:</td><td>Ericsson_2001</td></tr><tr><td>measured_compound:</td><td>clevidipine enantiomers</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>clevidipine 456.316 g/mol (drugbank)</td></tr></table><h4>Interpretation flags</h4><ul><li>dropped duplicate Q23 ('mean blood clearance values of (+)-S-clevidipine', value 0.096) — already have one for this compound</li><li>dropped duplicate Q65 ('volumes of distribution at steady state of (+)-S-clevidipine', value 0.54) — already have one for this compound</li><li>dropped unlinked row (NIL): 'context-sensitive half-time' — extend the ontology if this is a real PK parameter (source ['Ericsson_2001:abstract'])</li><li>dropped unlinked row (NIL): 'time for 90% decline in concentration for (-)-R-clevidipine' — extend the ontology if this is a real PK parameter (source ['Ericsson_2001:abstract'])</li><li>dropped unlinked row (NIL): 'time for 90% decline in concentration for (+)-S-clevidipine' — extend the ontology if this is a real PK parameter (source ['Ericsson_2001:abstract'])</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=clevidipine enantiomers</li><li>molar mass: no plausible PubChem entry for 'clevidipine enantiomers' ('clevidipine enantiomers') — left in mass units</li><li>molar mass: none found for 'clevidipine enantiomers' — its concentrations stay mass-only</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Clevidipine_Ericsson2001_reference;
