model Hydrochlorothiazide_Kutumova2022_PD_fractional_distal_sodium
  "linear exposure-response sweep — Kutumova_2022 :: Fractional distal sodium reabsorption rate (Fractional distal sodium reabsorption rate)"
  extends Pharmacolibrary.Interfaces.PartialExposureResponseSweep(
    E0 = 0,      // [1]
    Emax = 0, EC50 = 1,      // unused by a line
    exposure_per_s = 1.15740740741e-11);
  parameter Real slope = 0.304   "[1]";
equation
  response = E0 + slope*exposure;
  // defaulted: E0
  annotation(experiment(StartTime = 0, StopTime = 1000, Interval = 2),
    Documentation(info = "<html><body><h4>Hydrochlorothiazide_Kutumova2022_PD_fractional_distal_sodium</h4><p>The steady-state exposure-response curve of Kutumova E et al., <i>Frontiers in physiology 13:1070115</i> 2022 (<a href=\"https://doi.org/10.3389/fphys.2022.1070115\">doi:10.3389/fphys.2022.1070115</a>) — Fractional distal sodium reabsorption rate against hydrochlorothiazide mg/day — obtained by sweeping the driver instead of simulating a dose. Model family: linear.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = (library default) drug-free response (baseline)
  slope =      0.304          change in response per unit of exposure (E(D)-value, Q335)</pre><p>The algebra is <code>response = E0 + slope*exposure</code>; this model only supplies the numbers. The x axis is one mg/day of hydrochlorothiazide per second of simulated time (exposure is in kg/s): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0   (drug-free)</pre></body></html>"));
end Hydrochlorothiazide_Kutumova2022_PD_fractional_distal_sodium;
