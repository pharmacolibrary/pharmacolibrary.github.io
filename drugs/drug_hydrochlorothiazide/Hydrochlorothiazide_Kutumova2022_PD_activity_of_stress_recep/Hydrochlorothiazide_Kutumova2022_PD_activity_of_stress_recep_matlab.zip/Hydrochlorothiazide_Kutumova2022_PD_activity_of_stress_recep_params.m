function p = Hydrochlorothiazide_Kutumova2022_PD_activity_of_stress_recep_params()
% Hydrochlorothiazide_Kutumova2022_PD_activity_of_stress_recep_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% hydrochlorothiazide Kutumova_2022::Activity_of_stress_receptors: linear exposure-response sweep (response = E0 + slope*exposure). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one mg/day per second, in SI inside (kg/m3, s). Response Activity of stress receptors in its own unit. Driver: hydrochlorothiazide (dose_only).
p.E0 = 0.0;
p.Emax = 0.0;
p.EC50 = 1.0;
p.gamma = 1.0;
p.slope = 0.389;
p.exposure_per_s = 1.15740740741e-11;
p.stop_time = 1000.0;
p.form = 'E0 + slope*exposure';
end
