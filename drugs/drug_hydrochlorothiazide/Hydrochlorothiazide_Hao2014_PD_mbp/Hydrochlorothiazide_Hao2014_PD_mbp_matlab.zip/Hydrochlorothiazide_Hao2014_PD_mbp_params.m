function p = Hydrochlorothiazide_Hao2014_PD_mbp_params()
% Hydrochlorothiazide_Hao2014_PD_mbp_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% hydrochlorothiazide Hao_2014::MBP: indirect_response_iv exposure-response sweep (response = E0/(1 + Emax*frac)). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one ng/ml per second, in SI inside (kg/m3, s). Response MBP in mmHg. Driver: hydrochlorothiazide (cited_pk).
p.E0 = 185.58823529411765;
p.Emax = 1.23;
p.EC50 = 0.00040339999999999994;
p.gamma = 1.0;
p.slope = 0.0;
p.exposure_per_s = 1e-06;
p.stop_time = 1900.0;
p.form = 'E0/(1 + Emax*frac)';
end
