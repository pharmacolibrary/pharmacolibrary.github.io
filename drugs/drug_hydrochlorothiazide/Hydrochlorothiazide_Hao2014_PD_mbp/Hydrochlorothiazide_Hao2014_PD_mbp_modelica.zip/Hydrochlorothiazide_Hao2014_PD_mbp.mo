model Hydrochlorothiazide_Hao2014_PD_mbp
  "indirect_response_iv exposure-response sweep — Hao_2014 :: MBP (mean arterial blood pressure)"
  extends Pharmacolibrary.Pharmacodynamic.IndirectTurnoverSweep(
    E0 = 185.588235294,      // [mmHg]
    Emax = 1.23,  // type IV effect term
    EC50 = 0.0004034,  // [kg/m3; ng/ml × 1e-06]
    gamma = 1,
    exposure_per_s = 1e-06);   // 1 ng/ml per second
  // e0_from_kin_kout: no baseline row; E0 = kin/kout (63.1/0.34 = 185.6) — the paper's stated baseline may differ
  // defaulted: gamma
  annotation(experiment(StartTime = 0, StopTime = 1900, Interval = 3.8),
    Documentation(info = "<html><body><!-- drug-about --><h4>About hydrochlorothiazide</h4><p>Hydrochlorothiazide is a thiazide diuretic used to treat high blood pressure, heart failure, and fluid retention conditions such as nephrotic syndrome and nephrogenic diabetes insipidus. It is widely used, appears on the WHO list of essential medicines, and is available alone and in many fixed combinations with blood pressure drugs.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q423930\">Wikidata Q423930</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h4>Hydrochlorothiazide_Hao2014_PD_mbp</h4><p>The steady-state exposure-response curve of Hao K et al., <i>The Journal of pharmacy and pharmacology 66(8):1112–1121</i> 2014 (<a href=\"https://doi.org/10.1111/jphp.12230\">doi:10.1111/jphp.12230</a>) — mean arterial blood pressure [mmHg] against hydrochlorothiazide ng/ml — obtained by sweeping the driver instead of simulating a dose. Model family: indirect_response_iv.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = 185.588235294 mmHg     drug-free response (baseline) (kin/kout, Q327/Q328)
  Emax  =       1.23          maximal effect term (Smax, Q320)
  EC50  =      403.4 ng/ml    exposure at half of the maximal effect term (SC50, Q321)
  gamma = (library default) Hill coefficient</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.IndirectTurnoverSweep\">IndirectTurnoverSweep</a>; this model only supplies the numbers. The x axis is one ng/ml of hydrochlorothiazide per second of simulated time (exposure is in kg/m3): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><p>The effect term enters as a reciprocal (steady state of <code>der(R) = Kin - Kout*(1 + Emax*frac)*R</code>), so EC50 is the exposure at half the maximal STIMULATION of turnover, not at half the response.</p><h4>What it reproduces</h4><pre>  exposure = 0         response 185.6   (drug-free)
  exposure = EC50 (403.4 ng/ml)  response 114.9
  exposure -> infinity  response 83.22</pre></body></html>"));
end Hydrochlorothiazide_Hao2014_PD_mbp;
