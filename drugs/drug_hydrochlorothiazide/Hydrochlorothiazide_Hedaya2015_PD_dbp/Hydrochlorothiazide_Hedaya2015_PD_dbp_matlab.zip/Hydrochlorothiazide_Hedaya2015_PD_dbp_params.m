function p = Hydrochlorothiazide_Hedaya2015_PD_dbp_params()
% Hydrochlorothiazide_Hedaya2015_PD_dbp_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% hydrochlorothiazide Hedaya_2015::DBP: sigmoid_emax exposure-response sweep (response = E0 + Emax*frac). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one µg/mL per second, in SI inside (kg/m3, s). Response DBP in mmHg. Driver: IRB (conc_no_pk).
p.E0 = 0.0;
p.Emax = -4.73;
p.EC50 = 0.0015199999999999997;
p.gamma = 1.9;
p.slope = 0.0;
p.exposure_per_s = 0.001;
p.stop_time = 16.0;
p.form = 'E0 + Emax*frac';
end
