model Hydrochlorothiazide_Hedaya2015_PD_dbp
  "sigmoid_emax exposure-response sweep — Hedaya_2015 :: DBP (DBP)"
  extends Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep(
    E0 = 0,      // [1]
    Emax = -4.73,  // [mmHg]
    EC50 = 0.00152,  // [kg/m3; µg/mL × 0.001]
    gamma = 1.9,
    exposure_per_s = 0.001);   // 1 µg/mL per second
  // imax_as_negative_emax: Imax (Q323) enters SigmoidEmaxSweep as −Emax
  // defaulted: E0
  annotation(experiment(StartTime = 0, StopTime = 16, Interval = 0.032),
    Documentation(info = "<html><body><!-- drug-about --><h4>About hydrochlorothiazide</h4><p>Hydrochlorothiazide is a thiazide diuretic used to treat high blood pressure, heart failure, and fluid retention conditions such as nephrotic syndrome and nephrogenic diabetes insipidus. It is widely used, appears on the WHO list of essential medicines, and is available alone and in many fixed combinations with blood pressure drugs.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q423930\">Wikidata Q423930</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h4>Hydrochlorothiazide_Hedaya2015_PD_dbp</h4><p>The steady-state exposure-response curve of Hedaya MA et al., <i>Biopharmaceutics &amp; drug disposition 36(4):216–231</i> 2015 (<a href=\"https://doi.org/10.1002/bdd.1935\">doi:10.1002/bdd.1935</a>) — DBP [mmHg] against IRB µg/mL — obtained by sweeping the driver instead of simulating a dose. Model family: sigmoid_emax.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = (library default) drug-free response (baseline)
  Emax  =       4.73 mmHg     maximal effect term (E max, Q323)
  EC50  =       1.52 µg/mL    exposure at half of the maximal effect term (EC 50, Q321)
  gamma =        1.9          Hill coefficient (n, Q325)</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep\">SigmoidEmaxSweep</a>; this model only supplies the numbers. The x axis is one µg/mL of IRB per second of simulated time (exposure is in kg/m3): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0   (drug-free)
  exposure = EC50 (1.52 µg/mL)  response -2.365
  exposure -> infinity  response -4.73</pre></body></html>"));
end Hydrochlorothiazide_Hedaya2015_PD_dbp;
