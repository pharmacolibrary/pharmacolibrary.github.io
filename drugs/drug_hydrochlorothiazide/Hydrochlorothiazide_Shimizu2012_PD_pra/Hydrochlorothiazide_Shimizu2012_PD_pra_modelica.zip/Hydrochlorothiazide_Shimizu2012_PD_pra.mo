model Hydrochlorothiazide_Shimizu2012_PD_pra
  "indirect_response_iii exposure-response sweep — Shimizu_2012 :: PRA (plasma renin activity)"
  extends Pharmacolibrary.Interfaces.PartialExposureResponseSweep(
    E0 = 0,      // [1]
    Emax = 14,  // type III effect term
    EC50 = 0.000585,  // [kg/m3; µg/mL × 0.001]
    gamma = 1,
    exposure_per_s = 0.001);   // 1 µg/mL per second
equation
  response = E0*(1 + Emax*frac);   // steady state, indirect response type III
  // defaulted: E0
  // defaulted: gamma
  annotation(experiment(StartTime = 0, StopTime = 5.9, Interval = 0.0118),
    Documentation(info = "<html><body><h4>Hydrochlorothiazide_Shimizu2012_PD_pra</h4><p>The steady-state exposure-response curve of Shimizu R et al., <i>Drug metabolism and pharmacokinetics 27(2):207–215</i> 2012 (<a href=\"https://doi.org/10.2133/dmpk.dmpk-11-rg-060\">doi:10.2133/dmpk.dmpk-11-rg-060</a>) — plasma renin activity [ng&amp;Ang I/mL/h] against losartan µg/mL — obtained by sweeping the driver instead of simulating a dose. Model family: indirect_response_iii.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = (library default) drug-free response (baseline)
  Emax  =         14          maximal effect term (RE max (HCTZ 1 mg/kg), Q323)
  EC50  =      0.585 µg/mL    exposure at half of the maximal effect term (REC 50, Q321)
  gamma = (library default) Hill coefficient</pre><p>The algebra is <code>response = E0*(1 + Emax*frac)</code>; this model only supplies the numbers. The x axis is one µg/mL of losartan per second of simulated time (exposure is in kg/m3): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0   (drug-free)
  exposure = EC50 (0.585 µg/mL)  response 0
  exposure -> infinity  response 0</pre></body></html>"));
end Hydrochlorothiazide_Shimizu2012_PD_pra;
