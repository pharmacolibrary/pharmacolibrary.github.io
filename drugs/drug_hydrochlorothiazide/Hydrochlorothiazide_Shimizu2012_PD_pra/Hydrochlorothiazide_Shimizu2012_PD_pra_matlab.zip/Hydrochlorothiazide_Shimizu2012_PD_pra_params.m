function p = Hydrochlorothiazide_Shimizu2012_PD_pra_params()
% Hydrochlorothiazide_Shimizu2012_PD_pra_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% hydrochlorothiazide Shimizu_2012::PRA: indirect_response_iii exposure-response sweep (response = E0*(1 + Emax*frac)). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one µg/mL per second, in SI inside (kg/m3, s). Response PRA in ng&Ang I/mL/h. Driver: losartan (pk_record).
p.E0 = 0.0;
p.Emax = 14.0;
p.EC50 = 0.0005849999999999998;
p.gamma = 1.0;
p.slope = 0.0;
p.exposure_per_s = 0.001;
p.stop_time = 5.9;
p.form = 'E0*(1 + Emax*frac)';
end
