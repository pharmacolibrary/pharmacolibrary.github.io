function p = Micafungin_Caballero2023_PD_n_params()
% Micafungin_Caballero2023_PD_n_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% micafungin Caballero_2023::N: sigmoid_emax exposure-response sweep (response = E0 + Emax*frac). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one mg/L per second, in SI inside (kg/m3, s). Response N in log CFU/mL. Driver: micafungin (cited_pk).
p.E0 = 0.0;
p.Emax = -6.944444444444445e-06;
p.EC50 = 0.00017099999999999998;
p.gamma = 1.0;
p.slope = 0.0;
p.exposure_per_s = 0.001;
p.stop_time = 1.8;
p.form = 'E0 + Emax*frac';
end
