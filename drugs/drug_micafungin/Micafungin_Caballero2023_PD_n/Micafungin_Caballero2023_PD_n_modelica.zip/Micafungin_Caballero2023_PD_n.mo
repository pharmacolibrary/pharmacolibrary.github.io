model Micafungin_Caballero2023_PD_n
  "sigmoid_emax exposure-response sweep — Caballero_2023 :: N (log CFU/mL)"
  extends Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep(
    E0 = 0,      // [1]
    Emax = -6.94444444444e-06,  // [1/s; h−1 × 0.000277778]
    EC50 = 0.000171,  // [kg/m3; mg/L × 0.001]
    gamma = 1,
    exposure_per_s = 0.001);   // 1 mg/L per second
  // imax_as_negative_emax: Imax (Q323) enters SigmoidEmaxSweep as −Emax
  // defaulted: E0
  annotation(experiment(StartTime = 0, StopTime = 1.8, Interval = 0.0036),
    Documentation(info = "<html><body><!-- drug-about --><h4>About micafungin</h4><p>Micafungin is an antifungal medicine used to treat fungal infections such as candidiasis and aspergillosis. It is authorised in the European Union for candidiasis and is an approved drug.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q6827850\">Wikidata Q6827850</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h4>Micafungin_Caballero2023_PD_n</h4><p>The steady-state exposure-response curve of Caballero U et al., <i>CPT: pharmacometrics &amp; systems pharmacology 12(6):770–782</i> 2023 (<a href=\"https://doi.org/10.1002/psp4.12949\">doi:10.1002/psp4.12949</a>) — log CFU/mL [log CFU/mL] against micafungin mg/L — obtained by sweeping the driver instead of simulating a dose. Model family: sigmoid_emax.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = (library default) drug-free response (baseline)
  Emax  =      0.025 h−1      maximal effect term (E maxCANDIN, Q323)
  EC50  =      0.171 mg/L     exposure at half of the maximal effect term (EC50CANDIN, Q321)
  gamma =          1          Hill coefficient (h CANDIN, Q325)</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep\">SigmoidEmaxSweep</a>; this model only supplies the numbers. The x axis is one mg/L of micafungin per second of simulated time (exposure is in kg/m3): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0   (drug-free)
  exposure = EC50 (0.171 mg/L)  response -3.472e-06
  exposure -> infinity  response -6.944e-06</pre></body></html>"));
end Micafungin_Caballero2023_PD_n;
