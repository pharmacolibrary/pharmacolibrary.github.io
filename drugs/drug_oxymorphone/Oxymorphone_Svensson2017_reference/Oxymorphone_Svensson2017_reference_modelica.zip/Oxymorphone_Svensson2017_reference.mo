model Oxymorphone_Svensson2017_reference
  parameter Real Cl_ref = 2.222222222222222e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.06 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.3013371,
    adminMass = 0.0001,
    ka = 0.0002777777777777778,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About oxymorphone</h4><p>Oxymorphone is an opioid painkiller used to treat moderate to severe pain. It is an approved medicine, also approved for veterinary use, and is used mainly in North America rather than the European Union.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q423380\">Wikidata Q423380</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>oxymorphone</td></tr><tr><td>population:</td><td>review reference</td></tr><tr><td>source_paper:</td><td>Svensson_2017</td></tr><tr><td>measured_compound:</td><td>oxymorphone</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>oxymorphone 301.337 g/mol (drugbank)</td></tr></table><p><b>Defaulted (base-class default used):</b> Tlag.</p><h4>Interpretation flags</h4><ul><li>built from REVIEW reference values (Svensson_2017) — secondary source</li><li>volume reported by review</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 104400, Tolerance = 1e-9, Interval = 1));
end Oxymorphone_Svensson2017_reference;
