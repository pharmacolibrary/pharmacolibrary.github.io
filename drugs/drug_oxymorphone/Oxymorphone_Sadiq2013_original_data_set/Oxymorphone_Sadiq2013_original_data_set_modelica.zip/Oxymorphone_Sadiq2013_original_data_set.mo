model Oxymorphone_Sadiq2013_original_data_set
  parameter Real Cl_ref = 9.083333333333332e-07 "Cl [m3/s]";
  parameter Real Vd_ref = 0.00117 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 0.9,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.3013371,
    adminMass = 2.1000000000000002e-06,
    ka = 0.00425,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About oxymorphone</h4><p>Oxymorphone is an opioid painkiller used to treat moderate to severe pain. It is an approved medicine, also approved for veterinary use, and is used mainly in North America rather than the European Union.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q423380\">Wikidata Q423380</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>oxymorphone</td></tr><tr><td>population:</td><td>male Sprague-Dawley rats</td></tr><tr><td>source_paper:</td><td>Sadiq_2013</td></tr><tr><td>measured_compound:</td><td>oxymorphone</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>tab_1</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>oxymorphone 301.337 g/mol (drugbank)</td></tr></table><p><b>Defaulted (base-class default used):</b> F, Tlag.</p><h4>Interpretation flags</h4><ul><li>dropped duplicate Q30 ('Q av (mL/min)', value '56.6') — already have one for this compound</li><li>dropped unlinked row (NIL): 'REC blood (%)' — extend the ontology if this is a real PK parameter (source ['tab_1:row7:col1', 'tab_1:row7:col2', 'tab_1:row7:col4'])</li><li>dropped unlinked row (NIL): 'REC brain (%)' — extend the ontology if this is a real PK parameter (source ['tab_1:row8:col1', 'tab_1:row8:col2', 'tab_1:row8:col4'])</li><li>dropped duplicate Q22 ('CL in (mL/min)', value '0.123') — already have one for this compound</li><li>dropped PD-category row 'Baseline effect (s)' → Q324 (E0, category G11) — pharmacodynamic parameters belong to scholarpd, not the PK model (source ['tab_1:row11:col1', 'tab_1:row11:col2', 'tab_1:row11:col4'])</li><li>dropped PD-category row 'E max (s)' → Q320 (Emax, category G11) — pharmacodynamic parameters belong to scholarpd, not the PK model (source ['tab_1:row12:col1', 'tab_1:row12:col4'])</li><li>dropped PD-category row 'EC 50 (ng/mL)' → Q321 (EC50, category G11) — pharmacodynamic parameters belong to scholarpd, not the PK model (source ['tab_1:row13:col1', 'tab_1:row13:col4'])</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=oxymorphone</li><li>structure disagreement: deterministic 1C vs LLM 2C — review compartment count</li><li>1C volume normalization: Q63→Q61 (single-compartment model has no central/peripheral split; 'V c (mL)' is the general volume)</li><li>population split: 'original data set' subgroup of Sadiq_2013 (paper reports 2 populations: bootstrap resampling, original data set)</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>gap-filled Q49 (kabs) from Noh_2017's review values (primary lacked it)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Oxymorphone_Sadiq2013_original_data_set;
