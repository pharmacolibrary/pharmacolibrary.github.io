function p = Oxymorphone_Sadiq2013_original_data_set_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: oxymorphone   source: Sadiq_2013 / original_data_set   route: oral
  % estimated (absent from source): F
  p.name  = 'Oxymorphone_Sadiq2013_original_data_set_params';
  p.drug  = 'oxymorphone';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 1.17;                % central volume [L]
  p.CL = 3.27;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 15.3;                % absorption rate [1/h]
  p.F  = 0.9;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 2.1;             % dose [mg]
end
