model Arbekacin_Suzuki2003_reference
  parameter Real Cl_ref = 1.638888888888889e-07 "Cl [m3/s]";
  parameter Real Vd_ref = 0.035 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.5526190000000001,
    adminMass = 0.0002
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About arbekacin</h4><p>Arbekacin is an aminoglycoside antibiotic that kills bacteria and is used as an anti-infective agent. It is considered investigational and is not authorised in the European Union.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q4784668\">Wikidata Q4784668</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>arbekacin</td></tr><tr><td>population:</td><td>preterm and term newborn infants</td></tr><tr><td>source_paper:</td><td>Suzuki_2003</td></tr><tr><td>measured_compound:</td><td>arbekacin</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>arbekacin 552.619 g/mol (drugbank)</td></tr></table><h4>Interpretation flags</h4><ul><li>unit_dimension_unknown: 'mL/min per kg' (CL)</li><li>implicit units: 'CL' → L/h (from the popPK convention: 'Clearance is conventionally expressed in L/h in population PK; the value 0.59 is of a plausible magnitude for L/h for a ')</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=arbekacin</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 777600, Tolerance = 1e-9, Interval = 1));
end Arbekacin_Suzuki2003_reference;
