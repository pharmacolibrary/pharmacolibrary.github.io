model Vericiguat_Ruehs2021_reference
  parameter Real Cl_ref = 3.611111111111112e-07 "Cl [m3/s]";
  parameter Real cov_sex_0 = 0 "sex covariate";
  parameter Real Vd_ref = 0.0389 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref*(1 + (0.85)*cov_sex_0),
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.426388,
    adminMass = 1.25e-06,
    ka = 0.00041666666666666664,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About vericiguat</h4><p>Vericiguat is a vasodilator used to treat heart failure. It is approved and authorised in the European Union, though it also remains investigational for other uses.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q27283201\">Wikidata Q27283201</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>vericiguat</td></tr><tr><td>population:</td><td>adults with heart failure and reduced ejection fraction</td></tr><tr><td>source_paper:</td><td>Ruehs_2021</td></tr><tr><td>measured_compound:</td><td>vericiguat</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>Tab2</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>vericiguat 426.388 g/mol (drugbank)</td></tr></table><p><b>Defaulted (base-class default used):</b> Tlag.</p><h4>Interpretation flags</h4><ul><li>table section iiv: 'CL/F (L/h)' routed out of structural estimates ('Inter-individual variabilityCV (%)a')</li><li>table section iiv: 'V/F (L)' routed out of structural estimates ('Inter-individual variabilityCV (%)a')</li><li>table section iiv: 'ka (1/h)' routed out of structural estimates ('Inter-individual variabilityCV (%)a')</li><li>table section iiv: 'CL/F (L/h)' routed out of structural estimates ('Inter-individual variability CV (%)a')</li><li>table section iiv: 'V/F (L)' routed out of structural estimates ('Inter-individual variability CV (%)a')</li><li>table section iiv: 'ka (1/h)' routed out of structural estimates ('Inter-individual variability CV (%)a')</li><li>dropped value-less row: 'θCL,age'</li><li>dropped value-less row: 'θCL,bilirubin'</li><li>covariate level 'θV,sex' → Q900:v_sex = 0.850 (linear_fractional on Q27)</li><li>dropped unlinked row (NIL): 'θF,dose≤1.25 mg' — extend the ontology if this is a real PK parameter (source ['Tab2:row12:col1', 'Tab2:row12:col2'])</li><li>dropped unlinked row (NIL): 'θF,dose=5 mg' — extend the ontology if this is a real PK parameter (source ['Tab2:row13:col1', 'Tab2:row13:col2'])</li><li>dropped unlinked row (NIL): 'θF,dose=10 mg' — extend the ontology if this is a real PK parameter (source ['Tab2:row14:col1', 'Tab2:row14:col2'])</li><li>NIL: refused to back-fill base 'CL/F' from footnote/prose loose number None (source ['Tab2:footnote']); the table cell was unparseable — needs review</li><li>NIL: refused to back-fill base 'V/F' from footnote/prose loose number None (source ['Tab2:footnote']); the table cell was unparseable — needs review</li><li>NIL: refused to back-fill base 'kabs' from footnote/prose loose number None (source ['Tab2:footnote']); the table cell was unparseable — needs review</li><li>covariate effect for Q22 has no base parameter row (kept as unattached equation-variable)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 432000, Tolerance = 1e-9, Interval = 1));
end Vericiguat_Ruehs2021_reference;
