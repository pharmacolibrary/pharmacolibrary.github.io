model Luseogliflozin_Sasaki2015_PD_uge
  "sigmoid_emax exposure-response sweep — Sasaki_2015 :: UGE (urinary glucose excretion)"
  extends Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep(
    E0 = 0,      // [1]
    Emax = 1.37731481481e-06,  // [kg/s; g/day × 1.15741e-08]
    EC50 = 254,  // [ng h/mL]
    gamma = 0.931,
    exposure_per_s = 1);   // 1 ng h/mL per second
  // exposure_unit_unresolved: 'ng h/mL' — the x axis is in the paper's unit, not SI
  // defaulted: E0
  annotation(experiment(StartTime = 0, StopTime = 2600, Interval = 5.2),
    Documentation(info = "<html><body><!-- drug-about --><h4>About luseogliflozin</h4><p>Luseogliflozin is an SGLT2 inhibitor studied for the treatment of type 2 diabetes. It is not authorised in the European Union and remains investigational.</p><p><small>Summary written by glm-5.3-flash from <a href=&quot;https://www.wikidata.org/wiki/Q27275212&quot;>Wikidata Q27275212</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h4>Luseogliflozin_Sasaki2015_PD_uge</h4><p>The steady-state exposure-response curve of Sasaki T et al., <i>Advances in therapy 32(4):319–340</i> 2015 (<a href=\"https://doi.org/10.1007/s12325-015-0200-x\">doi:10.1007/s12325-015-0200-x</a>) — urinary glucose excretion [g/day] against luseogliflozin ng h/mL — obtained by sweeping the driver instead of simulating a dose. Model family: sigmoid_emax.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = (library default) drug-free response (baseline)
  Emax  =        119 g/day    maximal effect term (E max, Q320)
  EC50  =        254 ng h/mL  exposure at half of the maximal effect term (EC50, Q321)
  gamma =      0.931          Hill coefficient (γ, Q325)</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep\">SigmoidEmaxSweep</a>; this model only supplies the numbers. The x axis is one ng h/mL of luseogliflozin per second of simulated time: there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0   (drug-free)
  exposure = EC50 (254 ng h/mL)  response 6.887e-07
  exposure -> infinity  response 1.377e-06</pre></body></html>"));
end Luseogliflozin_Sasaki2015_PD_uge;
