function p = Luseogliflozin_Sasaki2015_PD_uge_params()
% Luseogliflozin_Sasaki2015_PD_uge_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% luseogliflozin Sasaki_2015::UGE: sigmoid_emax exposure-response sweep (response = E0 + Emax*frac). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one ng h/mL per second, in SI inside (kg/m3, s). Response UGE in g/day. Driver: luseogliflozin (cited_pk).
p.E0 = 0.0;
p.Emax = 1.3773148148148149e-06;
p.EC50 = 254.0;
p.gamma = 0.931;
p.slope = 0.0;
p.exposure_per_s = 1.0;
p.stop_time = 2600.0;
p.form = 'E0 + Emax*frac';
end
