model SuraminSodium_Kosarek2006_reference
  parameter Real Cl_ref = 3.6166666666666666e-08 "Cl [m3/s]";
  parameter Real Vd_ref = 0.0238 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 1.29728,
    adminMass = 0.00027
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About suramin_sodium</h4><p>Suramin is an antiprotozoal drug used against trypanosomiasis, and has also been studied as an antineoplastic and antinematodal agent. It is listed as investigational in DrugBank and has no European Union authorisation, though it appears on the WHO essential medicines list.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q425946\">Wikidata Q425946</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>suramin_sodium</td></tr><tr><td>population:</td><td>dogs with naturally occurring cancers</td></tr><tr><td>source_paper:</td><td>Kosarek_2006</td></tr><tr><td>measured_compound:</td><td>suramin</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>suramin 1297.28 g/mol (drugbank); suramin_sodium 1297.28 g/mol (drugbank)</td></tr></table><h4>Interpretation flags</h4><ul><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=suramin</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 2419200, Tolerance = 1e-9, Interval = 1));
end SuraminSodium_Kosarek2006_reference;
