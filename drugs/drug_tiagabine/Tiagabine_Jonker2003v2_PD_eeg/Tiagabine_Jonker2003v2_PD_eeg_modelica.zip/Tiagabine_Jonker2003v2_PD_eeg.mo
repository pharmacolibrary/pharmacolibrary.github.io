model Tiagabine_Jonker2003v2_PD_eeg
  "sigmoid_emax exposure-response sweep — Jonker_2003_2 :: EEG (EEG response in the 11.5- to 30-Hz frequency band)"
  extends Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep(
    E0 = 0,      // [1]
    Emax = 327,  // [microV]
    EC50 = 0.000392,  // [kg/m3; ng/ml × 1e-06]
    gamma = 3.1,
    exposure_per_s = 1e-06);   // 1 ng/ml per second
  // defaulted: E0
  annotation(experiment(StartTime = 0, StopTime = 4000, Interval = 8),
    Documentation(info = "<html><body><!-- drug-about --><h4>About tiagabine</h4><p>Tiagabine is an anticonvulsant used to treat focal epilepsy and has also been studied for bipolar disorder. It is an approved medicine, though not authorised in the European Union, and remains under investigation for other uses.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q907219\">Wikidata Q907219</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h4>Tiagabine_Jonker2003v2_PD_eeg</h4><p>The steady-state exposure-response curve of Jonker DM et al., <i>Epilepsia 44(3):329–338</i> 2003 (<a href=\"https://doi.org/10.1046/j.1528-1157.2003.37802.x\">doi:10.1046/j.1528-1157.2003.37802.x</a>) — EEG response in the 11.5- to 30-Hz frequency band [microV] against tiagabine ng/ml — obtained by sweeping the driver instead of simulating a dose. Model family: sigmoid_emax.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = (library default) drug-free response (baseline)
  Emax  =        327 microV   maximal effect term (Emax, Q320)
  EC50  =        392 ng/ml    exposure at half of the maximal effect term (EC50, Q321)
  gamma =        3.1          Hill coefficient (nH, Q325)</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep\">SigmoidEmaxSweep</a>; this model only supplies the numbers. The x axis is one ng/ml of tiagabine per second of simulated time (exposure is in kg/m3): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0   (drug-free)
  exposure = EC50 (392 ng/ml)  response 163.5
  exposure -> infinity  response 327</pre></body></html>"));
end Tiagabine_Jonker2003v2_PD_eeg;
