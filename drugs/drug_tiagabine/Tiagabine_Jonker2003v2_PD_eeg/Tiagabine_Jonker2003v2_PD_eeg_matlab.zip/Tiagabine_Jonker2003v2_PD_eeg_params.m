function p = Tiagabine_Jonker2003v2_PD_eeg_params()
% Tiagabine_Jonker2003v2_PD_eeg_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% tiagabine Jonker_2003_2::EEG: sigmoid_emax exposure-response sweep (response = E0 + Emax*frac). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one ng/ml per second, in SI inside (kg/m3, s). Response EEG in microV. Driver: tiagabine (cited_pk).
p.E0 = 0.0;
p.Emax = 327.0;
p.EC50 = 0.000392;
p.gamma = 3.1;
p.slope = 0.0;
p.exposure_per_s = 1e-06;
p.stop_time = 4000.0;
p.form = 'E0 + Emax*frac';
end
