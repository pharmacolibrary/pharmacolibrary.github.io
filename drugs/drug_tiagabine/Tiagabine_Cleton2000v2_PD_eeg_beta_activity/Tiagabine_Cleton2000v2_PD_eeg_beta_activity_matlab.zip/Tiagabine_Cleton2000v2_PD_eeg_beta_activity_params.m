function p = Tiagabine_Cleton2000v2_PD_eeg_beta_activity_params()
% Tiagabine_Cleton2000v2_PD_eeg_beta_activity_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% tiagabine Cleton_2000_2::EEG_beta_activity: sigmoid_emax exposure-response sweep (response = E0 + Emax*frac). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one ng ml(-1) per second, in SI inside (kg/m3, s). Response EEG beta activity in microV. Driver: tiagabine (cited_pk).
p.E0 = 0.0;
p.Emax = 82.0;
p.EC50 = 0.000486;
p.gamma = 2.0;
p.slope = 0.0;
p.exposure_per_s = 1e-06;
p.stop_time = 4900.0;
p.form = 'E0 + Emax*frac';
end
