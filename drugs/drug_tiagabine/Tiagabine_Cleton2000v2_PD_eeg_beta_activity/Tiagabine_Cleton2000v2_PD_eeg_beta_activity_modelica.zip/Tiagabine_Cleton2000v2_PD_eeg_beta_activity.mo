model Tiagabine_Cleton2000v2_PD_eeg_beta_activity
  "sigmoid_emax exposure-response sweep — Cleton_2000_2 :: EEG beta activity (increase in beta activity (11.5-30 Hz) of the EEG)"
  extends Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep(
    E0 = 0,      // [1]
    Emax = 82,  // [microV]
    EC50 = 0.000486,  // [kg/m3; ng ml(-1) × 1e-06]
    gamma = 2,
    exposure_per_s = 1e-06);   // 1 ng ml(-1) per second
  // defaulted: E0
  annotation(experiment(StartTime = 0, StopTime = 4900, Interval = 9.8),
    Documentation(info = "<html><body><!-- drug-about --><h4>About tiagabine</h4><p>Tiagabine is an anticonvulsant used to treat focal epilepsy and has also been studied for bipolar disorder. It is an approved medicine, though not authorised in the European Union, and remains under investigation for other uses.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q907219\">Wikidata Q907219</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h4>Tiagabine_Cleton2000v2_PD_eeg_beta_activity</h4><p>The steady-state exposure-response curve of Cleton A et al., <i>European journal of pharmaceutical sciences : official journal of the European Federation for Pharmaceutical Sciences 12(2):141–150</i> 2000 (<a href=\"https://doi.org/10.1016/s0928-0987(00)00179-2\">doi:10.1016/s0928-0987(00)00179-2</a>) — increase in beta activity (11.5-30 Hz) of the EEG [microV] against tiagabine ng ml(-1) — obtained by sweeping the driver instead of simulating a dose. Model family: sigmoid_emax.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = (library default) drug-free response (baseline)
  Emax  =         82 microV   maximal effect term (maximum EEG effect, Q320)
  EC50  =        486 ng ml(-1) exposure at half of the maximal effect term (EC(50), Q321)
  gamma =          2          Hill coefficient (Hill factor, Q325)</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep\">SigmoidEmaxSweep</a>; this model only supplies the numbers. The x axis is one ng ml(-1) of tiagabine per second of simulated time (exposure is in kg/m3): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0   (drug-free)
  exposure = EC50 (486 ng ml(-1))  response 41
  exposure -> infinity  response 82</pre></body></html>"));
end Tiagabine_Cleton2000v2_PD_eeg_beta_activity;
