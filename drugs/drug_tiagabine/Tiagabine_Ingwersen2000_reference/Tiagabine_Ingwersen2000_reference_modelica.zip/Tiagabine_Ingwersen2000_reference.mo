model Tiagabine_Ingwersen2000_reference
  parameter Real Cl_ref = 1.6944444444444442e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.062 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.375548,
    adminMass = 3e-05,
    ka = 0.0001388888888888889,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About tiagabine</h4><p>Tiagabine is an anticonvulsant used to treat focal epilepsy and has also been studied for bipolar disorder. It is an approved medicine, though not authorised in the European Union, and remains under investigation for other uses.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q907219\">Wikidata Q907219</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>tiagabine</td></tr><tr><td>population:</td><td>adults with epilepsy on monotherapy</td></tr><tr><td>source_paper:</td><td>Ingwersen_2000</td></tr><tr><td>measured_compound:</td><td>tiagabine</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C_enteral: apparent (/F) parameterization ⇒ extravascular dosing</td></tr><tr><td>molar_masses:</td><td>tiagabine 375.548 g/mol (drugbank)</td></tr></table><p><b>Defaulted (base-class default used):</b> ka, Tlag.</p><h4>Interpretation flags</h4><ul><li>dropped unlinked row (NIL): 'height' — extend the ontology if this is a real PK parameter (source ['Ingwersen_2000:abstract'])</li><li>apparent-ness (ontology-grounded): parameterization=apparent, measured_compound=tiagabine</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary's parameterization (rate-constant / ka-only) does not use it</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 104400, Tolerance = 1e-9, Interval = 1));
end Tiagabine_Ingwersen2000_reference;
