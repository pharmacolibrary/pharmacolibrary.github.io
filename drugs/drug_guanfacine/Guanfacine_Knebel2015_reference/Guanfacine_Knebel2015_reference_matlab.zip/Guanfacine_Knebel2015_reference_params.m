function p = Guanfacine_Knebel2015_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: guanfacine   source: Knebel_2015 / reference   route: oral
  p.name  = 'Guanfacine_Knebel2015_reference_params';
  p.drug  = 'guanfacine';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 804.0;                % central volume [L]
  p.CL = 33.1;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.552;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.651;             % absorption lag [h]
  p.dose = 3.0;             % dose [mg]
end
