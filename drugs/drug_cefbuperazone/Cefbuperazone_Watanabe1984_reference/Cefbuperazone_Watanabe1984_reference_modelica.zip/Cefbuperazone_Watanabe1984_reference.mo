model Cefbuperazone_Watanabe1984_reference
  parameter Real Cl_ref = 1.2666666666666665e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.004059999999999999 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.6276499999999999,
    adminMass = 0.002
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About cefbuperazone</h4><p>Cefbuperazone is a second-generation cephalosporin antibiotic used to treat bacterial infections. It is not an authorised medicine in the European Union and appears to be little used today.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q5057221\">Wikidata Q5057221</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>cefbuperazone</td></tr><tr><td>population:</td><td>patients undergoing postoperative drainage</td></tr><tr><td>source_paper:</td><td>Watanabe_1984</td></tr><tr><td>measured_compound:</td><td>cefbuperazone</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>cefbuperazone 627.65 g/mol (drugbank)</td></tr></table><h4>Interpretation flags</h4><ul><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=cefbuperazone</li><li>structure disagreement: deterministic 1C vs LLM 2C — review compartment count</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Cefbuperazone_Watanabe1984_reference;
