model Levothyroxine_Meng2019_PD_ft4
  "indirect_response_i exposure-response sweep — Meng_2019 :: FT4 (free thyroxine)"
  extends Pharmacolibrary.Interfaces.PartialExposureResponseSweep(
    E0 = 0.0,      // [1]
    Emax = 1.0,  // type I effect term
    EC50 = 5.8151e-05,  // [kg; mg × 1e-06]
    gamma = 1.0,
    exposure_per_s = 1e-06);   // 1 mg per second
equation
  response = E0*(1 - Emax*frac);   // steady state, indirect response type I
  // defaulted: E0
  // defaulted: Emax
  // defaulted: gamma
  annotation(experiment(StartTime = 0, StopTime = 581.51, Interval = 1.16302));
end Levothyroxine_Meng2019_PD_ft4;
