function p = Levothyroxine_Meng2019_PD_ft4_params()
% Levothyroxine_Meng2019_PD_ft4_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% levothyroxine Meng_2019::FT4: indirect_response_i exposure-response sweep (response = E0*(1 - Emax*frac)). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one mg per second, in SI inside (kg/m3, s). Response FT4 in pmol l−1. Driver: anti-thyroid drug (ATD) (dose_only).
p.E0 = 0.0;
p.Emax = 1.0;
p.EC50 = 5.8151e-05;
p.gamma = 1.0;
p.slope = 0.0;
p.exposure_per_s = 1e-06;
p.stop_time = 581.51;
p.form = 'E0*(1 - Emax*frac)';
end
