function p = Hydrocortisone_Hamitouche2017_PD_na_k_params()
% Hydrocortisone_Hamitouche2017_PD_na_k_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% hydrocortisone Hamitouche_2017::Na_K: indirect_response_i exposure-response sweep (response = E0*(1 - Emax*frac)). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one μg/L per second, in SI inside (kg/m3, s). Response Na/K in its own unit. Driver: hydrocortisone (conc_no_pk).
p.E0 = 0.0;
p.Emax = 1.0;
p.EC50 = 1.6699999999999996e-05;
p.gamma = 1.0;
p.slope = 0.0;
p.exposure_per_s = 1e-06;
p.stop_time = 170.0;
p.form = 'E0*(1 - Emax*frac)';
end
