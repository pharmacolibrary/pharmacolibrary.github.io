model Artemisinin_Birgersson2016_reference
  parameter Real Cl_ref = 0.00011583333333333333 "Cl [m3/s]";
  parameter Real Vd_ref = 1.21 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.28233600000000003,
    adminMass = 0.00016,
    ka = 0.0001388888888888889,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About artemisinin</h4><p>Artemisinin is an antimalarial drug used to treat malaria. It is considered investigational and is not an approved medicine in the European Union.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q426921\">Wikidata Q426921</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>artemisinin</td></tr><tr><td>population:</td><td>healthy male Vietnamese volunteers</td></tr><tr><td>source_paper:</td><td>Birgersson_2016</td></tr><tr><td>measured_compound:</td><td>artemisinin</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>Tab2</td></tr><tr><td>input:</td><td>PK_1C_enteral: apparent (/F) parameterization ⇒ extravascular dosing</td></tr><tr><td>molar_masses:</td><td>artemisinin 282.336 g/mol (drugbank)</td></tr></table><p><b>Defaulted (base-class default used):</b> ka, Tlag.</p><h4>Interpretation flags</h4><ul><li>table section iiv: 'F (%)' routed out of structural estimates ('IIV/IOV* CV % (RSE %)')</li><li>dropped value-less row: 'CL/F'</li><li>dropped value-less row: 'V/F'</li><li>dropped value-less row: 'MTT'</li><li>dropped value-less row: 'RSE'</li><li>dropped value-less row: 'CV %'</li><li>dropped value-less row: '95 % CI'</li><li>apparent-ness (ontology-grounded): parameterization=apparent, measured_compound=artemisinin</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Artemisinin_Birgersson2016_reference;
