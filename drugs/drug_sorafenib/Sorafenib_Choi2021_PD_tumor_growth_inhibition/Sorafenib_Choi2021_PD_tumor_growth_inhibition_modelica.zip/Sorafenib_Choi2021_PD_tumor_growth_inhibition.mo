model Sorafenib_Choi2021_PD_tumor_growth_inhibition
  "linear exposure-response sweep — Choi_2021 :: tumor-growth inhibition (tumor-growth inhibition)"
  extends Pharmacolibrary.Interfaces.PartialExposureResponseSweep(
    E0 = 0.0415,      // [cm3]
    Emax = 0, EC50 = 1,      // unused by a line
    exposure_per_s = 1);
  parameter Real slope = 0.0267   "[l/mg per day]";
equation
  response = E0 + slope*exposure;
  // family_inferred: the record's model family is transduction; read from the parameters: a slope and no Emax — linear
  annotation(experiment(StartTime = 0, StopTime = 1000, Interval = 2),
    Documentation(info = "<html><body><!-- drug-about --><h4>About sorafenib</h4><p>Sorafenib is an anticancer protein kinase inhibitor used to treat liver cancer (hepatocellular carcinoma) and kidney cancer (renal cell carcinoma), and it has also been studied for other cancers such as thyroid cancer and acute myeloid leukemia. It is authorised in the European Union and widely used in cancer care.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q421136\">Wikidata Q421136</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h4>Sorafenib_Choi2021_PD_tumor_growth_inhibition</h4><p>The steady-state exposure-response curve of Choi YH et al., <i>The Journal of pharmacology and experimental therapeutics 377(3):305–315</i> 2021 (<a href=\"https://doi.org/10.1124/jpet.121.000584\">doi:10.1124/jpet.121.000584</a>) — tumor-growth inhibition [cm3] against Sor milligram per liter — obtained by sweeping the driver instead of simulating a dose. Model family: linear.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    =     0.0415 cm3      drug-free response (baseline) (w0 (initial tumor volume prior to administration), Q324)
  slope =     0.0267 l/mg per day change in response per unit of exposure (k2 (potency of the drug), Q335)</pre><p>The algebra is <code>response = E0 + slope*exposure</code>; this model only supplies the numbers. The x axis is one milligram per liter of Sor per second of simulated time: there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0.0415   (drug-free)</pre></body></html>"));
end Sorafenib_Choi2021_PD_tumor_growth_inhibition;
