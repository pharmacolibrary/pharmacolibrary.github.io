function p = Sorafenib_Choi2021_PD_tumor_growth_inhibition_params()
% Sorafenib_Choi2021_PD_tumor_growth_inhibition_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% sorafenib Choi_2021::tumor_growth_inhibition: linear exposure-response sweep (response = E0 + slope*exposure). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one milligram per liter per second, in SI inside (kg/m3, s). Response tumor-growth inhibition in cm3. Driver: Sor (not_resolved).
p.E0 = 0.0415;
p.Emax = 0.0;
p.EC50 = 1.0;
p.gamma = 1.0;
p.slope = 0.0267;
p.exposure_per_s = 1.0;
p.stop_time = 1000.0;
p.form = 'E0 + slope*exposure';
end
