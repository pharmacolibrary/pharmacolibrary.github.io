% run_Sorafenib_Choi2021_PD_tumor_growth_inhibition  Evaluate the exposure-response curve and plot response against exposure.
% A sweep is a static map: no ODE solver is needed. exposure runs 0..stop_time*exposure_per_s.
p = Sorafenib_Choi2021_PD_tumor_growth_inhibition_params();
exposure = linspace(0, p.stop_time * p.exposure_per_s, 501);
frac = exposure.^p.gamma ./ (p.EC50^p.gamma + exposure.^p.gamma);
E0 = p.E0; Emax = p.Emax; slope = p.slope;
response = E0 + slope.*exposure;
figure; plot(exposure, response, 'LineWidth', 1.5); grid on;
xlabel('exposure [milligram per liter]'); ylabel('response [cm3]'); title('Sorafenib_Choi2021_PD_tumor_growth_inhibition', 'Interpreter', 'none');
writematrix([exposure(:) response(:)], 'Sorafenib_Choi2021_PD_tumor_growth_inhibition.csv');
