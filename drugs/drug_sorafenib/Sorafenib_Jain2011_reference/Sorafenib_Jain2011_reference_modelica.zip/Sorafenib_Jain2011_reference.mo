model Sorafenib_Jain2011_reference
  parameter Real Cl_ref = 2.258333333333334e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.213 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.464825,
    adminMass = 1e-05
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About sorafenib</h4><p>Sorafenib is an anticancer protein kinase inhibitor used to treat liver cancer (hepatocellular carcinoma) and kidney cancer (renal cell carcinoma), and it has also been studied for other cancers such as thyroid cancer and acute myeloid leukemia. It is authorised in the European Union and widely used in cancer care.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q421136\">Wikidata Q421136</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>sorafenib</td></tr><tr><td>population:</td><td>patients with solid tumours</td></tr><tr><td>source_paper:</td><td>Jain_2011</td></tr><tr><td>measured_compound:</td><td>sorafenib</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>sorafenib 464.825 g/mol (drugbank)</td></tr></table><h4>Interpretation flags</h4><ul><li>dropped unlinked row (NIL): 'fraction undergoing EHC' — extend the ontology if this is a real PK parameter (source ['Jain_2011:abstract'])</li><li>dropped duplicate Q81 ('average time to gall bladder emptying', value '6.13') — already have one for this compound</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=sorafenib</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 345600, Tolerance = 1e-9, Interval = 1));
end Sorafenib_Jain2011_reference;
