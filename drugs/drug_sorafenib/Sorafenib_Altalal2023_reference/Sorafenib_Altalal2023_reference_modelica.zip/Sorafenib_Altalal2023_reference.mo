model Sorafenib_Altalal2023_reference
  parameter Real Cl_ref = 3.5000000000000004e-05 "Cl [m3/s]";
  parameter Real Vd_ref = 9.288936290267682 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.464825,
    adminMass = 0.0008,
    ka = 0.0001388888888888889,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About sorafenib</h4><p>Sorafenib is an anticancer protein kinase inhibitor used to treat liver cancer (hepatocellular carcinoma) and kidney cancer (renal cell carcinoma), and it has also been studied for other cancers such as thyroid cancer and acute myeloid leukemia. It is authorised in the European Union and widely used in cancer care.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q421136\">Wikidata Q421136</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>sorafenib</td></tr><tr><td>population:</td><td>review reference</td></tr><tr><td>source_paper:</td><td>Altalal_2023</td></tr><tr><td>measured_compound:</td><td>sorafenib</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C_enteral: apparent (/F) parameterization ⇒ extravascular dosing</td></tr><tr><td>molar_masses:</td><td>sorafenib 464.825 g/mol (drugbank)</td></tr></table><p><b>Defaulted (base-class default used):</b> ka, Tlag.</p><h4>Interpretation flags</h4><ul><li>built from REVIEW reference values (Altalal_2023) — secondary source</li><li>central volume derived from CL·t½/ln2</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 950400, Tolerance = 1e-9, Interval = 1));
end Sorafenib_Altalal2023_reference;
