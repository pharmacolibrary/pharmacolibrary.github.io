model Sorafenib_Huh2021_syo_1644_100_mg
  parameter Real Cl_ref = 9.25e-07 "Cl [m3/s]";
  parameter Real Vd_ref = 0.00817 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.464825,
    adminMass = 0.0001
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About sorafenib</h4><p>Sorafenib is an anticancer protein kinase inhibitor used to treat liver cancer (hepatocellular carcinoma) and kidney cancer (renal cell carcinoma), and it has also been studied for other cancers such as thyroid cancer and acute myeloid leukemia. It is authorised in the European Union and widely used in cancer care.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q421136\">Wikidata Q421136</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>sorafenib</td></tr><tr><td>population:</td><td>healthy volunteers</td></tr><tr><td>source_paper:</td><td>Huh_2021</td></tr><tr><td>measured_compound:</td><td>sorafenib</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>pharmaceutics-13-00629-t002</td></tr><tr><td>input:</td><td>PK_1C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>sorafenib 464.825 g/mol (drugbank)</td></tr></table><h4>Interpretation flags</h4><ul><li>dropped unlinked row (NIL): 'Total CV (%)' — extend the ontology if this is a real PK parameter (source ['Huh_2021_table_1:row1:col1', 'Huh_2021_table_1:row3:col1'])</li><li>salvaged Q61 ('Volume of distribution (V)'=8.17) from results prose — parameter table was unreadable</li><li>salvaged Q22 ('clearance (CL) in the central compartment'=3.33) from results prose — parameter table was unreadable</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=sorafenib</li><li>held at status:extracted — NIL link or unit issue (mismatch/unknown/normalisation-failed) present</li><li>status held at route_to_review — not promoted</li><li>population split: 'syo-1644 100 mg(n = 7)' subgroup of Huh_2021 (paper reports 5 populations: nexavar® 200 mg(n = 8), parameter estimates(relative standard error, %), syo-1644 100 mg(n = 7), syo-1644 150 mg(n = 7), syo-1644 200 mg(n = 8))</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 432000, Tolerance = 1e-9, Interval = 1));
end Sorafenib_Huh2021_syo_1644_100_mg;
