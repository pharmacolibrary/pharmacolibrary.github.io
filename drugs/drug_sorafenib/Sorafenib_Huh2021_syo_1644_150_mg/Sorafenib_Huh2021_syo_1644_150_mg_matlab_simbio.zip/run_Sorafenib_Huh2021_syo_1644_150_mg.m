% Run (SimBiology): build model + dose, simulate 0..144.0 h, plot.
p = Sorafenib_Huh2021_syo_1644_150_mg_params();
[model, dose, variant] = build_sb_pk(p);
sd = simulate_sb(model, variant, dose, 144.0);
