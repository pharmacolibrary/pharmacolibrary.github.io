function p = Captopril_Kiriyama2024_PD_qt_params()
% Captopril_Kiriyama2024_PD_qt_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% captopril Kiriyama_2024::QT: sigmoid_emax exposure-response sweep (response = E0 + Emax*frac). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one ng/mL per second, in SI inside (kg/m3, s). Response QT in msec. Driver: captopril (pk_record).
p.E0 = 0.08120000000000001;
p.Emax = 0.0419;
p.EC50 = 0.004873;
p.gamma = 0.1347;
p.slope = 0.0;
p.exposure_per_s = 1e-06;
p.stop_time = 49000.0;
p.form = 'E0 + Emax*frac';
end
