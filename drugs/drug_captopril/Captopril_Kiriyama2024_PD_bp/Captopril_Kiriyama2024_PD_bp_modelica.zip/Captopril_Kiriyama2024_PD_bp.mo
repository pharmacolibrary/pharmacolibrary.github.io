model Captopril_Kiriyama2024_PD_bp
  "sigmoid_emax exposure-response sweep — Kiriyama_2024 :: BP (blood pressure)"
  extends Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep(
    E0 = 105,      // [mmHg]
    Emax = -41.8,  // [mmHg]
    EC50 = 0.007885,  // [kg/m3; ng/mL × 1e-06]
    gamma = 0.662,
    exposure_per_s = 1e-06);   // 1 ng/mL per second
  // imax_as_negative_emax: Imax (Q323) enters SigmoidEmaxSweep as −Emax
  annotation(experiment(StartTime = 0, StopTime = 79000, Interval = 158),
    Documentation(info = "<html><body><!-- drug-about --><h4>About captopril</h4><p>Captopril is an ACE inhibitor used to treat high blood pressure and congestive heart failure, and has also been used for conditions such as Raynaud disease and rheumatoid arthritis. It is an approved medicine and remains in use, generally as an oral antihypertensive, though it carries a boxed warning.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q421119\">Wikidata Q421119</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h4>Captopril_Kiriyama2024_PD_bp</h4><p>The steady-state exposure-response curve of Kiriyama A et al., <i>Pharmacology research &amp; perspectives 12(4):e1249</i> 2024 (<a href=\"https://doi.org/10.1002/prp2.1249\">doi:10.1002/prp2.1249</a>) — blood pressure [mmHg] against captopril ng/mL — obtained by sweeping the driver instead of simulating a dose. Model family: sigmoid_emax.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    =        105 mmHg     drug-free response (baseline) (E0, Q324)
  Emax  =       41.8 mmHg     maximal effect term (Emax, Q323)
  EC50  =       7885 ng/mL    exposure at half of the maximal effect term (EC50, Q321)
  gamma =      0.662          Hill coefficient (γ, Q325)</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep\">SigmoidEmaxSweep</a>; this model only supplies the numbers. The x axis is one ng/mL of captopril per second of simulated time (exposure is in kg/m3): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 105   (drug-free)
  exposure = EC50 (7885 ng/mL)  response 84.1
  exposure -> infinity  response 63.2</pre></body></html>"));
end Captopril_Kiriyama2024_PD_bp;
