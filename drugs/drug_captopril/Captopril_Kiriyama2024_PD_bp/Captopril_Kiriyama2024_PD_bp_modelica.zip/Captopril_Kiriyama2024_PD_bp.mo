model Captopril_Kiriyama2024_PD_bp
  "indirect_response_i exposure-response sweep — Kiriyama_2024 :: BP (blood pressure)"
  extends Pharmacolibrary.Interfaces.PartialExposureResponseSweep(
    E0 = 96.8,      // [mmHg]
    Emax = 0.0117,  // type I effect term
    EC50 = 8.63e-05,  // [kg/m3; ng/mL × 1e-06]
    gamma = 0.662,
    exposure_per_s = 1e-06);   // 1 ng/mL per second
equation
  response = E0*(1 - Emax*frac);   // steady state, indirect response type I
  annotation(experiment(StartTime = 0, StopTime = 870, Interval = 1.74),
    Documentation(info = "<html><body><h4>Captopril_Kiriyama2024_PD_bp</h4><p>The steady-state exposure-response curve of Kiriyama A et al., <i>Pharmacology research &amp; perspectives 12(4):e1249</i> 2024 (<a href=\"https://doi.org/10.1002/prp2.1249\">doi:10.1002/prp2.1249</a>) — blood pressure [mmHg] against nifedipine and captopril (parent plasma concentrations; no metabolite driver) ng/mL — obtained by sweeping the driver instead of simulating a dose. Model family: indirect_response_i.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    =       96.8 mmHg     drug-free response (baseline) (E0 — BP, Q324)
  Emax  =     0.0117          maximal effect term (Nifedipine — QT, Q320)
  EC50  =       86.3 ng/mL    exposure at half of the maximal effect term (EC50,1 — BP, Q321)
  gamma =      0.662          Hill coefficient (γ — BP, Q325)</pre><p>The algebra is <code>response = E0*(1 - Emax*frac)</code>; this model only supplies the numbers. The x axis is one ng/mL of nifedipine and captopril (parent plasma concentrations; no metabolite driver) per second of simulated time (exposure is in kg/m3): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 96.8   (drug-free)
  exposure = EC50 (86.3 ng/mL)  response 96.23
  exposure -> infinity  response 95.67</pre></body></html>"));
end Captopril_Kiriyama2024_PD_bp;
