function p = Captopril_Kiriyama2024_PD_bp_params()
% Captopril_Kiriyama2024_PD_bp_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% captopril Kiriyama_2024::BP: indirect_response_i exposure-response sweep (response = E0*(1 - Emax*frac)). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one ng/mL per second, in SI inside (kg/m3, s). Response BP in mmHg. Driver: nifedipine and captopril (parent plasma concentrations; no metabolite driver) (conc_no_pk).
p.E0 = 96.8;
p.Emax = 0.0117;
p.EC50 = 8.63e-05;
p.gamma = 0.662;
p.slope = 0.0;
p.exposure_per_s = 1e-06;
p.stop_time = 870.0;
p.form = 'E0*(1 - Emax*frac)';
end
