function p = Captopril_Kiriyama2024_PD_bp_params()
% Captopril_Kiriyama2024_PD_bp_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% captopril Kiriyama_2024::BP: sigmoid_emax exposure-response sweep (response = E0 + Emax*frac). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one ng/mL per second, in SI inside (kg/m3, s). Response BP in mmHg. Driver: captopril (pk_record).
p.E0 = 105.0;
p.Emax = -41.8;
p.EC50 = 0.007885;
p.gamma = 0.662;
p.slope = 0.0;
p.exposure_per_s = 1e-06;
p.stop_time = 79000.0;
p.form = 'E0 + Emax*frac';
end
