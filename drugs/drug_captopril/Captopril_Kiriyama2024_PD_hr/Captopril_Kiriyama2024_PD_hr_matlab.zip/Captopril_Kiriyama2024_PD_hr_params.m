function p = Captopril_Kiriyama2024_PD_hr_params()
% Captopril_Kiriyama2024_PD_hr_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% captopril Kiriyama_2024::HR: sigmoid_emax exposure-response sweep (response = E0 + Emax*frac). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one ng/mL per second, in SI inside (kg/m3, s). Response HR in beat/min. Driver: captopril (pk_record).
p.E0 = 312.8;
p.Emax = -80.4;
p.EC50 = 7.599999999999999e-06;
p.gamma = 1.4;
p.slope = 0.0;
p.exposure_per_s = 1e-06;
p.stop_time = 76.0;
p.form = 'E0 + Emax*frac';
end
