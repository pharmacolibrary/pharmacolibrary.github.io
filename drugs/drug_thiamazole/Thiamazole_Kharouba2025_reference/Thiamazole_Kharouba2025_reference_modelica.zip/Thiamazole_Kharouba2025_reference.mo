model Thiamazole_Kharouba2025_reference
  parameter Real Cl_ref = 9.722222222222222e-07 "Cl [m3/s]";
  parameter Real Vd_ref = 0.029286709330045957 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.114166,
    adminMass = 1e-05
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About thiamazole</h4><p>Thiamazole (methimazole) is an antithyroid medicine used to treat hyperthyroidism, goiter, and thyroid crisis. It is an approved drug and remains in use as a systemic antithyroid preparation.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q419663\">Wikidata Q419663</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>thiamazole</td></tr><tr><td>population:</td><td>review reference</td></tr><tr><td>source_paper:</td><td>Kharouba_2025</td></tr><tr><td>measured_compound:</td><td>thiamazole</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>thiamazole 114.166 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>built from REVIEW reference values (Kharouba_2025) — secondary source</li><li>central volume derived from CL·t½/ln2</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 104400, Tolerance = 1e-9, Interval = 1));
end Thiamazole_Kharouba2025_reference;
