function p = Linagliptin_Retlich2015_PD_dpp_4_params()
% Linagliptin_Retlich2015_PD_dpp_4_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% linagliptin Retlich_2015::DPP_4: sigmoid_emax exposure-response sweep (response = E0 + Emax*frac). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one nmol/L per second, in SI inside (kg/m3, s). Response DPP-4 in its own unit. Driver: linagliptin (pk_record).
p.E0 = 0.0;
p.Emax = -92.4;
p.EC50 = 3.06e-06;
p.gamma = 3.22;
p.slope = 0.0;
p.exposure_per_s = 1e-06;
p.stop_time = 31.0;
p.form = 'E0 + Emax*frac';
end
