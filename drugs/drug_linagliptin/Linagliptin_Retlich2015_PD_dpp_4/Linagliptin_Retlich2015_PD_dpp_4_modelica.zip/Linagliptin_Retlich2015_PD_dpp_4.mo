model Linagliptin_Retlich2015_PD_dpp_4
  "sigmoid_emax exposure-response sweep — Retlich_2015 :: DPP-4 (DPP-4 activity)"
  extends Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep(
    E0 = 0,      // [1]
    Emax = -92.4,  // [1]
    EC50 = 3.06e-06,  // [mol/m3; nmol/L × 1e-06]
    gamma = 3.22,
    exposure_per_s = 1e-06);   // 1 nmol/L per second
  // inhibition_sign: effect_direction=inhibition with a positive Emax (Q320) — sign flipped
  // defaulted: E0
  annotation(experiment(StartTime = 0, StopTime = 31, Interval = 0.062),
    Documentation(info = "<html><body><h4>Linagliptin_Retlich2015_PD_dpp_4</h4><p>The steady-state exposure-response curve of Retlich S et al., <i>Clinical pharmacokinetics 54(7):737–750</i> 2015 (<a href=\"https://doi.org/10.1007/s40262-014-0232-4\">doi:10.1007/s40262-014-0232-4</a>) — DPP-4 activity against linagliptin nmol/L — obtained by sweeping the driver instead of simulating a dose. Model family: sigmoid_emax.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = (library default) drug-free response (baseline)
  Emax  =       92.4          maximal effect term (E max (%) — Value, Q320)
  EC50  =       3.06 nmol/L   exposure at half of the maximal effect term (EC50 (nmol/L) — Value, Q321)
  gamma =       3.22          Hill coefficient (HILL — Value, Q325)</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep\">SigmoidEmaxSweep</a>; this model only supplies the numbers. The x axis is one nmol/L of linagliptin per second of simulated time (exposure is in mol/m3): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0   (drug-free)
  exposure = EC50 (3.06 nmol/L)  response -46.2
  exposure -> infinity  response -92.4</pre></body></html>"));
end Linagliptin_Retlich2015_PD_dpp_4;
