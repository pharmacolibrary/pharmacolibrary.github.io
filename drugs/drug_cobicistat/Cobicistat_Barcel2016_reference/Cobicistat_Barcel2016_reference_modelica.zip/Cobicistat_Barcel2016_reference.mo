model Cobicistat_Barcel2016_reference
  parameter Real Cl_ref = 2.111111111111111e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.061 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 0.9,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.77603,
    adminMass = 0.00015,
    ka = 8.499999999999999e-05,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About cobicistat</h4><p>Cobicistat is an anti-HIV medicine used in the treatment of HIV infection, where it acts as a booster that inhibits the CYP3A enzyme to raise levels of other antiviral drugs. It is authorised in the European Union and is used in combination antiviral products for HIV.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q5138908\">Wikidata Q5138908</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>cobicistat</td></tr><tr><td>population:</td><td>HIV-1-infected individuals</td></tr><tr><td>source_paper:</td><td>Barceló_2016</td></tr><tr><td>measured_compound:</td><td>cobicistat</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>cobicistat 776.03 g/mol (drugbank)</td></tr></table><p><b>Defaulted (base-class default used):</b> F, Tlag.</p><h4>Interpretation flags</h4><ul><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=cobicistat</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li><li>gap-filled Q49 (kabs) from Courlet_2021's review values (primary lacked it)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 136800, Tolerance = 1e-9, Interval = 1));
end Cobicistat_Barcel2016_reference;
