% Run: build params, simulate 0..38.0 h, plot + save Cobicistat_Barcel2016_reference.png/.csv/.json.
% Interactive display (keep the window open):  octave --persist run_Cobicistat_Barcel2016_reference.m
here = fileparts(mfilename('fullpath'));
p = Cobicistat_Barcel2016_reference_params();
out = simulate_pk(p, 0:0.05:38.0);

% figure (shown on screen if interactive) and PNG (works in MATLAB and Octave)
fig = figure; plot(out.t, out.C, 'LineWidth', 1.5); grid on;
xlabel('time [h]'); ylabel('central concentration [mg/L]');
title('cobicistat — Barceló_2016 (oral)');
print(fig, fullfile(here, 'Cobicistat_Barcel2016_reference.png'), '-dpng', '-r150');

% CSV (time_h, Cc_mg_per_L)
fid = fopen(fullfile(here, 'Cobicistat_Barcel2016_reference.csv'), 'w');
fprintf(fid, 'time_h,Cc_mg_per_L\n');
fprintf(fid, '%.10g,%.10g\n', [out.t(:), out.C(:)].');
fclose(fid);

% JSON (summary + arrays; jsonencode with a manual fallback for older versions)
fid = fopen(fullfile(here, 'Cobicistat_Barcel2016_reference.json'), 'w');
try
  s.model = 'Cobicistat_Barcel2016_reference'; s.Cmax = out.Cmax; s.Tmax = out.Tmax; s.AUC = out.AUC;
  s.time_h = out.t(:).'; s.Cc_mg_per_L = out.C(:).';
  fprintf(fid, '%s', jsonencode(s));
catch
  fprintf(fid, '{"model":"Cobicistat_Barcel2016_reference","Cmax":%g,"Tmax":%g,"AUC":%g}', out.Cmax, out.Tmax, out.AUC);
end
fclose(fid);

fprintf('Cmax=%.3g mg/L  Tmax=%.3g h  AUC=%.3g mg*h/L\n', out.Cmax, out.Tmax, out.AUC);
fprintf('wrote Cobicistat_Barcel2016_reference.png, Cobicistat_Barcel2016_reference.csv, Cobicistat_Barcel2016_reference.json\n');
