function p = Cobicistat_Barcel2016_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: cobicistat   source: Barceló_2016 / reference   route: oral
  % estimated (absent from source): F
  p.name  = 'Cobicistat_Barcel2016_reference_params';
  p.drug  = 'cobicistat';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 61.0;                % central volume [L]
  p.CL = 7.6;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.306;                % absorption rate [1/h]
  p.F  = 0.9;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 150.0;             % dose [mg]
end
