function p = Piperaquine_Chotsiri2021_population_estimatec_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: piperaquine   source: Chotsiri_2021 / population_estimatec   route: oral
  % estimated (absent from source): ka
  p.name  = 'Piperaquine_Chotsiri2021_population_estimatec_params';
  p.drug  = 'piperaquine';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 2190.0;                % central volume [L]
  p.CL = 49.0;                % clearance [L/h]
  p.Vp = [3270.0];             % peripheral volumes [L]
  p.Q  = [244.0];             % inter-compartmental clearances [L/h]
  p.ka = 0.5;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 320.0;             % dose [mg]
end
