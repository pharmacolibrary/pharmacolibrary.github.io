model Piperaquine_Chotsiri2021_population_estimatec
  parameter Real Cl_ref = 1.3611111111111111e-05 "Cl [m3/s]";
  parameter Real Vd_ref = 2.19 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.53552,
    adminMass = 0.00032,
    ka = 0.0001388888888888889,
    Tlag = 0.0,
    k12 = 3.094875697615424e-05,
    k21 = 2.072714916751614e-05
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About piperaquine</h4><p>Piperaquine is an antimalarial drug used to treat malaria, typically in fixed combination with an artemisinin derivative. It is approved and used mainly in malaria-endemic regions as part of artemisinin-based combination therapy, though it is not authorised in the European Union.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q7197338\">Wikidata Q7197338</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>piperaquine</td></tr><tr><td>population:</td><td>pregnant women receiving IPTp with dihydroartemisinin-piperaquine</td></tr><tr><td>source_paper:</td><td>Chotsiri_2021</td></tr><tr><td>measured_compound:</td><td>piperaquine</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>T2</td></tr><tr><td>input:</td><td>PK_2C_enteral: apparent (/F) parameterization ⇒ extravascular dosing</td></tr><tr><td>molar_masses:</td><td>piperaquine 535.52 g/mol (drugbank)</td></tr></table><p><b>Defaulted (base-class default used):</b> ka, Tlag.</p><h4>Interpretation flags</h4><ul><li>table section iiv: 'CL/F (liters/h)' routed out of structural estimates ('Interindividual variability (%CV)')</li><li>table section iiv: 'VC/F (liters)' routed out of structural estimates ('Interindividual variability (%CV)')</li><li>table section iiv: 'Q2/F (liters/h)' routed out of structural estimates ('Interindividual variability (%CV)')</li><li>table section iov: 'MTT (h)' routed out of structural estimates ('Interoccasion variability (%CV)')</li><li>table section iov: 'F' routed out of structural estimates ('Interoccasion variability (%CV)')</li><li>dropped duplicate Q69 ('Q2/F (liters/h)', value '98.2') — already have one for this compound</li><li>apparent-ness (ontology-grounded): parameterization=apparent, measured_compound=piperaquine</li><li>structure disagreement: deterministic 2C vs LLM 3C — review compartment count</li><li>population split: 'population estimatec' subgroup of Chotsiri_2021 (paper reports 2 populations: population estimatec, prior estimateb)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 604800, Tolerance = 1e-9, Interval = 1));
end Piperaquine_Chotsiri2021_population_estimatec;
