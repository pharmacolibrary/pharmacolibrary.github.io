% Run (SimBiology): build model + dose, simulate 0..144.0 h, plot.
p = Piperaquine_Chotsiri2021_prior_estimateb_params();
[model, dose, variant] = build_sb_pk(p);
sd = simulate_sb(model, variant, dose, 144.0);
