model Piperaquine_Wattanakul2021_PD_pcir
  "sigmoid_emax exposure-response sweep — Wattanakul_2021 :: PCIR (total circulating parasites (P. falciparum parasite density))"
  extends Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep(
    E0 = 0,      // [1]
    Emax = -8.02777777778e-05,  // [1/s; h−1 × 0.000277778]
    EC50 = 5.43e-06,  // [kg/m3; ng/ml × 1e-06]
    gamma = 2.8,
    exposure_per_s = 1e-06);   // 1 ng/ml per second
  // imax_as_negative_emax: Imax (Q323) enters SigmoidEmaxSweep as −Emax
  // defaulted: E0
  annotation(experiment(StartTime = 0, StopTime = 55, Interval = 0.11),
    Documentation(info = "<html><body><!-- drug-about --><h4>About piperaquine</h4><p>Piperaquine is an antimalarial drug used to treat malaria, typically in fixed combination with an artemisinin derivative. It is approved and used mainly in malaria-endemic regions as part of artemisinin-based combination therapy, though it is not authorised in the European Union.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q7197338\">Wikidata Q7197338</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h4>Piperaquine_Wattanakul2021_PD_pcir</h4><p>The steady-state exposure-response curve of Wattanakul T et al., <i>Antimicrobial agents and chemotherapy 65(4)</i> 2021 (<a href=\"https://doi.org/10.1128/AAC.01583-20\">doi:10.1128/AAC.01583-20</a>) — total circulating parasites (P. falciparum parasite density) [parasites] against piperaquine ng/ml — obtained by sweeping the driver instead of simulating a dose. Model family: sigmoid_emax.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = (library default) drug-free response (baseline)
  Emax  =      0.289 h−1      maximal effect term (Emax, Q323)
  EC50  =       5.43 ng/ml    exposure at half of the maximal effect term (EC50, Q321)
  gamma =        2.8          Hill coefficient (γ, Q325)</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep\">SigmoidEmaxSweep</a>; this model only supplies the numbers. The x axis is one ng/ml of piperaquine per second of simulated time (exposure is in kg/m3): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0   (drug-free)
  exposure = EC50 (5.43 ng/ml)  response -4.014e-05
  exposure -> infinity  response -8.028e-05</pre></body></html>"));
end Piperaquine_Wattanakul2021_PD_pcir;
