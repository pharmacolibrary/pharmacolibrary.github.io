model Piperaquine_Patel2014_PD_parasite_density
  "indirect_response_i exposure-response sweep — Patel_2014 :: parasite density (parasite density)"
  extends Pharmacolibrary.Interfaces.PartialExposureResponseSweep(
    E0 = 0,      // [1]
    Emax = 1,  // type I effect term
    EC50 = 1.68e-05,  // [kg/m3; μg/L × 1e-06]
    gamma = 1,
    exposure_per_s = 1e-06);   // 1 μg/L per second
equation
  response = E0*(1 - Emax*frac);   // steady state, indirect response type I
  // defaulted: E0
  // defaulted: Emax
  // defaulted: gamma
  annotation(experiment(StartTime = 0, StopTime = 170, Interval = 0.34),
    Documentation(info = "<html><body><!-- drug-about --><h4>About piperaquine</h4><p>Piperaquine is an antimalarial drug used to treat malaria, typically in fixed combination with an artemisinin derivative. It is approved and used mainly in malaria-endemic regions as part of artemisinin-based combination therapy, though it is not authorised in the European Union.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q7197338\">Wikidata Q7197338</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h4>Piperaquine_Patel2014_PD_parasite_density</h4><p>The steady-state exposure-response curve of Patel K et al., <i>The Journal of antimicrobial chemotherapy 69(8):2155–2163</i> 2014 (<a href=\"https://doi.org/10.1093/jac/dku120\">doi:10.1093/jac/dku120</a>) — parasite density against piperaquine μg/L — obtained by sweeping the driver instead of simulating a dose. Model family: indirect_response_i.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = (library default) drug-free response (baseline)
  Emax  = (library default) maximal effect term
  EC50  =       16.8 μg/L     exposure at half of the maximal effect term (IC50, Q322)
  gamma = (library default) Hill coefficient</pre><p>The algebra is <code>response = E0*(1 - Emax*frac)</code>; this model only supplies the numbers. The x axis is one μg/L of piperaquine per second of simulated time (exposure is in kg/m3): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0   (drug-free)
  exposure = EC50 (16.8 μg/L)  response 0
  exposure -> infinity  response 0</pre></body></html>"));
end Piperaquine_Patel2014_PD_parasite_density;
