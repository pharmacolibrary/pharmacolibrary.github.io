model Zolmitriptan_MaassenVanDenBrink1998_PD_contraction
  "emax exposure-response sweep — MaassenVanDenBrink_1998 :: contraction (Coronary artery contraction)"
  extends Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep(
    E0 = 0,      // [1]
    Emax = 11.8,  // [% of contraction elicited by 100 mmol/L K+]
    EC50 = 0.000476,  // [mol/m3; nmol/L × 1e-06]
    gamma = 1,
    exposure_per_s = 1e-06);   // 1 nmol/L per second
  // defaulted: E0
  // defaulted: gamma
  annotation(experiment(StartTime = 0, StopTime = 4800, Interval = 9.6),
    Documentation(info = "<html><body><!-- drug-about --><h4>About zolmitriptan</h4><p>Zolmitriptan is a serotonin 5-HT1 receptor agonist used to treat migraine attacks. It is an approved medicine, widely used as an antimigraine preparation.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q218820\">Wikidata Q218820</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h4>Zolmitriptan_MaassenVanDenBrink1998_PD_contraction</h4><p>The steady-state exposure-response curve of MaassenVanDenBrink A et al., <i>Circulation 98(1):25–30</i> 1998 (<a href=\"https://doi.org/10.1161/01.cir.98.1.25\">doi:10.1161/01.cir.98.1.25</a>) — Coronary artery contraction [% of contraction elicited by 100 mmol/L K+] against zolmitriptan nmol/L — obtained by sweeping the driver instead of simulating a dose. Model family: emax.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = (library default) drug-free response (baseline)
  Emax  =       11.8 % of contraction elicited by 100 mmol/L K+ maximal effect term (E max, Q320)
  EC50  =        476 nmol/L   exposure at half of the maximal effect term (EC 50, Q321)
  gamma = (library default) Hill coefficient</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep\">SigmoidEmaxSweep</a>; this model only supplies the numbers. The x axis is one nmol/L of zolmitriptan per second of simulated time (exposure is in mol/m3): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0   (drug-free)
  exposure = EC50 (476 nmol/L)  response 5.9
  exposure -> infinity  response 11.8</pre></body></html>"));
end Zolmitriptan_MaassenVanDenBrink1998_PD_contraction;
