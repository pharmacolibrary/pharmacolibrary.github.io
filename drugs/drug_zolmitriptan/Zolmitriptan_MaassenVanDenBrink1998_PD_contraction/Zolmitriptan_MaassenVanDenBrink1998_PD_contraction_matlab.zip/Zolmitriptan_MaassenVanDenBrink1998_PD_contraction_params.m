function p = Zolmitriptan_MaassenVanDenBrink1998_PD_contraction_params()
% Zolmitriptan_MaassenVanDenBrink1998_PD_contraction_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% zolmitriptan MaassenVanDenBrink_1998::contraction: emax exposure-response sweep (response = E0 + Emax*frac). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one nmol/L per second, in SI inside (kg/m3, s). Response contraction in % of contraction elicited by 100 mmol/L K+. Driver: zolmitriptan (cited_pk).
p.E0 = 0.0;
p.Emax = 11.8;
p.EC50 = 0.00047599999999999997;
p.gamma = 1.0;
p.slope = 0.0;
p.exposure_per_s = 1e-06;
p.stop_time = 4800.0;
p.form = 'E0 + Emax*frac';
end
