model Itraconazole_Comisar2025_reference
  parameter Real Cl_ref = 6.6944444444444455e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.114 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.7056330000000001,
    adminMass = 0.0002,
    ka = 0.0010722222222222222,
    Tlag = 0.0,
    k12 = 9.600389863547757e-06,
    k21 = 2.3792270531400967e-05
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About itraconazole</h4><p>Itraconazole is an antifungal medicine used to treat a range of fungal infections, including aspergillosis, candidiasis, histoplasmosis, blastomycosis, onychomycosis, and other mycoses. It is an approved, widely used systemic antifungal and appears on the WHO list of essential medicines, though it carries a boxed warning.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q411229\">Wikidata Q411229</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>itraconazole</td></tr><tr><td>population:</td><td>review reference</td></tr><tr><td>source_paper:</td><td>Comisar_2025</td></tr><tr><td>measured_compound:</td><td>itraconazole</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_2C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>itraconazole 705.633 g/mol (drugbank)</td></tr></table><p><b>Defaulted (base-class default used):</b> Tlag.</p><h4>Interpretation flags</h4><ul><li>built from REVIEW reference values (Comisar_2025) — secondary source</li><li>volume reported by review</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Itraconazole_Comisar2025_reference;
