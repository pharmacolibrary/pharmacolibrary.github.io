model Tofacitinib_Tsuchiwata2026_reference
  parameter Real Cl_ref = 7.527777777777778e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.126 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.31236959999999997,
    adminMass = 2e-06,
    ka = 0.0008527777777777777,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About tofacitinib</h4><p>Tofacitinib is a JAK inhibitor immunosuppressant used to treat rheumatoid arthritis and ulcerative colitis, and has also been studied for conditions such as alopecia areata. It is an approved medicine, authorised in the European Union for rheumatoid arthritis, and carries a boxed warning.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q3530324\">Wikidata Q3530324</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>tofacitinib</td></tr><tr><td>population:</td><td>adults with active ankylosing spondylitis</td></tr><tr><td>source_paper:</td><td>Tsuchiwata_2026</td></tr><tr><td>measured_compound:</td><td>tofacitinib</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>Table2</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>tofacitinib 312.37 g/mol (drugbank)</td></tr></table><p><b>Defaulted (base-class default used):</b> Tlag.</p><h4>Interpretation flags</h4><ul><li>dropped duplicate Q27 ('CL/F', value '-0.244') — already have one for this compound</li><li>dropped duplicate Q76 ('V/F', value '-0.230') — already have one for this compound</li><li>dropped value-less row: 'BCCL'</li><li>dropped value-less row: 'BCRP'</li><li>dropped value-less row: 'Weight'</li><li>dropped value-less row: 'Age'</li><li>implicit units: 'Ka/hour–1' → 1/h (from the paper text: &quot;Table 2 lists the parameter row label as 'Ka/hour–1'. The paper text also states the point estimate for ka was '3.07 hou&quot;)</li><li>apparent-ness (ontology-grounded): parameterization=apparent, measured_compound=tofacitinib</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of TLAG: primary's parameterization (rate-constant / ka-only) does not use it</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Tofacitinib_Tsuchiwata2026_reference;
