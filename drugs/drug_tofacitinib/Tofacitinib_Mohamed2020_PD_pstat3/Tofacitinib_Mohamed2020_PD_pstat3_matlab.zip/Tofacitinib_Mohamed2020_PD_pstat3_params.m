function p = Tofacitinib_Mohamed2020_PD_pstat3_params()
% Tofacitinib_Mohamed2020_PD_pstat3_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% tofacitinib Mohamed_2020::pSTAT3: emax exposure-response sweep (response = E0 + Emax*frac). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one nM per second, in SI inside (kg/m3, s). Response pSTAT3 in AU. Driver: tofacitinib (pk_record).
p.E0 = 34.0;
p.Emax = -34.0;
p.EC50 = 119.0;
p.gamma = 1.0;
p.slope = 0.0;
p.exposure_per_s = 1.0;
p.stop_time = 1200.0;
p.form = 'E0 + Emax*frac';
end
