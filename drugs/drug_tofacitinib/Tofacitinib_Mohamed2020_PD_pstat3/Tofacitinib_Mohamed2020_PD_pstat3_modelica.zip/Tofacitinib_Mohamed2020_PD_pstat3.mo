model Tofacitinib_Mohamed2020_PD_pstat3
  "emax exposure-response sweep — Mohamed_2020 :: pSTAT3 (IL-6–induced pSTAT3)"
  extends Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep(
    E0 = 34,      // [AU]
    Emax = -34,  // [AU]
    EC50 = 119,  // [nM]
    gamma = 1,
    exposure_per_s = 1);   // 1 nM per second
  // imax_as_negative_emax: Imax (Q323) enters SigmoidEmaxSweep as −Emax
  // exposure_unit_unresolved: 'nM' — the x axis is in the paper's unit, not SI
  // defaulted: gamma
  annotation(experiment(StartTime = 0, StopTime = 1200, Interval = 2.4),
    Documentation(info = "<html><body><!-- drug-about --><h4>About tofacitinib</h4><p>Tofacitinib is a JAK inhibitor immunosuppressant used to treat rheumatoid arthritis and ulcerative colitis, and has also been studied for conditions such as alopecia areata. It is an approved medicine, authorised in the European Union for rheumatoid arthritis, and carries a boxed warning.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q3530324\">Wikidata Q3530324</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h4>Tofacitinib_Mohamed2020_PD_pstat3</h4><p>The steady-state exposure-response curve of Mohamed MF et al., <i>Journal of clinical pharmacology 60(2):188–197</i> 2020 (<a href=\"https://doi.org/10.1002/jcph.1513\">doi:10.1002/jcph.1513</a>) — IL-6–induced pSTAT3 [AU] against tofacitinib nM — obtained by sweeping the driver instead of simulating a dose. Model family: emax.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    =         34 AU       drug-free response (baseline) (Intercept, Q324)
  Emax  =        -34 AU       maximal effect term (Emax for drug effect, Q323)
  EC50  =        119 nM       exposure at half of the maximal effect term (EC50 for tofacitinib, Q321)
  gamma = (library default) Hill coefficient</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep\">SigmoidEmaxSweep</a>; this model only supplies the numbers. The x axis is one nM of tofacitinib per second of simulated time: there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 34   (drug-free)
  exposure = EC50 (119 nM)  response 17
  exposure -> infinity  response 0</pre></body></html>"));
end Tofacitinib_Mohamed2020_PD_pstat3;
