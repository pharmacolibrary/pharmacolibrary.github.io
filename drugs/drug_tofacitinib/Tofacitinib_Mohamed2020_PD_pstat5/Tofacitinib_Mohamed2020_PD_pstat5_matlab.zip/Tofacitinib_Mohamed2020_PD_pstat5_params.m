function p = Tofacitinib_Mohamed2020_PD_pstat5_params()
% Tofacitinib_Mohamed2020_PD_pstat5_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% tofacitinib Mohamed_2020::pSTAT5: sigmoid_emax exposure-response sweep (response = E0 + Emax*frac). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one nM per second, in SI inside (kg/m3, s). Response pSTAT5 in AU. Driver: tofacitinib (pk_record).
p.E0 = 23.0;
p.Emax = -23.0;
p.EC50 = 79.0;
p.gamma = 1.3;
p.slope = 0.0;
p.exposure_per_s = 1.0;
p.stop_time = 790.0;
p.form = 'E0 + Emax*frac';
end
