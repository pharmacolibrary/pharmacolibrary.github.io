model Tofacitinib_Mohamed2020_PD_pstat5
  "sigmoid_emax exposure-response sweep — Mohamed_2020 :: pSTAT5 (IL-7–induced pSTAT5)"
  extends Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep(
    E0 = 23,      // [AU]
    Emax = -23,  // [AU]
    EC50 = 79,  // [nM]
    gamma = 1.3,
    exposure_per_s = 1);   // 1 nM per second
  // imax_as_negative_emax: Imax (Q323) enters SigmoidEmaxSweep as −Emax
  // exposure_unit_unresolved: 'nM' — the x axis is in the paper's unit, not SI
  annotation(experiment(StartTime = 0, StopTime = 790, Interval = 1.58),
    Documentation(info = "<html><body><!-- drug-about --><h4>About tofacitinib</h4><p>Tofacitinib is a JAK inhibitor immunosuppressant used to treat rheumatoid arthritis and ulcerative colitis, and has also been studied for conditions such as alopecia areata. It is an approved medicine, authorised in the European Union for rheumatoid arthritis, and carries a boxed warning.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q3530324\">Wikidata Q3530324</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h4>Tofacitinib_Mohamed2020_PD_pstat5</h4><p>The steady-state exposure-response curve of Mohamed MF et al., <i>Journal of clinical pharmacology 60(2):188–197</i> 2020 (<a href=\"https://doi.org/10.1002/jcph.1513\">doi:10.1002/jcph.1513</a>) — IL-7–induced pSTAT5 [AU] against tofacitinib nM — obtained by sweeping the driver instead of simulating a dose. Model family: sigmoid_emax.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    =         23 AU       drug-free response (baseline) (Intercept, Q324)
  Emax  =        -23 AU       maximal effect term (Emax for drug effect, Q323)
  EC50  =         79 nM       exposure at half of the maximal effect term (EC50 for tofacitinib, Q321)
  gamma =        1.3          Hill coefficient (Hill factor, Q325)</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep\">SigmoidEmaxSweep</a>; this model only supplies the numbers. The x axis is one nM of tofacitinib per second of simulated time: there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 23   (drug-free)
  exposure = EC50 (79 nM)  response 11.5
  exposure -> infinity  response 0</pre></body></html>"));
end Tofacitinib_Mohamed2020_PD_pstat5;
