function p = Tofacitinib_Mukherjee2018_PD_cr_params()
% Tofacitinib_Mukherjee2018_PD_cr_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% tofacitinib Mukherjee_2018::CR: emax exposure-response sweep (response = E0 + Emax*frac). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one mg or ng ml –1 per second, in SI inside (kg/m3, s). Response CR in its own unit. Driver: tofacitinib (dose_only).
p.E0 = 0.0;
p.Emax = 2.35;
p.EC50 = 1.06;
p.gamma = 1.0;
p.slope = 0.0;
p.exposure_per_s = 1.0;
p.stop_time = 11.0;
p.form = 'E0 + Emax*frac';
end
