model Tofacitinib_Mukherjee2018_PD_cr
  "emax exposure-response sweep — Mukherjee_2018 :: CR (Clinical remission)"
  extends Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep(
    E0 = 0,      // [1]
    Emax = 2.35,  // [1]
    EC50 = 1.06,  // [mg or ng ml –1]
    gamma = 1,
    exposure_per_s = 1);   // 1 mg or ng ml –1 per second
  // exposure_unit_unresolved: 'mg or ng ml –1' — the x axis is in the paper's unit, not SI
  // defaulted: E0
  // defaulted: gamma
  annotation(experiment(StartTime = 0, StopTime = 11, Interval = 0.022),
    Documentation(info = "<html><body><!-- drug-about --><h4>About tofacitinib</h4><p>Tofacitinib is a JAK inhibitor immunosuppressant used to treat rheumatoid arthritis and ulcerative colitis, and has also been studied for conditions such as alopecia areata. It is an approved medicine, authorised in the European Union for rheumatoid arthritis, and carries a boxed warning.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q3530324\">Wikidata Q3530324</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h4>Tofacitinib_Mukherjee2018_PD_cr</h4><p>The steady-state exposure-response curve of Mukherjee A et al., <i>British journal of clinical pharmacology 84(6):1136–1145</i> 2018 (<a href=\"https://doi.org/10.1111/bcp.13523\">doi:10.1111/bcp.13523</a>) — Clinical remission against tofacitinib mg or ng ml –1 — obtained by sweeping the driver instead of simulating a dose. Model family: emax.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = (library default) drug-free response (baseline)
  Emax  =       2.35          maximal effect term (E max, Q320)
  EC50  =       1.06 mg or ng ml –1 exposure at half of the maximal effect term (E 50, Q321)
  gamma = (library default) Hill coefficient</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep\">SigmoidEmaxSweep</a>; this model only supplies the numbers. The x axis is one mg or ng ml –1 of tofacitinib per second of simulated time: there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0   (drug-free)
  exposure = EC50 (1.06 mg or ng ml –1)  response 1.175
  exposure -> infinity  response 2.35</pre></body></html>"));
end Tofacitinib_Mukherjee2018_PD_cr;
