model Tofacitinib_Mukherjee2018_PD_mh
  "linear exposure-response sweep — Mukherjee_2018 :: MH (Mucosal healing)"
  extends Pharmacolibrary.Interfaces.PartialExposureResponseSweep(
    E0 = 0,      // [1]
    Emax = 0, EC50 = 1,      // unused by a line
    exposure_per_s = 1);
  parameter Real slope = 0.08   "[1]";
equation
  response = E0 + slope*exposure;
  // defaulted: E0
  annotation(experiment(StartTime = 0, StopTime = 1000, Interval = 2),
    Documentation(info = "<html><body><!-- drug-about --><h4>About tofacitinib</h4><p>Tofacitinib is a JAK inhibitor immunosuppressant used to treat rheumatoid arthritis and ulcerative colitis, and has also been studied for conditions such as alopecia areata. It is an approved medicine, authorised in the European Union for rheumatoid arthritis, and carries a boxed warning.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q3530324\">Wikidata Q3530324</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h4>Tofacitinib_Mukherjee2018_PD_mh</h4><p>The steady-state exposure-response curve of Mukherjee A et al., <i>British journal of clinical pharmacology 84(6):1136–1145</i> 2018 (<a href=\"https://doi.org/10.1111/bcp.13523\">doi:10.1111/bcp.13523</a>) — Mucosal healing against tofacitinib mg or ng ml–1 — obtained by sweeping the driver instead of simulating a dose. Model family: linear.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = (library default) drug-free response (baseline)
  slope =       0.08          change in response per unit of exposure (Slope, Q335)</pre><p>The algebra is <code>response = E0 + slope*exposure</code>; this model only supplies the numbers. The x axis is one mg or ng ml–1 of tofacitinib per second of simulated time: there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0   (drug-free)</pre></body></html>"));
end Tofacitinib_Mukherjee2018_PD_mh;
