function p = Tofacitinib_Mukherjee2018_PD_mh_params()
% Tofacitinib_Mukherjee2018_PD_mh_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% tofacitinib Mukherjee_2018::MH: linear exposure-response sweep (response = E0 + slope*exposure). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one mg or ng ml–1 per second, in SI inside (kg/m3, s). Response MH in its own unit. Driver: tofacitinib (dose_only).
p.E0 = 0.0;
p.Emax = 0.0;
p.EC50 = 1.0;
p.gamma = 1.0;
p.slope = 0.08;
p.exposure_per_s = 1.0;
p.stop_time = 1000.0;
p.form = 'E0 + slope*exposure';
end
