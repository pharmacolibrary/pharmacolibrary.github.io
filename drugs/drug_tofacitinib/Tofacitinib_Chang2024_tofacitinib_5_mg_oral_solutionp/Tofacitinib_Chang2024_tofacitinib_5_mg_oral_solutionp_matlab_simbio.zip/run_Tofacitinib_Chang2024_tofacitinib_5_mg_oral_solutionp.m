% Run (SimBiology): build model + dose, simulate 0..24.0 h, plot.
p = Tofacitinib_Chang2024_tofacitinib_5_mg_oral_solutionp_params();
[model, dose, variant] = build_sb_pk(p);
sd = simulate_sb(model, variant, dose, 24.0);
