model Tofacitinib_Chang2024_tofacitinib_5_mg_tablet
  parameter Real Cl_ref = 7.2361111111111115e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.08922000000000001 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.31236959999999997,
    adminMass = 3.2000000000000003e-06,
    ka = 0.0007722222222222222,
    Tlag = 684.0
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About tofacitinib</h4><p>Tofacitinib is a JAK inhibitor immunosuppressant used to treat rheumatoid arthritis and ulcerative colitis, and has also been studied for conditions such as alopecia areata. It is an approved medicine, authorised in the European Union for rheumatoid arthritis, and carries a boxed warning.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q3530324\">Wikidata Q3530324</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>tofacitinib</td></tr><tr><td>population:</td><td>children and adolescents with juvenile idiopathic arthritis</td></tr><tr><td>source_paper:</td><td>Chang_2024</td></tr><tr><td>measured_compound:</td><td>tofacitinib</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>psp413104-tbl-0003</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>tofacitinib 312.37 g/mol (drugbank)</td></tr></table><h4>Interpretation flags</h4><ul><li>unit_dimension_unknown: 'n = 11' (AUC∞)</li><li>unit_dimension_unknown: 'n = 11' (AUClast)</li><li>unit_dimension_unknown: 'n = 11' (Cmax)</li><li>dropped unlinked row (NIL): 't 1/2 (h), mean (SD)' — extend the ontology if this is a real PK parameter (source ['Chang_2024_table_4:row4:col1'])</li><li>salvaged Q27 ('CL/F'=26.05) from results prose — parameter table was unreadable</li><li>salvaged Q76 ('V/F'=89.22) from results prose — parameter table was unreadable</li><li>salvaged Q49 ('k a'=2.78) from results prose — parameter table was unreadable</li><li>salvaged Q83 ('absorption lag time'=0.19) from results prose — parameter table was unreadable</li><li>implicit units: 'AUCinf (ng∙h/mL) b' → ng∙h/mL (from the paper text: &quot;The unit 'ng∙h/mL' is explicitly provided in the prompt's parameter label 'AUCinf (ng∙h/mL) b = 126.8'. Additionally, th&quot;)</li><li>implicit units: 'AUClast (ng∙h/mL) b' → ng∙h/mL (from the paper text: &quot;The unit 'ng∙h/mL' is explicitly provided in the prompt's parameter label 'AUClast (ng∙h/mL) b = 125.7'. This is consist&quot;)</li><li>implicit units: 'C max (ng/mL) b' → ng/mL (from the paper text: &quot;The unit 'ng/mL' is explicitly provided in the prompt's parameter label 'C max (ng/mL) b = 34.6'. The paper text also st&quot;)</li><li>apparent-ness (ontology-grounded): parameterization=apparent, measured_compound=tofacitinib</li><li>held at status:extracted — NIL link or unit issue (mismatch/unknown/normalisation-failed) present</li><li>status held at route_to_review — not promoted</li><li>population split: 'tofacitinib 5 mg tablet (n = 11)' subgroup of Chang_2024 (paper reports 3 populations: estimate, tofacitinib 5 mg oral solution (n = 12)p, tofacitinib 5 mg tablet (n = 11))</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Tofacitinib_Chang2024_tofacitinib_5_mg_tablet;
