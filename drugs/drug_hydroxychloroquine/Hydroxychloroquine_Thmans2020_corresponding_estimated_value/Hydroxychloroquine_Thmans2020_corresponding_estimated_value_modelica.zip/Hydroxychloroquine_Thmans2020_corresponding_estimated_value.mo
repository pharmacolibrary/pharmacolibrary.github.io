model Hydroxychloroquine_Thmans2020_corresponding_estimated_value
  parameter Real Cl_ref = 2.7472222222222226e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.605 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 0.746,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.335872,
    adminMass = 0.0002,
    ka = 0.00021250000000000002,
    Tlag = 1602.0
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About hydroxychloroquine</h4><p>Hydroxychloroquine is used to treat and prevent malaria and to manage autoimmune conditions such as systemic lupus erythematosus, rheumatoid arthritis, Sjögren's syndrome, and certain skin diseases. It is widely used and is included on the WHO list of essential medicines.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q421094\">Wikidata Q421094</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>hydroxychloroquine</td></tr><tr><td>population:</td><td>COVID-19 patients</td></tr><tr><td>source_paper:</td><td>Thémans_2020</td></tr><tr><td>measured_compound:</td><td>hydroxychloroquine</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>Tab2</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>hydroxychloroquine 335.872 g/mol (drugbank)</td></tr></table><h4>Interpretation flags</h4><ul><li>table section iiv: 'Εprop (σ2)' routed out of structural estimates ('IIV on Tlag (ω2)')</li><li>table section iiv: 'Εadd (σ2)' routed out of structural estimates ('IIV on Tlag (ω2)')</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=hydroxychloroquine</li><li>population split: 'corresponding estimated value in model by carmichael et al. [2]' subgroup of Thémans_2020 (paper reports 2 populations: corresponding estimated value in model by carmichael et al. [2], estimate)</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 777600, Tolerance = 1e-9, Interval = 1));
end Hydroxychloroquine_Thmans2020_corresponding_estimated_value;
