% Run (SimBiology): build model + dose, simulate 0..216.0 h, plot.
p = Hydroxychloroquine_Thmans2020_corresponding_estimated_value_params();
[model, dose, variant] = build_sb_pk(p);
sd = simulate_sb(model, variant, dose, 216.0);
