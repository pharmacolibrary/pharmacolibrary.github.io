model Hydroxychloroquine_Balevic2019_prenatal
  parameter Real Cl_ref = 1.3055555555555555e-05 "Cl [m3/s]";
  parameter Real Vd_ref = 2.0 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.335872,
    adminMass = 0.0004,
    ka = 0.0003194444444444444,
    Tlag = 1400.4
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About hydroxychloroquine</h4><p>Hydroxychloroquine is used to treat and prevent malaria and to manage autoimmune conditions such as systemic lupus erythematosus, rheumatoid arthritis, Sjögren's syndrome, and certain skin diseases. It is widely used and is included on the WHO list of essential medicines.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q421094\">Wikidata Q421094</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>hydroxychloroquine</td></tr><tr><td>population:</td><td>pregnant women with rheumatic disease</td></tr><tr><td>source_paper:</td><td>Balevic_2019</td></tr><tr><td>measured_compound:</td><td>hydroxychloroquine</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>T2</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>hydroxychloroquine 335.872 g/mol (drugbank)</td></tr></table><h4>Interpretation flags</h4><ul><li>dropped unlinked row (NIL): 'Median' — extend the ontology if this is a real PK parameter (source ['Balevic_2019_table_3:row1:col1', 'Balevic_2019_table_3:row1:col2', 'Balevic_2019_table_3:row1:col3'])</li><li>dropped unlinked row (NIL): '25%' — extend the ontology if this is a real PK parameter (source ['Balevic_2019_table_3:row2:col1', 'Balevic_2019_table_3:row2:col2', 'Balevic_2019_table_3:row2:col3'])</li><li>routed 'SD' → Q315 (sigma) to residual_error — variability estimate, not a structural parameter</li><li>dropped unlinked row (NIL): 'SE' — extend the ontology if this is a real PK parameter (source ['Balevic_2019_table_3:row6:col1', 'Balevic_2019_table_3:row6:col2', 'Balevic_2019_table_3:row6:col3'])</li><li>dropped value-less row: 'CL/F'</li><li>dropped value-less row: 'CV'</li><li>dropped value-less row: 'dVdWT'</li><li>dropped value-less row: 'Ka'</li><li>dropped value-less row: 'RSE'</li><li>dropped value-less row: 'V/F'</li><li>salvaged Q76 ('V/F (model B)'=2000) from results prose — parameter table was unreadable</li><li>salvaged Q27 ('CL/F (model B)'=47) from results prose — parameter table was unreadable</li><li>apparent-ness (ontology-grounded): parameterization=apparent, measured_compound=hydroxychloroquine</li><li>held at status:extracted — NIL link or unit issue (mismatch/unknown/normalisation-failed) present</li><li>structure disagreement: deterministic 1C vs LLM 2C — review compartment count</li><li>status held at route_to_review — not promoted</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 604800, Tolerance = 1e-9, Interval = 1));
end Hydroxychloroquine_Balevic2019_prenatal;
