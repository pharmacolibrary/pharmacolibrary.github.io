function p = Hydroxychloroquine_Thmans2020_estimate_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: hydroxychloroquine   source: Thémans_2020 / estimate   route: oral
  p.name  = 'Hydroxychloroquine_Thmans2020_estimate_params';
  p.drug  = 'hydroxychloroquine';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 860.8;                % central volume [L]
  p.CL = 15.7;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 9.3;                % absorption rate [1/h]
  p.F  = 0.746;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 200.0;             % dose [mg]
end
