model Hydroxychloroquine_Zahr2021_reference
  parameter Real Cl_ref = 4.083333333333333e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.00199 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.335872,
    adminMass = 0.000516,
    ka = 0.00020833333333333332,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About hydroxychloroquine</h4><p>Hydroxychloroquine is used to treat and prevent malaria and to manage autoimmune conditions such as systemic lupus erythematosus, rheumatoid arthritis, Sjögren's syndrome, and certain skin diseases. It is widely used and is included on the WHO list of essential medicines.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q421094\">Wikidata Q421094</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>hydroxychloroquine</td></tr><tr><td>population:</td><td>hospitalized adults with COVID-19</td></tr><tr><td>source_paper:</td><td>Zahr_2021</td></tr><tr><td>measured_compound:</td><td>hydroxychloroquine</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>tbl0015</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>hydroxychloroquine 335.872 g/mol (drugbank)</td></tr></table><p><b>Defaulted (base-class default used):</b> Tlag.</p><h4>Interpretation flags</h4><ul><li>dropped duplicate Q76 ('ηV/F', value '0.61') — already have one for this compound</li><li>dropped duplicate Q27 ('ηCL/F', value '0.69') — already have one for this compound</li><li>implicit units: 'β, V/F*(BW/70)β' → L (from the paper text: 'Abstract: &quot;Vd/F ... 6690 L&quot;; Table 1 caption: &quot;V/F, L: apparent volume of distribution, liter&quot;')</li><li>implicit units: 'CL/F' → L/h (from the paper text: 'Abstract: &quot;CL/F ... 45.9 L/h&quot;; Table 1 caption: &quot;CL/F, L/h: apparent elimination clearance, liter/hour&quot;')</li><li>apparent-ness (ontology-grounded): parameterization=apparent, measured_compound=hydroxychloroquine</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of TLAG: primary's parameterization (rate-constant / ka-only) does not use it</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Hydroxychloroquine_Zahr2021_reference;
