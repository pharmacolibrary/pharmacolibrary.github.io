model Hydroxychloroquine_Yang2025_reference
  parameter Real Cl_ref = 4.555555555555555e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 1.22 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.335872,
    adminMass = 0.000516,
    ka = 0.0003194444444444444,
    Tlag = 1400.4
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About hydroxychloroquine</h4><p>Hydroxychloroquine is used to treat and prevent malaria and to manage autoimmune conditions such as systemic lupus erythematosus, rheumatoid arthritis, Sjögren's syndrome, and certain skin diseases. It is widely used and is included on the WHO list of essential medicines.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q421094\">Wikidata Q421094</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>hydroxychloroquine</td></tr><tr><td>population:</td><td>patients with rheumatic diseases on long-term HCQ</td></tr><tr><td>source_paper:</td><td>Yang_2025</td></tr><tr><td>measured_compound:</td><td>hydroxychloroquine</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>hydroxychloroquine 335.872 g/mol (drugbank)</td></tr></table><h4>Interpretation flags</h4><ul><li>apparent-ness (ontology-grounded): parameterization=apparent, measured_compound=hydroxychloroquine</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li><li>gap-filled Q49 (kabs) from Alvarez_2022's review values (primary lacked it)</li><li>gap-filled Q83 (tlag) from Alvarez_2022's review values (primary lacked it)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 950400, Tolerance = 1e-9, Interval = 1));
end Hydroxychloroquine_Yang2025_reference;
