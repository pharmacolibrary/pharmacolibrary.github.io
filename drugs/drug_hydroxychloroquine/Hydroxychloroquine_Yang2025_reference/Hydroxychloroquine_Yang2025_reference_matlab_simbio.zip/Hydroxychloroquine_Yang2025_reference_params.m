function p = Hydroxychloroquine_Yang2025_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: hydroxychloroquine   source: Yang_2025 / reference   route: oral
  p.name  = 'Hydroxychloroquine_Yang2025_reference_params';
  p.drug  = 'hydroxychloroquine';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 1220.0;                % central volume [L]
  p.CL = 16.4;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 1.15;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.389;             % absorption lag [h]
  p.dose = 516.0;             % dose [mg]
end
