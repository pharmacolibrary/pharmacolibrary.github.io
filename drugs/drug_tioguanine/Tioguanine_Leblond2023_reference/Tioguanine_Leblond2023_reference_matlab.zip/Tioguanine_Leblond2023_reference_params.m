function p = Tioguanine_Leblond2023_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: tioguanine   source: Leblond_2023 / reference   route: oral
  % estimated (absent from source): ka
  p.name  = 'Tioguanine_Leblond2023_reference_params';
  p.drug  = 'tioguanine';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 455.0;                % central volume [L]
  p.CL = 77.0;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.5;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 140.0;             % dose [mg]
end
