model Dapagliflozin_Sokolov2023_PD_hba1c
  "emax exposure-response sweep — Sokolov_2023 :: HbA1c (HbA1c)"
  extends Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep(
    E0 = 0,      // [1]
    Emax = -0.000421,  // [1; % × 0.01]
    EC50 = 67.4,  // [ng/mL*h]
    gamma = 1,
    exposure_per_s = 1);   // 1 ng/mL*h per second
  // imax_as_negative_emax: Imax (Q323) enters SigmoidEmaxSweep as −Emax
  // exposure_unit_unresolved: 'ng/mL*h' — the x axis is in the paper's unit, not SI
  // defaulted: E0
  // defaulted: gamma
  annotation(experiment(StartTime = 0, StopTime = 680, Interval = 1.36),
    Documentation(info = "<html><body><h4>Dapagliflozin_Sokolov2023_PD_hba1c</h4><p>The steady-state exposure-response curve of Sokolov V et al., <i>Frontiers in pharmacology 14:1229255</i> 2023 (<a href=\"https://doi.org/10.3389/fphar.2023.1229255\">doi:10.3389/fphar.2023.1229255</a>) — HbA1c [%] against dapagliflozin ng/mL*h — obtained by sweeping the driver instead of simulating a dose. Model family: emax.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = (library default) drug-free response (baseline)
  Emax  =     0.0421 %        maximal effect term (Imaxhba1c, Q323)
  EC50  =       67.4 ng/mL*h  exposure at half of the maximal effect term (IAUC50hba1c, Q322)
  gamma = (library default) Hill coefficient</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep\">SigmoidEmaxSweep</a>; this model only supplies the numbers. The x axis is one ng/mL*h of dapagliflozin per second of simulated time: there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0   (drug-free)
  exposure = EC50 (67.4 ng/mL*h)  response -0.0002105
  exposure -> infinity  response -0.000421</pre></body></html>"));
end Dapagliflozin_Sokolov2023_PD_hba1c;
