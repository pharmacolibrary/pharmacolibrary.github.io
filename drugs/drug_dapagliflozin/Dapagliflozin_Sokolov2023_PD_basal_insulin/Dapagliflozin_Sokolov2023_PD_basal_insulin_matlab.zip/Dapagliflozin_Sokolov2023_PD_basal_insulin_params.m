function p = Dapagliflozin_Sokolov2023_PD_basal_insulin_params()
% Dapagliflozin_Sokolov2023_PD_basal_insulin_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% dapagliflozin Sokolov_2023::basal_insulin: emax exposure-response sweep (response = E0 + Emax*frac). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one ng/mL*h per second, in SI inside (kg/m3, s). Response basal insulin in IU/mL. Driver: dapagliflozin (cited_pk).
p.E0 = 0.0;
p.Emax = -0.0941;
p.EC50 = 38.8;
p.gamma = 1.0;
p.slope = 0.0;
p.exposure_per_s = 1.0;
p.stop_time = 390.0;
p.form = 'E0 + Emax*frac';
end
