model Dapagliflozin_Kobuchi2025_PD_hba1c
  "indirect_response_i exposure-response sweep — Kobuchi_2025 :: HbA1c (HbA1c)"
  extends Pharmacolibrary.Interfaces.PartialExposureResponseSweep(
    E0 = 0.0,      // [1]
    Emax = 0.034,  // type I effect term
    EC50 = 2.3699999999999997e-05,  // [kg/m3; ng/mL × 1e-06]
    gamma = 1.0,
    exposure_per_s = 1e-06);   // 1 ng/mL per second
equation
  response = E0*(1 - Emax*frac);   // steady state, indirect response type I
  // defaulted: E0
  // defaulted: gamma
  annotation(experiment(StartTime = 0, StopTime = 237, Interval = 0.474));
end Dapagliflozin_Kobuchi2025_PD_hba1c;
