function p = Dapagliflozin_Sokolov2023_PD_glucose_params()
% Dapagliflozin_Sokolov2023_PD_glucose_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% dapagliflozin Sokolov_2023::glucose: emax exposure-response sweep (response = E0 + Emax*frac). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one ng/mL*h per second, in SI inside (kg/m3, s). Response glucose in mg/dL. Driver: dapagliflozin (cited_pk).
p.E0 = 0.0;
p.Emax = -0.0014999999999999998;
p.EC50 = 67.4;
p.gamma = 1.0;
p.slope = 0.0;
p.exposure_per_s = 1.0;
p.stop_time = 680.0;
p.form = 'E0 + Emax*frac';
end
