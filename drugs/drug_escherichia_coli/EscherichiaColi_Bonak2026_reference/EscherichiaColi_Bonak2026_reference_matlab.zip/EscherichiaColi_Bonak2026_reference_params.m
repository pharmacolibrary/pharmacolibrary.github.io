function p = EscherichiaColi_Bonak2026_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: escherichia_coli   source: Boşnak_2026 / reference   route: oral
  p.name  = 'EscherichiaColi_Bonak2026_reference_params';
  p.drug  = 'escherichia_coli';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 97.57;                % central volume [L]
  p.CL = 4.77;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 1.12;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 750.0;             % dose [mg]
end
