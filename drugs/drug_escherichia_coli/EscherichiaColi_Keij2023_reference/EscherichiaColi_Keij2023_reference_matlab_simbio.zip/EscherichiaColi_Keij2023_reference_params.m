function p = EscherichiaColi_Keij2023_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: escherichia_coli   source: Keij_2023 / reference   route: oral
  % estimated (absent from source): F, dose
  p.name  = 'EscherichiaColi_Keij2023_reference_params';
  p.drug  = 'escherichia_coli';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 43.0;                % central volume [L]
  p.CL = 3.22;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.085;                % absorption rate [1/h]
  p.F  = 0.9;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 100.0;             % dose [mg]
end
