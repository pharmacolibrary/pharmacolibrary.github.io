function p = Trametinib_Ravix2024_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: trametinib   source: Ravix_2024 / reference   route: iv_bolus
  % estimated (absent from source): F
  p.name  = 'Trametinib_Ravix2024_reference_params';
  p.drug  = 'trametinib';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'iv_bolus';        % 'oral' | 'iv_bolus'
  p.depot = false;             % oral -> first-order absorption depot
  p.Vc = 102.0;                % central volume [L]
  p.CL = 4.2;                % clearance [L/h]
  p.Vp = [338.0];             % peripheral volumes [L]
  p.Q  = [35.1];             % inter-compartmental clearances [L/h]
  p.ka = 0.0;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 2.0;             % dose [mg]
end
