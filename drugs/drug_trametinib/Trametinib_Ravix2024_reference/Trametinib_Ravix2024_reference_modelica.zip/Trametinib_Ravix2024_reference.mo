model Trametinib_Ravix2024_reference
  parameter Real Cl_ref = 1.1666666666666668e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.10200000000000001 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.6153948,
    adminMass = 2e-06,
    k12 = 9.558823529411764e-05,
    k21 = 2.8846153846153842e-05
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About trametinib</h4><p>Trametinib is a MEK inhibitor anticancer drug used to treat melanoma, including metastatic melanoma, and also studied for other cancers such as non-small-cell lung carcinoma and low-grade serous carcinoma. It is authorised in the European Union, where it is used for melanoma and glioma.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q7833138\">Wikidata Q7833138</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>trametinib</td></tr><tr><td>population:</td><td>adult oncology patients with solid tumours</td></tr><tr><td>source_paper:</td><td>Ravix_2024</td></tr><tr><td>measured_compound:</td><td>trametinib</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>cancers-16-02193-t002</td></tr><tr><td>input:</td><td>PK_2C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>trametinib 615.395 g/mol (drugbank)</td></tr></table><h4>Interpretation flags</h4><ul><li>dropped value-less row: 'ka(h−1)' (captured trailing unit 'h−1' for child rows)</li><li>dropped value-less row: 'θCL (L·h−1)' (captured trailing unit 'L·h−1' for child rows)</li><li>dropped value-less row: 'θAGE'</li><li>dropped value-less row: 'θFFM'</li><li>dropped value-less row: 'V2 (L)' (captured trailing unit 'L' for child rows)</li><li>dropped value-less row: 'Q (L·h−1)' (captured trailing unit 'L·h−1' for child rows)</li><li>dropped value-less row: 'V3 (L)' (captured trailing unit 'L' for child rows)</li><li>salvaged Q22 ('CL'=4.2) from results prose — parameter table was unreadable</li><li>salvaged Q63 ('central volume (V2)'=102) from results prose — parameter table was unreadable</li><li>salvaged Q30 ('intercompartmental clearance (Q)'=35.1) from results prose — parameter table was unreadable</li><li>salvaged Q64 ('peripheral volume (V3)'=338) from results prose — parameter table was unreadable</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=trametinib</li><li>held at status:extracted — NIL link or unit issue (mismatch/unknown/normalisation-failed) present</li><li>status held at route_to_review — not promoted</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 345600, Tolerance = 1e-9, Interval = 1));
end Trametinib_Ravix2024_reference;
