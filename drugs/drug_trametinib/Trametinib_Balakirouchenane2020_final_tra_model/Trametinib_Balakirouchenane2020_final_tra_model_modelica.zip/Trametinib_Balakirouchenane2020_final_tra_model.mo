model Trametinib_Balakirouchenane2020_final_tra_model
  parameter Real Cl_ref = 1.6194444444444445e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.0619 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.6153948,
    adminMass = 7.5e-05,
    ka = 0.00025361111111111114,
    Tlag = 2552.4
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About trametinib</h4><p>Trametinib is a MEK inhibitor anticancer drug used to treat melanoma, including metastatic melanoma, and also studied for other cancers such as non-small-cell lung carcinoma and low-grade serous carcinoma. It is authorised in the European Union, where it is used for melanoma and glioma.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q7833138\">Wikidata Q7833138</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>trametinib</td></tr><tr><td>population:</td><td>patients with BRAF-mutated metastatic solid tumors</td></tr><tr><td>source_paper:</td><td>Balakirouchenane_2020</td></tr><tr><td>measured_compound:</td><td>trametinib</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>cancers-12-00931-t003</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>dabrafenib 519.56 g/mol (pubchem); hydroxy-dabrafenib 535.559 g/mol (pubchem); trametinib 615.395 g/mol (drugbank)</td></tr></table><h4>Interpretation flags</h4><ul><li>implicit units: 'ka (1/h)' → 1/h (from the paper text: 'The provided parameter entry states “ka (1/h) = 0.913”; the parenthetical gives the unit explicitly.')</li><li>apparent-ness (ontology-grounded): parameterization=apparent, measured_compound=trametinib</li><li>template fit: PK_3M_9C — formed from central; parent 2, metabolites [0]</li><li>population split: 'final tra model' subgroup of Balakirouchenane_2020 (paper reports 3 populations: dlt, final tra model, no dlt)</li><li>row roles (LLM): model_class=compartmental; 25/25 row label(s) assigned, 24 linked by role; re-tagged trametinib→dabrafenib ×1, trametinib→hydroxy-dabrafenib ×1</li><li>engineer: parent_metabolite composite downgraded to a 1C model of the measured compound — the paper reports the metabolite's own CL and V but neither the parent's disposition nor a formation rate, so the parent sub-component could not be populated; the parent's concentration-time course is NOT produced by this model</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 147600, Tolerance = 1e-9, Interval = 1));
end Trametinib_Balakirouchenane2020_final_tra_model;
