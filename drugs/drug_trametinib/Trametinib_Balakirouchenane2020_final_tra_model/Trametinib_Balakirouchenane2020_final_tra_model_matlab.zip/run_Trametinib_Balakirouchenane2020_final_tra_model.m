% Run: build params, simulate 0..41.0 h, plot + save Trametinib_Balakirouchenane2020_final_tra_model.png/.csv/.json.
% Interactive display (keep the window open):  octave --persist run_Trametinib_Balakirouchenane2020_final_tra_model.m
here = fileparts(mfilename('fullpath'));
p = Trametinib_Balakirouchenane2020_final_tra_model_params();
out = simulate_pk(p, 0:0.05:41.0);

% figure (shown on screen if interactive) and PNG (works in MATLAB and Octave)
fig = figure; plot(out.t, out.C, 'LineWidth', 1.5); grid on;
xlabel('time [h]'); ylabel('central concentration [mg/L]');
title('trametinib — Balakirouchenane_2020 (oral)');
print(fig, fullfile(here, 'Trametinib_Balakirouchenane2020_final_tra_model.png'), '-dpng', '-r150');

% CSV (time_h, Cc_mg_per_L)
fid = fopen(fullfile(here, 'Trametinib_Balakirouchenane2020_final_tra_model.csv'), 'w');
fprintf(fid, 'time_h,Cc_mg_per_L\n');
fprintf(fid, '%.10g,%.10g\n', [out.t(:), out.C(:)].');
fclose(fid);

% JSON (summary + arrays; jsonencode with a manual fallback for older versions)
fid = fopen(fullfile(here, 'Trametinib_Balakirouchenane2020_final_tra_model.json'), 'w');
try
  s.model = 'Trametinib_Balakirouchenane2020_final_tra_model'; s.Cmax = out.Cmax; s.Tmax = out.Tmax; s.AUC = out.AUC;
  s.time_h = out.t(:).'; s.Cc_mg_per_L = out.C(:).';
  fprintf(fid, '%s', jsonencode(s));
catch
  fprintf(fid, '{"model":"Trametinib_Balakirouchenane2020_final_tra_model","Cmax":%g,"Tmax":%g,"AUC":%g}', out.Cmax, out.Tmax, out.AUC);
end
fclose(fid);

fprintf('Cmax=%.3g mg/L  Tmax=%.3g h  AUC=%.3g mg*h/L\n', out.Cmax, out.Tmax, out.AUC);
fprintf('wrote Trametinib_Balakirouchenane2020_final_tra_model.png, Trametinib_Balakirouchenane2020_final_tra_model.csv, Trametinib_Balakirouchenane2020_final_tra_model.json\n');
