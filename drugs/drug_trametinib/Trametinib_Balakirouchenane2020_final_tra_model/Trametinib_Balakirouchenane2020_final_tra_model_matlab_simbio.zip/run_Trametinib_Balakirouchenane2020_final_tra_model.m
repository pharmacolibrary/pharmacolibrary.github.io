% Run (SimBiology): build model + dose, simulate 0..41.0 h, plot.
p = Trametinib_Balakirouchenane2020_final_tra_model_params();
[model, dose, variant] = build_sb_pk(p);
sd = simulate_sb(model, variant, dose, 41.0);
