model Raltitrexed_Blair2004_total_cohort
  parameter Real Cl_ref = 5.722222222222223e-07 "Cl [m3/s]";
  parameter Real Vd_ref = 0.0066500000000000005 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.458488,
    adminMass = 1e-05
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About raltitrexed</h4><p>Raltitrexed is an anticancer antimetabolite (a folic acid analogue) used to treat advanced colorectal cancer. It was withdrawn in some countries because of serious toxicity, but remains available and used in a limited number of countries.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q15304877\">Wikidata Q15304877</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>raltitrexed</td></tr><tr><td>population:</td><td>patients with advanced solid tumours</td></tr><tr><td>source_paper:</td><td>Blair_2004</td></tr><tr><td>measured_compound:</td><td>raltitrexed</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>tab_0</td></tr><tr><td>input:</td><td>PK_1C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>raltitrexed 458.488 g/mol (drugbank)</td></tr></table><h4>Interpretation flags</h4><ul><li>dropped unlinked row (NIL): 'Number of patients' — extend the ontology if this is a real PK parameter (source ['tab_0:row1:col3'])</li><li>dropped unlinked row (NIL): 'Number of courses' — extend the ontology if this is a real PK parameter (source ['tab_0:row2:col3'])</li><li>dropped unlinked row (NIL): 'Number of observations' — extend the ontology if this is a real PK parameter (source ['tab_0:row3:col3'])</li><li>dropped unlinked row (NIL): 'Number of observations per patient 15 ± 3 (3-22)' — extend the ontology if this is a real PK parameter (source ['tab_0:row4:col3'])</li><li>table mostly unlinked (4/4 table-cell rows NIL) — likely the wrong table was located, not 0 genuinely-missing ontology parameter(s); route_to_review instead of building a model from the residual linked cell(s)</li><li>salvaged Q22 ('CL (l h -1 )'=2.06) from results prose — parameter table was unreadable</li><li>salvaged Q61 ('V (l)'=6.65) from results prose — parameter table was unreadable</li><li>salvaged Q30 ('q 1'=0.54) from results prose — parameter table was unreadable</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=raltitrexed</li><li>held at status:extracted — NIL link or unit issue (mismatch/unknown/normalisation-failed) present</li><li>structure disagreement: deterministic 1C vs LLM 2C — review compartment count</li><li>status held at route_to_review — not promoted</li><li>population split: 'total cohort' subgroup of Blair_2004 (paper reports 3 populations: model development, model validation, total cohort)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Raltitrexed_Blair2004_total_cohort;
