function p = Tetracycline_Thompson2019_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: tetracycline   source: Thompson_2019 / reference   route: oral
  % estimated (absent from source): F
  p.name  = 'Tetracycline_Thompson2019_reference_params';
  p.drug  = 'tetracycline';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 96.8;                % central volume [L]
  p.CL = 3.32;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.414;                % absorption rate [1/h]
  p.F  = 0.9;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 1000.0;             % dose [mg]
end
