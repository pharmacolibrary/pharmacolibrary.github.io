function p = Tetracycline_Li1993_PD_k_params()
% Tetracycline_Li1993_PD_k_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% tetracycline Li_1993::K: sigmoid_emax exposure-response sweep (response = E0 + Emax*frac). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one µg/m1 per second, in SI inside (kg/m3, s). Response K' in h-1. Driver: tetracycline (cited_pk).
p.E0 = 0.0;
p.Emax = 0.0009444444444444444;
p.EC50 = 0.96;
p.gamma = 1.02;
p.slope = 0.0;
p.exposure_per_s = 1.0;
p.stop_time = 9.6;
p.form = 'E0 + Emax*frac';
end
