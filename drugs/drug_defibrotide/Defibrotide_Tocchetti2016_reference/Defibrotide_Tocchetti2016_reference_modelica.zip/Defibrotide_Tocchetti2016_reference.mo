model Defibrotide_Tocchetti2016_reference
  parameter Real Cl_ref = 1.6305555555555557e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.00602965736169297 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    adminMass = 0.00175
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About defibrotide</h4><p>Defibrotide, a mixture of single-stranded DNA fragments from pig intestinal mucosa, is an antithrombotic medicine used to treat hepatic veno-occlusive disease. It is authorised in the European Union and is also being studied for other uses.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q3704725\">Wikidata Q3704725</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>defibrotide</td></tr><tr><td>population:</td><td>review reference</td></tr><tr><td>source_paper:</td><td>Tocchetti_2016</td></tr><tr><td>measured_compound:</td><td>defibrotide</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C: IV (no input phase)</td></tr></table><h4>Interpretation flags</h4><ul><li>built from REVIEW reference values (Tocchetti_2016) — secondary source</li><li>central volume derived from CL·t½/ln2</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Defibrotide_Tocchetti2016_reference;
