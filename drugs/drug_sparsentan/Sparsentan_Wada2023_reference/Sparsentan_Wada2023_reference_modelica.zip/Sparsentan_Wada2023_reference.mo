model Sparsentan_Wada2023_reference
  parameter Real Cl_ref = 1.0777777777777777e-06 "Cl [m3/s]";
  parameter Real cov_cyp3a4_0 = 0 "cyp3a4 covariate";
  parameter Real cov_cyp3a4_1 = 0 "cyp3a4 covariate";
  parameter Real cov_crcl = 1.0 "crcl covariate (reference 1.0)";
  parameter Real Vd_ref = 0.0493 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref*(1 + (-0.273)*cov_cyp3a4_0)*(1 + (-1.069)*cov_cyp3a4_1)*(cov_crcl/1.0)^(0.222),
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.59276,
    adminMass = 0.0002,
    ka = 0.00020555555555555556,
    Tlag = 1152.0,
    k12 = 1.1437908496732026e-05,
    k21 = 4.6602387511478417e-05
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About sparsentan</h4><p>Sparsentan is used to treat IgA glomerulonephritis, a kidney disease. It is approved and authorised in the European Union, though it remains under investigation for other uses and carries a boxed warning.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q27088845\">Wikidata Q27088845</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>sparsentan</td></tr><tr><td>population:</td><td>healthy volunteers and patients with focal segmental glomerulosclerosis</td></tr><tr><td>source_paper:</td><td>Wada_2023</td></tr><tr><td>measured_compound:</td><td>sparsentan</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>psp412996-tbl-0002</td></tr><tr><td>input:</td><td>PK_2C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>sparsentan 592.76 g/mol (drugbank)</td></tr></table><h4>Interpretation flags</h4><ul><li>table section iiv: 'CL/F (L/h)' routed out of structural estimates ('IIV (%)')</li><li>table section iiv: 'V c/F (L)' routed out of structural estimates ('IIV (%)')</li><li>table section iiv: 'K a (1/h)' routed out of structural estimates ('IIV (%)')</li><li>unit_dimension_unknown: 'derived' (t1/2z)</li><li>dropped duplicate Q57 ('Induction t 1/2 (day)', value '0.001') — already have one for this compound</li><li>dropped unlinked row (NIL): 'Dose on F rel' — extend the ontology if this is a real PK parameter (source ['psp412996-tbl-0002:row10:col1', 'psp412996-tbl-0002:row10:col2'])</li><li>covariate level 'Moderate CYP3A4' → Q900:moderate_cyp3a4 = -0.273 (linear_fractional on Q27)</li><li>covariate level 'Strong CYP3A4' → Q900:strong_cyp3a4 = -1.069 (linear_fractional on Q27)</li><li>dropped unlinked row (NIL): 'ALKP' — extend the ontology if this is a real PK parameter (source ['psp412996-tbl-0002:row14:col1', 'psp412996-tbl-0002:row14:col2'])</li><li>covariate level 'CrCL' → Q900:crcl = 0.222 (power on Q27)</li><li>dropped unlinked row (NIL): 'Maleb' — extend the ontology if this is a real PK parameter (source ['psp412996-tbl-0002:row16:col1', 'psp412996-tbl-0002:row16:col2'])</li><li>dropped unlinked row (NIL): 'Black or African American' — extend the ontology if this is a real PK parameter (source ['psp412996-tbl-0002:row18:col1', 'psp412996-tbl-0002:row18:col2'])</li><li>dropped unlinked row (NIL): 'Asian' — extend the ontology if this is a real PK parameter (source ['psp412996-tbl-0002:row19:col1', 'psp412996-tbl-0002:row19:col2'])</li><li>dropped unlinked row (NIL): 'Tablet' — extend the ontology if this is a real PK parameter (source ['psp412996-tbl-0002:row21:col1', 'psp412996-tbl-0002:row21:col2', 'psp412996-tbl-0002:row24:col1', 'psp412996-tbl-0002:row24:col2'])</li><li>dropped unlinked row (NIL): 'Crushed tablet' — extend the ontology if this is a real PK parameter (source ['psp412996-tbl-0002:row22:col1', 'psp412996-tbl-0002:row22:col2', 'psp412996-tbl-0002:row25:col1', 'psp412996-tbl-0002:row25:col2'])</li><li>routed 'Variance CL' → Q315 (sigma) to residual_error — variability estimate, not a structural parameter</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 259200, Tolerance = 1e-9, Interval = 1));
end Sparsentan_Wada2023_reference;
