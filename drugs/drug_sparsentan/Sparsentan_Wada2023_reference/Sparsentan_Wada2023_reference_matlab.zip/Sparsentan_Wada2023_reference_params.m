function p = Sparsentan_Wada2023_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: sparsentan   source: Wada_2023 / reference   route: oral
  p.name  = 'Sparsentan_Wada2023_reference_params';
  p.drug  = 'sparsentan';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 49.3;                % central volume [L]
  p.CL = 3.88;                % clearance [L/h]
  p.Vp = [12.1];             % peripheral volumes [L]
  p.Q  = [2.03];             % inter-compartmental clearances [L/h]
  p.ka = 0.74;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.32;             % absorption lag [h]
  p.dose = 200.0;             % dose [mg]
end
