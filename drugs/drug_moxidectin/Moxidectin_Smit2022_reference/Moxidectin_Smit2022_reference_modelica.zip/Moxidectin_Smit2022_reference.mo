model Moxidectin_Smit2022_reference
  parameter Real Cl_ref = 1.2416666666666667e-06 "Cl [m3/s]";
  parameter Real cov_wt_0 = 0 "wt covariate";
  parameter Real Vd_ref = 0.136 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref*(1 + (0.75)*cov_wt_0),
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.63983,
    adminMass = 2e-06,
    ka = 0.0009388888888888888,
    Tlag = 5904.0,
    k12 = 2.0424836601307188e-05,
    k21 = 2.3701175578308686e-06
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About moxidectin</h4><p>Moxidectin is an antinematodal drug used to treat parasitic worm infections, notably onchocerciasis, and is also used in veterinary medicine. It is approved for human use in the United States and is also widely used as a veterinary antiparasitic.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q903824\">Wikidata Q903824</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>moxidectin</td></tr><tr><td>population:</td><td>adults infected with Strongyloides stercoralis</td></tr><tr><td>source_paper:</td><td>Smit_2022</td></tr><tr><td>measured_compound:</td><td>moxidectin</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>Tab2</td></tr><tr><td>input:</td><td>PK_2C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>moxidectin 639.83 g/mol (drugbank)</td></tr></table><h4>Interpretation flags</h4><ul><li>table section iiv: 'ωTlag' routed out of structural estimates ('Interindividual variability')</li><li>table section iiv: 'ωTlag' routed out of structural estimates ('Interindividual variability')</li><li>table section iiv: 'ωKa' routed out of structural estimates ('Interindividual variability')</li><li>table section iiv: 'ωCL/F' routed out of structural estimates ('Interindividual variability')</li><li>table section iiv: 'ωV1/F' routed out of structural estimates ('Interindividual variability')</li><li>table section iiv: 'ωQ/F' routed out of structural estimates ('Interindividual variability')</li><li>table section iiv: 'ωV2/F' routed out of structural estimates ('Interindividual variability')</li><li>table section residual_error: 'Proportional errorb' routed out of structural estimates ('Residual variability')</li><li>dropped value-less row: 'Parameter'</li><li>covariate level 'WT on Q/F' → Q900:wt_on_q_f = 0.75 (linear_fractional on Q27)</li><li>dropped value-less row: 'AGE'</li><li>dropped value-less row: 'CI'</li><li>dropped value-less row: 'CL/F'</li><li>dropped value-less row: 'CL/Fpop'</li><li>dropped value-less row: 'Ka'</li><li>dropped value-less row: 'Q/F'</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 432000, Tolerance = 1e-9, Interval = 1));
end Moxidectin_Smit2022_reference;
