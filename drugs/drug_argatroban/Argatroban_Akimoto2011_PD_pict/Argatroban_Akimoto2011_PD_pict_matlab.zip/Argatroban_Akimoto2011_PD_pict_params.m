function p = Argatroban_Akimoto2011_PD_pict_params()
% Argatroban_Akimoto2011_PD_pict_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% argatroban Akimoto_2011::PiCT: emax exposure-response sweep (response = E0 + Emax*frac). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one ng/mL per second, in SI inside (kg/m3, s). Response PiCT in s. Driver: argatroban (pk_record).
p.E0 = 25.0;
p.Emax = 129.0;
p.EC50 = 0.0011099999999999999;
p.gamma = 1.0;
p.slope = 0.0;
p.exposure_per_s = 1e-06;
p.stop_time = 12000.0;
p.form = 'E0 + Emax*frac';
end
