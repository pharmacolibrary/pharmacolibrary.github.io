function p = Argatroban_Cox2004_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: argatroban   source: Cox_2004 / reference   route: iv_bolus
  % estimated (absent from source): F
  p.name  = 'Argatroban_Cox2004_reference_params';
  p.drug  = 'argatroban';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'iv_bolus';        % 'oral' | 'iv_bolus'
  p.depot = false;             % oral -> first-order absorption depot
  p.Vc = 11.0;                % central volume [L]
  p.CL = 22.0;                % clearance [L/h]
  p.Vp = [13.0];             % peripheral volumes [L]
  p.Q  = [10.0];             % inter-compartmental clearances [L/h]
  p.ka = 0.0;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 1.75;             % dose [mg]
end
