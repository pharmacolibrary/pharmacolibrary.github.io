model Argatroban_Cox2004_reference
  parameter Real Cl_ref = 6.11111111111111e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.011 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.50864,
    adminMass = 1.75e-06,
    k12 = 0.0002525252525252525,
    k21 = 0.00021367521367521368
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About argatroban</h4><p>Argatroban is a direct thrombin inhibitor used as an anticoagulant, mainly in patients who cannot receive heparin, such as those with heparin-induced thrombocytopenia. It is an approved anticoagulant that is used in clinical practice, though it is not authorised in the European Union.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q27074501\">Wikidata Q27074501</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>argatroban</td></tr><tr><td>population:</td><td>patients undergoing percutaneous coronary intervention</td></tr><tr><td>source_paper:</td><td>Cox_2004</td></tr><tr><td>measured_compound:</td><td>argatroban</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>Table II</td></tr><tr><td>input:</td><td>PK_2C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>argatroban 508.64 g/mol (drugbank)</td></tr></table><h4>Interpretation flags</h4><ul><li>table section iiv: 'Clearanceb (CL), L/h' routed out of structural estimates ('IIV, % (%CV)')</li><li>table section iiv: 'Volume in central compartment (V1), L' routed out of structural estimates ('IIV, % (%CV)')</li><li>table section iiv: 'Volume in peripheral compartment (V2), L' routed out of structural estimates ('IIV, % (%CV)')</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=argatroban</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Argatroban_Cox2004_reference;
