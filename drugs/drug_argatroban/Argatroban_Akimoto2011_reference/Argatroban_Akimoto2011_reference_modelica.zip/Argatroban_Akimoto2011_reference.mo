model Argatroban_Akimoto2011_reference
  parameter Real Cl_ref = 5.833333333333334e-06 "Cl [m3/s]";
  parameter Real cov_wt_0 = 0 "wt covariate";
  parameter Real Vd_ref = 0.0092 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref*(1 + (0.11)*cov_wt_0),
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.50864,
    adminMass = 1.0500000000000001e-06,
    k12 = 0.0002747584541062802,
    k21 = 0.000382996632996633
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About argatroban</h4><p>Argatroban is a direct thrombin inhibitor used as an anticoagulant, mainly in patients who cannot receive heparin, such as those with heparin-induced thrombocytopenia. It is an approved anticoagulant that is used in clinical practice, though it is not authorised in the European Union.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q27074501\">Wikidata Q27074501</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>argatroban</td></tr><tr><td>population:</td><td>adults undergoing elective percutaneous coronary intervention</td></tr><tr><td>source_paper:</td><td>Akimoto_2011</td></tr><tr><td>measured_compound:</td><td>argatroban</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>Table III</td></tr><tr><td>input:</td><td>PK_2C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>argatroban 508.64 g/mol (drugbank)</td></tr></table><h4>Interpretation flags</h4><ul><li>table section iiv: 'CL, %CV' routed out of structural estimates ('Interindividual variability parameters')</li><li>table section iiv: 'CL, %CV' routed out of structural estimates ('Interindividual variability parameters')</li><li>table section iiv: 'V1, %CV' routed out of structural estimates ('Interindividual variability parameters')</li><li>table section iiv: 'V1, %CV' routed out of structural estimates ('Interindividual variability parameters')</li><li>table section iiv: 'V2, %CV' routed out of structural estimates ('Interindividual variability parameters')</li><li>table section iiv: 'V2, %CV' routed out of structural estimates ('Interindividual variability parameters')</li><li>table section iiv: 'Residual variability parameters, %CV' routed out of structural estimates ('Interindividual variability parameters')</li><li>table section iiv: 'Residual variability parameters, %CV' routed out of structural estimates ('Interindividual variability parameters')</li><li>covariate level 'Effect of WT' → Q900:effect_of_wt = 0.11 (linear_fractional on Q22)</li><li>implicit units: 'CL, ᵃ L/h' → L/h (from the paper text: &quot;Table II footnote a states: 'CL = 21 + 0.20 * (WT - 82)'&quot;)</li><li>implicit units: 'V1, ᵇ L' → L (from the paper text: &quot;Table II footnote b states: 'V1 = 9.2 + 0.11 * (WT - 82)'&quot;)</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=argatroban</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Argatroban_Akimoto2011_reference;
