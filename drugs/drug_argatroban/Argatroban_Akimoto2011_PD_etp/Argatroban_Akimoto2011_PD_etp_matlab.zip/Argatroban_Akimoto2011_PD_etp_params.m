function p = Argatroban_Akimoto2011_PD_etp_params()
% Argatroban_Akimoto2011_PD_etp_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% argatroban Akimoto_2011::ETP: sigmoid_emax exposure-response sweep (response = E0 + Emax*frac). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one ng/mL per second, in SI inside (kg/m3, s). Response ETP in %. Driver: argatroban (pk_record).
p.E0 = 0.0;
p.Emax = -0.97;
p.EC50 = 0.000245;
p.gamma = 1.8;
p.slope = 0.0;
p.exposure_per_s = 1e-06;
p.stop_time = 2500.0;
p.form = 'E0 + Emax*frac';
end
