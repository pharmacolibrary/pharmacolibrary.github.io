model Argatroban_Akimoto2011_PD_etp
  "sigmoid_emax exposure-response sweep — Akimoto_2011 :: ETP (endogenous thrombin potential)"
  extends Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep(
    E0 = 0,      // [1]
    Emax = -0.97,  // [1; % × 0.01]
    EC50 = 0.000245,  // [kg/m3; ng/mL × 1e-06]
    gamma = 1.8,
    exposure_per_s = 1e-06);   // 1 ng/mL per second
  // imax_as_negative_emax: Imax (Q323) enters SigmoidEmaxSweep as −Emax
  // defaulted: E0
  annotation(experiment(StartTime = 0, StopTime = 2500, Interval = 5),
    Documentation(info = "<html><body><!-- drug-about --><h4>About argatroban</h4><p>Argatroban is a direct thrombin inhibitor used as an anticoagulant, mainly in patients who cannot receive heparin, such as those with heparin-induced thrombocytopenia. It is an approved anticoagulant that is used in clinical practice, though it is not authorised in the European Union.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q27074501\">Wikidata Q27074501</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h4>Argatroban_Akimoto2011_PD_etp</h4><p>The steady-state exposure-response curve of Akimoto K et al., <i>Journal of clinical pharmacology 51(6):805–818</i> 2011 (<a href=\"https://doi.org/10.1177/0091270010372627\">doi:10.1177/0091270010372627</a>) — endogenous thrombin potential [%] against argatroban ng/mL — obtained by sweeping the driver instead of simulating a dose. Model family: sigmoid_emax.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = (library default) drug-free response (baseline)
  Emax  =         97 %        maximal effect term (E max, Q323)
  EC50  =        245 ng/mL    exposure at half of the maximal effect term (EC 50, Q321)
  gamma =        1.8          Hill coefficient (Hill constant, Q325)</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep\">SigmoidEmaxSweep</a>; this model only supplies the numbers. The x axis is one ng/mL of argatroban per second of simulated time (exposure is in kg/m3): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0   (drug-free)
  exposure = EC50 (245 ng/mL)  response -0.485
  exposure -> infinity  response -0.97</pre></body></html>"));
end Argatroban_Akimoto2011_PD_etp;
