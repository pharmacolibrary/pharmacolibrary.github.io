function p = Argatroban_Cox2004_PD_act_params()
% Argatroban_Cox2004_PD_act_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% argatroban Cox_2004::ACT: sigmoid_emax exposure-response sweep (response = E0 + Emax*frac). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one ng/mL per second, in SI inside (kg/m3, s). Response ACT in sec. Driver: argatroban (pk_record).
p.E0 = 148.0;
p.Emax = 316.0;
p.EC50 = 0.0019199999999999998;
p.gamma = 1.13;
p.slope = 0.0;
p.exposure_per_s = 1e-06;
p.stop_time = 20000.0;
p.form = 'E0 + Emax*frac';
end
