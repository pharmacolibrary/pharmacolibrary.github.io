function p = Argatroban_Akimoto2011_PD_act_params()
% Argatroban_Akimoto2011_PD_act_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% argatroban Akimoto_2011::ACT: sigmoid_emax exposure-response sweep (response = E0 + Emax*frac). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one ng/mL per second, in SI inside (kg/m3, s). Response ACT in s. Driver: argatroban (pk_record).
p.E0 = 116.0;
p.Emax = 516.0;
p.EC50 = 0.0040999999999999995;
p.gamma = 0.87;
p.slope = 0.0;
p.exposure_per_s = 1e-06;
p.stop_time = 41000.0;
p.form = 'E0 + Emax*frac';
end
