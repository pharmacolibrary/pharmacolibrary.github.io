model Argatroban_Akimoto2011_PD_aptt
  "emax exposure-response sweep — Akimoto_2011 :: aPTT (activated partial thromboplastin time)"
  extends Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep(
    E0 = 34,      // [s; s × 1]
    Emax = 84,  // [s; s × 1]
    EC50 = 0.00158,  // [kg/m3; ng/mL × 1e-06]
    gamma = 1,
    exposure_per_s = 1e-06);   // 1 ng/mL per second
  // defaulted: gamma
  annotation(experiment(StartTime = 0, StopTime = 16000, Interval = 32),
    Documentation(info = "<html><body><!-- drug-about --><h4>About argatroban</h4><p>Argatroban is a direct thrombin inhibitor used as an anticoagulant, mainly in patients who cannot receive heparin, such as those with heparin-induced thrombocytopenia. It is an approved anticoagulant that is used in clinical practice, though it is not authorised in the European Union.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q27074501\">Wikidata Q27074501</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h4>Argatroban_Akimoto2011_PD_aptt</h4><p>The steady-state exposure-response curve of Akimoto K et al., <i>Journal of clinical pharmacology 51(6):805–818</i> 2011 (<a href=\"https://doi.org/10.1177/0091270010372627\">doi:10.1177/0091270010372627</a>) — activated partial thromboplastin time [s] against argatroban ng/mL — obtained by sweeping the driver instead of simulating a dose. Model family: emax.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    =         34 s        drug-free response (baseline) (Baseline, Q324)
  Emax  =         84 s        maximal effect term (E max, Q320)
  EC50  =       1580 ng/mL    exposure at half of the maximal effect term (EC 50, Q321)
  gamma = (library default) Hill coefficient</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep\">SigmoidEmaxSweep</a>; this model only supplies the numbers. The x axis is one ng/mL of argatroban per second of simulated time (exposure is in kg/m3): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 34   (drug-free)
  exposure = EC50 (1580 ng/mL)  response 76
  exposure -> infinity  response 118</pre></body></html>"));
end Argatroban_Akimoto2011_PD_aptt;
