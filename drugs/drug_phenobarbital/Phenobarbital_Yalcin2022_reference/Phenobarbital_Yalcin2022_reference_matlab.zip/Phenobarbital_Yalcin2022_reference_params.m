function p = Phenobarbital_Yalcin2022_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: phenobarbital   source: Yalcin_2022 / reference   route: iv_bolus
  % estimated (absent from source): F
  p.name  = 'Phenobarbital_Yalcin2022_reference_params';
  p.drug  = 'phenobarbital';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'iv_bolus';        % 'oral' | 'iv_bolus'
  p.depot = false;             % oral -> first-order absorption depot
  p.Vc = 1.82;                % central volume [L]
  p.CL = 5.88;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.0;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 100.0;             % dose [mg]
end
