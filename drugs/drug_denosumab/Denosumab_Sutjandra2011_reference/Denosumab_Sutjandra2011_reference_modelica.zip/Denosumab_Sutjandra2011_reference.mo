model Denosumab_Sutjandra2011_reference
  parameter Real Cl_ref = 6.477563131313132e-09 "Cl [m3/s]";
  parameter Real Vd_ref = 0.0026409090909090913 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    adminMass = 3.3e-07
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About denosumab</h4><p>Denosumab is a monoclonal antibody used to treat bone diseases, especially postmenopausal osteoporosis and bone loss linked to cancer. It is widely used and authorised in the European Union, with products covering osteoporosis, bone resorption, bone tumours, and giant cell tumour of bone.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q408283\">Wikidata Q408283</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>denosumab</td></tr><tr><td>population:</td><td>healthy subjects and postmenopausal women with osteopenia or osteoporosis</td></tr><tr><td>source_paper:</td><td>Sutjandra_2011</td></tr><tr><td>measured_compound:</td><td>denosumab</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C: IV (no input phase)</td></tr></table><h4>Interpretation flags</h4><ul><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=denosumab</li><li>held at status:extracted — NIL link or unit issue (mismatch/unknown/normalisation-failed) present</li><li>structure disagreement: deterministic 1C vs LLM 2C — review compartment count</li><li>1C volume normalization: Q63→Q61 (single-compartment model has no central/peripheral split; 'central volume of distribution' is the general volume)</li><li>status held at route_to_review — not promoted</li><li>molar mass: none found for 'denosumab' — its concentrations stay mass-only</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li><li>skipped review gap-fill of CL: primary's parameterization (rate-constant / ka-only) does not use it</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary's parameterization (rate-constant / ka-only) does not use it</li><li>derived CL=0.0233192 L/h from Ke × V = CL (Q47 × Q61); not separately reported</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 1468800, Tolerance = 1e-9, Interval = 1));
end Denosumab_Sutjandra2011_reference;
