model Progabide_Johno1982_reference
  parameter Real Cl_ref = 4.0638888888888886e-05 "Cl [m3/s]";
  parameter Real Vd_ref = 0.1379 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.33477999999999997,
    adminMass = 1e-05
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About progabide</h4><p>Progabide is an anticonvulsant drug developed for the treatment of epilepsy, with additional antidepressant and antiparkinsonian properties. It is classed as an experimental agent and is not an established, widely marketed medicine today.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q426524\">Wikidata Q426524</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>progabide</td></tr><tr><td>population:</td><td>male rhesus monkeys</td></tr><tr><td>source_paper:</td><td>Johno_1982</td></tr><tr><td>measured_compound:</td><td>progabide</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>progabide 334.78 g/mol (drugbank)</td></tr></table><h4>Interpretation flags</h4><ul><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=progabide</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Progabide_Johno1982_reference;
