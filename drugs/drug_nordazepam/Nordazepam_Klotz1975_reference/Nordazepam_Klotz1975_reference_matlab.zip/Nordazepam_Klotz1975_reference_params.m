function p = Nordazepam_Klotz1975_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: nordazepam   source: Klotz_1975 / reference   route: iv_bolus
  % estimated (absent from source): F, dose
  p.name  = 'Nordazepam_Klotz1975_reference_params';
  p.drug  = 'nordazepam';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'iv_bolus';        % 'oral' | 'iv_bolus'
  p.depot = false;             % oral -> first-order absorption depot
  p.Vc = 22.506043;                % central volume [L]
  p.CL = 0.78;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.0;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 10.0;             % dose [mg]
end
