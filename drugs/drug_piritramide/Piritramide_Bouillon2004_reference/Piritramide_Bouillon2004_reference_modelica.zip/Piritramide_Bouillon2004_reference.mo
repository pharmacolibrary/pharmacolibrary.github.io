model Piritramide_Bouillon2004_reference
  parameter Real Cl_ref = 1.8472222222222224e-05 "Cl [m3/s]";
  parameter Real Vd_ref = 0.0479 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.4305851,
    adminMass = 4.5e-05,
    k12 = 0.0012468104848063094,
    k21 = 0.00014856274184632393
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About piritramide</h4><p>Piritramide is a strong opioid painkiller used to treat moderate to severe pain, such as pain after surgery. It is not approved everywhere and has been withdrawn in some countries, but it remains in clinical use in parts of Europe, mainly in hospital settings.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q416439\">Wikidata Q416439</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>piritramide</td></tr><tr><td>population:</td><td>intensive care patients</td></tr><tr><td>source_paper:</td><td>Bouillon_2004</td></tr><tr><td>measured_compound:</td><td>piritramide</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_2C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>piritramide 430.585 g/mol (drugbank)</td></tr></table><h4>Interpretation flags</h4><ul><li>unit_dimension_unknown: 'Lh(-1)' (CL)</li><li>unit_dimension_unknown: 'Lh(-1)' (Q)</li><li>unit_dimension_unknown: 'Lh(-1)' (CL)</li><li>dropped duplicate Q22 ('Cl3', value 18.4) — already have one for this compound</li><li>implicit units: 'clearances Cl1' → L/h (from the popPK convention: 'No unit provided in text or table. Clearance is conventionally expressed in L/h, and the magnitude 66.5 is consistent wi')</li><li>implicit units: 'Cl2' → L/h (from the popPK convention: 'No unit provided in text or table. Intercompartmental clearance (Q) is conventionally expressed in L/h, and the magnitud')</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=piritramide</li><li>structure disagreement: deterministic 2C vs LLM 3C — review compartment count</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 345600, Tolerance = 1e-9, Interval = 1));
end Piritramide_Bouillon2004_reference;
