model Finerenone_Heinig2023_reference
  parameter Real Cl_ref = 8.305555555555555e-06 "Cl [m3/s]";
  parameter Real cov_egfr_0 = 0 "egfr covariate";
  parameter Real cov_height_1 = 0 "height covariate";
  parameter Real cov_creatinine_2 = 0 "creatinine covariate";
  parameter Real cov_smoking_3 = 0 "smoking covariate";
  parameter Real cov_cyp3a4_4 = 0 "cyp3a4 covariate";
  parameter Real cov_cyp3a4_5 = 0 "cyp3a4 covariate";
  parameter Real Vd_ref = 0.113 "Vd [m3]";
  parameter Real cov_body_weight_0 = 0 "body weight covariate";
  parameter Boolean cov_category_1 = false "category level 1";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref*(1 + (0.155)*cov_egfr_0)*(1 + (0.72)*cov_height_1)*(1 + (0.118)*cov_creatinine_2)*(1 + (1.04)*cov_smoking_3)*(1 + (0.951)*cov_cyp3a4_4)*(1 + (0.996)*cov_cyp3a4_5),
    Vd = Vd_ref*(1 + (0.501)*cov_body_weight_0) + (0.0012900000000000001)*(if cov_category_1 then 1 else 0),
    adminDuration = 600,
    adminCount = 1,
    MM = 0.378432,
    adminMass = 1.25e-06,
    ka = 0.00625,
    Tlag = 774.0
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>finerenone</td></tr><tr><td>population:</td><td>adults with CKD and T2D</td></tr><tr><td>source_paper:</td><td>Heinig_2023</td></tr><tr><td>measured_compound:</td><td>finerenone</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>Tab3</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>finerenone 378.432 g/mol (drugbank)</td></tr></table><h4>Interpretation flags</h4><ul><li>table section iiv: 'ω2 CL/Fa' routed out of structural estimates ('Interindividual variability')</li><li>table section iiv: 'ω2 CL/Fa' routed out of structural estimates ('Interindividual variability')</li><li>table section iiv: 'ω2 Vc/Fb' routed out of structural estimates ('Interindividual variability')</li><li>table section iiv: 'ω2 Vc/Fb' routed out of structural estimates ('Interindividual variability')</li><li>table section iiv: 'Covariance CL/F × Vc/F' routed out of structural estimates ('Interindividual variability')</li><li>table section iiv: 'Covariance CL/F × Vc/F' routed out of structural estimates ('Interindividual variability')</li><li>table section residual_error: 'σ2' routed out of structural estimates ('Residual error')</li><li>table section residual_error: 'σ2' routed out of structural estimates ('Residual error')</li><li>covariate level 'Effect of eGFR-EPI (time-varying) on CL/F and F' → Q900:effect_of_egfr_epi_time_varying_on_cl_f_and_f = 0.155 (linear_fractional on Q27)</li><li>covariate level 'Effect of body height on CL/F and F' → Q900:effect_of_body_height_on_cl_f_and_f = 0.720 (linear_fractional on Q27)</li><li>covariate level 'Effect of creatinine on CL/F and F' → Q900:effect_of_creatinine_on_cl_f_and_f = 0.118 (linear_fractional on Q27)</li><li>dropped unlinked row (NIL): 'Effect of SGLT-2 inhibitor use (≥50% of treatment period) on CL/F and F' — extend the ontology if this is a real PK parameter (source ['Tab3:row13:col1', 'Tab3:row13:col2'])</li><li>covariate level 'Effect of smoking (current or former smokers) on CL/F and F' → Q900:effect_of_smoking_current_or_former_smokers_on_cl_f_and_f = 1.04 (linear_fractional on Q27)</li><li>dropped duplicate Q27 ('Effect of GGT on CL/F', value '-0.0694') — already have one for this compound</li><li>covariate level 'Effect of CYP3A4 inhibitor use (weak, moderate or strong ≥50% of on treatment period) on CL/F and F' → Q900:effect_of_cyp3a4_inhibitor_use_weak_moderate_or_strong_ge_50_of_on_treatment_period_on_cl_f_and_f = 0.951 (linear_fractional on Q27)</li><li>covariate level 'Effect of CYP3A4 inhibitor use (other categories) on CL/F and F' → Q900:effect_of_cyp3a4_inhibitor_use_other_categories_on_cl_f_and_f = 0.996 (linear_fractional on Q27)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Finerenone_Heinig2023_reference;
