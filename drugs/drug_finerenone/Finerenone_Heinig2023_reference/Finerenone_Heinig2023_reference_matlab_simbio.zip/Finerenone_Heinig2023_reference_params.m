function p = Finerenone_Heinig2023_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: finerenone   source: Heinig_2023 / reference   route: oral
  p.name  = 'Finerenone_Heinig2023_reference_params';
  p.drug  = 'finerenone';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 113.0;                % central volume [L]
  p.CL = 29.9;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 22.5;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.215;             % absorption lag [h]
  p.dose = 1.25;             % dose [mg]
end
