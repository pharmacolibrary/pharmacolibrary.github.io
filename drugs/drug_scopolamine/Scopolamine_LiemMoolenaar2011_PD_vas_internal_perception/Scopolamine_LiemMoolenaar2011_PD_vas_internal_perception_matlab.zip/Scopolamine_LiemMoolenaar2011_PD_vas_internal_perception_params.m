function p = Scopolamine_LiemMoolenaar2011_PD_vas_internal_perception_params()
% Scopolamine_LiemMoolenaar2011_PD_vas_internal_perception_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% scopolamine Liem-Moolenaar_2011::VAS_internal_perception: linear exposure-response sweep (response = E0 + slope*exposure). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one pg ml-1 per second, in SI inside (kg/m3, s). Response VAS internal perception in log mm. Driver: scopolamine (pk_record).
p.E0 = 0.336;
p.Emax = 0.0;
p.EC50 = 1.0;
p.gamma = 1.0;
p.slope = 0.000331;
p.exposure_per_s = 1e-09;
p.stop_time = 1000.0;
p.form = 'E0 + slope*exposure';
end
