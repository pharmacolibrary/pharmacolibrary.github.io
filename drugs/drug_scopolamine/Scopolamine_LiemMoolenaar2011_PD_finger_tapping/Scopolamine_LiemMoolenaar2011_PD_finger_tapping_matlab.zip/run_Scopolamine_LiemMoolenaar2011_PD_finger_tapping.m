% run_Scopolamine_LiemMoolenaar2011_PD_finger_tapping  Evaluate the exposure-response curve and plot response against exposure.
% A sweep is a static map: no ODE solver is needed. exposure runs 0..stop_time*exposure_per_s.
p = Scopolamine_LiemMoolenaar2011_PD_finger_tapping_params();
exposure = linspace(0, p.stop_time * p.exposure_per_s, 501);
frac = exposure.^p.gamma ./ (p.EC50^p.gamma + exposure.^p.gamma);
E0 = p.E0; Emax = p.Emax; slope = p.slope;
response = E0 + slope.*exposure;
figure; plot(exposure, response, 'LineWidth', 1.5); grid on;
xlabel('exposure [pg ml-1]'); ylabel('response [taps (10 s)-1]'); title('Scopolamine_LiemMoolenaar2011_PD_finger_tapping', 'Interpreter', 'none');
writematrix([exposure(:) response(:)], 'Scopolamine_LiemMoolenaar2011_PD_finger_tapping.csv');
