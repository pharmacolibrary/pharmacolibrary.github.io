function p = Scopolamine_LiemMoolenaar2011_PD_vas_alertness_params()
% Scopolamine_LiemMoolenaar2011_PD_vas_alertness_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% scopolamine Liem-Moolenaar_2011::VAS_alertness: linear exposure-response sweep (response = E0 + slope*exposure). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one pg ml-1 per second, in SI inside (kg/m3, s). Response VAS alertness in mm. Driver: scopolamine (pk_record).
p.E0 = 53.6;
p.Emax = 0.0;
p.EC50 = 1.0;
p.gamma = 1.0;
p.slope = -6.219999999999999e-14;
p.exposure_per_s = 1e-09;
p.stop_time = 1000.0;
p.form = 'E0 + slope*exposure';
end
