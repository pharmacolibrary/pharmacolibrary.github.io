function p = Scopolamine_Ebert2001_PD_eeg_alpha_power_params()
% Scopolamine_Ebert2001_PD_eeg_alpha_power_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% scopolamine Ebert_2001::EEG_alpha_power: sigmoid_emax exposure-response sweep (response = E0 + Emax*frac). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one ng/ml per second, in SI inside (kg/m3, s). Response EEG alpha power in microV2. Driver: scopolamine (pk_record).
p.E0 = 0.58;
p.Emax = -0.29;
p.EC50 = 6e-07;
p.gamma = 1.17;
p.slope = 0.0;
p.exposure_per_s = 1e-06;
p.stop_time = 6.0;
p.form = 'E0 + Emax*frac';
end
