model Scopolamine_LiemMoolenaar2011_PD_body_sway
  "linear exposure-response sweep — Liem-Moolenaar_2011 :: Body sway (Body sway)"
  extends Pharmacolibrary.Interfaces.PartialExposureResponseSweep(
    E0 = 2.4,      // [log mm]
    Emax = 0, EC50 = 1,      // unused by a line
    exposure_per_s = 1e-09);
  parameter Real slope = 0.00147   "[log mm (pg ml-1)]";
equation
  response = E0 + slope*exposure;
  // family_inferred: the record's model family is effect_compartment; read from the parameters: a slope and no Emax — linear
  annotation(experiment(StartTime = 0, StopTime = 1000, Interval = 2),
    Documentation(info = "<html><body><h4>Scopolamine_LiemMoolenaar2011_PD_body_sway</h4><p>The steady-state exposure-response curve of Liem-Moolenaar M et al., <i>British journal of clinical pharmacology 71(6):886–898</i> 2011 (<a href=\"https://doi.org/10.1111/j.1365-2125.2011.03936.x\">doi:10.1111/j.1365-2125.2011.03936.x</a>) — Body sway [log mm] against scopolamine pg ml-1 — obtained by sweeping the driver instead of simulating a dose. Model family: linear.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    =        2.4 log mm   drug-free response (baseline) (Intercept, Q324)
  slope =    0.00147 log mm (pg ml-1) change in response per unit of exposure (Slope, Q335)</pre><p>The algebra is <code>response = E0 + slope*exposure</code>; this model only supplies the numbers. The x axis is one pg ml-1 of scopolamine per second of simulated time (exposure is in kg/m3): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 2.4   (drug-free)</pre></body></html>"));
end Scopolamine_LiemMoolenaar2011_PD_body_sway;
