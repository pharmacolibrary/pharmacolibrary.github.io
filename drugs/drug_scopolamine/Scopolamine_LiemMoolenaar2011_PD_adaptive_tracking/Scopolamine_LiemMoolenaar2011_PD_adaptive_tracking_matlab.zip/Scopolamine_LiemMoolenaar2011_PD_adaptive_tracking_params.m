function p = Scopolamine_LiemMoolenaar2011_PD_adaptive_tracking_params()
% Scopolamine_LiemMoolenaar2011_PD_adaptive_tracking_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% scopolamine Liem-Moolenaar_2011::Adaptive_tracking: linear exposure-response sweep (response = E0 + slope*exposure). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one pg ml-1 per second, in SI inside (kg/m3, s). Response Adaptive tracking in %. Driver: scopolamine (pk_record).
p.E0 = 0.000479;
p.Emax = 0.0;
p.EC50 = 1.0;
p.gamma = 1.0;
p.slope = -2.1699999999999998e-13;
p.exposure_per_s = 1e-09;
p.stop_time = 1000.0;
p.form = 'E0 + slope*exposure';
end
