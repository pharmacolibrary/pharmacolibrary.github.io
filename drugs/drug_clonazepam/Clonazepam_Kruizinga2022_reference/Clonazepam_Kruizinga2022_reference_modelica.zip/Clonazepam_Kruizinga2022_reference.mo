model Clonazepam_Kruizinga2022_reference
  parameter Real Cl_ref = 4.444444444444445e-08 "Cl [m3/s]";
  parameter Real Vd_ref = 0.0115 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.315711,
    adminMass = 5e-07,
    k12 = 0.00027053140096618356,
    k21 = 0.00024117140396210163
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>clonazepam</td></tr><tr><td>population:</td><td>healthy adults</td></tr><tr><td>source_paper:</td><td>Kruizinga_2022</td></tr><tr><td>measured_compound:</td><td>clonazepam</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>bcp15152-tbl-0002</td></tr><tr><td>input:</td><td>PK_2C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>clonazepam 315.711 g/mol (drugbank)</td></tr></table><h4>Interpretation flags</h4><ul><li>column 'parameter' classified 'other' by the LLM but kept: the deterministic diagnostic-column test disagrees (a stratum column is a value column, not a statistic)</li><li>column 'parameter' classified 'other' by the LLM but kept: the deterministic diagnostic-column test disagrees (a stratum column is a value column, not a statistic)</li><li>column 'parameter' classified 'other' by the LLM but kept: the deterministic diagnostic-column test disagrees (a stratum column is a value column, not a statistic)</li><li>column 'parameter' classified 'other' by the LLM but kept: the deterministic diagnostic-column test disagrees (a stratum column is a value column, not a statistic)</li><li>column 'parameter' classified 'other' by the LLM but kept: the deterministic diagnostic-column test disagrees (a stratum column is a value column, not a statistic)</li><li>column 'parameter' classified 'other' by the LLM but kept: the deterministic diagnostic-column test disagrees (a stratum column is a value column, not a statistic)</li><li>column 'parameter' classified 'other' by the LLM but kept: the deterministic diagnostic-column test disagrees (a stratum column is a value column, not a statistic)</li><li>column 'parameter' classified 'other' by the LLM but kept: the deterministic diagnostic-column test disagrees (a stratum column is a value column, not a statistic)</li><li>dropped diagnostic row 'Plasma kinetics' → Q318 (shrinkage) — reported statistic, not a parameter</li><li>dropped diagnostic row 'θ Prob. slow group' → Q318 (shrinkage) — reported statistic, not a parameter</li><li>dropped unlinked row (NIL): 'Saliva kinetics' — extend the ontology if this is a real PK parameter (source ['bcp15152-tbl-0002:row7:col2', 'bcp15152-tbl-0002:row7:col3', 'bcp15152-tbl-0002:row7:col4'])</li><li>dropped diagnostic row 'θ RatioMAX' → Q318 (shrinkage) — reported statistic, not a parameter</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=clonazepam</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 950400, Tolerance = 1e-9, Interval = 1));
end Clonazepam_Kruizinga2022_reference;
