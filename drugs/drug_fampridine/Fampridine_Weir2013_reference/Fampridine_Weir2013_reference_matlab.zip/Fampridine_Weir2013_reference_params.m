function p = Fampridine_Weir2013_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: fampridine   source: Weir_2013 / reference   route: oral
  p.name  = 'Fampridine_Weir2013_reference_params';
  p.drug  = 'fampridine';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 304.0;                % central volume [L]
  p.CL = 36.0;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 1.22;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 20.0;             % dose [mg]
end
