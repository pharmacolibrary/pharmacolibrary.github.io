model Fampridine_Renou2026_reference
  parameter Real Cl_ref = 4.1944444444444445e-08 "Cl [m3/s]";
  parameter Real Vd_ref = 0.0052699999999999995 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.0941145,
    adminMass = 2e-05,
    ka = 0.00039166666666666663,
    Tlag = 0.0,
    k12 = 2.67235926628716e-05,
    k21 = 5.7956104252400534e-05
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About fampridine</h4><p>Fampridine (dalfampridine), a potassium channel blocker, is used to improve walking in people with multiple sclerosis, including its progressive and relapsing-remitting forms. It is authorised in the European Union for multiple sclerosis and is also being investigated for other uses.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q372539\">Wikidata Q372539</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>fampridine</td></tr><tr><td>population:</td><td>review reference</td></tr><tr><td>source_paper:</td><td>Renou_2026</td></tr><tr><td>measured_compound:</td><td>fampridine</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_2C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>fampridine 94.1145 g/mol (drugbank)</td></tr></table><p><b>Defaulted (base-class default used):</b> Tlag.</p><h4>Interpretation flags</h4><ul><li>built from REVIEW reference values (Renou_2026) — secondary source</li><li>volume reported by review</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 518400, Tolerance = 1e-9, Interval = 1));
end Fampridine_Renou2026_reference;
