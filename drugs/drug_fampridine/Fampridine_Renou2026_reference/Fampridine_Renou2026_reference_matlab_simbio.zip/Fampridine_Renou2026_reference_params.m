function p = Fampridine_Renou2026_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: fampridine   source: Renou_2026 / reference   route: oral
  p.name  = 'Fampridine_Renou2026_reference_params';
  p.drug  = 'fampridine';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 5.27;                % central volume [L]
  p.CL = 0.151;                % clearance [L/h]
  p.Vp = [2.43];             % peripheral volumes [L]
  p.Q  = [0.507];             % inter-compartmental clearances [L/h]
  p.ka = 1.41;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 20.0;             % dose [mg]
end
