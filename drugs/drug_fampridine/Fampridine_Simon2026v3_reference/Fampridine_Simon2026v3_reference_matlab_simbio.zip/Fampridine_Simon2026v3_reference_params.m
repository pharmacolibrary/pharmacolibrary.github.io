function p = Fampridine_Simon2026v3_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: fampridine   source: Simon_2026_3 / reference   route: oral
  % estimated (absent from source): F
  p.name  = 'Fampridine_Simon2026v3_reference_params';
  p.drug  = 'fampridine';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 50.0;                % central volume [L]
  p.CL = 5.0;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 1.0;                % absorption rate [1/h]
  p.F  = 0.9;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 20.0;             % dose [mg]
end
