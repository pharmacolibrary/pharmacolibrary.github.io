% Run (SimBiology): build model + dose, simulate 0..29.0 h, plot.
p = Fampridine_Rupp1983_reference_params();
[model, dose, variant] = build_sb_pk(p);
sd = simulate_sb(model, variant, dose, 29.0);
