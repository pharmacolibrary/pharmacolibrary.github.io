model Epoprostenol_Vucicevic2025_reference
  parameter Real Cl_ref = 3.861111111111112e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.23700000000000002 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.35246510000000003,
    adminMass = 0.0001,
    ka = 8.333333333333333e-05,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About epoprostenol</h4><p>Epoprostenol (prostacyclin) is used to treat pulmonary hypertension, including portopulmonary and primary pulmonary hypertension, and chronic pulmonary heart disease. It is an approved drug that acts as an antithypertensive and platelet aggregation inhibitor, and is also being studied for other investigational uses.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q412050\">Wikidata Q412050</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>epoprostenol</td></tr><tr><td>population:</td><td>review reference</td></tr><tr><td>source_paper:</td><td>Vucicevic_2025</td></tr><tr><td>measured_compound:</td><td>epoprostenol</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>epoprostenol 352.465 g/mol (drugbank)</td></tr></table><p><b>Defaulted (base-class default used):</b> Tlag.</p><h4>Interpretation flags</h4><ul><li>built from REVIEW reference values (Vucicevic_2025) — secondary source</li><li>volume reported by review</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 259200, Tolerance = 1e-9, Interval = 1));
end Epoprostenol_Vucicevic2025_reference;
