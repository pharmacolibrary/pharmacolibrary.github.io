model Epoprostenol_Nicolas2012_reference
  parameter Real Cl_ref = 1.2194444444444445e-05 "Cl [m3/s]";
  parameter Real Vd_ref = 0.458 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    adminMass = 0.0001,
    ka = 0.0006000000000000001,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About epoprostenol</h4><p>Epoprostenol (prostacyclin) is used to treat pulmonary hypertension, including portopulmonary and primary pulmonary hypertension, and chronic pulmonary heart disease. It is an approved drug that acts as an antithypertensive and platelet aggregation inhibitor, and is also being studied for other investigational uses.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q412050\">Wikidata Q412050</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>epoprostenol</td></tr><tr><td>population:</td><td>healthy male subjects</td></tr><tr><td>source_paper:</td><td>Nicolas_2012</td></tr><tr><td>measured_compound:</td><td>6-keto-prostacyclin F1a</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>tab_1</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>epoprostenol 352.465 g/mol (drugbank)</td></tr></table><p><b>Defaulted (base-class default used):</b> Tlag.</p><h4>Interpretation flags</h4><ul><li>dropped unlinked row (NIL): 'PK parameters' — extend the ontology if this is a real PK parameter (source ['tab_1:row2:col1', 'tab_1:row2:col2'])</li><li>covariate effect for Q44 has no base parameter row (kept as unattached equation-variable)</li><li>covariate effect for Q44 has no base parameter row (kept as unattached equation-variable)</li><li>covariate effect for Q83 has no base parameter row (kept as unattached equation-variable)</li><li>metabolite 6-keto-prostacyclin f1a: Q22→Q351 — only the metabolite is measured and fm is not identifiable, so its CL/V are apparent (fm-divided)</li><li>metabolite 6-keto-prostacyclin f1a: Q61→Q367 — only the metabolite is measured and fm is not identifiable, so its CL/V are apparent (fm-divided)</li><li>apparent-ness (ontology-grounded): parameterization=apparent, measured_compound=6-keto-prostacyclin F1a</li><li>template fit: PK_3M_9C — formed from central; parent 1, metabolites [0]</li><li>structure disagreement: deterministic 1C vs LLM 2C — review compartment count</li><li>row roles (LLM): model_class=compartmental; 6/6 row label(s) assigned, 6 linked by role; re-tagged 6-keto-prostacyclin F1a→parent ×15</li><li>molar mass: none of 1 PubChem candidate(s) is '6-keto-prostacyclin F1a' (LLM) — left in mass units</li><li>molar mass: none found for '6-keto-prostacyclin F1a' — its concentrations stay mass-only</li><li>gap-filled Q27 (CL/F) from Vizza_2017's review values (primary lacked it)</li><li>gap-filled Q76 (V/F) from Vizza_2017's review values (primary lacked it)</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 136800, Tolerance = 1e-9, Interval = 1));
end Epoprostenol_Nicolas2012_reference;
