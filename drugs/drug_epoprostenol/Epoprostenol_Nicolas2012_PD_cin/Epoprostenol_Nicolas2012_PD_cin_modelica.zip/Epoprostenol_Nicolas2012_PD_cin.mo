model Epoprostenol_Nicolas2012_PD_cin
  "linear exposure-response sweep — Nicolas_2012 :: CIn (cardiac index)"
  extends Pharmacolibrary.Interfaces.PartialExposureResponseSweep(
    E0 = 0,      // [1]
    Emax = 0, EC50 = 1,      // unused by a line
    exposure_per_s = 1e-09);
  parameter Real slope = 0.0011299   "[1]";
equation
  response = E0 + slope*exposure;
  // defaulted: E0
  annotation(experiment(StartTime = 0, StopTime = 1000, Interval = 2),
    Documentation(info = "<html><body><!-- drug-about --><h4>About epoprostenol</h4><p>Epoprostenol (prostacyclin) is used to treat pulmonary hypertension, including portopulmonary and primary pulmonary hypertension, and chronic pulmonary heart disease. It is an approved drug that acts as an antithypertensive and platelet aggregation inhibitor, and is also being studied for other investigational uses.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q412050\">Wikidata Q412050</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h4>Epoprostenol_Nicolas2012_PD_cin</h4><p>The steady-state exposure-response curve of Nicolas LB et al., <i>British journal of clinical pharmacology 74(6):978-989</i> 2012 (<a href=\"https://doi.org/10.1111/j.1365-2125.2012.04301.x\">doi:10.1111/j.1365-2125.2012.04301.x</a>) — cardiac index [l min -1 m -2] against 6-keto-prostacyclin F1a pg ml -1 — obtained by sweeping the driver instead of simulating a dose. Model family: linear.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = (library default) drug-free response (baseline)
  slope =  0.0011299          change in response per unit of exposure (slope, Q335)</pre><p>The algebra is <code>response = E0 + slope*exposure</code>; this model only supplies the numbers. The x axis is one pg ml -1 of 6-keto-prostacyclin F1a per second of simulated time (exposure is in kg/m3): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0   (drug-free)</pre></body></html>"));
end Epoprostenol_Nicolas2012_PD_cin;
