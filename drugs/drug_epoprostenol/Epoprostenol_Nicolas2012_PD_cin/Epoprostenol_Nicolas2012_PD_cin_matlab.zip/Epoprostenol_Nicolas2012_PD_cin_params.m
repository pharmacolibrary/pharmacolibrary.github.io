function p = Epoprostenol_Nicolas2012_PD_cin_params()
% Epoprostenol_Nicolas2012_PD_cin_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% epoprostenol Nicolas_2012::CIn: linear exposure-response sweep (response = E0 + slope*exposure). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one pg ml -1 per second, in SI inside (kg/m3, s). Response CIn in l min -1 m -2. Driver: 6-keto-prostacyclin F1a (pk_record).
p.E0 = 0.0;
p.Emax = 0.0;
p.EC50 = 1.0;
p.gamma = 1.0;
p.slope = 0.0011299;
p.exposure_per_s = 1e-09;
p.stop_time = 1000.0;
p.form = 'E0 + slope*exposure';
end
