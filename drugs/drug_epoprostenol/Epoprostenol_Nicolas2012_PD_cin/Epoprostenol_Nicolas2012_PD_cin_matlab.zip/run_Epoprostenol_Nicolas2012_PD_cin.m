% run_Epoprostenol_Nicolas2012_PD_cin  Evaluate the exposure-response curve and plot response against exposure.
% A sweep is a static map: no ODE solver is needed. exposure runs 0..stop_time*exposure_per_s.
p = Epoprostenol_Nicolas2012_PD_cin_params();
exposure = linspace(0, p.stop_time * p.exposure_per_s, 501);
frac = exposure.^p.gamma ./ (p.EC50^p.gamma + exposure.^p.gamma);
E0 = p.E0; Emax = p.Emax; slope = p.slope;
response = E0 + slope.*exposure;
figure; plot(exposure, response, 'LineWidth', 1.5); grid on;
xlabel('exposure [pg ml -1]'); ylabel('response [l min -1 m -2]'); title('Epoprostenol_Nicolas2012_PD_cin', 'Interpreter', 'none');
writematrix([exposure(:) response(:)], 'Epoprostenol_Nicolas2012_PD_cin.csv');
