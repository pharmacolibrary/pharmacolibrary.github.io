model Tolmetin_FloresMurrieta1998_PD_antinociceptive_effect
  "indirect_response_i exposure-response sweep — Flores-Murrieta_1998 :: antinociceptive effect (antinociceptive effect)"
  extends Pharmacolibrary.Pharmacodynamic.IndirectTurnoverSweep(
    E0 = 0,      // [1]
    Emax = 76,  // type IV effect term
    EC50 = 0.00922,  // [kg/m3; micrograms/ml × 0.001]
    gamma = 1,
    exposure_per_s = 0.001);   // 1 micrograms/ml per second
  // emax_not_a_fraction: type I needs Imax ≤ 1 but the record has 76; bound as the reciprocal stimulation form (IV) the paper fitted
  // defaulted: E0
  // defaulted: gamma
  annotation(experiment(StartTime = 0, StopTime = 93, Interval = 0.186),
    Documentation(info = "<html><body><!-- drug-about --><h4>About tolmetin</h4><p>Tolmetin is a non-steroidal anti-inflammatory drug used to treat osteoarthritis, rheumatoid arthritis, and juvenile rheumatoid arthritis. It is an approved medicine, available as oral antiinflammatory products and topical preparations for joint and muscular pain.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q3992411\">Wikidata Q3992411</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h4>Tolmetin_FloresMurrieta1998_PD_antinociceptive_effect</h4><p>The steady-state exposure-response curve of Flores-Murrieta FJ et al., <i>Journal of pharmacokinetics and biopharmaceutics 26(5):547–557</i> 1998 (<a href=\"https://doi.org/10.1023/a:1023273100270\">doi:10.1023/a:1023273100270</a>) — antinociceptive effect [%] against tolmetin micrograms/ml — obtained by sweeping the driver instead of simulating a dose. Model family: indirect_response_i.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = (library default) drug-free response (baseline)
  Emax  =         76          maximal effect term (maximal inhibition, Q323)
  EC50  =       9.22 micrograms/ml exposure at half of the maximal effect term (IC50, Q322)
  gamma = (library default) Hill coefficient</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.IndirectTurnoverSweep\">IndirectTurnoverSweep</a>; this model only supplies the numbers. The x axis is one micrograms/ml of tolmetin per second of simulated time (exposure is in kg/m3): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><p>The effect term enters as a reciprocal (steady state of <code>der(R) = Kin - Kout*(1 + Emax*frac)*R</code>), so EC50 is the exposure at half the maximal STIMULATION of turnover, not at half the response.</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0   (drug-free)
  exposure = EC50 (9.22 micrograms/ml)  response 0
  exposure -> infinity  response 0</pre></body></html>"));
end Tolmetin_FloresMurrieta1998_PD_antinociceptive_effect;
