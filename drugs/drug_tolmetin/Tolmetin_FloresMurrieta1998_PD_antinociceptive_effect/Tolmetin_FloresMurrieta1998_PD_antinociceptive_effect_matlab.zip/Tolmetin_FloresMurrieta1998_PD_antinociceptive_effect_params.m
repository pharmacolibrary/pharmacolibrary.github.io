function p = Tolmetin_FloresMurrieta1998_PD_antinociceptive_effect_params()
% Tolmetin_FloresMurrieta1998_PD_antinociceptive_effect_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% tolmetin Flores-Murrieta_1998::antinociceptive_effect: indirect_response_i exposure-response sweep (response = E0/(1 + Emax*frac)). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one micrograms/ml per second, in SI inside (kg/m3, s). Response antinociceptive effect in %. Driver: tolmetin (cited_pk).
p.E0 = 0.0;
p.Emax = 76.0;
p.EC50 = 0.009219999999999999;
p.gamma = 1.0;
p.slope = 0.0;
p.exposure_per_s = 0.001;
p.stop_time = 93.0;
p.form = 'E0/(1 + Emax*frac)';
end
