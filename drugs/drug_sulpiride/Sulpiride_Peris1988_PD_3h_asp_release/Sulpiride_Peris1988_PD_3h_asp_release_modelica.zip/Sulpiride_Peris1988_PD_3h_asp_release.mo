model Sulpiride_Peris1988_PD_3h_asp_release
  "emax exposure-response sweep — Peris_1988 :: [3H]ASP release (K+-stimulated [3H]D-aspartate release from rat striatal slices)"
  extends Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep(
    E0 = 0,      // [1]
    Emax = -0.75,  // [1; % × 0.01]
    EC50 = 240,  // [nM]
    gamma = 1,
    exposure_per_s = 1);   // 1 nM per second
  // imax_as_negative_emax: Imax (Q323) enters SigmoidEmaxSweep as −Emax
  // exposure_unit_unresolved: 'nM' — the x axis is in the paper's unit, not SI
  // defaulted: E0
  // defaulted: gamma
  annotation(experiment(StartTime = 0, StopTime = 2400, Interval = 4.8),
    Documentation(info = "<html><body><!-- drug-about --><h4>About sulpiride</h4><p>Sulpiride is an antipsychotic medicine used to treat psychotic disorders such as schizophrenia. It is approved in some countries and used mainly in Europe and Asia, but it is not available everywhere, as some markets have withdrawn it.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q422418\">Wikidata Q422418</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h4>Sulpiride_Peris1988_PD_3h_asp_release</h4><p>The steady-state exposure-response curve of Peris J et al., <i>Synapse (New York, N.Y.) 2(4):450–456</i> 1988 (<a href=\"https://doi.org/10.1002/syn.890020413\">doi:10.1002/syn.890020413</a>) — K+-stimulated [3H]D-aspartate release from rat striatal slices [%] against sulpiride nM — obtained by sweeping the driver instead of simulating a dose. Model family: emax.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = (library default) drug-free response (baseline)
  Emax  =         75 %        maximal effect term (Emax, Q323)
  EC50  =        240 nM       exposure at half of the maximal effect term (EC50, Q321)
  gamma = (library default) Hill coefficient</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep\">SigmoidEmaxSweep</a>; this model only supplies the numbers. The x axis is one nM of sulpiride per second of simulated time: there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0   (drug-free)
  exposure = EC50 (240 nM)  response -0.375
  exposure -> infinity  response -0.75</pre></body></html>"));
end Sulpiride_Peris1988_PD_3h_asp_release;
