function p = Sulpiride_Peris1988_PD_3h_asp_release_params()
% Sulpiride_Peris1988_PD_3h_asp_release_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% sulpiride Peris_1988::3H_ASP_release: emax exposure-response sweep (response = E0 + Emax*frac). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one nM per second, in SI inside (kg/m3, s). Response [3H]ASP release in %. Driver: sulpiride (cited_pk).
p.E0 = 0.0;
p.Emax = -0.75;
p.EC50 = 240.0;
p.gamma = 1.0;
p.slope = 0.0;
p.exposure_per_s = 1.0;
p.stop_time = 2400.0;
p.form = 'E0 + Emax*frac';
end
