model Sulpiride_Bressolle1984_reference
  parameter Real Cl_ref = 1.4966666666666664e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.01015 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 0.15,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.341426,
    adminMass = 0.0008,
    ka = 0.0004611111111111111,
    Tlag = 5400.0
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About sulpiride</h4><p>Sulpiride is an antipsychotic medicine used to treat psychotic disorders such as schizophrenia. It is approved in some countries and used mainly in Europe and Asia, but it is not available everywhere, as some markets have withdrawn it.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q422418\">Wikidata Q422418</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>sulpiride</td></tr><tr><td>population:</td><td>healthy male subjects</td></tr><tr><td>source_paper:</td><td>Bressolle_1984</td></tr><tr><td>measured_compound:</td><td>sulpiride</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>sulpiride 341.426 g/mol (drugbank)</td></tr></table><h4>Interpretation flags</h4><ul><li>dropped duplicate Q26 ('renal clearance of unbound drug', value 97.6) — already have one for this compound</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=sulpiride</li><li>1C volume normalization: Q63→Q61 (single-compartment model has no central/peripheral split; 'initial volume of distribution' is the general volume)</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li><li>gap-filled Q49 (kabs) from Yao_2019's review values (primary lacked it)</li><li>gap-filled Q83 (tlag) from Yao_2019's review values (primary lacked it)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Sulpiride_Bressolle1984_reference;
