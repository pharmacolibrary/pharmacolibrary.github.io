model Diazepam_Aurlie2023_reference
  parameter Real Cl_ref = 3.4333333333333336e-07 "Cl [m3/s]";
  parameter Real Vd_ref = 0.020460000000000002 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C_enteral(
    weight = 70.0,
    F = 0.9,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.28474,
    adminMass = 1e-05,
    ka = 0.0002861111111111111,
    Tlag = 669.6,
    k12 = 6.24524818073205e-05,
    k21 = 0.00017267267267267265
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About diazepam</h4><p>Diazepam is a benzodiazepine sedative used for conditions such as anxiety, insomnia, epilepsy including status epilepticus, muscle spasticity, and alcohol withdrawal. It is widely used, appears on the WHO essential medicines list, and is also approved for veterinary use, though it carries a boxed warning.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q210402\">Wikidata Q210402</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>diazepam</td></tr><tr><td>population:</td><td>review reference</td></tr><tr><td>source_paper:</td><td>Aurélie_2023</td></tr><tr><td>measured_compound:</td><td>diazepam</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_2C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>diazepam 284.74 g/mol (drugbank)</td></tr></table><p><b>Defaulted (base-class default used):</b> F.</p><h4>Interpretation flags</h4><ul><li>built from REVIEW reference values (Aurélie_2023) — secondary source</li><li>volume reported by review</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 259200, Tolerance = 1e-9, Interval = 1));
end Diazepam_Aurlie2023_reference;
