function p = Diazepam_Aurlie2023_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: diazepam   source: Aurélie_2023 / reference   route: oral
  % estimated (absent from source): F
  p.name  = 'Diazepam_Aurlie2023_reference_params';
  p.drug  = 'diazepam';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 7.44;                % central volume [L]
  p.CL = 1.236;                % clearance [L/h]
  p.Vp = [0.62];             % peripheral volumes [L]
  p.Q  = [93.0];             % inter-compartmental clearances [L/h]
  p.ka = 1.21;                % absorption rate [1/h]
  p.F  = 0.9;                 % bioavailability [0-1]
  p.Tlag = 84.2;             % absorption lag [h]
  p.dose = 10.0;             % dose [mg]
end
