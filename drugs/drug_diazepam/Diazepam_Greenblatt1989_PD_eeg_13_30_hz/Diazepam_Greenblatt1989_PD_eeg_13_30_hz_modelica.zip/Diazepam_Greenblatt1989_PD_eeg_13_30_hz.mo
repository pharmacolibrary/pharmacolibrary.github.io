model Diazepam_Greenblatt1989_PD_eeg_13_30_hz
  "sigmoid_emax exposure-response sweep — Greenblatt_1989 :: EEG 13–30 Hz (Percent 13 to 30 Hz EEG activity (percentage of total EEG amplitude in 13–30 Hz range))"
  extends Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep(
    E0 = 0,      // [1]
    Emax = 0.194,  // [1; % × 0.01]
    EC50 = 0.000269,  // [kg/m3; ng/ml × 1e-06]
    gamma = 1,
    exposure_per_s = 1e-06);   // 1 ng/ml per second
  // defaulted: E0
  // defaulted: gamma
  annotation(experiment(StartTime = 0, StopTime = 2700, Interval = 5.4),
    Documentation(info = "<html><body><!-- drug-about --><h4>About diazepam</h4><p>Diazepam is a benzodiazepine sedative used for conditions such as anxiety, insomnia, epilepsy including status epilepticus, muscle spasticity, and alcohol withdrawal. It is widely used, appears on the WHO essential medicines list, and is also approved for veterinary use, though it carries a boxed warning.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q210402\">Wikidata Q210402</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h4>Diazepam_Greenblatt1989_PD_eeg_13_30_hz</h4><p>The steady-state exposure-response curve of Greenblatt DJ et al., <i>Clinical pharmacology and therapeutics 45(4):356–365</i> 1989 (<a href=\"https://doi.org/10.1038/clpt.1989.41\">doi:10.1038/clpt.1989.41</a>) — Percent 13 to 30 Hz EEG activity (percentage of total EEG amplitude in 13–30 Hz range) [%] against diazepam ng/ml — obtained by sweeping the driver instead of simulating a dose. Model family: sigmoid_emax.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = (library default) drug-free response (baseline)
  Emax  =       19.4 %        maximal effect term (Emax, Q320)
  EC50  =        269 ng/ml    exposure at half of the maximal effect term (EC50, Q321)
  gamma = (library default) Hill coefficient</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep\">SigmoidEmaxSweep</a>; this model only supplies the numbers. The x axis is one ng/ml of diazepam per second of simulated time (exposure is in kg/m3): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0   (drug-free)
  exposure = EC50 (269 ng/ml)  response 0.097
  exposure -> infinity  response 0.194</pre></body></html>"));
end Diazepam_Greenblatt1989_PD_eeg_13_30_hz;
