model Trimethoprim_Tu1989_reference
  parameter Real Cl_ref = 1.6815166666666668e-05 "Cl [m3/s]";
  parameter Real Vd_ref = 0.14413 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.2903177,
    adminMass = 0.0004,
    ka = 0.0001388888888888889,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About trimethoprim</h4><p>Trimethoprim is an antibiotic used to treat bacterial infections, especially urinary tract infections, and is also used against infections such as toxoplasmosis and pneumocystosis. It remains widely used, appears on the WHO list of essential medicines, and is also approved for veterinary use.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q422665\">Wikidata Q422665</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>trimethoprim</td></tr><tr><td>population:</td><td>male Sprague-Dawley rats</td></tr><tr><td>source_paper:</td><td>Tu_1989</td></tr><tr><td>measured_compound:</td><td>trimethoprim</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C_enteral: apparent (/F) parameterization ⇒ extravascular dosing</td></tr><tr><td>molar_masses:</td><td>trimethoprim 290.318 g/mol (drugbank)</td></tr></table><p><b>Defaulted (base-class default used):</b> ka, Tlag.</p><h4>Interpretation flags</h4><ul><li>dropped duplicate Q290 ('apparent volume of distribution in the central compartment based on the area under the plasma concentration-time curve', value 5729) — already have one for this compound</li><li>unit_dimension_unknown: 'mL.min-1kg-1' (CL)</li><li>implicit units: 'clearance' → L/h (from the popPK convention: 'Clearance is a volumetric flow rate; the standard unit in population pharmacokinetics is L/h.')</li><li>apparent-ness (ontology-grounded): parameterization=apparent, measured_compound=trimethoprim</li><li>1C volume normalization: Q290→Q76 (single-compartment model has no central/peripheral split; 'apparent volume of distribution in the central compartment' is the general volume)</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary's parameterization (rate-constant / ka-only) does not use it</li><li>derived CL/F=60.5346 L/h from Ke × V/F = CL/F (Q47 × Q76); not separately reported</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Trimethoprim_Tu1989_reference;
