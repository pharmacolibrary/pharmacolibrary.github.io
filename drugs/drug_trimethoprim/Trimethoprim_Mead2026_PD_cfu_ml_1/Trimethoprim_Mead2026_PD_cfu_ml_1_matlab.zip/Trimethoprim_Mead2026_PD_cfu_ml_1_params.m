function p = Trimethoprim_Mead2026_PD_cfu_ml_1_params()
% Trimethoprim_Mead2026_PD_cfu_ml_1_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% trimethoprim Mead_2026::CFU_mL_1: emax exposure-response sweep (response = E0 + Emax*frac). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one μg mL -1 per second, in SI inside (kg/m3, s). Response CFU mL -1 in CFU mL -1. Driver: Trimethoprim (cited_pk).
p.E0 = 0.0;
p.Emax = -0.98;
p.EC50 = 1.7999999999999994e-05;
p.gamma = 3.8;
p.slope = 0.0;
p.exposure_per_s = 0.001;
p.stop_time = 0.18;
p.form = 'E0 + Emax*frac';
end
