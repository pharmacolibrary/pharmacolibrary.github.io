model Trimethoprim_Mead2026_PD_cfu_ml_1
  "emax exposure-response sweep — Mead_2026 :: CFU mL -1 (Bacterial population density)"
  extends Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep(
    E0 = 0,      // [1]
    Emax = -0.98,  // [CFU mL -1]
    EC50 = 1.8e-05,  // [kg/m3; μg mL -1 × 0.001]
    gamma = 3.8,
    exposure_per_s = 0.001);   // 1 μg mL -1 per second
  // imax_as_negative_emax: Imax (Q323) enters SigmoidEmaxSweep as −Emax
  // defaulted: E0
  annotation(experiment(StartTime = 0, StopTime = 0.18, Interval = 0.00036),
    Documentation(info = "<html><body><!-- drug-about --><h4>About trimethoprim</h4><p>Trimethoprim is an antibiotic used to treat bacterial infections, especially urinary tract infections, and is also used against infections such as toxoplasmosis and pneumocystosis. It remains widely used, appears on the WHO list of essential medicines, and is also approved for veterinary use.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q422665\">Wikidata Q422665</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h4>Trimethoprim_Mead2026_PD_cfu_ml_1</h4><p>The steady-state exposure-response curve of Mead A et al., <i>Journal of applied microbiology 137(5)</i> 2026 (<a href=\"https://doi.org/10.1093/jambio/lxag106\">doi:10.1093/jambio/lxag106</a>) — Bacterial population density [CFU mL -1] against Trimethoprim μg mL -1 — obtained by sweeping the driver instead of simulating a dose. Model family: emax.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = (library default) drug-free response (baseline)
  Emax  =       0.98 CFU mL -1 maximal effect term (E max, Q323)
  EC50  =      0.018 μg mL -1 exposure at half of the maximal effect term (EC 50, Q321)
  gamma =        3.8          Hill coefficient (γ, Q325)</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep\">SigmoidEmaxSweep</a>; this model only supplies the numbers. The x axis is one μg mL -1 of Trimethoprim per second of simulated time (exposure is in kg/m3): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0   (drug-free)
  exposure = EC50 (0.018 μg mL -1)  response -0.49
  exposure -> infinity  response -0.98</pre></body></html>"));
end Trimethoprim_Mead2026_PD_cfu_ml_1;
