model Bendamustine_Kim2018_reference
  parameter Real Cl_ref = 1.0888888888888891e-05 "Cl [m3/s]";
  parameter Real Vd_ref = 0.0207 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C_enteral(
    weight = 70.0,
    F = 0.9,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.358263,
    adminMass = 0.0001,
    ka = 0.0016666666666666666,
    Tlag = 0.0,
    k12 = 8.856682769726248e-06,
    k21 = 0.00021670606776989757
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About bendamustine</h4><p>Bendamustine is an alkylating anticancer drug used to treat blood cancers such as chronic lymphocytic leukemia and several types of lymphoma, including mantle cell and non-Hodgkin lymphoma. It is an approved medicine and appears on the WHO list of essential medicines, so it is widely used in cancer care.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q425745\">Wikidata Q425745</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>bendamustine</td></tr><tr><td>population:</td><td>primary central nervous system lymphoma</td></tr><tr><td>source_paper:</td><td>Kim_2018</td></tr><tr><td>measured_compound:</td><td>bendamustine</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>Tab2</td></tr><tr><td>input:</td><td>PK_2C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>bendamustine 358.263 g/mol (drugbank)</td></tr></table><p><b>Defaulted (base-class default used):</b> F, Tlag.</p><h4>Interpretation flags</h4><ul><li>dropped duplicate Q30 ('Q2', value '0.836') — already have one for this compound</li><li>dropped duplicate Q77 ('V4', value '0.041') — already have one for this compound</li><li>dropped duplicate Q22 ('CLcsf', value '0.140') — already have one for this compound</li><li>dropped unlinked row (NIL): 'RV' — extend the ontology if this is a real PK parameter (source ['Tab2:row13:col1', 'Tab2:row13:col2', 'Tab2:row13:col3', 'Tab2:row13:col4', 'Tab2:row13:col5'])</li><li>implicit units: 'V1' → L (from the paper text: 'The text states: &quot;The overall volume of distribution in plasma (Vplasma = V1 + V2 = 19.7 L)&quot;.')</li><li>implicit units: 'CL' → L/h (from the paper text: 'The text states: &quot;elimination clearance from the central plasma compartment (32.5 L/hr. for patient with BSA = 1.675)&quot;.')</li><li>implicit units: 'V2' → L (from the popPK convention: 'V2 is a volume of distribution. The text establishes the scale for plasma volumes in Liters (V1+V2=19.7 L), and 0.846 is')</li><li>implicit units: 'Q1' → L/h (from the popPK convention: 'Q1 is an intercompartmental clearance. By convention in population PK, clearances are expressed in L/h, and the magnitud')</li><li>implicit units: 'V3' → L (from the popPK convention: 'V3 is a volume of distribution (biophase/CSF compartment). Volumes are conventionally in L, and the magnitude is consist')</li><li>implicit units: 'Q3' → L/h (from the popPK convention: 'Q3 is an intercompartmental clearance. By convention in population PK, clearances are expressed in L/h.')</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=bendamustine</li><li>structure disagreement: deterministic 2C vs LLM 3C — review compartment count</li><li>gap-filled Q49 (kabs) from Lammers_2017's review values (primary lacked it)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Bendamustine_Kim2018_reference;
