model Bendamustine_Radhakrishnan2019_reference
  parameter Real Cl_ref = 2.833333333333333e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.0492 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.358263,
    adminMass = 1e-05
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About bendamustine</h4><p>Bendamustine is an alkylating anticancer drug used to treat blood cancers such as chronic lymphocytic leukemia and several types of lymphoma, including mantle cell and non-Hodgkin lymphoma. It is an approved medicine and appears on the WHO list of essential medicines, so it is widely used in cancer care.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q425745\">Wikidata Q425745</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>bendamustine</td></tr><tr><td>population:</td><td>review reference</td></tr><tr><td>source_paper:</td><td>Radhakrishnan_2019</td></tr><tr><td>measured_compound:</td><td>bendamustine</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>bendamustine 358.263 g/mol (drugbank)</td></tr></table><h4>Interpretation flags</h4><ul><li>built from REVIEW reference values (Radhakrishnan_2019) — secondary source</li><li>volume reported by review</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Bendamustine_Radhakrishnan2019_reference;
