model Haloperidol_Li2022_reference
  parameter Real Cl_ref = 1.7705555555555556e-05 "Cl [m3/s]";
  parameter Real Vd_ref = 2.3051999999999997 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.375864,
    adminMass = 5e-07
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>haloperidol</td></tr><tr><td>population:</td><td>critically ill adult patients with ICU delirium</td></tr><tr><td>source_paper:</td><td>Li_2022</td></tr><tr><td>measured_compound:</td><td>haloperidol</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>tab_1</td></tr><tr><td>input:</td><td>PK_1C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>haloperidol 375.864 g/mol (drugbank)</td></tr></table><h4>Interpretation flags</h4><ul><li>dropped value-less row: 'CRP'</li><li>dropped value-less row: 'CL'</li><li>dropped value-less row: 'Vd'</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=haloperidol</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 518400, Tolerance = 1e-9, Interval = 1));
end Haloperidol_Li2022_reference;
