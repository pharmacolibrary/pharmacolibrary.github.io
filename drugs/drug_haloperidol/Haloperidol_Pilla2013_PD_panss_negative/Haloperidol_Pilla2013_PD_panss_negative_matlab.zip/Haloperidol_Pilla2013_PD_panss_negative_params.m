function p = Haloperidol_Pilla2013_PD_panss_negative_params()
% Haloperidol_Pilla2013_PD_panss_negative_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% haloperidol Pilla_2013::PANSS_negative: sigmoid_emax exposure-response sweep (response = E0 + Emax*frac). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one ng/mL per second, in SI inside (kg/m3, s). Response PANSS negative in its own unit. Driver: haloperidol (pk_record).
p.E0 = 24.1;
p.Emax = -0.21;
p.EC50 = 6.4e-06;
p.gamma = 1.0;
p.slope = 0.0;
p.exposure_per_s = 1e-06;
p.stop_time = 64.0;
p.form = 'E0 + Emax*frac';
end
