model Haloperidol_Franken2017_reference
  parameter Real Cl_ref = 8.138888888888889e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 1.26 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.375864,
    adminMass = 5e-07
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About haloperidol</h4><p>Haloperidol is an antipsychotic used to treat conditions such as schizophrenia, psychosis, delirium, Tourette syndrome, and vomiting. It is widely used and appears on the WHO list of essential medicines, though it carries a boxed warning.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q251347\">Wikidata Q251347</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>haloperidol</td></tr><tr><td>population:</td><td>terminally ill adult patients</td></tr><tr><td>source_paper:</td><td>Franken_2017</td></tr><tr><td>measured_compound:</td><td>haloperidol</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>Tab2</td></tr><tr><td>input:</td><td>PK_1C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>haloperidol 375.864 g/mol (drugbank)</td></tr></table><h4>Interpretation flags</h4><ul><li>table section iiv: 'F' routed out of structural estimates ('IIV (%)')</li><li>table section iiv: 'F' routed out of structural estimates ('IIV (%)')</li><li>table section iiv: 'F' routed out of structural estimates ('IIV (%)')</li><li>table section iiv: 'F' routed out of structural estimates ('IIV (%)')</li><li>table section iiv: 'F' routed out of structural estimates ('IIV (%)')</li><li>table section iiv: 'F' routed out of structural estimates ('IIV (%)')</li><li>table section iiv: 'CL' routed out of structural estimates ('IIV (%)')</li><li>table section iiv: 'CL' routed out of structural estimates ('IIV (%)')</li><li>table section iiv: 'CL' routed out of structural estimates ('IIV (%)')</li><li>table section iiv: 'CL' routed out of structural estimates ('IIV (%)')</li><li>table section iiv: 'CL' routed out of structural estimates ('IIV (%)')</li><li>table section iiv: 'CL' routed out of structural estimates ('IIV (%)')</li><li>table section iiv: 'Vd' routed out of structural estimates ('IIV (%)')</li><li>table section iiv: 'Vd' routed out of structural estimates ('IIV (%)')</li><li>table section iiv: 'Vd' routed out of structural estimates ('IIV (%)')</li><li>table section iiv: 'Vd' routed out of structural estimates ('IIV (%)')</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 604800, Tolerance = 1e-9, Interval = 1));
end Haloperidol_Franken2017_reference;
