function p = Haloperidol_Franken2017_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: haloperidol   source: Franken_2017 / reference   route: iv_bolus
  p.name  = 'Haloperidol_Franken2017_reference_params';
  p.drug  = 'haloperidol';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'iv_bolus';        % 'oral' | 'iv_bolus'
  p.depot = false;             % oral -> first-order absorption depot
  p.Vc = 1260.0;                % central volume [L]
  p.CL = 29.3;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.0;                % absorption rate [1/h]
  p.F  = 0.861;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 0.5;             % dose [mg]
end
