function p = Haloperidol_Li2022_final_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: haloperidol   source: Li_2022 / final   route: iv_bolus
  % estimated (absent from source): F
  p.name  = 'Haloperidol_Li2022_final_params';
  p.drug  = 'haloperidol';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'iv_bolus';        % 'oral' | 'iv_bolus'
  p.depot = false;             % oral -> first-order absorption depot
  p.Vc = 1490.0;                % central volume [L]
  p.CL = 51.7;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.0;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 0.5;             % dose [mg]
end
