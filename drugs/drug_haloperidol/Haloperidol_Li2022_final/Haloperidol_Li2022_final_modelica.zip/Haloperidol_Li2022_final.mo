model Haloperidol_Li2022_final
  parameter Real Cl_ref = 1.4361111111111113e-05 "Cl [m3/s]";
  parameter Real Vd_ref = 1.49 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.375864,
    adminMass = 5e-07
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About haloperidol</h4><p>Haloperidol is an antipsychotic used to treat conditions such as schizophrenia, psychosis, delirium, Tourette syndrome, and vomiting. It is widely used and appears on the WHO list of essential medicines, though it carries a boxed warning.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q251347\">Wikidata Q251347</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>haloperidol</td></tr><tr><td>population:</td><td>critically ill adults with ICU delirium</td></tr><tr><td>source_paper:</td><td>Li_2022</td></tr><tr><td>measured_compound:</td><td>haloperidol</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>pharmaceutics-14-00549-t002</td></tr><tr><td>input:</td><td>PK_1C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>haloperidol 375.864 g/mol (drugbank)</td></tr></table><h4>Interpretation flags</h4><ul><li>dropped unlinked row (NIL): 'CRP' — extend the ontology if this is a real PK parameter (source ['pharmaceutics-14-00549-t002:row4:col4'])</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=haloperidol</li><li>model-stage split: 'final model' is the final model of Li_2022 (paper reports 2 stages: base model, final model); same population, different model-building step</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 432000, Tolerance = 1e-9, Interval = 1));
end Haloperidol_Li2022_final;
