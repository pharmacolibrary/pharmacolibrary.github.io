function p = Haloperidol_Pilla2013_PD_panss_params()
% Haloperidol_Pilla2013_PD_panss_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% haloperidol Pilla_2013::PANSS: sigmoid_emax exposure-response sweep (response = E0 + Emax*frac). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one ng/mL per second, in SI inside (kg/m3, s). Response PANSS in its own unit. Driver: haloperidol (pk_record).
p.E0 = 91.6;
p.Emax = -0.31;
p.EC50 = 3.58e-06;
p.gamma = 1.0;
p.slope = 0.0;
p.exposure_per_s = 1e-06;
p.stop_time = 36.0;
p.form = 'E0 + Emax*frac';
end
