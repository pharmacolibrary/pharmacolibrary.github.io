model Haloperidol_Pilla2013_PD_panss
  "sigmoid_emax exposure-response sweep — Pilla_2013 :: PANSS (PANSS total score)"
  extends Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep(
    E0 = 91.6,      // [1]
    Emax = -0.31,  // [1]
    EC50 = 3.58e-06,  // [kg/m3; ng/mL × 1e-06]
    gamma = 1,
    exposure_per_s = 1e-06);   // 1 ng/mL per second
  // imax_as_negative_emax: Imax (Q323) enters SigmoidEmaxSweep as −Emax
  // defaulted: gamma
  annotation(experiment(StartTime = 0, StopTime = 36, Interval = 0.072),
    Documentation(info = "<html><body><!-- drug-about --><h4>About haloperidol</h4><p>Haloperidol is an antipsychotic used to treat conditions such as schizophrenia, psychosis, delirium, Tourette syndrome, and vomiting. It is widely used and appears on the WHO list of essential medicines, though it carries a boxed warning.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q251347\">Wikidata Q251347</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h4>Haloperidol_Pilla2013_PD_panss</h4><p>The steady-state exposure-response curve of Pilla Reddy V et al., <i>Journal of clinical psychopharmacology 33(6):731–739</i> 2013 (<a href=\"https://doi.org/10.1097/JCP.0b013e3182a4ee2c\">doi:10.1097/JCP.0b013e3182a4ee2c</a>) — PANSS total score against haloperidol ng/mL — obtained by sweeping the driver instead of simulating a dose. Model family: sigmoid_emax.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    =       91.6          drug-free response (baseline) (Baseline PANSS, Q324)
  Emax  =       0.31          maximal effect term (E max, Q323)
  EC50  =       3.58 ng/mL    exposure at half of the maximal effect term (EC 50, Q321)
  gamma = (library default) Hill coefficient</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep\">SigmoidEmaxSweep</a>; this model only supplies the numbers. The x axis is one ng/mL of haloperidol per second of simulated time (exposure is in kg/m3): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 91.6   (drug-free)
  exposure = EC50 (3.58 ng/mL)  response 91.44
  exposure -> infinity  response 91.29</pre></body></html>"));
end Haloperidol_Pilla2013_PD_panss;
