model Levodopa_Senek2018_reference
  parameter Real Cl_ref = 1.3472222222222222e-05 "Cl [m3/s]";
  parameter Real Vd_ref = 0.168 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.19718790000000003,
    adminMass = 4.5e-05,
    ka = 0.0003333333333333333,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About levodopa</h4><p>Levodopa is a dopaminergic medicine used to treat Parkinson's disease. It is an approved anti-Parkinson drug and remains widely used, with an authorised product in the European Union.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q300989\">Wikidata Q300989</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>levodopa</td></tr><tr><td>population:</td><td>healthy subjects and Parkinson's disease patients</td></tr><tr><td>source_paper:</td><td>Senek_2018</td></tr><tr><td>measured_compound:</td><td>levodopa</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>Tab2</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>levodopa 197.188 g/mol (drugbank)</td></tr></table><p><b>Defaulted (base-class default used):</b> Tlag.</p><h4>Interpretation flags</h4><ul><li>dropped value-less row: 'CL/F (L/min)*(WT/70)0.75'</li><li>dropped value-less row: 'CL/F (L/min)*(WT/70)0.75'</li><li>dropped value-less row: 'VC/F (L)*(WT/70)' (captured trailing unit 'WT/70' for child rows)</li><li>dropped value-less row: 'VC/F (L)*(WT/70)' (captured trailing unit 'WT/70' for child rows)</li><li>dropped value-less row: 'Q/F (L/min)*(WT/70)0.75'</li><li>dropped value-less row: 'VP/F (L)*(WT/70)' (captured trailing unit 'WT/70' for child rows)</li><li>dropped value-less row: 'MTT1 (min)' (captured trailing unit 'min' for child rows)</li><li>dropped value-less row: 'MTT1 (min)' (captured trailing unit 'min' for child rows)</li><li>dropped value-less row: 'MTT2 (min)' (captured trailing unit 'min' for child rows)</li><li>dropped value-less row: 'MTT2 (min)' (captured trailing unit 'min' for child rows)</li><li>dropped value-less row: 'fa1‡'</li><li>dropped value-less row: 'fa1‡'</li><li>dropped value-less row: 'Pre-dose concentration (μg/mL)' (captured trailing unit 'μg/mL' for child rows)</li><li>dropped value-less row: 'Pre-dose concentration (μg/mL)' (captured trailing unit 'μg/mL' for child rows)</li><li>dropped value-less row: 'INTERCL/F-CDAMT (mg)' (captured trailing unit 'mg' for child rows)</li><li>dropped value-less row: 'CL/F-HY'</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Levodopa_Senek2018_reference;
