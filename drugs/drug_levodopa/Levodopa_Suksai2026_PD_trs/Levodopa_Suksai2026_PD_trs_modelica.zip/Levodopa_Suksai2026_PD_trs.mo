model Levodopa_Suksai2026_PD_trs
  "sigmoid_emax exposure-response sweep — Suksai_2026 :: TRS (therapeutic motor response (TRS-based motor outcome))"
  extends Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep(
    E0 = 30,      // [1]
    Emax = 10,  // [1]
    EC50 = 0.0025,  // [kg/m3; mg/L × 0.001]
    gamma = 2,
    exposure_per_s = 0.001);   // 1 mg/L per second
  annotation(experiment(StartTime = 0, StopTime = 25, Interval = 0.05),
    Documentation(info = "<html><body><!-- drug-about --><h4>About levodopa</h4><p>Levodopa is a dopaminergic medicine used to treat Parkinson's disease. It is an approved anti-Parkinson drug and remains widely used, with an authorised product in the European Union.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q300989\">Wikidata Q300989</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h4>Levodopa_Suksai2026_PD_trs</h4><p>The steady-state exposure-response curve of Suksai S et al., <i>Frontiers in pharmacology 17:1817435</i> 2026 (<a href=\"https://doi.org/10.3389/fphar.2026.1817435\">doi:10.3389/fphar.2026.1817435</a>) — therapeutic motor response (TRS-based motor outcome) against levodopa mg/L — obtained by sweeping the driver instead of simulating a dose. Model family: sigmoid_emax.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    =         30          drug-free response (baseline) (E0, Q324)
  Emax  =         10          maximal effect term (Emax, Q320)
  EC50  =        2.5 mg/L     exposure at half of the maximal effect term (EC50, Q321)
  gamma =          2          Hill coefficient (gamma, Q325)</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep\">SigmoidEmaxSweep</a>; this model only supplies the numbers. The x axis is one mg/L of levodopa per second of simulated time (exposure is in kg/m3): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 30   (drug-free)
  exposure = EC50 (2.5 mg/L)  response 35
  exposure -> infinity  response 40</pre></body></html>"));
end Levodopa_Suksai2026_PD_trs;
