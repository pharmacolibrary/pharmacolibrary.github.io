function p = Levodopa_Suksai2026_PD_trs_params()
% Levodopa_Suksai2026_PD_trs_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% levodopa Suksai_2026::TRS: sigmoid_emax exposure-response sweep (response = E0 + Emax*frac). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one mg/L per second, in SI inside (kg/m3, s). Response TRS in its own unit. Driver: levodopa (cited_pk).
p.E0 = 30.0;
p.Emax = 10.0;
p.EC50 = 0.0024999999999999996;
p.gamma = 2.0;
p.slope = 0.0;
p.exposure_per_s = 0.001;
p.stop_time = 25.0;
p.form = 'E0 + Emax*frac';
end
