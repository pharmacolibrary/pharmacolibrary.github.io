model Ceftriaxone_RoubaudBaudron2025_reference
  parameter Real Cl_ref = 9.722222222222222e-08 "Cl [m3/s]";
  parameter Real Vd_ref = 0.00713 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C_enteral(
    weight = 70.0,
    F = 0.9,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.5545800000000001,
    adminMass = 0.001,
    ka = 0.00045277777777777775,
    Tlag = 0.0,
    k12 = 0.0003560853981611345,
    k21 = 0.0003062592145824957
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About ceftriaxone</h4><p>Ceftriaxone is a third-generation cephalosporin antibiotic used to treat many bacterial infections, including pneumonia, meningitis, gonorrhea, sepsis, and urinary tract infections. It is an approved medicine and is listed by the WHO as an essential medicine, so it is widely used around the world.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q421713\">Wikidata Q421713</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>ceftriaxone</td></tr><tr><td>population:</td><td>older patients (≥65 years)</td></tr><tr><td>source_paper:</td><td>Roubaud-Baudron_2025</td></tr><tr><td>measured_compound:</td><td>ceftriaxone</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>ofaf313-T2</td></tr><tr><td>input:</td><td>PK_2C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>ceftriaxone 554.58 g/mol (drugbank)</td></tr></table><p><b>Defaulted (base-class default used):</b> F, Tlag.</p><h4>Interpretation flags</h4><ul><li>dropped unlinked row (NIL): 'β Cockcrofta' — extend the ontology if this is a real PK parameter (source ['ofaf313-T2:row7:col1', 'ofaf313-T2:row7:col2'])</li><li>dropped duplicate Q49 ('Ka', value '0.56') — already have one for this compound</li><li>dropped duplicate Q63 ('Vc', value '0.46') — already have one for this compound</li><li>dropped duplicate Q22 ('CL', value '0.14') — already have one for this compound</li><li>dropped value-less row: 'Ka (h-1)Vc (L)Vp (L)Q (L/h)CLnr (L/h)CoeffR'</li><li>apparent-by-design (ADVISORY, codes unchanged): extravascular dosing with no identifiable F, so these reported disposition parameters are likely apparent unless the model puts first-pass in its structure — Q63 (Vc, L); Q64 (Vp, L); Q30 (Q, L/h); Q22 (CL, L/h)</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=ceftriaxone</li><li>skipped review gap-fill of TLAG: primary's parameterization (rate-constant / ka-only) does not use it</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 345600, Tolerance = 1e-9, Interval = 1));
end Ceftriaxone_RoubaudBaudron2025_reference;
