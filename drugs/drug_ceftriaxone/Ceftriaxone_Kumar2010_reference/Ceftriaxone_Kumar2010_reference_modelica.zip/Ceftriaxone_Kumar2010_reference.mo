model Ceftriaxone_Kumar2010_reference
  parameter Real Cl_ref = 5.833333333333333e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.035 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 0.9,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.5545800000000001,
    adminMass = 0.0001,
    ka = 0.0002777777777777778,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About ceftriaxone</h4><p>Ceftriaxone is a third-generation cephalosporin antibiotic used to treat many bacterial infections, including pneumonia, meningitis, gonorrhea, sepsis, and urinary tract infections. It is an approved medicine and is listed by the WHO as an essential medicine, so it is widely used around the world.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q421713\">Wikidata Q421713</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>ceftriaxone</td></tr><tr><td>population:</td><td>healthy and endometritic cows</td></tr><tr><td>source_paper:</td><td>Kumar_2010</td></tr><tr><td>measured_compound:</td><td>ceftriaxone</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>ceftriaxone 554.58 g/mol (drugbank)</td></tr></table><p><b>Defaulted (base-class default used):</b> F, Tlag.</p><h4>Interpretation flags</h4><ul><li>dropped unlinked row (NIL): 'P/C ratio' — extend the ontology if this is a real PK parameter (source ['Kumar_2010:abstract', 'Kumar_2010:abstract'])</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=ceftriaxone</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li><li>gap-filled Q49 (kabs) from Alonso_2021's review values (primary lacked it)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Ceftriaxone_Kumar2010_reference;
