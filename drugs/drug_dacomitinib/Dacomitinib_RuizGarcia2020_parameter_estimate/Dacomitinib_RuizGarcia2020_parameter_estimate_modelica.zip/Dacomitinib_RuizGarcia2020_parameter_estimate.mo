model Dacomitinib_RuizGarcia2020_parameter_estimate
  parameter Real Cl_ref = 8.303611111111112e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.7897480000000001 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 1.0,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.469939,
    adminMass = 4.5e-05,
    ka = 7.194444444444445e-05,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About dacomitinib</h4><p>Dacomitinib is an EGFR tyrosine kinase inhibitor used to treat non-small-cell lung cancer. It is authorised in the European Union for this indication.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q17130597\">Wikidata Q17130597</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>dacomitinib</td></tr><tr><td>population:</td><td>healthy volunteers</td></tr><tr><td>source_paper:</td><td>Ruiz-Garcia_2020</td></tr><tr><td>measured_compound:</td><td>dacomitinib</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>pharmaceutics-12-00330-t004</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>dacomitinib 469.939 g/mol (drugbank)</td></tr></table><p><b>Defaulted (base-class default used):</b> Tlag.</p><h4>Interpretation flags</h4><ul><li>dropped duplicate Q49 ('PPI on ka', value '-0.524') — already have one for this compound</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=dacomitinib</li><li>structure disagreement: deterministic 1C vs LLM 2C — review compartment count</li><li>population split: 'parameter estimate' subgroup of Ruiz-Garcia_2020 (paper reports 2 populations: estimate (rse%), parameter estimate)</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of TLAG: primary's parameterization (rate-constant / ka-only) does not use it</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 432000, Tolerance = 1e-9, Interval = 1));
end Dacomitinib_RuizGarcia2020_parameter_estimate;
