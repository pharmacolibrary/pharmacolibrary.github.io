function p = Dacomitinib_RuizGarcia2020_parameter_estimate_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: dacomitinib   source: Ruiz-Garcia_2020 / parameter_estimate   route: oral
  p.name  = 'Dacomitinib_RuizGarcia2020_parameter_estimate_params';
  p.drug  = 'dacomitinib';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 789.748;                % central volume [L]
  p.CL = 29.893;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.259;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 45.0;             % dose [mg]
end
