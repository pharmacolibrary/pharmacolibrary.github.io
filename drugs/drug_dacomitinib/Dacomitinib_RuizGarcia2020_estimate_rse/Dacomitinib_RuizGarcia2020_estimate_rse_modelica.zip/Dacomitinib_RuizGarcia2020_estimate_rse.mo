model Dacomitinib_RuizGarcia2020_estimate_rse
  parameter Real Cl_ref = 8.111111111111112e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.131 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 1.0,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.469939,
    adminMass = 4.5e-05,
    ka = 6.833333333333334e-06,
    Tlag = 2696.4
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About dacomitinib</h4><p>Dacomitinib is an EGFR tyrosine kinase inhibitor used to treat non-small-cell lung cancer. It is authorised in the European Union for this indication.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q17130597\">Wikidata Q17130597</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>dacomitinib</td></tr><tr><td>population:</td><td>healthy volunteers</td></tr><tr><td>source_paper:</td><td>Ruiz-Garcia_2020</td></tr><tr><td>measured_compound:</td><td>dacomitinib</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>pharmaceutics-12-00330-t004</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>dacomitinib 469.939 g/mol (drugbank)</td></tr></table><h4>Interpretation flags</h4><ul><li>column 'estimate (rse%)' classified 'rse' by the LLM but kept as the estimate: the header names the point value</li><li>column 'estimate (rse%)' classified 'rse' by the LLM but kept as the estimate: the header names the point value</li><li>column 'estimate (rse%)' classified 'rse' by the LLM but kept as the estimate: the header names the point value</li><li>column 'estimate (rse%)' classified 'rse' by the LLM but kept as the estimate: the header names the point value</li><li>column 'estimate (rse%)' classified 'rse' by the LLM but kept as the estimate: the header names the point value</li><li>column 'estimate (rse%)' classified 'rse' by the LLM but kept as the estimate: the header names the point value</li><li>column 'estimate (rse%)' classified 'rse' by the LLM but kept as the estimate: the header names the point value</li><li>column 'estimate (rse%)' classified 'rse' by the LLM but kept as the estimate: the header names the point value</li><li>column 'estimate (rse%)' classified 'rse' by the LLM but kept as the estimate: the header names the point value</li><li>column 'estimate (rse%)' classified 'rse' by the LLM but kept as the estimate: the header names the point value</li><li>column 'estimate (rse%)' classified 'rse' by the LLM but kept as the estimate: the header names the point value</li><li>column 'estimate (rse%)' classified 'rse' by the LLM but kept as the estimate: the header names the point value</li><li>column 'estimate (rse%)' classified 'rse' by the LLM but kept as the estimate: the header names the point value</li><li>column 'estimate (rse%)' classified 'rse' by the LLM but kept as the estimate: the header names the point value</li><li>column 'estimate (rse%)' classified 'rse' by the LLM but kept as the estimate: the header names the point value</li><li>column 'estimate (rse%)' classified 'rse' by the LLM but kept as the estimate: the header names the point value</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 518400, Tolerance = 1e-9, Interval = 1));
end Dacomitinib_RuizGarcia2020_estimate_rse;
