function p = Dacomitinib_RuizGarcia2020_estimate_rse_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: dacomitinib   source: Ruiz-Garcia_2020 / estimate_rse   route: oral
  p.name  = 'Dacomitinib_RuizGarcia2020_estimate_rse_params';
  p.drug  = 'dacomitinib';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 131.0;                % central volume [L]
  p.CL = 29.2;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.0246;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.749;             % absorption lag [h]
  p.dose = 45.0;             % dose [mg]
end
