model RezafunginAcetate_Rubino2021_reference
  parameter Real Cl_ref = 7.055555555555556e-08 "Cl [m3/s]";
  parameter Real cov_albumin = 1.0 "albumin covariate (reference 1.0)";
  parameter Real Vd_ref = 0.0111 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref*(cov_albumin/1.0)^(-0.844),
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 1.226412,
    adminMass = 5e-05,
    k12 = 1.3538538538538538e-05,
    k21 = 1.0292998477929986e-05
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About rezafungin_acetate</h4><p>Rezafungin acetate is an antifungal medicine used to treat invasive candida infections of the bloodstream. It is a newer antifungal that has been authorised in the United States but is not approved in the European Union.</p><p><small><b>Unverified</b> — written by glm-5.3-flash from general knowledge (no Wikidata entry found) and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>rezafungin_acetate</td></tr><tr><td>population:</td><td>healthy volunteers and patients with fungal infections</td></tr><tr><td>source_paper:</td><td>Rubino_2021</td></tr><tr><td>measured_compound:</td><td>rezafungin</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>T2</td></tr><tr><td>input:</td><td>PK_2C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>rezafungin 1226.41 g/mol (pubchem); rezafungin_acetate 1285.46 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>table section iiv: 'CL, liter/h' routed out of structural estimates ('Interindividual variability (%CV)')</li><li>table section iiv: 'CL, liter/h' routed out of structural estimates ('Interindividual variability (%CV)')</li><li>table section iiv: 'CL, liter/h' routed out of structural estimates ('Interindividual variability (%CV)')</li><li>table section iiv: 'Vc, liter' routed out of structural estimates ('Interindividual variability (%CV)')</li><li>table section iiv: 'Vc, liter' routed out of structural estimates ('Interindividual variability (%CV)')</li><li>table section iiv: 'Vc, liter' routed out of structural estimates ('Interindividual variability (%CV)')</li><li>table section iiv: 'Vp1, liter' routed out of structural estimates ('Interindividual variability (%CV)')</li><li>table section iiv: 'Vp1, liter' routed out of structural estimates ('Interindividual variability (%CV)')</li><li>table section iiv: 'Vp1, liter' routed out of structural estimates ('Interindividual variability (%CV)')</li><li>covariate level 'CL-albumin power' → Q900:theta_cl_albumin_power = -0.844 (power on Q22)</li><li>dropped unlinked row (NIL): 'Proportional change in females' — extend the ontology if this is a real PK parameter (source ['T2:row4:col1', 'T2:row4:col2'])</li><li>dropped PD-category row 'Vc-BSA slope' → Q335 (slope, category G13) — pharmacodynamic parameters belong to scholarpd, not the PK model (source ['T2:row8:col1', 'T2:row8:col2'])</li><li>dropped unlinked row (NIL): 'Proportional change in infected patients' — extend the ontology if this is a real PK parameter (source ['T2:row9:col1', 'T2:row9:col2', 'T2:row17:col1', 'T2:row17:col2'])</li><li>dropped duplicate Q22 ('CLd1, liter/h', value '18.2') — already have one for this compound</li><li>covariate level 'Vp1-BSA power' → Q900:theta_v2_weight_power = 1.14 (power on Q64)</li><li>covariate level 'Vp2-BSA power' → Q900:theta_v3_weight_power = 2.47 (power on Q77)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 604800, Tolerance = 1e-9, Interval = 1));
end RezafunginAcetate_Rubino2021_reference;
