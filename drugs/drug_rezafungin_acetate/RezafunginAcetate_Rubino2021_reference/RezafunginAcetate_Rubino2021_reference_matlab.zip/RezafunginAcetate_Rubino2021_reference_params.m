function p = RezafunginAcetate_Rubino2021_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: rezafungin_acetate   source: Rubino_2021 / reference   route: iv_bolus
  % estimated (absent from source): F
  p.name  = 'RezafunginAcetate_Rubino2021_reference_params';
  p.drug  = 'rezafungin_acetate';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'iv_bolus';        % 'oral' | 'iv_bolus'
  p.depot = false;             % oral -> first-order absorption depot
  p.Vc = 11.1;                % central volume [L]
  p.CL = 0.254;                % clearance [L/h]
  p.Vp = [14.6];             % peripheral volumes [L]
  p.Q  = [0.541];             % inter-compartmental clearances [L/h]
  p.ka = 0.0;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 50.0;             % dose [mg]
end
