model RezafunginAcetate_Lakota2018_reference
  parameter Real Cl_ref = 5.194444444444444e-08 "Cl [m3/s]";
  parameter Real Vd_ref = 0.00894 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 1.285456,
    adminMass = 1e-05,
    k12 = 0.000758140691026597,
    k21 = 0.0005379188712522045
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About rezafungin_acetate</h4><p>Rezafungin acetate is an antifungal medicine used to treat invasive candida infections of the bloodstream. It is a newer antifungal that has been authorised in the United States but is not approved in the European Union.</p><p><small><b>Unverified</b> — written by glm-5.3-flash from general knowledge (no Wikidata entry found) and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>rezafungin_acetate</td></tr><tr><td>population:</td><td>review reference</td></tr><tr><td>source_paper:</td><td>Lakota_2018</td></tr><tr><td>measured_compound:</td><td>rezafungin_acetate</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_2C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>rezafungin_acetate 1285.46 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>built from REVIEW reference values (Lakota_2018) — secondary source</li><li>volume reported by review</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 604800, Tolerance = 1e-9, Interval = 1));
end RezafunginAcetate_Lakota2018_reference;
