model Tamsulosin_Tsuda2010_reference
  parameter Real Cl_ref = 6.333333333333333e-07 "Cl [m3/s]";
  parameter Real Vd_ref = 0.0375 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.408512,
    adminMass = 1.0000000000000001e-07,
    ka = 0.00010222222222222222,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About tamsulosin</h4><p>Tamsulosin is an alpha-blocker used to treat prostate problems such as enlarged prostate, prostatitis, and urinary retention. It is an approved medicine and is widely used in urological care, including in combination products.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q418480\">Wikidata Q418480</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>tamsulosin</td></tr><tr><td>population:</td><td>paediatric patients with neuropathic and non-neuropathic bladder</td></tr><tr><td>source_paper:</td><td>Tsuda_2010</td></tr><tr><td>measured_compound:</td><td>tamsulosin</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>Table 3</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>tamsulosin 408.512 g/mol (drugbank)</td></tr></table><p><b>Defaulted (base-class default used):</b> Tlag.</p><h4>Interpretation flags</h4><ul><li>salvaged Q27 ('CL/F (l h -1 )'=2.28) from results prose — parameter table was unreadable</li><li>salvaged Q76 ('V/F (l)'=37.5) from results prose — parameter table was unreadable</li><li>salvaged Q49 ('Ka (h -1 )'=0.368) from results prose — parameter table was unreadable</li><li>apparent-ness (ontology-grounded): parameterization=apparent, measured_compound=tamsulosin</li><li>held at status:extracted — NIL link or unit issue (mismatch/unknown/normalisation-failed) present</li><li>status held at route_to_review — not promoted</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of TLAG: primary's parameterization (rate-constant / ka-only) does not use it</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 259200, Tolerance = 1e-9, Interval = 1));
end Tamsulosin_Tsuda2010_reference;
