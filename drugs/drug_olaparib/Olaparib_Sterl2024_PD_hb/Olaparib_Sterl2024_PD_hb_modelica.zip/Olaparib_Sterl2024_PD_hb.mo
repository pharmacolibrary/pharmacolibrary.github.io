model Olaparib_Sterl2024_PD_hb
  "linear exposure-response sweep — Sterlé_2024 :: HB (haemoglobinaemia)"
  extends Pharmacolibrary.Interfaces.PartialExposureResponseSweep(
    E0 = 116.2,      // [kg/m3; g/dL × 10]
    Emax = 0, EC50 = 1,      // unused by a line
    exposure_per_s = 0.001);
  parameter Real slope = 0.56   "[meter ** 3 / kilogram; L/mg × 1000]";
equation
  response = E0 + slope*exposure;
  // family_inferred: the record's model family is disease_progression; read from the parameters: a slope and no Emax — linear
  annotation(experiment(StartTime = 0, StopTime = 1000, Interval = 2),
    Documentation(info = "<html><body><!-- drug-about --><h4>About olaparib</h4><p>Olaparib is a PARP inhibitor anticancer drug used to treat cancers such as ovarian, breast, pancreatic, and castration-resistant prostate cancer. It is approved and authorised in the European Union for these cancer indications.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q7083106\">Wikidata Q7083106</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h4>Olaparib_Sterl2024_PD_hb</h4><p>The steady-state exposure-response curve of Sterlé M et al., <i>Therapeutic advances in medical oncology 16:17588359241248328</i> 2024 (<a href=\"https://doi.org/10.1177/17588359241248328\">doi:10.1177/17588359241248328</a>) — haemoglobinaemia [g/dL] against olaparib mg/L — obtained by sweeping the driver instead of simulating a dose. Model family: linear.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    =      11.62 g/dL     drug-free response (baseline) (HB0pop, Q324)
  slope =    0.00056 L/mg     change in response per unit of exposure (SLOPEHBpop, Q335)</pre><p>The algebra is <code>response = E0 + slope*exposure</code>; this model only supplies the numbers. The x axis is one mg/L of olaparib per second of simulated time (exposure is in kg/m3): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 116.2   (drug-free)</pre></body></html>"));
end Olaparib_Sterl2024_PD_hb;
