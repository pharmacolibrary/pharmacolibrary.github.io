function p = Olaparib_Sterl2024_PD_hb_params()
% Olaparib_Sterl2024_PD_hb_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% olaparib Sterlé_2024::HB: linear exposure-response sweep (response = E0 + slope*exposure). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one mg/L per second, in SI inside (kg/m3, s). Response HB in g/dL. Driver: olaparib (cited_pk).
p.E0 = 116.19999999999997;
p.Emax = 0.0;
p.EC50 = 1.0;
p.gamma = 1.0;
p.slope = 0.56;
p.exposure_per_s = 0.001;
p.stop_time = 1000.0;
p.form = 'E0 + slope*exposure';
end
