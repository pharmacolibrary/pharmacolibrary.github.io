model Olaparib_DeJongh2025_PD_txeno
  "linear exposure-response sweep — DeJongh_2025 :: TXeno (Tumor volume)"
  extends Pharmacolibrary.Interfaces.PartialExposureResponseSweep(
    E0 = 0,      // [1]
    Emax = 0, EC50 = 1,      // unused by a line
    exposure_per_s = 1);
  parameter Real slope = 15400   "[1 / meter; uM−1 × 1e+06]";
equation
  response = E0 + slope*exposure;
  // family_inferred: the record's model family is effect_compartment; read from the parameters: a slope and no Emax — linear
  // defaulted: E0
  annotation(experiment(StartTime = 0, StopTime = 1000, Interval = 2),
    Documentation(info = "<html><body><!-- drug-about --><h4>About olaparib</h4><p>Olaparib is a PARP inhibitor anticancer drug used to treat cancers such as ovarian, breast, pancreatic, and castration-resistant prostate cancer. It is approved and authorised in the European Union for these cancer indications.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q7083106\">Wikidata Q7083106</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h4>Olaparib_DeJongh2025_PD_txeno</h4><p>The steady-state exposure-response curve of DeJongh J et al., <i>Journal of pharmacokinetics and pharmacodynamics 52(2):17</i> 2025 (<a href=\"https://doi.org/10.1007/s10928-025-09962-x\">doi:10.1007/s10928-025-09962-x</a>) — Tumor volume [cm3] against olaparib uM — obtained by sweeping the driver instead of simulating a dose. Model family: linear.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = (library default) drug-free response (baseline)
  slope =     0.0154 uM−1     change in response per unit of exposure (Olaparib linear effect coefficient, Q335)</pre><p>The algebra is <code>response = E0 + slope*exposure</code>; this model only supplies the numbers. The x axis is one uM of olaparib per second of simulated time: there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0   (drug-free)</pre></body></html>"));
end Olaparib_DeJongh2025_PD_txeno;
