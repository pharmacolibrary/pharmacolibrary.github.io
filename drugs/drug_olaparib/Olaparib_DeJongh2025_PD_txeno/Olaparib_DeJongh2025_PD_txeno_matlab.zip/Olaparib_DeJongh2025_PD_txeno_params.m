function p = Olaparib_DeJongh2025_PD_txeno_params()
% Olaparib_DeJongh2025_PD_txeno_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% olaparib DeJongh_2025::TXeno: linear exposure-response sweep (response = E0 + slope*exposure). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one uM per second, in SI inside (kg/m3, s). Response TXeno in cm3. Driver: olaparib (pk_record).
p.E0 = 0.0;
p.Emax = 0.0;
p.EC50 = 1.0;
p.gamma = 1.0;
p.slope = 15400.0;
p.exposure_per_s = 1.0;
p.stop_time = 1000.0;
p.form = 'E0 + slope*exposure';
end
