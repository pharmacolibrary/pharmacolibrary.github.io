model Olaparib_Velev2021_reference
  parameter Real Cl_ref = 1.0000000000000002e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.00257 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C_enteral(
    weight = 70.0,
    F = 0.9,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.43446280000000004,
    adminMass = 0.0001,
    ka = 6.861111111111111e-05,
    Tlag = 0.0,
    k12 = 0.00011997405966277564,
    k21 = 1.5651438240270732e-05
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About olaparib</h4><p>Olaparib is a PARP inhibitor anticancer drug used to treat cancers such as ovarian, breast, pancreatic, and castration-resistant prostate cancer. It is approved and authorised in the European Union for these cancer indications.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q7083106\">Wikidata Q7083106</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>olaparib</td></tr><tr><td>population:</td><td>BRCA-mutated ovarian cancer patients</td></tr><tr><td>source_paper:</td><td>Velev_2021</td></tr><tr><td>measured_compound:</td><td>olaparib</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>pharmaceuticals-14-00804-t0A1</td></tr><tr><td>input:</td><td>PK_2C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>olaparib 434.463 g/mol (drugbank)</td></tr></table><p><b>Defaulted (base-class default used):</b> F, Tlag.</p><h4>Interpretation flags</h4><ul><li>column 'description' classified 'other' by the LLM but kept: the deterministic diagnostic-column test disagrees (a stratum column is a value column, not a statistic)</li><li>column 'description' classified 'other' by the LLM but kept: the deterministic diagnostic-column test disagrees (a stratum column is a value column, not a statistic)</li><li>unit_dimension_unknown: 'Mean Estimate from Zhou et al.' (CL)</li><li>dropped duplicate Q22 ('θECOG-PS on CL', value '-0.240') — already have one for this compound</li><li>unit_dimension_unknown: 'Mean Estimate from Zhou et al.' (Frel)</li><li>unit_dimension_unknown: 'Mean Estimate from Zhou et al.' (Frel)</li><li>dropped duplicate Q87 ('Frel tablet c', value '0.627') — already have one for this compound</li><li>unit_dimension_unknown: 'Mean Estimate from Zhou et al.' (kabs)</li><li>unit_dimension_unknown: 'Mean Estimate from Zhou et al.' (kabs)</li><li>dropped duplicate Q49 ('ka (h−1) tabletstrength 100 mg', value '0.374') — already have one for this compound</li><li>unit_dimension_unknown: 'Mean Estimate from Zhou et al.' (kabs)</li><li>dropped duplicate Q49 ('ka (h−1) tabletstrength 150 mg', value '0.267') — already have one for this compound</li><li>unit_dimension_unknown: 'Mean Estimate from Zhou et al.' (D1)</li><li>unit_dimension_unknown: 'Mean Estimate from Zhou et al.' (D1)</li><li>dropped duplicate Q310 ('D1 (h) tablet', value '0.467') — already have one for this compound</li><li>implicit units: 'ka (h−1) capsule' → 1/h (from the popPK convention: &quot;The parameter is 'kabs' (Absorption rate constant). The table text does not explicitly state a unit (the provided '(h−1)&quot;)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Olaparib_Velev2021_reference;
