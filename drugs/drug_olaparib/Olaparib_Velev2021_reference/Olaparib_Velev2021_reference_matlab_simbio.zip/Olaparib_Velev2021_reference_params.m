function p = Olaparib_Velev2021_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: olaparib   source: Velev_2021 / reference   route: oral
  % estimated (absent from source): F
  p.name  = 'Olaparib_Velev2021_reference_params';
  p.drug  = 'olaparib';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 2.57;                % central volume [L]
  p.CL = 3.6;                % clearance [L/h]
  p.Vp = [19.7];             % peripheral volumes [L]
  p.Q  = [1.11];             % inter-compartmental clearances [L/h]
  p.ka = 0.247;                % absorption rate [1/h]
  p.F  = 0.9;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 100.0;             % dose [mg]
end
