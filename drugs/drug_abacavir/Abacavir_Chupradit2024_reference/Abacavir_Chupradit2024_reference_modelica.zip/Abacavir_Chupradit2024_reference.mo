model Abacavir_Chupradit2024_reference
  parameter Real Cl_ref = 2.2303921568627456e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.12404411764705885 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.2863323,
    adminMass = 0.0006,
    ka = 0.0001277777777777778,
    Tlag = 1656.0
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About abacavir</h4><p>Abacavir is an antiviral medicine used to treat HIV infection and HIV/AIDS. It is widely used, appears on the WHO essential medicines list, and is authorised in the European Union, typically in combination products for HIV treatment.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q304330\">Wikidata Q304330</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>abacavir</td></tr><tr><td>population:</td><td>review reference</td></tr><tr><td>source_paper:</td><td>Chupradit_2024</td></tr><tr><td>measured_compound:</td><td>abacavir</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>abacavir 286.332 g/mol (drugbank)</td></tr></table><h4>Interpretation flags</h4><ul><li>built from REVIEW reference values (Chupradit_2024) — secondary source</li><li>volume reported by review</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 259200, Tolerance = 1e-9, Interval = 1));
end Abacavir_Chupradit2024_reference;
