model Pentobarbital_Ketharanathan2023_final
  parameter Real Cl_ref = 9.972222222222222e-07 "Cl [m3/s]";
  parameter Real Vd_ref = 0.14200000000000002 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.2262722,
    adminMass = 0.00035
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About pentobarbital</h4><p>Pentobarbital is a barbiturate sedative-hypnotic used as a hypnotic and sedative, and to treat status epilepticus. It remains an approved medicine and is also approved for veterinary use, though it is not authorised in the European Union.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q409632\">Wikidata Q409632</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>pentobarbital</td></tr><tr><td>population:</td><td>critically ill children with refractory status epilepticus or severe traumatic brain injury (PICU)</td></tr><tr><td>source_paper:</td><td>Ketharanathan_2023</td></tr><tr><td>measured_compound:</td><td>pentobarbital</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>Tab2</td></tr><tr><td>input:</td><td>PK_1C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>pentobarbital 226.272 g/mol (drugbank)</td></tr></table><h4>Interpretation flags</h4><ul><li>dropped unlinked row (NIL): 'OFV' — extend the ontology if this is a real PK parameter (source ['Tab2:row2:col2'])</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=pentobarbital</li><li>model-stage split: 'final model' is the final model of Ketharanathan_2023 (paper reports 2 stages: base model, final model); same population, different model-building step</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 518400, Tolerance = 1e-9, Interval = 1));
end Pentobarbital_Ketharanathan2023_final;
