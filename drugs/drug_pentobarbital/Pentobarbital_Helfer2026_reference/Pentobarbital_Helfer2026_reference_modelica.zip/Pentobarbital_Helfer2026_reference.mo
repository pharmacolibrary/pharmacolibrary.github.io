model Pentobarbital_Helfer2026_reference
  parameter Real Cl_ref = 1.425e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.03543 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.2262722,
    adminMass = 2.73e-05,
    k12 = 0.0001396337065261705,
    k21 = 7.889048353089176e-05
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About pentobarbital</h4><p>Pentobarbital is a barbiturate sedative-hypnotic used as a hypnotic and sedative, and to treat status epilepticus. It remains an approved medicine and is also approved for veterinary use, though it is not authorised in the European Union.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q409632\">Wikidata Q409632</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>pentobarbital</td></tr><tr><td>population:</td><td>pediatric patients (birth to 21 years)</td></tr><tr><td>source_paper:</td><td>Helfer_2026</td></tr><tr><td>measured_compound:</td><td>pentobarbital</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>jcph70204-tbl-0002</td></tr><tr><td>input:</td><td>PK_2C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>pentobarbital 226.272 g/mol (drugbank)</td></tr></table><h4>Interpretation flags</h4><ul><li>table section residual_error: 'Proportional error (%)' routed out of structural estimates ('Residual error')</li><li>table section residual_error: 'Proportional error (%)' routed out of structural estimates ('Residual error')</li><li>table section residual_error: 'Proportional error (%)' routed out of structural estimates ('Residual error')</li><li>table section residual_error: 'Proportional error (%)' routed out of structural estimates ('Residual error')</li><li>routed 'Shared variability CL and V1 b' → Q314 (omega_cov) to covariance — variability estimate, not a structural parameter</li><li>routed 'η1' → Q312 (IIV) to iiv — variability estimate, not a structural parameter</li><li>dropped unlinked row (NIL): 'Number of Participants' — extend the ontology if this is a real PK parameter (source ['Helfer_2026_table_3:row0:col1', 'Helfer_2026_table_3:row0:col2', 'Helfer_2026_table_3:row0:col3', 'Helfer_2026_table_3:row0:col4'])</li><li>NIL: refused to back-fill base 'NIL' from footnote/prose loose number 90.4 (source ['jcph70204-tbl-0002:footnote']); the table cell was unparseable — needs review</li><li>NIL: refused to back-fill base 'omega_cov' from footnote/prose loose number None (source ['jcph70204-tbl-0002:footnote']); the table cell was unparseable — needs review</li><li>covariate category for IIV from footnote/prose kept as documentation only (['jcph70204-tbl-0002:footnote'])</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=pentobarbital</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Pentobarbital_Helfer2026_reference;
