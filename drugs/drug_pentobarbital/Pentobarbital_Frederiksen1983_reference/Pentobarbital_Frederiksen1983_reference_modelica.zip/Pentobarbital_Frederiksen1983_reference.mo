model Pentobarbital_Frederiksen1983_reference
  parameter Real Cl_ref = 3.611111111111111e-10 "Cl [m3/s]";
  parameter Real Vd_ref = 0.0756 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.2262722,
    adminMass = 0.0001
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About pentobarbital</h4><p>Pentobarbital is a barbiturate sedative-hypnotic used as a hypnotic and sedative, and to treat status epilepticus. It remains an approved medicine and is also approved for veterinary use, though it is not authorised in the European Union.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q409632\">Wikidata Q409632</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>pentobarbital</td></tr><tr><td>population:</td><td>dogs</td></tr><tr><td>source_paper:</td><td>Frederiksen_1983</td></tr><tr><td>measured_compound:</td><td>pentobarbital</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>pentobarbital 226.272 g/mol (drugbank)</td></tr></table><h4>Interpretation flags</h4><ul><li>unit_dimension_unknown: 'liters/min X kg' (CL)</li><li>dropped PD-category row 'Threshold pentobarbital concentrations required to suppress the corneal reflex' → Q321 (EC50, category G11) — pharmacodynamic parameters belong to scholarpd, not the PK model (source ['Frederiksen_1983:abstract'])</li><li>dropped unlinked row (NIL): 'withdrawal response to pain' — extend the ontology if this is a real PK parameter (source ['Frederiksen_1983:abstract'])</li><li>implicit units: 'elimination clearance' → L/h (from the popPK convention: 'No unit stated in text, caption, or footnotes. Total clearance in population PK is conventionally expressed in L/h; the ')</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=pentobarbital</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 147600, Tolerance = 1e-9, Interval = 1));
end Pentobarbital_Frederiksen1983_reference;
