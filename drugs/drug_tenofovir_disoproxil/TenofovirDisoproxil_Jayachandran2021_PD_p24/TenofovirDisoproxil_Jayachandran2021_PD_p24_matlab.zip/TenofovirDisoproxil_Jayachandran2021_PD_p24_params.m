function p = TenofovirDisoproxil_Jayachandran2021_PD_p24_params()
% TenofovirDisoproxil_Jayachandran2021_PD_p24_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% tenofovir_disoproxil Jayachandran_2021::p24: linear exposure-response sweep (response = E0 + slope*exposure). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one fmol/million cells per second, in SI inside (kg/m3, s). Response p24 in pg/mL. Driver: tenofovir-diphosphate (TFVdp) in rectal mononuclear cells (MMCs) (not_resolved).
p.E0 = 0.0;
p.Emax = 0.0;
p.EC50 = 1.0;
p.gamma = 1.0;
p.slope = 0.00011;
p.exposure_per_s = 1.0;
p.stop_time = 1000.0;
p.form = 'E0 + slope*exposure';
end
