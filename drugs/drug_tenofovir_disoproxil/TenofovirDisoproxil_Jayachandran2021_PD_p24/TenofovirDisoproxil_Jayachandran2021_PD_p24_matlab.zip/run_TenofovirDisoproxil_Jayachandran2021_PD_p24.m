% run_TenofovirDisoproxil_Jayachandran2021_PD_p24  Evaluate the exposure-response curve and plot response against exposure.
% A sweep is a static map: no ODE solver is needed. exposure runs 0..stop_time*exposure_per_s.
p = TenofovirDisoproxil_Jayachandran2021_PD_p24_params();
exposure = linspace(0, p.stop_time * p.exposure_per_s, 501);
frac = exposure.^p.gamma ./ (p.EC50^p.gamma + exposure.^p.gamma);
E0 = p.E0; Emax = p.Emax; slope = p.slope;
response = E0 + slope.*exposure;
figure; plot(exposure, response, 'LineWidth', 1.5); grid on;
xlabel('exposure [fmol/million cells]'); ylabel('response [pg/mL]'); title('TenofovirDisoproxil_Jayachandran2021_PD_p24', 'Interpreter', 'none');
writematrix([exposure(:) response(:)], 'TenofovirDisoproxil_Jayachandran2021_PD_p24.csv');
