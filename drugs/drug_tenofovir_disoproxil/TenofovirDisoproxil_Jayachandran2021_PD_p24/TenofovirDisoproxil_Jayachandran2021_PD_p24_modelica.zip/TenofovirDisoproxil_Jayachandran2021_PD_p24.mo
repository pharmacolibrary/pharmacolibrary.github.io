model TenofovirDisoproxil_Jayachandran2021_PD_p24
  "linear exposure-response sweep — Jayachandran_2021 :: p24 (cumulative p24 antigen expression (ex vivo HIV-1 infection of rectal explants))"
  extends Pharmacolibrary.Interfaces.PartialExposureResponseSweep(
    E0 = 0,      // [1]
    Emax = 0, EC50 = 1,      // unused by a line
    exposure_per_s = 1);
  parameter Real slope = 0.00011   "[(pg/mL)/(fmol/million cells)]";
equation
  response = E0 + slope*exposure;
  // defaulted: E0
  annotation(experiment(StartTime = 0, StopTime = 1000, Interval = 2),
    Documentation(info = "<html><body><!-- drug-about --><h4>About tenofovir_disoproxil</h4><p>Tenofovir disoproxil is an antiviral used to treat HIV infection and chronic hepatitis B. It is widely used and is authorised in the European Union, available both alone and in combination products for HIV.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q27132753\">Wikidata Q27132753</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h4>TenofovirDisoproxil_Jayachandran2021_PD_p24</h4><p>The steady-state exposure-response curve of Jayachandran P et al., <i>CPT: pharmacometrics &amp; systems pharmacology 10(3):179–187</i> 2021 (<a href=\"https://doi.org/10.1002/psp4.12583\">doi:10.1002/psp4.12583</a>) — cumulative p24 antigen expression (ex vivo HIV-1 infection of rectal explants) [pg/mL] against tenofovir-diphosphate (TFVdp) in rectal mononuclear cells (MMCs) fmol/million cells — obtained by sweeping the driver instead of simulating a dose. Model family: linear.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = (library default) drug-free response (baseline)
  slope =    0.00011 (pg/mL)/(fmol/million cells) change in response per unit of exposure (Slope, Q335)</pre><p>The algebra is <code>response = E0 + slope*exposure</code>; this model only supplies the numbers. The x axis is one fmol/million cells of tenofovir-diphosphate (TFVdp) in rectal mononuclear cells (MMCs) per second of simulated time: there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0   (drug-free)</pre></body></html>"));
end TenofovirDisoproxil_Jayachandran2021_PD_p24;
