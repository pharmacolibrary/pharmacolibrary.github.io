function p = Camostat_Kosinsky2022_PD_viral_entry_rate_params()
% Camostat_Kosinsky2022_PD_viral_entry_rate_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% camostat Kosinsky_2022::Viral_entry_rate: indirect_response_i exposure-response sweep (response = E0*(1 - Emax*frac)). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one nM per second, in SI inside (kg/m3, s). Response Viral entry rate in relative to control. Driver: FOY-251 (cited_pk).
p.E0 = 0.0;
p.Emax = 1.0;
p.EC50 = 7.46;
p.gamma = 1.0;
p.slope = 0.0;
p.exposure_per_s = 1.0;
p.stop_time = 74.6;
p.form = 'E0*(1 - Emax*frac)';
end
