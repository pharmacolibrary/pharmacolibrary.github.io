model Camostat_Kosinsky2022_reference
  parameter Real Cl_ref = 7.577555555555556e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.02236 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 0.9,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.313,
    adminMass = 0.0002,
    ka = 0.00018611111111111112,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About camostat</h4><p>Camostat is a protease inhibitor that blocks trypsin and has been investigated as an oral drug, including for pancreatitis-related conditions. It is not authorised in the European Union and remains investigational rather than in routine approved use.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q5026909\">Wikidata Q5026909</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>camostat</td></tr><tr><td>population:</td><td>adults</td></tr><tr><td>source_paper:</td><td>Kosinsky_2022</td></tr><tr><td>measured_compound:</td><td>FOY-251</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>tab1</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>FOY-251 313 g/mol (paper); camostat 398.413 g/mol (drugbank)</td></tr></table><p><b>Defaulted (base-class default used):</b> F, Tlag.</p><h4>Interpretation flags</h4><ul><li>table section residual_error: 'b' routed out of structural estimates ('Residual error model')</li><li>table section residual_error: 'b' routed out of structural estimates ('Residual error model')</li><li>metabolite volume: 'Vd, L' Q63→Q61 for FOY-251 — it is 1-compartment, so its central volume is its only volume</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=FOY-251</li><li>template fit: none — only the metabolite is modelled — no parent compartment</li><li>row roles (LLM): model_class=compartmental; 5/5 row label(s) assigned, 6 linked by role</li><li>review gap-fill skipped: this record measures 'FOY-251', not camostat — the review values are the parent's</li><li>derived CL=27.2792 L/h from Ke × V = CL (Q47 × Q61); not separately reported</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Camostat_Kosinsky2022_reference;
