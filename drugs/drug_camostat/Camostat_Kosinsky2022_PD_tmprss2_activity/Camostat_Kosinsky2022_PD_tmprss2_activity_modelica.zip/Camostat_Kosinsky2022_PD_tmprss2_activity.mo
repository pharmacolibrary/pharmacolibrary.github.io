model Camostat_Kosinsky2022_PD_tmprss2_activity
  "indirect_response_i exposure-response sweep — Kosinsky_2022 :: TMPRSS2 activity (name)"
  extends Pharmacolibrary.Interfaces.PartialExposureResponseSweep(
    E0 = 0.0,      // [1]
    Emax = 1.0,  // type I effect term
    EC50 = 7.46,  // [nM]
    gamma = 1.0,
    exposure_per_s = 1.0);   // 1 nM per second
equation
  response = E0*(1 - Emax*frac);   // steady state, indirect response type I
  // exposure_unit_unresolved: 'nM' — the x axis is in the paper's unit, not SI
  // defaulted: E0
  // defaulted: Emax
  // defaulted: gamma
  annotation(experiment(StartTime = 0, StopTime = 74.6, Interval = 0.1492));
end Camostat_Kosinsky2022_PD_tmprss2_activity;
