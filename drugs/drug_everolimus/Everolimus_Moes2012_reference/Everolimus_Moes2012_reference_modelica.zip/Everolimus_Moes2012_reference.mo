model Everolimus_Moes2012_reference
  parameter Real Cl_ref = 4.9722222222222224e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.148 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.95824,
    adminMass = 1.5e-06,
    ka = 0.0020444444444444447,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About everolimus</h4><p>Everolimus is an mTOR inhibitor used as an antineoplastic and immunosuppressant for cancers such as renal cell carcinoma, breast cancer, and neuroendocrine tumors, as well as tuberous sclerosis. It is authorised in the European Union for several cancer types and tuberous sclerosis, and is an approved drug.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q421052\">Wikidata Q421052</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>everolimus</td></tr><tr><td>population:</td><td>renal transplant patients</td></tr><tr><td>source_paper:</td><td>Moes_2012</td></tr><tr><td>measured_compound:</td><td>everolimus</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>everolimus 958.24 g/mol (drugbank)</td></tr></table><p><b>Defaulted (base-class default used):</b> Tlag.</p><h4>Interpretation flags</h4><ul><li>apparent-ness (ontology-grounded): parameterization=apparent, measured_compound=everolimus</li><li>1C volume normalization: Q63→Q61 (single-compartment model has no central/peripheral split; 'volume of distribution of the central compartment after oral administration [V(1)/F]' is the general volume)</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of TLAG: primary's parameterization (rate-constant / ka-only) does not use it</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 108000, Tolerance = 1e-9, Interval = 1));
end Everolimus_Moes2012_reference;
