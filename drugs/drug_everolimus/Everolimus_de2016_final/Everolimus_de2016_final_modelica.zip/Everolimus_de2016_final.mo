model Everolimus_de2016_final
  parameter Real Cl_ref = 4.833333333333333e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.0252 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.95824,
    adminMass = 5e-06,
    ka = 0.00017972222222222223,
    Tlag = 0.0,
    k12 = 0.0005632716049382716,
    k21 = 3.548611111111111e-05
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About everolimus</h4><p>Everolimus is an mTOR inhibitor used as an antineoplastic and immunosuppressant for cancers such as renal cell carcinoma, breast cancer, and neuroendocrine tumors, as well as tuberous sclerosis. It is authorised in the European Union for several cancer types and tuberous sclerosis, and is an approved drug.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q421052\">Wikidata Q421052</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>everolimus</td></tr><tr><td>population:</td><td>patients with advanced thyroid carcinoma</td></tr><tr><td>source_paper:</td><td>de_2016</td></tr><tr><td>measured_compound:</td><td>everolimus</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>Tab2</td></tr><tr><td>input:</td><td>PK_2C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>everolimus 958.24 g/mol (drugbank)</td></tr></table><p><b>Defaulted (base-class default used):</b> Tlag.</p><h4>Interpretation flags</h4><ul><li>table section iiv: 'Cl/F (CV%)' routed out of structural estimates ('Inter-individual variability')</li><li>table section iiv: 'Cl/F (CV%)' routed out of structural estimates ('Inter-individual variability')</li><li>table section iiv: 'V 1/F (CV%)' routed out of structural estimates ('Inter-individual variability')</li><li>table section iiv: 'V 1/F (CV%)' routed out of structural estimates ('Inter-individual variability')</li><li>table section iov: 'F (CV%)' routed out of structural estimates ('Inter-occasion variability')</li><li>table section iov: 'F (CV%)' routed out of structural estimates ('Inter-occasion variability')</li><li>table section residual_error: 'σ (proportional error)' routed out of structural estimates ('Residual variability')</li><li>table section residual_error: 'σ (proportional error)' routed out of structural estimates ('Residual variability')</li><li>apparent-ness (ontology-grounded): parameterization=apparent, measured_compound=everolimus</li><li>model-stage split: 'final model' is the final model of de_2016 (paper reports 2 stages: base model, final model); same population, different model-building step</li><li>skipped review gap-fill of TLAG: primary's parameterization (rate-constant / ka-only) does not use it</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Everolimus_de2016_final;
