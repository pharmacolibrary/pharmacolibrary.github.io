function p = Everolimus_de2016_base_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: everolimus   source: de_2016 / base   route: oral
  p.name  = 'Everolimus_de2016_base_params';
  p.drug  = 'everolimus';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 29.1;                % central volume [L]
  p.CL = 20.3;                % clearance [L/h]
  p.Vp = [475.0];             % peripheral volumes [L]
  p.Q  = [60.0];             % inter-compartmental clearances [L/h]
  p.ka = 0.643;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 5.0;             % dose [mg]
end
