% Run (SimBiology): build model + dose, simulate 0..24.0 h, plot.
p = Everolimus_de2016_base_params();
[model, dose, variant] = build_sb_pk(p);
sd = simulate_sb(model, variant, dose, 24.0);
