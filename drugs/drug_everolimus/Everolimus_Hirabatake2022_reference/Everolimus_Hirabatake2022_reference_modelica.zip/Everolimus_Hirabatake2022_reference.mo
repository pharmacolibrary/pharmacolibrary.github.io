model Everolimus_Hirabatake2022_reference
  parameter Real Cl_ref = 3.2500000000000002e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.054 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.95824,
    adminMass = 2.5e-06,
    k12 = 0.00021707818930041153,
    k21 = 3.7886949651655534e-05
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About everolimus</h4><p>Everolimus is an mTOR inhibitor used as an antineoplastic and immunosuppressant for cancers such as renal cell carcinoma, breast cancer, and neuroendocrine tumors, as well as tuberous sclerosis. It is authorised in the European Union for several cancer types and tuberous sclerosis, and is an approved drug.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q421052\">Wikidata Q421052</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>everolimus</td></tr><tr><td>population:</td><td>Japanese patients with advanced breast cancer</td></tr><tr><td>source_paper:</td><td>Hirabatake_2022</td></tr><tr><td>measured_compound:</td><td>everolimus</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>T3</td></tr><tr><td>input:</td><td>PK_2C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>everolimus 958.24 g/mol (drugbank)</td></tr></table><h4>Interpretation flags</h4><ul><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=everolimus</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Everolimus_Hirabatake2022_reference;
