function p = Esomeprazole_Chung2022_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: esomeprazole   source: Chung_2022 / reference   route: oral
  p.name  = 'Esomeprazole_Chung2022_reference_params';
  p.drug  = 'esomeprazole';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 121.0;                % central volume [L]
  p.CL = 221.0;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.95;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 30.0;             % dose [mg]
end
