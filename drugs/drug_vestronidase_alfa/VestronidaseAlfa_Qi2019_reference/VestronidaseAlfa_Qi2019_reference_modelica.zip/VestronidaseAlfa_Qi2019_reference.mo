model VestronidaseAlfa_Qi2019_reference
  parameter Real Cl_ref = 5.527777777777778e-07 "Cl [m3/s]";
  parameter Real Vd_ref = 0.00149 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    adminMass = 7e-05,
    k12 = 0.00017524235645041016,
    k21 = 8.617528419508619e-05
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About vestronidase_alfa</h4><p>Vestronidase alfa is an enzyme replacement therapy used to treat mucopolysaccharidosis VII, also known as Sly syndrome. It is authorised in the European Union and is used mainly for this rare metabolic disorder.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q48970976\">Wikidata Q48970976</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>vestronidase_alfa</td></tr><tr><td>population:</td><td>adult and pediatric subjects with MPS VII</td></tr><tr><td>source_paper:</td><td>Qi_2019</td></tr><tr><td>measured_compound:</td><td>vestronidase_alfa</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>Tab2</td></tr><tr><td>input:</td><td>PK_2C: IV (no input phase)</td></tr></table><h4>Interpretation flags</h4><ul><li>table section iiv: 'ω2 for CL' routed out of structural estimates ('Interindividual variability')</li><li>table section iiv: 'ω2 for CL' routed out of structural estimates ('Interindividual variability')</li><li>table section iiv: 'ω2 for CL' routed out of structural estimates ('Interindividual variability')</li><li>table section iiv: 'ω2 for Vc' routed out of structural estimates ('Interindividual variability')</li><li>table section iiv: 'ω2 for Vc' routed out of structural estimates ('Interindividual variability')</li><li>table section iiv: 'ω2 for Vc' routed out of structural estimates ('Interindividual variability')</li><li>table section iiv: 'ω2 for Vc' routed out of structural estimates ('Interindividual variability')</li><li>table section iiv: 'ω2 for Q' routed out of structural estimates ('Interindividual variability')</li><li>table section iiv: 'ω2 for Q' routed out of structural estimates ('Interindividual variability')</li><li>table section iiv: 'ω2 for Q' routed out of structural estimates ('Interindividual variability')</li><li>table section iiv: 'ω2 for Vp' routed out of structural estimates ('Interindividual variability')</li><li>table section iiv: 'ω2 for Vp' routed out of structural estimates ('Interindividual variability')</li><li>table section iiv: 'ω2 for Vp' routed out of structural estimates ('Interindividual variability')</li><li>table section iiv: 'ω2 for Vp' routed out of structural estimates ('Interindividual variability')</li><li>table section residual_error: 'σ2 prop' routed out of structural estimates ('Residual variability')</li><li>table section residual_error: 'σ2 prop' routed out of structural estimates ('Residual variability')</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end VestronidaseAlfa_Qi2019_reference;
