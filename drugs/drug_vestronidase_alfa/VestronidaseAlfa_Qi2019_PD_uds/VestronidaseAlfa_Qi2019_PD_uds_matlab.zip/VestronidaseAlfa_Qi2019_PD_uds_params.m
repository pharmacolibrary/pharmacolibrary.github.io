function p = VestronidaseAlfa_Qi2019_PD_uds_params()
% VestronidaseAlfa_Qi2019_PD_uds_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% vestronidase_alfa Qi_2019::uDS: emax exposure-response sweep (response = E0 + Emax*frac). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one µg h/mL per second, in SI inside (kg/m3, s). Response uDS in %. Driver: vestronidase alfa (dose_only).
p.E0 = 0.0;
p.Emax = -0.7690000000000001;
p.EC50 = 7.3;
p.gamma = 1.0;
p.slope = 0.0;
p.exposure_per_s = 1.0;
p.stop_time = 73.0;
p.form = 'E0 + Emax*frac';
end
