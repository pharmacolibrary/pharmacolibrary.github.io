model VestronidaseAlfa_Qi2019_PD_ucs
  "emax exposure-response sweep — Qi_2019 :: uCS (Urinary chondroitin sulfate)"
  extends Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep(
    E0 = 0,      // [1]
    Emax = -0.82,  // [1; percent × 0.01]
    EC50 = 8.6,  // [µg h/mL]
    gamma = 1,
    exposure_per_s = 1);   // 1 µg h/mL per second
  // imax_as_negative_emax: Imax (Q323) enters SigmoidEmaxSweep as −Emax
  // exposure_unit_unresolved: 'µg h/mL' — the x axis is in the paper's unit, not SI
  // defaulted: E0
  // defaulted: gamma
  annotation(experiment(StartTime = 0, StopTime = 86, Interval = 0.172),
    Documentation(info = "<html><body><!-- drug-about --><h4>About vestronidase_alfa</h4><p>Vestronidase alfa is an enzyme replacement therapy used to treat mucopolysaccharidosis VII, also known as Sly syndrome. It is authorised in the European Union and is used mainly for this rare metabolic disorder.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q48970976\">Wikidata Q48970976</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h4>VestronidaseAlfa_Qi2019_PD_ucs</h4><p>The steady-state exposure-response curve of Qi Y et al., <i>Clinical pharmacokinetics 58(5):673–683</i> 2019 (<a href=\"https://doi.org/10.1007/s40262-018-0721-y\">doi:10.1007/s40262-018-0721-y</a>) — Urinary chondroitin sulfate [%] against vestronidase alfa µg h/mL — obtained by sweeping the driver instead of simulating a dose. Model family: emax.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = (library default) drug-free response (baseline)
  Emax  =         82 percent  maximal effect term (Imax, Q323)
  EC50  =        8.6 µg h/mL  exposure at half of the maximal effect term (IC50, Q322)
  gamma = (library default) Hill coefficient</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep\">SigmoidEmaxSweep</a>; this model only supplies the numbers. The x axis is one µg h/mL of vestronidase alfa per second of simulated time: there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0   (drug-free)
  exposure = EC50 (8.6 µg h/mL)  response -0.41
  exposure -> infinity  response -0.82</pre></body></html>"));
end VestronidaseAlfa_Qi2019_PD_ucs;
