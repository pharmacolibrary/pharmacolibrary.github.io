function p = Naratriptan_MaassenVanDenBrink1998_PD_coronary_artery_contra_params()
% Naratriptan_MaassenVanDenBrink1998_PD_coronary_artery_contra_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% naratriptan MaassenVanDenBrink_1998::coronary_artery_contraction: emax exposure-response sweep (response = E0 + Emax*frac). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one nmol/L per second, in SI inside (kg/m3, s). Response coronary artery contraction in % of contraction elicited by 100 mmol/L K+. Driver: naratriptan (conc_no_pk).
p.E0 = 0.0;
p.Emax = 10.1;
p.EC50 = 0.00017099999999999998;
p.gamma = 1.0;
p.slope = 0.0;
p.exposure_per_s = 1e-06;
p.stop_time = 1800.0;
p.form = 'E0 + Emax*frac';
end
