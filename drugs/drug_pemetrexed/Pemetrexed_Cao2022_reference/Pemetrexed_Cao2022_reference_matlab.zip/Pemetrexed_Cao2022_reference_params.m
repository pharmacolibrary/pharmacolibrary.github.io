function p = Pemetrexed_Cao2022_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: pemetrexed   source: Cao_2022 / reference   route: iv_bolus
  % estimated (absent from source): F, dose
  p.name  = 'Pemetrexed_Cao2022_reference_params';
  p.drug  = 'pemetrexed';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'iv_bolus';        % 'oral' | 'iv_bolus'
  p.depot = false;             % oral -> first-order absorption depot
  p.Vc = 17.53;                % central volume [L]
  p.CL = 7.63;                % clearance [L/h]
  p.Vp = [3.86];             % peripheral volumes [L]
  p.Q  = [0.08];             % inter-compartmental clearances [L/h]
  p.ka = 0.0;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 10.0;             % dose [mg]
end
