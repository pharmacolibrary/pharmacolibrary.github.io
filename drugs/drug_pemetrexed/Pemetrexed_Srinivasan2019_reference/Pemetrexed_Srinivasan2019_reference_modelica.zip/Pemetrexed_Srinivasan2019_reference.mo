model Pemetrexed_Srinivasan2019_reference
  parameter Real Cl_ref = 9.166666666666666e-07 "Cl [m3/s]";
  parameter Real Vd_ref = 0.005200000000000001 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.4274106,
    adminMass = 1e-05,
    k12 = 0.0003632478632478632,
    k21 = 0.0003201506591337099
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About pemetrexed</h4><p>Pemetrexed is an anticancer drug used to treat non-small-cell lung cancer and mesothelioma. It is an approved antifolate chemotherapy, with several products authorised in the European Union.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q415220\">Wikidata Q415220</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>pemetrexed</td></tr><tr><td>population:</td><td>adult patients with non-small cell lung cancer</td></tr><tr><td>source_paper:</td><td>Srinivasan_2019</td></tr><tr><td>measured_compound:</td><td>pemetrexed</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_2C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>pemetrexed 427.411 g/mol (drugbank)</td></tr></table><h4>Interpretation flags</h4><ul><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=pemetrexed</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Pemetrexed_Srinivasan2019_reference;
