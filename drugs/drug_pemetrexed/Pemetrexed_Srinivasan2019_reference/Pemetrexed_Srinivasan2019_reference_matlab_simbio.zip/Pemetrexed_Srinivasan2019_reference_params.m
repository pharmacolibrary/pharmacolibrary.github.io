function p = Pemetrexed_Srinivasan2019_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: pemetrexed   source: Srinivasan_2019 / reference   route: iv_bolus
  % estimated (absent from source): F, dose
  p.name  = 'Pemetrexed_Srinivasan2019_reference_params';
  p.drug  = 'pemetrexed';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'iv_bolus';        % 'oral' | 'iv_bolus'
  p.depot = false;             % oral -> first-order absorption depot
  p.Vc = 5.2;                % central volume [L]
  p.CL = 3.3;                % clearance [L/h]
  p.Vp = [5.9];             % peripheral volumes [L]
  p.Q  = [6.8];             % inter-compartmental clearances [L/h]
  p.ka = 0.0;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 10.0;             % dose [mg]
end
