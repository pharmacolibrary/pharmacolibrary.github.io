model Dasabuvir_Mensing2016_reference
  parameter Real Cl_ref = 4.363425925925926e-05 "Cl [m3/s]";
  parameter Real Vd_ref = 0.638 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.49357999999999996,
    adminMass = 2.5e-05,
    ka = 6.909722222222221e-05,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About dasabuvir</h4><p>Dasabuvir is an antiviral medicine used to treat chronic hepatitis C infection. It has been an approved medicine and was included on the WHO essential medicines list, although its authorisation in the European Union has since been withdrawn.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q19462214\">Wikidata Q19462214</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>dasabuvir</td></tr><tr><td>population:</td><td>adults with chronic HCV genotype 1 infection</td></tr><tr><td>source_paper:</td><td>Mensing_2016</td></tr><tr><td>measured_compound:</td><td>dasabuvir</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>Table III</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>dasabuvir 493.58 g/mol (drugbank)</td></tr></table><p><b>Defaulted (base-class default used):</b> Tlag.</p><h4>Interpretation flags</h4><ul><li>salvaged Q49 ('k a , day -1'=5.97) from results prose — parameter table was unreadable</li><li>salvaged Q27 ('CL/F, L/day'=3770) from results prose — parameter table was unreadable</li><li>salvaged Q290 ('Vc/F, L'=638) from results prose — parameter table was unreadable</li><li>salvaged Q69 ('Q/F, L/day'=254) from results prose — parameter table was unreadable</li><li>salvaged Q82 ('Vp/F, L'=5110) from results prose — parameter table was unreadable</li><li>apparent-ness (ontology-grounded): parameterization=apparent, measured_compound=dasabuvir</li><li>held at status:extracted — NIL link or unit issue (mismatch/unknown/normalisation-failed) present</li><li>topology: transfer parameter unlinked (Q100) — add Kfm/formation-rate/rate-constant to the ontology; routing to review</li><li>status held at route_to_review — not promoted</li><li>skipped review gap-fill of TLAG: primary's parameterization (rate-constant / ka-only) does not use it</li><li>engineer: parent → metabolite not buildable on PK_3M_9C (None) — the measured compound's 1-compartment model instead</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 97200, Tolerance = 1e-9, Interval = 1));
end Dasabuvir_Mensing2016_reference;
