model Imipenem_Gomez2015_reference
  parameter Real Cl_ref = 4.9444444444444444e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.0707 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.299346,
    adminMass = 1e-05
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About imipenem</h4><p>Imipenem is a carbapenem antibiotic used to treat serious bacterial infections such as sepsis, urinary tract infections, endocarditis, and infections caused by staphylococci or Pseudomonas. It is an approved antibiotic, generally given by injection and mainly reserved for severe or hospital-treated infections.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q425152\">Wikidata Q425152</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>imipenem</td></tr><tr><td>population:</td><td>review reference</td></tr><tr><td>source_paper:</td><td>Gomez_2015</td></tr><tr><td>measured_compound:</td><td>imipenem</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>imipenem 299.346 g/mol (drugbank)</td></tr></table><h4>Interpretation flags</h4><ul><li>built from REVIEW reference values (Gomez_2015) — secondary source</li><li>volume reported by review</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Imipenem_Gomez2015_reference;
