model Cariprazine_Girgis2016_PD_occ_d2
  "emax exposure-response sweep — Girgis_2016 :: OCC_D2 (D2 receptor occupancy)"
  extends Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep(
    E0 = 0,      // [1]
    Emax = 1,  // [1; % × 0.01]
    EC50 = 1.77,  // [nM]
    gamma = 1,
    exposure_per_s = 1);   // 1 nM per second
  // exposure_unit_unresolved: 'nM' — the x axis is in the paper's unit, not SI
  // defaulted: E0
  // defaulted: gamma
  annotation(experiment(StartTime = 0, StopTime = 18, Interval = 0.036),
    Documentation(info = "<html><body><!-- drug-about --><h4>About cariprazine</h4><p>Cariprazine is an antipsychotic used to treat schizophrenia and bipolar I disorder. It is authorised in the European Union for schizophrenia and is also being investigated for other uses.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q2938837\">Wikidata Q2938837</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h4>Cariprazine_Girgis2016_PD_occ_d2</h4><p>The steady-state exposure-response curve of Girgis RR et al., <i>Psychopharmacology 233(19-20):3503–3512</i> 2016 (<a href=\"https://doi.org/10.1007/s00213-016-4382-y\">doi:10.1007/s00213-016-4382-y</a>) — D2 receptor occupancy [%] against total active cariprazine (cariprazine + DCAR + DDCAR) nM — obtained by sweeping the driver instead of simulating a dose. Model family: emax.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = (library default) drug-free response (baseline)
  Emax  =        100 %        maximal effect term (Emax, Q320)
  EC50  =       1.77 nM       exposure at half of the maximal effect term (EC50, Q321)
  gamma = (library default) Hill coefficient</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep\">SigmoidEmaxSweep</a>; this model only supplies the numbers. The x axis is one nM of total active cariprazine (cariprazine + DCAR + DDCAR) per second of simulated time: there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0   (drug-free)
  exposure = EC50 (1.77 nM)  response 0.5
  exposure -> infinity  response 1</pre></body></html>"));
end Cariprazine_Girgis2016_PD_occ_d2;
