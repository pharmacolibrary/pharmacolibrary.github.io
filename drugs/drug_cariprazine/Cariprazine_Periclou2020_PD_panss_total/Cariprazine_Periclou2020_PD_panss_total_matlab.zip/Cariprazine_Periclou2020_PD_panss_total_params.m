function p = Cariprazine_Periclou2020_PD_panss_total_params()
% Cariprazine_Periclou2020_PD_panss_total_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% cariprazine Periclou_2020::PANSS_total: sigmoid_emax exposure-response sweep (response = E0 + Emax*frac). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one nM per second, in SI inside (kg/m3, s). Response PANSS total in its own unit. Driver: total cariprazine (sum of cariprazine, DCAR, and DDCAR) (conc_no_pk).
p.E0 = 96.4;
p.Emax = -0.118;
p.EC50 = 55.0;
p.gamma = 2.11;
p.slope = 0.0;
p.exposure_per_s = 1.0;
p.stop_time = 550.0;
p.form = 'E0 + Emax*frac';
end
