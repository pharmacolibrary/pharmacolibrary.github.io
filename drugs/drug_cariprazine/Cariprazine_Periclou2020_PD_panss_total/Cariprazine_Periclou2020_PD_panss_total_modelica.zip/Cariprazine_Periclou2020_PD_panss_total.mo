model Cariprazine_Periclou2020_PD_panss_total
  "sigmoid_emax exposure-response sweep — Periclou_2020 :: PANSS total (Positive and Negative Syndrome Scale total score)"
  extends Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep(
    E0 = 96.4,      // [1]
    Emax = -0.118,  // [1]
    EC50 = 55,  // [nM]
    gamma = 2.11,
    exposure_per_s = 1);   // 1 nM per second
  // imax_as_negative_emax: Imax (Q323) enters SigmoidEmaxSweep as −Emax
  // exposure_unit_unresolved: 'nM' — the x axis is in the paper's unit, not SI
  annotation(experiment(StartTime = 0, StopTime = 550, Interval = 1.1),
    Documentation(info = "<html><body><!-- drug-about --><h4>About cariprazine</h4><p>Cariprazine is an antipsychotic used to treat schizophrenia and bipolar I disorder. It is authorised in the European Union for schizophrenia and is also being investigated for other uses.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q2938837\">Wikidata Q2938837</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h4>Cariprazine_Periclou2020_PD_panss_total</h4><p>The steady-state exposure-response curve of Periclou A et al., <i>Clinical and translational science 13(2):362–371</i> 2020 (<a href=\"https://doi.org/10.1111/cts.12720\">doi:10.1111/cts.12720</a>) — Positive and Negative Syndrome Scale total score against total cariprazine (sum of cariprazine, DCAR, and DDCAR) nM — obtained by sweeping the driver instead of simulating a dose. Model family: sigmoid_emax.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    =       96.4          drug-free response (baseline) (PANSS0, Q324)
  Emax  =      0.118          maximal effect term (Emax, Q323)
  EC50  =         55 nM       exposure at half of the maximal effect term (EC50 (nM), Q321)
  gamma =       2.11          Hill coefficient (γ, Q325)</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep\">SigmoidEmaxSweep</a>; this model only supplies the numbers. The x axis is one nM of total cariprazine (sum of cariprazine, DCAR, and DDCAR) per second of simulated time: there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 96.4   (drug-free)
  exposure = EC50 (55 nM)  response 96.34
  exposure -> infinity  response 96.28</pre></body></html>"));
end Cariprazine_Periclou2020_PD_panss_total;
