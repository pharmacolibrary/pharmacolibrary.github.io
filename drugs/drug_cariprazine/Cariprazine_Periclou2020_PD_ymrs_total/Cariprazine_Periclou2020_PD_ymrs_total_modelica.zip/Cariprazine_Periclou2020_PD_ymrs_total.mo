model Cariprazine_Periclou2020_PD_ymrs_total
  "emax exposure-response sweep — Periclou_2020 :: YMRS total (Young Mania Rating Scale total score)"
  extends Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep(
    E0 = 32.7,      // [1]
    Emax = -0.25,  // [1]
    EC50 = 62.4,  // [nM]
    gamma = 1,
    exposure_per_s = 1);   // 1 nM per second
  // imax_as_negative_emax: Imax (Q323) enters SigmoidEmaxSweep as −Emax
  // exposure_unit_unresolved: 'nM' — the x axis is in the paper's unit, not SI
  // defaulted: gamma
  annotation(experiment(StartTime = 0, StopTime = 630, Interval = 1.26),
    Documentation(info = "<html><body><!-- drug-about --><h4>About cariprazine</h4><p>Cariprazine is an antipsychotic used to treat schizophrenia and bipolar I disorder. It is authorised in the European Union for schizophrenia and is also being investigated for other uses.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q2938837\">Wikidata Q2938837</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h4>Cariprazine_Periclou2020_PD_ymrs_total</h4><p>The steady-state exposure-response curve of Periclou A et al., <i>Clinical and translational science 13(2):362–371</i> 2020 (<a href=\"https://doi.org/10.1111/cts.12720\">doi:10.1111/cts.12720</a>) — Young Mania Rating Scale total score against total cariprazine (sum of cariprazine, DCAR, and DDCAR) nM — obtained by sweeping the driver instead of simulating a dose. Model family: emax.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    =       32.7          drug-free response (baseline) (YMRS0, Q324)
  Emax  =       0.25          maximal effect term (E max, Q323)
  EC50  =       62.4 nM       exposure at half of the maximal effect term (EC50 (nM), Q321)
  gamma = (library default) Hill coefficient</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep\">SigmoidEmaxSweep</a>; this model only supplies the numbers. The x axis is one nM of total cariprazine (sum of cariprazine, DCAR, and DDCAR) per second of simulated time: there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 32.7   (drug-free)
  exposure = EC50 (62.4 nM)  response 32.58
  exposure -> infinity  response 32.45</pre></body></html>"));
end Cariprazine_Periclou2020_PD_ymrs_total;
