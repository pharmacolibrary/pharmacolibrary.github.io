function p = Cariprazine_Periclou2020_PD_ymrs_total_params()
% Cariprazine_Periclou2020_PD_ymrs_total_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% cariprazine Periclou_2020::YMRS_total: emax exposure-response sweep (response = E0 + Emax*frac). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one nM per second, in SI inside (kg/m3, s). Response YMRS total in its own unit. Driver: total cariprazine (sum of cariprazine, DCAR, and DDCAR) (conc_no_pk).
p.E0 = 32.7;
p.Emax = -0.25;
p.EC50 = 62.4;
p.gamma = 1.0;
p.slope = 0.0;
p.exposure_per_s = 1.0;
p.stop_time = 630.0;
p.form = 'E0 + Emax*frac';
end
