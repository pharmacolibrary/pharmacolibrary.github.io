function p = Cariprazine_Girgis2016_PD_occ_d3_params()
% Cariprazine_Girgis2016_PD_occ_d3_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% cariprazine Girgis_2016::OCC_D3: emax exposure-response sweep (response = E0 + Emax*frac). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one nM per second, in SI inside (kg/m3, s). Response OCC_D3 in %. Driver: total active cariprazine (cariprazine + DCAR + DDCAR) (conc_no_pk).
p.E0 = 0.0;
p.Emax = 1.0;
p.EC50 = 1.42;
p.gamma = 1.0;
p.slope = 0.0;
p.exposure_per_s = 1.0;
p.stop_time = 15.0;
p.form = 'E0 + Emax*frac';
end
