function p = Cariprazine_Periclou2021_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: cariprazine   source: Periclou_2021 / reference   route: oral
  p.name  = 'Cariprazine_Periclou2021_reference_params';
  p.drug  = 'cariprazine';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 266.0;                % central volume [L]
  p.CL = 21.5;                % clearance [L/h]
  p.Vp = [149.0];             % peripheral volumes [L]
  p.Q  = [0.431];             % inter-compartmental clearances [L/h]
  p.ka = 0.352;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 1.5;             % dose [mg]
end
