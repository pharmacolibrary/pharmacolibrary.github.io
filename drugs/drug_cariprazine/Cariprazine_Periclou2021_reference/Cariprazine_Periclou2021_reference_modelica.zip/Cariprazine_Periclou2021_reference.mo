// general-linear (2 compartments) — non-mammillary/4C+; central↔peripheral
// edges with clearance Qj; topology flagged for reviewer confirmation.
model Cariprazine_Periclou2021_reference
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_General_Linear(
    nComp = 2, centralIdx = 1, F = 1,
    V = {0.266, 0.149},
    CLelim = {5.972222222222223e-06, 0.0},
    nEdge = 2,
    edge = {{1, 2}, {2, 1}},
    CLedge = {1.1972222222222222e-07, 1.1972222222222222e-07}
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About cariprazine</h4><p>Cariprazine is an antipsychotic used to treat schizophrenia and bipolar I disorder. It is authorised in the European Union for schizophrenia and is also being investigated for other uses.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q2938837\">Wikidata Q2938837</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>cariprazine</td></tr><tr><td>population:</td><td>adults with schizophrenia or bipolar mania</td></tr><tr><td>source_paper:</td><td>Periclou_2021</td></tr><tr><td>measured_compound:</td><td>cariprazine</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>general_linear</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>Tab2</td></tr><tr><td>molar_masses:</td><td>cariprazine 427.41 g/mol (drugbank); desmethyl-cariprazine (DCAR) 413.387 g/mol (pubchem); didesmethyl-cariprazine (DDCAR) 399.36 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>dropped value-less row: 'DUR'</li><li>dropped value-less row: 'Ka'</li><li>dropped value-less row: 'CL/F'</li><li>dropped value-less row: 'Power of WTKG'</li><li>dropped value-less row: 'Proportional shift for race = black'</li><li>dropped value-less row: 'Proportional shift for race = Asiand'</li><li>dropped value-less row: 'Proportional shift for race = Japanesed'</li><li>dropped value-less row: 'VC/F'</li><li>dropped unlinked row (NIL): 'Proportional shift for first dose' — extend the ontology if this is a real PK parameter (source ['Tab2:row10:col1', 'Tab2:row13:col1', 'Tab2:row26:col1', 'Tab2:row30:col1'])</li><li>dropped value-less row: 'Q3/F'</li><li>dropped value-less row: 'VP1/F'</li><li>dropped value-less row: 'Q4/F'</li><li>dropped value-less row: 'VP2/F'</li><li>dropped value-less row: 'DCL/F'</li><li>dropped value-less row: 'Proportional shift for sex = female'</li><li>dropped value-less row: 'DVC/F'</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 259200, Tolerance = 1e-9, Interval = 1));
end Cariprazine_Periclou2021_reference;
