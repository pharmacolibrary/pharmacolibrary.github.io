function p = Moxifloxacin_Gotta2015_PD_qtc_params()
% Moxifloxacin_Gotta2015_PD_qtc_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% moxifloxacin Gotta_2015::QTc: sigmoid_emax exposure-response sweep (response = E0 + Emax*frac). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one μM per second, in SI inside (kg/m3, s). Response ΔQTc in ms. Driver: moxifloxacin (cited_pk).
p.E0 = 0.23900000000000002;
p.Emax = 0.0546;
p.EC50 = 16.3;
p.gamma = 1.8;
p.slope = 0.0;
p.exposure_per_s = 1.0;
p.stop_time = 170.0;
p.form = 'E0 + Emax*frac';
end
