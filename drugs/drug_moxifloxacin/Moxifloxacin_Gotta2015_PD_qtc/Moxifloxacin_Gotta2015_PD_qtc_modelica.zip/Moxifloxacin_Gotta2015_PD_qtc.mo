model Moxifloxacin_Gotta2015_PD_qtc
  "sigmoid_emax exposure-response sweep — Gotta_2015 :: ΔQTc (QTc prolongation)"
  extends Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep(
    E0 = 0.239,      // [s; ms × 0.001]
    Emax = 0.0546,  // [s; ms × 0.001]
    EC50 = 16.3,  // [μM]
    gamma = 1.8,
    exposure_per_s = 1);   // 1 μM per second
  // exposure_unit_unresolved: 'μM' — the x axis is in the paper's unit, not SI
  annotation(experiment(StartTime = 0, StopTime = 170, Interval = 0.34),
    Documentation(info = "<html><body><!-- drug-about --><h4>About moxifloxacin</h4><p>Moxifloxacin is a fluoroquinolone antibiotic used to treat bacterial infections such as pneumonia, sinusitis, bronchitis, conjunctivitis, and urinary tract infections. It is an approved medicine, included on the WHO essential medicines list, and is used both systemically and as eye drops, though it carries a boxed warning.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q424940\">Wikidata Q424940</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h4>Moxifloxacin_Gotta2015_PD_qtc</h4><p>The steady-state exposure-response curve of Gotta V et al., <i>British journal of pharmacology 172(17):4364–4379</i> 2015 (<a href=\"https://doi.org/10.1111/bph.13218\">doi:10.1111/bph.13218</a>) — QTc prolongation [ms] against moxifloxacin μM — obtained by sweeping the driver instead of simulating a dose. Model family: sigmoid_emax.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    =        239 ms       drug-free response (baseline) (QTcBL60, Q324)
  Emax  =       54.6 ms       maximal effect term (Emax, Q320)
  EC50  =       16.3 μM       exposure at half of the maximal effect term (EC50, Q321)
  gamma =        1.8          Hill coefficient (Hill coefficient, Q325)</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep\">SigmoidEmaxSweep</a>; this model only supplies the numbers. The x axis is one μM of moxifloxacin per second of simulated time: there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0.239   (drug-free)
  exposure = EC50 (16.3 μM)  response 0.2663
  exposure -> infinity  response 0.2936</pre></body></html>"));
end Moxifloxacin_Gotta2015_PD_qtc;
