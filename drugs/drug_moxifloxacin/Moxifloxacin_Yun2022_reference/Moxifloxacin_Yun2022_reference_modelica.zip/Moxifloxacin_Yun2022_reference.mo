model Moxifloxacin_Yun2022_reference
  parameter Real Cl_ref = 2.027777777777778e-06 "Cl [m3/s]";
  parameter Boolean cov_category_0 = false "category level 0";
  parameter Real Vd_ref = 0.0101 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C_enteral(
    weight = 70.0,
    F = 100.0,
    Cl = Cl_ref + (9.25e-06)*(if cov_category_0 then 1 else 0),
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.4014314,
    adminMass = 0.0004,
    ka = 0.005611111111111111,
    Tlag = 0.0,
    k12 = 0.0005748074807480748,
    k21 = 0.00023793260473588344
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About moxifloxacin</h4><p>Moxifloxacin is a fluoroquinolone antibiotic used to treat bacterial infections such as pneumonia, sinusitis, bronchitis, conjunctivitis, and urinary tract infections. It is an approved medicine, included on the WHO essential medicines list, and is used both systemically and as eye drops, though it carries a boxed warning.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q424940\">Wikidata Q424940</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>moxifloxacin</td></tr><tr><td>population:</td><td>adults with multidrug-resistant tuberculosis</td></tr><tr><td>source_paper:</td><td>Yun_2022</td></tr><tr><td>measured_compound:</td><td>moxifloxacin</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>T2</td></tr><tr><td>input:</td><td>PK_2C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>moxifloxacin 401.431 g/mol (drugbank)</td></tr></table><p><b>Defaulted (base-class default used):</b> Tlag.</p><h4>Interpretation flags</h4><ul><li>table section iiv: 'IIV for Vd' routed out of structural estimates ('Interindividual variability CV (%)')</li><li>table section iiv: 'IIV for Vd' routed out of structural estimates ('Interindividual variability CV (%)')</li><li>table section iiv: 'IIV for CL' routed out of structural estimates ('Interindividual variability CV (%)')</li><li>table section iiv: 'IIV for CL' routed out of structural estimates ('Interindividual variability CV (%)')</li><li>table section iiv: 'IIV for Q & Vp' routed out of structural estimates ('Interindividual variability CV (%)')</li><li>table section iiv: 'IIV for Q & Vp' routed out of structural estimates ('Interindividual variability CV (%)')</li><li>table section residual_error: 'Proportional error' routed out of structural estimates ('Residual variability (RV)')</li><li>table section residual_error: 'Proportional error' routed out of structural estimates ('Residual variability (RV)')</li><li>column 'bootstrap' classified 'other' by the LLM but kept: the deterministic diagnostic-column test disagrees (a stratum column is a value column, not a statistic)</li><li>column 'bootstrap' classified 'other' by the LLM but kept: the deterministic diagnostic-column test disagrees (a stratum column is a value column, not a statistic)</li><li>column 'bootstrap' classified 'other' by the LLM but kept: the deterministic diagnostic-column test disagrees (a stratum column is a value column, not a statistic)</li><li>column 'bootstrap' classified 'other' by the LLM but kept: the deterministic diagnostic-column test disagrees (a stratum column is a value column, not a statistic)</li><li>column 'bootstrap' classified 'other' by the LLM but kept: the deterministic diagnostic-column test disagrees (a stratum column is a value column, not a statistic)</li><li>column 'bootstrap' classified 'other' by the LLM but kept: the deterministic diagnostic-column test disagrees (a stratum column is a value column, not a statistic)</li><li>column 'bootstrap' classified 'other' by the LLM but kept: the deterministic diagnostic-column test disagrees (a stratum column is a value column, not a statistic)</li><li>column 'bootstrap' classified 'other' by the LLM but kept: the deterministic diagnostic-column test disagrees (a stratum column is a value column, not a statistic)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Moxifloxacin_Yun2022_reference;
