function p = Moxifloxacin_AguadoSierra2024_PD_qt_params()
% Moxifloxacin_AguadoSierra2024_PD_qt_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% moxifloxacin Aguado-Sierra_2024::QT: linear exposure-response sweep (response = E0 + slope*exposure). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one µg/mL per second, in SI inside (kg/m3, s). Response ΔQT in ms. Driver: moxifloxacin (cited_pk).
p.E0 = 0.0;
p.Emax = 0.0;
p.EC50 = 1.0;
p.gamma = 1.0;
p.slope = 0.01;
p.exposure_per_s = 0.001;
p.stop_time = 1000.0;
p.form = 'E0 + slope*exposure';
end
