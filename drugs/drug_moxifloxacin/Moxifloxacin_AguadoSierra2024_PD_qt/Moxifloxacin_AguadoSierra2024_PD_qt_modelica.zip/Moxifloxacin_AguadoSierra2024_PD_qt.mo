model Moxifloxacin_AguadoSierra2024_PD_qt
  "linear exposure-response sweep — Aguado-Sierra_2024 :: ΔQT (QT interval prolongation)"
  extends Pharmacolibrary.Interfaces.PartialExposureResponseSweep(
    E0 = 0,      // [1]
    Emax = 0, EC50 = 1,      // unused by a line
    exposure_per_s = 0.001);
  parameter Real slope = 0.01   "[1]";
equation
  response = E0 + slope*exposure;
  // defaulted: E0
  annotation(experiment(StartTime = 0, StopTime = 1000, Interval = 2),
    Documentation(info = "<html><body><!-- drug-about --><h4>About moxifloxacin</h4><p>Moxifloxacin is a fluoroquinolone antibiotic used to treat bacterial infections such as pneumonia, sinusitis, bronchitis, conjunctivitis, and urinary tract infections. It is an approved medicine, included on the WHO essential medicines list, and is used both systemically and as eye drops, though it carries a boxed warning.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q424940\">Wikidata Q424940</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h4>Moxifloxacin_AguadoSierra2024_PD_qt</h4><p>The steady-state exposure-response curve of Aguado-Sierra J et al., <i>Journal of pharmacological and toxicological methods 126:107498</i> 2024 (<a href=\"https://doi.org/10.1016/j.vascn.2024.107498\">doi:10.1016/j.vascn.2024.107498</a>) — QT interval prolongation [ms] against moxifloxacin µg/mL — obtained by sweeping the driver instead of simulating a dose. Model family: linear.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = (library default) drug-free response (baseline)
  slope =       0.01          change in response per unit of exposure (Slope, Q335)</pre><p>The algebra is <code>response = E0 + slope*exposure</code>; this model only supplies the numbers. The x axis is one µg/mL of moxifloxacin per second of simulated time (exposure is in kg/m3): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0   (drug-free)</pre></body></html>"));
end Moxifloxacin_AguadoSierra2024_PD_qt;
