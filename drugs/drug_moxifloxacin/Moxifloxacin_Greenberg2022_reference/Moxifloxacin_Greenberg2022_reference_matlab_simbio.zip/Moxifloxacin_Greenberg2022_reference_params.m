function p = Moxifloxacin_Greenberg2022_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: moxifloxacin   source: Greenberg_2022 / reference   route: oral
  p.name  = 'Moxifloxacin_Greenberg2022_reference_params';
  p.drug  = 'moxifloxacin';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 167.0;                % central volume [L]
  p.CL = 18.2;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 2.21;                % absorption rate [1/h]
  p.F  = 0.76;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 10.0;             % dose [mg]
end
