function p = Moxifloxacin_Xu2024_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: moxifloxacin   source: Xu_2024 / reference   route: oral
  % estimated (absent from source): ka
  p.name  = 'Moxifloxacin_Xu2024_reference_params';
  p.drug  = 'moxifloxacin';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 33.4;                % central volume [L]
  p.CL = 3.53;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.5;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 400.0;             % dose [mg]
end
