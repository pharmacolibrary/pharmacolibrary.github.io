model D_4AminosalicylicAcid_Sy2015_reference
  parameter Real Cl_ref = 2.2611111111111117e-06 "Cl [m3/s]";
  parameter Real cov_gender_0 = 0 "gender covariate";
  parameter Real Vd_ref = 0.0489 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref*(1 + (0.315)*cov_gender_0),
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    adminMass = 0.004,
    ka = 4.284722222222222e-05,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About 4_aminosalicylic_acid</h4><p>4-Aminosalicylic acid is an antibiotic used to treat tuberculosis and has also been used for Crohn's colitis. It remains in clinical use and is included on the WHO list of essential medicines.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q229924\">Wikidata Q229924</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>4_aminosalicylic_acid</td></tr><tr><td>population:</td><td>tuberculosis patients</td></tr><tr><td>source_paper:</td><td>Sy_2015</td></tr><tr><td>measured_compound:</td><td>para-aminosalicylic acid</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>tab_2</td></tr><tr><td>input:</td><td>PK_1C_enteral: transit-compartment absorption reported; transit absorption (ktr=0.0001714/s, n=3) folded to first-order ka = ktr/(n+1) = 4.285e-05/s — same mean absorption time, no delay phase</td></tr><tr><td>molar_masses:</td><td>4_aminosalicylic_acid 153.137 g/mol (pubchem)</td></tr></table><p><b>Defaulted (base-class default used):</b> Tlag.</p><h4>Interpretation flags</h4><ul><li>dropped duplicate Q27 ('CL/F', value '32.2') — already have one for this compound</li><li>dropped duplicate Q76 ('V/F', value '25.2') — already have one for this compound</li><li>dropped duplicate Q306 ('Ktr', value '44.7') — already have one for this compound</li><li>dropped unlinked row (NIL): 'Efavirenz on CL/F' — extend the ontology if this is a real PK parameter (source ['tab_2:row18:col1'])</li><li>covariate level 'Gender on CL/F' → Q900:gender_on_cl_f = 0.315 (linear_fractional on Q27)</li><li>apparent-ness (ontology-grounded): parameterization=apparent, measured_compound=para-aminosalicylic acid</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end D_4AminosalicylicAcid_Sy2015_reference;
