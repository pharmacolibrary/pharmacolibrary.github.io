function p = Sirolimus_de2023_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: sirolimus   source: de_2023 / reference   route: iv_bolus
  % estimated (absent from source): F
  p.name  = 'Sirolimus_de2023_reference_params';
  p.drug  = 'sirolimus';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'iv_bolus';        % 'oral' | 'iv_bolus'
  p.depot = false;             % oral -> first-order absorption depot
  p.Vc = 25.984;                % central volume [L]
  p.CL = 1.512;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.0;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 4.2;             % dose [mg]
end
