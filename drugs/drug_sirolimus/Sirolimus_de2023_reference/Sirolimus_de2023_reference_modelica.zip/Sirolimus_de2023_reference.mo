model Sirolimus_de2023_reference
  parameter Real Cl_ref = 4.2e-07 "Cl [m3/s]";
  parameter Real Vd_ref = 0.025983999999999997 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.914187,
    adminMass = 4.2000000000000004e-06
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About sirolimus</h4><p>Sirolimus is an immunosuppressive medicine used to prevent rejection of transplanted organs, and is also used in conditions such as renal cell carcinoma, graft-versus-host disease, lymphangioleiomyomatosis, and tuberous sclerosis-related angiofibroma. It is widely used and authorised in the European Union, with products approved for graft rejection, kidney transplantation, angiofibroma, tuberous sclerosis, and uveitis.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q32089\">Wikidata Q32089</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>sirolimus</td></tr><tr><td>population:</td><td>healthy adult horses</td></tr><tr><td>source_paper:</td><td>de_2023</td></tr><tr><td>measured_compound:</td><td>sirolimus</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>jvim16650-tbl-0001</td></tr><tr><td>input:</td><td>PK_1C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>sirolimus 914.187 g/mol (drugbank)</td></tr></table><h4>Interpretation flags</h4><ul><li>dropped unlinked row (NIL): 'Parameters' — extend the ontology if this is a real PK parameter (source ['jvim16650-tbl-0001:row0:col1'])</li><li>salvaged Q61 ('Volume of distribution'=371.2) from results prose — parameter table was unreadable</li><li>salvaged Q22 ('clearance'=0.36) from results prose — parameter table was unreadable</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=sirolimus</li><li>held at status:extracted — NIL link or unit issue (mismatch/unknown/normalisation-failed) present</li><li>status held at route_to_review — not promoted</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 259200, Tolerance = 1e-9, Interval = 1));
end Sirolimus_de2023_reference;
