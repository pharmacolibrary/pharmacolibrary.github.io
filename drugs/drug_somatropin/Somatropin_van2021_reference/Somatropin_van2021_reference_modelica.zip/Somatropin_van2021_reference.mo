model Somatropin_van2021_reference
  parameter Real Cl_ref = 4.166666666666667e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.065 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 0.9,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    adminMass = 0.0001,
    ka = 0.00026388888888888886,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About somatropin</h4><p>Somatropin, a recombinant form of human growth hormone, is used to treat growth disorders such as pituitary dwarfism, Turner syndrome, and Prader-Willi syndrome. It is an approved medicine with authorised products in the European Union and is widely used for growth-related conditions.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q19709937\">Wikidata Q19709937</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>somatropin</td></tr><tr><td>population:</td><td>review reference</td></tr><tr><td>source_paper:</td><td>van_2021</td></tr><tr><td>measured_compound:</td><td>somatropin</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr></table><p><b>Defaulted (base-class default used):</b> F, Tlag.</p><h4>Interpretation flags</h4><ul><li>built from REVIEW reference values (van_2021) — secondary source</li><li>volume reported by review</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Somatropin_van2021_reference;
