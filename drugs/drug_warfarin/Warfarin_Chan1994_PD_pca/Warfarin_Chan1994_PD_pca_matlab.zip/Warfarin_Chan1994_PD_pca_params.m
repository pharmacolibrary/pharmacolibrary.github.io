function p = Warfarin_Chan1994_PD_pca_params()
% Warfarin_Chan1994_PD_pca_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% warfarin Chan_1994::PCA: indirect_response_i exposure-response sweep (response = E0*(1 - Emax*frac)). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one mg.L-1 per second, in SI inside (kg/m3, s). Response PCA in its own unit. Driver: warfarin (cited_pk).
p.E0 = 0.0;
p.Emax = 1.0;
p.EC50 = 2.5999999999999992e-06;
p.gamma = 0.9;
p.slope = 0.0;
p.exposure_per_s = 0.001;
p.stop_time = 0.026;
p.form = 'E0*(1 - Emax*frac)';
end
