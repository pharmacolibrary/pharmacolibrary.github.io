function p = Warfarin_Aoyama2022_PD_inr_params()
% Warfarin_Aoyama2022_PD_inr_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% warfarin Aoyama_2022::INR: sigmoid_emax exposure-response sweep (response = E0 + Emax*frac). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one mg/L per second, in SI inside (kg/m3, s). Response INR in its own unit. Driver: S-warfarin (pk_record).
p.E0 = 0.0;
p.Emax = -1.0;
p.EC50 = 0.004099999999999999;
p.gamma = 1.15;
p.slope = 0.0;
p.exposure_per_s = 0.001;
p.stop_time = 41.0;
p.form = 'E0 + Emax*frac';
end
