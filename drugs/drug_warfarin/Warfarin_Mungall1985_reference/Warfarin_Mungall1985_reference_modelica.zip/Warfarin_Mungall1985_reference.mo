model Warfarin_Mungall1985_reference
  parameter Real Cl_ref = 9.666666666666667e-08 "Cl [m3/s]";
  parameter Real Vd_ref = 0.0143 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 0.9,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.3083279,
    adminMass = 7.5e-06,
    ka = 0.0005439814814814814,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>warfarin</td></tr><tr><td>population:</td><td>adult patients</td></tr><tr><td>source_paper:</td><td>Mungall_1985</td></tr><tr><td>measured_compound:</td><td>warfarin</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>warfarin 308.328 g/mol (drugbank)</td></tr></table><p><b>Defaulted (base-class default used):</b> F, Tlag.</p><h4>Interpretation flags</h4><ul><li>covariate category for CL/F from footnote/prose kept as documentation only (['Mungall_1985:abstract'])</li><li>covariate category for CL from footnote/prose kept as documentation only (['Mungall_1985:abstract'])</li><li>covariate category for CL from footnote/prose kept as documentation only (['Mungall_1985:abstract'])</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=warfarin</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li><li>gap-filled Q22 (CL) from Aoyama_2022's review values (primary lacked it)</li><li>gap-filled Q61 (V) from Aoyama_2022's review values (primary lacked it)</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of TLAG: primary's parameterization (rate-constant / ka-only) does not use it</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 518400, Tolerance = 1e-9, Interval = 1));
end Warfarin_Mungall1985_reference;
