function p = Warfarin_Hirai2024_PD_pt_inr_params()
% Warfarin_Hirai2024_PD_pt_inr_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% warfarin Hirai_2024::PT_INR: sigmoid_emax exposure-response sweep (response = E0 + Emax*frac). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one mg/h per second, in SI inside (kg/m3, s). Response PT-INR in its own unit. Driver: warfarin (dose_only).
p.E0 = 0.0;
p.Emax = -1.0;
p.EC50 = 2.9444444444444443e-10;
p.gamma = 1.18;
p.slope = 0.0;
p.exposure_per_s = 2.77777777778e-10;
p.stop_time = 11.0;
p.form = 'E0 + Emax*frac';
end
