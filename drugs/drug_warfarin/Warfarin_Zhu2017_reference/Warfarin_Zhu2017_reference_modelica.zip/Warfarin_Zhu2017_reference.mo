model Warfarin_Zhu2017_reference
  parameter Real Cl_ref = 1.6277777777777775e-07 "Cl [m3/s]";
  parameter Real Vd_ref = 0.0229 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.3083,
    adminMass = 7.5e-06
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>warfarin</td></tr><tr><td>population:</td><td>Chinese patients with valve replacement</td></tr><tr><td>source_paper:</td><td>Zhu_2017</td></tr><tr><td>measured_compound:</td><td>S-warfarin</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>tab_2</td></tr><tr><td>input:</td><td>PK_1C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>warfarin 308.328 g/mol (drugbank); S-warfarin 308.3 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>dropped unlinked row (NIL): 'OFV' — extend the ontology if this is a real PK parameter (source ['tab_2:row2:col2'])</li><li>dropped unlinked row (NIL): 'OFV' — extend the ontology if this is a real PK parameter (source ['tab_2:row2:col6'])</li><li>routed 'Inter-individual variation' → Q312 (IIV) to iiv — variability estimate, not a structural parameter</li><li>routed 'Inter-individual variation' → Q312 (IIV) to iiv — variability estimate, not a structural parameter</li><li>routed 'Intra-individual variation' → Q313 (IOV) to iov — variability estimate, not a structural parameter</li><li>routed 'Intra-individual variation' → Q313 (IOV) to iov — variability estimate, not a structural parameter</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=S-warfarin</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 518400, Tolerance = 1e-9, Interval = 1));
end Warfarin_Zhu2017_reference;
