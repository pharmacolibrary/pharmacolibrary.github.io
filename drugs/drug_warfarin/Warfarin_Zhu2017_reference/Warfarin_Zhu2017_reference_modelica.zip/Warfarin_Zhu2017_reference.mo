model Warfarin_Zhu2017_reference
  parameter Real Cl_ref = 1.6277777777777775e-07 "Cl [m3/s]";
  parameter Real Vd_ref = 0.0229 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 0.9,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.3083,
    adminMass = 7.5e-06,
    ka = 5.9444444444444445e-05,
    Tlag = 4644.0
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About warfarin</h4><p>Warfarin is an anticoagulant used to prevent and treat blood clots in conditions such as atrial fibrillation, heart valve disease, pulmonary embolism, thrombosis, and heart disease. It is widely used in human medicine and is included on the WHO list of essential medicines, though it also serves as a rodenticide and carries a boxed warning.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q113368879\">Wikidata Q113368879</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>warfarin</td></tr><tr><td>population:</td><td>Chinese patients with valve replacement</td></tr><tr><td>source_paper:</td><td>Zhu_2017</td></tr><tr><td>measured_compound:</td><td>S-warfarin</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>tab_2</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>S-warfarin 308.3 g/mol (pubchem); warfarin 308.328 g/mol (drugbank)</td></tr></table><p><b>Defaulted (base-class default used):</b> F.</p><h4>Interpretation flags</h4><ul><li>dropped unlinked row (NIL): 'OFV' — extend the ontology if this is a real PK parameter (source ['tab_2:row2:col2'])</li><li>dropped unlinked row (NIL): 'OFV' — extend the ontology if this is a real PK parameter (source ['tab_2:row2:col6'])</li><li>routed 'Inter-individual variation' → Q312 (IIV) to iiv — variability estimate, not a structural parameter</li><li>routed 'Inter-individual variation' → Q312 (IIV) to iiv — variability estimate, not a structural parameter</li><li>routed 'Intra-individual variation' → Q313 (IOV) to iov — variability estimate, not a structural parameter</li><li>routed 'Intra-individual variation' → Q313 (IOV) to iov — variability estimate, not a structural parameter</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=S-warfarin</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li><li>gap-filled Q49 (kabs) from Gomeni_2026's review values (primary lacked it)</li><li>gap-filled Q83 (tlag) from Gomeni_2026's review values (primary lacked it)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 604800, Tolerance = 1e-9, Interval = 1));
end Warfarin_Zhu2017_reference;
