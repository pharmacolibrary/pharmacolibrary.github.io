function p = Warfarin_RodrguezFernndez2024_PD_inr_params()
% Warfarin_RodrguezFernndez2024_PD_inr_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% warfarin Rodríguez-Fernández_2024::INR: indirect_response_ii exposure-response sweep (response = E0/(1 - Emax*frac)). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one mg/L per second, in SI inside (kg/m3, s). Response INR in its own unit. Driver: warfarin (cited_pk).
p.E0 = 23.0;
p.Emax = 1.0;
p.EC50 = 0.033999999999999996;
p.gamma = 1.0;
p.slope = 0.0;
p.exposure_per_s = 0.0009999999999999998;
p.stop_time = 340.0;
p.form = 'E0/(1 - Emax*frac)';
end
