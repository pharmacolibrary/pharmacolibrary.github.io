model Warfarin_RodrguezFernndez2024_PD_inr
  "indirect_response_ii exposure-response sweep — Rodríguez-Fernández_2024 :: INR (INR)"
  extends Pharmacolibrary.Interfaces.PartialExposureResponseSweep(
    E0 = 23.0,      // [1]
    Emax = 1.0,  // type II effect term
    EC50 = 0.033999999999999996,  // [kg/m3; mg/L × 0.001]
    gamma = 1.0,
    exposure_per_s = 0.0009999999999999998);   // 1 mg/L per second
equation
  response = E0/(1 - Emax*frac);   // steady state, indirect response type II
  // defaulted: Emax
  // defaulted: gamma
  annotation(experiment(StartTime = 0, StopTime = 340, Interval = 0.68));
end Warfarin_RodrguezFernndez2024_PD_inr;
