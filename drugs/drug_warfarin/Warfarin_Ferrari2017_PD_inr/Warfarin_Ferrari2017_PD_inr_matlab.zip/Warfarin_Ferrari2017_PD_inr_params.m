function p = Warfarin_Ferrari2017_PD_inr_params()
% Warfarin_Ferrari2017_PD_inr_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% warfarin Ferrari_2017::INR: linear exposure-response sweep (response = E0 + slope*exposure). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one SI per second, in SI inside (kg/m3, s). Response INR in its own unit. Driver: (S)-warfarin and (R)-warfarin (not_resolved).
p.E0 = 0.0;
p.Emax = 0.0;
p.EC50 = 1.0;
p.gamma = 1.0;
p.slope = 0.71;
p.exposure_per_s = 1.0;
p.stop_time = 1000.0;
p.form = 'E0 + slope*exposure';
end
