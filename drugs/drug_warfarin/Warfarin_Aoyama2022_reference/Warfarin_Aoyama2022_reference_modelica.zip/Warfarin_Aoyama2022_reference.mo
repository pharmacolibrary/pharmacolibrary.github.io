model Warfarin_Aoyama2022_reference
  parameter Real Cl_ref = 9.666666666666667e-08 "Cl [m3/s]";
  parameter Real Vd_ref = 0.0143 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 0.9,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    adminMass = 3.2000000000000003e-06,
    ka = 5.9444444444444445e-05,
    Tlag = 4644.0
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>warfarin</td></tr><tr><td>population:</td><td>adult patients</td></tr><tr><td>source_paper:</td><td>Aoyama_2022</td></tr><tr><td>measured_compound:</td><td>S-warfarin</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>table 1</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>warfarin 308.328 g/mol (drugbank)</td></tr></table><p><b>Defaulted (base-class default used):</b> F.</p><h4>Interpretation flags</h4><ul><li>dropped value-less row: 'Male, N (%)' (captured trailing unit '%' for child rows)</li><li>dropped value-less row: 'Age >60 years, N (%)' (captured trailing unit '%' for child rows)</li><li>dropped value-less row: 'BMI ≤25 kg/m 2 , N (%)' (captured trailing unit '%' for child rows)</li><li>dropped value-less row: 'eGFR b) , mL/min/1.73 m 2'</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=S-warfarin</li><li>gap-filled Q22 (CL) from Aoyama_2022's review values (primary lacked it)</li><li>gap-filled Q61 (V) from Aoyama_2022's review values (primary lacked it)</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li><li>gap-filled Q49 (kabs) from Gomeni_2026's review values (primary lacked it)</li><li>gap-filled Q83 (tlag) from Gomeni_2026's review values (primary lacked it)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 604800, Tolerance = 1e-9, Interval = 1));
end Warfarin_Aoyama2022_reference;
