function p = Warfarin_Shi2024_PD_npt_params()
% Warfarin_Shi2024_PD_npt_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% warfarin Shi_2024::NPT: indirect_response_i exposure-response sweep (response = E0*(1 - Emax*frac)). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one mg/L per second, in SI inside (kg/m3, s). Response NPT in its own unit. Driver: S-warfarin (cited_pk).
p.E0 = 0.0;
p.Emax = 1.0;
p.EC50 = 7.249999999999999e-05;
p.gamma = 1.0;
p.slope = 0.0;
p.exposure_per_s = 0.001;
p.stop_time = 0.73;
p.form = 'E0*(1 - Emax*frac)';
end
