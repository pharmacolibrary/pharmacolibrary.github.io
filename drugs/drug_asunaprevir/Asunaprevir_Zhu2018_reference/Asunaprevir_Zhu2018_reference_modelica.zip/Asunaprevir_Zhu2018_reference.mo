model Asunaprevir_Zhu2018_reference
  parameter Real Cl_ref = 1.411111111111111e-05 "Cl [m3/s]";
  parameter Real Vd_ref = 0.0476 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.7482859999999999,
    adminMass = 0.0001,
    ka = 0.00013444444444444444,
    Tlag = 0.0,
    k12 = 0.00012605042016806722,
    k21 = 1.06951871657754e-05
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About asunaprevir</h4><p>Asunaprevir is an antiviral protease inhibitor that was used to treat hepatitis C virus infections. It is no longer in use, having been withdrawn from the market.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q4811881\">Wikidata Q4811881</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>asunaprevir</td></tr><tr><td>population:</td><td>adults with chronic HCV infection</td></tr><tr><td>source_paper:</td><td>Zhu_2018</td></tr><tr><td>measured_compound:</td><td>asunaprevir</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>Tab2</td></tr><tr><td>input:</td><td>PK_2C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>asunaprevir 748.286 g/mol (drugbank)</td></tr></table><p><b>Defaulted (base-class default used):</b> Tlag.</p><h4>Interpretation flags</h4><ul><li>table section residual_error: 'ε' routed out of structural estimates ('Residual errorc')</li><li>table section residual_error: 'ε' routed out of structural estimates ('Residual errorc')</li><li>dropped duplicate Q27 ('CL/F ~ induction', value '0.355') — already have one for this compound</li><li>dropped value-less row: 'Relative F ~ tablet'</li><li>dropped duplicate Q310 ('D1 ~ tablet', value '0.864') — already have one for this compound</li><li>dropped value-less row: 'CL ~ age'</li><li>dropped value-less row: 'Vc ~ female'</li><li>dropped value-less row: 'CL ~ female'</li><li>dropped value-less row: 'CL ~ Asian Race'</li><li>dropped value-less row: 'CL ~ Other Race'</li><li>dropped value-less row: 'CL ~ baseline AST'</li><li>dropped value-less row: 'CL ~ AST'</li><li>dropped value-less row: 'Vc ~ cirrhosis'</li><li>dropped value-less row: 'CL ~ cirrhosis'</li><li>dropped value-less row: 'Ka ~ tablet'</li><li>dropped duplicate Q27 ('CL/F', value '0.168') — already have one for this compound</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Asunaprevir_Zhu2018_reference;
