function p = Indinavir_Csajka2004_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: indinavir   source: Csajka_2004 / reference   route: oral
  p.name  = 'Indinavir_Csajka2004_reference_params';
  p.drug  = 'indinavir';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 65.7;                % central volume [L]
  p.CL = 32.4;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.871;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.485;             % absorption lag [h]
  p.dose = 2400.0;             % dose [mg]
end
