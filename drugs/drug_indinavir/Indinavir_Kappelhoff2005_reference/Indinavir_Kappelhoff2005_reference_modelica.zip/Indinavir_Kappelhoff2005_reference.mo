model Indinavir_Kappelhoff2005_reference
  parameter Real Cl_ref = 2.916666666666667e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.09659999999999999 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 0.9,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.6137895,
    adminMass = 0.0024,
    ka = 0.00024194444444444445,
    Tlag = 1746.0
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About indinavir</h4><p>Indinavir is a protease inhibitor that was used to treat HIV infection and AIDS.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q425490\">Wikidata Q425490</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>indinavir</td></tr><tr><td>population:</td><td>review reference</td></tr><tr><td>source_paper:</td><td>Kappelhoff_2005</td></tr><tr><td>measured_compound:</td><td>indinavir</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>indinavir 613.789 g/mol (drugbank)</td></tr></table><p><b>Defaulted (base-class default used):</b> F.</p><h4>Interpretation flags</h4><ul><li>built from REVIEW reference values (Kappelhoff_2005) — secondary source</li><li>volume reported by review</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 129600, Tolerance = 1e-9, Interval = 1));
end Indinavir_Kappelhoff2005_reference;
