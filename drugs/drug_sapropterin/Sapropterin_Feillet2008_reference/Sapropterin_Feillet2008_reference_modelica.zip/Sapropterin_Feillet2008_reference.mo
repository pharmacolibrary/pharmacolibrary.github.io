model Sapropterin_Feillet2008_reference
  parameter Real Cl_ref = 0.0005833333333333334 "Cl [m3/s]";
  parameter Real Vd_ref = 8.35 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    adminMass = 0.0001,
    ka = 0.0001388888888888889,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>sapropterin</td></tr><tr><td>population:</td><td>patients with phenylketonuria aged >=8 years</td></tr><tr><td>source_paper:</td><td>Feillet_2008</td></tr><tr><td>measured_compound:</td><td>sapropterin (6R-BH4)</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C_enteral: apparent (/F) parameterization ⇒ extravascular dosing</td></tr><tr><td>molar_masses:</td><td>sapropterin 241.247 g/mol (drugbank)</td></tr></table><p><b>Defaulted (base-class default used):</b> ka, Tlag.</p><h4>Interpretation flags</h4><ul><li>apparent-ness (ontology-grounded): parameterization=apparent, measured_compound=sapropterin (6R-BH4)</li><li>1C volume normalization: Q63→Q61 (single-compartment model has no central/peripheral split; 'central volume of distribution (mean' is the general volume)</li><li>molar mass: 'sapropterin (6R-BH4)' ('sapropterin (6R-BH4)') not found in PubChem — left in mass units</li><li>molar mass: none found for 'sapropterin (6R-BH4)' — its concentrations stay mass-only</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 122400, Tolerance = 1e-9, Interval = 1));
end Sapropterin_Feillet2008_reference;
