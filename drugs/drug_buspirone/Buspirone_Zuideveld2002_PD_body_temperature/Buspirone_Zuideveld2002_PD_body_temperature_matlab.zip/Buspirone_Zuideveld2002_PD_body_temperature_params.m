function p = Buspirone_Zuideveld2002_PD_body_temperature_params()
% Buspirone_Zuideveld2002_PD_body_temperature_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% buspirone Zuideveld_2002::body_temperature: indirect_response_i exposure-response sweep (response = E0*(1 - Emax*frac)). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one ng/ml per second, in SI inside (kg/m3, s). Response body temperature in its own unit. Driver: buspirone (pk_record).
p.E0 = 0.0;
p.Emax = 0.465;
p.EC50 = 1.76e-05;
p.gamma = 1.0;
p.slope = 0.0;
p.exposure_per_s = 1e-06;
p.stop_time = 180.0;
p.form = 'E0*(1 - Emax*frac)';
end
