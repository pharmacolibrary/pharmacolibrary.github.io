model Buspirone_Zuideveld2002_PD_body_temperature
  "indirect_response_i exposure-response sweep — Zuideveld_2002 :: body temperature (body temperature)"
  extends Pharmacolibrary.Interfaces.PartialExposureResponseSweep(
    E0 = 0,      // [1]
    Emax = 0.465,  // type I effect term
    EC50 = 1.76e-05,  // [kg/m3; ng/ml × 1e-06]
    gamma = 1,
    exposure_per_s = 1e-06);   // 1 ng/ml per second
equation
  response = E0*(1 - Emax*frac);   // steady state, indirect response type I
  // defaulted: E0
  // defaulted: gamma
  annotation(experiment(StartTime = 0, StopTime = 180, Interval = 0.36),
    Documentation(info = "<html><body><!-- drug-about --><h4>About buspirone</h4><p>Buspirone is a medication used to treat anxiety disorders and related neurotic conditions. It is an approved anxiolytic, used fairly widely for anxiety, though it is not authorised in the European Union.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q412194\">Wikidata Q412194</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h4>Buspirone_Zuideveld2002_PD_body_temperature</h4><p>The steady-state exposure-response curve of Zuideveld KP et al., <i>The Journal of pharmacology and experimental therapeutics 303(3):1130–1137</i> 2002 (<a href=\"https://doi.org/10.1124/jpet.102.036798\">doi:10.1124/jpet.102.036798</a>) — body temperature against buspirone ng/ml — obtained by sweeping the driver instead of simulating a dose. Model family: indirect_response_i.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = (library default) drug-free response (baseline)
  Emax  =      0.465          maximal effect term (intrinsic activity, Q323)
  EC50  =       17.6 ng/ml    exposure at half of the maximal effect term (potency (C50), Q322)
  gamma = (library default) Hill coefficient</pre><p>The algebra is <code>response = E0*(1 - Emax*frac)</code>; this model only supplies the numbers. The x axis is one ng/ml of buspirone per second of simulated time (exposure is in kg/m3): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0   (drug-free)
  exposure = EC50 (17.6 ng/ml)  response 0
  exposure -> infinity  response 0</pre></body></html>"));
end Buspirone_Zuideveld2002_PD_body_temperature;
