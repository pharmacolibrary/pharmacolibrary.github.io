model Buspirone_Schoeffter1988_PD_forskolin_stimulated_adenylate_c
  "emax exposure-response sweep — Schoeffter_1988 :: forskolin-stimulated adenylate cyclase activity in calf hippocampus (forskolin-stimulated adenylate cyclase activity in calf hippocampus)"
  extends Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep(
    E0 = 0,      // [1]
    Emax = -14,  // [% inhibition]
    EC50 = 65,  // [nM]
    gamma = 1,
    exposure_per_s = 1);   // 1 nM per second
  // imax_as_negative_emax: Imax (Q323) enters SigmoidEmaxSweep as −Emax
  // exposure_unit_unresolved: 'nM' — the x axis is in the paper's unit, not SI
  // defaulted: E0
  // defaulted: gamma
  annotation(experiment(StartTime = 0, StopTime = 650, Interval = 1.3),
    Documentation(info = "<html><body><!-- drug-about --><h4>About buspirone</h4><p>Buspirone is a medication used to treat anxiety disorders and related neurotic conditions. It is an approved anxiolytic, used fairly widely for anxiety, though it is not authorised in the European Union.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q412194\">Wikidata Q412194</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h4>Buspirone_Schoeffter1988_PD_forskolin_stimulated_adenylate_c</h4><p>The steady-state exposure-response curve of Schoeffter P et al., <i>British journal of pharmacology 95(3):975–985</i> 1988 (<a href=\"https://doi.org/10.1111/j.1476-5381.1988.tb11728.x\">doi:10.1111/j.1476-5381.1988.tb11728.x</a>) — forskolin-stimulated adenylate cyclase activity in calf hippocampus [% inhibition] against buspirone nM — obtained by sweeping the driver instead of simulating a dose. Model family: emax.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = (library default) drug-free response (baseline)
  Emax  =         14 % inhibition maximal effect term (Emax, Q323)
  EC50  =         65 nM       exposure at half of the maximal effect term (EC50, Q321)
  gamma = (library default) Hill coefficient</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep\">SigmoidEmaxSweep</a>; this model only supplies the numbers. The x axis is one nM of buspirone per second of simulated time: there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0   (drug-free)
  exposure = EC50 (65 nM)  response -7
  exposure -> infinity  response -14</pre></body></html>"));
end Buspirone_Schoeffter1988_PD_forskolin_stimulated_adenylate_c;
