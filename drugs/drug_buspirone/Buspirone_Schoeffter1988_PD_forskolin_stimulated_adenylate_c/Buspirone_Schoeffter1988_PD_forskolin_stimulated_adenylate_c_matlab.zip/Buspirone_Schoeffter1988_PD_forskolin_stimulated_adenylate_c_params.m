function p = Buspirone_Schoeffter1988_PD_forskolin_stimulated_adenylate_c_params()
% Buspirone_Schoeffter1988_PD_forskolin_stimulated_adenylate_c_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% buspirone Schoeffter_1988::forskolin_stimulated_adenylate_cyclase_activity_in_calf_hippocampus: emax exposure-response sweep (response = E0 + Emax*frac). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one nM per second, in SI inside (kg/m3, s). Response forskolin-stimulated adenylate cyclase activity in calf hippocampus in % inhibition. Driver: buspirone (cited_pk).
p.E0 = 0.0;
p.Emax = -14.0;
p.EC50 = 65.0;
p.gamma = 1.0;
p.slope = 0.0;
p.exposure_per_s = 1.0;
p.stop_time = 650.0;
p.form = 'E0 + Emax*frac';
end
