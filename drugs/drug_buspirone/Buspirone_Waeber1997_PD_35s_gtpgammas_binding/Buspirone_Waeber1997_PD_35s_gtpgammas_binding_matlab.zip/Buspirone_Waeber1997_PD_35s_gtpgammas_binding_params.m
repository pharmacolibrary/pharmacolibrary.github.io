function p = Buspirone_Waeber1997_PD_35s_gtpgammas_binding_params()
% Buspirone_Waeber1997_PD_35s_gtpgammas_binding_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% buspirone Waeber_1997::35S_GTPgammaS_binding: emax exposure-response sweep (response = E0 + Emax*frac). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one nM per second, in SI inside (kg/m3, s). Response [35S]GTPgammaS binding in % stimulation. Driver: buspirone (cited_pk).
p.E0 = 0.0;
p.Emax = 0.78;
p.EC50 = 132.0;
p.gamma = 1.0;
p.slope = 0.0;
p.exposure_per_s = 1.0;
p.stop_time = 1400.0;
p.form = 'E0 + Emax*frac';
end
