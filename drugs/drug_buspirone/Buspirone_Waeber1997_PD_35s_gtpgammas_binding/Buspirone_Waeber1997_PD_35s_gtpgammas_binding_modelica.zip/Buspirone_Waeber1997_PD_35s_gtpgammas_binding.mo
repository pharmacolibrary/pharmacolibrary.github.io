model Buspirone_Waeber1997_PD_35s_gtpgammas_binding
  "emax exposure-response sweep — Waeber_1997 :: [35S]GTPgammaS binding ([35S]GTPgammaS binding stimulation in hippocampus)"
  extends Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep(
    E0 = 0,      // [1]
    Emax = 0.78,  // [1; % × 0.01]
    EC50 = 132,  // [nM]
    gamma = 1,
    exposure_per_s = 1);   // 1 nM per second
  // exposure_unit_unresolved: 'nM' — the x axis is in the paper's unit, not SI
  // defaulted: E0
  // defaulted: gamma
  annotation(experiment(StartTime = 0, StopTime = 1400, Interval = 2.8),
    Documentation(info = "<html><body><!-- drug-about --><h4>About buspirone</h4><p>Buspirone is a medication used to treat anxiety disorders and related neurotic conditions. It is an approved anxiolytic, used fairly widely for anxiety, though it is not authorised in the European Union.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q412194\">Wikidata Q412194</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h4>Buspirone_Waeber1997_PD_35s_gtpgammas_binding</h4><p>The steady-state exposure-response curve of Waeber C et al., <i>Molecular pharmacology 52(4):623–631</i> 1997 (<a href=\"https://doi.org/10.1124/mol.52.4.623\">doi:10.1124/mol.52.4.623</a>) — [35S]GTPgammaS binding stimulation in hippocampus [% stimulation] against buspirone nM — obtained by sweeping the driver instead of simulating a dose. Model family: emax.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = (library default) drug-free response (baseline)
  Emax  =         78 %        maximal effect term (Emax, Q320)
  EC50  =        132 nM       exposure at half of the maximal effect term (EC50, Q321)
  gamma = (library default) Hill coefficient</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep\">SigmoidEmaxSweep</a>; this model only supplies the numbers. The x axis is one nM of buspirone per second of simulated time: there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0   (drug-free)
  exposure = EC50 (132 nM)  response 0.39
  exposure -> infinity  response 0.78</pre></body></html>"));
end Buspirone_Waeber1997_PD_35s_gtpgammas_binding;
