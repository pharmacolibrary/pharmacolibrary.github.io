function p = Buspirone_De1986_PD_inhibition_of_forskolin_stimulated_adeny_params()
% Buspirone_De1986_PD_inhibition_of_forskolin_stimulated_adeny_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% buspirone De_1986::inhibition_of_forskolin_stimulated_adenylate_cyclase_activity: emax exposure-response sweep (response = E0 + Emax*frac). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one nM per second, in SI inside (kg/m3, s). Response inhibition of forskolin-stimulated adenylate cyclase activity in % inhibition. Driver: buspirone (cited_pk).
p.E0 = 0.0;
p.Emax = -0.5;
p.EC50 = 146.0;
p.gamma = 1.0;
p.slope = 0.0;
p.exposure_per_s = 1.0;
p.stop_time = 1500.0;
p.form = 'E0 + Emax*frac';
end
