model Cefoperazone_Soback1989_reference
  parameter Real Cl_ref = 2.266666666666667e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.0209 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.64567,
    adminMass = 0.004
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About cefoperazone</h4><p>Cefoperazone is a third-generation cephalosporin antibiotic used to treat bacterial infections, including urinary, respiratory, and Pseudomonas infections. It has been withdrawn from the market in many places and is no longer widely available.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q2325775\">Wikidata Q2325775</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>cefoperazone</td></tr><tr><td>population:</td><td>unweaned calves</td></tr><tr><td>source_paper:</td><td>Soback_1989</td></tr><tr><td>measured_compound:</td><td>cefoperazone</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>cefoperazone 645.67 g/mol (drugbank)</td></tr></table><h4>Interpretation flags</h4><ul><li>dropped duplicate Q57 ('The terminal halflife of cefoperazone ... after intramuscular administration', value 136.9) — already have one for this compound</li><li>dropped duplicate Q57 ('The t1/2 ... by the co-administration of probenecid', value 257.3) — already have one for this compound</li><li>unit_dimension_unknown: 'ml min-1 kg-1' (CL)</li><li>implicit units: 'The total body clearance' → L/h (from the popPK convention: 'No unit is stated in the provided text or table footnotes. Total body clearance is conventionally expressed in volume pe')</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=cefoperazone</li><li>held at status:extracted — NIL link or unit issue (mismatch/unknown/normalisation-failed) present</li><li>status held at route_to_review — not promoted</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li><li>gap-filled Q61 (V) from Zhou_2022's review values (primary lacked it)</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Cefoperazone_Soback1989_reference;
