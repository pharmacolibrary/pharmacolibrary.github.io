function p = ImmunoglobulinsNormalHumanForExtravascularAdm_Zhang2020_refe_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: immunoglobulins_normal_human_for_extravascular_adm   source: Zhang_2020 / reference   route: iv_bolus
  % estimated (absent from source): F, dose
  p.name  = 'ImmunoglobulinsNormalHumanForExtravascularAdm_Zhang2020_refe_params';
  p.drug  = 'immunoglobulins_normal_human_for_extravascular_adm';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'iv_bolus';        % 'oral' | 'iv_bolus'
  p.depot = false;             % oral -> first-order absorption depot
  p.Vc = 3.95;                % central volume [L]
  p.CL = 0.00575;                % clearance [L/h]
  p.Vp = [4.44];             % peripheral volumes [L]
  p.Q  = [0.010833];             % inter-compartmental clearances [L/h]
  p.ka = 0.0;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 10.0;             % dose [mg]
end
