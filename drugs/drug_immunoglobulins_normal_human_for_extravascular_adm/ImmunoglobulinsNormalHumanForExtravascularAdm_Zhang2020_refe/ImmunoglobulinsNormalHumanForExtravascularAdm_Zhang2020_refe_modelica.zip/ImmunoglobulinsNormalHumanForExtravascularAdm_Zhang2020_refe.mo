model ImmunoglobulinsNormalHumanForExtravascularAdm_Zhang2020_refe
  parameter Real Cl_ref = 1.5972222222222225e-09 "Cl [m3/s]";
  parameter Real Vd_ref = 0.00395 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    adminMass = 1e-05,
    k12 = 7.618377871542429e-07,
    k21 = 6.777610944277612e-07
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About immunoglobulins_normal_human_for_extravascular_adm</h4><p>Hizentra is a pharmaceutical product containing normal human immunoglobulin, a class of medicines used for immune-related conditions. It is classified in the ATC system under normal human immunoglobulins for systemic antiinfective use.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q57266522\">Wikidata Q57266522</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>immunoglobulins_normal_human_for_extravascular_adm</td></tr><tr><td>population:</td><td>patients with primary immunodeficiency</td></tr><tr><td>source_paper:</td><td>Zhang_2020</td></tr><tr><td>measured_compound:</td><td>serum IgG</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_2C: IV (no input phase)</td></tr></table><h4>Interpretation flags</h4><ul><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=serum IgG</li><li>molar mass: none found for 'immunoglobulins_normal_human_for_extravascular_adm' — its concentrations stay mass-only</li><li>molar mass: none found for 'serum IgG' — its concentrations stay mass-only</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li><li>review gap-fill skipped: this record measures 'serum IgG', not immunoglobulins_normal_human_for_extravascular_adm — the review values are the parent's</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 9072000, Tolerance = 1e-9, Interval = 1));
end ImmunoglobulinsNormalHumanForExtravascularAdm_Zhang2020_refe;
