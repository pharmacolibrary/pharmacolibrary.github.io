function p = Glibenclamide_Rambiritch2016_PD_mean_glucose_concentration_params()
% Glibenclamide_Rambiritch2016_PD_mean_glucose_concentration_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% glibenclamide Rambiritch_2016::mean_glucose_concentration: emax exposure-response sweep (response = E0 + Emax*frac). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one mg per second, in SI inside (kg/m3, s). Response mean glucose concentration in mmol/L. Driver: glibenclamide (dose_only).
p.E0 = 16.699999999999996;
p.Emax = -0.33999999999999997;
p.EC50 = 1.85e-06;
p.gamma = 1.0;
p.slope = 0.0;
p.exposure_per_s = 1e-06;
p.stop_time = 19.0;
p.form = 'E0 + Emax*frac';
end
