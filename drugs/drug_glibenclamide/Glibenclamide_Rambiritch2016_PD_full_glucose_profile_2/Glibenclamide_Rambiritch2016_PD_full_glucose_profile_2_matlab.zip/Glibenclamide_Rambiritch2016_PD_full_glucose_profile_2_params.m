function p = Glibenclamide_Rambiritch2016_PD_full_glucose_profile_2_params()
% Glibenclamide_Rambiritch2016_PD_full_glucose_profile_2_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% glibenclamide Rambiritch_2016::full_glucose_profile::2: emax exposure-response sweep (response = E0 + Emax*frac). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one mg/L per second, in SI inside (kg/m3, s). Response full glucose profile in mmol/L. Driver: glibenclamide (cited_pk).
p.E0 = 15.399999999999999;
p.Emax = -0.30999999999999994;
p.EC50 = 0.04359999999999999;
p.gamma = 1.0;
p.slope = 0.0;
p.exposure_per_s = 0.001;
p.stop_time = 440.0;
p.form = 'E0 + Emax*frac';
end
