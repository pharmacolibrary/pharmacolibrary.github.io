function p = Glibenclamide_Rambiritch2016_PD_full_glucose_profile_params()
% Glibenclamide_Rambiritch2016_PD_full_glucose_profile_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% glibenclamide Rambiritch_2016::full_glucose_profile: emax exposure-response sweep (response = E0 + Emax*frac). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one mg per second, in SI inside (kg/m3, s). Response full glucose profile in mmol/L. Driver: glibenclamide (dose_only).
p.E0 = 15.899999999999999;
p.Emax = -0.33999999999999997;
p.EC50 = 2.21e-06;
p.gamma = 1.0;
p.slope = 0.0;
p.exposure_per_s = 1e-06;
p.stop_time = 23.0;
p.form = 'E0 + Emax*frac';
end
