model Glibenclamide_Rambiritch2016_PD_full_glucose_profile
  "emax exposure-response sweep — Rambiritch_2016 :: full glucose profile (full glucose profile)"
  extends Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep(
    E0 = 15.9,      // [mol/m3; mmol/L × 1]
    Emax = -0.34,  // [mol/m3; mmol/L × 1]
    EC50 = 2.21e-06,  // [kg; mg × 1e-06]
    gamma = 1,
    exposure_per_s = 1e-06);   // 1 mg per second
  // imax_as_negative_emax: Imax (Q323) enters SigmoidEmaxSweep as −Emax
  // defaulted: gamma
  annotation(experiment(StartTime = 0, StopTime = 23, Interval = 0.046),
    Documentation(info = "<html><body><!-- drug-about --><h4>About glibenclamide</h4><p>Glibenclamide (glyburide) is a sulfonylurea anti-diabetic medicine used to lower blood sugar in diabetes, including a form of maturity-onset diabetes of the young. It is an approved medicine, appears on the WHO essential medicines list, and is authorised in the European Union for diabetes.</p><p><small>Summary written by glm-5.3-flash from <a href=&quot;https://www.wikidata.org/wiki/Q420626&quot;>Wikidata Q420626</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h4>Glibenclamide_Rambiritch2016_PD_full_glucose_profile</h4><p>The steady-state exposure-response curve of Rambiritch V et al., <i>Clinical pharmacology : advances and applications 8:141–153</i> 2016 (<a href=\"https://doi.org/10.2147/CPAA.S102674\">doi:10.2147/CPAA.S102674</a>) — full glucose profile [mmol/L] against glibenclamide mg — obtained by sweeping the driver instead of simulating a dose. Model family: emax.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    =       15.9 mmol/L   drug-free response (baseline) (A0, Q324)
  Emax  =       0.34 mmol/L   maximal effect term (Emax, Q323)
  EC50  =       2.21 mg       exposure at half of the maximal effect term (ED50, Q322)
  gamma = (library default) Hill coefficient</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep\">SigmoidEmaxSweep</a>; this model only supplies the numbers. The x axis is one mg of glibenclamide per second of simulated time (exposure is in kg): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 15.9   (drug-free)
  exposure = EC50 (2.21 mg)  response 15.73
  exposure -> infinity  response 15.56</pre></body></html>"));
end Glibenclamide_Rambiritch2016_PD_full_glucose_profile;
