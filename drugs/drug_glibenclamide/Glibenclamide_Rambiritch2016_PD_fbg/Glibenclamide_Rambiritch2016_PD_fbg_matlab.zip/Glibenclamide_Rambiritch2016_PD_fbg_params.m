function p = Glibenclamide_Rambiritch2016_PD_fbg_params()
% Glibenclamide_Rambiritch2016_PD_fbg_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% glibenclamide Rambiritch_2016::FBG: emax exposure-response sweep (response = E0 + Emax*frac). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one mg per second, in SI inside (kg/m3, s). Response FBG in mmol/L. Driver: glibenclamide (dose_only).
p.E0 = 14.099999999999998;
p.Emax = -0.36999999999999994;
p.EC50 = 4.5599999999999995e-06;
p.gamma = 1.0;
p.slope = 0.0;
p.exposure_per_s = 1e-06;
p.stop_time = 46.0;
p.form = 'E0 + Emax*frac';
end
