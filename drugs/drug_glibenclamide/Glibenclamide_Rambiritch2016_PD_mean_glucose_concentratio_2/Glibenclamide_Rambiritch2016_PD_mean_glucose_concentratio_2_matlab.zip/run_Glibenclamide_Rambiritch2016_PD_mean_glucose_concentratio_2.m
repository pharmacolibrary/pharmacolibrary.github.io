% run_Glibenclamide_Rambiritch2016_PD_mean_glucose_concentratio_2  Evaluate the exposure-response curve and plot response against exposure.
% A sweep is a static map: no ODE solver is needed. exposure runs 0..stop_time*exposure_per_s.
p = Glibenclamide_Rambiritch2016_PD_mean_glucose_concentratio_2_params();
exposure = linspace(0, p.stop_time * p.exposure_per_s, 501);
frac = exposure.^p.gamma ./ (p.EC50^p.gamma + exposure.^p.gamma);
E0 = p.E0; Emax = p.Emax; slope = p.slope;
response = E0 + Emax.*frac;
figure; plot(exposure, response, 'LineWidth', 1.5); grid on;
xlabel('exposure [mg/L]'); ylabel('response [mmol/L]'); title('Glibenclamide_Rambiritch2016_PD_mean_glucose_concentratio_2', 'Interpreter', 'none');
writematrix([exposure(:) response(:)], 'Glibenclamide_Rambiritch2016_PD_mean_glucose_concentratio_2.csv');
