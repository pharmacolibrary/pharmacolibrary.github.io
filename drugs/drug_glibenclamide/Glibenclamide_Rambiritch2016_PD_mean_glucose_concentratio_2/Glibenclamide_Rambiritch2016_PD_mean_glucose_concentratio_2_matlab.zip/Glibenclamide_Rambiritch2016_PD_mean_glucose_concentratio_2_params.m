function p = Glibenclamide_Rambiritch2016_PD_mean_glucose_concentratio_2_params()
% Glibenclamide_Rambiritch2016_PD_mean_glucose_concentratio_2_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% glibenclamide Rambiritch_2016::mean_glucose_concentration::2: emax exposure-response sweep (response = E0 + Emax*frac). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one mg/L per second, in SI inside (kg/m3, s). Response mean glucose concentration in mmol/L. Driver: glibenclamide (cited_pk).
p.E0 = 16.699999999999996;
p.Emax = -0.33999999999999997;
p.EC50 = 0.03599999999999999;
p.gamma = 1.0;
p.slope = 0.0;
p.exposure_per_s = 0.001;
p.stop_time = 360.0;
p.form = 'E0 + Emax*frac';
end
