model CeftarolineFosamil_Principe2022_reference
  parameter Real Cl_ref = 1.777777777777778e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.02 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.68467,
    adminMass = 0.0012
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About ceftaroline_fosamil</h4><p>Ceftaroline fosamil is a cephalosporin antibiotic used to treat bacterial infections such as community-acquired pneumonia, skin infections, and staphylococcal infections. It is approved and authorised in the European Union, where it is used for these infections.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q409712\">Wikidata Q409712</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>ceftaroline_fosamil</td></tr><tr><td>population:</td><td>review reference</td></tr><tr><td>source_paper:</td><td>Principe_2022</td></tr><tr><td>measured_compound:</td><td>ceftaroline_fosamil</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>ceftaroline_fosamil 684.67 g/mol (drugbank)</td></tr></table><h4>Interpretation flags</h4><ul><li>built from REVIEW reference values (Principe_2022) — secondary source</li><li>volume reported by review</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end CeftarolineFosamil_Principe2022_reference;
