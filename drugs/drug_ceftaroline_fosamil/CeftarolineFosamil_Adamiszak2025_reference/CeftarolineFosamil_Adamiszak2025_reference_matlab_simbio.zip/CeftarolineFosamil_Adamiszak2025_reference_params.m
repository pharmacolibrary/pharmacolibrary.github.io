function p = CeftarolineFosamil_Adamiszak2025_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: ceftaroline_fosamil   source: Adamiszak_2025 / reference   route: iv_bolus
  % estimated (absent from source): F
  p.name  = 'CeftarolineFosamil_Adamiszak2025_reference_params';
  p.drug  = 'ceftaroline_fosamil';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'iv_bolus';        % 'oral' | 'iv_bolus'
  p.depot = false;             % oral -> first-order absorption depot
  p.Vc = 21.26;                % central volume [L]
  p.CL = 10.27;                % clearance [L/h]
  p.Vp = [7.82];             % peripheral volumes [L]
  p.Q  = [8.51];             % inter-compartmental clearances [L/h]
  p.ka = 0.0;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 400.0;             % dose [mg]
end
