function p = Cabotegravir_Renou2026_thoueille_et_al_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: cabotegravir   source: Renou_2026 / thoueille_et_al   route: oral
  p.name  = 'Cabotegravir_Renou2026_thoueille_et_al_params';
  p.drug  = 'cabotegravir';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 7.44;                % central volume [L]
  p.CL = 0.201;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 1.12;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 600.0;             % dose [mg]
end
