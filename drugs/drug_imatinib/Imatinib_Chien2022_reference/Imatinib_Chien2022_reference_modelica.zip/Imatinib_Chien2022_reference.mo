model Imatinib_Chien2022_reference
  parameter Real Cl_ref = 3.6666666666666666e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.17200000000000001 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.4936027,
    adminMass = 0.0004,
    ka = 0.0003388888888888889,
    Tlag = 0.0,
    k12 = 6.056201550387597e-06,
    k21 = 2.3891437308868502e-05
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About imatinib</h4><p>Imatinib is a tyrosine-kinase inhibitor used to treat several cancers, including chronic myeloid leukemia, gastrointestinal stromal tumors, dermatofibrosarcoma protuberans, and other leukemias. It is widely used and appears on the WHO list of essential medicines, with several products authorised in the European Union for these conditions.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q177094\">Wikidata Q177094</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>imatinib</td></tr><tr><td>population:</td><td>healthy volunteers</td></tr><tr><td>source_paper:</td><td>Chien_2022</td></tr><tr><td>measured_compound:</td><td>imatinib</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>Tab2</td></tr><tr><td>input:</td><td>PK_2C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>imatinib 493.603 g/mol (drugbank)</td></tr></table><p><b>Defaulted (base-class default used):</b> Tlag.</p><h4>Interpretation flags</h4><ul><li>column 'p value (paired t test)' classified 'other' by the LLM but kept: the deterministic diagnostic-column test disagrees (a stratum column is a value column, not a statistic)</li><li>column 'p value (paired t test)' classified 'other' by the LLM but kept: the deterministic diagnostic-column test disagrees (a stratum column is a value column, not a statistic)</li><li>routed 'Prop error (%)' → Q316 (prop_error) to residual_error — variability estimate, not a structural parameter</li><li>dropped unlinked row (NIL): 'x̅G (RSDG)' — extend the ontology if this is a real PK parameter (source ['Chien_2022_table_3:row0:col5'])</li><li>dropped unlinked row (NIL): 'x̃(IQR)' — extend the ontology if this is a real PK parameter (source ['Chien_2022_table_3:row4:col5'])</li><li>apparent-ness (ontology-grounded): parameterization=apparent, measured_compound=imatinib</li><li>skipped review gap-fill of TLAG: primary's parameterization (rate-constant / ka-only) does not use it</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 172800, Tolerance = 1e-9, Interval = 1));
end Imatinib_Chien2022_reference;
