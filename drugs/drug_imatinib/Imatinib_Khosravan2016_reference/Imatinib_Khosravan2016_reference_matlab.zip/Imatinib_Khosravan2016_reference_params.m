function p = Imatinib_Khosravan2016_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: imatinib   source: Khosravan_2016 / reference   route: oral
  p.name  = 'Imatinib_Khosravan2016_reference_params';
  p.drug  = 'imatinib';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 2700.0;                % central volume [L]
  p.CL = 34.1;                % clearance [L/h]
  p.Vp = [774.0];             % peripheral volumes [L]
  p.Q  = [0.688];             % inter-compartmental clearances [L/h]
  p.ka = 0.126;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.527;             % absorption lag [h]
  p.dose = 400.0;             % dose [mg]
end
