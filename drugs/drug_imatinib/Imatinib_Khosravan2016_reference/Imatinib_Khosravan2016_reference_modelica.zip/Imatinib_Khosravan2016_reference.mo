model Imatinib_Khosravan2016_reference
  parameter Real Cl_ref = 9.472222222222223e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 2.7 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.4936027,
    adminMass = 0.0004,
    ka = 3.5e-05,
    Tlag = 1897.2,
    k12 = 7.078189300411522e-08,
    k21 = 2.4691358024691354e-07
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About imatinib</h4><p>Imatinib is a tyrosine-kinase inhibitor used to treat several cancers, including chronic myeloid leukemia, gastrointestinal stromal tumors, dermatofibrosarcoma protuberans, and other leukemias. It is widely used and appears on the WHO list of essential medicines, with several products authorised in the European Union for these conditions.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q177094\">Wikidata Q177094</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>imatinib</td></tr><tr><td>population:</td><td>review reference</td></tr><tr><td>source_paper:</td><td>Khosravan_2016</td></tr><tr><td>measured_compound:</td><td>imatinib</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_2C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>imatinib 493.603 g/mol (drugbank)</td></tr></table><h4>Interpretation flags</h4><ul><li>built from REVIEW reference values (Khosravan_2016) — secondary source</li><li>volume reported by review</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 1123200, Tolerance = 1e-9, Interval = 1));
end Imatinib_Khosravan2016_reference;
