model Propylthiouracil_Gwka2018_reference
  parameter Real Cl_ref = 3.75e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.0235 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.170232,
    adminMass = 5e-05,
    ka = 0.0001388888888888889,
    Tlag = 576.0
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About propylthiouracil</h4><p>Propylthiouracil is an antithyroid medicine used to treat hyperthyroidism, goiter, and thyroid crisis. It remains an approved antithyroid drug, though it carries a boxed warning, meaning its use requires careful monitoring.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q377342\">Wikidata Q377342</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>propylthiouracil</td></tr><tr><td>population:</td><td>healthy subjects</td></tr><tr><td>source_paper:</td><td>Główka_2018</td></tr><tr><td>measured_compound:</td><td>propylthiouracil</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>table 3</td></tr><tr><td>input:</td><td>PK_1C_enteral: apparent (/F) parameterization ⇒ extravascular dosing</td></tr><tr><td>molar_masses:</td><td>propylthiouracil 170.232 g/mol (drugbank)</td></tr></table><p><b>Defaulted (base-class default used):</b> ka.</p><h4>Interpretation flags</h4><ul><li>apparent-ness (ontology-grounded): parameterization=apparent, measured_compound=propylthiouracil</li><li>1C volume normalization: Q290→Q76 (single-compartment model has no central/peripheral split; 'V_C/f [l]' is the general volume)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Propylthiouracil_Gwka2018_reference;
