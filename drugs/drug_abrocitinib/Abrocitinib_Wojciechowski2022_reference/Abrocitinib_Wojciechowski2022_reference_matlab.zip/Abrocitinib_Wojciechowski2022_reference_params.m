function p = Abrocitinib_Wojciechowski2022_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: abrocitinib   source: Wojciechowski_2022 / reference   route: oral
  % estimated (absent from source): F
  p.name  = 'Abrocitinib_Wojciechowski2022_reference_params';
  p.drug  = 'abrocitinib';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 86.3;                % central volume [L]
  p.CL = 21.7;                % clearance [L/h]
  p.Vp = [8.11];             % peripheral volumes [L]
  p.Q  = [1.13];             % inter-compartmental clearances [L/h]
  p.ka = 3.99;                % absorption rate [1/h]
  p.F  = 0.9;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 200.0;             % dose [mg]
end
