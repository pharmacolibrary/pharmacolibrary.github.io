model Abrocitinib_Wojciechowski2022_reference
  parameter Real Cl_ref = 6.027777777777778e-06 "Cl [m3/s]";
  parameter Real cov_hepatic_0 = 0 "hepatic covariate";
  parameter Real cov_sex_1 = 0 "sex covariate";
  parameter Real Vd_ref = 0.0863 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C_enteral(
    weight = 70.0,
    F = 0.9,
    Cl = Cl_ref*(1 + (1.36)*cov_hepatic_0)*(1 + (0.348)*cov_sex_1),
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.32342000000000004,
    adminMass = 0.0002,
    ka = 0.0011083333333333333,
    Tlag = 0.0,
    k12 = 3.6371829535213077e-06,
    k21 = 3.8703932045485684e-05
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About abrocitinib</h4><p>Abrocitinib is a protein kinase inhibitor used to treat atopic dermatitis. It is authorised in the European Union as a dermatological medicine for dermatitis and is in approved use.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q76656815\">Wikidata Q76656815</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>abrocitinib</td></tr><tr><td>population:</td><td>healthy individuals and patients with psoriasis or atopic dermatitis</td></tr><tr><td>source_paper:</td><td>Wojciechowski_2022</td></tr><tr><td>measured_compound:</td><td>abrocitinib</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>Tab2</td></tr><tr><td>input:</td><td>PK_2C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>abrocitinib 323.42 g/mol (drugbank)</td></tr></table><p><b>Defaulted (base-class default used):</b> F, Tlag.</p><h4>Interpretation flags</h4><ul><li>table section iiv: 'ωCL, % CV' routed out of structural estimates ('Interindividual variability')</li><li>table section iiv: 'ωCL, % CV' routed out of structural estimates ('Interindividual variability')</li><li>table section iiv: 'ωCL, % CV' routed out of structural estimates ('Interindividual variability')</li><li>table section iiv: 'ωVc, % CV' routed out of structural estimates ('Interindividual variability')</li><li>table section iiv: 'ωVc, % CV' routed out of structural estimates ('Interindividual variability')</li><li>table section iiv: 'ωVc, % CV' routed out of structural estimates ('Interindividual variability')</li><li>table section covariance: 'ρCL-Vc' routed out of structural estimates ('Correlation')</li><li>table section covariance: 'ρCL-Vc' routed out of structural estimates ('Correlation')</li><li>dropped unlinked row (NIL): 'Objective function value' — extend the ontology if this is a real PK parameter (source ['Tab2:row1:col1'])</li><li>dropped unlinked row (NIL): 'Condition numbera' — extend the ontology if this is a real PK parameter (source ['Tab2:row2:col1'])</li><li>dropped unlinked row (NIL): 'AK1, mg' — extend the ontology if this is a real PK parameter (source ['Tab2:row9:col1', 'Tab2:row9:col3'])</li><li>dropped unlinked row (NIL): 'Effect of tablet formulations on ALAG1' — extend the ontology if this is a real PK parameter (source ['Tab2:row15:col1', 'Tab2:row15:col3'])</li><li>dropped duplicate Q22 ('Effect of rifampin on CL', value '0.24') — already have one for this compound</li><li>dropped unlinked row (NIL): 'Effect of suspension on Ak1' — extend the ontology if this is a real PK parameter (source ['Tab2:row24:col1', 'Tab2:row24:col3'])</li><li>dropped unlinked row (NIL): 'Effect of multiple dosing on F' — extend the ontology if this is a real PK parameter (source ['Tab2:row26:col1', 'Tab2:row26:col3'])</li><li>dropped unlinked row (NIL): 'Rate of change in CL with respect to time (half-life), h' — extend the ontology if this is a real PK parameter (source ['Tab2:row28:col1', 'Tab2:row28:col3'])</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Abrocitinib_Wojciechowski2022_reference;
