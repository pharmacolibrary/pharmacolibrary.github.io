function p = Abrocitinib_Wojciechowski2022v2_PD_circ_params()
% Abrocitinib_Wojciechowski2022v2_PD_circ_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% abrocitinib Wojciechowski_2022_2::CIRC: sigmoid_emax exposure-response sweep (response = E0 + Emax*frac). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one ng/mL per second, in SI inside (kg/m3, s). Response CIRC in × 1000/μL. Driver: abrocitinib (cited_pk).
p.E0 = 270.0;
p.Emax = -0.109;
p.EC50 = 5.5299999999999996e-05;
p.gamma = 0.232;
p.slope = 0.0;
p.exposure_per_s = 1e-06;
p.stop_time = 560.0;
p.form = 'E0 + Emax*frac';
end
