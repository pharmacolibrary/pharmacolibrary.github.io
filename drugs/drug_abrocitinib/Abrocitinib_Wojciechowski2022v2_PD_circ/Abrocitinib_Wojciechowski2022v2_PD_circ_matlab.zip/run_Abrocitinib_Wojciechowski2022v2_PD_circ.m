% run_Abrocitinib_Wojciechowski2022v2_PD_circ  Evaluate the exposure-response curve and plot response against exposure.
% A sweep is a static map: no ODE solver is needed. exposure runs 0..stop_time*exposure_per_s.
p = Abrocitinib_Wojciechowski2022v2_PD_circ_params();
exposure = linspace(0, p.stop_time * p.exposure_per_s, 501);
frac = exposure.^p.gamma ./ (p.EC50^p.gamma + exposure.^p.gamma);
E0 = p.E0; Emax = p.Emax; slope = p.slope;
response = E0 + Emax.*frac;
figure; plot(exposure, response, 'LineWidth', 1.5); grid on;
xlabel('exposure [ng/mL]'); ylabel('response [× 1000/μL]'); title('Abrocitinib_Wojciechowski2022v2_PD_circ', 'Interpreter', 'none');
writematrix([exposure(:) response(:)], 'Abrocitinib_Wojciechowski2022v2_PD_circ.csv');
