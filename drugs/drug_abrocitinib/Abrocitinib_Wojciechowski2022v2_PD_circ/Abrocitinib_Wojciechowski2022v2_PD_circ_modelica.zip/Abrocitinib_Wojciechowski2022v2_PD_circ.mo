model Abrocitinib_Wojciechowski2022v2_PD_circ
  "sigmoid_emax exposure-response sweep — Wojciechowski_2022_2 :: CIRC (platelet count)"
  extends Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep(
    E0 = 270,      // [× 1000/μL]
    Emax = -0.109,  // [× 1000/μL]
    EC50 = 5.53e-05,  // [kg/m3; ng/mL × 1e-06]
    gamma = 0.232,
    exposure_per_s = 1e-06);   // 1 ng/mL per second
  // family_inferred: the record's model family is disease_progression; read from the parameters: Emax/Imax, EC50/IC50 and a Hill coefficient — sigmoid Emax
  // imax_as_negative_emax: Imax (Q323) enters SigmoidEmaxSweep as −Emax
  annotation(experiment(StartTime = 0, StopTime = 560, Interval = 1.12),
    Documentation(info = "<html><body><!-- drug-about --><h4>About abrocitinib</h4><p>Abrocitinib is a protein kinase inhibitor used to treat atopic dermatitis. It is authorised in the European Union as a dermatological medicine for dermatitis and is in approved use.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q76656815\">Wikidata Q76656815</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h4>Abrocitinib_Wojciechowski2022v2_PD_circ</h4><p>The steady-state exposure-response curve of Wojciechowski J et al., <i>British journal of clinical pharmacology 88(8):3856–3871</i> 2022 (<a href=\"https://doi.org/10.1111/bcp.15334\">doi:10.1111/bcp.15334</a>) — platelet count [× 1000/μL] against abrocitinib ng/mL — obtained by sweeping the driver instead of simulating a dose. Model family: sigmoid_emax.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    =        270 × 1000/μL drug-free response (baseline) (Baseline platelet count, Q324)
  Emax  =      0.109 × 1000/μL maximal effect term (Maximum drug effect on platelet proliferation, Q323)
  EC50  =       55.3 ng/mL    exposure at half of the maximal effect term (Concentration at 50% of maximum drug effect, Q321)
  gamma =      0.232          Hill coefficient (Feedback exponent, Q325)</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep\">SigmoidEmaxSweep</a>; this model only supplies the numbers. The x axis is one ng/mL of abrocitinib per second of simulated time (exposure is in kg/m3): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 270   (drug-free)
  exposure = EC50 (55.3 ng/mL)  response 269.9
  exposure -> infinity  response 269.9</pre></body></html>"));
end Abrocitinib_Wojciechowski2022v2_PD_circ;
