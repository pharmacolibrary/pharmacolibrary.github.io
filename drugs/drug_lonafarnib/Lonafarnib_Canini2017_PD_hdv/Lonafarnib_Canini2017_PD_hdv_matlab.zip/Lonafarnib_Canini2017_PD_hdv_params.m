function p = Lonafarnib_Canini2017_PD_hdv_params()
% Lonafarnib_Canini2017_PD_hdv_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% lonafarnib Canini_2017::HDV: sigmoid_emax exposure-response sweep (response = E0 + Emax*frac). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one ng/mL per second, in SI inside (kg/m3, s). Response HDV in its own unit. Driver: lonafarnib (pk_record).
p.E0 = 0.0;
p.Emax = -1.0;
p.EC50 = 0.000227;
p.gamma = 1.48;
p.slope = 0.0;
p.exposure_per_s = 1e-06;
p.stop_time = 2300.0;
p.form = 'E0 + Emax*frac';
end
