model Lonafarnib_Canini2017_PD_hdv
  "sigmoid_emax exposure-response sweep — Canini_2017 :: HDV (HDV production)"
  extends Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep(
    E0 = 0,      // [1]
    Emax = -1,  // [1]
    EC50 = 0.000227,  // [kg/m3; ng/mL × 1e-06]
    gamma = 1.48,
    exposure_per_s = 1e-06);   // 1 ng/mL per second
  // imax_as_negative_emax: Imax (Q323) enters SigmoidEmaxSweep as −Emax
  // defaulted: E0
  annotation(experiment(StartTime = 0, StopTime = 2300, Interval = 4.6),
    Documentation(info = "<html><body><!-- drug-about --><h4>About lonafarnib</h4><p>Lonafarnib is a farnesyltransferase enzyme inhibitor used to treat progeria and certain laminopathies. It is an approved medicine, authorised in the European Union.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q3258910\">Wikidata Q3258910</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h4>Lonafarnib_Canini2017_PD_hdv</h4><p>The steady-state exposure-response curve of Canini L et al., <i>Hepatology communications 1(4):288–292</i> 2017 (<a href=\"https://doi.org/10.1002/hep4.1043\">doi:10.1002/hep4.1043</a>) — HDV production against lonafarnib ng/mL — obtained by sweeping the driver instead of simulating a dose. Model family: sigmoid_emax.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = (library default) drug-free response (baseline)
  Emax  =          1          maximal effect term (Maximal effectiveness, Q323)
  EC50  =        227 ng/mL    exposure at half of the maximal effect term (LNF concentration leading to 50% of effectiveness, Q322)
  gamma =       1.48          Hill coefficient (Hill factor, Q325)</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep\">SigmoidEmaxSweep</a>; this model only supplies the numbers. The x axis is one ng/mL of lonafarnib per second of simulated time (exposure is in kg/m3): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0   (drug-free)
  exposure = EC50 (227 ng/mL)  response -0.5
  exposure -> infinity  response -1</pre></body></html>"));
end Lonafarnib_Canini2017_PD_hdv;
