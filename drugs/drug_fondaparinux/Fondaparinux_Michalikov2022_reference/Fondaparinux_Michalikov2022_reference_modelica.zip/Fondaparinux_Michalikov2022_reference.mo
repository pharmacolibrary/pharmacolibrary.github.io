model Fondaparinux_Michalikov2022_reference
  parameter Real Cl_ref = 1.4691666666666668e-08 "Cl [m3/s]";
  parameter Real Vd_ref = 0.00555 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 1.508263,
    adminMass = 2.5e-06
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About fondaparinux</h4><p>Fondaparinux is an antithrombotic drug used to treat and prevent blood clots, including pulmonary embolism, thrombosis, thrombophlebitis, and phlebitis. It is an approved antithrombotic, classified among other antithrombotic agents, and has also been studied investigationally.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q27077698\">Wikidata Q27077698</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>fondaparinux</td></tr><tr><td>population:</td><td>dialysis-dependent chronic kidney disease patients</td></tr><tr><td>source_paper:</td><td>Michaličková_2022</td></tr><tr><td>measured_compound:</td><td>fondaparinux</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>fondaparinux 1508.26 g/mol (drugbank)</td></tr></table><h4>Interpretation flags</h4><ul><li>unit_dimension_unknown: 'times' (CL)</li><li>dropped duplicate Q22 ('CL of fondaparinux', value 2.26) — already have one for this compound</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=fondaparinux</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 1382400, Tolerance = 1e-9, Interval = 1));
end Fondaparinux_Michalikov2022_reference;
