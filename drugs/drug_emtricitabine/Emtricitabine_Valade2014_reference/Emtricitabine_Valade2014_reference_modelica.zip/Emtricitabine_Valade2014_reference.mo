model Emtricitabine_Valade2014_reference
  parameter Real Cl_ref = 4.194444444444445e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.0423 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.24724700000000002,
    adminMass = 0.0002,
    ka = 0.0008611111111111111,
    Tlag = 1879.2
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About emtricitabine</h4><p>Emtricitabine is an antiretroviral medicine used to treat HIV infection, working as a nucleoside reverse transcriptase inhibitor. It is widely used and is on the WHO list of essential medicines; it is authorised in the European Union for HIV infections and is also available in fixed-dose combination products.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q422604\">Wikidata Q422604</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>emtricitabine</td></tr><tr><td>population:</td><td>HIV-1-infected adult patients</td></tr><tr><td>source_paper:</td><td>Valade_2014</td></tr><tr><td>measured_compound:</td><td>emtricitabine</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>emtricitabine 247.247 g/mol (drugbank)</td></tr></table><h4>Interpretation flags</h4><ul><li>dropped duplicate Q19 ('median AUC0-48', value 17.2) — already have one for this compound</li><li>apparent-ness (ontology-grounded): parameterization=apparent, measured_compound=emtricitabine</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li><li>gap-filled Q49 (kabs) from Tanaudommongkon_2022's review values (primary lacked it)</li><li>gap-filled Q83 (tlag) from Tanaudommongkon_2022's review values (primary lacked it)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Emtricitabine_Valade2014_reference;
