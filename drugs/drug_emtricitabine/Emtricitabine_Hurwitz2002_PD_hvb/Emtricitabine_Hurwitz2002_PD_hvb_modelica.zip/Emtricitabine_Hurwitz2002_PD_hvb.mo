model Emtricitabine_Hurwitz2002_PD_hvb
  "indirect_response_i exposure-response sweep — Hurwitz_2002 :: HVB (serum virus load)"
  extends Pharmacolibrary.Interfaces.PartialExposureResponseSweep(
    E0 = 0,      // [1]
    Emax = 1,  // type I effect term
    EC50 = 1.5,  // [microM]
    gamma = 3.46,
    exposure_per_s = 1);   // 1 microM per second
equation
  response = E0*(1 - Emax*frac);   // steady state, indirect response type I
  // exposure_unit_unresolved: 'microM' — the x axis is in the paper's unit, not SI
  // defaulted: E0
  // defaulted: Emax
  annotation(experiment(StartTime = 0, StopTime = 15, Interval = 0.03),
    Documentation(info = "<html><body><!-- drug-about --><h4>About emtricitabine</h4><p>Emtricitabine is an antiretroviral medicine used to treat HIV infection, working as a nucleoside reverse transcriptase inhibitor. It is widely used and is on the WHO list of essential medicines; it is authorised in the European Union for HIV infections and is also available in fixed-dose combination products.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q422604\">Wikidata Q422604</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h4>Emtricitabine_Hurwitz2002_PD_hvb</h4><p>The steady-state exposure-response curve of Hurwitz SJ et al., <i>Antiviral chemistry &amp; chemotherapy 13(3):165–176</i> 2002 (<a href=\"https://doi.org/10.1177/095632020201300303\">doi:10.1177/095632020201300303</a>) — serum virus load against emtricitabine triphosphate microM — obtained by sweeping the driver instead of simulating a dose. Model family: indirect_response_i.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = (library default) drug-free response (baseline)
  Emax  = (library default) maximal effect term
  EC50  =        1.5 microM   exposure at half of the maximal effect term (IC50, Q322)
  gamma =       3.46          Hill coefficient (concentration exponent eta, Q325)</pre><p>The algebra is <code>response = E0*(1 - Emax*frac)</code>; this model only supplies the numbers. The x axis is one microM of emtricitabine triphosphate per second of simulated time: there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0   (drug-free)
  exposure = EC50 (1.5 microM)  response 0
  exposure -> infinity  response 0</pre></body></html>"));
end Emtricitabine_Hurwitz2002_PD_hvb;
