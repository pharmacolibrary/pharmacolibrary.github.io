function p = Emtricitabine_Hurwitz2002_PD_hvb_params()
% Emtricitabine_Hurwitz2002_PD_hvb_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% emtricitabine Hurwitz_2002::HVB: indirect_response_i exposure-response sweep (response = E0*(1 - Emax*frac)). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one microM per second, in SI inside (kg/m3, s). Response HVB in its own unit. Driver: emtricitabine triphosphate (not_resolved).
p.E0 = 0.0;
p.Emax = 1.0;
p.EC50 = 1.5;
p.gamma = 3.46;
p.slope = 0.0;
p.exposure_per_s = 1.0;
p.stop_time = 15.0;
p.form = 'E0*(1 - Emax*frac)';
end
