model Quetiapine_Fukushi2020_reference
  parameter Real Cl_ref = 2.4361111111111112e-05 "Cl [m3/s]";
  parameter Real Vd_ref = 0.277 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.383507,
    adminMass = 0.0004,
    ka = 0.0001388888888888889,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About quetiapine</h4><p>Quetiapine is an atypical antipsychotic used for conditions such as schizophrenia, bipolar disorder, and related mental disorders. It is an approved medicine used widely in psychiatric care, though it carries a boxed warning.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q408535\">Wikidata Q408535</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>quetiapine</td></tr><tr><td>population:</td><td>Japanese patients with bipolar depression</td></tr><tr><td>source_paper:</td><td>Fukushi_2020</td></tr><tr><td>measured_compound:</td><td>quetiapine</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>quetiapine 383.507 g/mol (drugbank)</td></tr></table><p><b>Defaulted (base-class default used):</b> Tlag.</p><h4>Interpretation flags</h4><ul><li>routed 'interindividual %CV of apparent oral clearance' → Q312 (IIV) to iiv — variability estimate, not a structural parameter</li><li>routed 'interindividual %CV of apparent volume of distribution' → Q312 (IIV) to iiv — variability estimate, not a structural parameter</li><li>dropped value-less row: 'γ-glutamyl transpeptidase on apparent oral clearance'</li><li>dropped value-less row: 'body weight on apparent volume of distribution'</li><li>apparent-ness (ontology-grounded): parameterization=apparent, measured_compound=quetiapine</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li><li>gap-filled Q49 (kabs) from Li_2026's review values (primary lacked it)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Quetiapine_Fukushi2020_reference;
