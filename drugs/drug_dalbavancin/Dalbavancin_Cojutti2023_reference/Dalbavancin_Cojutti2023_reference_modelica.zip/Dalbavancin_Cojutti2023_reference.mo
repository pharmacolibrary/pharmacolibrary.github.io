model Dalbavancin_Cojutti2023_reference
  parameter Real Cl_ref = 2.9444444444444446e-08 "Cl [m3/s]";
  parameter Real Vd_ref = 0.0364 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 1.81671,
    adminMass = 0.0015
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About dalbavancin</h4><p>Dalbavancin is a lipoglycopeptide antibiotic used to treat bacterial skin and soft tissue infections such as cellulitis, including infections caused by MRSA. It is approved and authorised in the European Union, where it is used for these infections.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q5210237\">Wikidata Q5210237</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>dalbavancin</td></tr><tr><td>population:</td><td>adult patients with staphylococcal osteoarticular infections</td></tr><tr><td>source_paper:</td><td>Cojutti_2023</td></tr><tr><td>measured_compound:</td><td>dalbavancin</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>dalbavancin 1816.71 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=dalbavancin</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 4838400, Tolerance = 1e-9, Interval = 1));
end Dalbavancin_Cojutti2023_reference;
