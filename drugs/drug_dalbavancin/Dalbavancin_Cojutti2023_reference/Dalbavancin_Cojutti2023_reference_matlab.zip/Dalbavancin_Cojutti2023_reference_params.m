function p = Dalbavancin_Cojutti2023_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: dalbavancin   source: Cojutti_2023 / reference   route: iv_bolus
  % estimated (absent from source): F
  % Vc is the record's Vss — no central volume was reported; 1-compartment reading
  p.name  = 'Dalbavancin_Cojutti2023_reference_params';
  p.drug  = 'dalbavancin';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'iv_bolus';        % 'oral' | 'iv_bolus'
  p.depot = false;             % oral -> first-order absorption depot
  p.Vc = 36.4;                % central volume [L]
  p.CL = 0.106;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.0;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 1500.0;             % dose [mg]
end
