model Dalbavancin_Baiardi2025_reference
  parameter Real Cl_ref = 7.583333333333333e-09 "Cl [m3/s]";
  parameter Real Vd_ref = 0.0036000000000000003 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 1.81671,
    adminMass = 0.0015,
    k12 = 1.7361111111111108e-06,
    k21 = 9.765624999999998e-07
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About dalbavancin</h4><p>Dalbavancin is a lipoglycopeptide antibiotic used to treat bacterial skin and soft tissue infections such as cellulitis, including infections caused by MRSA. It is approved and authorised in the European Union, where it is used for these infections.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q5210237\">Wikidata Q5210237</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>dalbavancin</td></tr><tr><td>population:</td><td>adult patients with renal function CLcr > 30 mL/min</td></tr><tr><td>source_paper:</td><td>Baiardi_2025</td></tr><tr><td>measured_compound:</td><td>dalbavancin</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>antibiotics-14-00190-t002</td></tr><tr><td>input:</td><td>PK_2C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>dalbavancin 1816.71 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>table section residual_error: 'b' routed out of structural estimates ('Residual Variability')</li><li>table section residual_error: 'b' routed out of structural estimates ('Residual Variability')</li><li>table section residual_error: 'b' routed out of structural estimates ('Residual Variability')</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=dalbavancin</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 1728000, Tolerance = 1e-9, Interval = 1));
end Dalbavancin_Baiardi2025_reference;
