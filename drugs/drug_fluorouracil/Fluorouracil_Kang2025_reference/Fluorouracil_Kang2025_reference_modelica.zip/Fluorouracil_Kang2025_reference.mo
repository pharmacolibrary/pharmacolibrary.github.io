model Fluorouracil_Kang2025_reference
  parameter Real Cl_ref = 6.3888888888888885e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.383 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.1300772,
    adminMass = 0.0001,
    ka = 0.0004416666666666667,
    Tlag = 0.0,
    k12 = 9.573542210617928e-05,
    k21 = 7.064868336544636e-05
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About fluorouracil</h4><p>Fluorouracil is an antimetabolite anticancer drug used to treat many cancers, including breast, stomach, colon, pancreatic, head and neck, and skin cancers, as well as actinic keratosis and basal-cell carcinoma of the skin. It is an approved medicine and is listed among WHO essential medicines, so it is widely used in cancer care worldwide.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q238512\">Wikidata Q238512</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>fluorouracil</td></tr><tr><td>population:</td><td>review reference</td></tr><tr><td>source_paper:</td><td>Kang_2025</td></tr><tr><td>measured_compound:</td><td>fluorouracil</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_2C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>fluorouracil 130.077 g/mol (drugbank)</td></tr></table><p><b>Defaulted (base-class default used):</b> Tlag.</p><h4>Interpretation flags</h4><ul><li>built from REVIEW reference values (Kang_2025) — secondary source</li><li>volume reported by review</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 259200, Tolerance = 1e-9, Interval = 1));
end Fluorouracil_Kang2025_reference;
