function p = Fluorouracil_Pierik2024_PD_v_params()
% Fluorouracil_Pierik2024_PD_v_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% fluorouracil Pierik_2024::V: sigmoid_emax exposure-response sweep (response = E0 + Emax*frac). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one SI per second, in SI inside (kg/m3, s). Response V in its own unit. Driver: 5-fluorouracil (cited_pk).
p.E0 = 1.0;
p.Emax = -1.0;
p.EC50 = 20.0;
p.gamma = 10.0;
p.slope = 0.0;
p.exposure_per_s = 1.0;
p.stop_time = 200.0;
p.form = 'E0 + Emax*frac';
end
