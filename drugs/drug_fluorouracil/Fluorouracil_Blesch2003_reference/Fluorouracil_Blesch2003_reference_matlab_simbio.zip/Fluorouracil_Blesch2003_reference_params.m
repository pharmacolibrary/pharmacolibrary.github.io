function p = Fluorouracil_Blesch2003_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: fluorouracil   source: Blesch_2003 / reference   route: iv_bolus
  % estimated (absent from source): F
  p.name  = 'Fluorouracil_Blesch2003_reference_params';
  p.drug  = 'fluorouracil';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'iv_bolus';        % 'oral' | 'iv_bolus'
  p.depot = false;             % oral -> first-order absorption depot
  p.Vc = 90.6;                % central volume [L]
  p.CL = 75.8;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.0;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.000552;             % absorption lag [h]
  p.dose = 1000.0;             % dose [mg]
end
