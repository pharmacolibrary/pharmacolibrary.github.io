model Levamisole_KreeftmeijerVegter2015_reference
  parameter Real Cl_ref = 0.0008555555555555555 "Cl [m3/s]";
  parameter Real Vd_ref = 16.52 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.204291,
    adminMass = 0.00015,
    ka = 0.00022222222222222223,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About levamisole</h4><p>Levamisole is an antinematodal drug used to treat worm infections and has also been used for benign colonic tumours. It is a WHO essential medicine and is also approved for veterinary use, though some uses have been withdrawn.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q417097\">Wikidata Q417097</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>levamisole</td></tr><tr><td>population:</td><td>children with steroid-sensitive nephrotic syndrome</td></tr><tr><td>source_paper:</td><td>Kreeftmeijer-Vegter_2015</td></tr><tr><td>measured_compound:</td><td>levamisole</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>levamisole 204.291 g/mol (drugbank)</td></tr></table><p><b>Defaulted (base-class default used):</b> Tlag.</p><h4>Interpretation flags</h4><ul><li>routed 'estimated interindividual variability' → Q312 (IIV) to iiv — variability estimate, not a structural parameter</li><li>dropped unlinked row (NIL): 'proportional effect of age on CL/F' — extend the ontology if this is a real PK parameter (source ['Kreeftmeijer-Vegter_2015:abstract'])</li><li>apparent-ness (ontology-grounded): parameterization=apparent, measured_compound=levamisole</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li><li>gap-filled Q49 (kabs) from Veltkamp_2024's review values (primary lacked it)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Levamisole_KreeftmeijerVegter2015_reference;
