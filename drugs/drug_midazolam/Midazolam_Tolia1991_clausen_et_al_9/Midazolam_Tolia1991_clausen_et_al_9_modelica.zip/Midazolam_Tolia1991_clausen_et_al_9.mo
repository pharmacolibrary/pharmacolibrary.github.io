model Midazolam_Tolia1991_clausen_et_al_9
  parameter Real Cl_ref = 7.000000000000001e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.077 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.325767,
    adminMass = 7e-06
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>midazolam</td></tr><tr><td>population:</td><td>children undergoing esophagogastroduodenoscopy</td></tr><tr><td>source_paper:</td><td>Tolia_1991</td></tr><tr><td>measured_compound:</td><td>midazolam</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>midazolam 325.767 g/mol (drugbank)</td></tr></table><h4>Interpretation flags</h4><ul><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=midazolam</li><li>population split: 'clausen et al.9 †' subgroup of Tolia_1991 (paper reports 5 populations: clausen et al.9 †, payne et al. 6 *, pentikäinen et al. 9 †, present study*, salonen et al.5 *)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Midazolam_Tolia1991_clausen_et_al_9;
