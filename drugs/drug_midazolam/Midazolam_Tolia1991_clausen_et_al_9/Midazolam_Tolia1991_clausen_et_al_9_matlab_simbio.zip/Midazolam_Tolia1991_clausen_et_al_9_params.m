function p = Midazolam_Tolia1991_clausen_et_al_9_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: midazolam   source: Tolia_1991 / clausen_et_al_9   route: oral
  % estimated (absent from source): F
  p.name  = 'Midazolam_Tolia1991_clausen_et_al_9_params';
  p.drug  = 'midazolam';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 77.0;                % central volume [L]
  p.CL = 25.2;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 1.77;                % absorption rate [1/h]
  p.F  = 0.9;                 % bioavailability [0-1]
  p.Tlag = 1.23;             % absorption lag [h]
  p.dose = 7.0;             % dose [mg]
end
