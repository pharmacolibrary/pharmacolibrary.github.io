model Midazolam_Breimer1991_PD_tnw_12_30
  "sigmoid_emax exposure-response sweep — Breimer_1991 :: TNW 12-30 (TNW 12-30)"
  extends Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep(
    E0 = 0.7,      // [Hz]
    Emax = 8.3,  // [Hz]
    EC50 = 0.000276,  // [kg/m3; µg/L × 1e-06]
    gamma = 3.9,
    exposure_per_s = 1e-06);   // 1 µg/L per second
  annotation(experiment(StartTime = 0, StopTime = 2800, Interval = 5.6),
    Documentation(info = "<html><body><!-- drug-about --><h4>About midazolam</h4><p>Midazolam is a benzodiazepine sedative used for conscious sedation, anesthesia, and to treat severe seizures such as status epilepticus. It is an authorised medicine in the European Union and is included on the WHO essential medicines list, so it is widely used.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q423071\">Wikidata Q423071</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h4>Midazolam_Breimer1991_PD_tnw_12_30</h4><p>The steady-state exposure-response curve of Breimer LT et al., <i>Clinical pharmacokinetics 20(6):497–508</i> 1991 (<a href=\"https://doi.org/10.2165/00003088-199120060-00006\">doi:10.2165/00003088-199120060-00006</a>) — TNW 12-30 [Hz] against midazolam µg/L — obtained by sweeping the driver instead of simulating a dose. Model family: sigmoid_emax.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    =        0.7 Hz       drug-free response (baseline) (Eo, Q324)
  Emax  =        8.3 Hz       maximal effect term (Emax, Q320)
  EC50  =        276 µg/L     exposure at half of the maximal effect term (EC50, Q321)
  gamma =        3.9          Hill coefficient (N, Q325)</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep\">SigmoidEmaxSweep</a>; this model only supplies the numbers. The x axis is one µg/L of midazolam per second of simulated time (exposure is in kg/m3): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0.7   (drug-free)
  exposure = EC50 (276 µg/L)  response 4.85
  exposure -> infinity  response 9</pre></body></html>"));
end Midazolam_Breimer1991_PD_tnw_12_30;
