function p = Midazolam_Breimer1991_PD_tnw_12_30_params()
% Midazolam_Breimer1991_PD_tnw_12_30_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% midazolam Breimer_1991::TNW_12_30: sigmoid_emax exposure-response sweep (response = E0 + Emax*frac). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one µg/L per second, in SI inside (kg/m3, s). Response TNW 12-30 in Hz. Driver: midazolam (cited_pk).
p.E0 = 0.7;
p.Emax = 8.3;
p.EC50 = 0.00027599999999999993;
p.gamma = 3.9;
p.slope = 0.0;
p.exposure_per_s = 1e-06;
p.stop_time = 2800.0;
p.form = 'E0 + Emax*frac';
end
