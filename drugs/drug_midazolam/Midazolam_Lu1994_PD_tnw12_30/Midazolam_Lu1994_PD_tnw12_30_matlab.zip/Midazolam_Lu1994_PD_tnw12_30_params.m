function p = Midazolam_Lu1994_PD_tnw12_30_params()
% Midazolam_Lu1994_PD_tnw12_30_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% midazolam Lu_1994::TNW12_30: sigmoid_emax exposure-response sweep (response = E0 + Emax*frac). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one micrograms.L-1 per second, in SI inside (kg/m3, s). Response TNW12-30 in its own unit. Driver: midazolam (cited_pk).
p.E0 = 3.4;
p.Emax = -11.4;
p.EC50 = 0.00025399999999999994;
p.gamma = 2.9;
p.slope = 0.0;
p.exposure_per_s = 1e-06;
p.stop_time = 2600.0;
p.form = 'E0 + Emax*frac';
end
