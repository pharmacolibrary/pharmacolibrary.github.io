function p = Midazolam_Tolia1991_salonen_et_al_5_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: midazolam   source: Tolia_1991 / salonen_et_al_5   route: oral
  % estimated (absent from source): F
  p.name  = 'Midazolam_Tolia1991_salonen_et_al_5_params';
  p.drug  = 'midazolam';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 98.0;                % central volume [L]
  p.CL = 29.4;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.14;                % absorption rate [1/h]
  p.F  = 0.9;                 % bioavailability [0-1]
  p.Tlag = 0.08;             % absorption lag [h]
  p.dose = 7.0;             % dose [mg]
end
