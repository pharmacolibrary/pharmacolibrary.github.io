function p = Midazolam_FloresPrez2023_PD_bis_params()
% Midazolam_FloresPrez2023_PD_bis_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% midazolam Flores-Pérez_2023::BIS: sigmoid_emax exposure-response sweep (response = E0 + Emax*frac). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one SI per second, in SI inside (kg/m3, s). Response BIS in its own unit. Driver: midazolam (pk_record).
p.E0 = 57.63;
p.Emax = -0.088;
p.EC50 = 13.57;
p.gamma = 1.0;
p.slope = 0.0;
p.exposure_per_s = 1.0;
p.stop_time = 140.0;
p.form = 'E0 + Emax*frac';
end
