model Midazolam_FloresPrez2023_PD_bis
  "sigmoid_emax exposure-response sweep — Flores-Pérez_2023 :: BIS (Bispectral Index Scale (BIS))"
  extends Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep(
    E0 = 57.63,      // [1]
    Emax = -0.088,  // [1]
    EC50 = 1.357e-05,  // [kg/m3; ng/mL × 1e-06]
    gamma = 1,
    exposure_per_s = 1e-06);   // 1 ng/mL per second
  // imax_as_negative_emax: Imax (Q323) enters SigmoidEmaxSweep as −Emax
  // defaulted: gamma
  annotation(experiment(StartTime = 0, StopTime = 140, Interval = 0.28),
    Documentation(info = "<html><body><!-- drug-about --><h4>About midazolam</h4><p>Midazolam is a benzodiazepine sedative used for conscious sedation, anesthesia, and to treat severe seizures such as status epilepticus. It is an authorised medicine in the European Union and is included on the WHO essential medicines list, so it is widely used.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q423071\">Wikidata Q423071</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h4>Midazolam_FloresPrez2023_PD_bis</h4><p>The steady-state exposure-response curve of Flores-Pérez C et al., <i>Pharmaceutics 15(11)</i> 2023 (<a href=\"https://doi.org/10.3390/pharmaceutics15112565\">doi:10.3390/pharmaceutics15112565</a>) — Bispectral Index Scale (BIS) against midazolam ng/mL — obtained by sweeping the driver instead of simulating a dose. Model family: sigmoid_emax.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    =      57.63          drug-free response (baseline) (E0, Q324)
  Emax  =      0.088          maximal effect term (Imax, Q323)
  EC50  =      13.57 ng/mL    exposure at half of the maximal effect term (IC50, Q322)
  gamma = (library default) Hill coefficient</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep\">SigmoidEmaxSweep</a>; this model only supplies the numbers. The x axis is one ng/mL of midazolam per second of simulated time (exposure is in kg/m3): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 57.63   (drug-free)
  exposure = EC50 (13.57 ng/mL)  response 57.59
  exposure -> infinity  response 57.54</pre></body></html>"));
end Midazolam_FloresPrez2023_PD_bis;
