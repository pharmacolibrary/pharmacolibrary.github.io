function p = Midazolam_Seng2014_base_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: midazolam   source: Seng_2014 / base   route: oral
  % estimated (absent from source): F
  p.name  = 'Midazolam_Seng2014_base_params';
  p.drug  = 'midazolam';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 27.2;                % central volume [L]
  p.CL = 13.1;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.14;                % absorption rate [1/h]
  p.F  = 0.9;                 % bioavailability [0-1]
  p.Tlag = 0.08;             % absorption lag [h]
  p.dose = 1.0;             % dose [mg]
end
