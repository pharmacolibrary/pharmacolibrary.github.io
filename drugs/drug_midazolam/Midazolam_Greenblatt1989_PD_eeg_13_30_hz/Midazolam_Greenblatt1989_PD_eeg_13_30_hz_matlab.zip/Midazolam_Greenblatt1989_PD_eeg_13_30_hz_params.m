function p = Midazolam_Greenblatt1989_PD_eeg_13_30_hz_params()
% Midazolam_Greenblatt1989_PD_eeg_13_30_hz_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% midazolam Greenblatt_1989::EEG_13_30_Hz: sigmoid_emax exposure-response sweep (response = E0 + Emax*frac). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one ng/ml per second, in SI inside (kg/m3, s). Response EEG 13-30 Hz in %. Driver: midazolam (pk_record).
p.E0 = 0.0;
p.Emax = 0.214;
p.EC50 = 3.52e-05;
p.gamma = 2.19;
p.slope = 0.0;
p.exposure_per_s = 1e-06;
p.stop_time = 360.0;
p.form = 'E0 + Emax*frac';
end
