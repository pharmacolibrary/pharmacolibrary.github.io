% run_Midazolam_Mandema1991v2_PD_eeg_beta  Evaluate the exposure-response curve and plot response against exposure.
% A sweep is a static map: no ODE solver is needed. exposure runs 0..stop_time*exposure_per_s.
p = Midazolam_Mandema1991v2_PD_eeg_beta_params();
exposure = linspace(0, p.stop_time * p.exposure_per_s, 501);
frac = exposure.^p.gamma ./ (p.EC50^p.gamma + exposure.^p.gamma);
E0 = p.E0; Emax = p.Emax; slope = p.slope;
response = E0 + Emax.*frac;
figure; plot(exposure, response, 'LineWidth', 1.5); grid on;
xlabel('exposure [ngmlP-1]'); ylabel('response [uV s-1]'); title('Midazolam_Mandema1991v2_PD_eeg_beta', 'Interpreter', 'none');
writematrix([exposure(:) response(:)], 'Midazolam_Mandema1991v2_PD_eeg_beta.csv');
