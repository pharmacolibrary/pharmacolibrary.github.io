function p = Midazolam_Mandema1991v2_PD_eeg_beta_params()
% Midazolam_Mandema1991v2_PD_eeg_beta_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% midazolam Mandema_1991_2::EEG_beta: sigmoid_emax exposure-response sweep (response = E0 + Emax*frac). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one ngmlP-1 per second, in SI inside (kg/m3, s). Response EEG beta in uV s-1. Driver: midazolam (cited_pk).
p.E0 = 61.0;
p.Emax = 85.0;
p.EC50 = 40.0;
p.gamma = 0.84;
p.slope = 0.0;
p.exposure_per_s = 1.0;
p.stop_time = 400.0;
p.form = 'E0 + Emax*frac';
end
