model Midazolam_Briassoulis1998_reference
  parameter Real Cl_ref = 1.4816666666666665e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.0952 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.325767,
    adminMass = 1.5e-05
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About midazolam</h4><p>Midazolam is a benzodiazepine sedative used for conscious sedation, anesthesia, and to treat severe seizures such as status epilepticus. It is an authorised medicine in the European Union and is included on the WHO essential medicines list, so it is widely used.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q423071\">Wikidata Q423071</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>midazolam</td></tr><tr><td>population:</td><td>review reference</td></tr><tr><td>source_paper:</td><td>Briassoulis_1998</td></tr><tr><td>measured_compound:</td><td>midazolam</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>midazolam 325.767 g/mol (drugbank)</td></tr></table><h4>Interpretation flags</h4><ul><li>built from REVIEW reference values (Briassoulis_1998) — secondary source</li><li>volume reported by review</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 259200, Tolerance = 1e-9, Interval = 1));
end Midazolam_Briassoulis1998_reference;
