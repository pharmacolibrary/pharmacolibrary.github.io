% Run (SimBiology): build model + dose, simulate 0..24.0 h, plot.
p = Midazolam_Tolia1991_payne_et_al_6_params();
[model, dose, variant] = build_sb_pk(p);
sd = simulate_sb(model, variant, dose, 24.0);
