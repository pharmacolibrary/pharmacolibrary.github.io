model Midazolam_McCann2025_reference
  parameter Real Cl_ref = 4.077777777777778e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.00709 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C_enteral(
    weight = 70.0,
    F = 0.9,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.325767,
    adminMass = 2e-06,
    ka = 3.888888888888889e-05,
    Tlag = 288.0,
    k12 = 0.001751684688920232,
    k21 = 0.00036452728043570424
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About midazolam</h4><p>Midazolam is a benzodiazepine sedative used for conscious sedation, anesthesia, and to treat severe seizures such as status epilepticus. It is an authorised medicine in the European Union and is included on the WHO essential medicines list, so it is widely used.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q423071\">Wikidata Q423071</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>midazolam</td></tr><tr><td>population:</td><td>children with and without obesity</td></tr><tr><td>source_paper:</td><td>McCann_2025</td></tr><tr><td>measured_compound:</td><td>midazolam</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>cts70247-tbl-0002</td></tr><tr><td>input:</td><td>PK_2C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>midazolam 325.767 g/mol (drugbank)</td></tr></table><p><b>Defaulted (base-class default used):</b> F.</p><h4>Interpretation flags</h4><ul><li>table section iiv: 'CL' routed out of structural estimates ('Interindividual variability (%CV)')</li><li>table section iiv: 'CL' routed out of structural estimates ('Interindividual variability (%CV)')</li><li>table section iiv: 'CL' routed out of structural estimates ('Interindividual variability (%CV)')</li><li>table section iiv: 'CL' routed out of structural estimates ('Interindividual variability (%CV)')</li><li>table section residual_error: 'Proportional error (%)' routed out of structural estimates ('Residual error')</li><li>table section residual_error: 'Proportional error (%)' routed out of structural estimates ('Residual error')</li><li>table section residual_error: 'Proportional error (%)' routed out of structural estimates ('Residual error')</li><li>table section residual_error: 'Proportional error (%)' routed out of structural estimates ('Residual error')</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=midazolam</li><li>gap-filled Q49 (kabs) from Jia_2026's review values (primary lacked it)</li><li>gap-filled Q83 (tlag) from Langlois_1987's review values (primary lacked it)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Midazolam_McCann2025_reference;
