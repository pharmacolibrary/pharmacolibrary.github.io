function p = Midazolam_Seng2014_final_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: midazolam   source: Seng_2014 / final   route: oral
  % estimated (absent from source): F
  p.name  = 'Midazolam_Seng2014_final_params';
  p.drug  = 'midazolam';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 27.3;                % central volume [L]
  p.CL = 14.5;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 1.77;                % absorption rate [1/h]
  p.F  = 0.9;                 % bioavailability [0-1]
  p.Tlag = 1.23;             % absorption lag [h]
  p.dose = 1.0;             % dose [mg]
end
