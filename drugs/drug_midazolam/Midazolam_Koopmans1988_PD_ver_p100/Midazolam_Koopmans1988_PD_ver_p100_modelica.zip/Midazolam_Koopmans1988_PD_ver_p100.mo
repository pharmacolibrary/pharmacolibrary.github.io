model Midazolam_Koopmans1988_PD_ver_p100
  "sigmoid_emax exposure-response sweep — Koopmans_1988 :: VER-P100 (VER P-100 latency)"
  extends Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep(
    E0 = 0,      // [1]
    Emax = 0.0118,  // [s; msec × 0.001]
    EC50 = 4.81e-05,  // [kg/m3; ng/ml × 1e-06]
    gamma = 2.9,
    exposure_per_s = 1e-06);   // 1 ng/ml per second
  // defaulted: E0
  annotation(experiment(StartTime = 0, StopTime = 490, Interval = 0.98),
    Documentation(info = "<html><body><!-- drug-about --><h4>About midazolam</h4><p>Midazolam is a benzodiazepine sedative used for conscious sedation, anesthesia, and to treat severe seizures such as status epilepticus. It is an authorised medicine in the European Union and is included on the WHO essential medicines list, so it is widely used.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q423071\">Wikidata Q423071</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h4>Midazolam_Koopmans1988_PD_ver_p100</h4><p>The steady-state exposure-response curve of Koopmans R et al., <i>Clinical pharmacology and therapeutics 44(1):14–22</i> 1988 (<a href=\"https://doi.org/10.1038/clpt.1988.106\">doi:10.1038/clpt.1988.106</a>) — VER P-100 latency [msec] against midazolam ng/ml — obtained by sweeping the driver instead of simulating a dose. Model family: sigmoid_emax.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = (library default) drug-free response (baseline)
  Emax  =       11.8 msec     maximal effect term (Emax - E0, Q320)
  EC50  =       48.1 ng/ml    exposure at half of the maximal effect term (EC50, Q321)
  gamma =        2.9          Hill coefficient (s, Q325)</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep\">SigmoidEmaxSweep</a>; this model only supplies the numbers. The x axis is one ng/ml of midazolam per second of simulated time (exposure is in kg/m3): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0   (drug-free)
  exposure = EC50 (48.1 ng/ml)  response 0.0059
  exposure -> infinity  response 0.0118</pre></body></html>"));
end Midazolam_Koopmans1988_PD_ver_p100;
