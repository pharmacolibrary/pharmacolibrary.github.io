function p = Midazolam_Koopmans1988_PD_ver_p100_params()
% Midazolam_Koopmans1988_PD_ver_p100_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% midazolam Koopmans_1988::VER_P100: sigmoid_emax exposure-response sweep (response = E0 + Emax*frac). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one ng/ml per second, in SI inside (kg/m3, s). Response VER-P100 in msec. Driver: midazolam (cited_pk).
p.E0 = 0.0;
p.Emax = 0.011800000000000001;
p.EC50 = 4.81e-05;
p.gamma = 2.9;
p.slope = 0.0;
p.exposure_per_s = 1e-06;
p.stop_time = 490.0;
p.form = 'E0 + Emax*frac';
end
