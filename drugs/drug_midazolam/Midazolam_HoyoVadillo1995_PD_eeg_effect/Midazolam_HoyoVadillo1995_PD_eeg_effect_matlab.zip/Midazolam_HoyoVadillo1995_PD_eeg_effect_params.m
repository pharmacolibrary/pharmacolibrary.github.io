function p = Midazolam_HoyoVadillo1995_PD_eeg_effect_params()
% Midazolam_HoyoVadillo1995_PD_eeg_effect_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% midazolam Hoyo-Vadillo_1995::EEG_effect: sigmoid_emax exposure-response sweep (response = E0 + Emax*frac). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one ng/ml per second, in SI inside (kg/m3, s). Response EEG effect in pV/s. Driver: midazolam (cited_pk).
p.E0 = 75.0;
p.Emax = 142.0;
p.EC50 = 8.499999999999999e-05;
p.gamma = 1.2;
p.slope = 0.0;
p.exposure_per_s = 1e-06;
p.stop_time = 850.0;
p.form = 'E0 + Emax*frac';
end
