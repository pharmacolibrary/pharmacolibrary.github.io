% Run: build params, simulate 0..35.0 h, plot + save Midazolam_Burtin1994_mean_estimate_se_index_data_set.png/.csv/.json.
% Interactive display (keep the window open):  octave --persist run_Midazolam_Burtin1994_mean_estimate_se_index_data_set.m
here = fileparts(mfilename('fullpath'));
p = Midazolam_Burtin1994_mean_estimate_se_index_data_set_params();
out = simulate_pk(p, 0:0.05:35.0);

% figure (shown on screen if interactive) and PNG (works in MATLAB and Octave)
fig = figure; plot(out.t, out.C, 'LineWidth', 1.5); grid on;
xlabel('time [h]'); ylabel('central concentration [mg/L]');
title('midazolam — Burtin_1994 (oral)');
print(fig, fullfile(here, 'Midazolam_Burtin1994_mean_estimate_se_index_data_set.png'), '-dpng', '-r150');

% CSV (time_h, Cc_mg_per_L)
fid = fopen(fullfile(here, 'Midazolam_Burtin1994_mean_estimate_se_index_data_set.csv'), 'w');
fprintf(fid, 'time_h,Cc_mg_per_L\n');
fprintf(fid, '%.10g,%.10g\n', [out.t(:), out.C(:)].');
fclose(fid);

% JSON (summary + arrays; jsonencode with a manual fallback for older versions)
fid = fopen(fullfile(here, 'Midazolam_Burtin1994_mean_estimate_se_index_data_set.json'), 'w');
try
  s.model = 'Midazolam_Burtin1994_mean_estimate_se_index_data_set'; s.Cmax = out.Cmax; s.Tmax = out.Tmax; s.AUC = out.AUC;
  s.time_h = out.t(:).'; s.Cc_mg_per_L = out.C(:).';
  fprintf(fid, '%s', jsonencode(s));
catch
  fprintf(fid, '{"model":"Midazolam_Burtin1994_mean_estimate_se_index_data_set","Cmax":%g,"Tmax":%g,"AUC":%g}', out.Cmax, out.Tmax, out.AUC);
end
fclose(fid);

fprintf('Cmax=%.3g mg/L  Tmax=%.3g h  AUC=%.3g mg*h/L\n', out.Cmax, out.Tmax, out.AUC);
fprintf('wrote Midazolam_Burtin1994_mean_estimate_se_index_data_set.png, Midazolam_Burtin1994_mean_estimate_se_index_data_set.csv, Midazolam_Burtin1994_mean_estimate_se_index_data_set.json\n');
