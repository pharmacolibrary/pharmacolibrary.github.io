model Oxaliplatin_Yang2025_reference
  parameter Real Cl_ref = 3.2499999999999997e-09 "Cl [m3/s]";
  parameter Real Vd_ref = 0.00553 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.397294,
    adminMass = 1e-05
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About oxaliplatin</h4><p>Oxaliplatin is a platinum-based anticancer drug used to treat colorectal and other gastrointestinal cancers, including colon, rectal, gastric, and pancreatic adenocarcinomas. It is an approved medicine and is included on the WHO list of essential medicines, so it is widely used in cancer care.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q422327\">Wikidata Q422327</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>oxaliplatin</td></tr><tr><td>population:</td><td>review reference</td></tr><tr><td>source_paper:</td><td>Yang_2025</td></tr><tr><td>measured_compound:</td><td>oxaliplatin</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>oxaliplatin 397.294 g/mol (drugbank)</td></tr></table><h4>Interpretation flags</h4><ul><li>built from REVIEW reference values (Yang_2025) — secondary source</li><li>volume reported by review</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 6048000, Tolerance = 1e-9, Interval = 1));
end Oxaliplatin_Yang2025_reference;
