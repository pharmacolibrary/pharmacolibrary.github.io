model Oxaliplatin_Zhu2023_PD_pdto
  "sigmoid_emax exposure-response sweep — Zhu_2023 :: PDTO (PDTO volumes)"
  extends Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep(
    E0 = 0,      // [1]
    Emax = -0.073,  // [1]
    EC50 = 0.358,  // [mol/m3; μmol/L × 0.001]
    gamma = 0.61,
    exposure_per_s = 0.001);   // 1 μmol/L per second
  // imax_as_negative_emax: Imax (Q323) enters SigmoidEmaxSweep as −Emax
  // defaulted: E0
  annotation(experiment(StartTime = 0, StopTime = 3600, Interval = 7.2),
    Documentation(info = "<html><body><!-- drug-about --><h4>About oxaliplatin</h4><p>Oxaliplatin is a platinum-based anticancer drug used to treat colorectal and other gastrointestinal cancers, including colon, rectal, gastric, and pancreatic adenocarcinomas. It is an approved medicine and is included on the WHO list of essential medicines, so it is widely used in cancer care.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q422327\">Wikidata Q422327</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h4>Oxaliplatin_Zhu2023_PD_pdto</h4><p>The steady-state exposure-response curve of Zhu J et al., <i>Pharmaceutics 15(9)</i> 2023 (<a href=\"https://doi.org/10.3390/pharmaceutics15092274\">doi:10.3390/pharmaceutics15092274</a>) — PDTO volumes against oxaliplatin μmol/L — obtained by sweeping the driver instead of simulating a dose. Model family: sigmoid_emax.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = (library default) drug-free response (baseline)
  Emax  =      0.073          maximal effect term (Emax, Q323)
  EC50  =        358 μmol/L   exposure at half of the maximal effect term (EC50, Q321)
  gamma =       0.61          Hill coefficient (Hill, Q325)</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep\">SigmoidEmaxSweep</a>; this model only supplies the numbers. The x axis is one μmol/L of oxaliplatin per second of simulated time (exposure is in mol/m3): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0   (drug-free)
  exposure = EC50 (358 μmol/L)  response -0.0365
  exposure -> infinity  response -0.073</pre></body></html>"));
end Oxaliplatin_Zhu2023_PD_pdto;
