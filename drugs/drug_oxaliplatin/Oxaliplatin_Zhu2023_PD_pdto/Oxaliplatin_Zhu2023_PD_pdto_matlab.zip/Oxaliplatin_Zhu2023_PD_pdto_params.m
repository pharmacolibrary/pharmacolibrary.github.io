function p = Oxaliplatin_Zhu2023_PD_pdto_params()
% Oxaliplatin_Zhu2023_PD_pdto_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% oxaliplatin Zhu_2023::PDTO: sigmoid_emax exposure-response sweep (response = E0 + Emax*frac). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one μmol/L per second, in SI inside (kg/m3, s). Response PDTO in its own unit. Driver: oxaliplatin (pk_record).
p.E0 = 0.0;
p.Emax = -0.073;
p.EC50 = 0.35799999999999993;
p.gamma = 0.61;
p.slope = 0.0;
p.exposure_per_s = 0.001;
p.stop_time = 3600.0;
p.form = 'E0 + Emax*frac';
end
