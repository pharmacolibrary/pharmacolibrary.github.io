model Oxaliplatin_Kobuchi2020_PD_xacute
  "indirect_response_iii exposure-response sweep — Kobuchi_2020 :: xacute (number of withdrawal responses in the acetone test)"
  extends Pharmacolibrary.Interfaces.PartialExposureResponseSweep(
    E0 = 3.1,      // [times]
    Emax = 10.1,  // type III effect term
    EC50 = 0.00036,  // [kg/m3; μg·mL−1 × 0.001]
    gamma = 1,
    exposure_per_s = 0.001);   // 1 μg·mL−1 per second
equation
  response = E0*(1 + Emax*frac);   // steady state, indirect response type III
  // defaulted: gamma
  annotation(experiment(StartTime = 0, StopTime = 3.6, Interval = 0.0072),
    Documentation(info = "<html><body><!-- drug-about --><h4>About oxaliplatin</h4><p>Oxaliplatin is a platinum-based anticancer drug used to treat colorectal and other gastrointestinal cancers, including colon, rectal, gastric, and pancreatic adenocarcinomas. It is an approved medicine and is included on the WHO list of essential medicines, so it is widely used in cancer care.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q422327\">Wikidata Q422327</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h4>Oxaliplatin_Kobuchi2020_PD_xacute</h4><p>The steady-state exposure-response curve of Kobuchi S et al., <i>Pharmaceutics 12(2)</i> 2020 (<a href=\"https://doi.org/10.3390/pharmaceutics12020125\">doi:10.3390/pharmaceutics12020125</a>) — number of withdrawal responses in the acetone test [times] against L-OHP μg·mL−1 — obtained by sweeping the driver instead of simulating a dose. Model family: indirect_response_iii.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    =        3.1 times    drug-free response (baseline) (x0,acute, Q324)
  Emax  =       10.1          maximal effect term (Emax,acute, Q320)
  EC50  =       0.36 μg·mL−1  exposure at half of the maximal effect term (EC50,acute, Q321)
  gamma = (library default) Hill coefficient</pre><p>The algebra is <code>response = E0*(1 + Emax*frac)</code>; this model only supplies the numbers. The x axis is one μg·mL−1 of L-OHP per second of simulated time (exposure is in kg/m3): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 3.1   (drug-free)
  exposure = EC50 (0.36 μg·mL−1)  response 18.75
  exposure -> infinity  response 34.41</pre></body></html>"));
end Oxaliplatin_Kobuchi2020_PD_xacute;
