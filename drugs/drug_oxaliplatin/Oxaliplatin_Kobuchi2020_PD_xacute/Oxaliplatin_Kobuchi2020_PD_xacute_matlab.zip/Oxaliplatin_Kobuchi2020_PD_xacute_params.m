function p = Oxaliplatin_Kobuchi2020_PD_xacute_params()
% Oxaliplatin_Kobuchi2020_PD_xacute_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% oxaliplatin Kobuchi_2020::xacute: indirect_response_iii exposure-response sweep (response = E0*(1 + Emax*frac)). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one μg·mL−1 per second, in SI inside (kg/m3, s). Response xacute in times. Driver: L-OHP (conc_no_pk).
p.E0 = 3.1;
p.Emax = 10.1;
p.EC50 = 0.0003599999999999999;
p.gamma = 1.0;
p.slope = 0.0;
p.exposure_per_s = 0.001;
p.stop_time = 3.6;
p.form = 'E0*(1 + Emax*frac)';
end
