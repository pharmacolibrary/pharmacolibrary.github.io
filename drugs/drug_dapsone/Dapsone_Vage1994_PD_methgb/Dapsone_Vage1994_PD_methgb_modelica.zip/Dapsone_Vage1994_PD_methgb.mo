model Dapsone_Vage1994_PD_methgb
  "emax exposure-response sweep — Vage_1994 :: MetHgb (methemoglobin (MetHgb) forming ability)"
  extends Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep(
    E0 = 0,      // [1]
    Emax = 0.84,  // [1; % × 0.01]
    EC50 = 828,  // [microM]
    gamma = 1,
    exposure_per_s = 1);   // 1 microM per second
  // exposure_unit_unresolved: 'microM' — the x axis is in the paper's unit, not SI
  // defaulted: E0
  // defaulted: gamma
  annotation(experiment(StartTime = 0, StopTime = 8300, Interval = 16.6),
    Documentation(info = "<html><body><!-- drug-about --><h4>About dapsone</h4><p>Dapsone is used to treat leprosy, dermatitis herpetiformis, acne, and relapsing polychondritis. It remains widely used and is included on the WHO essential medicines list, with topical use for acne and systemic use for mycobacterial disease.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q422226\">Wikidata Q422226</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h4>Dapsone_Vage1994_PD_methgb</h4><p>The steady-state exposure-response curve of Vage C et al., <i>Toxicology and applied pharmacology 129(2):309–316</i> 1994 (<a href=\"https://doi.org/10.1006/taap.1994.1255\">doi:10.1006/taap.1994.1255</a>) — methemoglobin (MetHgb) forming ability [%] against dapsone hydroxylamine (DDS-NOH) microM — obtained by sweeping the driver instead of simulating a dose. Model family: emax.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = (library default) drug-free response (baseline)
  Emax  =         84 %        maximal effect term (Emax, Q320)
  EC50  =        828 microM   exposure at half of the maximal effect term (EC50, Q321)
  gamma = (library default) Hill coefficient</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep\">SigmoidEmaxSweep</a>; this model only supplies the numbers. The x axis is one microM of dapsone hydroxylamine (DDS-NOH) per second of simulated time: there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0   (drug-free)
  exposure = EC50 (828 microM)  response 0.42
  exposure -> infinity  response 0.84</pre></body></html>"));
end Dapsone_Vage1994_PD_methgb;
