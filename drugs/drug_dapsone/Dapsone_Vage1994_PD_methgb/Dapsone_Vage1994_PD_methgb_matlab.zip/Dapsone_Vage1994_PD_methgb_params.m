function p = Dapsone_Vage1994_PD_methgb_params()
% Dapsone_Vage1994_PD_methgb_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% dapsone Vage_1994::MetHgb: emax exposure-response sweep (response = E0 + Emax*frac). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one microM per second, in SI inside (kg/m3, s). Response MetHgb in %. Driver: dapsone hydroxylamine (DDS-NOH) (not_resolved).
p.E0 = 0.0;
p.Emax = 0.84;
p.EC50 = 828.0;
p.gamma = 1.0;
p.slope = 0.0;
p.exposure_per_s = 1.0;
p.stop_time = 8300.0;
p.form = 'E0 + Emax*frac';
end
