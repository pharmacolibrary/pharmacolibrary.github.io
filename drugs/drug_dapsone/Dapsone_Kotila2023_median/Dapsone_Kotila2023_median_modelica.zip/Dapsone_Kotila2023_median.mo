model Dapsone_Kotila2023_median
  parameter Real Cl_ref = 4.2222222222222226e-07 "Cl [m3/s]";
  parameter Real Vd_ref = 0.055560000000000005 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.248301,
    adminMass = 5e-05,
    ka = 2.4999999999999998e-05,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About dapsone</h4><p>Dapsone is used to treat leprosy, dermatitis herpetiformis, acne, and relapsing polychondritis. It remains widely used and is included on the WHO essential medicines list, with topical use for acne and systemic use for mycobacterial disease.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q422226\">Wikidata Q422226</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>dapsone</td></tr><tr><td>population:</td><td>healthy Nigerians</td></tr><tr><td>source_paper:</td><td>Kotila_2023</td></tr><tr><td>measured_compound:</td><td>dapsone</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>T2</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>dapsone 248.301 g/mol (drugbank)</td></tr></table><p><b>Defaulted (base-class default used):</b> Tlag.</p><h4>Interpretation flags</h4><ul><li>dropped unlinked row (NIL): '2.' — extend the ontology if this is a real PK parameter (source ['T2:row4:col5'])</li><li>dropped unlinked row (NIL): '3.' — extend the ontology if this is a real PK parameter (source ['T2:row5:col5'])</li><li>dropped unlinked row (NIL): '4.' — extend the ontology if this is a real PK parameter (source ['T2:row6:col5'])</li><li>apparent-ness (ontology-grounded): parameterization=apparent, measured_compound=dapsone</li><li>population split: 'median' subgroup of Kotila_2023 (paper reports 3 populations: base model selection, mean, median)</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary's parameterization (rate-constant / ka-only) does not use it</li><li>gap-filled Q49 (kabs) from Simpson_2006_2's review values (primary lacked it)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 604800, Tolerance = 1e-9, Interval = 1));
end Dapsone_Kotila2023_median;
