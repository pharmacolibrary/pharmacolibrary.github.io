model Dapsone_Mirochnick2001_reference
  parameter Real Cl_ref = 5.502777777777777e-07 "Cl [m3/s]";
  parameter Real Vd_ref = 0.098 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.248301,
    adminMass = 5e-05,
    ka = 0.000738888888888889,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About dapsone</h4><p>Dapsone is used to treat leprosy, dermatitis herpetiformis, acne, and relapsing polychondritis. It remains widely used and is included on the WHO essential medicines list, with topical use for acne and systemic use for mycobacterial disease.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q422226\">Wikidata Q422226</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>dapsone</td></tr><tr><td>population:</td><td>children with human immunodeficiency virus infection</td></tr><tr><td>source_paper:</td><td>Mirochnick_2001</td></tr><tr><td>measured_compound:</td><td>dapsone</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>dapsone 248.301 g/mol (drugbank)</td></tr></table><p><b>Defaulted (base-class default used):</b> Tlag.</p><h4>Interpretation flags</h4><ul><li>unit_dimension_mismatch: 'dapsone CL/F' → Q27 (unit 'dimensionless' vs ontology '[length] ** 3 / [time]') — route to review</li><li>dropped duplicate Q27 ('dapsone CL/F', value 50) — already have one for this compound</li><li>implicit units: 'absorption rate constant' → 1/h (from the popPK convention: 'Absorption rate constants are first-order rate constants and are conventionally expressed in reciprocal hours (1/h) in p')</li><li>apparent-ness (ontology-grounded): parameterization=apparent, measured_compound=dapsone</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of TLAG: primary's parameterization (rate-constant / ka-only) does not use it</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 691200, Tolerance = 1e-9, Interval = 1));
end Dapsone_Mirochnick2001_reference;
