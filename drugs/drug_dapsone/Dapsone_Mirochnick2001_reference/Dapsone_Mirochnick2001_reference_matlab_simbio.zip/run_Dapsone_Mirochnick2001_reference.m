% Run (SimBiology): build model + dose, simulate 0..192.0 h, plot.
p = Dapsone_Mirochnick2001_reference_params();
[model, dose, variant] = build_sb_pk(p);
sd = simulate_sb(model, variant, dose, 192.0);
