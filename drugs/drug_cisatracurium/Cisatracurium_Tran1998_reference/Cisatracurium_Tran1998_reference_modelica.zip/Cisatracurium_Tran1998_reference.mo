model Cisatracurium_Tran1998_reference
  parameter Real Cl_ref = 1.0277777777777777e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.00826 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.92916,
    adminMass = 1e-05
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About cisatracurium</h4><p>Cisatracurium is a peripherally acting muscle relaxant, related to atracurium, used to relax muscles during surgical procedures and mechanical ventilation. It is an approved medicine in widespread clinical use, mainly in anaesthesia and intensive care settings.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q81978749\">Wikidata Q81978749</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>cisatracurium</td></tr><tr><td>population:</td><td>patients under propofol anesthesia</td></tr><tr><td>source_paper:</td><td>Tran_1998</td></tr><tr><td>measured_compound:</td><td>cisatracurium</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>cisatracurium 929.16 g/mol (drugbank)</td></tr></table><h4>Interpretation flags</h4><ul><li>unit_dimension_unknown: 'mL x min(-1) x kg(-1)' (CL)</li><li>implicit units: 'total clearance' → L/h (from the popPK convention: 'The paper provides no explicit unit in the text or table footnotes. The parameter is total clearance with a value of 3.7')</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=cisatracurium</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Cisatracurium_Tran1998_reference;
