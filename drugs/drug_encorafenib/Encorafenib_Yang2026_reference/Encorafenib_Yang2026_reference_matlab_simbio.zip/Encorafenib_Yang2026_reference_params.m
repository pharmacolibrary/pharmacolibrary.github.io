function p = Encorafenib_Yang2026_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: encorafenib   source: Yang_2026 / reference   route: oral
  p.name  = 'Encorafenib_Yang2026_reference_params';
  p.drug  = 'encorafenib';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 61.73;                % central volume [L]
  p.CL = 12.238;                % clearance [L/h]
  p.Vp = [54.549];             % peripheral volumes [L]
  p.Q  = [1.045];             % inter-compartmental clearances [L/h]
  p.ka = 0.954;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 50.0;             % dose [mg]
end
