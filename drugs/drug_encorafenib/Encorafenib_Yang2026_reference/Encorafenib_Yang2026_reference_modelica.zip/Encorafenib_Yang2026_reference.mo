model Encorafenib_Yang2026_reference
  parameter Real Cl_ref = 3.3994444444444444e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.06173 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.54001,
    adminMass = 5e-05,
    ka = 0.000265,
    Tlag = 0.0,
    k12 = 4.7023777381788065e-06,
    k21 = 5.321413367390378e-06
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About encorafenib</h4><p>Encorafenib is a BRAF protein kinase inhibitor used to treat melanoma and colorectal cancer, and has also been studied for lung cancer. It is authorised in the European Union for melanoma and colorectal cancers.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q15409405\">Wikidata Q15409405</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>encorafenib</td></tr><tr><td>population:</td><td>healthy participants and patients with melanoma, metastatic CRC, NSCLC, or other solid tumors</td></tr><tr><td>source_paper:</td><td>Yang_2026</td></tr><tr><td>measured_compound:</td><td>encorafenib</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>Tab2</td></tr><tr><td>input:</td><td>PK_2C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>encorafenib 540.01 g/mol (drugbank)</td></tr></table><p><b>Defaulted (base-class default used):</b> Tlag.</p><h4>Interpretation flags</h4><ul><li>dropped PD-category row 'θEmax' → Q320 (Emax, category G11) — pharmacodynamic parameters belong to scholarpd, not the PK model (source ['Tab2:row7:col1', 'Tab2:row7:col2'])</li><li>dropped PD-category row 'θEC50 (ng/mL)' → Q321 (EC50, category G11) — pharmacodynamic parameters belong to scholarpd, not the PK model (source ['Tab2:row8:col1', 'Tab2:row8:col2'])</li><li>kept covariate coefficient θGamma=10 (covariate Gamma) — not an ontology parameter</li><li>routed 'θProp err' → Q316 (prop_error) to residual_error — variability estimate, not a structural parameter</li><li>dropped duplicate Q27 ('θmCRC tumor on CL/F day 1 (L/h)', value '-0.175') — already have one for this compound</li><li>dropped duplicate Q27 ('θOther tumor type on CL/F day 1 (L/h)', value '-0.094') — already have one for this compound</li><li>dropped duplicate Q290 ('θBWT on c(Vc/F) day 1 (L)', value '0.588') — already have one for this compound</li><li>apparent-ness (ontology-grounded): parameterization=apparent, measured_compound=encorafenib</li><li>skipped review gap-fill of TLAG: primary's parameterization (rate-constant / ka-only) does not use it</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 1209600, Tolerance = 1e-9, Interval = 1));
end Encorafenib_Yang2026_reference;
