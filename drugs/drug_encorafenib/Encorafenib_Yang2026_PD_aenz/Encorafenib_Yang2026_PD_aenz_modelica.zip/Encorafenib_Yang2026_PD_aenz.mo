model Encorafenib_Yang2026_PD_aenz
  "indirect_response_iii exposure-response sweep — Yang_2026 :: AENZ (enzyme amount)"
  extends Pharmacolibrary.Interfaces.PartialExposureResponseSweep(
    E0 = 1,      // [1]
    Emax = 1.861,  // type III effect term
    EC50 = 9.097e-06,  // [kg/m3; ng/mL × 1e-06]
    gamma = 1,
    exposure_per_s = 1e-06);   // 1 ng/mL per second
equation
  response = E0*(1 + Emax*frac);   // steady state, indirect response type III
  // defaulted: gamma
  annotation(experiment(StartTime = 0, StopTime = 91, Interval = 0.182),
    Documentation(info = "<html><body><!-- drug-about --><h4>About encorafenib</h4><p>Encorafenib is a BRAF protein kinase inhibitor used to treat melanoma and colorectal cancer, and has also been studied for lung cancer. It is authorised in the European Union for melanoma and colorectal cancers.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q15409405\">Wikidata Q15409405</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h4>Encorafenib_Yang2026_PD_aenz</h4><p>The steady-state exposure-response curve of Yang DZ et al., <i>Clinical pharmacokinetics 65(5):693–707</i> 2026 (<a href=\"https://doi.org/10.1007/s40262-025-01608-y\">doi:10.1007/s40262-025-01608-y</a>) — enzyme amount against encorafenib ng/mL — obtained by sweeping the driver instead of simulating a dose. Model family: indirect_response_iii.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    =          1          drug-free response (baseline) (baseline enzyme amount ratio, Q324)
  Emax  =      1.861          maximal effect term (maximum autoinduction effect, Q320)
  EC50  =      9.097 ng/mL    exposure at half of the maximal effect term (concentration at half maximum effect, Q321)
  gamma = (library default) Hill coefficient</pre><p>The algebra is <code>response = E0*(1 + Emax*frac)</code>; this model only supplies the numbers. The x axis is one ng/mL of encorafenib per second of simulated time (exposure is in kg/m3): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 1   (drug-free)
  exposure = EC50 (9.097 ng/mL)  response 1.93
  exposure -> infinity  response 2.861</pre></body></html>"));
end Encorafenib_Yang2026_PD_aenz;
