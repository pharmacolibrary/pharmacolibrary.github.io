function p = Encorafenib_Yang2026_PD_aenz_params()
% Encorafenib_Yang2026_PD_aenz_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% encorafenib Yang_2026::AENZ: indirect_response_iii exposure-response sweep (response = E0*(1 + Emax*frac)). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one ng/mL per second, in SI inside (kg/m3, s). Response AENZ in its own unit. Driver: encorafenib (pk_record).
p.E0 = 1.0;
p.Emax = 1.861;
p.EC50 = 9.097e-06;
p.gamma = 1.0;
p.slope = 0.0;
p.exposure_per_s = 1e-06;
p.stop_time = 91.0;
p.form = 'E0*(1 + Emax*frac)';
end
