function p = Chloroquine_Yao2021_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: chloroquine   source: Yao_2021 / reference   route: oral
  p.name  = 'Chloroquine_Yao2021_reference_params';
  p.drug  = 'chloroquine';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 156.0;                % central volume [L]
  p.CL = 33.3;                % clearance [L/h]
  p.Vp = [3630.0];             % peripheral volumes [L]
  p.Q  = [58.7];             % inter-compartmental clearances [L/h]
  p.ka = 0.559;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.149;             % absorption lag [h]
  p.dose = 500.0;             % dose [mg]
end
