model Chloroquine_Yao2021_reference
  parameter Real Cl_ref = 9.25e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.156 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.319872,
    adminMass = 0.0005,
    ka = 0.00015527777777777778,
    Tlag = 536.4
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About chloroquine</h4><p>Chloroquine is an antimalarial drug used to treat and prevent malaria, and has also been used for conditions such as rheumatoid arthritis and amebiasis. It remains an approved medicine, including veterinary use, and is listed among WHO essential medicines, though resistance has limited its usefulness in some regions.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q422438\">Wikidata Q422438</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>chloroquine</td></tr><tr><td>population:</td><td>COVID-19 patients</td></tr><tr><td>source_paper:</td><td>Yao_2021</td></tr><tr><td>measured_compound:</td><td>chloroquine</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>Tab4</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>chloroquine 319.872 g/mol (drugbank)</td></tr></table><h4>Interpretation flags</h4><ul><li>covariate effect for Q314 has no base parameter row (kept as unattached equation-variable)</li><li>apparent-ness (ontology-grounded): parameterization=apparent, measured_compound=chloroquine</li><li>structure disagreement: deterministic 1C vs LLM 2C — review compartment count</li><li>gap-filled Q76 (V/F) from Chairat_2018's review values (primary lacked it)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Chloroquine_Yao2021_reference;
