// parent + metabolites (desethylchloroquine): PK_3M_9C — formed from central; parent 2, metabolites [2]
model Chloroquine_AbdRahman2020_reference
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_3M_9C(
    Vd1 = 2.93,
    Vd2 = 4.7,
    q12 = 1.3111111111111113e-05,
    q21 = 1.3111111111111113e-05,
    q1_m11 = 1.5166666666666667e-05,
    CL1 = 0.0,
    Vd1m1 = 0.04,
    CLm1 = 1.0444444444444445e-05,
    Vd2m1 = 2.84,
    qm11_m12 = 1.0083333333333332e-05,
    qm12_m11 = 1.0083333333333332e-05,
    MW = 0.319872,
    MW_m1 = 0.2918,
    F = 1,
    ka = 0.0002619444444444444,
    Tlag = 0.0,
    adminDuration = 600,
    adminCount = 1,
    adminMass = 0.000375
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About chloroquine</h4><p>Chloroquine is an antimalarial drug used to treat and prevent malaria, and has also been used for conditions such as rheumatoid arthritis and amebiasis. It remains an approved medicine, including veterinary use, and is listed among WHO essential medicines, though resistance has limited its usefulness in some regions.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q422438\">Wikidata Q422438</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>chloroquine</td></tr><tr><td>population:</td><td>healthy adults inoculated with blood-stage Plasmodium vivax</td></tr><tr><td>source_paper:</td><td>Abd-Rahman_2020</td></tr><tr><td>measured_compound:</td><td>chloroquine</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>parent_metabolite</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>cpt1893-tbl-0002</td></tr><tr><td>input:</td><td>PK_3M_9C: absorption rate constant reported; formation of desethylchloroquine: fm not identifiable (CLm/F, Vm/F reported) — all of CL forms it; dose 375 mg (paper)</td></tr><tr><td>molar_masses:</td><td>chloroquine 319.872 g/mol (drugbank); desethylchloroquine 291.8 g/mol (paper)</td></tr></table><p><b>Defaulted (base-class default used):</b> Tlag.</p><h4>Interpretation flags</h4><ul><li>table section iiv: 'ωka' routed out of structural estimates ('Interindividual variability')</li><li>table section iiv: 'ωka' routed out of structural estimates ('Interindividual variability')</li><li>table section iiv: 'ωka' routed out of structural estimates ('Interindividual variability')</li><li>table section iiv: 'ωka' routed out of structural estimates ('Interindividual variability')</li><li>table section iiv: 'ωka' routed out of structural estimates ('Interindividual variability')</li><li>table section iiv: 'ωka' routed out of structural estimates ('Interindividual variability')</li><li>table section iiv: 'ωka' routed out of structural estimates ('Interindividual variability')</li><li>table section iiv: 'ωka' routed out of structural estimates ('Interindividual variability')</li><li>table section iiv: 'ωFrel' routed out of structural estimates ('Interindividual variability')</li><li>table section iiv: 'ωFrel' routed out of structural estimates ('Interindividual variability')</li><li>table section iiv: 'ωFrel' routed out of structural estimates ('Interindividual variability')</li><li>table section iiv: 'ωFrel' routed out of structural estimates ('Interindividual variability')</li><li>table section iiv: 'ωFrel' routed out of structural estimates ('Interindividual variability')</li><li>table section iiv: 'ωFrel' routed out of structural estimates ('Interindividual variability')</li><li>table section iiv: 'ωFrel' routed out of structural estimates ('Interindividual variability')</li><li>table section iiv: 'ωFrel' routed out of structural estimates ('Interindividual variability')</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 691200, Tolerance = 1e-9, Interval = 1));
end Chloroquine_AbdRahman2020_reference;
