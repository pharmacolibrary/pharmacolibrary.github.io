function p = Chloroquine_AbdRahman2020_reference_params()
% Auto-generated parent-metabolite PK model (clinical units: mg, L, h).
%   drug: chloroquine   source: Abd-Rahman_2020 / reference   PK_3M_9C parent + 1 metabolite(s), 4 compartments, oral
%   dA/dt = K*A; C = A./V. K(i,j) is the rate [1/h] at which compartment j feeds i:
%   a metabolic conversion carries MW_dst/MW_src, so one molecule forms one molecule.
%   molar masses: C_central=319.872 g/mol C_M1=291.8 g/mol
  p.name  = 'Chloroquine_AbdRahman2020_reference_params';
  p.drug  = 'chloroquine';
  p.kind  = 'network';
  p.template = 'PK_3M_9C';
  p.states = {'central', 'peripheral', 'central_M1', 'peripheral_M1'};
  p.V = [2930.0, 4700.0, 40.0, 2840.0];          % compartment volumes [L]
  p.K = [-0.03474402730375427, 0.010042553191489362, 0.0, 0.0;
         0.016109215017064846, -0.010042553191489362, 0.0, 0.0;
         0.01699941922161356, 0.0, -1.8475000000000001, 0.01278169014084507;
         0.0, 0.0, 0.9075, -0.01278169014084507];
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;
  p.dose_into = 1;   % central
  p.ka = 0.943;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h] (in dose_start)
  p.dose = 375.0;             % dose [mg]
  p.dose_start = 0.016666666666666666;   % dose enters from [h] ...
  p.dose_duration = 0.16666666666666666;   % ... at a constant rate for [h]
  p.out_idx = [1.0, 3.0];
  p.out_names = {'C_central', 'C_M1'};
  p.out_labels = {'chloroquine', 'desethylchloroquine'};
end
