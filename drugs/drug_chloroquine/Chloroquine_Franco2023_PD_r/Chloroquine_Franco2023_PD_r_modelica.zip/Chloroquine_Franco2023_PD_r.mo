model Chloroquine_Franco2023_PD_r
  "sigmoid_emax exposure-response sweep — Franco_2023 :: R (JIMT-1 cell viability (% cell viability))"
  extends Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep(
    E0 = 0.982,      // [1; % × 0.01]
    Emax = -0.01,  // [1; % × 0.01]
    EC50 = 24.4,  // [μM]
    gamma = 1.7,
    exposure_per_s = 1);   // 1 μM per second
  // imax_as_negative_emax: Imax (Q323) enters SigmoidEmaxSweep as −Emax
  // exposure_unit_unresolved: 'μM' — the x axis is in the paper's unit, not SI
  annotation(experiment(StartTime = 0, StopTime = 250, Interval = 0.5),
    Documentation(info = "<html><body><!-- drug-about --><h4>About chloroquine</h4><p>Chloroquine is an antimalarial drug used to treat and prevent malaria, and has also been used for conditions such as rheumatoid arthritis and amebiasis. It remains an approved medicine, including veterinary use, and is listed among WHO essential medicines, though resistance has limited its usefulness in some regions.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q422438\">Wikidata Q422438</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h4>Chloroquine_Franco2023_PD_r</h4><p>The steady-state exposure-response curve of Franco YL et al., <i>Cancer diagnosis &amp; prognosis 3(2):175–182</i> 2023 (<a href=\"https://doi.org/10.21873/cdp.10198\">doi:10.21873/cdp.10198</a>) — JIMT-1 cell viability (% cell viability) [%] against chloroquine μM — obtained by sweeping the driver instead of simulating a dose. Model family: sigmoid_emax.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    =       98.2 %        drug-free response (baseline) (R0, Q324)
  Emax  =          1 %        maximal effect term (Imax, Q323)
  EC50  =       24.4 μM       exposure at half of the maximal effect term (IC50, Q322)
  gamma =        1.7          Hill coefficient (Hill coefficient, Q325)</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep\">SigmoidEmaxSweep</a>; this model only supplies the numbers. The x axis is one μM of chloroquine per second of simulated time: there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0.982   (drug-free)
  exposure = EC50 (24.4 μM)  response 0.977
  exposure -> infinity  response 0.972</pre></body></html>"));
end Chloroquine_Franco2023_PD_r;
