function p = Chloroquine_Franco2023_PD_r_params()
% Chloroquine_Franco2023_PD_r_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% chloroquine Franco_2023::R: sigmoid_emax exposure-response sweep (response = E0 + Emax*frac). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one μM per second, in SI inside (kg/m3, s). Response R in %. Driver: chloroquine (cited_pk).
p.E0 = 0.9820000000000001;
p.Emax = -0.01;
p.EC50 = 24.4;
p.gamma = 1.7;
p.slope = 0.0;
p.exposure_per_s = 1.0;
p.stop_time = 250.0;
p.form = 'E0 + Emax*frac';
end
