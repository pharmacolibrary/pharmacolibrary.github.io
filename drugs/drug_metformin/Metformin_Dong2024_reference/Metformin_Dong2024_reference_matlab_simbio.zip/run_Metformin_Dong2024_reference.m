% Run (SimBiology): build model + dose, simulate 0..39.0 h, plot.
p = Metformin_Dong2024_reference_params();
[model, dose, variant] = build_sb_pk(p);
sd = simulate_sb(model, variant, dose, 39.0);
