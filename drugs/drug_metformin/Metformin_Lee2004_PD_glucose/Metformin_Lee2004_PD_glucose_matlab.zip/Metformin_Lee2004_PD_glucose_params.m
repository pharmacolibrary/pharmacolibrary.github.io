function p = Metformin_Lee2004_PD_glucose_params()
% Metformin_Lee2004_PD_glucose_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% metformin Lee_2004::glucose: indirect_response_i exposure-response sweep (response = E0*(1 - Emax*frac)). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one microg/mL per second, in SI inside (kg/m3, s). Response glucose in its own unit. Driver: metformin (cited_pk).
p.E0 = 122.44117647058823;
p.Emax = 1.0;
p.EC50 = 0.0022599999999999994;
p.gamma = 1.0;
p.slope = 0.0;
p.exposure_per_s = 0.001;
p.stop_time = 23.0;
p.form = 'E0*(1 - Emax*frac)';
end
