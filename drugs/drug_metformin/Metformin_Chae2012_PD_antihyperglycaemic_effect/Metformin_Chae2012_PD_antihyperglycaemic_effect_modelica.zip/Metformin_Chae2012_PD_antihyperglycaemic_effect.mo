model Metformin_Chae2012_PD_antihyperglycaemic_effect
  "sigmoid_emax exposure-response sweep — Chae_2012 :: antihyperglycaemic effect (antihyperglycaemic effect)"
  extends Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep(
    E0 = 0,      // [1]
    Emax = -0.198,  // [1; % × 0.01]
    EC50 = 3.68,  // [kg/m3; mg ml -1 × 1]
    gamma = 0.55,
    exposure_per_s = 1);   // 1 mg ml -1 per second
  // family_inferred: the record's model family is transduction; read from the parameters: Emax/Imax, EC50/IC50 and a Hill coefficient — sigmoid Emax
  // imax_as_negative_emax: Imax (Q323) enters SigmoidEmaxSweep as −Emax
  // defaulted: E0
  annotation(experiment(StartTime = 0, StopTime = 37, Interval = 0.074),
    Documentation(info = "<html><body><!-- drug-about --><h4>About metformin</h4><p>Metformin is an anti-diabetic medicine used to treat diabetes and high blood sugar, including maturity-onset diabetes of the young type 2. It is widely used and appears on the WHO list of essential medicines, and is also available in many combination products with other oral glucose-lowering drugs.</p><p><small>Summary written by glm-5.3-flash from <a href=&quot;https://www.wikidata.org/wiki/Q19484&quot;>Wikidata Q19484</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h4>Metformin_Chae2012_PD_antihyperglycaemic_effect</h4><p>The steady-state exposure-response curve of Chae JW et al., <i>British journal of clinical pharmacology 74(5):815–823</i> 2012 (<a href=\"https://doi.org/10.1111/j.1365-2125.2012.04260.x\">doi:10.1111/j.1365-2125.2012.04260.x</a>) — antihyperglycaemic effect [%] against metformin mg ml -1 — obtained by sweeping the driver instead of simulating a dose. Model family: sigmoid_emax.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = (library default) drug-free response (baseline)
  Emax  =       19.8 %        maximal effect term (Emax, Q323)
  EC50  =       3.68 mg ml -1 exposure at half of the maximal effect term (EC50, Q321)
  gamma =       0.55          Hill coefficient (r, Q325)</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep\">SigmoidEmaxSweep</a>; this model only supplies the numbers. The x axis is one mg ml -1 of metformin per second of simulated time (exposure is in kg/m3): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0   (drug-free)
  exposure = EC50 (3.68 mg ml -1)  response -0.099
  exposure -> infinity  response -0.198</pre></body></html>"));
end Metformin_Chae2012_PD_antihyperglycaemic_effect;
