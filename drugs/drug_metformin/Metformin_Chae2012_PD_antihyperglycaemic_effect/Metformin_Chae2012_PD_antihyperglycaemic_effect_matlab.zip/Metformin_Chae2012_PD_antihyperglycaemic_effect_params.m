function p = Metformin_Chae2012_PD_antihyperglycaemic_effect_params()
% Metformin_Chae2012_PD_antihyperglycaemic_effect_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% metformin Chae_2012::antihyperglycaemic_effect: sigmoid_emax exposure-response sweep (response = E0 + Emax*frac). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one mg ml -1 per second, in SI inside (kg/m3, s). Response antihyperglycaemic effect in %. Driver: metformin (pk_record).
p.E0 = 0.0;
p.Emax = -0.198;
p.EC50 = 3.6799999999999997;
p.gamma = 0.55;
p.slope = 0.0;
p.exposure_per_s = 1.0;
p.stop_time = 37.0;
p.form = 'E0 + Emax*frac';
end
