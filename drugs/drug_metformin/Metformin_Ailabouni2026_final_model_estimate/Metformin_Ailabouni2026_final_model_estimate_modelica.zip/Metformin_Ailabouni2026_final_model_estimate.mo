model Metformin_Ailabouni2026_final_model_estimate
  parameter Real Cl_ref = 2.6777777777777782e-05 "Cl [m3/s]";
  parameter Real cov_egfr_0 = 0 "egfr covariate";
  parameter Real Vd_ref = 0.546 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref*(1 + (0.75)*cov_egfr_0),
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.1291636,
    adminMass = 0.00025,
    ka = 0.00026138888888888886,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>metformin</td></tr><tr><td>population:</td><td>pediatric patients</td></tr><tr><td>source_paper:</td><td>Ailabouni_2026</td></tr><tr><td>measured_compound:</td><td>metformin</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>tab_3</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>metformin 129.164 g/mol (drugbank)</td></tr></table><p><b>Defaulted (base-class default used):</b> Tlag.</p><h4>Interpretation flags</h4><ul><li>dropped unlinked row (NIL): 'TBW on CL/F' — extend the ontology if this is a real PK parameter (source ['tab_3:row6:col1', 'tab_3:row6:col4', 'tab_3:row6:col5', 'tab_3:row6:col6'])</li><li>covariate level 'eGFR on CL/F' → Q900:egfr_on_cl_f = 0.750 (linear_fractional on Q27)</li><li>implicit units: 'Ka (1/h)' → 1/h (from the popPK convention: &quot;The paper defines Ka as the 'first-order absorption rate constant' in the Table 4 caption. While the table itself does n&quot;)</li><li>apparent-ness (ontology-grounded): parameterization=apparent, measured_compound=metformin</li><li>population split: 'final model estimate' subgroup of Ailabouni_2026 (paper reports 3 populations: 250 mg, 850 mg, final model estimate)</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of TLAG: primary's parameterization (rate-constant / ka-only) does not use it</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Metformin_Ailabouni2026_final_model_estimate;
