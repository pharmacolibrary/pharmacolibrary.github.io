function p = Metformin_Fujimoto2025_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: metformin   source: Fujimoto_2025 / reference   route: oral
  % estimated (absent from source): F
  p.name  = 'Metformin_Fujimoto2025_reference_params';
  p.drug  = 'metformin';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 35.0;                % central volume [L]
  p.CL = 5.0;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.7;                % absorption rate [1/h]
  p.F  = 0.9;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 200.0;             % dose [mg]
end
