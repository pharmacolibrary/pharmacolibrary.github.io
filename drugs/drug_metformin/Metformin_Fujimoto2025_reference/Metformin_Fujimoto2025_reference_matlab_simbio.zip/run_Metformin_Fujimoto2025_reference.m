% Run (SimBiology): build model + dose, simulate 0..29.0 h, plot.
p = Metformin_Fujimoto2025_reference_params();
[model, dose, variant] = build_sb_pk(p);
sd = simulate_sb(model, variant, dose, 29.0);
