function p = Metformin_Jacobs2026_oral_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: metformin   source: Jacobs_2026 / oral   route: oral
  p.name  = 'Metformin_Jacobs2026_oral_params';
  p.drug  = 'metformin';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 35.0;                % central volume [L]
  p.CL = 0.059;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.41;                % absorption rate [1/h]
  p.F  = 0.0786;                 % bioavailability [0-1]
  p.Tlag = 0.34;             % absorption lag [h]
  p.dose = 2000.0;             % dose [mg]
end
