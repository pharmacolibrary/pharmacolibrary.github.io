function p = Metformin_Hong2008_PD_fpg_params()
% Metformin_Hong2008_PD_fpg_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% metformin Hong_2008::FPG: indirect_response_i exposure-response sweep (response = E0*(1 - Emax*frac)). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one mg.L(-1) per second, in SI inside (kg/m3, s). Response FPG in mg.dL(-1). Driver: metformin (pk_record).
p.E0 = 2.4099999999999997;
p.Emax = 1.0;
p.EC50 = 0.004229999999999999;
p.gamma = 1.0;
p.slope = 0.0;
p.exposure_per_s = 0.001;
p.stop_time = 43.0;
p.form = 'E0*(1 - Emax*frac)';
end
