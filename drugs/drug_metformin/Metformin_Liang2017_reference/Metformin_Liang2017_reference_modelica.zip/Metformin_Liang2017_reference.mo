model Metformin_Liang2017_reference
  parameter Real Cl_ref = 1.8999999999999998e-05 "Cl [m3/s]";
  parameter Real Vd_ref = 0.6 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.1291636,
    adminMass = 0.002,
    ka = 0.0001388888888888889,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About metformin</h4><p>Metformin is an anti-diabetic medicine used to treat diabetes and high blood sugar, including maturity-onset diabetes of the young type 2. It is widely used and appears on the WHO list of essential medicines, and is also available in many combination products with other oral glucose-lowering drugs.</p><p><small>Summary written by glm-5.3-flash from <a href=&quot;https://www.wikidata.org/wiki/Q19484&quot;>Wikidata Q19484</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>metformin</td></tr><tr><td>population:</td><td>review reference</td></tr><tr><td>source_paper:</td><td>Liang_2017</td></tr><tr><td>measured_compound:</td><td>metformin</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C_enteral: apparent (/F) parameterization ⇒ extravascular dosing</td></tr><tr><td>molar_masses:</td><td>metformin 129.164 g/mol (drugbank)</td></tr></table><p><b>Defaulted (base-class default used):</b> ka, Tlag.</p><h4>Interpretation flags</h4><ul><li>built from REVIEW reference values (Liang_2017) — secondary source</li><li>volume reported by review</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 111600, Tolerance = 1e-9, Interval = 1));
end Metformin_Liang2017_reference;
