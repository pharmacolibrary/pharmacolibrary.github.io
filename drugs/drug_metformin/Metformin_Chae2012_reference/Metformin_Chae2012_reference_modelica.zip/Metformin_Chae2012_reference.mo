model Metformin_Chae2012_reference
  parameter Real Cl_ref = 1.4611111111111112e-05 "Cl [m3/s]";
  parameter Real Vd_ref = 0.113 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 0.9,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.1291636,
    adminMass = 0.0005,
    ka = 0.00011388888888888888,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About metformin</h4><p>Metformin is an anti-diabetic medicine used to treat diabetes and high blood sugar, including maturity-onset diabetes of the young type 2. It is widely used and appears on the WHO list of essential medicines, and is also available in many combination products with other oral glucose-lowering drugs.</p><p><small>Summary written by glm-5.3-flash from <a href=&quot;https://www.wikidata.org/wiki/Q19484&quot;>Wikidata Q19484</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>metformin</td></tr><tr><td>population:</td><td>healthy humans</td></tr><tr><td>source_paper:</td><td>Chae_2012</td></tr><tr><td>measured_compound:</td><td>metformin</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>tab_1</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>metformin 129.164 g/mol (drugbank)</td></tr></table><p><b>Defaulted (base-class default used):</b> F, Tlag.</p><h4>Interpretation flags</h4><ul><li>table section iiv: 'CL (l h -1 )' routed out of structural estimates ('Interindividual')</li><li>table section iiv: 'V (l)' routed out of structural estimates ('Interindividual')</li><li>table section iiv: 'r' routed out of structural estimates ('Interindividual')</li><li>dropped unlinked row (NIL): 'Parameter, unit' — extend the ontology if this is a real PK parameter (source ['tab_1:row2:col3', 'tab_1:row2:col5'])</li><li>dropped unlinked row (NIL): 't' — extend the ontology if this is a real PK parameter (source ['tab_1:row9:col2'])</li><li>dropped PD-category row 'Emax' → Q320 (Emax, category G11) — pharmacodynamic parameters belong to scholarpd, not the PK model (source ['tab_1:row10:col2'])</li><li>dropped PD-category row 'EC50' → Q321 (EC50, category G11) — pharmacodynamic parameters belong to scholarpd, not the PK model (source ['tab_1:row11:col2'])</li><li>dropped unlinked row (NIL): 'r' — extend the ontology if this is a real PK parameter (source ['tab_1:row12:col2'])</li><li>apparent-by-design (ADVISORY, codes unchanged): extravascular dosing with no identifiable F, so these reported disposition parameters are likely apparent unless the model puts first-pass in its structure — Q22 (CL (l h -1 )); Q61 (V (l))</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=metformin</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of TLAG: primary's parameterization (rate-constant / ka-only) does not use it</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Metformin_Chae2012_reference;
