model AlglucosidaseAlfa_Tiraboschi2023_reference
  parameter Real Cl_ref = 2.175e-07 "Cl [m3/s]";
  parameter Real Vd_ref = 0.00329 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    adminMass = 0.0001
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About alglucosidase_alfa</h4><p>Alglucosidase alfa is an enzyme medication used to treat glycogen storage disease type II (Pompe disease). It is an approved enzyme therapy and has also been studied investigationally.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q2919537\">Wikidata Q2919537</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>alglucosidase_alfa</td></tr><tr><td>population:</td><td>review reference</td></tr><tr><td>source_paper:</td><td>Tiraboschi_2023</td></tr><tr><td>measured_compound:</td><td>alglucosidase_alfa</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C: IV (no input phase)</td></tr></table><h4>Interpretation flags</h4><ul><li>built from REVIEW reference values (Tiraboschi_2023) — secondary source</li><li>volume reported by review</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end AlglucosidaseAlfa_Tiraboschi2023_reference;
