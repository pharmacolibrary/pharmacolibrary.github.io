function p = Daunorubicin_Quartino2007_PD_si_params()
% Daunorubicin_Quartino2007_PD_si_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% daunorubicin Quartino_2007::SI: sigmoid_emax exposure-response sweep (response = E0 + Emax*frac). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one μg/mL per second, in SI inside (kg/m3, s). Response SI in %. Driver: daunorubicin (Dnr) (conc_no_pk).
p.E0 = 0.0;
p.Emax = -0.0091;
p.EC50 = 8.999999999999998e-05;
p.gamma = 1.23;
p.slope = 0.0;
p.exposure_per_s = 0.001;
p.stop_time = 0.9;
p.form = 'E0 + Emax*frac';
end
