model Daunorubicin_Quartino2007_PD_si
  "sigmoid_emax exposure-response sweep — Quartino_2007 :: SI (survival index)"
  extends Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep(
    E0 = 0,      // [1]
    Emax = -0.0091,  // [1; % × 0.01]
    EC50 = 9e-05,  // [kg/m3; μg/mL × 0.001]
    gamma = 1.23,
    exposure_per_s = 0.001);   // 1 μg/mL per second
  // imax_as_negative_emax: Imax (Q323) enters SigmoidEmaxSweep as −Emax
  // defaulted: E0
  annotation(experiment(StartTime = 0, StopTime = 0.9, Interval = 0.0018),
    Documentation(info = "<html><body><!-- drug-about --><h4>About daunorubicin</h4><p>Daunorubicin is an anthracycline antibiotic used to treat acute myeloid leukemia and lymphoid leukemia. It is an approved, widely used anticancer drug and appears on the WHO list of essential medicines.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q411659\">Wikidata Q411659</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h4>Daunorubicin_Quartino2007_PD_si</h4><p>The steady-state exposure-response curve of Quartino A et al., <i>Journal of clinical pharmacology 47(8):1014–1021</i> 2007 (<a href=\"https://doi.org/10.1177/0091270007302563\">doi:10.1177/0091270007302563</a>) — survival index [%] against daunorubicin (Dnr) μg/mL — obtained by sweeping the driver instead of simulating a dose. Model family: sigmoid_emax.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = (library default) drug-free response (baseline)
  Emax  =       0.91 %        maximal effect term (E max, Q323)
  EC50  =       0.09 μg/mL    exposure at half of the maximal effect term (EC 50, Q322)
  gamma =       1.23          Hill coefficient (Slope, Q325)</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep\">SigmoidEmaxSweep</a>; this model only supplies the numbers. The x axis is one μg/mL of daunorubicin (Dnr) per second of simulated time (exposure is in kg/m3): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0   (drug-free)
  exposure = EC50 (0.09 μg/mL)  response -0.00455
  exposure -> infinity  response -0.0091</pre></body></html>"));
end Daunorubicin_Quartino2007_PD_si;
