model Daunorubicin_Gumbo2020v2_PD_bacterial_burden
  "sigmoid_emax exposure-response sweep — Gumbo_2020_2 :: bacterial burden (bacterial burden)"
  extends Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep(
    E0 = 7.61,      // [log 10 cfu/mL]
    Emax = -4.19,  // [log 10 cfu/mL]
    EC50 = 0.01167,  // [kg/m3; mg/L × 0.001]
    gamma = 1.92,
    exposure_per_s = 0.001);   // 1 mg/L per second
  // imax_as_negative_emax: Imax (Q323) enters SigmoidEmaxSweep as −Emax
  annotation(experiment(StartTime = 0, StopTime = 120, Interval = 0.24),
    Documentation(info = "<html><body><!-- drug-about --><h4>About daunorubicin</h4><p>Daunorubicin is an anthracycline antibiotic used to treat acute myeloid leukemia and lymphoid leukemia. It is an approved, widely used anticancer drug and appears on the WHO list of essential medicines.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q411659\">Wikidata Q411659</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h4>Daunorubicin_Gumbo2020v2_PD_bacterial_burden</h4><p>The steady-state exposure-response curve of Gumbo T et al., <i>The Journal of antimicrobial chemotherapy 75(5):1212–1217</i> 2020 (<a href=\"https://doi.org/10.1093/jac/dkz523\">doi:10.1093/jac/dkz523</a>) — bacterial burden [log 10 cfu/mL] against daunorubicin mg/L — obtained by sweeping the driver instead of simulating a dose. Model family: sigmoid_emax.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    =       7.61 log 10 cfu/mL drug-free response (baseline) (E con, Q324)
  Emax  =       4.19 log 10 cfu/mL maximal effect term (E max, Q323)
  EC50  =      11.67 mg/L     exposure at half of the maximal effect term (EC 50, Q321)
  gamma =       1.92          Hill coefficient (Hill coefficient, Q325)</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep\">SigmoidEmaxSweep</a>; this model only supplies the numbers. The x axis is one mg/L of daunorubicin per second of simulated time (exposure is in kg/m3): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 7.61   (drug-free)
  exposure = EC50 (11.67 mg/L)  response 5.515
  exposure -> infinity  response 3.42</pre></body></html>"));
end Daunorubicin_Gumbo2020v2_PD_bacterial_burden;
