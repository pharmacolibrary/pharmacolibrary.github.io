function p = Daunorubicin_Gumbo2020v2_PD_bacterial_burden_params()
% Daunorubicin_Gumbo2020v2_PD_bacterial_burden_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% daunorubicin Gumbo_2020_2::bacterial_burden: sigmoid_emax exposure-response sweep (response = E0 + Emax*frac). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one mg/L per second, in SI inside (kg/m3, s). Response bacterial burden in log 10 cfu/mL. Driver: daunorubicin (cited_pk).
p.E0 = 7.61;
p.Emax = -4.19;
p.EC50 = 0.011669999999999998;
p.gamma = 1.92;
p.slope = 0.0;
p.exposure_per_s = 0.001;
p.stop_time = 120.0;
p.form = 'E0 + Emax*frac';
end
