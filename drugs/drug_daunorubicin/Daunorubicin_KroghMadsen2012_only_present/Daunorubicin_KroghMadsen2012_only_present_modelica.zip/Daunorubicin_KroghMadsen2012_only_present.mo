model Daunorubicin_KroghMadsen2012_only_present
  parameter Real Cl_ref = 7.777777777777777e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.022 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.5275259999999999,
    adminMass = 1e-05,
    k21 = 0.00016816143497757848
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About daunorubicin</h4><p>Daunorubicin is an anthracycline antibiotic used to treat acute myeloid leukemia and lymphoid leukemia. It is an approved, widely used anticancer drug and appears on the WHO list of essential medicines.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q411659\">Wikidata Q411659</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>daunorubicin</td></tr><tr><td>population:</td><td>patients with acute myeloid leukemia</td></tr><tr><td>source_paper:</td><td>Krogh-Madsen_2012</td></tr><tr><td>measured_compound:</td><td>cytarabine, etoposide, and daunorubicin</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>tab_1</td></tr><tr><td>input:</td><td>PK_2C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>cytarabine, etoposide, and daunorubicin 527.526 g/mol (pubchem); daunorubicin 527.52 g/mol (drugbank)</td></tr></table><p><b>Defaulted (base-class default used):</b> k12.</p><h4>Interpretation flags</h4><ul><li>column 'only present' classified 'other' by the LLM but kept: the deterministic diagnostic-column test disagrees (a stratum column is a value column, not a statistic)</li><li>column 'only present' classified 'other' by the LLM but kept: the deterministic diagnostic-column test disagrees (a stratum column is a value column, not a statistic)</li><li>column 'only present' classified 'other' by the LLM but kept: the deterministic diagnostic-column test disagrees (a stratum column is a value column, not a statistic)</li><li>column 'only present' classified 'other' by the LLM but kept: the deterministic diagnostic-column test disagrees (a stratum column is a value column, not a statistic)</li><li>column 'only present' classified 'other' by the LLM but kept: the deterministic diagnostic-column test disagrees (a stratum column is a value column, not a statistic)</li><li>routed 'Res. error (%)' → Q316 (prop_error) to residual_error — variability estimate, not a structural parameter</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=cytarabine, etoposide, and daunorubicin</li><li>population split: 'only present' subgroup of Krogh-Madsen_2012 (paper reports 5 populations: daunorubicin, only present, only present study ?, prior study ?, prior study a)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Daunorubicin_KroghMadsen2012_only_present;
