model Etanercept_Breedveld2018_PD_esr
  "sigmoid_emax exposure-response sweep — Breedveld_2018 :: ESR (erythrocyte sedimentation rate)"
  extends Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep(
    E0 = 0,      // [1]
    Emax = -0.46,  // [1; % × 0.01]
    EC50 = 0.000465,  // [kg/m3; ng/mL × 1e-06]
    gamma = 0.48,
    exposure_per_s = 1e-06);   // 1 ng/mL per second
  // imax_as_negative_emax: Imax (Q323) enters SigmoidEmaxSweep as −Emax
  // defaulted: E0
  annotation(experiment(StartTime = 0, StopTime = 4700, Interval = 9.4),
    Documentation(info = "<html><body><!-- drug-about --><h4>About etanercept</h4><p>Etanercept is a TNF inhibitor used to treat inflammatory conditions such as rheumatoid and psoriatic arthritis, juvenile idiopathic arthritis, ankylosing spondylitis, and psoriasis. It is approved and widely used, with several products authorised in the European Union.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q415343\">Wikidata Q415343</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h4>Etanercept_Breedveld2018_PD_esr</h4><p>The steady-state exposure-response curve of Breedveld FC et al., <i>Clinical and translational science 11(1):38–45</i> 2018 (<a href=\"https://doi.org/10.1111/cts.12502\">doi:10.1111/cts.12502</a>) — erythrocyte sedimentation rate [mm/h] against etanercept ng/mL — obtained by sweeping the driver instead of simulating a dose. Model family: sigmoid_emax.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = (library default) drug-free response (baseline)
  Emax  =         46 %        maximal effect term (Emax, Q323)
  EC50  =        465 ng/mL    exposure at half of the maximal effect term (EC50, Q322)
  gamma =       0.48          Hill coefficient (Sigmoidicity factor, Q325)</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep\">SigmoidEmaxSweep</a>; this model only supplies the numbers. The x axis is one ng/mL of etanercept per second of simulated time (exposure is in kg/m3): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0   (drug-free)
  exposure = EC50 (465 ng/mL)  response -0.23
  exposure -> infinity  response -0.46</pre></body></html>"));
end Etanercept_Breedveld2018_PD_esr;
