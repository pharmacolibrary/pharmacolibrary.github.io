function p = Etanercept_Breedveld2018_PD_esr_params()
% Etanercept_Breedveld2018_PD_esr_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% etanercept Breedveld_2018::ESR: sigmoid_emax exposure-response sweep (response = E0 + Emax*frac). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one ng/mL per second, in SI inside (kg/m3, s). Response ESR in mm/h. Driver: etanercept (cited_pk).
p.E0 = 0.0;
p.Emax = -0.46;
p.EC50 = 0.00046499999999999997;
p.gamma = 0.48;
p.slope = 0.0;
p.exposure_per_s = 1e-06;
p.stop_time = 4700.0;
p.form = 'E0 + Emax*frac';
end
