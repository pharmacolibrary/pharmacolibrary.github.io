function p = Etanercept_Breedveld2018_PD_number_of_swollen_joints_params()
% Etanercept_Breedveld2018_PD_number_of_swollen_joints_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% etanercept Breedveld_2018::number_of_swollen_joints: sigmoid_emax exposure-response sweep (response = E0 + Emax*frac). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one ng/mL per second, in SI inside (kg/m3, s). Response number of swollen joints in its own unit. Driver: etanercept (cited_pk).
p.E0 = 0.0;
p.Emax = -0.5697;
p.EC50 = 0.000567;
p.gamma = 1.33;
p.slope = 0.0;
p.exposure_per_s = 1e-06;
p.stop_time = 5700.0;
p.form = 'E0 + Emax*frac';
end
