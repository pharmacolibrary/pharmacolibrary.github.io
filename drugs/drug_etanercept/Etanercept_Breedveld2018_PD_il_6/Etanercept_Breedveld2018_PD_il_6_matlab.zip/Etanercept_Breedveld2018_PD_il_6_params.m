function p = Etanercept_Breedveld2018_PD_il_6_params()
% Etanercept_Breedveld2018_PD_il_6_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% etanercept Breedveld_2018::IL_6: sigmoid_emax exposure-response sweep (response = E0 + Emax*frac). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one ng/mL per second, in SI inside (kg/m3, s). Response IL-6 in pg/mL. Driver: etanercept (cited_pk).
p.E0 = 0.0;
p.Emax = -0.2811;
p.EC50 = 8.7e-05;
p.gamma = 3.13;
p.slope = 0.0;
p.exposure_per_s = 1e-06;
p.stop_time = 870.0;
p.form = 'E0 + Emax*frac';
end
