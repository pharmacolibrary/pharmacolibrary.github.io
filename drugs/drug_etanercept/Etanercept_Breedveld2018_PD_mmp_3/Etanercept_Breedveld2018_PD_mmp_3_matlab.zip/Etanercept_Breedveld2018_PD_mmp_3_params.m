function p = Etanercept_Breedveld2018_PD_mmp_3_params()
% Etanercept_Breedveld2018_PD_mmp_3_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% etanercept Breedveld_2018::MMP_3: sigmoid_emax exposure-response sweep (response = E0 + Emax*frac). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one ng/mL per second, in SI inside (kg/m3, s). Response MMP-3 in ng/mL. Driver: etanercept (cited_pk).
p.E0 = 0.0;
p.Emax = -0.2788;
p.EC50 = 0.000159;
p.gamma = 1.39;
p.slope = 0.0;
p.exposure_per_s = 1e-06;
p.stop_time = 1600.0;
p.form = 'E0 + Emax*frac';
end
