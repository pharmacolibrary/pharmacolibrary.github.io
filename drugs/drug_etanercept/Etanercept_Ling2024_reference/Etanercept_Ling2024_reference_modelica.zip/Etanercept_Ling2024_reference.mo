model Etanercept_Ling2024_reference
  parameter Real Cl_ref = 7.861111111111112e-10 "Cl [m3/s]";
  parameter Real Vd_ref = 0.00919 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 0.9,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    adminMass = 4e-05,
    ka = 3.2416666666666664e-05,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About etanercept</h4><p>Etanercept is a TNF inhibitor used to treat inflammatory conditions such as rheumatoid and psoriatic arthritis, juvenile idiopathic arthritis, ankylosing spondylitis, and psoriasis. It is approved and widely used, with several products authorised in the European Union.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q415343\">Wikidata Q415343</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>etanercept</td></tr><tr><td>population:</td><td>patients with rheumatoid arthritis</td></tr><tr><td>source_paper:</td><td>Ling_2024</td></tr><tr><td>measured_compound:</td><td>etanercept biosimilar</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>pharmaceutics-16-00702-t004</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr></table><p><b>Defaulted (base-class default used):</b> F, Tlag.</p><h4>Interpretation flags</h4><ul><li>apparent-by-design (ADVISORY, codes unchanged): extravascular dosing with no identifiable F, so these reported disposition parameters are likely apparent unless the model puts first-pass in its structure — Q61 (VD (L)); Q22 (CL (L/h))</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=etanercept biosimilar</li><li>molar mass: no plausible PubChem entry for 'etanercept biosimilar' ('etanercept') — left in mass units</li><li>molar mass: none found for 'etanercept' — its concentrations stay mass-only</li><li>molar mass: none found for 'etanercept biosimilar' — its concentrations stay mass-only</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of TLAG: primary's parameterization (rate-constant / ka-only) does not use it</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 15552000, Tolerance = 1e-9, Interval = 1));
end Etanercept_Ling2024_reference;
