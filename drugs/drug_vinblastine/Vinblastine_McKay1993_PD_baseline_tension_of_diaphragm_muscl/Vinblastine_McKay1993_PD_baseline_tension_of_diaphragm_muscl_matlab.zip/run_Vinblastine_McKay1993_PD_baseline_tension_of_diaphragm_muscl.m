% run_Vinblastine_McKay1993_PD_baseline_tension_of_diaphragm_muscl  Evaluate the exposure-response curve and plot response against exposure.
% A sweep is a static map: no ODE solver is needed. exposure runs 0..stop_time*exposure_per_s.
p = Vinblastine_McKay1993_PD_baseline_tension_of_diaphragm_muscl_params();
exposure = linspace(0, p.stop_time * p.exposure_per_s, 501);
frac = exposure.^p.gamma ./ (p.EC50^p.gamma + exposure.^p.gamma);
E0 = p.E0; Emax = p.Emax; slope = p.slope;
response = E0 + Emax.*frac;
figure; plot(exposure, response, 'LineWidth', 1.5); grid on;
xlabel('exposure [pM]'); ylabel('response [g]'); title('Vinblastine_McKay1993_PD_baseline_tension_of_diaphragm_muscl', 'Interpreter', 'none');
writematrix([exposure(:) response(:)], 'Vinblastine_McKay1993_PD_baseline_tension_of_diaphragm_muscl.csv');
