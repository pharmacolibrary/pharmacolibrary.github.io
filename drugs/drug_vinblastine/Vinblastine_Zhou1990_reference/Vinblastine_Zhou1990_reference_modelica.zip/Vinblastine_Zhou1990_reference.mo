model Vinblastine_Zhou1990_reference
  parameter Real Cl_ref = 2.897222222222222e-05 "Cl [m3/s]";
  parameter Real Vd_ref = 0.41020000000000006 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    adminMass = 7e-06
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About vinblastine</h4><p>Vinblastine, a Vinca alkaloid, is a cancer medicine used against tumours such as Hodgkin's lymphoma, breast, testicular and kidney cancer, Kaposi's sarcoma, and also certain blood and immune disorders. It remains an approved medicine and is included on the WHO list of essential medicines, so it is widely used in cancer treatment worldwide.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q282629\">Wikidata Q282629</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>vinblastine</td></tr><tr><td>population:</td><td>rats given intravenous vinblastine or vincristine</td></tr><tr><td>source_paper:</td><td>Zhou_1990</td></tr><tr><td>measured_compound:</td><td>vinblastine and vincristine</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>table ii</td></tr><tr><td>input:</td><td>PK_2C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>vinblastine 810.974 g/mol (drugbank)</td></tr></table><p><b>Defaulted (base-class default used):</b> k12, k21.</p><h4>Interpretation flags</h4><ul><li>dropped unlinked row (NIL): 'Dose (mg/kg)' — extend the ontology if this is a real PK parameter (source ['Zhou_1990_table_1:row0:col1'])</li><li>covariate effect for Q900 has no base parameter row (kept as unattached equation-variable)</li><li>covariate effect for Q59 has no base parameter row (kept as unattached equation-variable)</li><li>covariate effect for Q900 has no base parameter row (kept as unattached equation-variable)</li><li>covariate effect for Q60 has no base parameter row (kept as unattached equation-variable)</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=vinblastine and vincristine</li><li>molar mass: no plausible PubChem entry for 'vinblastine and vincristine' ('vinblastine and vincristine') — left in mass units</li><li>molar mass: none found for 'vinblastine and vincristine' — its concentrations stay mass-only</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Vinblastine_Zhou1990_reference;
