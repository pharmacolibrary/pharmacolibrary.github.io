model Vinblastine_Toso1995_reference
  parameter Real Cl_ref = 2.4500000000000003e-05 "Cl [m3/s]";
  parameter Real Vd_ref = 5.292 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.8109741,
    adminMass = 1e-05
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About vinblastine</h4><p>Vinblastine, a Vinca alkaloid, is a cancer medicine used against tumours such as Hodgkin's lymphoma, breast, testicular and kidney cancer, Kaposi's sarcoma, and also certain blood and immune disorders. It remains an approved medicine and is included on the WHO list of essential medicines, so it is widely used in cancer treatment worldwide.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q282629\">Wikidata Q282629</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>vinblastine</td></tr><tr><td>population:</td><td>review reference</td></tr><tr><td>source_paper:</td><td>Toso_1995</td></tr><tr><td>measured_compound:</td><td>vinblastine</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>vinblastine 810.974 g/mol (drugbank)</td></tr></table><h4>Interpretation flags</h4><ul><li>built from REVIEW reference values (Toso_1995) — secondary source</li><li>volume reported by review</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 777600, Tolerance = 1e-9, Interval = 1));
end Vinblastine_Toso1995_reference;
