% Run (SimBiology): build model + dose, simulate 0..1344.0 h, plot.
p = Vinblastine_Zhou1990_estimated_parameters_vc_l_h_kg_params();
[model, dose, variant] = build_sb_pk(p);
sd = simulate_sb(model, variant, dose, 1344.0);
