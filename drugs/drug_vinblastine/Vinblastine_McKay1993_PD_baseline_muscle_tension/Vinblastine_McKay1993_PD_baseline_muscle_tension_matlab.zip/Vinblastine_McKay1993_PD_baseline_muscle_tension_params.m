function p = Vinblastine_McKay1993_PD_baseline_muscle_tension_params()
% Vinblastine_McKay1993_PD_baseline_muscle_tension_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% vinblastine McKay_1993::baseline_muscle_tension: sigmoid_emax exposure-response sweep (response = E0 + Emax*frac). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one pM per second, in SI inside (kg/m3, s). Response baseline muscle tension in g. Driver: vinblastine (cited_pk).
p.E0 = 0.0;
p.Emax = 0.00061;
p.EC50 = 88.0;
p.gamma = 1.0;
p.slope = 0.0;
p.exposure_per_s = 1.0;
p.stop_time = 880.0;
p.form = 'E0 + Emax*frac';
end
