function p = Vinblastine_PiwnicaWorms1995_PD_tc_sestamibi_params()
% Vinblastine_PiwnicaWorms1995_PD_tc_sestamibi_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% vinblastine Piwnica-Worms_1995::Tc_SESTAMIBI: sigmoid_emax exposure-response sweep (response = E0 + Emax*frac). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one pM per second, in SI inside (kg/m3, s). Response Tc-SESTAMIBI in fmol (mg of protein)-1 (nM,)-1. Driver: vinblastine (cited_pk).
p.E0 = 0.0;
p.Emax = -72.0;
p.EC50 = 13.0;
p.gamma = 1.1;
p.slope = 0.0;
p.exposure_per_s = 1.0;
p.stop_time = 130.0;
p.form = 'E0 + Emax*frac';
end
