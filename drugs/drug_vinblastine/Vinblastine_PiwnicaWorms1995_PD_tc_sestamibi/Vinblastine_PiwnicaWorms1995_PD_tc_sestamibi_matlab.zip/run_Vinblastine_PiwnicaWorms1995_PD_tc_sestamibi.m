% run_Vinblastine_PiwnicaWorms1995_PD_tc_sestamibi  Evaluate the exposure-response curve and plot response against exposure.
% A sweep is a static map: no ODE solver is needed. exposure runs 0..stop_time*exposure_per_s.
p = Vinblastine_PiwnicaWorms1995_PD_tc_sestamibi_params();
exposure = linspace(0, p.stop_time * p.exposure_per_s, 501);
frac = exposure.^p.gamma ./ (p.EC50^p.gamma + exposure.^p.gamma);
E0 = p.E0; Emax = p.Emax; slope = p.slope;
response = E0 + Emax.*frac;
figure; plot(exposure, response, 'LineWidth', 1.5); grid on;
xlabel('exposure [pM]'); ylabel('response [fmol (mg of protein)-1 (nM,)-1]'); title('Vinblastine_PiwnicaWorms1995_PD_tc_sestamibi', 'Interpreter', 'none');
writematrix([exposure(:) response(:)], 'Vinblastine_PiwnicaWorms1995_PD_tc_sestamibi.csv');
