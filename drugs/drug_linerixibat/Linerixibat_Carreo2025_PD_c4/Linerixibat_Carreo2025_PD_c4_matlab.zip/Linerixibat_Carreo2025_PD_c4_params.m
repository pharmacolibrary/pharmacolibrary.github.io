function p = Linerixibat_Carreo2025_PD_c4_params()
% Linerixibat_Carreo2025_PD_c4_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% linerixibat Carreño_2025::C4: indirect_response_iii exposure-response sweep (response = E0*(1 + Emax*frac)). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one mg/h per second, in SI inside (kg/m3, s). Response C4 in ng/mL. Driver: linerixibat (dose_only).
p.E0 = 1.19e-05;
p.Emax = 5.55;
p.EC50 = 8.416666666666666e-10;
p.gamma = 1.0;
p.slope = 0.0;
p.exposure_per_s = 2.77777777778e-10;
p.stop_time = 31.0;
p.form = 'E0*(1 + Emax*frac)';
end
