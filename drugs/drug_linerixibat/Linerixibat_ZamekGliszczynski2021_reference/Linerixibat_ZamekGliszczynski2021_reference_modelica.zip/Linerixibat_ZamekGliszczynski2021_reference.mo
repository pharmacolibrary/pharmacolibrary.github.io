model Linerixibat_ZamekGliszczynski2021_reference
  parameter Real Cl_ref = 1.7194444444444445e-05 "Cl [m3/s]";
  parameter Real Vd_ref = 0.016300000000000002 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.5466799999999999,
    adminMass = 1e-05
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>linerixibat</td></tr><tr><td>population:</td><td>healthy male volunteers</td></tr><tr><td>source_paper:</td><td>Zamek-Gliszczynski_2021</td></tr><tr><td>measured_compound:</td><td>linerixibat</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>linerixibat 546.68 g/mol (drugbank)</td></tr></table><h4>Interpretation flags</h4><ul><li>unit_dimension_unknown: 'fold' (CLH)</li><li>dropped duplicate Q40 ('fraction absorbed', value 0.167) — already have one for this compound</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=linerixibat</li><li>held at status:extracted — NIL link or unit issue (mismatch/unknown/normalisation-failed) present</li><li>status held at route_to_review — not promoted</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Linerixibat_ZamekGliszczynski2021_reference;
