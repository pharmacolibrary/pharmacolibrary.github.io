function p = Doxorubicin_Harashima1999_PD_cs_params()
% Doxorubicin_Harashima1999_PD_cs_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% doxorubicin Harashima_1999::Cs: linear exposure-response sweep (response = E0 + slope*exposure). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one mg/ml per second, in SI inside (kg/m3, s). Response Cs in its own unit. Driver: free doxorubicin (conc_no_pk).
p.E0 = 0.0;
p.Emax = 0.0;
p.EC50 = 1.0;
p.gamma = 1.0;
p.slope = 58320.000000000015;
p.exposure_per_s = 1.0;
p.stop_time = 1000.0;
p.form = 'E0 + slope*exposure';
end
