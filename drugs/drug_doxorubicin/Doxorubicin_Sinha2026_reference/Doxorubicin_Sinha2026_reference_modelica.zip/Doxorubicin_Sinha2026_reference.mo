model Doxorubicin_Sinha2026_reference
  parameter Real Cl_ref = 4.8611111111111115e-05 "Cl [m3/s]";
  parameter Real Vd_ref = 0.05 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.5435193,
    adminMass = 0.0001,
    ka = 0.0001388888888888889,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About doxorubicin</h4><p>Doxorubicin is a chemotherapy drug used to treat many cancers, including breast and ovarian cancer, various lymphomas, and several leukemias. It is widely used and appears on the WHO essential medicines list; several doxorubicin products are authorised in the European Union.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q18936\">Wikidata Q18936</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>doxorubicin</td></tr><tr><td>population:</td><td>review reference</td></tr><tr><td>source_paper:</td><td>Sinha_2026</td></tr><tr><td>measured_compound:</td><td>doxorubicin</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C_enteral: apparent (/F) parameterization ⇒ extravascular dosing</td></tr><tr><td>molar_masses:</td><td>doxorubicin 543.519 g/mol (drugbank)</td></tr></table><p><b>Defaulted (base-class default used):</b> ka, Tlag.</p><h4>Interpretation flags</h4><ul><li>built from REVIEW reference values (Sinha_2026) — secondary source</li><li>volume reported by review</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Doxorubicin_Sinha2026_reference;
