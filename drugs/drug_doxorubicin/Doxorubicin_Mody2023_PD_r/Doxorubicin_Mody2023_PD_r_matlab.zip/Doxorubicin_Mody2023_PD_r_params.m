function p = Doxorubicin_Mody2023_PD_r_params()
% Doxorubicin_Mody2023_PD_r_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% doxorubicin Mody_2023::R: indirect_response_i exposure-response sweep (response = E0*(1 - Emax*frac)). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one µM per second, in SI inside (kg/m3, s). Response R in %. Driver: doxorubicin (pk_record).
p.E0 = 1.01;
p.Emax = 0.0697;
p.EC50 = 0.107;
p.gamma = 1.0;
p.slope = 0.0;
p.exposure_per_s = 1.0;
p.stop_time = 1.1;
p.form = 'E0*(1 - Emax*frac)';
end
