function p = Doxorubicin_PrezBlanco2016_1_params()
% Auto-generated parent-metabolite PK model (clinical units: mg, L, h).
%   drug: doxorubicin   source: Pérez-Blanco_2016 / 1   PK_3M_9C parent + 1 metabolite(s), 5 compartments, IV bolus
%   dA/dt = K*A; C = A./V. K(i,j) is the rate [1/h] at which compartment j feeds i:
%   a metabolic conversion carries MW_dst/MW_src, so one molecule forms one molecule.
%   molar masses: C_central=543.519 g/mol C_M1=545.541 g/mol
  p.name  = 'Doxorubicin_PrezBlanco2016_1_params';
  p.drug  = 'doxorubicin';
  p.kind  = 'network';
  p.template = 'PK_3M_9C';
  p.states = {'central', 'peripheral', 'peripheral2', 'central_M1', 'peripheral_M1'};
  p.V = [17.7, 1830.0, 71.00000000000001, 79.8, 653.0];          % compartment volumes [L]
  p.K = [-0.5932203389830508, 0.0018579234972677596, 0.07605633802816901, 0.0, 0.0;
         0.192090395480226, -0.0018579234972677596, 0.0, 0.0, 0.0;
         0.3050847457627119, 0.0, -0.07605633802816901, 0.0, 0.0;
         0.014171160441570024, 0.0, 0.0, -5.790726817042607, 0.6493108728943339;
         0.0, 0.0, 0.0, 5.31328320802005, -0.6493108728943339];
  p.route = 'iv_bolus';        % 'oral' | 'iv_bolus'
  p.depot = false;
  p.dose_into = 1;   % central
  p.ka = 60.0;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h] (in dose_start)
  p.dose = 10.0;             % dose [mg]
  p.dose_start = 0.016666666666666666;   % dose enters from [h] ...
  p.dose_duration = 0.16666666666666666;   % ... at a constant rate for [h]
  p.out_idx = [1.0, 4.0];
  p.out_names = {'C_central', 'C_M1'};
  p.out_labels = {'doxorubicin', 'doxorubicinol'};
end
