function dA = network_rhs(t, A, p, dosing)
% Parent-metabolite network: state A = [A_depot (if oral); A_1 ... A_n] in mg.
% dA/dt = K*A over the compartments; while dosing, the dose (F*dose when oral) enters at
% a constant rate (into the depot when oral, then ka*A_depot into p.dose_into).
  off = double(p.depot);
  dA = zeros(numel(A), 1);
  dA(off+1:end) = p.K * A(off+1:end);
  rin = 0;
  if dosing, rin = p.F * p.dose / p.dose_duration; end
  if p.depot
     r = p.ka * A(1);
     dA(1) = rin - r;
     dA(off + p.dose_into) = dA(off + p.dose_into) + r;
  else
     dA(off + p.dose_into) = dA(off + p.dose_into) + rin;
  end
end
