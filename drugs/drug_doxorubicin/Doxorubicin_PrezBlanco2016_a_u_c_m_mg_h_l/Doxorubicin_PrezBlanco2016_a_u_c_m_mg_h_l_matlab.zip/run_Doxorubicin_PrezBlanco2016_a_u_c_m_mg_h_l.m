% Run: build params, simulate 0..37.0 h, plot every molecule + save Doxorubicin_PrezBlanco2016_a_u_c_m_mg_h_l.png/.csv/.json.
% Interactive display (keep the window open):  octave --persist run_Doxorubicin_PrezBlanco2016_a_u_c_m_mg_h_l.m
here = fileparts(mfilename('fullpath'));
p = Doxorubicin_PrezBlanco2016_a_u_c_m_mg_h_l_params();
out = simulate_network(p, 0:0.05:37.0);

fig = figure; semilogy(out.t, max(out.C, 1e-12), 'LineWidth', 1.5); grid on;
legend(p.out_labels, 'Location', 'northeast');
xlabel('time [h]'); ylabel('concentration [mg/L]');
title('doxorubicin — Pérez-Blanco_2016 (parent + metabolites)');
print(fig, fullfile(here, 'Doxorubicin_PrezBlanco2016_a_u_c_m_mg_h_l.png'), '-dpng', '-r150');

fid = fopen(fullfile(here, 'Doxorubicin_PrezBlanco2016_a_u_c_m_mg_h_l.csv'), 'w');
fprintf(fid, 'time_h');
fprintf(fid, ',%s_mg_per_L', p.out_names{:});
fprintf(fid, '\n');
fmt = ['%.10g', repmat(',%.10g', 1, numel(p.out_names)), '\n'];
fprintf(fid, fmt, [out.t(:), out.C].');
fclose(fid);

fid = fopen(fullfile(here, 'Doxorubicin_PrezBlanco2016_a_u_c_m_mg_h_l.json'), 'w');
try
  s.model = 'Doxorubicin_PrezBlanco2016_a_u_c_m_mg_h_l'; s.outputs = p.out_names; s.labels = p.out_labels;
  s.Cmax = out.Cmax; s.Tmax = out.Tmax; s.time_h = out.t(:).';
  for j = 1:numel(p.out_names), s.([p.out_names{j} '_mg_per_L']) = out.C(:, j).'; end
  fprintf(fid, '%s', jsonencode(s));
catch
  fprintf(fid, '{"model":"Doxorubicin_PrezBlanco2016_a_u_c_m_mg_h_l"}');
end
fclose(fid);

for j = 1:numel(p.out_names)
  fprintf('%s (%s): Cmax=%.4g mg/L  Tmax=%.3g h\n', p.out_names{j}, p.out_labels{j}, out.Cmax(j), out.Tmax(j));
end
fprintf('wrote Doxorubicin_PrezBlanco2016_a_u_c_m_mg_h_l.png, Doxorubicin_PrezBlanco2016_a_u_c_m_mg_h_l.csv, Doxorubicin_PrezBlanco2016_a_u_c_m_mg_h_l.json\n');
