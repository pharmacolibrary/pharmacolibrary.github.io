// parent + metabolites (doxorubicinol): PK_3M_9C — formed from central; parent 3, metabolites [2]
model Doxorubicin_PrezBlanco2016_a_u_c_total_ng_ml
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_3M_9C(
    Vd1 = 0.0177,
    Vd2 = 1.83,
    Vd3 = 0.07100000000000001,
    q12 = 9.444444444444444e-07,
    q21 = 9.444444444444444e-07,
    q13 = 1.5e-06,
    q31 = 1.5e-06,
    q1_m11 = 6.941666666666666e-08,
    CL1 = 4.0280555555555553e-07,
    Vd1m1 = 0.0798,
    CLm1 = 1.0583333333333334e-05,
    Vd2m1 = 0.653,
    qm11_m12 = 0.00011777777777777778,
    qm12_m11 = 0.00011777777777777778,
    MW = 0.5435193,
    MW_m1 = 0.545541,
    F = 1,
    adminMass = 0,
    infusionMass = 1e-05,
    infusionDuration = 600,
    adminCount = 1
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About doxorubicin</h4><p>Doxorubicin is a chemotherapy drug used to treat many cancers, including breast and ovarian cancer, various lymphomas, and several leukemias. It is widely used and appears on the WHO essential medicines list; several doxorubicin products are authorised in the European Union.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q18936\">Wikidata Q18936</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>doxorubicin</td></tr><tr><td>population:</td><td>adults with non-Hodgkin's lymphoma</td></tr><tr><td>source_paper:</td><td>Pérez-Blanco_2016</td></tr><tr><td>measured_compound:</td><td>doxorubicin and doxorubicinol</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>parent_metabolite</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>tab_2</td></tr><tr><td>input:</td><td>PK_3M_9C: IV / parenteral into the parent central compartment; formation of doxorubicinol: fm=0.147 × CL; dose 10 mg (library default)</td></tr><tr><td>molar_masses:</td><td>doxorubicin 543.519 g/mol (drugbank); doxorubicin and doxorubicinol 545.541 g/mol (pubchem); doxorubicinol 545.541 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>unit_dimension_unknown: 'l h' (CL)</li><li>unit_dimension_unknown: 'l h' (Q)</li><li>unit_dimension_unknown: 'l h' (Q2)</li><li>unit_dimension_unknown: 'l h' (CL)</li><li>unit_dimension_unknown: 'l h' (Q)</li><li>dropped unlinked row (NIL): 'Leukopenia' — extend the ontology if this is a real PK parameter (source ['Pérez-Blanco_2016_table_2:row1:col8', 'Pérez-Blanco_2016_table_2:row1:col11', 'Pérez-Blanco_2016_table_2:row1:col13', 'Pérez-Blanco_2016_table_2:row1:col14'])</li><li>dropped unlinked row (NIL): 'Neutropenia' — extend the ontology if this is a real PK parameter (source ['Pérez-Blanco_2016_table_2:row2:col8', 'Pérez-Blanco_2016_table_2:row2:col11', 'Pérez-Blanco_2016_table_2:row2:col13', 'Pérez-Blanco_2016_table_2:row2:col14'])</li><li>dropped unlinked row (NIL): 'Leucocyte count (10' — extend the ontology if this is a real PK parameter (source ['Pérez-Blanco_2016_table_2:row6:col1', 'Pérez-Blanco_2016_table_2:row6:col4', 'Pérez-Blanco_2016_table_2:row6:col8', 'Pérez-Blanco_2016_table_2:row6:col11', 'Pérez-Blanco_2016_table_2:row8:col1', 'Pérez-Blanco_2016_table_2:row8:col4', 'Pérez-Blanco_2016_table_2:row8:col8', 'Pérez-Blanco_2016_table_2:row8:col11'])</li><li>dropped unlinked row (NIL): 'Neutrophil count (10' — extend the ontology if this is a real PK parameter (source ['Pérez-Blanco_2016_table_2:row7:col1', 'Pérez-Blanco_2016_table_2:row7:col4', 'Pérez-Blanco_2016_table_2:row7:col8', 'Pérez-Blanco_2016_table_2:row7:col11', 'Pérez-Blanco_2016_table_2:row9:col1', 'Pérez-Blanco_2016_table_2:row9:col4', 'Pérez-Blanco_2016_table_2:row9:col8', 'Pérez-Blanco_2016_table_2:row9:col11'])</li><li>implicit units: 'CL (l h' → L/h (from the paper text: 'The results state: “Population estimates for parent drug (CL) and metabolite (CLm) clearance were 62 l h−1 and 27 l h−1,')</li><li>implicit units: 'Q 2 (l h' → L/h (from the popPK convention: 'Q2 is an intercompartmental clearance (defined in the table footnote); intercompartmental clearances are conventionally ')</li><li>implicit units: 'Q 3 (l h' → L/h (from the popPK convention: 'Q3 is an intercompartmental clearance (defined in the table footnote); intercompartmental clearances are conventionally ')</li><li>implicit units: 'CL m (l h' → L/h (from the paper text: 'The results state: “Population estimates for parent drug (CL) and metabolite (CLm) clearance were 62 l h−1 and 27 l h−1,')</li><li>implicit units: 'Q 5 (l h' → L/h (from the popPK convention: 'Q5 is an intercompartmental clearance (defined in the table footnote); intercompartmental clearances are conventionally ')</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=doxorubicin and doxorubicinol</li><li>template fit: PK_3M_9C — formed from central; parent 3, metabolites [2]</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 133200, Tolerance = 1e-9, Interval = 1));
end Doxorubicin_PrezBlanco2016_a_u_c_total_ng_ml;
