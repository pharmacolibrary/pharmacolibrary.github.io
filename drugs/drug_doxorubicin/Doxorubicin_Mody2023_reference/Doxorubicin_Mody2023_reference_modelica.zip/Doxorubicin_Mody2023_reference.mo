model Doxorubicin_Mody2023_reference
  parameter Real Cl_ref = 1.4805555555555555e-05 "Cl [m3/s]";
  parameter Real Vd_ref = 0.0177 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.5435193,
    adminMass = 1e-05,
    k12 = 0.000921217827997489,
    k21 = 8.910139647844566e-06
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About doxorubicin</h4><p>Doxorubicin is a chemotherapy drug used to treat many cancers, including breast and ovarian cancer, various lymphomas, and several leukemias. It is widely used and appears on the WHO essential medicines list; several doxorubicin products are authorised in the European Union.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q18936\">Wikidata Q18936</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>doxorubicin</td></tr><tr><td>population:</td><td>adults</td></tr><tr><td>source_paper:</td><td>Mody_2023</td></tr><tr><td>measured_compound:</td><td>doxorubicin</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>Tab2</td></tr><tr><td>input:</td><td>PK_2C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>doxorubicin 543.519 g/mol (drugbank)</td></tr></table><h4>Interpretation flags</h4><ul><li>unit_dimension_unknown: 'L/h/1.8m2' (CL)</li><li>unit_dimension_unknown: 'L/1.8m2' (V)</li><li>unit_dimension_unknown: 'L/h/1.8m2' (Q)</li><li>unit_dimension_unknown: 'L/1.8m2' (V2)</li><li>unit_dimension_unknown: 'L/h/1.8m2' (Q3)</li><li>unit_dimension_unknown: 'L/1.8m2' (V3)</li><li>dropped duplicate Q61 ('V (L)', value '14.6') — already have one for this compound</li><li>implicit units: 'CL (L/h/1.8m2)' → L/h (from the popPK convention: 'The parameter is Total Clearance (CL). The paper text does not explicitly state the unit in the provided excerpts, but t')</li><li>implicit units: 'V (L/1.8m2)' → L (from the popPK convention: 'The parameter is Volume of Distribution (V). The paper text does not explicitly state the unit in the provided excerpts,')</li><li>implicit units: 'Q2 (L/h/1.8m2)' → L/h (from the popPK convention: 'The parameter is Intercompartmental Clearance (Q2). The paper text does not explicitly state the unit in the provided ex')</li><li>implicit units: 'V2 (L/1.8m2)' → L (from the popPK convention: 'The parameter is Volume of Distribution of the peripheral compartment (V2). The paper text does not explicitly state the')</li><li>implicit units: 'Q3 (L/h/1.8m2)' → L/h (from the popPK convention: 'The parameter is Intercompartmental Clearance (Q3). The paper text does not explicitly state the unit in the provided ex')</li><li>implicit units: 'V3 (L/1.8m2)' → L (from the popPK convention: 'The parameter is Volume of Distribution of the second peripheral compartment (V3). The paper text does not explicitly st')</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=doxorubicin</li><li>structure disagreement: deterministic 2C vs LLM 3C — review compartment count</li><li>gap-filled Q83 (tlag) from Bérczi_1993's review values (primary lacked it)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Doxorubicin_Mody2023_reference;
