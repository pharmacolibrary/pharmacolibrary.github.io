function p = Doxorubicin_Choi2021_PD_w_params()
% Doxorubicin_Choi2021_PD_w_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% doxorubicin Choi_2021::w: linear exposure-response sweep (response = E0 + slope*exposure). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one milligram per liter per second, in SI inside (kg/m3, s). Response w in cm 3. Driver: doxorubicin (pk_record).
p.E0 = 0.0386;
p.Emax = 0.0;
p.EC50 = 1.0;
p.gamma = 1.0;
p.slope = 13.8;
p.exposure_per_s = 1.0;
p.stop_time = 1000.0;
p.form = 'E0 + slope*exposure';
end
