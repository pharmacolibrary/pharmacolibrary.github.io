function p = Doxorubicin_Dabour2026_PD_gdf15_params()
% Doxorubicin_Dabour2026_PD_gdf15_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% doxorubicin Dabour_2026::GDF15: indirect_response_iii exposure-response sweep (response = E0*(1 + Emax*frac)). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one μg/mL per second, in SI inside (kg/m3, s). Response GDF15 in pg/mL. Driver: DOX (conc_no_pk).
p.E0 = 7.448660000000001e-07;
p.Emax = 16.837;
p.EC50 = 3.8499999999999994e-05;
p.gamma = 1.0;
p.slope = 0.0;
p.exposure_per_s = 0.001;
p.stop_time = 0.39;
p.form = 'E0*(1 + Emax*frac)';
end
