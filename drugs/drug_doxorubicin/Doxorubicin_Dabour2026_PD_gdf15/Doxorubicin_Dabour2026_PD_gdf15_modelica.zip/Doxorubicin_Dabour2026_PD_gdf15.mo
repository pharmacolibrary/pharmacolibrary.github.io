model Doxorubicin_Dabour2026_PD_gdf15
  "indirect_response_iii exposure-response sweep — Dabour_2026 :: GDF15 (GDF15)"
  extends Pharmacolibrary.Interfaces.PartialExposureResponseSweep(
    E0 = 7.44866e-07,      // [kg/m3; pg/mL × 1e-09]
    Emax = 16.837,  // type III effect term
    EC50 = 3.85e-05,  // [kg/m3; μg/mL × 0.001]
    gamma = 1,
    exposure_per_s = 0.001);   // 1 μg/mL per second
equation
  response = E0*(1 + Emax*frac);   // steady state, indirect response type III
  // defaulted: gamma
  annotation(experiment(StartTime = 0, StopTime = 0.39, Interval = 0.00078),
    Documentation(info = "<html><body><!-- drug-about --><h4>About doxorubicin</h4><p>Doxorubicin is a chemotherapy drug used to treat many cancers, including breast and ovarian cancer, various lymphomas, and several leukemias. It is widely used and appears on the WHO essential medicines list; several doxorubicin products are authorised in the European Union.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q18936\">Wikidata Q18936</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h4>Doxorubicin_Dabour2026_PD_gdf15</h4><p>The steady-state exposure-response curve of Dabour MS et al., <i>Clinical and translational science 19(5):e70595</i> 2026 (<a href=\"https://doi.org/10.1111/cts.70595\">doi:10.1111/cts.70595</a>) — GDF15 [pg/mL] against doxorubicin μg/mL — obtained by sweeping the driver instead of simulating a dose. Model family: indirect_response_iii.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    =    744.866 pg/mL    drug-free response (baseline) (R 0, Q336)
  Emax  =     16.837          maximal effect term (E max, Q320)
  EC50  =     0.0385 μg/mL    exposure at half of the maximal effect term (EC50, Q321)
  gamma = (library default) Hill coefficient</pre><p>The algebra is <code>response = E0*(1 + Emax*frac)</code>; this model only supplies the numbers. The x axis is one μg/mL of doxorubicin per second of simulated time (exposure is in kg/m3): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 7.449e-07   (drug-free)
  exposure = EC50 (0.0385 μg/mL)  response 7.016e-06
  exposure -> infinity  response 1.329e-05</pre></body></html>"));
end Doxorubicin_Dabour2026_PD_gdf15;
