function p = Ketanserin_Trenk1983_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: ketanserin   source: Trenk_1983 / reference   route: iv_bolus
  % Vc is the record's Vss — no central volume was reported; 1-compartment reading
  p.name  = 'Ketanserin_Trenk1983_reference_params';
  p.drug  = 'ketanserin';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'iv_bolus';        % 'oral' | 'iv_bolus'
  p.depot = false;             % oral -> first-order absorption depot
  p.Vc = 231.0;                % central volume [L]
  p.CL = 27.3;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.0;                % absorption rate [1/h]
  p.F  = 0.51;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 40.0;             % dose [mg]
end
