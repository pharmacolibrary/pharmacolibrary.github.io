model Ketanserin_Hanff2005_reference
  parameter Real Cl_ref = 1.0527777777777777e-05 "Cl [m3/s]";
  parameter Real Vd_ref = 0.03808000000000001 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.395434,
    adminMass = 4e-05,
    ka = 0.0001388888888888889,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><h3>ModelCard</h3><table><tr><td>drug:</td><td>ketanserin</td></tr><tr><td>population:</td><td>pre-eclamptic patients</td></tr><tr><td>source_paper:</td><td>Hanff_2005</td></tr><tr><td>measured_compound:</td><td>ketanserin</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C_enteral: apparent (/F) parameterization ⇒ extravascular dosing</td></tr><tr><td>molar_masses:</td><td>ketanserin 395.434 g/mol (drugbank)</td></tr></table><p><b>Defaulted (base-class default used):</b> ka, Tlag.</p><h4>Interpretation flags</h4><ul><li>the dosed compound is ketanserin; the compartment is ketanserin. Input enters at the reported formation rate, so formation is already accounted for in the input step and the simulated concentration is ketanserin, not ketanserin</li><li>apparent parameters (CLm/F, Vm/F) already contain F and the metabolised fraction, so F=1 and no molar correction is applied — adding either would double-count it</li><li>ketanserin's own concentration-time course is not produced by this model</li><li>apparent-ness (ontology-grounded): parameterization=apparent, measured_compound=ketanserin</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Ketanserin_Hanff2005_reference;
