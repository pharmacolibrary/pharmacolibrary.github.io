function p = Mecillinam_Koumaki2023_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: mecillinam   source: Koumaki_2023 / reference   route: iv_bolus
  % estimated (absent from source): F
  p.name  = 'Mecillinam_Koumaki2023_reference_params';
  p.drug  = 'mecillinam';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'iv_bolus';        % 'oral' | 'iv_bolus'
  p.depot = false;             % oral -> first-order absorption depot
  p.Vc = 8.6184;                % central volume [L]
  p.CL = 14.49;                % clearance [L/h]
  p.Vp = [5.6392];             % peripheral volumes [L]
  p.Q  = [28.308];             % inter-compartmental clearances [L/h]
  p.ka = 0.0;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 1200.0;             % dose [mg]
end
