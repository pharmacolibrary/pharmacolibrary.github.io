model Mecillinam_Koumaki2023_reference
  parameter Real Cl_ref = 4.025e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.0086184 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.325426,
    adminMass = 0.0012,
    k12 = 0.0009123889971843188,
    k21 = 0.0013944058258854683
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About mecillinam</h4><p>Mecillinam (amdinocillin) is an extended-spectrum penicillin antibiotic used to treat bacterial infections, especially urinary tract infections. It has been withdrawn from the market in some countries but remains approved and used elsewhere, mainly for urinary infections.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q13019044\">Wikidata Q13019044</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>mecillinam</td></tr><tr><td>population:</td><td>healthy volunteers</td></tr><tr><td>source_paper:</td><td>Koumaki_2023</td></tr><tr><td>measured_compound:</td><td>mecillinam</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>tab1</td></tr><tr><td>input:</td><td>PK_2C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>mecillinam 325.426 g/mol (drugbank)</td></tr></table><h4>Interpretation flags</h4><ul><li>table section iiv: 'CL (mL/min/kg)' routed out of structural estimates ('Interindividual variability (%)')</li><li>table section iiv: 'V1 (mL/kg)' routed out of structural estimates ('Interindividual variability (%)')</li><li>table section iiv: 'V2 (mL/kg)' routed out of structural estimates ('Interindividual variability (%)')</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=mecillinam</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Mecillinam_Koumaki2023_reference;
