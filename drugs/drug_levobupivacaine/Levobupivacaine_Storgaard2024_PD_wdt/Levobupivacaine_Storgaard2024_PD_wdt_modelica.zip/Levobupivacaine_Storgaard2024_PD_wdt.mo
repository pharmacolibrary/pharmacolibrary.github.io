model Levobupivacaine_Storgaard2024_PD_wdt
  "linear exposure-response sweep — Storgaard_2024 :: WDT (Warmth detection threshold)"
  extends Pharmacolibrary.Interfaces.PartialExposureResponseSweep(
    E0 = 36.7,      // [C]
    Emax = 0, EC50 = 1,      // unused by a line
    exposure_per_s = 1e-06);
  parameter Real slope = 0.0418   "[C/μg-1]";
equation
  response = E0 + slope*exposure;
  annotation(experiment(StartTime = 0, StopTime = 1000, Interval = 2),
    Documentation(info = "<html><body><!-- drug-about --><h4>About levobupivacaine</h4><p>Levobupivacaine is a local anesthetic used to relieve pain. It is an approved amide-type local anesthetic, though some uses remain investigational.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q3272027\">Wikidata Q3272027</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h4>Levobupivacaine_Storgaard2024_PD_wdt</h4><p>The steady-state exposure-response curve of Storgaard IK et al., <i>Basic &amp; clinical pharmacology &amp; toxicology 134(5):676–685</i> 2024 (<a href=\"https://doi.org/10.1111/bcpt.14004\">doi:10.1111/bcpt.14004</a>) — Warmth detection threshold [C] against bupivacaine μg/L — obtained by sweeping the driver instead of simulating a dose. Model family: linear.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    =       36.7 C        drug-free response (baseline) (Baseline effect; intercept of the linear correlation between plasma concentration and effect, Q324)
  slope =     0.0418 C/μg-1   change in response per unit of exposure (Slope of linear correlation between plasma concentration and effect, Q335)</pre><p>The algebra is <code>response = E0 + slope*exposure</code>; this model only supplies the numbers. The x axis is one μg/L of bupivacaine per second of simulated time (exposure is in kg/m3): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 36.7   (drug-free)</pre></body></html>"));
end Levobupivacaine_Storgaard2024_PD_wdt;
