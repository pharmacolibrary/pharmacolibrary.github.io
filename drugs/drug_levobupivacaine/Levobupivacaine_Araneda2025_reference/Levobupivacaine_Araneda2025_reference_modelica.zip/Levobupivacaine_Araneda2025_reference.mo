model Levobupivacaine_Araneda2025_reference
  parameter Real Cl_ref = 4.8e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.0419 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.2884277,
    adminMass = 1e-05
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About levobupivacaine</h4><p>Levobupivacaine is a local anesthetic used to relieve pain. It is an approved amide-type local anesthetic, though some uses remain investigational.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q3272027\">Wikidata Q3272027</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>levobupivacaine</td></tr><tr><td>population:</td><td>patients undergoing video-assisted thoracoscopy and TAP blocks, and healthy volunteers</td></tr><tr><td>source_paper:</td><td>Araneda_2025</td></tr><tr><td>measured_compound:</td><td>levobupivacaine</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>levobupivacaine 288.428 g/mol (drugbank)</td></tr></table><h4>Interpretation flags</h4><ul><li>dropped unlinked row (NIL): 'Simulated doses' — extend the ontology if this is a real PK parameter (source ['Araneda_2025:abstract'])</li><li>dropped unlinked row (NIL): 'extended dosing' — extend the ontology if this is a real PK parameter (source ['Araneda_2025:abstract'])</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=levobupivacaine</li><li>held at status:extracted — NIL link or unit issue (mismatch/unknown/normalisation-failed) present</li><li>status held at route_to_review — not promoted</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Levobupivacaine_Araneda2025_reference;
