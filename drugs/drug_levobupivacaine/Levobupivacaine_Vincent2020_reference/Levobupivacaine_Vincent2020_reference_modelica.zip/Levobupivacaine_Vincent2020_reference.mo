model Levobupivacaine_Vincent2020_reference
  parameter Real Cl_ref = 2.4999999999999998e-06 "Cl [m3/s]";
  parameter Real cov_weight_0 = 0 "weight covariate";
  parameter Real Vd_ref = 0.014 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref*(1 + (0.87)*cov_weight_0),
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.2884277,
    adminMass = 2.8e-05,
    ka = 0.003,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About levobupivacaine</h4><p>Levobupivacaine is a local anesthetic used to relieve pain. It is an approved amide-type local anesthetic, though some uses remain investigational.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q3272027\">Wikidata Q3272027</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>levobupivacaine</td></tr><tr><td>population:</td><td>children</td></tr><tr><td>source_paper:</td><td>Vincent_2020</td></tr><tr><td>measured_compound:</td><td>levobupivacaine</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>table 2</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>levobupivacaine 288.428 g/mol (drugbank)</td></tr></table><p><b>Defaulted (base-class default used):</b> Tlag.</p><h4>Interpretation flags</h4><ul><li>table section iiv: 'Cl/F' routed out of structural estimates ('Between subject variability')</li><li>table section iiv: 'Cl/F' routed out of structural estimates ('Between subject variability')</li><li>table section iiv: 'Cl/F' routed out of structural estimates ('Between subject variability')</li><li>table section iiv: 'V/F' routed out of structural estimates ('Between subject variability')</li><li>table section iiv: 'V/F' routed out of structural estimates ('Between subject variability')</li><li>table section iiv: 'V/F' routed out of structural estimates ('Between subject variability')</li><li>table section iiv: 'Ka' routed out of structural estimates ('Between subject variability')</li><li>table section iiv: 'Ka' routed out of structural estimates ('Between subject variability')</li><li>table section iiv: 'Ka' routed out of structural estimates ('Between subject variability')</li><li>table section iiv: 'Residual variability' routed out of structural estimates ('Between subject variability')</li><li>table section iiv: 'Residual variability' routed out of structural estimates ('Between subject variability')</li><li>table section iiv: 'Residual variability' routed out of structural estimates ('Between subject variability')</li><li>apparent-ness (ontology-grounded): parameterization=apparent, measured_compound=levobupivacaine</li><li>held at status:extracted — NIL link or unit issue (mismatch/unknown/normalisation-failed) present</li><li>status held at route_to_review — not promoted</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Levobupivacaine_Vincent2020_reference;
