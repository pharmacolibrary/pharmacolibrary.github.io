model InsulinHuman_Potocka2011_reference
  parameter Real Cl_ref = 1.2055555555555556e-05 "Cl [m3/s]";
  parameter Real Vd_ref = 0.005 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C_enteral(
    weight = 70.0,
    F = 0.9,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 5.8076289999999995,
    adminMass = 0.0001,
    ka = 0.0006527777777777778,
    Tlag = 0.0,
    k12 = 0.0013277777777777776,
    k21 = 0.00021625045240680416
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About insulin_human</h4><p>Human insulin is an anti-diabetic medication used to treat type-1 diabetes and maturity-onset diabetes of the young type 2. It is widely used and remains authorised in the European Union for diabetes, available in fast-acting, intermediate-acting, long-acting, combined, and inhaled forms.</p><p><small>Summary written by glm-5.3-flash from <a href=&quot;https://www.wikidata.org/wiki/Q50265665&quot;>Wikidata Q50265665</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>insulin_human</td></tr><tr><td>population:</td><td>healthy volunteers</td></tr><tr><td>source_paper:</td><td>Potocka_2011</td></tr><tr><td>measured_compound:</td><td>insulin_human</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_2C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>insulin_human 5807.63 g/mol (pubchem)</td></tr></table><p><b>Defaulted (base-class default used):</b> F, Tlag.</p><h4>Interpretation flags</h4><ul><li>dropped duplicate Q49 ('first-order absorption rate constants associated with subcutaneously administered insulin', value 0.63) — already have one for this compound</li><li>apparent-by-design (ADVISORY, codes unchanged): extravascular dosing with no identifiable F, so these reported disposition parameters are likely apparent unless the model puts first-pass in its structure — Q22 (clearance); Q63 (volume of distribution in the central compartment); Q30 (intercompartmental clearance); Q64 (volume of distribution in the peripheral compartment)</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=insulin_human</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li><li>skipped review gap-fill of TLAG: primary's parameterization (rate-constant / ka-only) does not use it</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end InsulinHuman_Potocka2011_reference;
