model Prednisone_Bouazza2025_reference
  parameter Real Cl_ref = 0.0010558333333333333 "Cl [m3/s]";
  parameter Real Vd_ref = 16.45 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.36045,
    adminMass = 1e-05,
    ka = 0.00033055555555555556,
    Tlag = 612.0
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About prednisone</h4><p>Prednisone is a glucocorticoid used to treat many inflammatory, autoimmune, and allergic conditions, such as arthritis, ulcerative colitis, asthma-related inflammation, and certain cancers and blood disorders. It is widely used in human medicine and is also approved for veterinary use.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q424972\">Wikidata Q424972</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>prednisone</td></tr><tr><td>population:</td><td>systemic lupus erythematosus patients</td></tr><tr><td>source_paper:</td><td>Bouazza_2025</td></tr><tr><td>measured_compound:</td><td>prednisolone</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>bcp70103-tbl-0002</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>prednisolone 360.45 g/mol (pubchem); prednisone 358.428 g/mol (drugbank)</td></tr></table><h4>Interpretation flags</h4><ul><li>the dosed compound is prednisone; the compartment is prednisolone. Input enters at the reported formation rate, so formation is already accounted for in the input step and the simulated concentration is prednisolone, not prednisone</li><li>apparent parameters (CLm/F, Vm/F) already contain F and the metabolised fraction, so F=1 and no molar correction is applied — adding either would double-count it</li><li>prednisone's own concentration-time course is not produced by this model</li><li>column 'covariate effect' classified 'other' by the LLM but kept: the deterministic diagnostic-column test disagrees (a stratum column is a value column, not a statistic)</li><li>column 'covariate effect' classified 'other' by the LLM but kept: the deterministic diagnostic-column test disagrees (a stratum column is a value column, not a statistic)</li><li>column 'covariate effect' classified 'other' by the LLM but kept: the deterministic diagnostic-column test disagrees (a stratum column is a value column, not a statistic)</li><li>dropped unlinked row (NIL): 'βFdose' — extend the ontology if this is a real PK parameter (source ['bcp70103-tbl-0002:row4:col2'])</li><li>metabolite prednisolone: Q27→Q351 — only the metabolite is measured and fm is not identifiable, so its CL/V are apparent (fm-divided)</li><li>apparent-ness (ontology-grounded): parameterization=apparent, measured_compound=prednisolone</li><li>template fit: none — only the metabolite is modelled — no parent compartment</li><li>1C volume normalization: Q290→Q76 (single-compartment model has no central/peripheral split; 'VU/F (L.70 kg−1)' is the general volume)</li><li>row roles (LLM): model_class=compartmental; 8/8 row label(s) assigned, 6 linked by role</li><li>review gap-fill skipped: this record measures 'prednisolone', not prednisone — the review values are the parent's</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Prednisone_Bouazza2025_reference;
