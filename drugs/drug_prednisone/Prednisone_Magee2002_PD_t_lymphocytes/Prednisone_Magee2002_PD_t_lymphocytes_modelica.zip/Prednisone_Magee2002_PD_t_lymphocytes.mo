model Prednisone_Magee2002_PD_t_lymphocytes
  "indirect_response_i exposure-response sweep — Magee_2002 :: T-lymphocytes (T-lymphocyte cell counts)"
  extends Pharmacolibrary.Interfaces.PartialExposureResponseSweep(
    E0 = 2.02657807309,      // [cells ml-1]
    Emax = 1,  // type I effect term
    EC50 = 9.15e-06,  // [kg/m3; ng ml-1 × 1e-06]
    gamma = 1,
    exposure_per_s = 1e-06);   // 1 ng ml-1 per second
equation
  response = E0*(1 - Emax*frac);   // steady state, indirect response type I
  // e0_from_kin_kout: no baseline row; E0 = kin/kout (0.61/0.301 = 2.027) — the paper's stated baseline may differ
  // defaulted: Emax
  // defaulted: gamma
  annotation(experiment(StartTime = 0, StopTime = 92, Interval = 0.184),
    Documentation(info = "<html><body><!-- drug-about --><h4>About prednisone</h4><p>Prednisone is a glucocorticoid used to treat many inflammatory, autoimmune, and allergic conditions, such as arthritis, ulcerative colitis, asthma-related inflammation, and certain cancers and blood disorders. It is widely used in human medicine and is also approved for veterinary use.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q424972\">Wikidata Q424972</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h4>Prednisone_Magee2002_PD_t_lymphocytes</h4><p>The steady-state exposure-response curve of Magee MH et al., <i>British journal of clinical pharmacology 53(5):474–484</i> 2002 (<a href=\"https://doi.org/10.1046/j.1365-2125.2002.01567.x\">doi:10.1046/j.1365-2125.2002.01567.x</a>) — T-lymphocyte cell counts [cells ml-1] against prednisolone ng ml-1 — obtained by sweeping the driver instead of simulating a dose. Model family: indirect_response_i.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = 2.02657807309 cells ml-1 drug-free response (baseline) (kin/kout, Q327/Q328)
  Emax  = (library default) maximal effect term
  EC50  =       9.15 ng ml-1  exposure at half of the maximal effect term (IC50, Q322)
  gamma = (library default) Hill coefficient</pre><p>The algebra is <code>response = E0*(1 - Emax*frac)</code>; this model only supplies the numbers. The x axis is one ng ml-1 of prednisolone per second of simulated time (exposure is in kg/m3): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 2.027   (drug-free)
  exposure = EC50 (9.15 ng ml-1)  response 1.013
  exposure -> infinity  response 0</pre></body></html>"));
end Prednisone_Magee2002_PD_t_lymphocytes;
