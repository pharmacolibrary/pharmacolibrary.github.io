model Prednisone_Magee2002_reference
  parameter Real Cl_ref = 3.75e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.0448 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.36045,
    adminMass = 1.89e-05,
    ka = 0.0015611111111111112,
    Tlag = 1018.8
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About prednisone</h4><p>Prednisone is a glucocorticoid used to treat many inflammatory, autoimmune, and allergic conditions, such as arthritis, ulcerative colitis, asthma-related inflammation, and certain cancers and blood disorders. It is widely used in human medicine and is also approved for veterinary use.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q424972\">Wikidata Q424972</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>prednisone</td></tr><tr><td>population:</td><td>healthy adults</td></tr><tr><td>source_paper:</td><td>Magee_2002</td></tr><tr><td>measured_compound:</td><td>prednisolone</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>prednisolone 360.45 g/mol (pubchem); prednisone 358.428 g/mol (drugbank)</td></tr></table><h4>Interpretation flags</h4><ul><li>the dosed compound is prednisone; the compartment is prednisolone. Input enters at the reported formation rate, so formation is already accounted for in the input step and the simulated concentration is prednisolone, not prednisone</li><li>apparent parameters (CLm/F, Vm/F) already contain F and the metabolised fraction, so F=1 and no molar correction is applied — adding either would double-count it</li><li>prednisone's own concentration-time course is not produced by this model</li><li>unit_dimension_unknown: 'hx1' (kabs)</li><li>unit_dimension_unknown: 'lkgx1' (V1/F)</li><li>dropped duplicate Q290 ('V\nc\n/F/TBW(lkgx1)', value 0.59) — already have one for this compound</li><li>unit_dimension_unknown: 'lhx1' (CL/F)</li><li>unit_dimension_unknown: 'lhx1kgx1' (CL/F)</li><li>dropped duplicate Q27 ('CL/F/TBW(lhx1kgx1)', value 0.178) — already have one for this compound</li><li>unit_dimension_unknown: 'ngmlx1h' (AUC)</li><li>unit_dimension_unknown: 'lhx1kg' (CL/F)</li><li>dropped duplicate Q27 ('CL/F/TBW(lhx1kg)', value 0.788) — already have one for this compound</li><li>implicit units: 'k\na\n(hx1)' → 1/h (from the popPK convention: 'The parameter is an absorption rate constant (kabs). In population pharmacokinetics, first-order rate constants are conv')</li><li>implicit units: 'CL/F(lhx1)' → L/h (from the popPK convention: 'The parameter is total clearance (CL/F). In population pharmacokinetics, clearance is conventionally expressed in volume')</li><li>implicit units: 'AUC(ngmlx1h)' → ng·h/mL (from the popPK convention: 'The parameter is Area Under the Curve (AUC). In population pharmacokinetics, AUC is conventionally expressed as concentr')</li><li>metabolite prednisolone: Q27→Q351 — only the metabolite is measured and fm is not identifiable, so its CL/V are apparent (fm-divided)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Prednisone_Magee2002_reference;
