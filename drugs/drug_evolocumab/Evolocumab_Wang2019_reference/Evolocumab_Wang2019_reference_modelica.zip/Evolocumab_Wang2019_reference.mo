model Evolocumab_Wang2019_reference
  parameter Real Cl_ref = 2.777777777777778e-09 "Cl [m3/s]";
  parameter Real Vd_ref = 0.00275 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 0.9,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    adminMass = 0.0001,
    ka = 2.835648148148148e-06,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About evolocumab</h4><p>Evolocumab, a monoclonal antibody that lowers cholesterol, is used to treat dyslipidemias such as hypercholesterolemia and related conditions including coronary artery disease. It is authorised in the European Union and is widely used as a lipid-modifying agent.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q15623825\">Wikidata Q15623825</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>evolocumab</td></tr><tr><td>population:</td><td>Caucasian and Asian populations</td></tr><tr><td>source_paper:</td><td>Wang_2019</td></tr><tr><td>measured_compound:</td><td>evolocumab</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr></table><p><b>Defaulted (base-class default used):</b> F, Tlag.</p><h4>Interpretation flags</h4><ul><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=evolocumab</li><li>molar mass: none found for 'evolocumab' — its concentrations stay mass-only</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li><li>gap-filled Q49 (kabs) from Gibbs_2017's review values (primary lacked it)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 4838400, Tolerance = 1e-9, Interval = 1));
end Evolocumab_Wang2019_reference;
