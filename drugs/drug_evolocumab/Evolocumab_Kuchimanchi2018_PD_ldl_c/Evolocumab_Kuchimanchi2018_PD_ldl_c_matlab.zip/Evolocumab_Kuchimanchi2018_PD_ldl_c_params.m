function p = Evolocumab_Kuchimanchi2018_PD_ldl_c_params()
% Evolocumab_Kuchimanchi2018_PD_ldl_c_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% evolocumab Kuchimanchi_2018::LDL_C: emax exposure-response sweep (response = E0 + Emax*frac). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one (μg/mL)·day per second, in SI inside (kg/m3, s). Response LDL-C in mg/dL. Driver: evolocumab (cited_pk).
p.E0 = 1.4999999999999998;
p.Emax = -0.9969999999999999;
p.EC50 = 51.5;
p.gamma = 1.0;
p.slope = 0.0;
p.exposure_per_s = 1.0;
p.stop_time = 520.0;
p.form = 'E0 + Emax*frac';
end
