model Evolocumab_Kuchimanchi2018_PD_ldl_c
  "emax exposure-response sweep — Kuchimanchi_2018 :: LDL-C (LDL-C)"
  extends Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep(
    E0 = 1.5,      // [kg/m3; mg/dL × 0.01]
    Emax = -0.997,  // [kg/m3; mg/dL × 0.01]
    EC50 = 51.5,  // [(μg/mL)·day]
    gamma = 1,
    exposure_per_s = 1);   // 1 (μg/mL)·day per second
  // imax_as_negative_emax: Imax (Q323) enters SigmoidEmaxSweep as −Emax
  // exposure_unit_unresolved: '(μg/mL)·day' — the x axis is in the paper's unit, not SI
  // defaulted: gamma
  annotation(experiment(StartTime = 0, StopTime = 520, Interval = 1.04),
    Documentation(info = "<html><body><!-- drug-about --><h4>About evolocumab</h4><p>Evolocumab, a monoclonal antibody that lowers cholesterol, is used to treat dyslipidemias such as hypercholesterolemia and related conditions including coronary artery disease. It is authorised in the European Union and is widely used as a lipid-modifying agent.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q15623825\">Wikidata Q15623825</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h4>Evolocumab_Kuchimanchi2018_PD_ldl_c</h4><p>The steady-state exposure-response curve of Kuchimanchi M et al., <i>Journal of pharmacokinetics and pharmacodynamics 45(3):505–522</i> 2018 (<a href=\"https://doi.org/10.1007/s10928-018-9592-y\">doi:10.1007/s10928-018-9592-y</a>) — LDL-C [mg/dL] against evolocumab (μg/mL)·day — obtained by sweeping the driver instead of simulating a dose. Model family: emax.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    =        150 mg/dL    drug-free response (baseline) (Baseline LDL-C, Q324)
  Emax  =      -99.7 mg/dL    maximal effect term (Emax (maximal change in LDL-C following evolocumab administration), Q323)
  EC50  =       51.5 (μg/mL)·day exposure at half of the maximal effect term (EC50 (evolocumab exposure resulting in 50% of maximal effect), Q321)
  gamma = (library default) Hill coefficient</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep\">SigmoidEmaxSweep</a>; this model only supplies the numbers. The x axis is one (μg/mL)·day of evolocumab per second of simulated time: there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 1.5   (drug-free)
  exposure = EC50 (51.5 (μg/mL)·day)  response 1.001
  exposure -> infinity  response 0.503</pre></body></html>"));
end Evolocumab_Kuchimanchi2018_PD_ldl_c;
