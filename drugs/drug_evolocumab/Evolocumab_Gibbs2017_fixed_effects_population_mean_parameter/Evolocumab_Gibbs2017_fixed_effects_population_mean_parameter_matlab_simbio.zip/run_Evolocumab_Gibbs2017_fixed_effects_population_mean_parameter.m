% Run (SimBiology): build model + dose, simulate 0..1008.0 h, plot.
p = Evolocumab_Gibbs2017_fixed_effects_population_mean_parameter_params();
[model, dose, variant] = build_sb_pk(p);
sd = simulate_sb(model, variant, dose, 1008.0);
