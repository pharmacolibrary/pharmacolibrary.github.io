function p = Evolocumab_Gibbs2017_fixed_effects_population_mean_parameter_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: evolocumab   source: Gibbs_2017 / fixed_effects_population_mean_parameter   route: oral
  % estimated (absent from source): F
  p.name  = 'Evolocumab_Gibbs2017_fixed_effects_population_mean_parameter_params';
  p.drug  = 'evolocumab';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 2.66;                % central volume [L]
  p.CL = 0.010667;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.245;                % absorption rate [1/h]
  p.F  = 0.9;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 7.0;             % dose [mg]
end
