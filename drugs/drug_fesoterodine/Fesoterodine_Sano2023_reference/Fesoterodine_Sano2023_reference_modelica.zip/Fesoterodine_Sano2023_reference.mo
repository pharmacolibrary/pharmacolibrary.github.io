model Fesoterodine_Sano2023_reference
  parameter Real Cl_ref = 1.9833333333333335e-05 "Cl [m3/s]";
  parameter Real Vd_ref = 0.0737 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.341495,
    adminMass = 2e-06,
    ka = 2.5055555555555555e-05,
    Tlag = 1004.4000000000001
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About fesoterodine</h4><p>Fesoterodine is a muscarinic antagonist used to treat overactive bladder, a condition involving urinary frequency and incontinence. It is an approved medicine, authorised in the European Union, and is used for this urological indication.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q4482372\">Wikidata Q4482372</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>fesoterodine</td></tr><tr><td>population:</td><td>pediatric patients with neurogenic detrusor overactivity or overactive bladder</td></tr><tr><td>source_paper:</td><td>Sano_2023</td></tr><tr><td>measured_compound:</td><td>5-hydroxymethyl tolterodine</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>Tab2</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>5-hydroxymethyl tolterodine 341.495 g/mol (pubchem); fesoterodine 411.577 g/mol (drugbank)</td></tr></table><h4>Interpretation flags</h4><ul><li>the dosed compound is fesoterodine; the compartment is 5-hydroxymethyl tolterodine. Input enters at the reported formation rate, so formation is already accounted for in the input step and the simulated concentration is 5-hydroxymethyl tolterodine, not fesoterodine</li><li>apparent parameters (CLm/F, Vm/F) already contain F and the metabolised fraction, so F=1 and no molar correction is applied — adding either would double-count it</li><li>fesoterodine's own concentration-time course is not produced by this model</li><li>table section iiv: 'ωCL/F, % CV' routed out of structural estimates ('Inter-individual variance')</li><li>table section iiv: 'ωCL/F, % CV' routed out of structural estimates ('Inter-individual variance')</li><li>table section iiv: 'ωCL/F, % CV' routed out of structural estimates ('Inter-individual variance')</li><li>table section iiv: 'ωCL/F, % CV' routed out of structural estimates ('Inter-individual variance')</li><li>table section iiv: 'ωCL/F-Vd/F' routed out of structural estimates ('Inter-individual variance')</li><li>table section iiv: 'ωCL/F-Vd/F' routed out of structural estimates ('Inter-individual variance')</li><li>table section iiv: 'ωCL/F-Vd/F' routed out of structural estimates ('Inter-individual variance')</li><li>table section iiv: 'ωVd/F, % CV' routed out of structural estimates ('Inter-individual variance')</li><li>table section iiv: 'ωVd/F, % CV' routed out of structural estimates ('Inter-individual variance')</li><li>table section iiv: 'ωVd/F, % CV' routed out of structural estimates ('Inter-individual variance')</li><li>table section iiv: 'ωVd/F, % CV' routed out of structural estimates ('Inter-individual variance')</li><li>table section iiv: 'ωCL/F-Ka' routed out of structural estimates ('Inter-individual variance')</li><li>table section iiv: 'ωCL/F-Ka' routed out of structural estimates ('Inter-individual variance')</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 133200, Tolerance = 1e-9, Interval = 1));
end Fesoterodine_Sano2023_reference;
