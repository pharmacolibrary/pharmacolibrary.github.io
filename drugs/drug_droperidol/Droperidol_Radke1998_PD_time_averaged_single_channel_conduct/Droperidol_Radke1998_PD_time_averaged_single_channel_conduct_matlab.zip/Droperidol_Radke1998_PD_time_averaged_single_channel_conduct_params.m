function p = Droperidol_Radke1998_PD_time_averaged_single_channel_conduct_params()
% Droperidol_Radke1998_PD_time_averaged_single_channel_conduct_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% droperidol Radke_1998::time_averaged_single_channel_conductance: emax exposure-response sweep (response = E0 + Emax*frac). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one mM per second, in SI inside (kg/m3, s). Response time averaged single channel conductance in its own unit. Driver: droperidol (cited_pk).
p.E0 = 0.0;
p.Emax = -0.77;
p.EC50 = 0.68;
p.gamma = 1.0;
p.slope = 0.0;
p.exposure_per_s = 1.0;
p.stop_time = 6.8;
p.form = 'E0 + Emax*frac';
end
