model Droperidol_Radke1998_PD_time_averaged_single_channel_conduct
  "emax exposure-response sweep — Radke_1998 :: time averaged single channel conductance (time averaged single channel conductance)"
  extends Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep(
    E0 = 0,      // [1]
    Emax = -0.77,  // [1; % × 0.01]
    EC50 = 0.68,  // [mM]
    gamma = 1,
    exposure_per_s = 1);   // 1 mM per second
  // imax_as_negative_emax: Imax (Q323) enters SigmoidEmaxSweep as −Emax
  // exposure_unit_unresolved: 'mM' — the x axis is in the paper's unit, not SI
  // defaulted: E0
  // defaulted: gamma
  annotation(experiment(StartTime = 0, StopTime = 6.8, Interval = 0.0136),
    Documentation(info = "<html><body><!-- drug-about --><h4>About droperidol</h4><p>Droperidol is a butyrophenone antipsychotic and antiemetic used for conditions such as pain and schizophreniform disorder, and as an adjuvant in anesthesia. It remains an approved medicine, including veterinary use, but carries a boxed warning, so its use is cautious.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q174259\">Wikidata Q174259</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h4>Droperidol_Radke1998_PD_time_averaged_single_channel_conduct</h4><p>The steady-state exposure-response curve of Radke PW et al., <i>European journal of anaesthesiology 15(1):89–95</i> 1998 (<a href=\"https://doi.org/10.1046/j.1365-2346.1998.00221.x\">doi:10.1046/j.1365-2346.1998.00221.x</a>) — time averaged single channel conductance against droperidol mM — obtained by sweeping the driver instead of simulating a dose. Model family: emax.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = (library default) drug-free response (baseline)
  Emax  =         77 %        maximal effect term (maximal conductance block, Q323)
  EC50  =       0.68 mM       exposure at half of the maximal effect term (EC50, Q321)
  gamma = (library default) Hill coefficient</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep\">SigmoidEmaxSweep</a>; this model only supplies the numbers. The x axis is one mM of droperidol per second of simulated time: there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0   (drug-free)
  exposure = EC50 (0.68 mM)  response -0.385
  exposure -> infinity  response -0.77</pre></body></html>"));
end Droperidol_Radke1998_PD_time_averaged_single_channel_conduct;
