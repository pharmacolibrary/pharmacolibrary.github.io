model Vigabatrin_Ounissi2019_reference
  parameter Real Cl_ref = 6.555555555555556e-07 "Cl [m3/s]";
  parameter Real Vd_ref = 0.017 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.12915700000000002,
    adminMass = 0.002,
    ka = 0.0001388888888888889,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About vigabatrin</h4><p>Vigabatrin is an antiepileptic drug used to treat epilepsy, including infantile spasms and partial seizures. It is authorised in the European Union, where its use is limited to these specific seizure types.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q421663\">Wikidata Q421663</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>vigabatrin</td></tr><tr><td>population:</td><td>children with infantile spasms</td></tr><tr><td>source_paper:</td><td>Ounissi_2019</td></tr><tr><td>measured_compound:</td><td>vigabatrin</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C_enteral: apparent (/F) parameterization ⇒ extravascular dosing</td></tr><tr><td>molar_masses:</td><td>vigabatrin 129.157 g/mol (drugbank)</td></tr></table><p><b>Defaulted (base-class default used):</b> ka, Tlag.</p><h4>Interpretation flags</h4><ul><li>dropped unlinked row (NIL): 'absorption duration' — extend the ontology if this is a real PK parameter (source ['Ounissi_2019:abstract'])</li><li>apparent-ness (ontology-grounded): parameterization=apparent, measured_compound=vigabatrin</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 90000, Tolerance = 1e-9, Interval = 1));
end Vigabatrin_Ounissi2019_reference;
