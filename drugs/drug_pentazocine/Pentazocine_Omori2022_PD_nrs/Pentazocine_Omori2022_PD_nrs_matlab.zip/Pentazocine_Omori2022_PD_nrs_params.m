function p = Pentazocine_Omori2022_PD_nrs_params()
% Pentazocine_Omori2022_PD_nrs_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% pentazocine Omori_2022::NRS: indirect_response_ii exposure-response sweep (response = E0/(1 - Emax*frac)). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one ng/mL per second, in SI inside (kg/m3, s). Response NRS in its own unit. Driver: Pentazocine (pk_record).
p.E0 = 0.397;
p.Emax = 1.0;
p.EC50 = 0.000144;
p.gamma = 1.0;
p.slope = 0.0;
p.exposure_per_s = 1e-06;
p.stop_time = 1500.0;
p.form = 'E0/(1 - Emax*frac)';
end
