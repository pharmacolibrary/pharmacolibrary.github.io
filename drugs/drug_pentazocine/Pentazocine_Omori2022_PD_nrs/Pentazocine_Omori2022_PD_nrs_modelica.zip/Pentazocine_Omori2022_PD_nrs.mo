model Pentazocine_Omori2022_PD_nrs
  "indirect_response_ii exposure-response sweep — Omori_2022 :: NRS (Pain severity)"
  extends Pharmacolibrary.Interfaces.PartialExposureResponseSweep(
    E0 = 0.397,      // [× 10 Pain scale]
    Emax = 1,  // type II effect term
    EC50 = 0.000144,  // [kg/m3; ng/mL × 1e-06]
    gamma = 1,
    exposure_per_s = 1e-06);   // 1 ng/mL per second
equation
  response = E0/(1 - Emax*frac);   // steady state, indirect response type II
  // defaulted: gamma
  annotation(experiment(StartTime = 0, StopTime = 1500, Interval = 3),
    Documentation(info = "<html><body><!-- drug-about --><h4>About pentazocine</h4><p>Pentazocine is an opioid painkiller used to treat moderate to severe pain. It is an approved medicine and is also approved for veterinary use.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q105290238\">Wikidata Q105290238</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h4>Pentazocine_Omori2022_PD_nrs</h4><p>The steady-state exposure-response curve of Omori T et al., <i>Biological &amp; pharmaceutical bulletin 45(12):1754–1763</i> 2022 (<a href=\"https://doi.org/10.1248/bpb.b22-00398\">doi:10.1248/bpb.b22-00398</a>) — Pain severity against Pentazocine ng/mL — obtained by sweeping the driver instead of simulating a dose. Model family: indirect_response_ii.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    =      0.397 × 10 Pain scale drug-free response (baseline) (Pain base, Q324)
  Emax  =          1          maximal effect term (E max, Q320)
  EC50  =        144 ng/mL    exposure at half of the maximal effect term (EC 50, Q321)
  gamma = (library default) Hill coefficient</pre><p>The algebra is <code>response = E0/(1 - Emax*frac)</code>; this model only supplies the numbers. The x axis is one ng/mL of Pentazocine per second of simulated time (exposure is in kg/m3): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0.397   (drug-free)
  exposure = EC50 (144 ng/mL)  response 0.794
  exposure -> infinity  response inf</pre></body></html>"));
end Pentazocine_Omori2022_PD_nrs;
