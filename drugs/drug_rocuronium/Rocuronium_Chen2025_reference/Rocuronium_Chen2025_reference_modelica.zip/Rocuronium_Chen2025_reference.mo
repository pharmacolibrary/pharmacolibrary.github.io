model Rocuronium_Chen2025_reference
  parameter Real Cl_ref = 2.0666666666666666e-05 "Cl [m3/s]";
  parameter Real Vd_ref = 0.0175 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.529786,
    adminMass = 1e-05,
    k12 = 0.000279047619047619,
    k21 = 0.00017316784869976357
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About rocuronium</h4><p>Rocuronium is a non-depolarising neuromuscular blocking agent used to relax muscles, for example during surgery. It is an approved medicine and is widely used in anaesthesia, mainly in hospital settings.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q185331\">Wikidata Q185331</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>rocuronium</td></tr><tr><td>population:</td><td>review reference</td></tr><tr><td>source_paper:</td><td>Chen_2025</td></tr><tr><td>measured_compound:</td><td>rocuronium</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_2C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>rocuronium 529.786 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>built from REVIEW reference values (Chen_2025) — secondary source</li><li>volume reported by review</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Rocuronium_Chen2025_reference;
