model Rocuronium_Szenohradszky1992_reference
  parameter Real Cl_ref = 3.3716666666666664e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.005383 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.529786,
    adminMass = 1e-05
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About rocuronium</h4><p>Rocuronium is a non-depolarising neuromuscular blocking agent used to relax muscles, for example during surgery. It is an approved medicine and is widely used in anaesthesia, mainly in hospital settings.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q185331\">Wikidata Q185331</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>rocuronium</td></tr><tr><td>population:</td><td>patients undergoing cadaver renal transplantation and healthy controls</td></tr><tr><td>source_paper:</td><td>Szenohradszky_1992</td></tr><tr><td>measured_compound:</td><td>rocuronium</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>rocuronium 529.786 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=rocuronium</li><li>1C volume normalization: Q63→Q61 (single-compartment model has no central/peripheral split; 'volume of the central compartment' is the general volume)</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Rocuronium_Szenohradszky1992_reference;
