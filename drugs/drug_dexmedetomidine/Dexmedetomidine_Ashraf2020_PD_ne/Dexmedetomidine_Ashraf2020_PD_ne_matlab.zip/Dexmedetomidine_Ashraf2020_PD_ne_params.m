function p = Dexmedetomidine_Ashraf2020_PD_ne_params()
% Dexmedetomidine_Ashraf2020_PD_ne_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% dexmedetomidine Ashraf_2020::NE: indirect_response_i exposure-response sweep (response = E0*(1 - Emax*frac)). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one nM per second, in SI inside (kg/m3, s). Response NE in nM. Driver: dexmedetomidine (pk_record).
p.E0 = 0.814;
p.Emax = 1.0;
p.EC50 = 0.334;
p.gamma = 1.0;
p.slope = 0.0;
p.exposure_per_s = 1.0;
p.stop_time = 3.4;
p.form = 'E0*(1 - Emax*frac)';
end
