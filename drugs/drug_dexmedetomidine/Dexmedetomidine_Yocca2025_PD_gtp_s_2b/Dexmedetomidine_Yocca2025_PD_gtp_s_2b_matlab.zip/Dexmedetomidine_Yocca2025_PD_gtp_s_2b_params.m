function p = Dexmedetomidine_Yocca2025_PD_gtp_s_2b_params()
% Dexmedetomidine_Yocca2025_PD_gtp_s_2b_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% dexmedetomidine Yocca_2025::GTP_S_2B: emax exposure-response sweep (response = E0 + Emax*frac). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one nM per second, in SI inside (kg/m3, s). Response GTPγS α2B in % of UK-14304 maximum. Driver: dexmedetomidine (cited_pk).
p.E0 = 0.0;
p.Emax = 1.47;
p.EC50 = 2.8;
p.gamma = 1.0;
p.slope = 0.0;
p.exposure_per_s = 1.0;
p.stop_time = 28.0;
p.form = 'E0 + Emax*frac';
end
