function p = Dexmedetomidine_Huang2025_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: dexmedetomidine   source: Huang_2025 / reference   route: oral
  % estimated (absent from source): F
  p.name  = 'Dexmedetomidine_Huang2025_reference_params';
  p.drug  = 'dexmedetomidine';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 18.834;                % central volume [L]
  p.CL = 32.987;                % clearance [L/h]
  p.Vp = [80.6];             % peripheral volumes [L]
  p.Q  = [102.907];             % inter-compartmental clearances [L/h]
  p.ka = 0.43;                % absorption rate [1/h]
  p.F  = 0.9;                 % bioavailability [0-1]
  p.Tlag = 0.484;             % absorption lag [h]
  p.dose = 0.1;             % dose [mg]
end
