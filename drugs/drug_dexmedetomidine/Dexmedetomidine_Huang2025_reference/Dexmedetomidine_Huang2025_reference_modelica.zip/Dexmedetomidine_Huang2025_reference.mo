model Dexmedetomidine_Huang2025_reference
  parameter Real Cl_ref = 9.163055555555556e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.018834 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C_enteral(
    weight = 70.0,
    F = 0.9,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.2002795,
    adminMass = 1.0000000000000001e-07,
    ka = 0.00011944444444444444,
    Tlag = 1742.3999999999999,
    k12 = 0.0015177486342666335,
    k21 = 0.00035465605183347123
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About dexmedetomidine</h4><p>Dexmedetomidine is a sedative drug used for conscious sedation, and has also been studied for pain and agitation in dementia. It is authorised in the European Union and also approved for veterinary use, with some investigational uses.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q412133\">Wikidata Q412133</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>dexmedetomidine</td></tr><tr><td>population:</td><td>Chinese healthy volunteers and patients (adults)</td></tr><tr><td>source_paper:</td><td>Huang_2025</td></tr><tr><td>measured_compound:</td><td>dexmedetomidine</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>T4</td></tr><tr><td>input:</td><td>PK_2C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>dexmedetomidine 200.28 g/mol (drugbank)</td></tr></table><p><b>Defaulted (base-class default used):</b> F.</p><h4>Interpretation flags</h4><ul><li>table section iiv: 'ω (CL), %' routed out of structural estimates ('Inter-individual')</li><li>table section iiv: 'ω (CL), %' routed out of structural estimates ('Inter-individual')</li><li>table section iiv: 'ω (CL), %' routed out of structural estimates ('Inter-individual')</li><li>table section iiv: 'ω (CL), %' routed out of structural estimates ('Inter-individual')</li><li>table section iiv: 'ω (KA), %' routed out of structural estimates ('Inter-individual')</li><li>table section iiv: 'ω (KA), %' routed out of structural estimates ('Inter-individual')</li><li>table section iiv: 'ω (KA), %' routed out of structural estimates ('Inter-individual')</li><li>table section iiv: 'ω (KA), %' routed out of structural estimates ('Inter-individual')</li><li>table section residual_error: 'σ (Prop), %' routed out of structural estimates ('Residual error')</li><li>table section residual_error: 'σ (Prop), %' routed out of structural estimates ('Residual error')</li><li>table section residual_error: 'σ (Prop), %' routed out of structural estimates ('Residual error')</li><li>table section residual_error: 'σ (Prop), %' routed out of structural estimates ('Residual error')</li><li>table section residual_error: 'σ (Add), pg/mL' routed out of structural estimates ('Residual error')</li><li>table section residual_error: 'σ (Add), pg/mL' routed out of structural estimates ('Residual error')</li><li>table section residual_error: 'σ (Add), pg/mL' routed out of structural estimates ('Residual error')</li><li>table section residual_error: 'σ (Add), pg/mL' routed out of structural estimates ('Residual error')</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Dexmedetomidine_Huang2025_reference;
