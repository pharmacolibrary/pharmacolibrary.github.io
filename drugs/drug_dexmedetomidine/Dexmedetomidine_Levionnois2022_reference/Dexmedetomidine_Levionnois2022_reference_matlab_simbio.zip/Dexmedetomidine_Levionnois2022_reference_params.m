function p = Dexmedetomidine_Levionnois2022_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: dexmedetomidine   source: Levionnois_2022 / reference   route: iv_bolus
  % estimated (absent from source): F
  p.name  = 'Dexmedetomidine_Levionnois2022_reference_params';
  p.drug  = 'dexmedetomidine';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'iv_bolus';        % 'oral' | 'iv_bolus'
  p.depot = false;             % oral -> first-order absorption depot
  p.Vc = 196.0;                % central volume [L]
  p.CL = 137.2;                % clearance [L/h]
  p.Vp = [28.7];             % peripheral volumes [L]
  p.Q  = [130.9];             % inter-compartmental clearances [L/h]
  p.ka = 0.0;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 1.0;             % dose [mg]
end
