% run_Dexmedetomidine_Yocca2025_PD_arrestin_2c  Evaluate the exposure-response curve and plot response against exposure.
% A sweep is a static map: no ODE solver is needed. exposure runs 0..stop_time*exposure_per_s.
p = Dexmedetomidine_Yocca2025_PD_arrestin_2c_params();
exposure = linspace(0, p.stop_time * p.exposure_per_s, 501);
frac = exposure.^p.gamma ./ (p.EC50^p.gamma + exposure.^p.gamma);
E0 = p.E0; Emax = p.Emax; slope = p.slope;
response = E0 + Emax.*frac;
figure; plot(exposure, response, 'LineWidth', 1.5); grid on;
xlabel('exposure [nM]'); ylabel('response [% of UK-14304 maximum]'); title('Dexmedetomidine_Yocca2025_PD_arrestin_2c', 'Interpreter', 'none');
writematrix([exposure(:) response(:)], 'Dexmedetomidine_Yocca2025_PD_arrestin_2c.csv');
