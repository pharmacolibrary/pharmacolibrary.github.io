function p = Dexmedetomidine_Yocca2025_PD_arrestin_2c_params()
% Dexmedetomidine_Yocca2025_PD_arrestin_2c_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% dexmedetomidine Yocca_2025::arrestin_2C: emax exposure-response sweep (response = E0 + Emax*frac). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one nM per second, in SI inside (kg/m3, s). Response β-arrestin α2C in % of UK-14304 maximum. Driver: dexmedetomidine (cited_pk).
p.E0 = 0.0;
p.Emax = 0.9500000000000001;
p.EC50 = 24.0;
p.gamma = 1.0;
p.slope = 0.0;
p.exposure_per_s = 1.0;
p.stop_time = 240.0;
p.form = 'E0 + Emax*frac';
end
