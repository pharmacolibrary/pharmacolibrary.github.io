function p = Dexmedetomidine_James2022_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: dexmedetomidine   source: James_2022 / reference   route: iv_bolus
  % estimated (absent from source): F
  p.name  = 'Dexmedetomidine_James2022_reference_params';
  p.drug  = 'dexmedetomidine';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'iv_bolus';        % 'oral' | 'iv_bolus'
  p.depot = false;             % oral -> first-order absorption depot
  p.Vc = 161.0;                % central volume [L]
  p.CL = 27.3;                % clearance [L/h]
  p.Vp = [7903.0];             % peripheral volumes [L]
  p.Q  = [26.0];             % inter-compartmental clearances [L/h]
  p.ka = 0.0;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 1.0;             % dose [mg]
end
