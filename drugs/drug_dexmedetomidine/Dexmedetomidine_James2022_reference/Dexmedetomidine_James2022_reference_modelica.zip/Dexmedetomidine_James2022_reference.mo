model Dexmedetomidine_James2022_reference
  parameter Real Cl_ref = 7.583333333333333e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.161 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.2002795,
    adminMass = 1e-06,
    k12 = 4.485852311939269e-05,
    k21 = 9.138583097839077e-07
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About dexmedetomidine</h4><p>Dexmedetomidine is a sedative drug used for conscious sedation, and has also been studied for pain and agitation in dementia. It is authorised in the European Union and also approved for veterinary use, with some investigational uses.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q412133\">Wikidata Q412133</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>dexmedetomidine</td></tr><tr><td>population:</td><td>paediatric post-cardiac surgery patients</td></tr><tr><td>source_paper:</td><td>James_2022</td></tr><tr><td>measured_compound:</td><td>dexmedetomidine</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_2C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>dexmedetomidine 200.28 g/mol (drugbank)</td></tr></table><h4>Interpretation flags</h4><ul><li>dropped unlinked row (NIL): 'postmenstrual age when 50% of adult clearance is achieved' — extend the ontology if this is a real PK parameter (source ['James_2022:abstract'])</li><li>dropped PD-category row 'Hill coefficient' → Q325 (Hill, category G11) — pharmacodynamic parameters belong to scholarpd, not the PK model (source ['James_2022:abstract'])</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=dexmedetomidine</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Dexmedetomidine_James2022_reference;
