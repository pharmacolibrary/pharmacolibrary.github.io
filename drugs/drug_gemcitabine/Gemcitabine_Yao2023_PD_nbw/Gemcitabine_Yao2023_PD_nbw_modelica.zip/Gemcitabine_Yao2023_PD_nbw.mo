model Gemcitabine_Yao2023_PD_nbw
  "linear exposure-response sweep — Yao_2023 :: NBW (Net body weight)"
  extends Pharmacolibrary.Interfaces.PartialExposureResponseSweep(
    E0 = 0.0141,      // [kg; g × 0.001]
    Emax = 0, EC50 = 1,      // unused by a line
    exposure_per_s = 0.001);
  parameter Real slope = 11600   "[meter ** 3 / kilogram; mL/μg × 1000]";
equation
  response = E0 + slope*exposure;
  annotation(experiment(StartTime = 0, StopTime = 1000, Interval = 2),
    Documentation(info = "<html><body><!-- drug-about --><h4>About gemcitabine</h4><p>Gemcitabine is an antimetabolite anticancer drug used to treat various cancers, including pancreatic, lung, bladder, and breast-related carcinomas as well as several lymphomas. It is an approved medicine and is included on the WHO list of essential medicines, so it is widely used in cancer treatment worldwide.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q414143\">Wikidata Q414143</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h4>Gemcitabine_Yao2023_PD_nbw</h4><p>The steady-state exposure-response curve of Yao QY et al., <i>Acta pharmacologica Sinica 44(2):465–474</i> 2023 (<a href=\"https://doi.org/10.1038/s41401-022-00960-0\">doi:10.1038/s41401-022-00960-0</a>) — Net body weight [g] against gemcitabine μg/mL — obtained by sweeping the driver instead of simulating a dose. Model family: linear.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    =       14.1 g        drug-free response (baseline) (NBW 0, Q324)
  slope =       11.6 mL/μg    change in response per unit of exposure (K W,GEM, Q335)</pre><p>The algebra is <code>response = E0 + slope*exposure</code>; this model only supplies the numbers. The x axis is one μg/mL of gemcitabine per second of simulated time (exposure is in kg/m3): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0.0141   (drug-free)</pre></body></html>"));
end Gemcitabine_Yao2023_PD_nbw;
