function p = Gemcitabine_Yao2023_PD_nbw_params()
% Gemcitabine_Yao2023_PD_nbw_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% gemcitabine Yao_2023::NBW: linear exposure-response sweep (response = E0 + slope*exposure). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one μg/mL per second, in SI inside (kg/m3, s). Response NBW in g. Driver: gemcitabine (cited_pk).
p.E0 = 0.0141;
p.Emax = 0.0;
p.EC50 = 1.0;
p.gamma = 1.0;
p.slope = 11600.000000000002;
p.exposure_per_s = 0.001;
p.stop_time = 1000.0;
p.form = 'E0 + slope*exposure';
end
