function p = Gemcitabine_Yao2023_PD_net_body_weight_params()
% Gemcitabine_Yao2023_PD_net_body_weight_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% gemcitabine Yao_2023::net_body_weight: emax exposure-response sweep (response = E0 + Emax*frac). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one μg/mL per second, in SI inside (kg/m3, s). Response net body weight in its own unit. Driver: gemcitabine (cited_pk).
p.E0 = 0.0;
p.Emax = -0.369;
p.EC50 = 0.0009989999999999999;
p.gamma = 1.0;
p.slope = 0.0;
p.exposure_per_s = 0.001;
p.stop_time = 10.0;
p.form = 'E0 + Emax*frac';
end
