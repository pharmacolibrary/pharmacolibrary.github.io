model Gemcitabine_Yao2023_PD_net_body_weight
  "emax exposure-response sweep — Yao_2023 :: net body weight (name)"
  extends Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep(
    E0 = 0,      // [1]
    Emax = -0.369,  // [1]
    EC50 = 0.000999,  // [kg/m3; μg/mL × 0.001]
    gamma = 1,
    exposure_per_s = 0.001);   // 1 μg/mL per second
  // family_inferred: the record's model family is disease_progression; read from the parameters: Emax/Imax and EC50/IC50 without a Hill coefficient — Emax
  // inhibition_sign: effect_direction=inhibition with a positive Emax (Q320) — sign flipped
  // defaulted: E0
  // defaulted: gamma
  annotation(experiment(StartTime = 0, StopTime = 10, Interval = 0.02),
    Documentation(info = "<html><body><h4>Gemcitabine_Yao2023_PD_net_body_weight</h4><p>The steady-state exposure-response curve of Yao QY et al., <i>Acta pharmacologica Sinica 44(2):465–474</i> 2023 (<a href=\"https://doi.org/10.1038/s41401-022-00960-0\">doi:10.1038/s41401-022-00960-0</a>) — name against gemcitabine μg/mL — obtained by sweeping the driver instead of simulating a dose. Model family: emax.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = (library default) drug-free response (baseline)
  Emax  =      0.369          maximal effect term (E W,max, Q320)
  EC50  =      0.999 μg/mL    exposure at half of the maximal effect term (EC T,50 (μg/mL), Q321)
  gamma = (library default) Hill coefficient</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep\">SigmoidEmaxSweep</a>; this model only supplies the numbers. The x axis is one μg/mL of gemcitabine per second of simulated time (exposure is in kg/m3): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0   (drug-free)
  exposure = EC50 (0.999 μg/mL)  response -0.1845
  exposure -> infinity  response -0.369</pre></body></html>"));
end Gemcitabine_Yao2023_PD_net_body_weight;
