function p = Gemcitabine_Blaauboer2022_PD_unknown_params()
% Gemcitabine_Blaauboer2022_PD_unknown_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% gemcitabine Blaauboer_2022::unknown: emax exposure-response sweep (response = E0 + Emax*frac). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one ng/ml per second, in SI inside (kg/m3, s). Response unknown in mm3. Driver: gemcitabine (cited_pk).
p.E0 = 0.0;
p.Emax = -0.51;
p.EC50 = 1.5e-06;
p.gamma = 1.0;
p.slope = 0.0;
p.exposure_per_s = 1e-06;
p.stop_time = 15.0;
p.form = 'E0 + Emax*frac';
end
