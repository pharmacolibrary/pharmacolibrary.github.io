model Gemcitabine_Blaauboer2022_PD_unknown
  "emax exposure-response sweep — Blaauboer_2022 :: unknown (tumor size)"
  extends Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep(
    E0 = 0,      // [1]
    Emax = -0.51,  // [1; % × 0.01]
    EC50 = 1.5e-06,  // [kg/m3; ng/ml × 1e-06]
    gamma = 1,
    exposure_per_s = 1e-06);   // 1 ng/ml per second
  // family_inferred: the record's model family is unknown; read from the parameters: Emax/Imax and EC50/IC50 without a Hill coefficient — Emax
  // imax_as_negative_emax: Imax (Q323) enters SigmoidEmaxSweep as −Emax
  // defaulted: E0
  // defaulted: gamma
  annotation(experiment(StartTime = 0, StopTime = 15, Interval = 0.03),
    Documentation(info = "<html><body><h4>Gemcitabine_Blaauboer2022_PD_unknown</h4><p>The steady-state exposure-response curve of Blaauboer A et al., <i>International journal of oncology 61(2)</i> 2022 (<a href=\"https://doi.org/10.3892/ijo.2022.5387\">doi:10.3892/ijo.2022.5387</a>) — tumor size [mm3] against gemcitabine ng/ml — obtained by sweeping the driver instead of simulating a dose. Model family: emax.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = (library default) drug-free response (baseline)
  Emax  =         51 %        maximal effect term (maximal inhibition, Q323)
  EC50  =        1.5 ng/ml    exposure at half of the maximal effect term (EC 50, Q321)
  gamma = (library default) Hill coefficient</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep\">SigmoidEmaxSweep</a>; this model only supplies the numbers. The x axis is one ng/ml of gemcitabine per second of simulated time (exposure is in kg/m3): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0   (drug-free)
  exposure = EC50 (1.5 ng/ml)  response -0.255
  exposure -> infinity  response -0.51</pre></body></html>"));
end Gemcitabine_Blaauboer2022_PD_unknown;
