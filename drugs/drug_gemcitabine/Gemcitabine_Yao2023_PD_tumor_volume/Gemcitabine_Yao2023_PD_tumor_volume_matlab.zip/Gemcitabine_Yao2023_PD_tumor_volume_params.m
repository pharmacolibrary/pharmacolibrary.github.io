function p = Gemcitabine_Yao2023_PD_tumor_volume_params()
% Gemcitabine_Yao2023_PD_tumor_volume_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% gemcitabine Yao_2023::Tumor_volume: linear exposure-response sweep (response = E0 + slope*exposure). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one μg/mL per second, in SI inside (kg/m3, s). Response Tumor volume in mm3. Driver: gemcitabine (cited_pk).
p.E0 = 0.0;
p.Emax = 0.0;
p.EC50 = 1.0;
p.gamma = 1.0;
p.slope = 1510.0000000000005;
p.exposure_per_s = 0.001;
p.stop_time = 1000.0;
p.form = 'E0 + slope*exposure';
end
