function p = Gemcitabine_Yao2023_PD_tumor_volume_params()
% Gemcitabine_Yao2023_PD_tumor_volume_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% gemcitabine Yao_2023::tumor_volume: emax exposure-response sweep (response = E0 + Emax*frac). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one μg/mL per second, in SI inside (kg/m3, s). Response tumor volume in its own unit. Driver: gemcitabine (cited_pk).
p.E0 = 0.0;
p.Emax = -0.369;
p.EC50 = 0.0009989999999999999;
p.gamma = 1.0;
p.slope = 0.0;
p.exposure_per_s = 0.001;
p.stop_time = 10.0;
p.form = 'E0 + Emax*frac';
end
