model Gemcitabine_Serdjebi2017_reference
  parameter Real Cl_ref = 6.716666666666668e-05 "Cl [m3/s]";
  parameter Real Vd_ref = 0.045 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.2631981,
    adminMass = 1e-05,
    k12 = 8.370370370370371e-05,
    k21 = 0.00010462962962962962
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About gemcitabine</h4><p>Gemcitabine is an antimetabolite anticancer drug used to treat various cancers, including pancreatic, lung, bladder, and breast-related carcinomas as well as several lymphomas. It is an approved medicine and is included on the WHO list of essential medicines, so it is widely used in cancer treatment worldwide.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q414143\">Wikidata Q414143</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>gemcitabine</td></tr><tr><td>population:</td><td>adults with pancreatic cancer</td></tr><tr><td>source_paper:</td><td>Serdjebi_2017</td></tr><tr><td>measured_compound:</td><td>gemcitabine</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_2C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>gemcitabine 263.198 g/mol (drugbank)</td></tr></table><h4>Interpretation flags</h4><ul><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=gemcitabine</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Gemcitabine_Serdjebi2017_reference;
