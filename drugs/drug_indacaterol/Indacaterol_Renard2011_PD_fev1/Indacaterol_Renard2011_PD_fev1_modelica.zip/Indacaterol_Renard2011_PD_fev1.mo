model Indacaterol_Renard2011_PD_fev1
  "emax exposure-response sweep — Renard_2011 :: FEV1 (trough FEV1 (improvement vs placebo, steady state))"
  extends Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep(
    E0 = 0,      // [1]
    Emax = 0.000177,  // [m3; mL × 1e-06]
    EC50 = 2.8e-08,  // [kg; μg × 1e-09]
    gamma = 1,
    exposure_per_s = 1e-09);   // 1 μg per second
  // defaulted: E0
  // defaulted: gamma
  annotation(experiment(StartTime = 0, StopTime = 280, Interval = 0.56),
    Documentation(info = "<html><body><!-- drug-about --><h4>About indacaterol</h4><p>Indacaterol is an inhaled long-acting beta-2 agonist used to treat chronic obstructive pulmonary disease. It is authorised in the European Union, where several products are available, and is used as a single agent and in combination with other respiratory medicines.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q425654\">Wikidata Q425654</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h4>Indacaterol_Renard2011_PD_fev1</h4><p>The steady-state exposure-response curve of Renard D et al., <i>Respiratory research 12(1):54</i> 2011 (<a href=\"https://doi.org/10.1186/1465-9921-12-54\">doi:10.1186/1465-9921-12-54</a>) — trough FEV1 (improvement vs placebo, steady state) [mL] against indacaterol μg — obtained by sweeping the driver instead of simulating a dose. Model family: emax.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = (library default) drug-free response (baseline)
  Emax  =        177 mL       maximal effect term (Emax, Q320)
  EC50  =         28 μg       exposure at half of the maximal effect term (ED50, Q321)
  gamma = (library default) Hill coefficient</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep\">SigmoidEmaxSweep</a>; this model only supplies the numbers. The x axis is one μg of indacaterol per second of simulated time (exposure is in kg): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0   (drug-free)
  exposure = EC50 (28 μg)  response 8.85e-05
  exposure -> infinity  response 0.000177</pre></body></html>"));
end Indacaterol_Renard2011_PD_fev1;
