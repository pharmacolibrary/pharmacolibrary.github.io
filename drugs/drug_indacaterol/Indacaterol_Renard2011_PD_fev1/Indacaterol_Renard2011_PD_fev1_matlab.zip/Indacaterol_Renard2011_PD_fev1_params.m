function p = Indacaterol_Renard2011_PD_fev1_params()
% Indacaterol_Renard2011_PD_fev1_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% indacaterol Renard_2011::FEV1: emax exposure-response sweep (response = E0 + Emax*frac). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one μg per second, in SI inside (kg/m3, s). Response FEV1 in mL. Driver: indacaterol (dose_only).
p.E0 = 0.0;
p.Emax = 0.00017700000000000002;
p.EC50 = 2.8000000000000003e-08;
p.gamma = 1.0;
p.slope = 0.0;
p.exposure_per_s = 1e-09;
p.stop_time = 280.0;
p.form = 'E0 + Emax*frac';
end
