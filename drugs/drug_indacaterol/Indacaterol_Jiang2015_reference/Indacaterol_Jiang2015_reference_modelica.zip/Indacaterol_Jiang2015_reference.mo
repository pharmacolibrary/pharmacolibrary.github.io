model Indacaterol_Jiang2015_reference
  parameter Real Cl_ref = 1.886111111111111e-05 "Cl [m3/s]";
  parameter Real Vd_ref = 11.05 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.3924907,
    adminMass = 0.0001,
    ka = 0.0001388888888888889,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About indacaterol</h4><p>Indacaterol is an inhaled long-acting beta-2 agonist used to treat chronic obstructive pulmonary disease. It is authorised in the European Union, where several products are available, and is used as a single agent and in combination with other respiratory medicines.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q425654\">Wikidata Q425654</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>indacaterol</td></tr><tr><td>population:</td><td>review reference</td></tr><tr><td>source_paper:</td><td>Jiang_2015</td></tr><tr><td>measured_compound:</td><td>indacaterol</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C_enteral: apparent (/F) parameterization ⇒ extravascular dosing</td></tr><tr><td>molar_masses:</td><td>indacaterol 392.491 g/mol (drugbank)</td></tr></table><p><b>Defaulted (base-class default used):</b> ka, Tlag.</p><h4>Interpretation flags</h4><ul><li>built from REVIEW reference values (Jiang_2015) — secondary source</li><li>volume reported by review</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 2419200, Tolerance = 1e-9, Interval = 1));
end Indacaterol_Jiang2015_reference;
