function p = Etodolac_Boni1999_PD_pain_intensity_difference_scores_params()
% Etodolac_Boni1999_PD_pain_intensity_difference_scores_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% etodolac Boni_1999::pain_intensity_difference_scores: indirect_response_i exposure-response sweep (response = E0*(1 - Emax*frac)). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one mg/L per second, in SI inside (kg/m3, s). Response pain intensity difference scores in its own unit. Driver: etodolac (pk_record).
p.E0 = 0.0;
p.Emax = 1.0;
p.EC50 = 0.013999999999999997;
p.gamma = 3.34;
p.slope = 0.0;
p.exposure_per_s = 0.001;
p.stop_time = 140.0;
p.form = 'E0*(1 - Emax*frac)';
end
