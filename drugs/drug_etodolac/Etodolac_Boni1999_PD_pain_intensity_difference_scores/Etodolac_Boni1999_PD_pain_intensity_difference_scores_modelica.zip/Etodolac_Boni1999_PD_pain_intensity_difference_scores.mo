model Etodolac_Boni1999_PD_pain_intensity_difference_scores
  "indirect_response_i exposure-response sweep — Boni_1999 :: pain intensity difference scores (pain intensity difference scores)"
  extends Pharmacolibrary.Interfaces.PartialExposureResponseSweep(
    E0 = 0,      // [1]
    Emax = 1,  // type I effect term
    EC50 = 0.014,  // [kg/m3; mg/L × 0.001]
    gamma = 3.34,
    exposure_per_s = 0.001);   // 1 mg/L per second
equation
  response = E0*(1 - Emax*frac);   // steady state, indirect response type I
  // defaulted: E0
  // defaulted: Emax
  annotation(experiment(StartTime = 0, StopTime = 140, Interval = 0.28),
    Documentation(info = "<html><body><!-- drug-about --><h4>About etodolac</h4><p>It is an approved medicine, also approved for veterinary use, though it carries a boxed warning.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q2465218\">Wikidata Q2465218</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h4>Etodolac_Boni1999_PD_pain_intensity_difference_scores</h4><p>The steady-state exposure-response curve of Boni J et al., <i>Journal of clinical pharmacology 39(7):729–737</i> 1999 (<a href=\"https://doi.org/10.1177/00912709922008254\">doi:10.1177/00912709922008254</a>) — pain intensity difference scores against etodolac mg/L — obtained by sweeping the driver instead of simulating a dose. Model family: indirect_response_i.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = (library default) drug-free response (baseline)
  Emax  = (library default) maximal effect term
  EC50  =         14 mg/L     exposure at half of the maximal effect term (IC50, Q322)
  gamma =       3.34          Hill coefficient (Hill coefficient, Q325)</pre><p>The algebra is <code>response = E0*(1 - Emax*frac)</code>; this model only supplies the numbers. The x axis is one mg/L of etodolac per second of simulated time (exposure is in kg/m3): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0   (drug-free)
  exposure = EC50 (14 mg/L)  response 0
  exposure -> infinity  response 0</pre></body></html>"));
end Etodolac_Boni1999_PD_pain_intensity_difference_scores;
