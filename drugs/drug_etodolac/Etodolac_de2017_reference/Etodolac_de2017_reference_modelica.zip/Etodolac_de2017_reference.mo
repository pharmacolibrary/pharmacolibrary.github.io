model Etodolac_de2017_reference
  parameter Real Cl_ref = 6.13888888888889e-07 "Cl [m3/s]";
  parameter Real Vd_ref = 0.0146 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    adminMass = 1e-05
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About etodolac</h4><p>It is an approved medicine, also approved for veterinary use, though it carries a boxed warning.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q2465218\">Wikidata Q2465218</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>etodolac</td></tr><tr><td>population:</td><td>healthy volunteers</td></tr><tr><td>source_paper:</td><td>de_2017</td></tr><tr><td>measured_compound:</td><td>R-etodolac and S-etodolac</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>etodolac 287.353 g/mol (drugbank)</td></tr></table><h4>Interpretation flags</h4><ul><li>dropped duplicate Q22 ('total clearance of S-etodolac', value 26.8) — already have one for this compound</li><li>dropped duplicate Q65 ('Volume of distribution at steady-state was S-etodolac', value 45.8) — already have one for this compound</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=R-etodolac and S-etodolac</li><li>molar mass: no plausible PubChem entry for 'R-etodolac and S-etodolac' ('R-etodolac and S-etodolac') — left in mass units</li><li>molar mass: none found for 'R-etodolac and S-etodolac' — its concentrations stay mass-only</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Etodolac_de2017_reference;
