function p = Codeine_Ashraf2024_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: codeine   source: Ashraf_2024 / reference   route: oral
  % estimated (absent from source): F
  p.name  = 'Codeine_Ashraf2024_reference_params';
  p.drug  = 'codeine';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 231.2;                % central volume [L]
  p.CL = 59.6;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 6.49;                % absorption rate [1/h]
  p.F  = 0.9;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 60.0;             % dose [mg]
end
