model Codeine_Thigpen2019_reference
  parameter Real Cl_ref = 9.333333333333334e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.36400000000000005 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.29936419999999997,
    adminMass = 1e-05
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About codeine</h4><p>Codeine is an opioid used to treat pain and to suppress cough. It is widely used around the world, often combined with non-opioid painkillers, and is included on the WHO list of essential medicines.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q174723\">Wikidata Q174723</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>codeine</td></tr><tr><td>population:</td><td>review reference</td></tr><tr><td>source_paper:</td><td>Thigpen_2019</td></tr><tr><td>measured_compound:</td><td>codeine</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>codeine 299.364 g/mol (drugbank)</td></tr></table><h4>Interpretation flags</h4><ul><li>built from REVIEW reference values (Thigpen_2019) — secondary source</li><li>volume reported by review</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 136800, Tolerance = 1e-9, Interval = 1));
end Codeine_Thigpen2019_reference;
