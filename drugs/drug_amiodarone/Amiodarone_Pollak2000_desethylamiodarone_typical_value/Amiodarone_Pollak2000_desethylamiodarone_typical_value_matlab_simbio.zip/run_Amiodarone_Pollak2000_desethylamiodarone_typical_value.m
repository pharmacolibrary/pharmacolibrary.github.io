% Run (SimBiology): build model + dose, simulate 0..1008.0 h, plot.
p = Amiodarone_Pollak2000_desethylamiodarone_typical_value_params();
[model, dose, variant] = build_sb_pk(p);
sd = simulate_sb(model, variant, dose, 1008.0);
