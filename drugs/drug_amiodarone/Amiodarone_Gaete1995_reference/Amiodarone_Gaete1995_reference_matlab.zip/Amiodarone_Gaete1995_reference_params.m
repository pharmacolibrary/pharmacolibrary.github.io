function p = Amiodarone_Gaete1995_reference_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: amiodarone   source: Gaete_1995 / reference   route: oral
  p.name  = 'Amiodarone_Gaete1995_reference_params';
  p.drug  = 'amiodarone';
  p.ncmt  = 1;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 209.3;                % central volume [L]
  p.CL = 17.85;                % clearance [L/h]
  p.Vp = [];             % peripheral volumes [L]
  p.Q  = [];             % inter-compartmental clearances [L/h]
  p.ka = 0.82;                % absorption rate [1/h]
  p.F  = 0.686;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 200.0;             % dose [mg]
end
