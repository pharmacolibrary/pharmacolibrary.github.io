% Run (SimBiology): build model + dose, simulate 0..42.0 h, plot.
p = Amiodarone_Gaete1995_reference_params();
[model, dose, variant] = build_sb_pk(p);
sd = simulate_sb(model, variant, dose, 42.0);
