// parent + metabolites (N-desethylamiodarone): PK_3M_9C — formed from central; parent 1, metabolites [1]
model Amiodarone_Hirai2022_reference
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_3M_9C(
    Vd1 = 0.98,
    q1_m11 = 2.1944444444444445e-06,
    CL1 = 0.0,
    Vd1m1 = 0.98,
    CLm1 = 2.861111111111111e-06,
    MW = 0.6453116,
    MW_m1 = 0.617257,
    F = 1,
    ka = 0.0002777777777777778,
    Tlag = 0.0,
    adminDuration = 600,
    adminCount = 1,
    adminMass = 0.0002
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About amiodarone</h4><p>Amiodarone is an antiarrhythmic medicine used to treat and prevent various types of irregular heartbeat, including ventricular tachycardia, atrial fibrillation, and other arrhythmias. It is widely used, is included on the WHO list of essential medicines, and is an approved drug.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q410061\">Wikidata Q410061</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>amiodarone</td></tr><tr><td>population:</td><td>adult patients</td></tr><tr><td>source_paper:</td><td>Hirai_2022</td></tr><tr><td>measured_compound:</td><td>amiodarone</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>parent_metabolite</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>tab_0</td></tr><tr><td>input:</td><td>PK_3M_9C: absorption rate constant reported; formation of N-desethylamiodarone: fm not identifiable (CLm/F, Vm/F reported) — all of CL forms it; dose 200 mg (paper)</td></tr><tr><td>molar_masses:</td><td>N-desethylamiodarone 617.257 g/mol (pubchem); amiodarone 645.312 g/mol (drugbank)</td></tr></table><p><b>Defaulted (base-class default used):</b> Tlag.</p><h4>Interpretation flags</h4><ul><li>table section iiv: 'ωCL AMD , %' routed out of structural estimates ('Interindividual variability')</li><li>table section iiv: 'ωCL AMD , %' routed out of structural estimates ('Interindividual variability')</li><li>table section iiv: 'ωCL AMD , %' routed out of structural estimates ('Interindividual variability')</li><li>table section iiv: 'ωCL DEA , %' routed out of structural estimates ('Interindividual variability')</li><li>table section iiv: 'ωCL DEA , %' routed out of structural estimates ('Interindividual variability')</li><li>table section iiv: 'ωCL DEA , %' routed out of structural estimates ('Interindividual variability')</li><li>unit_dimension_unknown: 'fixed' (V)</li><li>unit_dimension_unknown: 'fixed' (Fab)</li><li>unit_dimension_unknown: 'fixed' (kabs)</li><li>unit_dimension_unknown: 'fixed' (V1)</li><li>dropped duplicate Q22 ('CL AMD', value 7.9) — already have one for this compound</li><li>NIL: refused to back-fill base 'V' from footnote/prose loose number 14.0 (source ['fig_0:caption']); the table cell was unparseable — needs review</li><li>NIL: refused to back-fill base 'CL/F' from footnote/prose loose number 10.3 (source ['fig_0:caption']); the table cell was unparseable — needs review</li><li>NIL: refused to back-fill base 'V1' from footnote/prose loose number 14.0 (source ['fig_0:caption']); the table cell was unparseable — needs review</li><li>implicit units: 'Vd AMD , L/kg (fixed)' → L/kg (from the paper text: &quot;The text under 'Figures and Tables' states the final model equation: 'Vd _AMD = 14.0 × Body weight'. Since Body weight i&quot;)</li><li>implicit units: 'k a , /h (fixed)' → 1/h (from the popPK convention: 'The parameter is the absorption rate constant (ka). In population pharmacokinetics, first-order rate constants are conve')</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 1555200, Tolerance = 1e-9, Interval = 1));
end Amiodarone_Hirai2022_reference;
