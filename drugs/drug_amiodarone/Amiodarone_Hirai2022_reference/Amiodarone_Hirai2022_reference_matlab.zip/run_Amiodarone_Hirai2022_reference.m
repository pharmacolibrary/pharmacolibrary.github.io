% Run: build params, simulate 0..432.0 h, plot every molecule + save Amiodarone_Hirai2022_reference.png/.csv/.json.
% Interactive display (keep the window open):  octave --persist run_Amiodarone_Hirai2022_reference.m
here = fileparts(mfilename('fullpath'));
p = Amiodarone_Hirai2022_reference_params();
out = simulate_network(p, 0:0.05:432.0);

fig = figure; semilogy(out.t, max(out.C, 1e-12), 'LineWidth', 1.5); grid on;
legend(p.out_labels, 'Location', 'northeast');
xlabel('time [h]'); ylabel('concentration [mg/L]');
title('amiodarone — Hirai_2022 (parent + metabolites)');
print(fig, fullfile(here, 'Amiodarone_Hirai2022_reference.png'), '-dpng', '-r150');

fid = fopen(fullfile(here, 'Amiodarone_Hirai2022_reference.csv'), 'w');
fprintf(fid, 'time_h');
fprintf(fid, ',%s_mg_per_L', p.out_names{:});
fprintf(fid, '\n');
fmt = ['%.10g', repmat(',%.10g', 1, numel(p.out_names)), '\n'];
fprintf(fid, fmt, [out.t(:), out.C].');
fclose(fid);

fid = fopen(fullfile(here, 'Amiodarone_Hirai2022_reference.json'), 'w');
try
  s.model = 'Amiodarone_Hirai2022_reference'; s.outputs = p.out_names; s.labels = p.out_labels;
  s.Cmax = out.Cmax; s.Tmax = out.Tmax; s.time_h = out.t(:).';
  for j = 1:numel(p.out_names), s.([p.out_names{j} '_mg_per_L']) = out.C(:, j).'; end
  fprintf(fid, '%s', jsonencode(s));
catch
  fprintf(fid, '{"model":"Amiodarone_Hirai2022_reference"}');
end
fclose(fid);

for j = 1:numel(p.out_names)
  fprintf('%s (%s): Cmax=%.4g mg/L  Tmax=%.3g h\n', p.out_names{j}, p.out_labels{j}, out.Cmax(j), out.Tmax(j));
end
fprintf('wrote Amiodarone_Hirai2022_reference.png, Amiodarone_Hirai2022_reference.csv, Amiodarone_Hirai2022_reference.json\n');
