function p = Amiodarone_Pollak2000_amiodarone_typical_value_params()
% Auto-generated population-PK parameters (clinical units).
%   drug: amiodarone   source: Pollak_2000 / amiodarone_typical_value   route: oral
  p.name  = 'Amiodarone_Pollak2000_amiodarone_typical_value_params';
  p.drug  = 'amiodarone';
  p.ncmt  = 2;              % disposition compartments (central + peripheral)
  p.route = 'oral';        % 'oral' | 'iv_bolus'
  p.depot = true;             % oral -> first-order absorption depot
  p.Vc = 882.0;                % central volume [L]
  p.CL = 9.541667;                % clearance [L/h]
  p.Vp = [12700.0];             % peripheral volumes [L]
  p.Q  = [24.5];             % inter-compartmental clearances [L/h]
  p.ka = 0.82;                % absorption rate [1/h]
  p.F  = 1.0;                 % bioavailability [0-1]
  p.Tlag = 0.0;             % absorption lag [h]
  p.dose = 100.0;             % dose [mg]
end
