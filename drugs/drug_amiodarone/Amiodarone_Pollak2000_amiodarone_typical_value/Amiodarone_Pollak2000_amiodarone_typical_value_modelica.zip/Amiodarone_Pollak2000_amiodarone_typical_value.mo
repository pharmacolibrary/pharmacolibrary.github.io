model Amiodarone_Pollak2000_amiodarone_typical_value
  parameter Real Cl_ref = 2.650462962962963e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.882 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.6453116,
    adminMass = 0.0001,
    ka = 0.00022777777777777775,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About amiodarone</h4><p>Amiodarone is an antiarrhythmic medicine used to treat and prevent various types of irregular heartbeat, including ventricular tachycardia, atrial fibrillation, and other arrhythmias. It is widely used, is included on the WHO list of essential medicines, and is an approved drug.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q410061\">Wikidata Q410061</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>amiodarone</td></tr><tr><td>population:</td><td>patients with cardiac arrhythmias</td></tr><tr><td>source_paper:</td><td>Pollak_2000</td></tr><tr><td>measured_compound:</td><td>amiodarone</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>table ii</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>amiodarone 645.312 g/mol (drugbank); desethylamiodarone 617.257 g/mol (pubchem)</td></tr></table><p><b>Defaulted (base-class default used):</b> Tlag.</p><h4>Interpretation flags</h4><ul><li>dropped unlinked row (NIL): 'Rapid' — extend the ontology if this is a real PK parameter (source ['Pollak_2000_table_2:row7:col1'])</li><li>implicit units: 'Elimination' → 1/day (from the paper text: &quot;The text states: 'terminal half-life was 55 days'. The parameter is identified as the elimination rate constant (kel). S&quot;)</li><li>apparent-ness (ontology-grounded): parameterization=apparent, measured_compound=amiodarone</li><li>topology: transfer parameter unlinked (Q100) — add Kfm/formation-rate/rate-constant to the ontology; routing to review</li><li>template fit: PK_3M_9C — formed from central; parent 2, metabolites [0]</li><li>status held at route_to_review — not promoted</li><li>population split: 'amiodarone typical value' subgroup of Pollak_2000 (paper reports 2 populations: amiodarone typical value, desethylamiodarone typical value)</li><li>row roles (LLM): model_class=compartmental; 6/6 row label(s) assigned, 25 linked by role; re-tagged amiodarone→parent ×26</li><li>gap-filled Q49 (kabs) from Kolowrat_2025's review values (primary lacked it)</li><li>engineer: parent → metabolite not buildable on PK_3M_9C (None) — the measured compound's 1-compartment model instead</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 1209600, Tolerance = 1e-9, Interval = 1));
end Amiodarone_Pollak2000_amiodarone_typical_value;
