% Run (SimBiology): build model + dose, simulate 0..336.0 h, plot.
p = Amiodarone_Pollak2000_amiodarone_typical_value_params();
[model, dose, variant] = build_sb_pk(p);
sd = simulate_sb(model, variant, dose, 336.0);
