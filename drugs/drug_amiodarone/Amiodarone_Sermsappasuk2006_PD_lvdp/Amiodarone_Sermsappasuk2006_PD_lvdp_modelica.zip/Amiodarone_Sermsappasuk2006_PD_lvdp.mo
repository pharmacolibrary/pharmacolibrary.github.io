model Amiodarone_Sermsappasuk2006_PD_lvdp
  "emax exposure-response sweep — Sermsappasuk_2006 :: LVDP (left ventricular developed pressure)"
  extends Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep(
    E0 = 0.0,      // [1]
    Emax = -0.37,  // [1; % × 0.01]
    EC50 = 0.53,  // [M]
    gamma = 1.0,
    exposure_per_s = 1.0);   // 1 M per second
  // inhibition_sign: effect_direction=inhibition with a positive Emax (Q320) — sign flipped
  // exposure_unit_unresolved: 'M' — the x axis is in the paper's unit, not SI
  // defaulted: E0
  // defaulted: gamma
  annotation(experiment(StartTime = 0, StopTime = 5.3, Interval = 0.0106));
end Amiodarone_Sermsappasuk2006_PD_lvdp;
