function p = Amiodarone_Sermsappasuk2006_PD_lvdp_params()
% Amiodarone_Sermsappasuk2006_PD_lvdp_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% amiodarone Sermsappasuk_2006::LVDP: emax exposure-response sweep (response = E0 + Emax*frac). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one M per second, in SI inside (kg/m3, s). Response LVDP in %. Driver: amiodarone (cited_pk).
p.E0 = 0.0;
p.Emax = -0.37;
p.EC50 = 0.53;
p.gamma = 1.0;
p.slope = 0.0;
p.exposure_per_s = 1.0;
p.stop_time = 5.3;
p.form = 'E0 + Emax*frac';
end
