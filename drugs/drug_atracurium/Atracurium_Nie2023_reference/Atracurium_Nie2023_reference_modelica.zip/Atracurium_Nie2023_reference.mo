model Atracurium_Nie2023_reference
  parameter Real Cl_ref = 9.283333333333335e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.0325 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_2C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.9291609999999999,
    adminMass = 1e-05,
    k12 = 0.0020940170940170937,
    k21 = 0.0008150365934797071
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About atracurium</h4><p>Atracurium is a muscle relaxant used to relax muscles during surgery and to help with insertion of a breathing tube under anaesthesia. It is widely used in anaesthetic practice and appears on the WHO list of essential medicines.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q165660\">Wikidata Q165660</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>atracurium</td></tr><tr><td>population:</td><td>review reference</td></tr><tr><td>source_paper:</td><td>Nie_2023</td></tr><tr><td>measured_compound:</td><td>atracurium</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>2C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_2C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>atracurium 929.161 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>built from REVIEW reference values (Nie_2023) — secondary source</li><li>volume reported by review</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Atracurium_Nie2023_reference;
