model Atracurium_Fisher1990_reference
  parameter Real Cl_ref = 9.216666666666666e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.329 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.9291609999999999,
    adminMass = 1e-05
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About atracurium</h4><p>Atracurium is a muscle relaxant used to relax muscles during surgery and to help with insertion of a breathing tube under anaesthesia. It is widely used in anaesthetic practice and appears on the WHO list of essential medicines.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q165660\">Wikidata Q165660</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>atracurium</td></tr><tr><td>population:</td><td>infants, children, and adults</td></tr><tr><td>source_paper:</td><td>Fisher_1990</td></tr><tr><td>measured_compound:</td><td>atracurium</td></tr><tr><td>parameterization:</td><td>mechanistic</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C: IV (no input phase)</td></tr><tr><td>molar_masses:</td><td>atracurium 929.161 g/mol (pubchem)</td></tr></table><h4>Interpretation flags</h4><ul><li>dropped unlinked row (NIL): 'steady state plasma concentration that resulted in 50% neuromuscular blockade' — extend the ontology if this is a real PK parameter (source ['Fisher_1990:abstract', 'Fisher_1990:abstract', 'Fisher_1990:abstract'])</li><li>apparent-ness (ontology-grounded): parameterization=mechanistic, measured_compound=atracurium</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li><li>gap-filled Q61 (V) from Cavallaro_2026's review values (primary lacked it)</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Atracurium_Fisher1990_reference;
