model Duloxetine_Tianmei2007_reference
  parameter Real Cl_ref = 2.4111111111111113e-05 "Cl [m3/s]";
  parameter Real Vd_ref = 1.57 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.29741500000000004,
    adminMass = 6e-05,
    ka = 0.00040555555555555554,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About duloxetine</h4><p>Duloxetine is an antidepressant (a serotonin–norepinephrine reuptake inhibitor) used for major depressive disorder, anxiety disorders, and nerve-related pain conditions such as diabetic neuropathy and fibromyalgia. It is approved and widely used, with several products authorised in the European Union.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q411932\">Wikidata Q411932</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>duloxetine</td></tr><tr><td>population:</td><td>healthy Chinese adults</td></tr><tr><td>source_paper:</td><td>Tianmei_2007</td></tr><tr><td>measured_compound:</td><td>duloxetine</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>duloxetine 297.415 g/mol (drugbank)</td></tr></table><p><b>Defaulted (base-class default used):</b> Tlag.</p><h4>Interpretation flags</h4><ul><li>dropped unlinked row (NIL): 'linearity index' — extend the ontology if this is a real PK parameter (source ['Tianmei_2007:abstract'])</li><li>dropped unlinked row (NIL): 'accumulation in duloxetine exposure' — extend the ontology if this is a real PK parameter (source ['Tianmei_2007:abstract'])</li><li>apparent-ness (ontology-grounded): parameterization=apparent, measured_compound=duloxetine</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li><li>gap-filled Q49 (kabs) from Chen_2024's review values (primary lacked it)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 259200, Tolerance = 1e-9, Interval = 1));
end Duloxetine_Tianmei2007_reference;
