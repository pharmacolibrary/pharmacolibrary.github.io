model Duloxetine_Chen2024_reference
  parameter Real Cl_ref = 3.277777777777778e-05 "Cl [m3/s]";
  parameter Real Vd_ref = 2.46 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.29741500000000004,
    adminMass = 6e-05,
    ka = 0.00040555555555555554,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About duloxetine</h4><p>Duloxetine is an antidepressant (a serotonin–norepinephrine reuptake inhibitor) used for major depressive disorder, anxiety disorders, and nerve-related pain conditions such as diabetic neuropathy and fibromyalgia. It is approved and widely used, with several products authorised in the European Union.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q411932\">Wikidata Q411932</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>duloxetine</td></tr><tr><td>population:</td><td>review reference</td></tr><tr><td>source_paper:</td><td>Chen_2024</td></tr><tr><td>measured_compound:</td><td>duloxetine</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>duloxetine 297.415 g/mol (drugbank)</td></tr></table><p><b>Defaulted (base-class default used):</b> Tlag.</p><h4>Interpretation flags</h4><ul><li>built from REVIEW reference values (Chen_2024) — secondary source</li><li>volume reported by review</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 345600, Tolerance = 1e-9, Interval = 1));
end Duloxetine_Chen2024_reference;
