model Lanreotide_Cendros2005_PD_gh
  "emax exposure-response sweep — Cendros_2005 :: GH (serum growth hormone (GH) concentrations)"
  extends Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep(
    E0 = 8.63e-06,      // [kg/m3; ng/mL × 1e-06]
    Emax = -0.82,  // [1; % × 0.01]
    EC50 = 2.06e-07,  // [kg/m3; ng/mL × 1e-06]
    gamma = 1,
    exposure_per_s = 1e-06);   // 1 ng/mL per second
  // imax_as_negative_emax: Imax (Q323) enters SigmoidEmaxSweep as −Emax
  // defaulted: gamma
  annotation(experiment(StartTime = 0, StopTime = 2.1, Interval = 0.0042),
    Documentation(info = "<html><body><!-- drug-about --><h4>About lanreotide</h4><p>Lanreotide is a synthetic somatostatin analogue used as a hormonal and antineoplastic drug. It is an approved medicine, also under investigation for additional uses.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q1707877\">Wikidata Q1707877</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h4>Lanreotide_Cendros2005_PD_gh</h4><p>The steady-state exposure-response curve of Cendros JM et al., <i>Metabolism: clinical and experimental 54(10):1276–1281</i> 2005 (<a href=\"https://doi.org/10.1016/j.metabol.2005.04.014\">doi:10.1016/j.metabol.2005.04.014</a>) — serum growth hormone (GH) concentrations [ng/mL] against lanreotide ng/mL — obtained by sweeping the driver instead of simulating a dose. Model family: emax.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    =       8.63 ng/mL    drug-free response (baseline) (E0, Q324)
  Emax  =         82 %        maximal effect term (Imax, Q323)
  EC50  =      0.206 ng/mL    exposure at half of the maximal effect term (EC50, Q321)
  gamma = (library default) Hill coefficient</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep\">SigmoidEmaxSweep</a>; this model only supplies the numbers. The x axis is one ng/mL of lanreotide per second of simulated time (exposure is in kg/m3): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 8.63e-06   (drug-free)
  exposure = EC50 (0.206 ng/mL)  response -0.41
  exposure -> infinity  response -0.82</pre></body></html>"));
end Lanreotide_Cendros2005_PD_gh;
