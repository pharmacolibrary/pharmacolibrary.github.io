function p = Lanreotide_Cendros2005_PD_gh_params()
% Lanreotide_Cendros2005_PD_gh_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% lanreotide Cendros_2005::GH: emax exposure-response sweep (response = E0 + Emax*frac). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one ng/mL per second, in SI inside (kg/m3, s). Response GH in ng/mL. Driver: lanreotide (cited_pk).
p.E0 = 8.63e-06;
p.Emax = -0.8200000000000001;
p.EC50 = 2.06e-07;
p.gamma = 1.0;
p.slope = 0.0;
p.exposure_per_s = 1e-06;
p.stop_time = 2.1;
p.form = 'E0 + Emax*frac';
end
