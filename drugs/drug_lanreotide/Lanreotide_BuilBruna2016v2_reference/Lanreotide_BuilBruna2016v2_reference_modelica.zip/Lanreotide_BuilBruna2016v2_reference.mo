model Lanreotide_BuilBruna2016v2_reference
  parameter Real Cl_ref = 5.9375e-06 "Cl [m3/s]";
  parameter Real Vd_ref = 0.0183 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 1.09633,
    adminMass = 0.0001,
    ka = 0.0001388888888888889,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About lanreotide</h4><p>Lanreotide is a synthetic somatostatin analogue used as a hormonal and antineoplastic drug. It is an approved medicine, also under investigation for additional uses.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q1707877\">Wikidata Q1707877</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>lanreotide</td></tr><tr><td>population:</td><td>patients with gastroenteropancreatic neuroendocrine tumors</td></tr><tr><td>source_paper:</td><td>Buil-Bruna_2016_2</td></tr><tr><td>measured_compound:</td><td>lanreotide</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C_enteral: apparent (/F) parameterization ⇒ extravascular dosing</td></tr><tr><td>molar_masses:</td><td>lanreotide 1096.33 g/mol (drugbank)</td></tr></table><p><b>Defaulted (base-class default used):</b> ka, Tlag.</p><h4>Interpretation flags</h4><ul><li>dropped value-less row: 'Body weight'</li><li>dropped value-less row: 'clearance'</li><li>dropped value-less row: 'volume of distribution'</li><li>dropped value-less row: 'absorption constant'</li><li>apparent-ness (ontology-grounded): parameterization=apparent, measured_compound=lanreotide</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li><li>skipped review gap-fill of V2: primary is 1C (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is 1C (peripheral family needs ≥2C)</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Lanreotide_BuilBruna2016v2_reference;
