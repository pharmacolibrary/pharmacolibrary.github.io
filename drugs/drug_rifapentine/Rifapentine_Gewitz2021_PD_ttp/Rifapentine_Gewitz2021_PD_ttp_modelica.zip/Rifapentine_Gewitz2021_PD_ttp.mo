model Rifapentine_Gewitz2021_PD_ttp
  "linear exposure-response sweep — Gewitz_2021 :: TTP (time to positivity (TTP))"
  extends Pharmacolibrary.Interfaces.PartialExposureResponseSweep(
    E0 = 0,      // [1]
    Emax = 0, EC50 = 1,      // unused by a line
    exposure_per_s = 1);
  parameter Real slope = 0.301   "[1]";
equation
  response = E0 + slope*exposure;
  // defaulted: E0
  annotation(experiment(StartTime = 0, StopTime = 1000, Interval = 2),
    Documentation(info = "<html><body><!-- drug-about --><h4>About rifapentine</h4><p>Rifapentine is an antibiotic used to treat pulmonary tuberculosis. It is an approved medicine and appears on the WHO essential medicines list, though it is not authorised in the European Union.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q3935297\">Wikidata Q3935297</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h4>Rifapentine_Gewitz2021_PD_ttp</h4><p>The steady-state exposure-response curve of Gewitz AD et al., <i>Antimicrobial agents and chemotherapy 65(10):e0179420</i> 2021 (<a href=\"https://doi.org/10.1128/AAC.01794-20\">doi:10.1128/AAC.01794-20</a>) — time to positivity (TTP) [days] against rifapentine AUC0-24 — obtained by sweeping the driver instead of simulating a dose. Model family: linear.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = (library default) drug-free response (baseline)
  slope =      0.301          change in response per unit of exposure (Slope, Q335)</pre><p>The algebra is <code>response = E0 + slope*exposure</code>; this model only supplies the numbers. The x axis is one AUC0-24 of rifapentine per second of simulated time: there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0   (drug-free)</pre></body></html>"));
end Rifapentine_Gewitz2021_PD_ttp;
