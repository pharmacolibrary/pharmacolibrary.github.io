function p = Rifapentine_Gewitz2021_PD_ttp_params()
% Rifapentine_Gewitz2021_PD_ttp_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% rifapentine Gewitz_2021::TTP: linear exposure-response sweep (response = E0 + slope*exposure). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one AUC0-24 per second, in SI inside (kg/m3, s). Response TTP in days. Driver: rifapentine (cited_pk).
p.E0 = 0.0;
p.Emax = 0.0;
p.EC50 = 1.0;
p.gamma = 1.0;
p.slope = 0.301;
p.exposure_per_s = 1.0;
p.stop_time = 1000.0;
p.form = 'E0 + slope*exposure';
end
