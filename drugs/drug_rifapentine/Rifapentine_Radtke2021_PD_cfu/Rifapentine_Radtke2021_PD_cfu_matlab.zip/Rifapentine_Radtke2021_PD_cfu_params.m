function p = Rifapentine_Radtke2021_PD_cfu_params()
% Rifapentine_Radtke2021_PD_cfu_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% rifapentine Radtke_2021::CFU: emax exposure-response sweep (response = E0 + Emax*frac). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one mg/liter per second, in SI inside (kg/m3, s). Response CFU in its own unit. Driver: rifapentine (cited_pk).
p.E0 = 0.0;
p.Emax = -2.7777777777777775e-06;
p.EC50 = 0.004709999999999999;
p.gamma = 1.0;
p.slope = 0.0;
p.exposure_per_s = 0.001;
p.stop_time = 48.0;
p.form = 'E0 + Emax*frac';
end
