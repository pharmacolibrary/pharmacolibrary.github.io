model Rifapentine_Radtke2021_PD_cfu
  "emax exposure-response sweep — Radtke_2021 :: CFU (lung CFU)"
  extends Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep(
    E0 = 0,      // [1]
    Emax = -2.77777777778e-06,  // [1/s; day-1 × 1.15741e-05]
    EC50 = 0.00471,  // [kg/m3; mg/liter × 0.001]
    gamma = 1,
    exposure_per_s = 0.001);   // 1 mg/liter per second
  // imax_as_negative_emax: Imax (Q323) enters SigmoidEmaxSweep as −Emax
  // defaulted: E0
  // defaulted: gamma
  annotation(experiment(StartTime = 0, StopTime = 48, Interval = 0.096),
    Documentation(info = "<html><body><!-- drug-about --><h4>About rifapentine</h4><p>Rifapentine is an antibiotic used to treat pulmonary tuberculosis. It is an approved medicine and appears on the WHO essential medicines list, though it is not authorised in the European Union.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q3935297\">Wikidata Q3935297</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h4>Rifapentine_Radtke2021_PD_cfu</h4><p>The steady-state exposure-response curve of Radtke KK et al., <i>Antimicrobial agents and chemotherapy 65(12):e0170521</i> 2021 (<a href=\"https://doi.org/10.1128/AAC.01705-21\">doi:10.1128/AAC.01705-21</a>) — lung CFU against rifapentine mg/liter — obtained by sweeping the driver instead of simulating a dose. Model family: emax.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = (library default) drug-free response (baseline)
  Emax  =       0.24 day-1    maximal effect term (Emax, Q323)
  EC50  =       4.71 mg/liter exposure at half of the maximal effect term (EC50, Q321)
  gamma = (library default) Hill coefficient</pre><p>The algebra is <a href=\"modelica://Pharmacolibrary.Pharmacodynamic.SigmoidEmaxSweep\">SigmoidEmaxSweep</a>; this model only supplies the numbers. The x axis is one mg/liter of rifapentine per second of simulated time (exposure is in kg/m3): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0   (drug-free)
  exposure = EC50 (4.71 mg/liter)  response -1.389e-06
  exposure -> infinity  response -2.778e-06</pre></body></html>"));
end Rifapentine_Radtke2021_PD_cfu;
