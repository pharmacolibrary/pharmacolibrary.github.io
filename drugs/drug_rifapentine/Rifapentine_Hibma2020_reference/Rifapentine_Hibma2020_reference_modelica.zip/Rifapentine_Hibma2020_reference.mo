model Rifapentine_Hibma2020_reference
  parameter Real Cl_ref = 8.638888888888889e-07 "Cl [m3/s]";
  parameter Real Vd_ref = 0.00215 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.8770307,
    adminMass = 0.0003,
    ka = 0.0001388888888888889,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About rifapentine</h4><p>Rifapentine is an antibiotic used to treat pulmonary tuberculosis. It is an approved medicine and appears on the WHO essential medicines list, though it is not authorised in the European Union.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q3935297\">Wikidata Q3935297</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>rifapentine</td></tr><tr><td>population:</td><td>adults with latent tuberculosis infection</td></tr><tr><td>source_paper:</td><td>Hibma_2020</td></tr><tr><td>measured_compound:</td><td>rifapentine</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>tab_1</td></tr><tr><td>input:</td><td>PK_1C_enteral: apparent (/F) parameterization ⇒ extravascular dosing</td></tr><tr><td>molar_masses:</td><td>rifapentine 877.031 g/mol (drugbank)</td></tr></table><p><b>Defaulted (base-class default used):</b> ka, Tlag.</p><h4>Interpretation flags</h4><ul><li>the dosed compound is rifapentine; the compartment is rifapentine. Input enters at the reported formation rate, so formation is already accounted for in the input step and the simulated concentration is rifapentine, not rifapentine</li><li>apparent parameters (CLm/F, Vm/F) already contain F and the metabolised fraction, so F=1 and no molar correction is applied — adding either would double-count it</li><li>rifapentine's own concentration-time course is not produced by this model</li><li>table section iiv: 'Parameter' routed out of structural estimates ('Interindividual Variability')</li><li>table section iiv: 'CL/F, L/h' routed out of structural estimates ('Interindividual Variability')</li><li>table section iiv: 'V/F, L' routed out of structural estimates ('Interindividual Variability')</li><li>table section iiv: 'MTT, h' routed out of structural estimates ('Interindividual Variability')</li><li>table section iiv: 'NN' routed out of structural estimates ('Interindividual Variability')</li><li>table section iiv: 'Dose' routed out of structural estimates ('Interindividual Variability')</li><li>table section iiv: 'HIV infection' routed out of structural estimates ('Interindividual Variability')</li><li>table section iiv: 'High-fat meal' routed out of structural estimates ('Interindividual Variability')</li><li>table section iiv: 'Residual error of rifapentine' routed out of structural estimates ('Interindividual Variability')</li><li>table section iiv: 'CL m /f m , L/h' routed out of structural estimates ('Interindividual Variability')</li><li>table section iiv: 'V m /f m , L' routed out of structural estimates ('Interindividual Variability')</li><li>dropped unlinked row (NIL): 'Dose' — extend the ontology if this is a real PK parameter (source ['tab_1:row7:col1'])</li><li>dropped unlinked row (NIL): 'HIV infection' — extend the ontology if this is a real PK parameter (source ['tab_1:row8:col1'])</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 86400, Tolerance = 1e-9, Interval = 1));
end Rifapentine_Hibma2020_reference;
