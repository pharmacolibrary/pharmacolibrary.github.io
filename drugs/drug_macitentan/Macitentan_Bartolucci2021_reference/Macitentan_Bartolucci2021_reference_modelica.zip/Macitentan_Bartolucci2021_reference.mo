model Macitentan_Bartolucci2021_reference
  parameter Real Cl_ref = 3.861111111111111e-07 "Cl [m3/s]";
  parameter Real Vd_ref = 0.034 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.588273,
    adminMass = 1e-05,
    ka = 0.0038666666666666667,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About macitentan</h4><p>Macitentan is an endothelin receptor antagonist used to treat pulmonary arterial hypertension. It is authorised in the European Union for pulmonary hypertension.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q6724151\">Wikidata Q6724151</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>macitentan</td></tr><tr><td>population:</td><td>healthy adults and adult subjects with pulmonary arterial hypertension</td></tr><tr><td>source_paper:</td><td>Bartolucci_2021</td></tr><tr><td>measured_compound:</td><td>macitentan</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C_enteral: absorption rate constant reported</td></tr><tr><td>molar_masses:</td><td>aprocitentan 546.194 g/mol (pubchem); macitentan 588.273 g/mol (drugbank)</td></tr></table><p><b>Defaulted (base-class default used):</b> Tlag.</p><h4>Interpretation flags</h4><ul><li>dropped unlinked row (NIL): 'accumulation factor' — extend the ontology if this is a real PK parameter (source ['Bartolucci_2021:abstract', 'Bartolucci_2021:abstract'])</li><li>apparent-ness (ontology-grounded): parameterization=apparent, measured_compound=macitentan</li><li>template fit: none — noncompartmental model — not a compartmental parent–metabolite model</li><li>row roles (LLM): model_class=noncompartmental; 5/5 row label(s) assigned, 0 linked by role</li><li>abstract-only: no full text was available, so these values were read from the abstract's prose — reported summary statistics, not a fitted model</li><li>skipped review gap-fill of V2: primary is PARENT_METABOLITE (peripheral family needs ≥2C)</li><li>skipped review gap-fill of Q: primary is PARENT_METABOLITE (peripheral family needs ≥2C)</li><li>gap-filled Q49 (kabs) from Liu_2020's review values (primary lacked it)</li><li>engineer: parent → metabolite not buildable on PK_3M_9C (None) — the measured compound's 1-compartment model instead</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 345600, Tolerance = 1e-9, Interval = 1));
end Macitentan_Bartolucci2021_reference;
