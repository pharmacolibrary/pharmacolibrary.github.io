model OmecamtivMecarbil_Vu2015_PD_lvotsv
  "linear exposure-response sweep — Vu_2015 :: LVOTSV (Doppler-derived left ventricular outflow tract stroke volume (LVOTSV))"
  extends Pharmacolibrary.Interfaces.PartialExposureResponseSweep(
    E0 = 0,      // [1]
    Emax = 0, EC50 = 1,      // unused by a line
    exposure_per_s = 1e-06);
  parameter Real slope = 1.6   "[mL per 100 ng/mL]";
equation
  response = E0 + slope*exposure;
  // defaulted: E0
  annotation(experiment(StartTime = 0, StopTime = 1000, Interval = 2),
    Documentation(info = "<html><body><!-- drug-about --><h4>About omecamtiv_mecarbil</h4><p>Omecamtiv mecarbil is an investigational cardiac stimulant studied for the treatment of heart failure with reduced pumping function (systolic heart failure). It has not been approved; a marketing application in the European Union was withdrawn, so it remains an investigational drug.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q7089956\">Wikidata Q7089956</a> and the WHO ATC classification and the EMA medicines list; not checked by a person.</small></p><!-- /drug-about --><h4>OmecamtivMecarbil_Vu2015_PD_lvotsv</h4><p>The steady-state exposure-response curve of Vu T et al., <i>Journal of clinical pharmacology 55(11):1236–1247</i> 2015 (<a href=\"https://doi.org/10.1002/jcph.538\">doi:10.1002/jcph.538</a>) — Doppler-derived left ventricular outflow tract stroke volume (LVOTSV) [mL] against omecamtiv mecarbil ng/mL — obtained by sweeping the driver instead of simulating a dose. Model family: linear.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = (library default) drug-free response (baseline)
  slope =        1.6 mL per 100 ng/mL change in response per unit of exposure (slope, Q335)</pre><p>The algebra is <code>response = E0 + slope*exposure</code>; this model only supplies the numbers. The x axis is one ng/mL of omecamtiv mecarbil per second of simulated time (exposure is in kg/m3): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 0   (drug-free)</pre></body></html>"));
end OmecamtivMecarbil_Vu2015_PD_lvotsv;
