function p = OmecamtivMecarbil_Vu2015_PD_lvotsv_params()
% OmecamtivMecarbil_Vu2015_PD_lvotsv_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% omecamtiv_mecarbil Vu_2015::LVOTSV: linear exposure-response sweep (response = E0 + slope*exposure). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one ng/mL per second, in SI inside (kg/m3, s). Response LVOTSV in mL. Driver: omecamtiv mecarbil (cited_pk).
p.E0 = 0.0;
p.Emax = 0.0;
p.EC50 = 1.0;
p.gamma = 1.0;
p.slope = 1.6;
p.exposure_per_s = 1e-06;
p.stop_time = 1000.0;
p.form = 'E0 + slope*exposure';
end
