function p = Dexamethasone_Yu2026_PD_cts_params()
% Dexamethasone_Yu2026_PD_cts_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% dexamethasone Yu_2026::CTS: indirect_response_i exposure-response sweep (response = E0*(1 - Emax*frac)). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one ng/mL per second, in SI inside (kg/m3, s). Response CTS in ng/mL. Driver: dexamethasone (pk_record).
p.E0 = 0.0;
p.Emax = 1.0;
p.EC50 = 3.83e-08;
p.gamma = 1.0;
p.slope = 0.0;
p.exposure_per_s = 1e-06;
p.stop_time = 0.39;
p.form = 'E0*(1 - Emax*frac)';
end
