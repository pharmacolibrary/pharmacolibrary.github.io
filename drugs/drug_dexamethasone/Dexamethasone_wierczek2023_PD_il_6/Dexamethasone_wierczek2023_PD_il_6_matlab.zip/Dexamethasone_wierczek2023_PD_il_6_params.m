function p = Dexamethasone_wierczek2023_PD_il_6_params()
% Dexamethasone_wierczek2023_PD_il_6_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% dexamethasone Świerczek_2023::IL_6: indirect_response_i exposure-response sweep (response = E0*(1 - Emax*frac)). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one ng/mL per second, in SI inside (kg/m3, s). Response IL-6 in pg/mL. Driver: dexamethasone (pk_record).
p.E0 = 5.970000000000001e-08;
p.Emax = 0.83;
p.EC50 = 3.35e-06;
p.gamma = 1.0;
p.slope = 0.0;
p.exposure_per_s = 1e-06;
p.stop_time = 34.0;
p.form = 'E0*(1 - Emax*frac)';
end
