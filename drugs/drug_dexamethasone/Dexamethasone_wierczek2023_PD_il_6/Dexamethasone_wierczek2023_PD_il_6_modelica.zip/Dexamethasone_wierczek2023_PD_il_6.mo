model Dexamethasone_wierczek2023_PD_il_6
  "indirect_response_i exposure-response sweep — Świerczek_2023 :: IL-6 (IL-6)"
  extends Pharmacolibrary.Interfaces.PartialExposureResponseSweep(
    E0 = 5.97e-08,      // [kg/m3; pg/mL × 1e-09]
    Emax = 0.83,  // type I effect term
    EC50 = 3.35e-06,  // [kg/m3; ng/mL × 1e-06]
    gamma = 1,
    exposure_per_s = 1e-06);   // 1 ng/mL per second
equation
  response = E0*(1 - Emax*frac);   // steady state, indirect response type I
  // defaulted: gamma
  annotation(experiment(StartTime = 0, StopTime = 34, Interval = 0.068),
    Documentation(info = "<html><body><h4>Dexamethasone_wierczek2023_PD_il_6</h4><p>The steady-state exposure-response curve of Świerczek A et al., <i>Clinical and translational science 16(9):1667–1679</i> 2023 (<a href=\"https://doi.org/10.1111/cts.13577\">doi:10.1111/cts.13577</a>) — IL-6 [pg/mL] against dexamethasone ng/mL — obtained by sweeping the driver instead of simulating a dose. Model family: indirect_response_i.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    =       59.7 pg/mL    drug-free response (baseline) (R 0IL6, Q324)
  Emax  =       0.83          maximal effect term (I maxDEX(IL6), Q323)
  EC50  =       3.35 ng/mL    exposure at half of the maximal effect term (IC50DEX(IL6), Q322)
  gamma = (library default) Hill coefficient</pre><p>The algebra is <code>response = E0*(1 - Emax*frac)</code>; this model only supplies the numbers. The x axis is one ng/mL of dexamethasone per second of simulated time (exposure is in kg/m3): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 5.97e-08   (drug-free)
  exposure = EC50 (3.35 ng/mL)  response 3.492e-08
  exposure -> infinity  response 1.015e-08</pre></body></html>"));
end Dexamethasone_wierczek2023_PD_il_6;
