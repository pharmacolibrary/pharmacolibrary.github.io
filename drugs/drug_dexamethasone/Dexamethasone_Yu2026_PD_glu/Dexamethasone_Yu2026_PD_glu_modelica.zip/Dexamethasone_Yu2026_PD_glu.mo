model Dexamethasone_Yu2026_PD_glu
  "indirect_response_iii exposure-response sweep — Yu_2026 :: GLU (glucose)"
  extends Pharmacolibrary.Interfaces.PartialExposureResponseSweep(
    E0 = 4.63917525773,      // [mM]
    Emax = 1.187,  // type III effect term
    EC50 = 7.99e-07,  // [kg/m3; ng/mL × 1e-06]
    gamma = 1,
    exposure_per_s = 1e-06);   // 1 ng/mL per second
equation
  response = E0*(1 + Emax*frac);   // steady state, indirect response type III
  // e0_from_kin_kout: no baseline row; E0 = kin/kout (0.225/0.0485 = 4.639) — the paper's stated baseline may differ
  // defaulted: gamma
  annotation(experiment(StartTime = 0, StopTime = 8, Interval = 0.016),
    Documentation(info = "<html><body><h4>Dexamethasone_Yu2026_PD_glu</h4><p>The steady-state exposure-response curve of Yu R et al., <i>Pharmaceutical research</i> 2026 (<a href=\"https://doi.org/10.1007/s11095-026-04120-5\">doi:10.1007/s11095-026-04120-5</a>) — glucose [mM] against dexamethasone ng/mL — obtained by sweeping the driver instead of simulating a dose. Model family: indirect_response_iii.</p><h4>The parameters, in the paper's terms</h4><pre>  E0    = 4.63917525773 mM       drug-free response (baseline) (kin/kout, Q327/Q328)
  Emax  =      1.187          maximal effect term (E max, Q320)
  EC50  =      0.799 ng/mL    exposure at half of the maximal effect term (EC 50, Q321)
  gamma = (library default) Hill coefficient</pre><p>The algebra is <code>response = E0*(1 + Emax*frac)</code>; this model only supplies the numbers. The x axis is one ng/mL of dexamethasone per second of simulated time (exposure is in kg/m3): there is no state, no dose and no kinetics — plot <code>response</code> against <code>exposure</code> (or <code>time</code>).</p><h4>What it reproduces</h4><pre>  exposure = 0         response 4.639   (drug-free)
  exposure = EC50 (0.799 ng/mL)  response 7.393
  exposure -> infinity  response 10.15</pre></body></html>"));
end Dexamethasone_Yu2026_PD_glu;
