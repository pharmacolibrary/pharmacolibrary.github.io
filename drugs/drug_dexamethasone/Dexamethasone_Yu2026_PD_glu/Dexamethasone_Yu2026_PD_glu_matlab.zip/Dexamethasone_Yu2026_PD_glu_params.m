function p = Dexamethasone_Yu2026_PD_glu_params()
% Dexamethasone_Yu2026_PD_glu_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% dexamethasone Yu_2026::GLU: indirect_response_iii exposure-response sweep (response = E0*(1 + Emax*frac)). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one ng/mL per second, in SI inside (kg/m3, s). Response GLU in mM. Driver: dexamethasone (pk_record).
p.E0 = 4.639175257731959;
p.Emax = 1.187;
p.EC50 = 7.99e-07;
p.gamma = 1.0;
p.slope = 0.0;
p.exposure_per_s = 1e-06;
p.stop_time = 8.0;
p.form = 'E0*(1 + Emax*frac)';
end
