function p = Dexamethasone_wierczek2023_PD_tnf_params()
% Dexamethasone_wierczek2023_PD_tnf_params  PD exposure-response sweep parameters (SI: kg/m3, s).
% dexamethasone Świerczek_2023::TNF: indirect_response_i exposure-response sweep (response = E0*(1 - Emax*frac)). Simulated time IS the swept exposure: exposure = exposure_per_s * time, one ng/mL per second, in SI inside (kg/m3, s). Response TNFα in pg/mL. Driver: dexamethasone (pk_record).
p.E0 = 1.0900000000000002e-08;
p.Emax = 0.805;
p.EC50 = 2.25e-06;
p.gamma = 1.0;
p.slope = 0.0;
p.exposure_per_s = 1e-06;
p.stop_time = 23.0;
p.form = 'E0*(1 - Emax*frac)';
end
