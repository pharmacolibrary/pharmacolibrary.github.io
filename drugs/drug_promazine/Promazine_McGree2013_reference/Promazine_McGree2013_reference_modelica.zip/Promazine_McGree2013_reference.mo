model Promazine_McGree2013_reference
  parameter Real Cl_ref = 0.00021361111111111111 "Cl [m3/s]";
  parameter Real Vd_ref = 6.8740000000000006 "Vd [m3]";
  extends Pharmacolibrary.Pharmacokinetic.Models.PK_1C_enteral(
    weight = 70.0,
    F = 1,
    Cl = Cl_ref,
    Vd = Vd_ref,
    adminDuration = 600,
    adminCount = 1,
    MM = 0.284419,
    adminMass = 0.0003,
    ka = 0.0001388888888888889,
    Tlag = 0.0
  );

  annotation (Documentation(info = "<html><body><!-- drug-about --><h4>About promazine</h4><p>Promazine is a phenothiazine antipsychotic used to treat schizophreniform disorder and vomiting. It has been withdrawn from human use, though it remains an approved veterinary drug.</p><p><small>Summary written by glm-5.3-flash from <a href=\"https://www.wikidata.org/wiki/Q419822\">Wikidata Q419822</a> and the WHO ATC classification; not checked by a person.</small></p><!-- /drug-about --><h3>ModelCard</h3><table><tr><td>drug:</td><td>promazine</td></tr><tr><td>population:</td><td>review reference</td></tr><tr><td>source_paper:</td><td>McGree_2013</td></tr><tr><td>measured_compound:</td><td>promazine</td></tr><tr><td>parameterization:</td><td>apparent</td></tr><tr><td>template:</td><td>1C</td></tr><tr><td>result_var:</td><td>C_central</td></tr><tr><td>final_model_source:</td><td>None</td></tr><tr><td>input:</td><td>PK_1C_enteral: apparent (/F) parameterization ⇒ extravascular dosing</td></tr><tr><td>molar_masses:</td><td>promazine 284.419 g/mol (drugbank)</td></tr></table><p><b>Defaulted (base-class default used):</b> ka, Tlag.</p><h4>Interpretation flags</h4><ul><li>built from REVIEW reference values (McGree_2013) — secondary source</li><li>volume reported by review</li></ul></body></html>"),
    experiment(StartTime = 0, StopTime = 111600, Tolerance = 1e-9, Interval = 1));
end Promazine_McGree2013_reference;
